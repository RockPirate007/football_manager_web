'use client';

import { useEffect, useState } from 'react';
import {
  ArrowLeftRight, Building2, ClipboardList, Dumbbell, FastForward, Globe, GraduationCap,
  LayoutDashboard, Medal, Newspaper, PlayCircle, Search, Table2, Trophy, UserRound, Users, Wallet,
} from 'lucide-react';
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
  CommandSeparator, CommandShortcut,
} from '@/components/ui/command';
import { Button } from '@/components/ui/button';
import { useGameStore, type TabId } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Разделы палитры — те же группы, что в сайдбаре (единый источник NAV в GameShell). */
const SECTIONS: Array<{ group: string; items: Array<{ id: TabId; label: string; icon: typeof Users }> }> = [
  {
    group: 'Разделы',
    items: [
      { id: 'dashboard', label: 'Дашборд', icon: LayoutDashboard },
      { id: 'match', label: 'Матч', icon: PlayCircle },
      { id: 'squad', label: 'Состав', icon: Users },
      { id: 'tactics', label: 'Тактика', icon: ClipboardList },
      { id: 'training', label: 'Тренировки', icon: Dumbbell },
      { id: 'academy', label: 'Академия', icon: GraduationCap },
      { id: 'league', label: 'Лига', icon: Table2 },
      { id: 'cup', label: 'Кубок', icon: Trophy },
      { id: 'euro', label: 'Европа', icon: Globe },
      { id: 'awards', label: 'Награды', icon: Medal },
      { id: 'transfers', label: 'Трансферы', icon: ArrowLeftRight },
      { id: 'finances', label: 'Финансы', icon: Wallet },
      { id: 'territory', label: 'Территория', icon: Building2 },
      { id: 'media', label: 'Медиа', icon: Newspaper },
      { id: 'coach', label: 'Тренер', icon: UserRound },
    ],
  },
];

/**
 * Модуль 6 — командная палитра (Ctrl+K / ⌘K): быстрый переход по разделам
 * + контекстные действия (играть матч / симулировать неделю / скорости).
 * FM-паттерн «quick access»: палитра НЕ активна во время live-матча.
 */
export function CommandPalette({ disabled }: { disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  const setTab = useGameStore((s) => s.setTab);
  const activeTab = useGameStore((s) => s.activeTab);
  const matchView = useGameStore((s) => s.matchView);
  const snapshot = useGameStore((s) => s.snapshot);
  const playWeek = useGameStore((s) => s.playWeek);
  const loading = useGameStore((s) => s.loading);

  // Глобальный хоткей Ctrl+K / ⌘K (не в инпутах — Cmd+K в поле ввода не перехватываем)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        const target = e.target as HTMLElement | null;
        if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
          return;
        }
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const canPlay = matchView === 'prematch' && !disabled && !!snapshot?.nextMatch;
  const canSim = matchView === 'prematch' && !disabled && !!snapshot && !snapshot.nextMatch;

  const go = (id: TabId) => {
    setTab(id);
    setOpen(false);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="hidden h-9 gap-2 border-border/60 text-muted-foreground md:flex"
        onClick={() => setOpen(true)}
        aria-label="Открыть командную палитру (Ctrl+K)"
        title="Быстрый переход — Ctrl+K"
        disabled={disabled}
      >
        <Search className="size-3.5" aria-hidden />
        <span className="text-[11px]">Переход</span>
        <kbd className="pointer-events-none ml-1 rounded border border-border/60 bg-secondary/60 px-1.5 py-0.5 text-[10px] font-semibold">
          Ctrl K
        </kbd>
      </Button>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Раздел или действие…" />
        <CommandList>
          <CommandEmpty>Ничего не найдено.</CommandEmpty>

          {(canPlay || canSim) && !loading ? (
            <CommandGroup heading="Действия">
              {canPlay ? (
                <CommandItem onSelect={() => { go('match'); void playWeek(); }}>
                  <PlayCircle className="size-4" aria-hidden />
                  <span>Играть матч недели</span>
                  <CommandShortcut>↵</CommandShortcut>
                </CommandItem>
              ) : null}
              {canSim ? (
                <CommandItem onSelect={() => { void playWeek(); setOpen(false); }}>
                  <FastForward className="size-4" aria-hidden />
                  <span>Симулировать неделю</span>
                  <CommandShortcut>↵</CommandShortcut>
                </CommandItem>
              ) : null}
            </CommandGroup>
          ) : null}

          {SECTIONS.map((section) => (
            <div key={section.group}>
              <CommandSeparator />
              <CommandGroup heading={section.group}>
                {section.items.map((item) => (
                  <CommandItem
                    key={item.id}
                    onSelect={() => go(item.id)}
                    className={cn(item.id === activeTab && 'text-primary')}
                  >
                    <item.icon className="size-4" aria-hidden />
                    <span>{item.label}</span>
                    {item.id === activeTab ? (
                      <CommandShortcut>открыт</CommandShortcut>
                    ) : null}
                  </CommandItem>
                ))}
              </CommandGroup>
            </div>
          ))}
        </CommandList>
      </CommandDialog>
    </>
  );
}

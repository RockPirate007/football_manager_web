import { NextResponse } from 'next/server';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode } from '@/lib/game/api-helpers';
import { SAVES_MAX, START_BALANCE_BASE, START_BALANCE_PER_STRENGTH } from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { generateLeague } from '@/lib/game/generate';
import { playerCreateData } from '@/lib/game/players';
import { hashString, mulberry32 } from '@/lib/game/rng';
import type { ClubDTO } from '@/lib/game/types';

const bodySchema = z.object({
  managerName: z.string().trim().min(1).max(40),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/new — ЛЕГАСИ-обёртка Фазы 1 (совместимость со старым
 * фронтендом до прихода Task 10-b). Новые клиенты используют
 * POST /api/game/saves { leagueCode, clubIndex, managerName, careerName }.
 *
 * Создаёт карьеру в РПЛ (Россия, 16 клубов — как Фаза 1) в статусе setup:
 * клуб выберет следующий POST /api/game/select. Ответ совместим со старым
 * контрактом: { ok, saveId, clubs[] }.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) {
      return fail('INVALID_NAME', 400);
    }
    const managerName = parsed.data.managerName;

    // Фаза 2: мульти-карьеры — старые сейвы НЕ удаляем, но лимит 8 действует
    const count = await db.gameSave.count();
    if (count >= SAVES_MAX) return fail('SAVE_LIMIT_REACHED', 409);

    // Генерация мира (РПЛ)
    const seed = hashString(`${crypto.randomUUID()}:${Date.now()}`);
    const rng = mulberry32(seed);
    const world = generateLeague(rng, 'RPL');
    const saveId = crypto.randomUUID();

    await db.gameSave.create({
      data: {
        id: saveId,
        managerName,
        careerName: managerName,
        leagueCode: 'RPL',
        status: 'setup',
        season: 1,
        week: 1,
        balance: 0,
        cupRound: 0,
      },
    });

    const ops: Prisma.PrismaPromise<unknown>[] = [];
    for (const team of world.teams) {
      ops.push(
        db.team.create({
          data: {
            id: team.id,
            saveId,
            name: team.name,
            shortName: team.shortName,
            city: team.city,
            colorPrimary: team.colorPrimary,
            colorSecondary: team.colorSecondary,
            strength: team.strength,
            isUserTeam: false,
            stadiumCapacity: team.stadiumCapacity,
            formation: team.formation,
            mentality: team.mentality,
            tempo: team.tempo,
            pressing: team.pressing,
            defLine: team.defLine,
            playStyle: team.playStyle,
          },
        }),
      );
      for (const player of team.players) {
        player.teamId = team.id;
        ops.push(db.player.create({ data: playerCreateData(saveId, player) }));
      }
    }
    for (const match of world.matches) {
      ops.push(
        db.match.create({
          data: {
            id: match.id,
            saveId,
            season: 1,
            week: match.week,
            homeTeamId: match.homeTeamId,
            awayTeamId: match.awayTeamId,
          },
        }),
      );
    }
    await db.$transaction(ops);

    const clubs: ClubDTO[] = world.teams.map((t) => ({
      id: t.id,
      name: t.name,
      shortName: t.shortName,
      city: t.city,
      colorPrimary: t.colorPrimary,
      colorSecondary: t.colorSecondary,
      strength: t.strength,
      stadiumCapacity: t.stadiumCapacity,
      startBalance:
        START_BALANCE_BASE + Math.max(0, t.strength - 55) * START_BALANCE_PER_STRENGTH,
    }));

    return NextResponse.json({ ok: true, saveId, clubs });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/new]', error);
    return fail('UNKNOWN', 500);
  }
}

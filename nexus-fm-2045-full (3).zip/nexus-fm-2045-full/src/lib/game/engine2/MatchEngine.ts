/**
 * ENGINE 2.0 — событийный матчевый движок (MatchEngine.ts).
 *
 * АРХИТЕКТУРА ЦИКЛА:
 *   for minute in 1..93:
 *     1) тик выносливости обеих команд (темп/прессинг/стамина)
 *     2) контрольные точки: перерыв (45), второй тайм (46), тактические
 *        сдвиги по плану (60/75), авто-замены по усталости (58+)
 *     3) действия минуты: базовое число = APM × темп; успешный прогресс
 *        продолжает атаку цепочкой (P ≈ 0.62, до 4 звеньев)
 *     4) действие = выбор по весам (зона × тактика) → дуэль атрибутов →
 *        событие/переход зоны/смена владения
 *     5) моментум-бар и «фоновые» события трансляции
 *
 * ДЕТЕРМИНИЗМ: все броски через один rng в фиксированном порядке; Map
 * строятся из массивов lineup/players (стабильный порядок вставки).
 *
 * СОВМЕСТИМОСТЬ: simulateMatchV2 — drop-in замена simulateMatch:
 * тот же вход (MatchTeamInput) и тот же выход (MatchResult).
 * Расширение входа: опциональное width ('narrow'|'normal'|'wide').
 */

import {
  APM_BASE,
  APM_TEMPO,
  CORNER_AFTER_BLOCK,
  CORNER_AFTER_SAVE,
  DRAIN_PER_MIN,
  DRAIN_PRESSING,
  DRAIN_STAMINA_BASE,
  DRAIN_STAMINA_SLOPE,
  DRAIN_TEMPO,
  FILLER_AFTER_QUIET,
  FILLER_CHANCE,
  FILLER_MAX,
  FOUL_AGGR_SLOPE,
  FOUL_ON_LOSS,
  FOUL_PRESSING_HIGH,
  INJURY_ON_DUEL,
  INJURY_PER_MIN,
  MORALE_BIG_MISS,
  MORALE_GOAL_CONCEDED,
  MORALE_GOAL_SCORED,
  MORALE_HALFTIME_LOSING_TALK,
  MORALE_LEAD_DAMP,
  MORALE_RED,
  MORALE_SAVE,
  MOMENTUM_COOLDOWN,
  MOMENTUM_DOMINANCE,
  MOMENTUM_WINDOW,
  OFFSIDE_BY_DEFLINE,
  OFFSIDE_DECISIONS_SLOPE,
  PASS_FOUL_CHANCE,
  PASS_FOUL_YELLOW,
  PEN_ON_BOX_FOUL,
  SHOT_XG,
  STRAIGHT_RED_ON_FOUL,
  SUB_COOLDOWN,
  SUB_ENERGY_THRESHOLD,
  SUB_FIRST_WINDOW,
  SUB_IN_ENERGY,
  YELLOW_AGGR_SLOPE,
  YELLOW_ON_FOUL,
} from './constants';
import {
  buildZoneOccupancy,
  flipZone,
  positionZoneWeight,
  progPassTargets,
  safePassTargets,
  zoneIsFlank,
  ZONE_XY,
  type ZoneId,
  type ZoneOccupancy,
} from './zones';
import {
  eff,
  resolveAerial,
  resolveDribble,
  resolvePass,
  resolveShot,
  rollForm,
  type DuelSide,
  type DuelSides,
} from './duels';
import * as C from './commentary';
import { FORMATIONS, MENTALITY_ORDER, SUB_MAX } from '../constants';
import { positionGroupOf, type PlayerLike } from '../players';
import { clamp, pick, pickWeighted, randInt, type RNG } from '../rng';
import type {
  DefLineLevel, FormationId, MatchEvent, MatchEventType, MatchStats, MatchPlanDTO, Mentality,
  PlayStyle, TempoLevel, WidthLevel,
} from '../types';
import { aiDefaultPlan } from '../coach';
import type { MatchInjury, MatchResult, MatchTeamInput, SubRecord } from '../match';

// ── Типы runtime ──────────────────────────────────────────────────────────

interface PlayerRT {
  p: PlayerLike;
  energy: number; // 0..100 внутри матча
  yellows: number;
  offAt: number | null; // минута схода (красная/травма/замена)
  /** Модуль 2: форма на матч (бросок по consistency, rollForm). */
  form: number;
}

export interface MatchInput2 extends MatchTeamInput {
  width?: WidthLevel;
}

interface SideRT {
  side: 'home' | 'away';
  homeAdv: boolean;
  input: MatchInput2;
  byId: Map<string, PlayerRT>;
  currentLineup: (string | null)[]; // слоты формации, обновляется заменами
  benchIds: string[]; // оставшиеся здоровые запасные
  zoneOcc: ZoneOccupancy;
  morale: number; // 0..100 командная мораль матча
  moraleDamp: number; // 1 − avgLead × MORALE_LEAD_DAMP
  subsUsed: number;
  lastSubMinute: number;
  subs: SubRecord[];
  plan: MatchPlanDTO;
  tactic: {
    mentality: Mentality;
    tempo: TempoLevel;
    pressing: 'low' | 'medium' | 'high';
    defLine: DefLineLevel;
    playStyle: PlayStyle;
    width: WidthLevel;
  };
  burst: number; // оставшиеся действия вспышки контратаки
  stats: { actions: number; shots: number; sot: number; corners: number; fouls: number };
}

interface MatchState {
  rng: RNG;
  minute: number;
  possession: 'home' | 'away';
  zone: ZoneId;
  events: MatchEvent[];
  scoreH: number;
  scoreA: number;
  injuries: MatchInjury[];
  lastEventMinute: number;
  fillers: number;
  actionLog: ('home' | 'away')[];
  lastMomentum: number;
  lastPasser: { id: string; name: string; team: 'home' | 'away' } | null;
  chainDepth: number;
}

/** Призрачный игрок — на случай пустых слотов (легаси/удаления). */
const GHOST: PlayerLike = {
  id: '__ghost__',
  teamId: null,
  firstName: 'Резерв',
  lastName: 'из дубля',
  nationality: 'RU',
  position: 'MC',
  shirtNumber: 0,
  age: 20,
  potential: 40,
  ovr: 35,
  morale: 50,
  condition: 100,
  injuryWeeks: 0,
  value: 0,
  salary: 0,
  goals: 0,
  assists: 0,
  apps: 0,
  yellowCards: 0,
  redCards: 0,
  cleanSheets: 0,
  cupGoals: 0,
  cupAssists: 0,
  euroGoals: 0,
  euroAssists: 0,
  contractUntil: 1,
  preContractTeamId: null,
  ratingSum: 0,
  ratingApps: 0,
  isAcademy: false,
  finishing: 30,
  passing: 30,
  dribbling: 30,
  crossing: 30,
  tackling: 30,
  marking: 30,
  positioning: 30,
  heading: 30,
  pace: 30,
  stamina: 30,
  strength: 30,
  aggression: 50,
  vision: 30,
  decisions: 30,
  leadership: 30,
  acceleration: 30,
  jumping: 30,
  reflexes: 30,
  rushingOut: 30,
  kicking: 30,
  handling: 30,
  injuryProneness: 30,
  consistency: 50,
};

const ghostRT = (): PlayerRT => ({ p: GHOST, energy: 80, form: 1, yellows: 0, offAt: null });

// ── Построение сторон ─────────────────────────────────────────────────────

function buildSide(input: MatchInput2, side: 'home' | 'away', homeAdv: boolean, rng: RNG): SideRT {
  const byId = new Map<string, PlayerRT>();
  for (const p of input.players) {
    // Модуль 2: бросок формы на матч по скрытой consistency (до первого
    // игрового броска — порядок бросков фиксирован, детерминизм сохранён)
    byId.set(p.id, {
      p,
      energy: clamp(p.condition, 30, 100),
      form: rollForm(rng, p.consistency),
      yellows: 0,
      offAt: null,
    });
  }
  const lineup = [...input.lineup];
  const starterIds = new Set(lineup.filter((x): x is string => !!x));
  const benchIds = (input.bench ?? input.players.filter((p) => !starterIds.has(p.id)).map((p) => p.id))
    .filter((id) => {
      const rt = byId.get(id);
      return rt !== undefined && rt.p.injuryWeeks === 0;
    });
  const starters = lineup
    .map((id) => (id ? byId.get(id) : undefined))
    .filter((x): x is PlayerRT => !!x);
  const avgLead = starters.length
    ? starters.reduce((s, x) => s + x.p.leadership, 0) / starters.length
    : 50;
  return {
    side,
    homeAdv,
    input,
    byId,
    currentLineup: lineup,
    benchIds,
    zoneOcc: buildZoneOccupancy(input.formation, lineup),
    morale: starters.length
      ? clamp(starters.reduce((s, x) => s + x.p.morale, 0) / starters.length, 10, 90)
      : 50,
    moraleDamp: Math.max(0.6, 1 - avgLead * MORALE_LEAD_DAMP),
    subsUsed: 0,
    lastSubMinute: 0,
    subs: [],
    plan: input.coach?.plan ?? aiDefaultPlan(),
    tactic: {
      mentality: input.mentality,
      tempo: input.tempo,
      pressing: input.pressing,
      defLine: input.defLine,
      playStyle: input.playStyle,
      width: input.width ?? 'normal',
    },
    burst: 0,
    stats: { actions: 0, shots: 0, sot: 0, corners: 0, fouls: 0 },
  };
}

// ── Доступ к полю ─────────────────────────────────────────────────────────

function fieldRTs(s: SideRT): PlayerRT[] {
  const out: PlayerRT[] = [];
  for (const id of s.currentLineup) {
    if (!id) continue;
    const rt = s.byId.get(id);
    if (rt && rt.offAt === null) out.push(rt);
  }
  return out;
}

function gkRT(s: SideRT): PlayerRT {
  for (const id of s.currentLineup) {
    if (!id) continue;
    const rt = s.byId.get(id);
    if (rt && rt.offAt === null && rt.p.position === 'GK') return rt;
  }
  const field = fieldRTs(s);
  if (field.length) return field.reduce((a, b) => (a.p.ovr <= b.p.ovr ? a : b));
  return ghostRT();
}

/** Исполнитель в зоне: взвешенно-случайный среди совместимых (совместимость × оvr × свежесть). */
function pickActor(rng: RNG, s: SideRT, zone: ZoneId, excludeId?: string): PlayerRT {
  const items: Array<{ item: PlayerRT; weight: number }> = [];
  for (const rt of fieldRTs(s)) {
    if (excludeId && rt.p.id === excludeId) continue;
    const aff = positionZoneWeight(rt.p.position, zone);
    if (aff <= 0) continue;
    items.push({ item: rt, weight: aff * (0.4 + rt.p.ovr / 250) * (0.5 + rt.energy / 200) });
  }
  if (items.length > 0) return pickWeighted(rng, items);
  const field = fieldRTs(s);
  if (field.length === 0) return ghostRT();
  const nonGk = field.filter((rt) => rt.p.position !== 'GK');
  const pool = (nonGk.length ? nonGk : field).filter((rt) => rt.p.id !== excludeId);
  const usePool = pool.length ? pool : field;
  return pickWeighted(rng, usePool.map((x) => ({ item: x, weight: Math.max(1, x.p.ovr) })));
}

/** Защитник против действия в зоне атакующего (взвешенно-случайный). */
function pickDefender(rng: RNG, s: SideRT, zone: ZoneId): PlayerRT {
  const defZone = flipZone(zone);
  const field = fieldRTs(s);
  if (field.length === 0) return ghostRT();
  const items: Array<{ item: PlayerRT; weight: number }> = [];
  for (const rt of field) {
    const w = positionZoneWeight(rt.p.position, defZone);
    if (w > 0) {
      items.push({ item: rt, weight: w * (0.4 + rt.p.ovr / 250) * (0.5 + rt.energy / 200) });
    }
  }
  if (items.length > 0) return pickWeighted(rng, items);
  const nonGk = field.filter((rt) => rt.p.position !== 'GK');
  const pool = nonGk.length ? nonGk : field;
  return pickWeighted(rng, pool.map((x) => ({ item: x, weight: Math.max(1, x.p.ovr) })));
}

function duelSideOf(s: SideRT, rt: PlayerRT): DuelSide {
  return { p: rt.p, energy: rt.energy, morale: s.morale, homeAdv: s.homeAdv, form: rt.form };
}

// ── События ───────────────────────────────────────────────────────────────

/**
 * Эмит события. teamSide — чьё teamId ставить; coordSide — с чьей стороны
 * отсчитывать координаты (по умолчанию = teamSide). Зона задаётся в терминах
 * ВЛАДЕЮЩЕЙ команды: хозяева атакуют слева направо, гости — зеркально.
 */
function emit(
  st: MatchState,
  teamSide: SideRT | null,
  type: MatchEventType,
  text: string,
  zone?: ZoneId,
  extra?: Partial<MatchEvent>,
  coordSide?: SideRT | null,
): void {
  const ev: MatchEvent = { minute: st.minute, type, text, ...extra };
  if (teamSide) ev.teamId = teamSide.input.teamId;
  if (zone) {
    const base = ZONE_XY[zone];
    const jx = (st.rng() - 0.5) * 12;
    const jy = (st.rng() - 0.5) * 10;
    const owner = coordSide ?? teamSide;
    const isHome = owner === null || owner.side === 'home';
    ev.x = clamp(Math.round(isHome ? base.x + jx : 100 - base.x - jx), 2, 98);
    ev.y = clamp(Math.round(isHome ? base.y + jy : 100 - base.y - jy), 2, 98);
  }
  st.events.push(ev);
  st.lastEventMinute = st.minute;
}

function nameRT(rt: PlayerRT): string {
  return C.nameOf(rt.p);
}

// ── Тактика: веса действий ────────────────────────────────────────────────

type ActionKind =
  | 'safePass' | 'progPass' | 'throughBall' | 'longBall'
  | 'dribble' | 'cross' | 'shot' | 'cutback';

function stepMentality(m: Mentality, dir: 1 | -1): Mentality {
  const idx = MENTALITY_ORDER.indexOf(m);
  return MENTALITY_ORDER[clamp(idx + dir, 0, MENTALITY_ORDER.length - 1)];
}

function riskOf(m: Mentality): number {
  switch (m) {
    case 'defensive': return 0.7;
    case 'cautious': return 0.85;
    case 'balanced': return 1.0;
    case 'attacking': return 1.18;
    case 'allout': return 1.35;
  }
}

function actionWeights(zone: ZoneId, s: SideRT): Array<{ kind: ActionKind; weight: number }> {
  const t = s.tactic;
  const risk = riskOf(t.mentality);
  const wide = t.width === 'wide' ? 1.22 : t.width === 'narrow' ? 0.82 : 1;
  const w: Array<{ kind: ActionKind; weight: number }> = [];
  const push = (kind: ActionKind, weight: number) => {
    if (weight > 0.01) w.push({ kind, weight });
  };

  switch (zone) {
    case 'DL':
    case 'DR':
    case 'DC': {
      push('safePass', 60);
      push('progPass', 16 * risk);
      push('longBall', 12 + (t.playStyle === 'long' ? 26 : 0));
      push('dribble', 5);
      break;
    }
    case 'ML':
    case 'MR': {
      push('safePass', 38);
      push('progPass', 26 * risk);
      push('cross', 6 + (t.playStyle === 'wing' ? 8 : 0));
      push('throughBall', 6 * risk);
      push('dribble', 12 * risk);
      push('longBall', 4);
      break;
    }
    case 'MC': {
      push('safePass', 42);
      push('progPass', 26 * risk);
      push('throughBall', 9 * risk);
      push('dribble', 9 * risk);
      push('shot', 4);
      push('longBall', 3);
      break;
    }
    case 'AL':
    case 'AR': {
      push('cross', (38 + (t.playStyle === 'wing' ? 18 : 0)) * wide);
      push('cutback', 12 * wide);
      push('dribble', 20 * risk);
      push('safePass', 16);
      push('progPass', 10 * risk);
      push('shot', 6 * risk);
      break;
    }
    case 'AC': {
      push('shot', 28 * risk);
      push('throughBall', 18 * risk);
      push('dribble', 20 * risk);
      push('safePass', 20);
      push('progPass', 12 * risk);
      break;
    }
    case 'BOX': {
      push('shot', 80 * risk);
      push('cutback', 14);
      push('safePass', 6);
      break;
    }
  }

  // контратака: вертикальная вспышка
  if (s.burst > 0) {
    for (const item of w) {
      if (item.kind === 'safePass') item.weight *= 0.25;
      else if (item.kind === 'progPass' || item.kind === 'throughBall' || item.kind === 'longBall' || item.kind === 'dribble') {
        item.weight *= 2.0;
      }
    }
  }
  return w;
}

/** Сколько своих в зоне (поддержка паса). */
function supportOf(s: SideRT, zone: ZoneId): number {
  let n = 0;
  for (const id of s.currentLineup) {
    if (!id) continue;
    const rt = s.byId.get(id);
    if (rt && rt.offAt === null && positionZoneWeight(rt.p.position, zone) >= 1) n += 1;
  }
  return n;
}

function pickTargetZone(rng: RNG, s: SideRT, from: ZoneId, targets: ZoneId[]): ZoneId {
  if (targets.length === 0) return from;
  const items = targets.map((z) => ({
    item: z,
    weight: Math.max(1, supportOf(s, z) * (z === from ? 0.4 : 1)),
  }));
  return pickWeighted(rng, items);
}

// ── Мораль / травмы / замены ──────────────────────────────────────────────

function swingMorale(s: SideRT, delta: number): void {
  s.morale = clamp(s.morale + delta * s.moraleDamp, 5, 95);
}

function clearSlot(s: SideRT, playerId: string): void {
  for (let i = 0; i < s.currentLineup.length; i++) {
    if (s.currentLineup[i] === playerId) s.currentLineup[i] = null;
  }
  s.zoneOcc = buildZoneOccupancy(s.input.formation, s.currentLineup);
}

function injurePlayer(rng: RNG, st: MatchState, s: SideRT, rt: PlayerRT): void {
  const roll = rng();
  const weeks = roll < 0.5 ? randInt(rng, 1, 2) : roll < 0.85 ? randInt(rng, 3, 5) : randInt(rng, 6, 10);
  st.injuries.push({ teamId: s.input.teamId, playerId: rt.p.id, weeks });
  rt.offAt = st.minute;
  emit(st, s, 'injury', C.textInjury(rng, rt.p), undefined, {
    playerId: rt.p.id,
    playerName: nameRT(rt),
  });
  if (!trySubstitute(rng, st, s, rt, 'injury')) {
    clearSlot(s, rt.p.id);
  }
  swingMorale(s, -4);
}

/** Замена outId → ближайший по группе запасной. true — замена удалась. */
function trySubstitute(
  rng: RNG,
  st: MatchState,
  s: SideRT,
  out: PlayerRT,
  reason: 'injury' | 'fatigue',
): boolean {
  if (s.subsUsed >= SUB_MAX || s.benchIds.length === 0) return false;
  const outGroup = positionGroupOf(out.p.position);
  const isGk = out.p.position === 'GK';
  const cands = s.benchIds
    .map((id) => s.byId.get(id))
    .filter((x): x is PlayerRT => !!x && x.offAt === null);
  if (cands.length === 0) return false;
  const sameGroup = cands.filter((x) => positionGroupOf(x.p.position) === outGroup);
  const gkPool = isGk ? cands.filter((x) => x.p.position === 'GK') : [];
  const pool = gkPool.length ? gkPool : sameGroup.length ? sameGroup : cands.filter((x) => x.p.position !== 'GK');
  const usePool = pool.length ? pool : cands;
  const inRT = pickWeighted(rng, usePool.map((x) => ({ item: x, weight: Math.max(1, x.p.ovr) })));
  let slot = -1;
  for (let i = 0; i < s.currentLineup.length; i++) {
    if (s.currentLineup[i] === out.p.id) { slot = i; break; }
  }
  if (slot < 0) {
    for (let i = 0; i < s.currentLineup.length; i++) {
      if (!s.currentLineup[i]) { slot = i; break; }
    }
  }
  if (slot < 0) slot = 0;
  const outId = out.p.id;
  out.offAt = st.minute;
  inRT.energy = Math.min(inRT.energy, SUB_IN_ENERGY);
  s.currentLineup[slot] = inRT.p.id;
  s.benchIds = s.benchIds.filter((id) => id !== inRT.p.id);
  s.zoneOcc = buildZoneOccupancy(s.input.formation, s.currentLineup);
  s.subsUsed += 1;
  s.lastSubMinute = st.minute;
  s.subs.push({ outId, inId: inRT.p.id, minute: st.minute, reason });
  emit(
    st, s, 'sub',
    `Замена: ${C.nameOf(inRT.p)} выходит вместо ${C.nameOf(out.p)}.`,
    undefined,
    { playerId: inRT.p.id, playerName: C.nameOf(inRT.p), subOutId: outId, subOutName: C.nameOf(out.p) },
  );
  return true;
}

// ── Гол / пенальти / фолы ─────────────────────────────────────────────────

function scoreGoal(
  st: MatchState,
  atk: SideRT,
  def: SideRT,
  scorer: PlayerRT,
  assist: { id: string; name: string } | null,
  zone: ZoneId,
  text: string,
): void {
  if (atk.side === 'home') st.scoreH += 1;
  else st.scoreA += 1;
  swingMorale(atk, MORALE_GOAL_SCORED);
  swingMorale(def, MORALE_GOAL_CONCEDED);
  const evExtra: Partial<MatchEvent> = { playerId: scorer.p.id, playerName: nameRT(scorer) };
  if (assist) {
    evExtra.assistId = assist.id;
    evExtra.assistName = assist.name;
  }
  emit(st, atk, 'goal', text, zone, evExtra);
  st.possession = def.side; // после гола мяч у пострадавших с центра
  st.zone = 'MC';
  st.chainDepth = 0;
  st.lastPasser = null;
}

function resolvePenalty(
  rng: RNG,
  st: MatchState,
  atk: SideRT,
  def: SideRT,
  taker: PlayerRT,
): void {
  atk.stats.shots += 1;
  atk.stats.sot += 1;
  const gk = gkRT(def);
  const fin = eff(taker.p, 'finishing', taker.energy, atk.morale, taker.form);
  const gkSkill =
    0.6 * eff(gk.p, 'reflexes', gk.energy, def.morale, gk.form) + 0.4 * eff(gk.p, 'handling', gk.energy, def.morale, gk.form);
  const pGoal = clamp(SHOT_XG.penalty * (0.55 + (fin - gkSkill) / 60), 0.35, 0.95);
  const r = rng();
  if (r < pGoal) {
    scoreGoal(st, atk, def, taker, null, 'BOX', C.textPenaltyGoal(rng, taker.p, atk.input.name));
  } else if (r < pGoal + 0.25) {
    swingMorale(def, MORALE_SAVE);
    emit(st, atk, 'chance', C.textPenaltySave(rng, taker.p, gk.p), 'BOX', {
      playerId: taker.p.id, playerName: nameRT(taker), gkName: C.nameOf(gk.p),
    });
    st.possession = def.side;
    st.zone = 'DC';
  } else {
    swingMorale(atk, MORALE_BIG_MISS);
    emit(st, atk, 'chance', C.textPenaltyMiss(rng, taker.p), 'BOX', {
      playerId: taker.p.id, playerName: nameRT(taker),
    });
    st.possession = def.side;
    st.zone = 'DC';
  }
}

/** Фол защитника d на жертве victim в зоне zone (термины атакующего). */
function resolveFoul(
  rng: RNG,
  st: MatchState,
  atk: SideRT,
  def: SideRT,
  d: PlayerRT,
  victim: PlayerRT,
  zone: ZoneId,
): void {
  const aggr = d.p.aggression;
  def.stats.fouls += 1;
  const yellowP = YELLOW_ON_FOUL + (aggr - 50) * YELLOW_AGGR_SLOPE;

  // пенальти: фол в чужой штрафной
  if (zone === 'BOX' && rng() < PEN_ON_BOX_FOUL) {
    emit(st, atk, 'chance', C.textPenaltyAwarded(rng, victim.p, d.p), zone, {
      playerId: victim.p.id, playerName: nameRT(victim),
    });
    resolvePenalty(rng, st, atk, def, victim);
    return;
  }

  if (rng() < STRAIGHT_RED_ON_FOUL) {
    d.offAt = st.minute;
    clearSlot(def, d.p.id);
    swingMorale(def, MORALE_RED);
    emit(st, def, 'red', C.textRed(rng, d.p), zone, { playerId: d.p.id, playerName: nameRT(d) }, atk);
  } else {
    // предупреждённый игрок осторожничает — риск второй жёлтой ниже
    const caution = d.yellows >= 1 ? 0.35 : 1;
    if (rng() < yellowP * caution) {
      d.yellows += 1;
      if (d.yellows >= 2) {
        d.offAt = st.minute;
        clearSlot(def, d.p.id);
        swingMorale(def, MORALE_RED);
        emit(st, def, 'red', C.textSecondYellow(rng, d.p), zone, { playerId: d.p.id, playerName: nameRT(d) }, atk);
      } else {
        emit(st, def, 'yellow', C.textYellow(rng, d.p, victim.p), zone, { playerId: d.p.id, playerName: nameRT(d) }, atk);
      }
    }
  }

  // травма жертвы от жёсткого фола
  if (rng() < INJURY_ON_DUEL * ((victim.p.injuryProneness ?? 50) / 50) * (atk.input.medRiskMult ?? 1)) {
    injurePlayer(rng, st, atk, victim);
  }

  // штрафной: мяч остаётся у атакующих в точке фола
  st.possession = atk.side;
  st.zone = zone;
  st.chainDepth = 0;
}

// ── Удары ─────────────────────────────────────────────────────────────────

function resolveShotAction(
  rng: RNG,
  st: MatchState,
  atk: SideRT,
  def: SideRT,
  shooter: PlayerRT,
  zone: ZoneId,
  xg: number,
  goalText: string | null,
): void {
  atk.stats.shots += 1;
  const gk = gkRT(def);
  const sides: DuelSides = {
    atk: duelSideOf(atk, shooter),
    def: duelSideOf(def, gk),
    gk: duelSideOf(def, gk),
  };
  const outcome = resolveShot(rng, sides, xg);
  const assist =
    st.lastPasser && st.lastPasser.team === atk.side && st.lastPasser.id !== shooter.p.id
      ? st.lastPasser
      : null;

  if (outcome === 'goal') {
    atk.stats.sot += 1;
    scoreGoal(st, atk, def, shooter, assist, zone, goalText ?? C.textShotGoal(rng, shooter.p, atk.input.name));
    return;
  }
  if (outcome === 'save') {
    atk.stats.sot += 1;
    swingMorale(def, MORALE_SAVE);
    emit(
      st, atk, rng() < 0.4 ? 'save' : 'shot_on',
      C.textShotSave(rng, shooter.p, gk.p),
      zone,
      { playerId: shooter.p.id, playerName: nameRT(shooter), gkName: C.nameOf(gk.p) },
    );
    if (rng() < CORNER_AFTER_SAVE) {
      atk.stats.corners += 1;
      emit(st, atk, 'corner', C.textCorner(rng, shooter.p, atk.input.name), zone);
      resolveCorner(rng, st, atk, def);
    } else {
      turnOver(st, def, 'DC');
    }
    return;
  }
  if (outcome === 'blocked') {
    const blocker = pickDefender(rng, def, zone);
    emit(st, atk, 'shot_off', C.textShotBlocked(rng, shooter.p, blocker.p), zone, {
      playerId: shooter.p.id, playerName: nameRT(shooter),
    });
    if (rng() < CORNER_AFTER_BLOCK) {
      atk.stats.corners += 1;
      emit(st, atk, 'corner', C.textCorner(rng, shooter.p, atk.input.name), zone);
      resolveCorner(rng, st, atk, def);
    } else {
      turnOver(st, def, flipZone(zone));
    }
    return;
  }
  // мимо
  const big = xg >= 0.18;
  if (big) swingMorale(atk, MORALE_BIG_MISS);
  emit(
    st, atk, 'shot_off',
    big ? C.textBigMiss(rng, shooter.p) : C.textShotOff(rng, shooter.p),
    zone,
    { playerId: shooter.p.id, playerName: nameRT(shooter) },
  );
  turnOver(st, def, 'DC');
}

/** Угловой: подача → верховая дуэль в BOX. */
function resolveCorner(rng: RNG, st: MatchState, atk: SideRT, def: SideRT): void {
  const attacker = pickActor(rng, atk, 'BOX');
  const defender = pickDefender(rng, def, 'BOX');
  const gk = gkRT(def);
  const won = resolveAerial(rng, {
    atk: duelSideOf(atk, attacker),
    def: duelSideOf(def, defender),
    gk: duelSideOf(def, gk),
  });
  if (won) {
    resolveShotAction(rng, st, atk, def, attacker, 'BOX', SHOT_XG.cornerHeader, C.textHeaderGoal(rng, attacker.p));
  } else {
    emit(st, def, 'duel', C.textCornerCleared(rng, defender.p), 'BOX', undefined, atk);
    turnOver(st, def, 'MC');
  }
}

function turnOver(st: MatchState, to: SideRT, zone: ZoneId): void {
  st.possession = to.side;
  st.zone = zone;
  st.chainDepth = 0;
  st.lastPasser = null;
  if (to.tactic.playStyle === 'counter' && zone[0] !== 'A' && zone !== 'BOX') {
    to.burst = 2;
  }
}

// ── Выполнение действия ───────────────────────────────────────────────────

function runAction(rng: RNG, st: MatchState, H: SideRT, A: SideRT): boolean {
  const atk = st.possession === 'home' ? H : A;
  const def = st.possession === 'home' ? A : H;
  atk.stats.actions += 1;
  st.actionLog.push(atk.side);
  if (st.actionLog.length > MOMENTUM_WINDOW * 2) {
    st.actionLog.splice(0, st.actionLog.length - MOMENTUM_WINDOW * 2);
  }
  if (atk.burst > 0) atk.burst -= 1;

  const zone = st.zone;
  const kind = pickWeighted(
    rng,
    actionWeights(zone, atk).map((x) => ({ item: x.kind, weight: x.weight })),
  );
  const actor = pickActor(rng, atk, zone);

  switch (kind) {
    case 'safePass': {
      st.lastPasser = null;
      const defender = pickDefender(rng, def, zone);
      const ok = resolvePass(rng, { atk: duelSideOf(atk, actor), def: duelSideOf(def, defender) }, 'safe');
      if (ok) {
        st.zone = pickTargetZone(rng, atk, zone, safePassTargets(zone));
        return false;
      }
      maybeIntercept(rng, st, atk, def, defender, zone, actor);
      return false;
    }
    case 'progPass': {
      const defender = pickDefender(rng, def, zone);
      const ok = resolvePass(rng, { atk: duelSideOf(atk, actor), def: duelSideOf(def, defender) }, 'prog');
      if (ok) {
        st.zone = pickTargetZone(rng, atk, zone, progPassTargets(zone));
        st.lastPasser = { id: actor.p.id, name: nameRT(actor), team: atk.side };
        if ((zone[0] === 'M' || zone[0] === 'A') && rng() < 0.22) {
          const target = pickActor(rng, atk, st.zone, actor.p.id);
          emit(st, atk, 'momentum', C.textProgPass(rng, actor.p, target.p), zone, {
            playerId: actor.p.id, playerName: nameRT(actor),
          });
        }
        return true;
      }
      maybeIntercept(rng, st, atk, def, defender, zone, actor);
      return false;
    }
    case 'throughBall': {
      const runner = pickActor(rng, atk, 'BOX', actor.p.id);
      const offP =
        OFFSIDE_BY_DEFLINE[def.tactic.defLine] -
        (runner.p.decisions - 50) * OFFSIDE_DECISIONS_SLOPE;
      if (rng() < clamp(offP, 0.04, 0.3)) {
        emit(st, atk, 'offside', C.textOffside(rng, runner.p, atk.input.name), zone, {
          playerId: runner.p.id, playerName: nameRT(runner),
        });
        turnOver(st, def, 'DC');
        return false;
      }
      const defender = pickDefender(rng, def, 'BOX');
      const ok = resolvePass(rng, { atk: duelSideOf(atk, actor), def: duelSideOf(def, defender) }, 'through');
      if (ok) {
        emit(st, atk, 'duel', C.textThroughPass(rng, actor.p, runner.p), zone, {
          playerId: actor.p.id, playerName: nameRT(actor),
        });
        st.zone = 'BOX';
        st.lastPasser = { id: actor.p.id, name: nameRT(actor), team: atk.side };
        return true;
      }
      emit(st, def, 'duel', C.textThroughCut(rng, defender.p), zone, undefined, atk);
      turnOver(st, def, flipZone(zone));
      return false;
    }
    case 'longBall': {
      const targetZone: ZoneId = pickTargetZone(rng, atk, zone, ['AL', 'AC', 'AR', 'ML', 'MR']);
      const target = pickActor(rng, atk, targetZone);
      const defender = pickDefender(rng, def, targetZone);
      const ok = resolveAerial(rng, { atk: duelSideOf(atk, target), def: duelSideOf(def, defender) });
      if (ok) {
        st.zone = targetZone;
        st.lastPasser = { id: actor.p.id, name: nameRT(actor), team: atk.side };
        return true;
      }
      if (rng() < 0.5) {
        emit(st, def, 'duel', C.textTackleWin(rng, defender.p), targetZone, undefined, atk);
      }
      turnOver(st, def, flipZone(targetZone));
      return false;
    }
    case 'dribble': {
      const defender = pickDefender(rng, def, zone);
      const ok = resolveDribble(rng, { atk: duelSideOf(atk, actor), def: duelSideOf(def, defender) });
      if (ok) {
        const targets = progPassTargets(zone);
        st.zone = targets.length ? pickTargetZone(rng, atk, zone, targets) : zone;
        st.lastPasser = null;
        const inAtt = zone[0] === 'A' || zone === 'BOX';
        if (inAtt && rng() < 0.5) {
          emit(st, atk, 'duel', C.textDribbleWin(rng, actor.p, defender.p), zone, {
            playerId: actor.p.id, playerName: nameRT(actor),
          });
        }
        return true;
      }
      const foulP =
        FOUL_ON_LOSS + (defender.p.aggression - 50) * FOUL_AGGR_SLOPE +
        (def.tactic.pressing === 'high' ? FOUL_PRESSING_HIGH : 0);
      if (rng() < clamp(foulP, 0.05, 0.5)) {
        resolveFoul(rng, st, atk, def, defender, actor, zone);
      } else {
        if (rng() < 0.45) {
          emit(st, def, 'duel', C.textTackleWin(rng, defender.p), zone, undefined, atk);
        }
        if (rng() < INJURY_ON_DUEL * ((actor.p.injuryProneness ?? 50) / 50) * (atk.input.medRiskMult ?? 1)) {
          injurePlayer(rng, st, atk, actor);
        }
        turnOver(st, def, flipZone(zone));
      }
      return false;
    }
    case 'cross': {
      const defender = pickDefender(rng, def, zone);
      const ok = resolvePass(rng, { atk: duelSideOf(atk, actor), def: duelSideOf(def, defender) }, 'safe');
      if (ok) {
        if (rng() < 0.5) {
          emit(st, atk, 'momentum', C.textCrossIn(rng, actor.p), zone, {
            playerId: actor.p.id, playerName: nameRT(actor),
          });
        }
        const striker = pickActor(rng, atk, 'BOX', actor.p.id);
        const cb = pickDefender(rng, def, 'BOX');
        const gk = gkRT(def);
        const aerial = resolveAerial(rng, {
          atk: duelSideOf(atk, striker),
          def: duelSideOf(def, cb),
          gk: duelSideOf(def, gk),
        });
        if (aerial) {
          resolveShotAction(rng, st, atk, def, striker, 'BOX', SHOT_XG.header, C.textHeaderGoal(rng, striker.p));
        } else {
          emit(st, def, 'duel', C.textCornerCleared(rng, cb.p), 'BOX', undefined, atk);
          turnOver(st, def, 'DC');
        }
      } else {
        if (rng() < 0.35) {
          atk.stats.corners += 1;
          emit(st, atk, 'corner', C.textCorner(rng, actor.p, atk.input.name), zone);
          resolveCorner(rng, st, atk, def);
        } else {
          maybeIntercept(rng, st, atk, def, defender, zone, actor);
        }
      }
      return false;
    }
    case 'cutback': {
      const receiver = pickActor(rng, atk, 'BOX', actor.p.id);
      const defender = pickDefender(rng, def, 'BOX');
      const ok = resolvePass(rng, { atk: duelSideOf(atk, actor), def: duelSideOf(def, defender) }, 'prog');
      if (ok) {
        st.lastPasser = { id: actor.p.id, name: nameRT(actor), team: atk.side };
        resolveShotAction(rng, st, atk, def, receiver, 'BOX', SHOT_XG.boxCentre, null);
      } else {
        maybeIntercept(rng, st, atk, def, defender, zone, actor);
      }
      return false;
    }
    case 'shot': {
      const xg = zone === 'BOX' ? SHOT_XG.boxSelf : zone === 'AC' ? SHOT_XG.longShot : SHOT_XG.cutInside;
      resolveShotAction(rng, st, atk, def, actor, zone, xg, null);
      return false;
    }
  }
}

function maybeIntercept(
  rng: RNG,
  st: MatchState,
  atk: SideRT,
  def: SideRT,
  defender: PlayerRT,
  zone: ZoneId,
  victim: PlayerRT,
): void {
  // фол-сдерживание при перехваченном пасе: нарушитель останавливает атаку
  if (rng() < PASS_FOUL_CHANCE) {
    def.stats.fouls += 1;
    // предупреждённый игрок осторожничает
    const caution = defender.yellows >= 1 ? 0.35 : 1;
    if (rng() < (PASS_FOUL_YELLOW + (defender.p.aggression - 50) * YELLOW_AGGR_SLOPE) * caution) {
      defender.yellows += 1;
      if (defender.yellows >= 2) {
        defender.offAt = st.minute;
        clearSlot(def, defender.p.id);
        swingMorale(def, MORALE_RED);
        emit(
          st, def, 'red', C.textSecondYellow(rng, defender.p), zone,
          { playerId: defender.p.id, playerName: nameRT(defender) }, atk,
        );
      } else {
        emit(
          st, def, 'yellow', C.textYellow(rng, defender.p, victim.p), zone,
          { playerId: defender.p.id, playerName: nameRT(defender) }, atk,
        );
      }
    }
    // штрафной: мяч остаётся у атакующих
    st.possession = atk.side;
    st.zone = zone;
    st.chainDepth = 0;
    return;
  }
  if (rng() < 0.3) {
    emit(st, def, 'duel', C.textIntercept(rng, defender.p, atk.input.name), zone, undefined, atk);
  }
  turnOver(st, def, flipZone(zone));
}

// ── Тики и проверки ───────────────────────────────────────────────────────

function staminaTick(s: SideRT): void {
  const tempoMult = DRAIN_TEMPO[s.tactic.tempo];
  const pressMult = DRAIN_PRESSING[s.tactic.pressing];
  for (const id of s.currentLineup) {
    if (!id) continue;
    const rt = s.byId.get(id);
    if (!rt || rt.offAt !== null) continue;
    const stMult = DRAIN_STAMINA_BASE + DRAIN_STAMINA_SLOPE * rt.p.stamina;
    rt.energy = Math.max(5, rt.energy - DRAIN_PER_MIN * tempoMult * pressMult * stMult);
  }
}

function fatigueSubCheck(rng: RNG, st: MatchState, s: SideRT): void {
  if (st.minute < SUB_FIRST_WINDOW) return;
  if (s.subsUsed >= SUB_MAX) return;
  if (!s.plan.fatigueSubs) return;
  if (s.lastSubMinute > 0 && st.minute - s.lastSubMinute < SUB_COOLDOWN) return;
  let worst: PlayerRT | null = null;
  for (const id of s.currentLineup) {
    if (!id) continue;
    const rt = s.byId.get(id);
    if (!rt || rt.offAt !== null || rt.p.position === 'GK') continue;
    if (worst === null || rt.energy < worst.energy) worst = rt;
  }
  if (worst && worst.energy < SUB_ENERGY_THRESHOLD) {
    trySubstitute(rng, st, s, worst, 'fatigue');
  }
}

function tacticDynamics(st: MatchState, H: SideRT, A: SideRT): void {
  if (st.minute !== 60 && st.minute !== 75) return;
  for (const s of [H, A]) {
    const my = s.side === 'home' ? st.scoreH : st.scoreA;
    const opp = s.side === 'home' ? st.scoreA : st.scoreH;
    if (my < opp && s.plan.chaseMode === 'allout') {
      s.tactic.mentality = stepMentality(s.tactic.mentality, 1);
    } else if (my > opp && s.plan.leadMode === 'park') {
      s.tactic.mentality = stepMentality(s.tactic.mentality, -1);
    }
  }
}

function momentumCheck(rng: RNG, st: MatchState, H: SideRT, A: SideRT): void {
  if (st.minute - st.lastMomentum < MOMENTUM_COOLDOWN) return;
  if (st.actionLog.length < MOMENTUM_WINDOW) return;
  const window = st.actionLog.slice(-MOMENTUM_WINDOW);
  const homeShare = window.filter((x) => x === 'home').length / window.length;
  const dominant: 'home' | 'away' = homeShare >= 0.5 ? 'home' : 'away';
  const share = dominant === 'home' ? homeShare : 1 - homeShare;
  if (share < MOMENTUM_DOMINANCE) return;
  const side = dominant === 'home' ? H : A;
  if (rng() < 0.5) {
    emit(st, side, 'momentum', C.textMomentum(rng, side.input.name));
    st.lastMomentum = st.minute;
  }
}

function fillerCheck(rng: RNG, st: MatchState, H: SideRT, A: SideRT): void {
  if (st.fillers >= FILLER_MAX) return;
  if (st.minute - st.lastEventMinute < FILLER_AFTER_QUIET) return;
  if (rng() >= FILLER_CHANCE) return;
  const side = st.possession === 'home' ? H : A;
  emit(st, side, 'momentum', C.textPossession(rng, side.input.name, st.zone), st.zone);
  st.fillers += 1;
}

function actionsThisMinute(rng: RNG, s: SideRT, opp: SideRT): number {
  let base = APM_BASE * APM_TEMPO[s.tactic.tempo];
  const myMen = fieldRTs(s).length;
  const oppMen = fieldRTs(opp).length;
  if (myMen < oppMen) base *= 0.88;
  else if (myMen > oppMen) base *= 1.12;
  const whole = Math.max(1, Math.floor(base));
  const frac = base - whole;
  const n = whole + (rng() < frac ? 1 : 0);
  return Math.min(n, 2);
}

// ── Порядок типов для сортировки ленты ────────────────────────────────────

const TYPE_ORDER: Record<MatchEventType, number> = {
  kickoff: 0,
  goal: 1,
  chance: 1,
  yellow: 1,
  red: 1,
  injury: 1,
  sub: 1,
  pen_goal: 1,
  pen_miss: 1,
  pen_save: 1,
  shot_on: 1,
  shot_off: 1,
  save: 1,
  corner: 1,
  offside: 1,
  duel: 1,
  momentum: 1,
  halftime: 2,
  fulltime: 3,
};

// ── Публичное API ─────────────────────────────────────────────────────────

/**
 * ENGINE 2.0: полный событийный симулятор матча. Drop-in замена
 * simulateMatch (та же сигнатура и результат). opts.neutral — финал кубка.
 */
export function simulateMatchV2(
  rng: RNG,
  home: MatchInput2,
  away: MatchInput2,
  opts?: { neutral?: boolean },
): MatchResult {
  const neutral = opts?.neutral === true;
  const H = buildSide(home, 'home', !neutral, rng);
  const A = buildSide(away, 'away', false, rng);

  const st: MatchState = {
    rng,
    minute: 0,
    possession: rng() < 0.5 ? 'home' : 'away',
    zone: 'MC',
    events: [],
    scoreH: 0,
    scoreA: 0,
    injuries: [],
    lastEventMinute: 0,
    fillers: 0,
    actionLog: [],
    lastMomentum: -MOMENTUM_COOLDOWN,
    lastPasser: null,
    chainDepth: 0,
  };

  emit(st, null, 'kickoff', C.KICKOFF_TEXT);

  for (let minute = 1; minute <= 93; minute++) {
    st.minute = minute;

    staminaTick(H);
    staminaTick(A);

    if (minute === 45) {
      emit(st, null, 'halftime', C.HALFTIME_TEXT);
      const losing = st.scoreH < st.scoreA ? H : st.scoreA < st.scoreH ? A : null;
      if (losing) swingMorale(losing, MORALE_HALFTIME_LOSING_TALK);
      for (const s of [H, A]) {
        for (const id of s.currentLineup) {
          const rt = id ? s.byId.get(id) : undefined;
          if (rt && rt.offAt === null) rt.energy = Math.min(100, rt.energy + 2);
        }
      }
      continue;
    }

    if (minute === 46) {
      st.possession = st.possession === 'home' ? 'away' : 'home';
      st.zone = 'MC';
      st.chainDepth = 0;
      emit(st, null, 'kickoff', C.KICKOFF_2ND_TEXT);
      continue;
    }

    fatigueSubCheck(rng, st, H);
    fatigueSubCheck(rng, st, A);
    tacticDynamics(st, H, A);

    // усталостные травмы «без контакта»
    for (const s of [H, A]) {
      const field = fieldRTs(s);
      if (field.length && rng() < INJURY_PER_MIN * field.length * (s.input.medRiskMult ?? 1)) {
        const victim = pickWeighted(
          rng,
          field.map((x) => ({ item: x, weight: Math.max(1, x.p.injuryProneness ?? 50) })),
        );
        injurePlayer(rng, st, s, victim);
      }
    }

    const poss = st.possession === 'home' ? H : A;
    const opp = st.possession === 'home' ? A : H;
    const n = actionsThisMinute(rng, poss, opp);

    for (let i = 0; i < n; i++) {
      const chain = runAction(rng, st, H, A);
      if (chain && rng() < 0.62 && st.chainDepth < 4) {
        st.chainDepth += 1;
        i -= 1; // атака продолжается в ту же минуту
      } else {
        st.chainDepth = 0;
      }
    }

    momentumCheck(rng, st, H, A);
    fillerCheck(rng, st, H, A);
  }

  emit(st, null, 'fulltime', C.FULLTIME_TEXT);

  const totalActions = Math.max(1, H.stats.actions + A.stats.actions);
  const possessionHome = clamp(Math.round((100 * H.stats.actions) / totalActions), 25, 75);
  const countType = (s: SideRT, type: MatchEventType) =>
    st.events.filter((e) => e.teamId === s.input.teamId && e.type === type).length;

  const stats: MatchStats = {
    possessionHome,
    shotsHome: H.stats.shots,
    shotsAway: A.stats.shots,
    sotHome: H.stats.sot,
    sotAway: A.stats.sot,
    cornersHome: H.stats.corners,
    cornersAway: A.stats.corners,
    foulsHome: Math.max(6, H.stats.fouls),
    foulsAway: Math.max(6, A.stats.fouls),
    yellowsHome: countType(H, 'yellow'),
    yellowsAway: countType(A, 'yellow'),
    redsHome: countType(H, 'red'),
    redsAway: countType(A, 'red'),
  };

  st.events.sort((a, b) => a.minute - b.minute || TYPE_ORDER[a.type] - TYPE_ORDER[b.type]);

  return {
    homeGoals: st.scoreH,
    awayGoals: st.scoreA,
    events: st.events,
    stats,
    homeStarters: [...home.lineup],
    awayStarters: [...away.lineup],
    homeSubs: H.subs,
    awaySubs: A.subs,
    injuries: st.injuries,
  };
}

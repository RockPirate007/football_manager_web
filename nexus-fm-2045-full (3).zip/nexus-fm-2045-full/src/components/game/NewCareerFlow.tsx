'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  ArrowLeft, Check, Loader2, MapPin, ShieldCheck, Sparkles, Trophy, Users,
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { ClubCard } from '@/components/game/ClubCard';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { formatMoney } from '@/lib/game/format';
import type { LeagueCatalogDTO, LeagueCode } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const DIFFICULTY_TONE: Record<string, string> = {
  Хардкор: 'border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]',
  Сложная: 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]',
  Средняя: 'border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]',
  Входная: 'border-primary/40 bg-primary/10 text-primary',
};

/** Карточка лиги (шаг 1). */
function LeagueCard({
  league,
  onSelect,
}: {
  league: LeagueCatalogDTO;
  onSelect: () => void;
}) {
  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      whileHover={{ y: -3 }}
      onClick={onSelect}
      className="min-h-[44px] w-full rounded-lg text-left outline-none focus-visible:ring-2 focus-visible:ring-ring"
      aria-label={`Лига ${league.nameRu}`}
    >
      <Card className="h-full border-border/70 transition-colors hover:border-primary/50">
        <CardContent className="flex h-full flex-col gap-3 p-4">
          <div className="flex items-start justify-between gap-2">
            <span className="text-4xl leading-none" role="img" aria-label={league.country}>
              {league.flag}
            </span>
            <Badge
              variant="outline"
              className={DIFFICULTY_TONE[league.difficulty] ?? 'border-border text-muted-foreground'}
            >
              {league.difficulty}
            </Badge>
          </div>
          <div>
            <div className="text-sm font-bold leading-tight">{league.nameRu}</div>
            <div className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="size-3" aria-hidden />
              {league.country}
            </div>
          </div>
          <div className="mt-auto space-y-1.5 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Users className="size-3.5 shrink-0" aria-hidden />
              {league.teamCount} клубов · {league.leagueWeeks} туров
            </div>
            <div className="flex items-center gap-1.5">
              <Trophy className="size-3.5 shrink-0 text-[#EAB308]" aria-hidden />
              {league.cupName}
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 shrink-0" aria-hidden />
              Средняя сила: <span className="font-semibold text-foreground tabular">{league.avgStrength}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.button>
  );
}

/** Шаг 1 — выбор лиги из каталога (GET /leagues). */
function StepLeague() {
  const leagues = useGameStore((s) => s.leagues);
  const leaguesLoading = useGameStore((s) => s.leaguesLoading);
  const setNewLeague = useGameStore((s) => s.setNewLeague);

  return (
    <div className="w-full max-w-5xl">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-5 text-center"
      >
        <h1 className="flex items-center justify-center gap-2 text-xl font-bold sm:text-2xl">
          <Sparkles className="size-5 text-primary" aria-hidden />
          Выберите лигу
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          6 чемпионатов и 6 национальных кубков. От «Хардкора» АПЛ до входной Лиги 1.
        </p>
      </motion.div>

      {leaguesLoading && leagues.length === 0 ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-52 rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {leagues.map((l) => (
            <LeagueCard key={l.code} league={l} onSelect={() => setNewLeague(l.code)} />
          ))}
        </div>
      )}
    </div>
  );
}

/** Шаг 2 — выбор клуба лиги. */
function StepClub() {
  const leagues = useGameStore((s) => s.leagues);
  const newLeagueCode = useGameStore((s) => s.newLeagueCode);
  const setNewClub = useGameStore((s) => s.setNewClub);
  const backToLeagues = useGameStore((s) => s.backToLeagues);
  const [selected, setSelected] = useState<number | null>(null);

  const league = leagues.find((l) => l.code === newLeagueCode);

  if (!league) {
    return (
      <Card className="border-border/70">
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          <p className="text-sm">Лига не выбрана — начните с шага 1.</p>
          <Button variant="outline" onClick={backToLeagues} className="min-h-11">
            <ArrowLeft className="size-4" aria-hidden />
            К выбору лиги
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-5"
      >
        <Button
          variant="ghost"
          size="sm"
          onClick={backToLeagues}
          className="mb-3 min-h-11 px-2 text-muted-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden />
          Все лиги
        </Button>
        <div className="text-center">
          <h1 className="flex items-center justify-center gap-2 text-xl font-bold sm:text-2xl">
            <span role="img" aria-label={league.country}>{league.flag}</span>
            {league.nameRu}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Чем сильнее клуб — тем выше ожидания. Аутсайдеру проще удивить лигу.
          </p>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {league.clubs.map((club) => (
          <ClubCard
            key={club.index}
            club={club}
            selected={selected === club.index}
            onSelect={() => {
              setSelected(club.index);
              setNewClub(club);
            }}
          />
        ))}
      </div>
    </div>
  );
}

/** Шаг 3 — имя менеджера и название карьеры, старт. */
function StepManager() {
  const leagues = useGameStore((s) => s.leagues);
  const newLeagueCode = useGameStore((s) => s.newLeagueCode);
  const newClub = useGameStore((s) => s.newClub);
  const backToClubs = useGameStore((s) => s.backToClubs);
  const createCareer = useGameStore((s) => s.createCareer);
  const loading = useGameStore((s) => s.loading);
  const savesCount = useGameStore((s) => s.saves.length);

  const [managerName, setManagerName] = useState('');
  const [careerName, setCareerName] = useState('');
  const [busy, setBusy] = useState(false);

  const league = leagues.find((l) => l.code === newLeagueCode);
  const club = newClub;

  if (!league || !club) {
    return (
      <Card className="border-border/70">
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          <p className="text-sm">Клуб не выбран — вернитесь к шагу 2.</p>
          <Button variant="outline" onClick={backToClubs} className="min-h-11">
            <ArrowLeft className="size-4" aria-hidden />
            К выбору клуба
          </Button>
        </CardContent>
      </Card>
    );
  }

  const autoCareerName = `${club.name} · Сезон 1`;

  const handleStart = async () => {
    const manager = managerName.trim();
    if (manager.length < 1) {
      toast.error('Введите имя менеджера');
      return;
    }
    if (manager.length > 40) {
      toast.error('Имя не длиннее 40 символов');
      return;
    }
    const career = careerName.trim();
    if (career.length > 60) {
      toast.error('Название карьеры — не длиннее 60 символов');
      return;
    }
    setBusy(true);
    const ok = await createCareer({
      leagueCode: league.code,
      clubIndex: club.index,
      managerName: manager,
      careerName: career.length > 0 ? career : undefined,
    });
    setBusy(false);
    if (!ok && useGameStore.getState().saves.length >= 8) {
      // Лимит карьер — уходим на экран карьер.
      useGameStore.getState().exitToCareers();
    }
  };

  const disabled = busy || loading;

  return (
    <div className="w-full max-w-md">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Button
          variant="ghost"
          size="sm"
          onClick={backToClubs}
          className="mb-3 min-h-11 px-2 text-muted-foreground"
        >
          <ArrowLeft className="size-4" aria-hidden />
          Клубы {league.nameRu}
        </Button>

        <Card className="border-border/70">
          <CardHeader className="text-center">
            <div className="mx-auto mb-2 flex size-16 items-center justify-center rounded-full bg-primary/15">
              <TeamCrest
                shortName={club.shortName}
                colorPrimary={club.colorPrimary}
                colorSecondary={club.colorSecondary}
                size="lg"
              />
            </div>
            <CardTitle className="text-xl">{club.name}</CardTitle>
            <p className="mt-1 text-xs text-muted-foreground">
              {league.flag} {league.nameRu} · {league.difficulty} · сила {club.strength}
            </p>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="rounded bg-secondary/60 px-2.5 py-2">
                <div className="text-muted-foreground">Стартовый бюджет</div>
                <div className="mt-0.5 tabular font-semibold text-[#EAB308]">
                  {formatMoney(club.startBalance)}
                </div>
              </div>
              <div className="rounded bg-secondary/60 px-2.5 py-2">
                <div className="text-muted-foreground">Стадион</div>
                <div className="mt-0.5 tabular font-semibold">
                  {club.stadiumCapacity.toLocaleString('ru-RU')} мест
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="new-manager-name">Имя менеджера</Label>
              <Input
                id="new-manager-name"
                value={managerName}
                onChange={(e) => setManagerName(e.target.value)}
                placeholder="Например: Алексей Воронин"
                maxLength={40}
                autoComplete="off"
                className="h-11 bg-secondary"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="new-career-name">Название карьеры</Label>
              <Input
                id="new-career-name"
                value={careerName}
                onChange={(e) => setCareerName(e.target.value)}
                placeholder={autoCareerName}
                maxLength={60}
                autoComplete="off"
                className="h-11 bg-secondary"
              />
              <p className="text-[11px] text-muted-foreground">
                Оставьте пустым — назовём «{autoCareerName}».
              </p>
            </div>

            <Button
              size="lg"
              className="h-12 w-full text-base"
              onClick={() => void handleStart()}
              disabled={disabled}
            >
              {disabled ? (
                <Loader2 className="size-5 animate-spin" aria-hidden />
              ) : (
                <Trophy className="size-5" aria-hidden />
              )}
              Начать карьеру
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              Впереди {league.leagueWeeks} туров и {league.cupName}. Карьера {savesCount + 1} из 8.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

/** Степпер «Лига → Клуб → Менеджер» — всегда видно, где вы в флоу. */
function CareerStepper({ step }: { step: 1 | 2 | 3 }) {
  const steps = [
    { n: 1, label: 'Лига' },
    { n: 2, label: 'Клуб' },
    { n: 3, label: 'Менеджер' },
  ] as const;
  return (
    <div className="mb-6 w-full">
      <ol
        className="mx-auto flex max-w-md items-center justify-center gap-2 sm:gap-3"
        aria-label="Шаги создания карьеры"
      >
        {steps.map((s, i) => {
          const state = s.n === step ? 'current' : s.n < step ? 'done' : 'todo';
          return (
            <li key={s.n} className="flex items-center gap-2 sm:gap-3">
              {i > 0 ? <span className="h-px w-6 bg-border sm:w-10" aria-hidden /> : null}
              <span
                className={cn(
                  'flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors',
                  state === 'current' &&
                    'border-primary/60 bg-primary/15 text-primary shadow-[0_0_16px_rgba(0,212,255,0.25)]',
                  state === 'done' && 'border-primary/30 bg-primary/5 text-primary/80',
                  state === 'todo' && 'border-border/60 text-muted-foreground/70',
                )}
                aria-current={state === 'current' ? 'step' : undefined}
              >
                <span
                  className={cn(
                    'flex size-5 items-center justify-center rounded-full text-[10px] font-bold leading-none tabular',
                    state === 'current' && 'bg-primary text-primary-foreground',
                    state === 'done' && 'bg-primary/20 text-primary',
                    state === 'todo' && 'bg-secondary text-muted-foreground',
                  )}
                >
                  {state === 'done' ? <Check className="size-3" aria-hidden /> : s.n}
                </span>
                <span className="hidden sm:inline">{s.label}</span>
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

/** Флоу новой карьеры: лига → клуб → менеджер (§7.3 architecture-upgrade.md). */
export function NewCareerFlow() {
  const phase = useGameStore((s) => s.phase);
  const startNewCareer = useGameStore((s) => s.startNewCareer);
  const step: 1 | 2 | 3 =
    phase === 'league-select' ? 1 : phase === 'club-select' ? 2 : 3;

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-background cyber-grid p-4 py-8 sm:p-6">
      {/* Мини-логотип + степпер */}
      <div className="mb-5 text-center">
        <h2 className="flex items-baseline justify-center gap-1.5 text-xl font-black tracking-tight">
          <span className="neon-text text-primary">NEXUS FM</span>
          <span className="text-[#FF6B35]">2045</span>
        </h2>
        <p className="mt-0.5 text-[11px] uppercase tracking-[0.2em] text-muted-foreground/70">
          Новая карьера
        </p>
      </div>
      <CareerStepper step={step} />

      {phase === 'league-select' ? (
        <StepLeague />
      ) : phase === 'club-select' ? (
        <StepClub />
      ) : (
        <StepManager />
      )}
      {phase === 'league-select' ? (
        <p className="mt-6 text-xs text-muted-foreground">
          Уже есть карьеры?{' '}
          <button
            type="button"
            className="font-semibold text-primary underline-offset-2 hover:underline"
            onClick={() => {
              void useGameStore.getState().fetchSaves().then(() => {
                const s = useGameStore.getState();
                if (s.saves.length > 0) {
                  useGameStore.setState({ phase: 'careers' });
                } else {
                  toast.error('Сохранённых карьер нет');
                }
              });
            }}
          >
            Вернуться к списку
          </button>{' '}
          или{' '}
          <button
            type="button"
            className="font-semibold text-primary underline-offset-2 hover:underline"
            onClick={startNewCareer}
          >
            обновить каталог
          </button>
        </p>
      ) : null}
    </main>
  );
}

/**
 * Пост-матчевые апдейты (мораль/состояние/статистика/травмы) и
 * межсезонье (старение, развитие, пенсии). Разделы 4.10–4.11 architecture.md.
 */

import {
  CONDITION_BENCH_GAIN, CONDITION_DRAIN_BASE, CONDITION_DRAIN_MIN, CONDITION_MAX,
  CONDITION_MIN, CONDITION_WEEKLY_RECOVERY, MORALE_BENCH_RATIO, MORALE_DRAW,
  MORALE_LOSS, MORALE_MAX, MORALE_MIN, MORALE_WIN, PRESSING_DRAIN, TEMPO_DRAIN,
  RATING_ASSIST, RATING_BASE, RATING_DRAW, RATING_GOAL, RATING_GK_CLEAN, RATING_GK_CONCEDED,
  RATING_GK_CONCEDED_CAP, RATING_LOSS, RATING_MAX, RATING_MIN, RATING_NOISE,
  RATING_RED, RATING_WIN, RATING_YELLOW,
} from './constants';
import { computeOvr, computeSalary, computeValue, type PlayerLike } from './players';
import { applyMatchDevelopment, developPlayerSeasonal } from './development';
import type { SubRecord } from './match';
import { clamp, pick, randInt, type RNG } from './rng';
import type { MatchEvent, TempoLevel, PressingLevel } from './types';

export interface PostMatchTeam {
  players: PlayerLike[];
  starterIds: Set<string>;
  benchIds: Set<string>;
  events: MatchEvent[]; // события матча этой команды (все)
  outcome: 'W' | 'D' | 'L';
  tempo: TempoLevel;
  pressing: PressingLevel;
  /** league — обычный матч; cup — голы/ассисты пишутся и в cupGoals/cupAssists; euro — и в euroGoals/euroAssists. */
  competition?: 'league' | 'cup' | 'euro';
  /** Фаза 3: пропущено этой командой (null = нет данных — рейтинг без GK-поправок). */
  goalsConceded?: number | null;
  /** Фаза 4: замены матча — минуты выходов/сходов (drain и apps по сыгранным минутам). Отсутствие = замены не фиксировались. */
  subs?: SubRecord[];
}

/**
 * Рейтинг матча стартёра (Фаза 3, §5 architecture-phase3.md — FM-шкала):
 * 6.5 + W/D/L (±0.3) + гол×0.7 + ассист×0.35 + жёлтая −0.1 + красная −0.6
 * + GK-поправки (сухой +0.4 / −0.12 за пропущенный, кап −0.6) + шум ±0.2,
 * clamp 4.5..10.0, ×10 → Int (округление до 0.1).
 */
export function computeMatchRating(args: {
  player: PlayerLike;
  outcome: 'W' | 'D' | 'L';
  goals: number;
  assists: number;
  yellows: number;
  reds: number;
  goalsConceded: number | null;
  rng: RNG;
}): number {
  const { player, outcome, rng } = args;
  let r = RATING_BASE
    + (outcome === 'W' ? RATING_WIN : outcome === 'D' ? RATING_DRAW : RATING_LOSS)
    + args.goals * RATING_GOAL
    + args.assists * RATING_ASSIST
    + args.yellows * RATING_YELLOW
    + args.reds * RATING_RED;
  if (player.position === 'GK' && args.goalsConceded !== null && args.goalsConceded !== undefined) {
    r += args.goalsConceded === 0
      ? RATING_GK_CLEAN
      : Math.max(RATING_GK_CONCEDED_CAP, args.goalsConceded * RATING_GK_CONCEDED);
  }
  // Модуль 2: стабильность сужает разброс рейтинга — нестабильный игрок
  // (consistency 20) качается на ±1.4×, надёжный (90) — на ±0.65×.
  const noiseAmp = clamp(0.55 + (100 - (player.consistency ?? 55)) / 100, 0.5, 1.5);
  r += (rng() * 2 - 1) * RATING_NOISE * noiseAmp;
  r = clamp(r, RATING_MIN, RATING_MAX);
  return Math.round(r * 10);
}

/**
 * Сыгранные минуты игрока (Фаза 4, §4.4):
 * стартёр — до схода (замена/удаление/травма), вышедший — 90 − минута входа,
 * не игравший — 0. Замена на 46' и выход на 46' дают в сумме ровно 90.
 */
function minutesPlayedOf(
  starterIds: Set<string>,
  subOutAt: Map<string, number>,
  offAt: Map<string, number>,
  subInAt: Map<string, number>,
  playerId: string,
): number {
  if (starterIds.has(playerId)) {
    const sub = subOutAt.get(playerId);
    if (sub !== undefined) return sub;
    const off = offAt.get(playerId);
    if (off !== undefined) return off;
    return 90;
  }
  const inM = subInAt.get(playerId);
  return inM !== undefined ? clamp(90 - inM, 0, 90) : 0;
}

/**
 * Пост-матч одной команды — per-match часть (Фаза 4, §4.4). Мутирует на месте.
 * Вызывается на КАЖДЫЙ матч команды (в неделе 1–2 матча).
 * - игравшие (стартёры и вышедшие на замену): drain готовности × минуты/90,
 *   apps+1, рейтинг матча;
 * - неиспользованный запас: +10;
 * - мораль: победа +15 / ничья +2 / поражение −15 (не игравшие — половина), clamp 5..100;
 * - голы/ассисты/карточки — из событий (кубок/евро — дублирование в счётчики);
 * - травмы — из injuries.
 * БЕЗ недельного восстановления: +8 — в applyWeeklyRecovery (ровно 1 раз в неделю).
 *
 * D-5 «Территория» (§3.5): опц. opts.injuryDurMult — множитель длительности
 * ВЫБРАННЫХ недель травмы (medical L клуба игрока): round, min 1. Без opts —
 * как раньше (обратная совместимость).
 *
 * Модуль 2: opts.devRng — ОТДЕЛЬНЫЙ rng-поток матчёвого опыта (минуты →
 * trainingXp, development.applyMatchDevelopment). Обязателен отдельный поток:
 * броски рейтинг-шума не должны смешиваться с ростом (детерминизм).
 */
export function applyMatchEffects(
  team: PostMatchTeam,
  injuries: Map<string, number>,
  ratingRng: RNG,
  opts?: { injuryDurMult?: number; devRng?: RNG },
): void {
  const goalDelta = team.outcome === 'W' ? MORALE_WIN : team.outcome === 'D' ? MORALE_DRAW : MORALE_LOSS;

  const statFromEvents = new Map<string, { goals: number; assists: number; yellows: number; reds: number }>();
  for (const e of team.events) {
    if (!e.playerId) continue;
    const rec = statFromEvents.get(e.playerId) ?? { goals: 0, assists: 0, yellows: 0, reds: 0 };
    if (e.type === 'goal') rec.goals += 1;
    if (e.type === 'yellow') rec.yellows += 1;
    if (e.type === 'red') rec.reds += 1;
    if (e.type === 'goal' && e.assistId) {
      const assistRec = statFromEvents.get(e.assistId) ?? { goals: 0, assists: 0, yellows: 0, reds: 0 };
      assistRec.assists += 1;
      statFromEvents.set(e.assistId, assistRec);
    }
    statFromEvents.set(e.playerId, rec);
  }

  // Минуты: выходы/сходы из замен + удаления/травмы из событий
  const subOutAt = new Map<string, number>();
  const subInAt = new Map<string, number>();
  for (const s of team.subs ?? []) {
    subOutAt.set(s.outId, s.minute);
    subInAt.set(s.inId, s.minute);
  }
  const offAt = new Map<string, number>();
  for (const e of team.events) {
    if (!e.playerId) continue;
    if (e.type === 'red' || e.type === 'injury') {
      offAt.set(e.playerId, Math.min(offAt.get(e.playerId) ?? 95, e.minute));
    }
  }

  for (const p of team.players) {
    const isBench = team.benchIds.has(p.id);
    const mins = minutesPlayedOf(team.starterIds, subOutAt, offAt, subInAt, p.id);
    const played = mins > 0;

    if (played) {
      const drain =
        Math.max(CONDITION_DRAIN_MIN, CONDITION_DRAIN_BASE - p.stamina / 12) +
        (team.tempo === 'high' ? TEMPO_DRAIN : team.tempo === 'low' ? -TEMPO_DRAIN : 0) +
        (team.pressing === 'high' ? PRESSING_DRAIN : 0);
      p.condition = clamp(p.condition - (drain * mins) / 90, CONDITION_MIN, CONDITION_MAX);
      p.apps += 1;
    } else if (isBench) {
      p.condition = clamp(p.condition + CONDITION_BENCH_GAIN, CONDITION_MIN, CONDITION_MAX);
    }

    // мораль
    const delta = played ? goalDelta : Math.round(goalDelta * MORALE_BENCH_RATIO);
    p.morale = clamp(p.morale + delta, MORALE_MIN, MORALE_MAX);

    // статистика сезона (кубок/евро: + дублируется в соревновательные счётчики)
    const st = statFromEvents.get(p.id);
    if (st) {
      p.goals += st.goals;
      p.assists += st.assists;
      p.yellowCards += st.yellows;
      p.redCards += st.reds;
      if (team.competition === 'cup') {
        p.cupGoals += st.goals;
        p.cupAssists += st.assists;
      }
      if (team.competition === 'euro') {
        p.euroGoals += st.goals;
        p.euroAssists += st.assists;
      }
    }

    // Фаза 4: рейтинг матча — ВСЕМ игравшим (вышедшим на замену тоже)
    if (played) {
      const st0 = st ?? { goals: 0, assists: 0, yellows: 0, reds: 0 };
      const ratingX10 = computeMatchRating({
        player: p,
        outcome: team.outcome,
        goals: st0.goals,
        assists: st0.assists,
        yellows: st0.yellows,
        reds: st0.reds,
        goalsConceded: team.goalsConceded ?? null,
        rng: ratingRng,
      });
      p.ratingSum += ratingX10;
      p.ratingApps += 1;

      // Модуль 2: матчёвый опыт — минуты молодёжи конвертируются в развитие
      // (пишется в trainingXp, конвертация в +1 — на недельной тренировке)
      if (opts?.devRng) applyMatchDevelopment(opts.devRng, p, mins);
    }

    // травма из матча (D-5: × medical-множитель длительности — клуб игрока)
    const weeks = injuries.get(p.id);
    if (weeks !== undefined) {
      p.injuryWeeks = opts?.injuryDurMult !== undefined
        ? Math.max(1, Math.round(weeks * opts.injuryDurMult))
        : weeks;
    }
  }
}

/**
 * Недельное восстановление (per-week, Фаза 4, §4.4): +8 готовности всем,
 * clamp 30..100. Вызывается РОВНО один раз на команду, сыгравшую ≥1 матч
 * в неделе — независимо от того, 1 матч или 2.
 *
 * D-5 «Территория» (§3.5): опц. opts.bonus — доп. восстановление клуба
 * игрока сверх +8 (fitness 0.4·L + hotel 0.6·L/0.3·L — собирает week.ts).
 */
export function applyWeeklyRecovery(
  players: PlayerLike[],
  opts?: { bonus?: number },
): void {
  const bonus = opts?.bonus ?? 0;
  for (const p of players) {
    p.condition = clamp(p.condition + CONDITION_WEEKLY_RECOVERY + bonus, CONDITION_MIN, CONDITION_MAX);
  }
}

/**
 * Пост-матч одной команды (легаси-обёртка Фазы 3): per-match эффекты +
 * недельное восстановление одним вызовом. Для недель с одним матчем и без
 * замен/удалений поведение тождественно до-Фазному; интеграция двойных
 * недель (applyMatchEffects ×2 + applyWeeklyRecovery ×1) — в week.ts (A10).
 */
export function applyPostMatch(team: PostMatchTeam, injuries: Map<string, number>, ratingRng: RNG): void {
  applyMatchEffects(team, injuries, ratingRng);
  applyWeeklyRecovery(team.players);
}


// ── Межсезонье (4.11) ────────────────────────────────────────────────────

export interface SeasonProgressionResult {
  retired: PlayerLike[]; // ушедшие игроки (нужно заменить)
}

/**
 * Развитие игрока в межсезонье (шаг 3 раздела 4.11) + пересчёт OVR/цен.
 * Возраст увеличивается на 1 В week.ts до вызова этой функции.
 * Модуль 2: логика — покатегорийные кривые development.ts (техника до ~27,
 * ментальные до ~31, физика деградирует после 30–32, GK сдвинут на +3).
 */
function developPlayer(rng: RNG, p: PlayerLike): void {
  developPlayerSeasonal(rng, p);
}

/**
 * Выйдет ли игрок на пенсию в межсезонье.
 * Модуль 2: вратари играют на ~3 года дольше полевых (до 38–40, как в FM).
 */
export function retires(p: PlayerLike, rng: RNG): boolean {
  if (p.position === 'GK') {
    if (p.age >= 38) return true;
    if (p.age >= 36) return rng() < 0.4;
    return false;
  }
  if (p.age >= 35) return true;
  if (p.age >= 33) return rng() < 0.4;
  return false;
}

/**
 * Полное межсезонье по составу: старение уже применено снаружи, здесь —
 * развитие, пенсии, сброс статистики, пересчёт экономики.
 * Возвращает ушедших (их нужно заменить новыми игроками).
 */
export function applySeasonProgression(rng: RNG, players: PlayerLike[]): SeasonProgressionResult {
  const retired: PlayerLike[] = [];

  for (const p of players) {
    developPlayer(rng, p);
    p.ovr = computeOvr(p, p.position);
    p.potential = Math.max(p.potential, p.ovr);
    // Сброс сезонной статистики и состояния (trainingXp НЕ сбрасывается —
    // непрерывность развития между сезонами; Фаза 3: рейтинг тоже сезонный)
    p.goals = 0;
    p.assists = 0;
    p.apps = 0;
    p.yellowCards = 0;
    p.redCards = 0;
    p.cleanSheets = 0;
    p.cupGoals = 0;
    p.cupAssists = 0;
    p.euroGoals = 0; // Фаза 4: евростатистика — сезонная (сброс как кубковая)
    p.euroAssists = 0;
    p.ratingSum = 0;
    p.ratingApps = 0;
    p.condition = 100;
    p.morale = 60;
    p.injuryWeeks = 0;
    p.value = computeValue(p);
    p.salary = computeSalary(p.value);
  }

  const remaining: PlayerLike[] = [];
  for (const p of players) {
    if (retires(p, rng)) retired.push(p);
    else remaining.push(p);
  }
  // Мутируем исходный массив: оставшиеся остаются, ушедшие удаляются снаружи
  players.length = 0;
  players.push(...remaining);

  return { retired };
}

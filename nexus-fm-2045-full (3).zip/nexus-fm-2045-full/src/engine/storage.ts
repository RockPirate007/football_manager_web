/**
 * StorageAdapter — хранение слотов сейвов (спека §2.2): list/read/write/remove/
 * rename. Реализации: NeutralinoStorage (exe: ${NL_APPDATA}/saves, атомарная
 * запись tmp+rename, meta.json со всеми 8 ключами), IndexedDBStorage (браузерный
 * фоллбэк: БД fm-desktop, ключи fm-desktop/slot-N + fm-desktop/meta),
 * MemoryStorage (тесты/bun). createStorage() — автовыбор с кешем на уровне
 * модуля. Изоморфно: Web API + window.Neutralino (декларации neutralino.d.ts).
 */

import { SAVES_MAX } from '@/lib/game/constants';
import type { SaveCardDTO } from '@/lib/game/types';

// ── Контракт (§2.2) ────────────────────────────────────────────────────────

export interface SlotMeta {
  /** 1..8 (SAVES_MAX). */
  slot: number;
  /** Та же DTO, что сейчас отдаёт GET /saves. */
  card: SaveCardDTO;
  /** ISO — последний автосейв слота. */
  updatedAt: string;
}

export interface StorageAdapter {
  /** Читает ТОЛЬКО meta.json (быстро). */
  list(): Promise<SlotMeta[]>;
  /** Raw canonical JSON slot-N.json; null — слот пуст. */
  read(slot: number): Promise<string | null>;
  /** Атомарно (tmp+rename) пишет слот и обновляет meta.json. */
  write(slot: number, json: string, meta: SlotMeta): Promise<void>;
  /** Удаляет slot-N.json + запись из meta.json. */
  remove(slot: number): Promise<void>;
  /** Только meta.json; поле gameSave.careerName — лениво при следующем автосейве. */
  rename(slot: number, careerName: string): Promise<void>;
}

function assertSlot(slot: number): void {
  if (!Number.isInteger(slot) || slot < 1 || slot > SAVES_MAX) {
    throw new Error(`storage: номер слота должен быть целым 1..${SAVES_MAX}, получено ${slot}`);
  }
}

/** Каталог NL_APPDATA (спека §7: скопы $NL_APPDATA/saves read-write). */
function appDataDir(): string {
  if (typeof NL_APPDATA !== 'undefined' && NL_APPDATA) return NL_APPDATA;
  return '.';
}

// ── NeutralinoStorage (основная для exe) ───────────────────────────────────

/** meta.json: ключи — ВСЕГДА все 8 слотов, пустые — null (§2.2). */
function metaEntriesFrom(raw: string | null): Record<number, SlotMeta | null> {
  const entries: Record<number, SlotMeta | null> = {};
  for (let s = 1; s <= SAVES_MAX; s++) entries[s] = null;
  if (raw === null) return entries;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) {
      const src = parsed as Record<string, unknown>;
      for (let s = 1; s <= SAVES_MAX; s++) {
        const value = src[String(s)];
        if (value !== null && typeof value === 'object') {
          entries[s] = value as SlotMeta;
        }
      }
    }
  } catch {
    // битый meta.json → считаем все слоты пустыми (слоты сами по себе целы)
  }
  return entries;
}

function metaJsonOf(entries: Record<number, SlotMeta | null>): string {
  const out: Record<string, SlotMeta | null> = {};
  for (let s = 1; s <= SAVES_MAX; s++) out[String(s)] = entries[s] ?? null;
  return JSON.stringify(out);
}

export class NeutralinoStorage implements StorageAdapter {
  private readonly dir = `${appDataDir()}/saves`;
  private dirEnsured = false;

  private slotPath(slot: number): string {
    return `${this.dir}/slot-${slot}.json`;
  }

  private get metaPath(): string {
    return `${this.dir}/meta.json`;
  }

  private async ensureDir(): Promise<void> {
    if (this.dirEnsured) return;
    try {
      await window.Neutralino?.filesystem.createDirectory(this.dir);
    } catch {
      // каталог уже существует (или создан параллельно) — не ошибка
    }
    this.dirEnsured = true;
  }

  /** Атомарная запись: .tmp + move (§2.2). */
  private async atomicWrite(path: string, content: string): Promise<void> {
    const fs = window.Neutralino?.filesystem;
    if (!fs) throw new Error('NeutralinoStorage: window.Neutralino.filesystem недоступен');
    const tmp = `${path}.tmp`;
    await fs.writeFile(tmp, content);
    await fs.move(tmp, path);
  }

  private async readText(path: string): Promise<string | null> {
    try {
      return await window.Neutralino?.filesystem.readFile(path) ?? null;
    } catch {
      return null; // файл не существует
    }
  }

  private async readEntries(): Promise<Record<number, SlotMeta | null>> {
    return metaEntriesFrom(await this.readText(this.metaPath));
  }

  private async writeEntries(entries: Record<number, SlotMeta | null>): Promise<void> {
    await this.ensureDir();
    await this.atomicWrite(this.metaPath, metaJsonOf(entries));
  }

  async list(): Promise<SlotMeta[]> {
    const entries = await this.readEntries();
    const out: SlotMeta[] = [];
    for (let s = 1; s <= SAVES_MAX; s++) {
      const meta = entries[s];
      if (meta) out.push(meta);
    }
    return out;
  }

  async read(slot: number): Promise<string | null> {
    assertSlot(slot);
    return this.readText(this.slotPath(slot));
  }

  async write(slot: number, json: string, meta: SlotMeta): Promise<void> {
    assertSlot(slot);
    await this.ensureDir();
    await this.atomicWrite(this.slotPath(slot), json);
    const entries = await this.readEntries();
    entries[slot] = meta;
    await this.writeEntries(entries);
  }

  async remove(slot: number): Promise<void> {
    assertSlot(slot);
    try {
      await window.Neutralino?.filesystem.removeFile(this.slotPath(slot));
    } catch {
      // слота может не быть — не ошибка
    }
    const entries = await this.readEntries();
    entries[slot] = null;
    await this.writeEntries(entries);
  }

  async rename(slot: number, careerName: string): Promise<void> {
    assertSlot(slot);
    const entries = await this.readEntries();
    const meta = entries[slot];
    if (!meta) return; // пустой слот — нечего переименовывать
    entries[slot] = { ...meta, card: { ...meta.card, careerName } };
    await this.writeEntries(entries);
  }
}

// ── IndexedDBStorage (браузерный фоллбэк) ──────────────────────────────────

const IDB_NAME = 'fm-desktop';
const IDB_VERSION = 1;
const IDB_STORE = 'saves';
const IDB_META_KEY = 'fm-desktop/meta';

function idbSlotKey(slot: number): string {
  return `fm-desktop/slot-${slot}`;
}

function withStore<T>(mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const open = indexedDB.open(IDB_NAME, IDB_VERSION);
    open.onupgradeneeded = () => {
      if (!open.result.objectStoreNames.contains(IDB_STORE)) {
        open.result.createObjectStore(IDB_STORE);
      }
    };
    open.onerror = () => reject(open.error ?? new Error('IndexedDBStorage: не удалось открыть БД'));
    open.onsuccess = () => {
      const db = open.result;
      const tx = db.transaction(IDB_STORE, mode);
      const request = fn(tx.objectStore(IDB_STORE));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error('IndexedDBStorage: операция не удалась'));
      tx.oncomplete = () => db.close();
    };
  });
}

export class IndexedDBStorage implements StorageAdapter {
  async list(): Promise<SlotMeta[]> {
    const raw = await withStore('readonly', (store) => store.get(IDB_META_KEY));
    if (!Array.isArray(raw)) return [];
    return (raw as SlotMeta[])
      .filter((m) => m !== null && typeof m === 'object')
      .sort((a, b) => a.slot - b.slot);
  }

  async read(slot: number): Promise<string | null> {
    assertSlot(slot);
    const raw = await withStore('readonly', (store) => store.get(idbSlotKey(slot)));
    return typeof raw === 'string' ? raw : null;
  }

  async write(slot: number, json: string, meta: SlotMeta): Promise<void> {
    assertSlot(slot);
    const metas = await this.list();
    const rest = metas.filter((m) => m.slot !== slot);
    rest.push(meta);
    rest.sort((a, b) => a.slot - b.slot);
    await withStore('readwrite', (store) => store.put(json, idbSlotKey(slot)));
    await withStore('readwrite', (store) => store.put(rest, IDB_META_KEY));
  }

  async remove(slot: number): Promise<void> {
    assertSlot(slot);
    const metas = (await this.list()).filter((m) => m.slot !== slot);
    await withStore('readwrite', (store) => store.delete(idbSlotKey(slot)));
    await withStore('readwrite', (store) => store.put(metas, IDB_META_KEY));
  }

  async rename(slot: number, careerName: string): Promise<void> {
    assertSlot(slot);
    const metas = await this.list();
    const idx = metas.findIndex((m) => m.slot === slot);
    if (idx < 0) return;
    metas[idx] = { ...metas[idx], card: { ...metas[idx].card, careerName } };
    await withStore('readwrite', (store) => store.put(metas, IDB_META_KEY));
  }
}

// ── MemoryStorage (тесты/bun) ──────────────────────────────────────────────

export class MemoryStorage implements StorageAdapter {
  private readonly slots = new Map<number, string>();
  private readonly metas = new Map<number, SlotMeta>();

  async list(): Promise<SlotMeta[]> {
    const out: SlotMeta[] = [];
    for (let s = 1; s <= SAVES_MAX; s++) {
      const meta = this.metas.get(s);
      if (meta) out.push(meta);
    }
    return out;
  }

  async read(slot: number): Promise<string | null> {
    assertSlot(slot);
    return this.slots.get(slot) ?? null;
  }

  async write(slot: number, json: string, meta: SlotMeta): Promise<void> {
    assertSlot(slot);
    this.slots.set(slot, json);
    this.metas.set(slot, meta);
  }

  async remove(slot: number): Promise<void> {
    assertSlot(slot);
    this.slots.delete(slot);
    this.metas.delete(slot);
  }

  async rename(slot: number, careerName: string): Promise<void> {
    assertSlot(slot);
    const meta = this.metas.get(slot);
    if (!meta) return;
    this.metas.set(slot, { ...meta, card: { ...meta.card, careerName } });
  }
}

// ── Автовыбор реализации (§2.2, кеш на уровне модуля) ──────────────────────

let cachedAdapter: StorageAdapter | null = null;
let initPromise: Promise<StorageAdapter> | null = null;

/**
 * Neutralino (exe, init() один раз в try/catch) → IndexedDB (браузер) →
 * Memory (тесты/bun). Выбор кешируется на уровне модуля.
 */
export async function createStorage(): Promise<StorageAdapter> {
  if (cachedAdapter) return cachedAdapter;
  if (initPromise) return initPromise;
  initPromise = (async () => {
    const adapter = await pickStorage();
    cachedAdapter = adapter;
    return adapter;
  })();
  return initPromise;
}

async function pickStorage(): Promise<StorageAdapter> {
  if (typeof window !== 'undefined' && window.Neutralino) {
    try {
      await window.Neutralino.init();
      return new NeutralinoStorage();
    } catch {
      // init провалился — уходим в браузерный фоллбэк
    }
  }
  if (typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined') {
    return new IndexedDBStorage();
  }
  return new MemoryStorage();
}

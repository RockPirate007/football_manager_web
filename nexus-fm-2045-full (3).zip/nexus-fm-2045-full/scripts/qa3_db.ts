/**
 * QA Фаза 3 (Task P3-5) — независимые проверки БД для scripts/qa_phase3.sh.
 * Запуск: bun scripts/qa3_db.ts <команда> <saveId> [аргументы]
 * Вывод: строки «ключ=значение» для сопоставления в bash.
 * Тихий Prisma-клиент (без query-логов). НИЧЕГО не пишет в чужие сейвы,
 * кроме явных команд подготовки сценариев (setconf/forceunhappy) — их вызывает
 * скрипт только на СОБСТВЕННЫХ тест-сейвах.
 */
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient({ log: [] });

/** Срез игроков сейва ДО финальной недели: id goals apps age teamId contractUntil. */
async function preids(saveId: string) {
  const rows = await db.player.findMany({
    where: { saveId },
    select: { id: true, goals: true, apps: true, age: true, teamId: true, contractUntil: true },
  });
  console.log(rows.map((r) => `${r.id} ${r.goals} ${r.apps} ${r.age} ${r.teamId ?? '-'} ${r.contractUntil}`).join('\n'));
}

interface PreRow { id: string; goals: number; apps: number; age: number; teamId: string | null; contractUntil: number }

async function loadPre(file: string): Promise<PreRow[]> {
  const { readFileSync } = await import('node:fs');
  return readFileSync(file, 'utf-8').trim().split(/\n/).filter(Boolean).map((line: string) => {
    const [id, goals, apps, age, teamId, contractUntil] = line.trim().split(/\s+/);
    return {
      id, goals: Number(goals), apps: Number(apps), age: Number(age),
      teamId: teamId === '-' ? null : teamId, contractUntil: Number(contractUntil),
    };
  });
}

/**
 * Инварианты снапшота сезона (§9 №5/№6, строгая монотонная форма — финальная
 * неделя играется в том же запросе, что и переход):
 *  - у каждого пережившего переход игрока есть запись истории сезона;
 *  - запись.age == возраст ДО перехода (снапшот строго ДО старения);
 *  - запись.goals/apps ≥ значений ДО финальной недели (сброс занулил бы);
 *  - запись.teamId == клуб ДО контрактов (снапшот ДО шага 5a/5c);
 *  - avgRating ∈ [45, 100] (×10) при apps > 0; записи новичков финальной недели — нулевые.
 * Пенсионеры (шаг 6) и дренаж (5d) удалены каскадом — исключены из сверки.
 */
async function snapcheck(saveId: string, season: number, file: string) {
  const pre = await loadPre(file);
  const existing = await db.player.findMany({ where: { saveId }, select: { id: true, age: true } });
  const existingIds = new Set(existing.map((p) => p.id));
  const postAgeById = new Map(existing.map((p) => [p.id, p.age]));
  const records = await db.playerSeasonRecord.findMany({
    where: { saveId, season },
    select: { playerId: true, goals: true, apps: true, age: true, teamId: true, avgRating: true },
  });
  const recordById = new Map(records.map((r) => [r.playerId, r]));

  let missing = 0, ageViol = 0, goalsViol = 0, appsViol = 0, teamViol = 0, agingViol = 0;
  for (const p of pre) {
    if (!existingIds.has(p.id)) continue; // пенсионер/дренаж — каскад унёс запись
    const rec = recordById.get(p.id);
    if (!rec) { missing += 1; continue; }
    if (rec.age !== p.age) ageViol += 1;
    if (rec.goals < p.goals) goalsViol += 1;
    if (rec.apps < p.apps) appsViol += 1;
    if ((rec.teamId ?? null) !== p.teamId) teamViol += 1;
    // старение — только клубные игроки (свободные агенты не стареют: шаг 6 идёт по ctxs)
    if (p.teamId !== null) {
      const ageAfter = postAgeById.get(p.id);
      if (ageAfter !== undefined && ageAfter !== p.age + 1) agingViol += 1;
    }
  }
  const preIds = new Set(pre.map((p) => p.id));
  const extra = records.filter((r) => !preIds.has(r.playerId));
  const extraNonZero = extra.filter((r) => r.goals > 0 || r.apps > 0).length;
  const ratingViol = records.filter((r) => r.apps > 0 && (r.avgRating < 45 || r.avgRating > 100)).length;
  const gone = pre.filter((p) => !existingIds.has(p.id)).length;
  console.log(`records=${records.length}`);
  console.log(`players_before=${pre.length}`);
  console.log(`players_gone=${gone}`);
  console.log(`missing=${missing}`);
  console.log(`age_violations=${ageViol}`);
  console.log(`aging_violations=${agingViol}`);
  console.log(`goals_violations=${goalsViol}`);
  console.log(`apps_violations=${appsViol}`);
  console.log(`team_violations=${teamViol}`);
  console.log(`rating_violations=${ratingViol}`);
  console.log(`extra_records=${extra.length}`);
  console.log(`extra_nonzero=${extraNonZero}`);
  console.log(`ok=${missing === 0 && ageViol === 0 && agingViol === 0 && goalsViol === 0 && appsViol === 0 && teamViol === 0 && ratingViol === 0 && extraNonZero === 0}`);
}

/** Удалённые в переходе (пенсии/дренаж): их записи истории исчезли (Cascade). */
async function gonecheck(saveId: string, file: string) {
  const pre = await loadPre(file);
  const existing = await db.player.findMany({ where: { saveId }, select: { id: true } });
  const existingIds = new Set(existing.map((p) => p.id));
  const goneIds = pre.filter((p) => !existingIds.has(p.id)).map((p) => p.id);
  const orphan = await db.playerSeasonRecord.count({
    where: { saveId, playerId: { in: goneIds.length > 0 ? goneIds : ['none'] } },
  });
  console.log(`players_gone=${goneIds.length}`);
  console.log(`records_of_gone=${orphan}`);
  console.log(`ok=${orphan === 0}`);
}

/** Записи истории по сезонам (рост каждый сезон) + всего. */
async function recordsbyseason(saveId: string) {
  const rows = await db.playerSeasonRecord.groupBy({
    by: ['season'], where: { saveId }, _count: { _all: true },
  });
  let total = 0;
  for (const r of rows.sort((a, b) => a.season - b.season)) {
    console.log(`records_s${r.season}=${r._count._all}`);
    total += r._count._all;
  }
  console.log(`records_total=${total}`);
}

/** Контракты клуба игрока: id contractUntil preContractTeamId (для диффа сезонов). */
async function usercontracts(saveId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true, season: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  const rows = await db.player.findMany({
    where: { saveId, teamId: save.teamId },
    select: { id: true, contractUntil: true, preContractTeamId: true, age: true, value: true },
    orderBy: { id: 'asc' },
  });
  console.log(`season=${save.season}`);
  for (const p of rows) {
    console.log(`${p.id} ${p.contractUntil} ${p.preContractTeamId ?? '-'} ${p.age} ${p.value}`);
  }
}

/** Истекающие у клуба игрока (contractUntil === season): id value age. */
async function userexpiring(saveId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true, season: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  const rows = await db.player.findMany({
    where: { saveId, teamId: save.teamId, contractUntil: save.season, preContractTeamId: null },
    select: { id: true, value: true, age: true, firstName: true, lastName: true },
    orderBy: { id: 'asc' },
  });
  console.log(`season=${save.season}`);
  console.log(`expiring=${rows.length}`);
  for (const p of rows) console.log(`${p.id} ${p.value} ${p.age} ${p.firstName} ${p.lastName}`);
}

/** Проверка free-лота истёкшего: source/status/price/TTL по playerId. */
async function freelisting(saveId: string, playerId: string) {
  const l = await db.transferListing.findFirst({
    where: { saveId, playerId }, orderBy: { createdAt: 'desc' },
    select: { source: true, status: true, price: true, expiresAt: true },
  });
  if (!l) { console.log('listing=none'); return; }
  console.log(`source=${l.source}`);
  console.log(`status=${l.status}`);
  console.log(`price=${l.price}`);
  console.log(`expires_at=${l.expiresAt}`);
}

/** Все active free-лоты (№4: переживают регенерацию рынка). */
async function freecount(saveId: string) {
  const active = await db.transferListing.count({ where: { saveId, source: 'free', status: 'active' } });
  const expired = await db.transferListing.count({ where: { saveId, source: 'free', status: 'expired' } });
  console.log(`free_active=${active}`);
  console.log(`free_expired=${expired}`);
}

/** Составы: минимальный размер ИИ-клуба + клуб игрока + свободные агенты. */
async function squads(saveId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true } });
  const teams = await db.team.findMany({
    where: { saveId }, select: { id: true, name: true, isUserTeam: true, players: { select: { id: true } } },
  });
  let minAi = 99, below15 = 0, userSquad = -1;
  for (const t of teams) {
    if (t.isUserTeam) { userSquad = t.players.length; continue; }
    minAi = Math.min(minAi, t.players.length);
    if (t.players.length < 15) {
      below15 += 1;
      console.log(`below15_club=${t.name}:${t.players.length}`);
    }
  }
  const freeAgents = await db.player.count({ where: { saveId, teamId: null } });
  console.log(`ai_min_squad=${minAi}`);
  console.log(`ai_below_15=${below15}`);
  console.log(`user_squad=${userSquad}`);
  console.log(`free_agents=${freeAgents}`);
  console.log(`ok=${minAi >= 15}`);
}

/** Средний avgRating по лиге (№18: [6.4, 7.1] после ≥10 недель) + инварианты рейтинга. */
async function ratings(saveId: string) {
  const rows = await db.player.findMany({
    where: { saveId, teamId: { not: null } },
    select: { ratingApps: true, ratingSum: true, apps: true, isAcademy: true },
  });
  const rated = rows.filter((p) => p.ratingApps > 0);
  const avg = rated.length > 0
    ? rated.reduce((s, p) => s + p.ratingSum / p.ratingApps, 0) / rated.length / 10
    : 0;
  const outOfRange = rated.filter((p) => p.ratingSum / p.ratingApps / 10 < 4.5 || p.ratingSum / p.ratingApps / 10 > 10).length;
  const appsMismatch = rows.filter((p) => (p.ratingApps > 0) !== (p.apps > 0) && !p.isAcademy).length;
  console.log(`rated_players=${rated.length}`);
  console.log(`league_avg_rating=${avg.toFixed(2)}`);
  console.log(`rating_out_of_range=${outOfRange}`);
  console.log(`rating_apps_mismatch=${appsMismatch}`);
  console.log(`ok=${outOfRange === 0}`);
}

/** Академия сезона: набор клуба игрока недели 4. */
async function academy(saveId: string, season: number) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  const mine = await db.player.findMany({
    where: { saveId, teamId: save.teamId, isAcademy: true, contractUntil: season + 2 },
    select: { age: true, ovr: true, potential: true },
  });
  const allSeason = await db.player.findMany({
    where: { saveId, isAcademy: true, contractUntil: season + 2 },
    select: { age: true, ovr: true, potential: true },
  });
  const agesOk = mine.every((p) => p.age === 16 || p.age === 17);
  const ovrOk = mine.every((p) => p.ovr >= 34 && p.ovr <= 52);
  const gems = allSeason.filter((p) => p.potential >= 85).length;
  console.log(`intake_user=${mine.length}`);
  console.log(`intake_all=${allSeason.length}`);
  console.log(`ages_ok=${agesOk}`);
  console.log(`ovr_ok=${ovrOk}`);
  console.log(`gems_all=${gems}`);
}

/** Принудительная подготовка сценария правления (только СВОИ сейвы!). */
async function setconf(saveId: string, conf: string, honeymoon: string, target?: string, place?: string) {
  const data: { boardConfidence: number; honeymoonUntilWeek: number; boardTarget?: string; boardTargetPlace?: number } = {
    boardConfidence: Number(conf),
    honeymoonUntilWeek: Number(honeymoon),
  };
  if (target) data.boardTarget = target;
  if (place) data.boardTargetPlace = Number(place);
  await db.gameSave.update({ where: { id: saveId }, data });
  console.log(`set_conf=${conf}`);
  console.log(`set_honeymoon=${honeymoon}`);
  if (target) console.log(`set_target=${target}:${place}`);
}

/** Сделать до 5 истекающих игроков клуба игрока «недовольными» (Босман p→0.75). */
async function forceunhappy(saveId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true, season: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  const rows = await db.player.findMany({
    where: { saveId, teamId: save.teamId, contractUntil: save.season, preContractTeamId: null },
    select: { id: true, firstName: true, lastName: true },
    orderBy: { ovr: 'desc' },
    take: 5,
  });
  for (const p of rows) {
    await db.player.update({
      where: { id: p.id },
      data: { morale: 10, salary: 100, apps: 0 },
    });
  }
  console.log(`unhappy_set=${rows.length}`);
  for (const p of rows) console.log(`unhappy ${p.id} ${p.firstName} ${p.lastName}`);
}

/** Игроки клуба с предконтрактом (после бросков Босмана). */
async function precontracts(saveId: string) {
  const rows = await db.player.findMany({
    where: { saveId, preContractTeamId: { not: null } },
    select: { id: true, firstName: true, lastName: true, preContractTeamId: true, contractUntil: true },
  });
  console.log(`precontracts=${rows.length}`);
  for (const p of rows) console.log(`pre ${p.id} ${p.firstName} ${p.lastName} ${p.preContractTeamId} ${p.contractUntil}`);
}

/** Поля сейва (сезон/неделя/статус/правление). */
async function saveinfo(saveId: string) {
  const s = await db.gameSave.findUnique({
    where: { id: saveId },
    select: {
      season: true, week: true, status: true, finishReason: true,
      boardTarget: true, boardTargetPlace: true, boardConfidence: true,
      honeymoonUntilWeek: true, careerName: true,
    },
  });
  if (!s) { console.log('save=missing'); return; }
  console.log(`save_career=${s.careerName}`);
  console.log(`save_season=${s.season}`);
  console.log(`save_week=${s.week}`);
  console.log(`save_status=${s.status}`);
  console.log(`save_finish_reason=${s.finishReason ?? 'null'}`);
  console.log(`save_board_target=${s.boardTarget ?? 'null'}`);
  console.log(`save_board_target_place=${s.boardTargetPlace ?? 'null'}`);
  console.log(`save_board_confidence=${s.boardConfidence}`);
  console.log(`save_honeymoon_until=${s.honeymoonUntilWeek ?? 'null'}`);
}

/** Finance-записи сезона по категориям (призовые/премия правления/трансферы). */
async function finances(saveId: string, season: number) {
  const rows = await db.financeRecord.findMany({
    where: { saveId, season },
    select: { kind: true, category: true, amount: true, description: true },
  });
  const byCat = new Map<string, number>();
  for (const r of rows) byCat.set(r.category, (byCat.get(r.category) ?? 0) + r.amount);
  console.log(`finance_records=${rows.length}`);
  for (const [cat, amount] of byCat) console.log(`finance_${cat}=${amount}`);
}

/** Всего записей истории сейва. */
async function recordscount(saveId: string) {
  console.log(`records_total=${await db.playerSeasonRecord.count({ where: { saveId } })}`);
}

/** Сделать n игроков клуба игрока с contractUntil=season+1 истекающими (сезон S). */
async function makeexpiring(saveId: string, nStr: string) {
  const n = Number(nStr || 2);
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true, season: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  // Сначала молодые (≤30, чтобы истечение не превратилось в пенсию 35+),
  // любой контракт длиннее сезона; если таких нет — любой не-предконтрактный.
  let rows = await db.player.findMany({
    where: { saveId, teamId: save.teamId, contractUntil: { gt: save.season }, preContractTeamId: null, age: { lte: 30 } },
    select: { id: true }, orderBy: { age: 'asc' }, take: n,
  });
  if (rows.length === 0) {
    rows = await db.player.findMany({
      where: { saveId, teamId: save.teamId, contractUntil: { gt: save.season }, preContractTeamId: null },
      select: { id: true }, orderBy: { age: 'asc' }, take: n,
    });
  }
  for (const p of rows) {
    await db.player.update({ where: { id: p.id }, data: { contractUntil: save.season } });
  }
  console.log(`made_expiring=${rows.length}`);
  for (const p of rows) console.log(`expiring_forced ${p.id}`);
}
async function playerinfo(saveId: string, playerId: string) {
  const p = await db.player.findFirst({
    where: { id: playerId, saveId },
    select: { teamId: true, contractUntil: true, preContractTeamId: true, firstName: true, lastName: true },
  });
  if (!p) { console.log('player=missing'); return; }
  console.log(`player_team=${p.teamId ?? 'null'}`);
  console.log(`player_contract_until=${p.contractUntil}`);
  console.log(`player_pre_contract=${p.preContractTeamId ?? 'null'}`);
  console.log(`player_name=${p.firstName} ${p.lastName}`);
}

/** Поиск новостей по подстроке (Босман/академия/правление). */
async function newssearch(saveId: string, substring: string) {
  const rows = await db.newsItem.findMany({
    where: { saveId, message: { contains: substring } },
    select: { season: true, week: true, type: true, message: true },
    orderBy: { id: 'asc' },
  });
  console.log(`news_found=${rows.length}`);
  for (const n of rows.slice(0, 5)) console.log(`news S${n.season}W${n.week} [${n.type}] ${n.message}`);
}

async function main() {
  const [cmd, saveId, ...rest] = process.argv.slice(2);
  if (!cmd || !saveId) {
    console.error('usage: qa3_db.ts <preids|snapcheck|gonecheck|recordsbyseason|usercontracts|userexpiring|freelisting|freecount|squads|ratings|academy|setconf|forceunhappy|precontracts|save|finances|records|playerinfo> <saveId> [args]');
    process.exit(1);
  }
  switch (cmd) {
    case 'preids': await preids(saveId); break;
    case 'snapcheck': await snapcheck(saveId, Number(rest[0] ?? 1), rest[1] ?? ''); break;
    case 'gonecheck': await gonecheck(saveId, rest[0] ?? ''); break;
    case 'recordsbyseason': await recordsbyseason(saveId); break;
    case 'usercontracts': await usercontracts(saveId); break;
    case 'userexpiring': await userexpiring(saveId); break;
    case 'freelisting': await freelisting(saveId, rest[0] ?? ''); break;
    case 'freecount': await freecount(saveId); break;
    case 'squads': await squads(saveId); break;
    case 'ratings': await ratings(saveId); break;
    case 'academy': await academy(saveId, Number(rest[0] ?? 1)); break;
    case 'setconf': await setconf(saveId, rest[0] ?? '55', rest[1] ?? '8', rest[2], rest[3]); break;
    case 'forceunhappy': await forceunhappy(saveId); break;
    case 'precontracts': await precontracts(saveId); break;
    case 'save': await saveinfo(saveId); break;
    case 'finances': await finances(saveId, Number(rest[0] ?? 1)); break;
    case 'records': await recordscount(saveId); break;
    case 'playerinfo': await playerinfo(saveId, rest[0] ?? ''); break;
    case 'makeexpiring': await makeexpiring(saveId, rest[0] ?? '2'); break;
    case 'newssearch': await newssearch(saveId, rest[0] ?? ''); break;
    default:
      console.error(`unknown command: ${cmd}`);
      process.exit(1);
  }
  await db.$disconnect();
}

main();

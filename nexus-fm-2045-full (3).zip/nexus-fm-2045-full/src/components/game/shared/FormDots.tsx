import { cn } from '@/lib/utils';
import type { FormResult } from '@/lib/game/types';

/** Цвета NEXUS FM 2045: В — неон-зелёный, Н — стальной (как в theme.py), П — красный. */
const DOT_STYLE: Record<FormResult, string> = {
  W: 'bg-[#22C55E]',
  D: 'bg-[#7B8CA3]',
  L: 'bg-[#EF4444]',
};

const DOT_TITLE: Record<FormResult, string> = {
  W: 'Победа',
  D: 'Ничья',
  L: 'Поражение',
};

/** 5 точек последних матчей (В — зелёная, Н — жёлтая, П — красная). */
export function FormDots({
  form,
  className,
}: {
  form: FormResult[];
  className?: string;
}) {
  const last5 = form.slice(-5);
  const padded: (FormResult | null)[] = [
    ...Array(Math.max(0, 5 - last5.length)).fill(null),
    ...last5,
  ];
  return (
    <span className={cn('inline-flex items-center gap-1', className)} aria-label="Форма команды">
      {padded.map((r, i) => (
        <span
          key={i}
          className={cn('size-2 rounded-full', r ? DOT_STYLE[r] : 'bg-muted')}
          title={r ? DOT_TITLE[r] : 'Ещё не сыграно'}
        />
      ))}
    </span>
  );
}

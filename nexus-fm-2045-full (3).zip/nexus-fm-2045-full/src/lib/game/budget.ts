/**
 * Модуль 5 «Финансы, инфраструктура, руководство»: бюджеты правления.
 * Трансферный бюджет (грант сезона + траты/пополнения) и зарплатный потолок.
 *
 * Чистые функции (без Prisma/rng — детерминизм): вызываются из engine/week.ts
 * (сезонный пересбор), engine/career.ts (инициализация) и engine/router.ts
 * (миграция легаси, списание при покупке, гвард ведомости при подписании).
 */

import {
  BUDGET_CARRYOVER_SHARE, BUDGET_CONFIDENCE_BONUS, BUDGET_PRIZE_SHARE,
  BUDGET_TV_SHARE, BUDGET_WAGE_RATIO, SALE_TO_BUDGET_RATIO,
  TRANSFER_BUDGET_RATIO, TV_MONEY_BY_LEAGUE, WAGE_BUDGET_HEADROOM,
  WAGE_BUDGET_SLACK, type LeagueCode,
} from './constants';
import { SPONSOR_BASE } from './constants';

/** Ленивая миграция легаси-сейвов: transferBudget = floor(balance × 0.4). */
export function migrateTransferBudget(balance: number, current: number): number {
  if (current > 0) return current;
  return Math.max(0, Math.floor(balance * TRANSFER_BUDGET_RATIO));
}

/** Ленивая миграция легаси: wageBudget = ceil(weeklyWages × 1.12), мин 1€. */
export function migrateWageBudget(weeklyWages: number, current: number): number {
  if (current > 0) return current;
  return Math.max(1, Math.ceil(weeklyWages * WAGE_BUDGET_HEADROOM));
}

/**
 * Трансферный грант нового сезона:
 *   TV_лиги × leagueWeeks × 0.30 (доля ТВ-потока)
 *   + призовые за место × 0.5 (доля призовых)
 *   + перенос остатка прошлого бюджета × 0.5
 *   + confidence ≥ 70 → ×1.15 (правление верит в проект).
 * Округление до €1 000. Минимум — €500 000 (правление не даёт сесть без денег).
 */
export function seasonTransferBudgetOf(args: {
  league: LeagueCode;
  leagueWeeks: number;
  place: number;
  teamCount: number;
  prize: number;
  prevBudgetLeft: number;
  confidence: number;
}): number {
  const tv = TV_MONEY_BY_LEAGUE[args.league] ?? TV_MONEY_BY_LEAGUE.RPL;
  // средний ТВ-множитель места (квартали) — как tvIncomeOf, но без округления
  const q1 = Math.ceil(args.teamCount / 4);
  const q3 = Math.ceil((args.teamCount * 3) / 4);
  const placeMult = args.place <= q1 ? 1.3 : args.place <= q3 ? 1.0 : 0.85;
  const grant =
    tv * placeMult * args.leagueWeeks * BUDGET_TV_SHARE
    + args.prize * BUDGET_PRIZE_SHARE
    + Math.max(0, args.prevBudgetLeft) * BUDGET_CARRYOVER_SHARE;
  const withConf =
    args.confidence >= 70 ? grant * (1 + BUDGET_CONFIDENCE_BONUS) : grant;
  return Math.max(500_000, Math.round(withConf / 1_000) * 1_000);
}

/**
 * Зарплатный потолок нового сезона:
 *   устойчивый доход = (ТВ-лиги + спонсор) × leagueWeeks / leagueWeeks × 0.65
 *   (т.е. 65% от недельного устойчивого потока лиги)
 *   НО не меньше текущей ведомости × 1.12 (правление даёт расти, но не режет
 *   действующие контракты) и не больше × 2.0 (аутсайдер не получает карт-бланш).
 * Округление до €100.
 */
export function seasonWageBudgetOf(args: {
  league: LeagueCode;
  weeklyWagesNow: number;
}): number {
  const tv = TV_MONEY_BY_LEAGUE[args.league] ?? TV_MONEY_BY_LEAGUE.RPL;
  const sustainable = (tv + SPONSOR_BASE) * BUDGET_WAGE_RATIO;
  const floorW = Math.ceil(args.weeklyWagesNow * WAGE_BUDGET_HEADROOM);
  const cap = Math.max(floorW, Math.ceil(args.weeklyWagesNow * 2.0));
  const value = Math.min(cap, Math.max(sustainable, floorW));
  return Math.max(100, Math.round(value / 100) * 100);
}

/** Пополнение трансферного бюджета при продаже: 80% суммы сделки. */
export function transferBudgetAfterSale(budget: number, salePrice: number): number {
  return budget + Math.round(salePrice * SALE_TO_BUDGET_RATIO);
}

/** Списание трансферного бюджета при покупке (не ниже нуля). */
export function transferBudgetAfterBuy(budget: number, price: number): number {
  return Math.max(0, budget - price);
}

/**
 * Гвард подписания (POST /market/buy, M5): новая ведомость с учётом
 * подписываемой зарплаты не должна превышать бюджет × 1.05 (5% люфта —
 * агенты иногда выжимают чуть больше; правление это прощает).
 */
export function wageBudgetAllows(args: {
  squadWages: number;
  signingSalary: number;
  wageBudget: number;
}): boolean {
  return args.squadWages + args.signingSalary <= args.wageBudget * WAGE_BUDGET_SLACK;
}

'use client';

import { useEffect, useMemo, useState, type ReactElement } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity, BookOpen, Car, ChevronDown, Construction, Crown, Dumbbell, GraduationCap, HardHat,
  Hotel, Landmark, Loader2, Radar, Stethoscope, Store, Wallet,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle,
} from '@/components/ui/sheet';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { BUILDING_UPKEEP_RATIO } from '@/engine/buildings';
import { availableStadiumOptions, stadiumDaysOf } from '@/lib/game/stadium';
import { STADIUM_MAX_CAPACITY } from '@/lib/game/constants';
import type { BuildingCardDTO, TeamDTO } from '@/lib/game/types';
import { formatMoney, formatMoneyExact } from '@/lib/game/format';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Иконки плиток (§3.6 + Модуль 5: scoutcenter Radar). */
const BUILDING_ICONS: Record<string, typeof Dumbbell> = {
  training: Dumbbell,
  medical: Stethoscope,
  fitness: Activity,
  academy: GraduationCap,
  hotel: Hotel,
  parking: Car,
  fanshop: Store,
  vip: Crown,
  scoutcenter: Radar,
};

/** Человекочитаемые эффекты уровня L (§3.2 — формулы каталога). */
function effectLines(id: string, level: number): string[] {
  switch (id) {
    case 'training':
      return [`Рост на тренировках: ×${(1 + 0.04 * level).toFixed(2)}`];
    case 'medical':
      return [
        `Длительность травм: −${10 * level}%`,
        `Риск травм (матч и тренировки): −${4 * level}%`,
      ];
    case 'fitness':
      return [`Недельное восстановление: +${(0.4 * level).toFixed(1)} сверх +8`];
    case 'academy':
      return [
        `Доп. игроки в наборе академии: +${[0, 0, 0, 1, 1, 2][Math.min(5, Math.max(0, level))]}`,
        `Бонус потенциала выпускников: +${(0.8 * level).toFixed(1)} (кап 93)`,
        `Шанс «жемчужины»: ×${(1 + 0.15 * level).toFixed(2)}`,
      ];
    case 'hotel':
      return [
        `Восстановление в неделю с 2 матчами: +${(0.6 * level).toFixed(1)}`,
        `Восстановление в неделю евроматча: +${(0.3 * level).toFixed(1)}`,
      ];
    case 'parking':
      return [`Билетная выручка домашних матчей: +${(1.5 * level).toFixed(1)}%`];
    case 'fanshop':
      return [`Доход мерчандайза: ${level > 0 ? formatMoneyExact(30_000 * level) : '€0'} в неделю`];
    case 'vip':
      return [
        `Доплата за домашний матч: ${level > 0 ? formatMoneyExact(160_000 * level) : '€0'}`,
        `Престиж менеджера при достройке уровня: +${2 * level}`,
      ];
    // ── Модуль 5: скаут-центр — синергия с туманом войны (Модуль 3) ──
    case 'scoutcenter':
      return [
        `Скорость изучения игроков: ×${(1 + 0.06 * level).toFixed(2)}`,
        `Слоты наблюдения: ${2 + [0, 0, 0, 1, 1, 2][Math.min(5, Math.max(0, level))]} базовых (L3 +1, L5 +2)`,
      ];
    default:
      return [];
  }
}

/** Desktop (lg) — панель сбоку карточкой; мобайл — нижний Sheet (§3.6). */
function useIsDesktop(): boolean {
  const [isDesktop, setIsDesktop] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);
  return isDesktop;
}

/** Сегменты уровня 0–5 (L5 — золотая рамка карточки). */
function LevelSegments({ level, gold }: { level: number; gold: boolean }) {
  return (
    <span className="flex items-center gap-1" aria-label={`Уровень ${level} из 5`}>
      {Array.from({ length: 5 }, (_, i) => (
        <span
          key={i}
          className={cn(
            'h-1.5 w-3 rounded-full',
            i < level
              ? gold
                ? 'bg-[#D4AF37]'
                : 'bg-primary'
              : 'bg-border',
          )}
        />
      ))}
    </span>
  );
}

/** Плитка здания: пусто / строится N дн. / ур. N (§3.6). */
function BuildingTile({
  card,
  absoluteDay,
  selected,
  onSelect,
  index,
}: {
  card: BuildingCardDTO;
  absoluteDay: number;
  selected: boolean;
  onSelect: () => void;
  index: number;
}) {
  const Icon = BUILDING_ICONS[card.id] ?? Dumbbell;
  const maxed = card.level >= 5;
  const endsAt = card.upgradeEndsAtDay;
  const building = endsAt !== null;
  const remaining = endsAt !== null ? Math.max(0, endsAt - absoluteDay) : 0;
  const total = card.daysNext ?? 0;
  const progress = building && total > 0
    ? Math.min(100, Math.max(0, ((total - remaining) / total) * 100))
    : 0;

  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, delay: Math.min(index * 0.04, 0.3) }}
      onClick={onSelect}
      aria-label={`${card.name}${building ? `, строится, осталось ${remaining} дн.` : `, уровень ${card.level}`}`}
      className={cn(
        'flex min-h-[44px] w-full flex-col gap-2.5 rounded-lg border p-3.5 text-left transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40',
        maxed
          ? 'border-[#D4AF37]/50 bg-[#D4AF37]/5'
          : 'border-border/70 bg-card hover:border-primary/40 hover:bg-primary/5',
        selected && !maxed && 'border-primary/60 bg-primary/10',
        selected && maxed && 'border-[#D4AF37]',
        card.level === 0 && !building && 'opacity-80',
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <Icon
          className={cn(
            'size-6 shrink-0',
            card.level === 0 && !building ? 'text-muted-foreground/60' : 'text-primary',
            maxed && 'text-[#D4AF37]',
          )}
          aria-hidden
        />
        {maxed ? (
          <Badge className="border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[10px] text-[#D4AF37]">
            Макс.
          </Badge>
        ) : building ? (
          <Badge variant="secondary" className="gap-1 text-[10px] tabular">
            <Construction className="size-3" aria-hidden />
            {remaining} дн.
          </Badge>
        ) : (
          <span className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
            {card.level === 0 ? 'Пусто' : `Ур. ${card.level}`}
          </span>
        )}
      </div>

      <span className="text-xs font-semibold leading-tight">{card.name}</span>

      {building ? (
        <div className="space-y-1">
          <Progress value={progress} className="h-1.5" aria-hidden />
          <span className="text-[10px] text-muted-foreground">
            Строится уровень {card.level + 1}
          </span>
        </div>
      ) : (
        <div className="flex items-center justify-between gap-2">
          <LevelSegments level={card.level} gold={maxed} />
          <span className="tabular text-[10px] text-muted-foreground">
            {formatMoney(card.upkeepWeekly)}/нед
          </span>
        </div>
      )}
    </motion.button>
  );
}

/** Панель деталей/апгрейда (общая для Sheet-мобайл и боковой карточки desktop). */
function BuildingPanel({
  card,
  absoluteDay,
  balance,
  busy,
  upgrading,
  onUpgrade,
}: {
  card: BuildingCardDTO;
  absoluteDay: number;
  balance: number;
  busy: boolean;
  upgrading: boolean;
  onUpgrade: () => void;
}) {
  const Icon = BUILDING_ICONS[card.id] ?? Dumbbell;
  const maxed = card.level >= 5;
  const endsAt = card.upgradeEndsAtDay;
  const building = endsAt !== null;
  const remaining = endsAt !== null ? Math.max(0, endsAt - absoluteDay) : 0;
  const total = card.daysNext ?? 0;
  const progress = building && total > 0
    ? Math.min(100, Math.max(0, ((total - remaining) / total) * 100))
    : 0;
  const nextUpkeep = card.priceNext !== null
    ? Math.round(card.priceNext * BUILDING_UPKEEP_RATIO) // содержание L+1 = 0.25% × price(L+1)
    : 0;
  const missing = card.priceNext !== null ? card.priceNext - balance : 0;
  const canBuy = !maxed && !building && !busy && card.priceNext !== null && missing <= 0 && !upgrading;
  const nextEffects = !maxed && !building ? effectLines(card.id, card.level + 1) : [];

  return (
    <div className="flex flex-col gap-4">
      {/* Заголовок */}
      <div className="flex items-start gap-3">
        <div
          className={cn(
            'flex size-11 shrink-0 items-center justify-center rounded-lg border',
            maxed ? 'border-[#D4AF37]/40 bg-[#D4AF37]/10' : 'border-border/70 bg-secondary/60',
          )}
        >
          <Icon className={cn('size-5', maxed ? 'text-[#D4AF37]' : 'text-primary')} aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-sm font-semibold leading-tight">{card.name}</h3>
            {maxed ? (
              <Badge className="border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[10px] text-[#D4AF37]">
                Уровень 5
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] tabular">
                Уровень {card.level}
              </Badge>
            )}
          </div>
          <div className="mt-1.5 flex items-center gap-2">
            <LevelSegments level={card.level} gold={maxed} />
            <span className="tabular text-[10px] text-muted-foreground">
              {card.level > 0 ? `содержание ${formatMoneyExact(card.upkeepWeekly)}/нед` : 'содержания нет'}
            </span>
          </div>
        </div>
      </div>

      {/* Текущие эффекты */}
      <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
        <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Текущие эффекты
        </p>
        {card.level === 0 ? (
          <p className="text-xs text-muted-foreground">
            Здание не построено — эффектов нет. Первый уровень открывает бонусы клуба.
          </p>
        ) : (
          <ul className="space-y-1">
            {effectLines(card.id, card.level).map((line) => (
              <li key={line} className="flex items-start gap-1.5 text-xs">
                <span className="mt-0.5 text-primary" aria-hidden>•</span>
                <span>{line}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Стройка / апгрейд */}
      {building ? (
        <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
          <div className="mb-2 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <HardHat className="size-3.5 text-primary" aria-hidden />
              Строится уровень {card.level + 1}
            </span>
            <span className="tabular text-muted-foreground">осталось {remaining} дн.</span>
          </div>
          <Progress value={progress} className="h-2" aria-label={`Прогресс стройки: ${Math.round(progress)}%`} />
          <p className="mt-2 text-[11px] text-muted-foreground">
            Уровень откроется автоматически — таймер тикает при прогоне недель.
            Ускорить или отменить стройку нельзя.
          </p>
        </div>
      ) : maxed ? (
        <div className="rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/5 p-3 text-xs">
          Здание максимального уровня — дальше развивать нельзя.
        </div>
      ) : (
        <div className="space-y-3 rounded-lg border border-border/60 bg-card p-3">
          <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            {card.level === 0 ? 'Постройка' : `Апгрейд до уровня ${card.level + 1}`}
          </p>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded bg-secondary/50 p-2">
              <div className="text-[10px] text-muted-foreground">Цена</div>
              <div className="tabular text-xs font-bold text-primary">
                {formatMoneyExact(card.priceNext ?? 0)}
              </div>
            </div>
            <div className="rounded bg-secondary/50 p-2">
              <div className="text-[10px] text-muted-foreground">Срок</div>
              <div className="tabular text-xs font-bold">{card.daysNext ?? 0} дн.</div>
            </div>
            <div className="rounded bg-secondary/50 p-2">
              <div className="text-[10px] text-muted-foreground">Содержание</div>
              <div className="tabular text-xs font-bold">
                {formatMoney(nextUpkeep)}/нед
              </div>
            </div>
          </div>

          {nextEffects.length > 0 ? (
            <div>
              <p className="mb-1 text-[10px] text-muted-foreground">После постройки:</p>
              <ul className="space-y-1">
                {nextEffects.map((line) => (
                  <li key={line} className="flex items-start gap-1.5 text-xs text-muted-foreground">
                    <span className="mt-0.5 text-primary" aria-hidden>•</span>
                    <span>{line}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {busy ? (
            <p className="text-xs text-[#FACC15]">
              У клуба уже идёт стройка — одновременно можно строить только одно здание.
            </p>
          ) : null}

          <Button
            type="button"
            size="lg"
            className="min-h-11 w-full font-semibold"
            disabled={!canBuy}
            onClick={onUpgrade}
          >
            {upgrading ? (
              <>
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Оформляем…
              </>
            ) : maxed ? (
              'Максимальный уровень'
            ) : busy ? (
              'Уже идёт стройка'
            ) : missing > 0 ? (
              `Не хватает ${formatMoney(missing)}`
            ) : (
              card.level === 0 ? 'Построить' : `Построить уровень ${card.level + 1}`
            )}
          </Button>
          <p className="text-[10px] text-muted-foreground">
            Оплата списывается с баланса клуба (не с трансферного бюджета). Одна стройка на клуб за раз.
          </p>
        </div>
      )}
    </div>
  );
}

/**
 * Модуль 5 «Инфраструктура 2.0»: карточка стадиона клуба игрока.
 * Вместимость + расширение блоками трибун (+3 000 / +5 000 / +8 000 мест):
 * цена растёт с размером стадиона, стройка 56/70/84 дня, лимит 90 000 мест.
 * Расширение НЕ блокирует стройку зданий (отдельные бригады) и наоборот.
 */
function StadiumCard({
  myTeam,
  balance,
  absoluteDay,
  expanding,
  onExpand,
}: {
  myTeam: TeamDTO;
  balance: number;
  absoluteDay: number;
  expanding: boolean;
  onExpand: (seats: 3000 | 5000 | 8000) => void;
}) {
  const capacity = myTeam.stadiumCapacity;
  const pending = myTeam.stadiumPending;
  const endsAt = myTeam.stadiumUpgradeEndsAtDay;
  const building = pending > 0 && endsAt !== null;
  const maxed = capacity >= STADIUM_MAX_CAPACITY;
  const options = maxed || building ? [] : availableStadiumOptions(capacity);

  const total = building ? stadiumDaysOf(pending as 3000 | 5000 | 8000) : 0;
  const remaining = endsAt !== null ? Math.max(0, endsAt - absoluteDay) : 0;
  const progress = building && total > 0
    ? Math.min(100, Math.max(0, ((total - remaining) / total) * 100))
    : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22 }}
      className="rounded-lg border border-border/70 bg-card p-4"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-lg border border-border/70 bg-secondary/60">
            <Landmark className="size-5 text-primary" aria-hidden />
          </div>
          <div>
            <h3 className="text-sm font-semibold leading-tight">Стадион</h3>
            <p className="mt-0.5 text-[11px] text-muted-foreground">
              {capacity.toLocaleString('ru-RU')} мест · билетная выручка домашних матчей
            </p>
          </div>
        </div>
        {maxed ? (
          <Badge className="border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[10px] text-[#D4AF37]">
            Максимум
          </Badge>
        ) : building ? (
          <Badge variant="secondary" className="gap-1 text-[10px] tabular">
            <Construction className="size-3" aria-hidden />
            {remaining} дн.
          </Badge>
        ) : null}
      </div>

      {building ? (
        <div className="mt-3 rounded-lg border border-primary/30 bg-primary/5 p-3">
          <div className="mb-2 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <HardHat className="size-3.5 text-primary" aria-hidden />
              Строятся трибуны: +{pending.toLocaleString('ru-RU')} мест
            </span>
            <span className="tabular text-muted-foreground">осталось {remaining} дн.</span>
          </div>
          <Progress value={progress} className="h-2" aria-label={`Прогресс стройки стадиона: ${Math.round(progress)}%`} />
          <p className="mt-2 text-[11px] text-muted-foreground">
            После завершения вместимость вырастет до {(capacity + pending).toLocaleString('ru-RU')} мест —
            новость придёт в ленту дашборда.
          </p>
        </div>
      ) : maxed ? (
        <p className="mt-3 rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/5 p-3 text-xs">
          Стадион достиг максимальной вместимости ({STADIUM_MAX_CAPACITY.toLocaleString('ru-RU')} мест) —
          дальше расти некуда.
        </p>
      ) : (
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {options.map((o) => {
            const missing = o.price - balance;
            const canBuy = !expanding && missing <= 0;
            return (
              <div
                key={o.seats}
                className="flex flex-col gap-2 rounded-lg border border-border/60 bg-secondary/40 p-2.5"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-xs font-bold tabular">
                    +{o.seats.toLocaleString('ru-RU')}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {(capacity + o.seats).toLocaleString('ru-RU')} всего
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                  <span className="tabular font-semibold text-primary">
                    {formatMoneyExact(o.price)}
                  </span>
                  <span className="tabular">{o.days} дн.</span>
                </div>
                <Button
                  type="button"
                  size="sm"
                  className="min-h-9 w-full text-xs font-semibold"
                  disabled={!canBuy}
                  onClick={() => onExpand(o.seats)}
                >
                  {expanding ? (
                    <>
                      <Loader2 className="size-3.5 animate-spin" aria-hidden />
                      Оформляем…
                    </>
                  ) : missing > 0 ? (
                    `Не хватает ${formatMoney(missing)}`
                  ) : (
                    'Начать стройку'
                  )}
                </Button>
              </div>
            );
          })}
          <p className="text-[10px] text-muted-foreground sm:col-span-3">
            Оплата с баланса клуба (не с трансферного бюджета). Чем больше стадион — тем
            дороже каждый следующий блок. Цена места: €900 × (1 + вместимость / 100 000).
          </p>
        </div>
      )}
    </motion.div>
  );
}

/** Экран «Территория» (D-5 §3.6 + Модуль 5): стадион, сетка 9 зданий, панель апгрейда. */
export function TerritoryScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const loading = useGameStore((s) => s.loading);
  const upgradeBuilding = useGameStore((s) => s.upgradeBuilding);
  const expandStadium = useGameStore((s) => s.expandStadium);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [legendOpen, setLegendOpen] = useState(false);
  const isDesktop = useIsDesktop();

  const { save, myTeam } = snapshot;
  const buildings = myTeam.buildings;
  const absoluteDay =
    (save.season - 1) * save.totalWeeks * 7 + (save.week - 1) * 7;
  const totalUpkeep = useMemo(
    () => buildings.reduce((s, b) => s + b.upkeepWeekly, 0),
    [buildings],
  );
  const busy = buildings.some((b) => b.upgradeEndsAtDay !== null);
  const selected = buildings.find((b) => b.id === selectedId) ?? null;

  const select = (id: string): void => {
    setSelectedId((prev) => (prev === id ? null : id));
  };

  const panel = selected ? (
    <BuildingPanel
      card={selected}
      absoluteDay={absoluteDay}
      balance={save.balance}
      busy={busy}
      upgrading={loading}
      onUpgrade={() => {
        void upgradeBuilding(selected.id);
      }}
    />
  ) : null;

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Территория"
        subtitle={`${myTeam.name} · стадион + 9 зданий, уровни 0–5`}
        action={
          <div className="flex items-center gap-1.5">
            <Badge
              variant="outline"
              className="gap-1 text-[11px] tabular"
              title="Суммарное еженедельное содержание всех зданий"
            >
              <Wallet className="size-3.5" aria-hidden />
              {totalUpkeep > 0 ? `${formatMoney(totalUpkeep)}/нед` : 'без содержания'}
            </Badge>
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="size-11"
              onClick={() => setLegendOpen((v) => !v)}
              aria-expanded={legendOpen}
              aria-label="Как работает территория"
              title="Как это работает"
            >
              <ChevronDown
                className={cn('size-4 transition-transform', legendOpen && 'rotate-180')}
                aria-hidden
              />
            </Button>
          </div>
        }
      />

      {/* Легенда */}
      <AnimatePresence initial={false}>
        {legendOpen ? (
          <motion.div
            key="legend"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="flex items-start gap-2.5 rounded-lg border border-border/70 bg-card p-3.5 text-xs text-muted-foreground">
              <BookOpen className="size-4 shrink-0 text-primary" aria-hidden />
              <div className="space-y-1">
                <p>
                  Здания дают клубу постоянные бонусы: рост тренировок, восстановление,
                  защиту от травм, качество академии, скаутинг (снимает туман войны
                  быстрее) и доходы (билеты, фан-шоп, VIP-ложи).
                </p>
                <p>
                  Стройка оплачивается с баланса клуба и занимает время — уровень растёт
                  по завершении. Одновременно может идти только одна стройка здания
                  (расширение стадиона идёт независимо — отдельная бригада).
                </p>
                <p>
                  Содержание — 0.25% от стоимости каждого здания — списывается каждую
                  неделю. Тап по плитке открывает детали и апгрейд.
                </p>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* ── Модуль 5: стадион — вместимость и расширение трибун ── */}
      <StadiumCard
        myTeam={myTeam}
        balance={save.balance}
        absoluteDay={absoluteDay}
        expanding={loading}
        onExpand={(seats) => {
          void expandStadium(seats);
        }}
      />

      {/* Сетка зданий: 9 плиток — мобайл 2×5, desktop 3×3 (§3.6) + боковая карточка desktop */}
      <div className="lg:grid lg:grid-cols-[1fr_360px] lg:items-start lg:gap-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {buildings.map((card, i) => (
            <BuildingTile
              key={card.id}
              card={card}
              absoluteDay={absoluteDay}
              selected={selectedId === card.id}
              onSelect={() => select(card.id)}
              index={i}
            />
          ))}
        </div>

        {/* Desktop: боковая карточка */}
        <div className="hidden lg:block">
          <AnimatePresence mode="wait">
            {panel ? (
              <motion.div
                key={selected?.id ?? 'selected'}
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                transition={{ duration: 0.18 }}
                className="rounded-lg border border-border/70 bg-card p-4"
              >
                {panel}
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center gap-2 rounded-lg border border-dashed border-border/60 p-8 text-center"
              >
                <BuildingIconHint />
                <p className="text-xs text-muted-foreground">
                  Выберите здание слева — детали, эффекты и апгрейд появятся здесь.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Мобайл: нижний Sheet с деталями (§3.6) */}
      {!isDesktop ? (
        <Sheet open={selected !== null} onOpenChange={(open) => !open && setSelectedId(null)}>
          <SheetContent side="bottom" className="pb-6">
            <SheetHeader>
              <SheetTitle className="sr-only">Детали здания</SheetTitle>
              <SheetDescription className="sr-only">
                Панель деталей и апгрейда выбранного здания территории клуба.
              </SheetDescription>
            </SheetHeader>
            {panel}
          </SheetContent>
        </Sheet>
      ) : null}
    </div>
  );
}

/** Заглушка-иконка для пустой боковой панели desktop. */
function BuildingIconHint(): ReactElement {
  return <HardHat className="size-8 text-muted-foreground/50" aria-hidden />;
}

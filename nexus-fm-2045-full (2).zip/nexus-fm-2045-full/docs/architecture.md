# Техническая архитектура — веб-игра «Футбольный Менеджер»

> **Task ID:** 2-b · **Автор:** Агент-Архитектор · **Дата:** 2026
> **Основа:** docs/research-football-manager.md (Task 2-a) — архитектура строго следует его рекомендациям: гибрид OSM (структура) + Top Eleven (атрибуты), 8 экранов, тёмная стадионная палитра, механика Пуассона, модель OSM «тур за клик».
> **Статус:** проект готов к реализации без дополнительных решений. Все формулы, типы, имена файлов и константы зафиксированы.

---

## 0. Сводка и незыблемые принципы

| Решение | Значение |
|---|---|
| Тип приложения | SPA: единственный видимый маршрут `/` (src/app/page.tsx), все «экраны» — вкладки внутри страницы |
| Frontend | Next.js 16 (App Router) + React 19, TypeScript 5 strict, клиентские компоненты |
| UI | Tailwind CSS 4 + shadcn/ui (New York, уже в src/components/ui) + lucide-react |
| Состояние клиента | Zustand (src/lib/store.ts) |
| Бэкенд | API Routes в src/app/api/game/* (серверные), валидация zod |
| БД | SQLite через Prisma (клиент `db` из '@/lib/db', файл db/custom.db) |
| Игровая логика | Чистые TS-модули в src/lib/game/* — НЕ зависит от React/Prisma (принимают/возвращают POJO) |
| z-ai-web-dev-sdk | **НЕ используется** (в игре нет AI-фич; все имена/названия — готовые массивы в src/lib/game/data.ts) |
| Единица времени | 1 «неделя» = 1 тур = 1 матч у каждой команды. Сезон = 30 туров (16 команд, 2 круга) |
| Деньги | Int, евро, без копеек (€1 = 1). В UI форматирование `€1.2M` / `€450K` |
| Случайность | Детерминированный seeded RNG (mulberry32) — матчи воспроизводимы, тестируемы |
| Единственный сейв | В БД живёт один активный GameSave (MVP, один игрок). «Новая игра» удаляет старый |

**Общие правила кода:**
- Все числа игрового баланса — только из `src/lib/game/constants.ts` (волшебных чисел в коде нет).
- SQLite не поддерживает enum и списки → в Prisma только скалярные поля; JSON-структуры хранятся строками (поля `events`, `stats`, `lineup`, `bench`).
- Правила UI-темы: тёмно-зелёная «стадионная» палитра (раздел 9), **запрещены синие/индиго**.
- Числа в таблицах — `font-variant-numeric: tabular-nums`.
- Все строки интерфейса — на русском.

---

## 1. Обзор системы

```
┌─────────────────────────── Браузер (маршрут /) ───────────────────────────┐
│  page.tsx ('use client')                                                  │
│  ├─ GameShell (верхнее меню desktop / нижний таб-бар mobile)              │
│  ├─ StartScreen → выбор клуба                                             │
│  └─ Экраны: Dashboard · Squad · Tactics · Match · League · Transfers ·    │
│             Finances        (переключение через Zustand `activeTab`)      │
│  Zustand store (src/lib/store.ts): activeTab, phase, snapshot, lastMatch  │
└───────────────┬───────────────────────────────────────────────────────────┘
                │ fetch (JSON) — src/lib/game/api.ts (типизированный клиент)
┌───────────────▼─────────────── Сервер Next.js ─────────────────────────────┐
│  /api/game/new        /api/game/select      /api/game/state               │
│  /api/game/tactic     /api/game/simulate    /api/game/market              │
│  /api/game/market/buy /api/game/market/sell /api/game/match               │
│  zod-валидация → игровая логика (src/lib/game/*) → Prisma                  │
└───────────────┬────────────────────────────────────────────────────────────┘
                │ Prisma Client ('@/lib/db')
┌───────────────▼─────────────────── SQLite (db/custom.db) ──────────────────┐
│ GameSave · Team · Player · Match · TransferListing · NewsItem ·            │
│ FinanceRecord                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

- «Таблица лиги» **не хранится в БД** — вычисляется на лету из `Match` (функция `computeStandings`, раздел 4.14).
- Клиент никогда не пишет в БД напрямую: любое действие = POST на API → ответ → гидрация стора.
- Симуляция матча происходит **целиком на сервере** (одним запросом); «живая трансляция» на клиенте — это поэтапная показуха заранее посчитанного массива событий.

---

## 2. Древо файлов проекта

Файлы, которые нужно СОЗДАТЬ (метка ✏️ — существующий файл правится). shadcn/ui-компоненты уже лежат в `src/components/ui` — их не трогаем, только импортируем.

```
prisma/
└── schema.prisma                          ✏️ ПЕРЕЗАПИСАТЬ (модели User/Post удалить)

src/
├── app/
│   ├── layout.tsx                         ✏️ ПРАВИТЬ: lang="ru", шрифт Inter, metadata «Футбольный Менеджер»
│   ├── globals.css                        ✏️ ПРАВИТЬ: дизайн-токены темы (раздел 9)
│   ├── page.tsx                           ✏️ ПЕРЕЗАПИСАТЬ: SPA-контейнер (раздел 5)
│   └── api/
│       ├── route.ts                          (оставить как есть — health-check)
│       └── game/
│           ├── new/route.ts                  POST   — новая игра: генерация мира, список 16 клубов
│           ├── select/route.ts               POST   — выбор клуба менеджером
│           ├── state/route.ts                GET    — полный снапшот состояния игры
│           ├── tactic/route.ts               POST   — сохранение состава и тактики
│           ├── simulate/route.ts             POST   — симуляция тура (матч игрока + ИИ + весь пакет обновлений)
│           ├── market/route.ts               GET    — трансферный рынок (фильтры)
│           ├── market/buy/route.ts           POST   — покупка игрока
│           ├── market/sell/route.ts          POST   — выставить своего игрока на продажу
│           └── match/route.ts                GET ?id= — детали матча (лента событий) для экрана Лиги
│
├── lib/
│   ├── db.ts                                (уже есть — не трогать)
│   ├── utils.ts                             (уже есть — cn())
│   ├── store.ts                             ✚ Zustand-стор (раздел 6)
│   └── game/
│       ├── types.ts                         ✚ все TS-типы игры (DTO, MatchEvent, StandingRow и т.д.)
│       ├── constants.ts                     ✚ все константы баланса (листинг в 4.1)
│       ├── data.ts                          ✚ ДАННЫЕ ГЕНЕРАЦИИ: имена, фамилии, города, суффиксы клубов,
│       │                                         цвета клубов, национальности, текстовые шаблоны событий
│       ├── rng.ts                           ✚ mulberry32 + gauss + hashString (детерминизм)
│       ├── poisson.ts                       ✚ сэмплер Пуассона (алгоритм Кнута)
│       ├── generate.ts                      ✚ генерация мира: 16 команд, составы, календарь 30 туров
│       ├── players.ts                       ✚ генерация игрока, расчёт OVR, цен/зарплат, авторегенерация состава
│       ├── strength.ts                      ✚ сила линий команды из состава+тактики (4.6)
│       ├── match.ts                         ✚ симуляция матча игрока: λ → Пуассон → события (4.8)
│       ├── week.ts                          ✚ симуляция тура целиком: ИИ-матчи, пост-матч, финансы, рынок, новости (4.9)
│       ├── transfers.ts                     ✚ генерация рынка, формула цены, покупка/продажа (4.12)
│       ├── finances.ts                      ✚ доходы/расходы, записи FinanceRecord (4.13)
│       ├── progression.ts                   ✚ пост-матч апдейты + межсезонье: старение, развитие, пенсии (4.10–4.11)
│       ├── standings.ts                     ✚ computeStandings из Match-записей (4.14)
│       └── api.ts                           ✚ типизированные fetch-обёртки для клиента (использует store)
│
└── components/
    └── game/
        ├── GameShell.tsx                 ✚ каркас: верхнее меню (desktop), нижний таб-бар (mobile), контент
        ├── StartScreen.tsx               ✚ ввод имени менеджера + выбор клуба из 16 карточек
        ├── ClubCard.tsx                  ✚ карточка клуба для стартового экрана
        ├── DashboardScreen.tsx           ✚ тайлы: след. матч, мини-таблица, новости, финансы, совет ассистента
        ├── SquadScreen.tsx               ✚ таблица состава + фильтры + карточка игрока
        ├── PlayerDialog.tsx              ✚ карточка игрока (модалка): OVR, атрибуты, экономика, действия
        ├── TacticsScreen.tsx             ✚ поле + выбор формации + слайдеры + автосостав + сила состава
        ├── PitchField.tsx                ✚ вертикальное поле с разметкой и слотами (чистая отрисовка)
        ├── PlayerChip.tsx                ✚ «фишка» игрока на поле (номер, OVR, бейдж позиции)
        ├── MatchScreen.tsx               ✚ пре-матч / трансляция / итог
        ├── MatchTimeline.tsx             ✚ лента событий с автоскроллом (используется и в экране Лиги)
        ├── LeagueScreen.tsx              ✚ таблица + календарь/результаты по турам
        ├── TransfersScreen.tsx           ✚ рынок (фильтры, покупка) + мои продажи
        ├── FinancesScreen.tsx            ✚ баланс, бюджет, ведомость, журнал операций
        └── shared/
            ├── PositionBadge.tsx         ✚ цветной бейдж позиции (GK/DEF/MID/FWD)
            ├── OvrBadge.tsx              ✚ круг с OVR, цвет по величине (≥85 золото и т.д.)
            ├── AttributeBar.tsx          ✚ строка атрибута: подпись + Progress + число
            ├── FormDots.tsx              ✚ 5 точек последних матчей (🟢🟡🔴)
            ├── TeamCrest.tsx             ✚ мини-герб: круг цвета клуба + shortName
            ├── StatCard.tsx              ✚ тайл-карточка дашборда (иконка, значение, подпись, ссылка)
            └── SectionHeader.tsx          ✚ заголовок секции (H2 + подзаголовок + действие справа)

Итого новых файлов: 11 API-роутов + 17 модулей lib + 21 игровой компонент + 2 правки app/* + 1 schema.
```

**Где хранить данные генерации:** только `src/lib/game/data.ts` (статические массивы, листинги в 4.3). Никаких JSON-файлов и внешних источников.

---

## 3. Схема Prisma (готова к вставке в prisma/schema.prisma)

Полностью заменить содержимое файла. `User` и `Post` удаляются. После записи: `bun run db:push`.

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

/// Сохранение игры. В БД всегда активен ОДИН сейв (MVP).
/// status: "setup" (клуб ещё не выбран) | "active" (идёт сезон) | "season_end" (момент между сезонами, показ призов)
model GameSave {
  id          String   @id @default(cuid())
  managerName String                        // имя менеджера с стартового экрана
  teamId      String?  @unique              // выбранный клуб (FK), null до выбора
  season      Int      @default(1)          // номер сезона, стартует с 1
  week        Int      @default(1)          // текущий тур 1..30
  balance     Int      @default(0)          // баланс клуба пользователя, € (Int, без копеек)
  status      String   @default("setup")
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  team    Team?            @relation("UserTeam", fields: [teamId], references: [id])
  teams   Team[]           @relation("SaveTeams")
  players Player[]         @relation("SavePlayers")   // все игроки сейва, включая свободных агентов рынка
  matches Match[]
  listings TransferListing[]
  news    NewsItem[]
  finance FinanceRecord[]
}

/// Клуб лиги (16 штук на сейв).
model Team {
  id              String  @id @default(cuid())
  saveId          String
  name            String                        // "Каменск Юнайтед"
  shortName       String  @default("FC")        // 2–3 буквы для мини-гербов
  city            String?
  colorPrimary    String  @default("#2E9E5B")   // hex, из палитры data.ts
  colorSecondary  String  @default("#F0F0E0")
  strength        Int     @default(65)          // базовая сила 50..90 (генерация; для превью и ИИ-матчей)
  isUserTeam      Boolean @default(false)
  stadiumCapacity Int     @default(25000)

  // ── Тактика (у ИИ — дефолты/случайные разумные значения) ──
  formation       String  @default("4-4-2")     // id формации из FORMATIONS
  mentality       String  @default("balanced")  // defensive|cautious|balanced|attacking|allout
  tempo           String  @default("medium")    // low|medium|high
  pressing        String  @default("medium")    // low|medium|high
  defLine         String  @default("medium")    // low|medium|high
  playStyle       String  @default("balanced")  // balanced|wing|passing|long|counter
  lineup          String?                        // JSON: string[] — id 11 игроков стартового состава (порядок = слоты формации)
  bench           String?                        // JSON: string[] — id до 7 запасных

  save     GameSave @relation("SaveTeams", fields: [saveId], references: [id], onDelete: Cascade)
  userSave GameSave? @relation("UserTeam")
  players  Player[] @relation("TeamPlayers")
  homeMatches Match[] @relation("HomeMatches")
  awayMatches Match[] @relation("AwayMatches")

  @@index([saveId])
}

/// Игрок. Атрибуты 1..100. Экономика в € (Int).
model Player {
  id          String  @id @default(cuid())
  saveId      String
  teamId      String?                          // null = свободный агент на трансферном рынке
  firstName   String
  lastName    String
  nationality String  @default("RU")           // 2 буквы, косметика
  position    String                           // GK|DL|DC|DR|DML|DMC|DMR|ML|MC|MR|AML|AMC|AMR|ST
  shirtNumber Int     @default(0)              // 1..99
  age         Int                              // 16..36
  potential   Int                              // потолок OVR (>= ovr)
  ovr         Int                              // текущий общий рейтинг 1..100

  // ── 12 полевых атрибутов (1..100) ──
  finishing   Int @default(50)                 // Удар/Финиш
  passing     Int @default(50)                 // Пас
  dribbling   Int @default(50)                 // Дриблинг
  crossing    Int @default(50)                 // Кроссы
  tackling    Int @default(50)                 // Отбор
  marking     Int @default(50)                 // Опека
  positioning Int @default(50)                 // Позиционирование
  heading     Int @default(50)                 // Игра головой
  pace        Int @default(50)                 // Скорость
  stamina     Int @default(50)                 // Выносливость
  strength    Int @default(50)                 // Сила
  aggression  Int @default(50)                 // Агрессия

  // ── 3 вратарских атрибута (1..100) ──
  reflexes    Int @default(50)                 // Рефлексы
  rushingOut  Int @default(50)                 // Выходы
  kicking     Int @default(50)                 // Ввод мяча

  // ── Состояние ──
  morale      Int @default(60)                 // 0..100
  condition   Int @default(100)                // 30..100 (физ. готовность)
  injuryWeeks Int @default(0)                  // сколько туров ещё вне игры

  // ── Экономика ──
  value       Int @default(0)                  // рыночная стоимость, € (формула 4.12)
  salary      Int @default(0)                  // зарплата €/неделю

  // ── Статистика текущего сезона ──
  goals       Int @default(0)
  assists     Int @default(0)
  apps        Int @default(0)                  // сыгранные матчи
  yellowCards Int @default(0)
  redCards    Int @default(0)

  save    GameSave         @relation("SavePlayers", fields: [saveId], references: [id], onDelete: Cascade)
  team    Team?            @relation("TeamPlayers", fields: [teamId], references: [id])
  listing TransferListing?

  @@index([saveId, teamId])
  @@index([saveId, position])
}

/// Матч. Таблица лиги вычисляется из сыгранных Match (см. 4.14).
model Match {
  id         String   @id @default(cuid())
  saveId     String
  season     Int      @default(1)
  week       Int                                     // 1..30
  homeTeamId String
  awayTeamId String
  homeGoals  Int?                                     // null пока status=scheduled
  awayGoals  Int?
  status     String   @default("scheduled")           // scheduled | played
  events     String?                                  // JSON: MatchEvent[] (полный для матча игрока, только голы для ИИ)
  stats      String?                                  // JSON: MatchStats (только матчи с участием клуба игрока)
  createdAt  DateTime @default(now())

  save     GameSave @relation(fields: [saveId], references: [id], onDelete: Cascade)
  homeTeam Team     @relation("HomeMatches", fields: [homeTeamId], references: [id])
  awayTeam Team     @relation("AwayMatches", fields: [awayTeamId], references: [id])

  @@unique([saveId, season, week, homeTeamId])
  @@index([saveId, season, week])
}

/// Лот трансферного рынка. Игрок рынка: Player.teamId = null + запись здесь.
model TransferListing {
  id        String   @id @default(cuid())
  saveId    String
  playerId  String   @unique
  price     Int                                        // цена покупки, €
  askFactor Float    @default(1.15)                    // «жадность» 1.0..1.3 (фиксируется при создании лота)
  source    String   @default("market")                // market (сгенерирован) | user (выставлен игроком)
  status    String   @default("active")                // active | sold | expired
  expiresAt Int      @default(6)                       // туров до снятия с продажи
  createdAt DateTime @default(now())

  save   GameSave @relation(fields: [saveId], references: [id], onDelete: Cascade)
  player Player   @relation(fields: [playerId], references: [id])

  @@index([saveId, status])
}

/// Новость для ленты дашборда.
model NewsItem {
  id        String   @id @default(cuid())
  saveId    String
  season    Int
  week      Int
  type      String   // result | transfer | injury | market | finance | info
  message   String
  createdAt DateTime @default(now())

  save GameSave @relation(fields: [saveId], references: [id], onDelete: Cascade)

  @@index([saveId, season, week])
}

/// Финансовая операция клуба игрока (журнал для экрана Финансы).
model FinanceRecord {
  id          String   @id @default(cuid())
  saveId      String
  season      Int
  week        Int
  kind        String   // income | expense
  category    String   // sponsor | tickets | prize | transfer_in | transfer_out | wages
  amount      Int                   // всегда положительное; знак определяется kind
  description String
  createdAt   DateTime @default(now())

  save GameSave @relation(fields: [saveId], references: [id], onDelete: Cascade)

  @@index([saveId, season, week])
}
```

**Важно (SQLite):** enum'ов нет — строковые поля валидируются zod-схемами в API; списки — только через JSON-строки (`events`, `stats`, `lineup`, `bench`). Парсинг JSON — через типизированные хелперы `parseEvents/parseStats/parseLineup` в `types.ts` (с безопасным fallback).

---

## 4. Игровая логика (спецификации алгоритмов)

Все модули — чистые функции над POJO. Вход/выход — типы из `types.ts`. Никакого обращения к Prisma внутри `match.ts`/`strength.ts` (оркестрация БД — только в `week.ts` и API-роутах).

### 4.1. Константы (`src/lib/game/constants.ts`, полный листинг)

```ts
// ── Мир ──
export const LEAGUE_SIZE = 16;        // команд в лиге
export const SEASON_WEEKS = 30;       // туров в сезоне (2 круга по 15)
export const SQUAD_MIN = 13;          // минимальный размер состава (≥2 GK, ≥4 DEF, ≥4 MID, ≥3 FWD)
export const SQUAD_MAX = 25;          // максимальный размер состава
export const LINEUP_SIZE = 11;
export const BENCH_MAX = 7;

// ── Экономика (€) ──
export const START_BALANCE_BASE = 20_000_000;   // стартовый баланс клуба игрока
export const START_BALANCE_PER_STRENGTH = 4_000_000; // + за каждую единицу силы выше 55
export const STADIUM_BASE = 15_000;             // вместимость = BASE + (strength-55)*1500
export const STADIUM_PER_STRENGTH = 1_500;
export const TICKET_PRICE = 30;                 // € за билет
export const SPONSOR_BASE = 300_000;            // €/неделю
export const SPONSOR_PER_PLACE = 25_000;        // + (16 - место) * это
export const PRIZE_MONEY = [15_000_000, 10_000_000, 7_000_000, 5_000_000,
  3_000_000, 3_000_000, 3_000_000, 3_000_000,   // места 5–8
  2_000_000, 2_000_000, 2_000_000, 2_000_000,   // места 9–12
  1_000_000, 1_000_000, 1_000_000, 500_000];    // места 13–16 (индекс = место-1)
export const TRANSFER_BUDGET_RATIO = 0.4;       // transferBudget = floor(balance * 0.4), но >= 0
export const WAGE_ALERT_RATIO = 0.7;            // алерт: зарплаты > 70% недельного дохода

// ── Матч ──
export const BASE_GOALS = 1.35;      // базовое λ (среднее голов команды)
export const HOME_ADVANTAGE = 1.06;  // множитель домашней команды
export const LAMBDA_MIN = 0.2;
export const LAMBDA_MAX = 5.0;
export const MAX_GOALS = 8;          // кап сэмпла Пуассона
export const EMPTY_SLOT_STRENGTH = 40; // сила пустого слота (сильный штраф)
export const RED_CARD_PROB = 0.025;  // на команду за матч
export const INJURY_PROB = 0.04;     // на команду за матч
export const RED_LAMBDA_SELF = 0.85; // множитель λ команды после красной (красная ≤ 45')
export const RED_LAMBDA_OPP = 1.10;  // множитель λ соперника после красной (≤ 45')
export const RED_LAMBDA_SELF_LATE = 0.93; // красная в 46'–70' (половинный эффект)
export const RED_LAMBDA_OPP_LATE = 1.05;

// ── Веса линий ──
export const LINE_WEIGHT = { attack: 0.35, midfield: 0.30, defence: 0.35 }; // teamStrength для UI
export const EFF_ATK = { attack: 0.75, midfield: 0.25 };  // effectiveAttack
export const EFF_DEF = { defence: 0.70, midfield: 0.30 }; // effectiveDefence
export const LINE_REF = { attack: 2.6, midfield: 4.8, defence: 5.6 }; // эталон весов 4-4-2

// ── Трансферы ──
export const MARKET_SIZE_MIN = 50;   // активных лотов рынка после рефреша
export const MARKET_SIZE_MAX = 70;
export const SELL_PRICE_MIN_RATIO = 0.75; // границы цены продажи своих
export const SELL_PRICE_MAX_RATIO = 2.5;
export const VALUE_BASE = 50_000;    // value = 50K × 1.11^OVR × ...
export const VALUE_GROWTH = 1.11;
export const SALARY_RATIO = 0.0002;  // salary = value × 0.0002 / неделю (min €500)

// ── Пост-матч ──
export const MORALE_WIN = 15, MORALE_DRAW = 2, MORALE_LOSS = -15;
export const CONDITION_DRAIN_BASE = 22;  // −(22 − stamina/12) стартёрам
export const CONDITION_BENCH_GAIN = 10;
export const CONDITION_WEEKLY_RECOVERY = 8;
```

### 4.2. RNG и Пуассон

`src/lib/game/rng.ts` — детерминированный генератор **mulberry32**:

```ts
function mulberry32(seed: number): () => number
function hashString(s: string): number        // FNV-1a 32-бит
function gauss(rng: () => number, mean: number, sd: number): number  // Box-Muller, clamp не нужен (клампим на месте)
function randInt(rng, min, max): number       // включительно
function pick<T>(rng, arr: T[]): T
```

Сид матча: `hashString(saveId + ':' + season + ':' + week + ':' + matchId)` — повторный прогон того же матча даёт тот же результат (тестируемость, защита от «пересимуляции»).

`src/lib/game/poisson.ts` — сэмплер по Кнуту:

```ts
function samplePoisson(rng: () => number, lambda: number): number {
  const L = Math.exp(-lambda); let k = 0, p = 1;
  do { k++; p *= rng(); } while (p > L);
  return Math.min(k - 1, MAX_GOALS);
}
```

### 4.3. Генерация мира (`generate.ts` + `data.ts`)

**data.ts — точное содержимое массивов (минимум, можно только расширять):**

```ts
export const FIRST_NAMES = [ // 20
  "Александр","Дмитрий","Иван","Артём","Никита","Максим","Сергей","Андрей","Кирилл","Егор",
  "Данил","Павел","Роман","Владимир","Тимур","Марк","Олег","Виктор","Степан","Ярослав"];
export const LAST_NAMES = [ // 24
  "Смирнов","Кузнецов","Попов","Волков","Соколов","Лебедев","Козлов","Новиков","Морозов","Петров",
  "Фролов","Орлов","Зайцев","Соловьёв","Васильев","Поляков","Медведев","Егоров","Ларионов","Гусев",
  "Титов","Абрамов","Данилов","Черкасов"];
export const CITIES = [ // 16 — вымышленные, по одному клубу на город
  "Каменск","Новоград","Зеленодольск","Северск","Озёрск","Южногорск","Светлогорье","Медногорск",
  "Тихорецк","Володарск","Ясногорск","Чернореченск","Берёгов","Степногорск","Пригорск","Зареченск"];
export const CLUB_SUFFIXES = [ // 10
  "Юнайтед","Сити","Атлетико","Альянс","Фортуна","Метеор","Олимпик","Стандарт","Прогресс","Сокол"];
export const CLUB_COLORS: [string, string][] = [ // 16 пар [primary, secondary] — БЕЗ синего/индиго
  ["#EAB308","#0D1210"],["#F87171","#F0F0E0"],["#4ADE80","#0D1210"],["#F0F0E0","#0D1210"],
  ["#FB923C","#0D1210"],["#B91C1C","#FACC15"],["#2E9E5B","#F0F0E0"],["#7F1D1D","#EAB308"],
  ["#A16207","#F0F0E0"],["#84CC16","#0D1210"],["#0D9488","#F0F0E0"],["#166534","#F0F0E0"],
  ["#D9A441","#0D1210"],["#9A3412","#F0F0E0"],["#65A30D","#0D1210"],["#FACC15","#1C2620"]];
export const FOREIGN_NAT = ["BR","PT","ES","FR","DE","IT","RS","UA","BY","KZ"]; // 18% игроков
// Текстовые шаблоны событий (подстановка {player}):
export const GOAL_TEMPLATES = [ /* ≥5, напр. "ГОЛ! {player} отправляет мяч в сетку!",
  "ГОЛ! {player} завершает красивую атаку!", "ГОЛ! {player} точно бьёт с линии штрафной!",
  "ГОЛ! {player} замыкает навес!", "ГОЛ! {player} реализует момент!" */ ];
export const CHANCE_TEMPLATES = [ /* ≥5, напр. "Опасно! {player} бьёт — рядом со штангой!",
  "{player} пробивает — вратарь на месте!", "Штанга! {player} был в шаге от гола!",
  "Удар {player} блокирован в последний момент!", "{player} тащит мяч к штрафной, но защита успевает!" */ ];
export const YELLOW_TEMPLATES = [ /* ≥2: "Жёлтая карточка: {player} — грубый подкат.",
  "Жёлтая: {player} срывает атаку фолом." */ ];
```

**Генерация 16 команд (`generateLeague(seed)`):**

1. Силы (значение `Team.strength`, распределение «пара топов + середина + аутсайдеры»):
   базовый вектор `[85, 83, 79, 77, 75, 74, 72, 70, 69, 67, 66, 65, 63, 61, 58, 55]`,
   каждая сила + gauss(0, 2), затем clamp(50, 88) и пересортировка по убыванию.
2. Названия: города перемешиваются rng, каждый i-й клуб = `{CITIES[i]} {pick(CLUB_SUFFIXES)}` (суффиксы могут повторяться, города — нет). `shortName` = первые 2–3 согласные города + заглавные (КМН, НВГ…). Цвета: `CLUB_COLORS` без повторов.
3. Стадион: `STADIUM_BASE + (strength − 55) × STADIUM_PER_STRENGTH` (top-клуб ≈ 60 000, аутсайдер ≈ 15 000).
4. Состав каждой команды — `generateSquad(rng, strength)` (раздел 4.4): ровно 20 игроков по шаблону:
   `GK×2, DL×2, DC×3, DR×2, DM×2 (DML/DMC/DMR — по одному rng-выбору), M×3 (ML/MC/MR), AM×2 (AML/AMR или AMC), ST×3`,
   + 1 случайный из `[DC, MC, ST]` → 21, + ещё 1 c вероятностью 0.25 → максимум 22. Итог 20–22.
5. ИИ-тактика: сильные (≥74) — `4-3-3`/`attacking`; средние (62–73) — `4-4-2`/`balanced`; слабые (<62) — `5-3-2` или `4-5-1`/`defensive`. `lineup` у ИИ НЕ сохраняется — выставляется автосоставом перед матчем (4.9).
6. **Календарь 30 туров** — круговой метод «карусель»: команды 0..15, фиксирована №16-я (последняя), остальные вращаются. Тур r (0..14): пары `i vs (15 - i mod 15)` с чередованием дома/гости по чётности r; вторая половина сезона (туры 16–30) — те же пары с обратным полем. Реализация — стандартный алгоритм round-robin; гарантирует: каждая пара встречается 2 раза, у всех по 15 домашних/15 гостевых.

**Игрок (`generatePlayer(rng, strength, position)`):**

- `age`: сэмплируется по весам: 16–19 → 10%, 20–23 → 20%, 24–27 → 30%, 28–31 → 25%, 32–36 → 15%.
- Атрибуты: `attr = clamp(round(gauss(rng, strength, 8) × roleMod), 20, 95)`,
  где `roleMod = 1.10` если вес атрибута в OVR-таблице (4.4) для его позиции ≥ 10, иначе `0.85`;
  вратарские атрибуты для полевых — `×0.4`; полевые для вратаря — `×0.6` (кроме тех, что входят в OVR GK).
- `nationality`: 82% «RU», иначе `pick(FOREIGN_NAT)`. Имя/фамилия: `pick(FIRST_NAMES) + ' ' + pick(LAST_NAMES)` (уникальность внутри команды: при коллизии переброс).
- `shirtNumber`: вратари 1–2, защитники 2–9/14–19..., просто сквозная нумерация при генерации 1..99 без повторов в команде.
- `potential`: `age ≤ 21 → ovr + randInt(4, 15)`, `22–24 → ovr + randInt(1, 8)`, `≥25 → ovr`.
- `ovr` — расчёт по весам (4.4); `value`/`salary` — по 4.12; `morale = 60`, `condition = 100`, `injuryWeeks = 0`.

**Стартовые балансы:** при выборе клуба пользователю проставляется
`GameSave.balance = START_BALANCE_BASE + (strength − 55) × START_BALANCE_PER_STRENGTH`
(aутсайдер €20M, середина ~€60M, топ €100M — согласовано со шкалой цен 4.12).

### 4.4. OVR — веса атрибутов по позициям (сумма = 100 в каждой строке)

| Атрибут | GK | DC | DL/DR | DML/DMC/DMR | ML/MC/MR | AML/AMC/AMR | ST |
|---|---|---|---|---|---|---|---|
| reflexes | **30** | – | – | – | – | – | – |
| rushingOut | **15** | – | – | – | – | – | – |
| kicking | **15** | – | – | – | – | – | – |
| finishing | – | – | 2 | 3 | 5 | **15** | **30** |
| passing | 5 | 5 | 10 | **20** | **24** | **18** | – |
| dribbling | – | – | 10 | 8 | **14** | **18** | **14** |
| crossing | – | – | **14** | – | **12** | **12** | – |
| tackling | – | **20** | **14** | **15** | 10 | – | – |
| marking | – | **20** | **12** | 10 | – | – | – |
| positioning | **15** | **15** | 8 | 10 | 8 | 4 | **10** |
| heading | – | **15** | – | 5 | – | – | **14** |
| pace | 5 | 8 | **18** | 8 | 10 | **20** | **18** |
| stamina | 5 | 5 | **14** | **14** | **14** | 8 | – |
| strength | 10 | **12** | – | 10 | – | 4 | **14** |
| aggression | – | – | – | – | – | – | – |

(aggression не входит в OVR ни для кого — «скрытый» атрибут риска карточек.)

`OVR(player) = round(Σ (атрибут × вес) / 100)`, диапазон 1..100. Веса — константа `OVR_WEIGHTS: Record<Position, Record<AttrKey, number>>` в `constants.ts` (значения — ровно таблица выше).

### 4.5. Соответствие позиции (`positionFit`)

6 групп: `GK | DEF(DL,DC,DR) | DM(DML,DMC,DMR) | MID(ML,MC,MR) | AM(AML,AMC,AMR) | ST`.
Матрица (строка = группа игрока, столбец = группа слота):

| игрок \ слот | GK | DEF | DM | MID | AM | ST |
|---|---|---|---|---|---|---|
| **GK** | 1.0 | 0.2 | 0.2 | 0.2 | 0.2 | 0.2 |
| **DEF** | 0.2 | 1.0 | 0.9 | 0.8 | 0.6 | 0.5 |
| **DM** | 0.2 | 0.9 | 1.0 | 0.85 | 0.7 | 0.6 |
| **MID** | 0.2 | 0.75 | 0.85 | 1.0 | 0.85 | 0.75 |
| **AM** | 0.2 | 0.6 | 0.7 | 0.85 | 1.0 | 0.9 |
| **ST** | 0.2 | 0.5 | 0.6 | 0.75 | 0.9 | 1.0 |

(Реализация исследования: 1.0 своя, 0.75–0.9 соседняя, 0.5 чужая.)

### 4.6. Сила команды из состава и тактики (`strength.ts`)

**Шаг 1 — вклад игрока в слот:**

```
contribution(p, slot) =
    OVR(p)
  × positionFit(группа(p.position), группа(slot.position))
  × (condition(p) / 100)                      // 0.30..1.00
  × (0.9 + 0.2 × morale(p) / 100)             // мораль 0..100 → ×0.90..×1.10
```

Травмированный (`injuryWeeks > 0`) в слот не ставится (валидация на входе); пустой слот = `EMPTY_SLOT_STRENGTH` с весами слота.

**Шаг 2 — вклад слота в линии** (по позиции слота, а не игрока):

| Слот | defence | midfield | attack |
|---|---|---|---|
| GK | 1.0 | – | – |
| DL/DC/DR | 1.0 | 0.15 | – |
| DML/DMC/DMR | 0.55 | 1.0 | – |
| ML/MC/MR | 0.15 | 1.0 | 0.15 |
| AML/AMC/AMR | – | 0.65 | 0.75 |
| ST | – | 0.10 | 1.0 |

```
lineStrength(team, line) = Σ_slots (contribution × весСлотаЛинии) / LINE_REF[line]
// LINE_REF = { attack: 2.6, midfield: 4.8, defence: 5.6 } — эталон формации 4-4-2.
```

Деление на эталон 4-4-2 делает формации осмысленными: у 5-3-2 автоматически ~×1.10 к обороне и ~×0.88 к атаке при том же качестве игроков (сумма весов обороны 5.85 против эталона 5.6), у 3-4-3 — наоборот.

**Шаг 3 — итоговые величины:**

```
teamAttack  = lineStrength('attack')      // ≈ шкала OVR
teamMidfield= lineStrength('midfield')
teamDefence = lineStrength('defence')
teamStrength (для UI) = round(0.35×teamAttack + 0.30×teamMidfield + 0.35×teamDefence)

effectiveAttack  = 0.75 × teamAttack  + 0.25 × teamMidfield
effectiveDefence = 0.70 × teamDefence + 0.30 × teamMidfield
```

### 4.7. Модификаторы

Применяются к effectiveAttack/effectiveDefence/effectiveMidfield **до** расчёта λ:

**Домашнее преимущество:** вся домашняя команда × `HOME_ADVANTAGE = 1.06` (≈ +0.3–0.4 гола, даёт ~46–49% домашних побед).

**Менталитет (5 уровней, на атаку/оборону/центр поля):**

| Менталитет | attack | defence | midfield |
|---|---|---|---|
| defensive | ×0.92 | ×1.08 | ×0.98 |
| cautious | ×0.96 | ×1.04 | ×1.00 |
| balanced | ×1.00 | ×1.00 | ×1.00 |
| attacking | ×1.08 | ×0.92 | ×1.02 |
| allout (тотальный) | ×1.16 | ×0.84 | ×1.04 |

**Темп** — на λ не влияет: low → количество «опасных моментов» ×0.8 и drain состояния −2; high → моментов ×1.2, drain +2.

**Прессинг:** low → своя оборона ×1.02; medium → ×1.00; high → атака соперника ×0.96, но drain +3 и λ жёлтых +0.4 (у обеих… только у прессингующей).

**Линия обороны:** low → оборона ×1.03 / атака ×0.97; high → атака ×1.03 / оборона ×0.97.

**Матрица стилей («камень-ножницы-бумага», механика OSM).** Цикл: `wing > passing > long > wing`; `counter` силён против атакующих стилей и слаб против «автобусов»; `balanced` нейтрален. Множитель на СВОЮ атаку при паре (мой стиль, стиль соперника):

| мой \ соперник | balanced | wing | passing | long | counter |
|---|---|---|---|---|---|
| **balanced** | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| **wing** | 1.00 | 1.00 | **1.05** | ×0.95 | 1.00 |
| **passing** | 1.00 | ×0.95 | 1.00 | **1.05** | 1.00 |
| **long** | 1.00 | **1.05** | ×0.95 | 1.00 | 1.00 |
| **counter** | 1.00 | **1.06** | **1.06** | 0.97 | 1.00 |

Дополнительно контратаки дают `defence ×1.03` против соперника с менталитетом attacking/allout.

**Классы формаций (множители сверх стилей):**

| Формация | Класс |
|---|---|
| 4-4-2 | balanced |
| 4-3-3 | flank_attack |
| 4-2-3-1 | center_attack |
| 4-5-1 | defensive |
| 3-5-2 | flank_mid |
| 5-3-2 | dense |
| 4-1-4-1 | defensive |
| 3-4-3 | flank_attack |

Правила (применяются к паре классов, суммируются при нескольких попаданиях):
- `dense` против `flank_attack`/`center_attack` → своя оборона ×1.07;
- `flank_attack` против `dense` → своя атака ×1.07;
- `flank_mid` против `dense` → своя атака ×1.06;
- `dense` против `balanced` → своя оборона ×1.04;
- `center_attack` против `defensive` → своя атака ×1.05;
- `defensive` против `flank_attack` → своя оборона ×1.05.

**Итог:** `effAtk' = effAtk × mentality.atk × defLine.atk × styleAtk × formationAtk (× 1.06 если дома)`; аналогично `effDef'`, `effMid'` (для владения).

### 4.8. Симуляция матча игрока (`match.ts`)

Вход: полные состояния двух команд (игроки, lineup, тактика, morale/condition). Выход: `MatchResult { homeGoals, awayGoals, events: MatchEvent[], stats: MatchStats }`.

**Шаг 1.** Силы линий (4.6) → модификаторы (4.7) → `effAtkH', effDefH', effAtkA', effDefA'`.

**Шаг 2. Карточки/травмы — ДО голов** (красная меняет λ):

- Красная: для каждой команды с вероятностью `RED_CARD_PROB = 0.025`: минута `randInt(20, 80)`; автор — игрок из состава, взвешенно по `aggression`; если это 2-я жёлтая — сначала фиксируется жёлтая на той же минуте.
- Жёлтые: `n = samplePoisson(1.2 + avgAggression/200 + (pressing=high ? 0.4 : 0))` на команду (кап 5); авторы взвешенно по aggression; вторая жёлтая тому же игроку = красная.
- Травма: вероятность `INJURY_PROB = 0.04` на команду; жертва — стартёр, взвешенно по `1/stamina`; длительность `randInt(1, 5)` туров.
- Корректировка λ при красной ДО минуты 45 (включительно): команда ×0.85, соперник ×1.10; при красной в 46–70: ×0.93 / ×1.05; позже 70 — не влияет на λ (только событие).

**Шаг 3. Голы:** 
```
λ_home = clamp(BASE_GOALS × (effAtkH' / effDefA'), 0.2, 5.0)
λ_away = clamp(BASE_GOALS × (effAtkA' / effDefH'), 0.2, 5.0)
homeGoals = samplePoisson(λ_home); awayGoals = samplePoisson(λ_away)   // кап MAX_GOALS=8
```

**Шаг 4. Таймлайн:**
- Минуты голов: с плотностью 2-го тайма (реальная статистика): 40% в 1–45, 52% в 46–90, 8% в 90+1..90+3. Все минуты матча сортируются.
- Автор гола: игрок на поле, вес = `finishing + (группа ST ? 20 : группа AM ? 10 : группа MID ? 0 : −30)`. Ассистент (50% голов): вес = `passing`, другой игрок.
- Опасные моменты («атмосфера»): `count = max(0, round((shots − goals − 2) × 0.5))` случайно разбросанных по матчу событий `type='chance'` из `CHANCE_TEMPLATES`.
- События `kickoff` (0'), `halftime` (45'), `fulltime` (90'+stoppage) — рамки ленты.

**Шаг 5. Статистика:**
```
shotsHome = clamp(round(4 + λ_home × 7), 3, 25);  аналогично away
shotsOnTarget = round(shots × (0.35 + rng() × 0.20))   // ≥ голов
possessionHome = clamp(50 + 1.2 × (effMidH' − effMidA'), 25, 75)
corners = round(shots × 0.45); fouls = randInt(8, 16) на команду (кореллирует с жёлтыми: fouls ≥ yellow×4)
```

**Шаг 6.** Пост-матч-обработка (4.10) выполняется в `week.ts` после записи Match.

**Событие (MatchEvent, JSON в `Match.events`):**
```ts
interface MatchEvent {
  minute: number;                       // 0..93
  type: 'kickoff'|'goal'|'yellow'|'red'|'injury'|'chance'|'halftime'|'fulltime';
  teamId?: string;                      // чьё событие (undefined для kickoff/halftime/fulltime)
  playerId?: string; playerName?: string;
  assistId?: string; assistName?: string;
  text: string;                         // готовая строка ленты
}
interface MatchStats {
  possessionHome: number; shotsHome: number; shotsAway: number;
  sotHome: number; sotAway: number;                     // в створ
  cornersHome: number; cornersAway: number;
  foulsHome: number; foulsAway: number;
  yellowsHome: number; yellowsAway: number; redsHome: number; redsAway: number;
}
```

### 4.9. Симуляция тура (`week.ts`) — оркестратор

`simulateWeek(saveId)` выполняется в одном POST `/api/game/simulate` внутри транзакции по шагам:

1. **Составы ИИ:** каждой ИИ-команде — `autoLineup(team)`: для каждого слота её формации взять доступного (не травмированного) игрока с максимальным `OVR × positionFit × condition/100`. Если у команды ИИ средняя усталость стартового состава < 55 — вместо самого уставшего поставить лучшего свежего запасного (простая ротация).
2. **Состав игрока:** если lineup не задан/невалиден (меньше 11, дубли, травмированные) — `autoLineup` + новость «Ассистент выставил состав автоматически».
3. **Матч игрока** — полный движок 4.8 (запись Match со статусом played, events, stats).
4. **7 матчей ИИ** — упрощённая формула: `Sh = team.strength`, с учётом свежести (`+ gauss(0, 3)`), λ по схеме 4.8 шаг 3 с множителями дома ×1.06; голы Пуассоном; в events — ТОЛЬКО голы (минута + автор, взвешенный по OVR из состава); `stats = null`.
5. **Пост-матч** для ВСЕХ 16 команд (4.10): мораль/состояние/статистика/травмы.
6. **Финансы игрока** (4.13): списание зарплат за тур; спонсор; билеты, если домашний матч.
7. **Рынок** (4.12): `expiresAt−1` у лотов, истёкшие → `status='expired'` (Player.teamId остаётся null, игрок «уходит» с рынка — используется повторно при следующей генерации лотов нельзя, просто игнорируется); догенерация до `MARKET_SIZE_MIN..MAX`; розыгрыш предложений по своим лотам (продажи игрока); ИИ-покупки: с вероятностью 0.15 одна случайная ИИ-команда покупает самый дешёвый лот, который «по карману» (флористика рынка).
8. **Новости**: результат тура игрока, крупные события (красная, травма), продажи/покупки, `NewsItem`.
9. **week++**; если `week > SEASON_WEEKS` → сезонный переход (4.11) и `week = 1, season++`.
10. Ответ API — пакет `WeekResultPayload` (раздел 7).

### 4.10. Пост-матч (`progression.ts`)

Для каждой команды после её матча:

```
Стартёры:   condition −= max(8, CONDITION_DRAIN_BASE − stamina/12) − tempoDrain − pressingDrain   // ≈ −12..−28
Запас:      condition += CONDITION_BENCH_GAIN        // +10
Все игроки: condition = clamp(condition + CONDITION_WEEKLY_RECOVERY, 30, 100)  // недельное восстановление
Стартёры:   apps += 1; goals/assists/yellowCards/redCards — из событий; травмированному injuryWeeks = длительность
Мораль:     победа +15 / ничья +2 / поражение −15 (запасные — половина: +8/+1/−8); clamp(5, 100)
```

«Форма» (последние 5 матчей) НЕ хранится на игроке — вычисляется из истории `Match` команды (4.14).

### 4.11. Сезонный переход (после тура 30)

1. Призовые: `PRIZE_MONEY[место−1]` → `GameSave.balance`, запись `FinanceRecord(prize)`, `NewsItem` «Сезон завершён! Вы заняли N место».
2. Все игроки: `age += 1`.
3. Развитие: `age ≤ 23` → 2–4 случайных атрибута с весом ≥10 в его OVR-строке `+randInt(1, 3)` (не выше потолка `potential` для пересчитанного OVR); `24–29` → 50% шанс одного `+1`; `30+` → `randInt(1, 3)` ключевых атрибутов `−randInt(1, 3)`.
4. Завершение карьеры: `age ≥ 35` — всегда; `33–34` — с вероятностью 0.4. Ушедшие удаляются, на их место `generatePlayer(strength−5, та же позиция)` с возрастом 17–19.
5. Пересчёт `ovr`, `value`, `salary` у всех.
6. Сброс сезонной статистики (`goals, assists, apps, cards` → 0), `condition = 100`, `morale = 60`, `injuryWeeks = 0`.
7. Новый календарь (та же карусель), `season += 1`, `week = 1`.
8. Полная регенерация рынка (старые лоты `expired`, новые `MARKET_SIZE_MIN..MAX`).

### 4.12. Трансферы (`transfers.ts`)

**Стоимость игрока (формула из исследования — буквально):**

```
value = 50_000 × 1.11^OVR × ageFactor × potentialFactor × formFactor

ageFactor:       16–21 → 1.3;  22–27 → 1.0;  28–30 → 0.75;  31–33 → 0.4;  34+ → 0.15
potentialFactor: 1 + clamp((potential − ovr) × 0.04, 0, 0.5)      // разница ≥ 8 → до ×1.5
formFactor:      0.9 + morale/100 × 0.2                            // 0.9..1.1
```

Опорная таблица (ageFactor=1.0, прочие=1.0) — для сверки QA: OVR 50 → €9.2M · 55 → €15.6M · 60 → €26.2M · 65 → €44.2M · 70 → €74.5M · 80 → €211M · 90 → €600M.
**Зарплата:** `salary = max(500, round(value × 0.0002 / 100) × 100)` €/нед.

**Рынок (лоты `source='market'`):** генерация игрока: OVR-цель равномерно 45..75, позиция случайная (GK 10%, DEF 30%, MID 35%, FWD 25%), возраст 16..34 с теми же весами, что в генерации. Цена лота = `value × askFactor`, `askFactor = 0.1×randInt(10,13)` (1.0..1.3, фиксируется при создании).

**Покупка (клуб игрока):** валидации: лот `active`, `SQUAD_MAX` не превышен, `price ≤ transferBudget` (4.13). Исполнение: `balance −= price`, игроку `teamId = мой клуб`, пересчёт номера, лот `sold`, `FinanceRecord(transfer_out, −price)`, `NewsItem`. Бюджет считается от нового баланса.

**Продажа (клуб игрока):** игрок выставляется с ценой в диапазоне `[0.75×value, 2.5×value]` (UI-слайдер). Валидации: после продажи `SQUAD_MIN` и минимумы (≥2 GK, ≥4 DEF, ≥4 MID, ≥3 FWD) соблюдены. Каждый тур в `week.ts`: вероятность оффера
`p = clamp(0.9 − 0.35 × (цена/value − 0.75), 0.15, 0.95)`;
при оффере — мгновенная продажа по цене (MVP без торгов): `balance += price`, `FinanceRecord(transfer_in)`, игрок `teamId = null`, лот `sold`, новость. Продать можно только не травмированного.

**transferBudget:** `max(0, floor(balance × TRANSFER_BUDGET_RATIO))` — вычисляется на лету, не хранится.

### 4.13. Финансы (`finances.ts`)

Все операции — только для клуба игрока, каждая пишет `FinanceRecord`:

| Событие | Когда | Сумма |
|---|---|---|
| Зарплаты (`wages`, expense) | каждый тур | `Σ salary` всех игроков клуба |
| Спонсор (`sponsor`, income) | каждый тур | `SPONSOR_BASE + (16 − место) × SPONSOR_PER_PLACE` |
| Билеты (`tickets`, income) | домашний матч | `вместимость × посещаемость × TICKET_PRICE`; посещаемость: место 1–4 → 92%, 5–8 → 80%, 9–12 → 68%, 13–16 → 55%, ±5% rng |
| Покупка (`transfer_out`, expense) | в момент сделки | цена |
| Продажа (`transfer_in`, income) | в момент сделки | цена |
| Призовые (`prize`, income) | конец сезона | `PRIZE_MONEY[место−1]` |

Правила: баланс может уходить в минус ТОЛЬКО от зарплат (долг подсвечивается красным, блокирует покупки); покупки жёстко ограничены `transferBudget`. Алерт на дашборде/финансах: `недельные зарплаты > WAGE_ALERT_RATIO × (спонсор + средние билеты за тур)`.

### 4.14. Таблица лиги на лету (`standings.ts`)

`computeStandings(matchesPlayed, teams) → StandingRow[]`: по каждой команде считать И/В/Н/П/ЗМ/ПМ/±/О (3/1/0) из `Match` со статусом `played`; сортировка: очки → разница → забитые → имя (alpha). `form`: последние 5 результатов команды по турам (`'W'|'D'|'L'[]`). Зоны для UI: места 1–3 «ЛЧ» (зелёная полоса), 4–6 «ЛЕ» (жёлтая), 14–16 «вылет» (красная).

---

## 5. Экраны и компоненты (8 экранов)

Все экраны — компоненты, переключаемые в `page.tsx` по `activeTab` из стора. shadcn-компоненты из `src/components/ui`. Данные — из снапшота стора (раздел 6). Иконки — lucide-react.

### 5.1. Стартовый экран (StartScreen, фаза `start` / `club-select`)

- **До создания игры:** `Card` по центру: заголовок «Футбольный Менеджер», `Input` «Имя менеджера», `Button` «Начать карьеру» → `POST /api/game/new`.
- **Выбор клуба:** грид `ClubCard` (4 колонки desktop / 1–2 mobile): `TeamCrest` (цвет клуба), название, город, `Badge` силы («Топ» ≥74 золото / «Середина» 62–73 / «Аутсайдер» <62), бюджет (стартовый баланс), вместимость. Клик → `AlertDialog` подтверждение → `POST /api/game/select` → гидрация → дашборд.
- Данные: список 16 клубов из ответа `/api/game/new`.

### 5.2. Дашборд (DashboardScreen, Portal-паттерн FM26)

- **Тайл следующего матча** (Card, вся ширина, главная CTA): `TeamCrest` мой − `TeamCrest` соперник, сила обеих (`Badge`), дома/в гостях, тур N/30, `Button` primary на всю ширину **«Сыграть матч»** (переключает на `match`).
- **Мини-таблица** (Card + Table, топ-6 + строка клуба игрока с её реальным местом): место, клуб, И, О, `FormDots`.
- **Лента новостей** (Card + ScrollArea): последние 8 `NewsItem`, иконка по типу (Trophy, ArrowLeftRight, Bandage, Wallet, Newspaper).
- **Снапшот финансов** (StatCard): баланс, бюджет трансферов, недельные зарплаты; красный текст при минусе/алерте 70%.
- **Совет ассистента** (Alert): 1 строка — правила: есть травмированные в составе → «В составе травмированный игрок»; ≥2 игрока не на своей позиции (fit < 0.9) → «N игроков не на своих позициях»; усталость стартового состава < 60 → «Состав устал, подумайте о ротации»; иначе «Команда в порядке и готова к матчу».
- **Состояние команды** (StatCard): средняя мораль (Progress), средняя готовность (Progress), кол-во травм (Badge).

### 5.3. Состав (SquadScreen)

- **Фильтр позиций:** `ToggleGroup` (Все | GK | DEF | MID | FWD — групповые фильтры) + `Select` сортировки (OVR ↓ по умолчанию, Позиция, Возраст, Стоимость, Мораль).
- **Таблица** (`Table`, sticky-header, зебра): № | `OvrBadge` | Имя+возраст | `PositionBadge` | форма (`FormDots` команды) | Готовность (мини-`Progress`) | Мораль (Badge ↑/↓/—) | Стоимость | Зарплата. Клик строки → `PlayerDialog`.
- **PlayerDialog** (`Dialog`): шапка — `OvrBadge` 28px + имя + `[национальность]` + возраст + `PositionBadge` + потенция «⇡ до N» (Badge); сетка 15 атрибутов (`AttributeBar`: подпись + `Progress` цвет ≥80 зелёный / 60–79 жёлтый / <60 серый); экономика: стоимость, зарплата, контракт; состояние: готовность `Progress`, мораль, травма (Badge красный «Травма: N туров»); статистика сезона (Матчи/Голы/Ассисты/Карточки — mini Table); действия: `Button` «В старт» / «В запас» (переключает в lineup/bench — `POST /api/game/tactic`), `Button` destructive «Выставить на продажу» (открывает диалог продажи: `Slider` цены в диапазоне 0.75×–2.5× + Button).
- Валидационные подсказки снизу: «Состав: 20/25 · Минимум соблюдён ✓».

### 5.4. Тактика (TacticsScreen)

- **Выбор формации:** `Select` с 8 пунктами (название + счёт «4-4-2» + мини-подсказка сильных сторон). При смене — слоты переразмечаются, игроки сохраняются по позиционной близости (перенос по совпадению группы слота, остальное в запас).
- **Поле** (`PitchField`, вертикальное, `aspect-ratio ~ 3/4`, газонный градиент `#1A5A2A→#3A8A4A` полосами, разметка: центральная линия, круг, штрафные «мелом» `#F0F0E0`): 11 слотов по координатам формации; `PlayerChip` — круг 44px с OVR + под ним номер/фамилия + `PositionBadge`; цвет рамки: зелёная = fit 1.0, жёлтая = 0.75–0.9, оранжевая = <0.75.
- **Взаимодействие — клик-клик** (мобильный友好, drag&drop НЕ делаем): первый клик по чипу выделяет (рамка-акцент), второй клик по другому чипу/слоту меняет местами / ставит. Клик по чипу запасных — обмен со стартёром.
- **Скамейка:** ряд из 7 `PlayerChip` (упрощённые) под полем; клик — так же.
- **Слайдеры** (`Slider`, 3/5 дискретных позиций, подпись значения справа): Менталитет (5), Темп (3), Прессинг (3), Линия обороны (3). **Стиль игры:** `ToggleGroup`/`RadioGroup` из 5 (обычный/владение/фланги/длинный мяч/контратаки).
- **Индикатор силы:** `Progress` + числа: Атака / Центр / Оборона (по 4.6, пересчёт на клиенте теми же функциями `strength.ts` — модуль изоморфный) + общий `teamStrength` крупно.
- **Кнопки:** «Автосостав» (лучшие 11 по вкладу, `Button` secondary), «Сохранить» (primary; диффы ушли — индикатор несохранённых изменений точкой на кнопке).
- Все изменения хранятся в локальном state экрана; «Сохранить» → `POST /api/game/tactic`.

### 5.5. Матч (MatchScreen)

- **Пре-матч** (`matchView='prematch'`): две колонки составов (компакт: `OvrBadge`+имя+позиция), сравнение силы: три `Progress`-бара (атака/центр/оборона) лицом к лицу, тактика соперника (кратко: формация + менталитет), `Button` primary «Начать матч» (футбольная иконка).
- **Трансляция** (`'live'`): сверху счёт крупно (tabular-nums) + минута; прогресс матча — тонкий `Progress` 0–90; лента `MatchTimeline` (ScrollArea, события появляются снизу, автоскролл): иконки lucide: Goal ⚽→`CircleDot`/Trophy, жёлтая `Square` (жёлтый залив), красная `Square` (красный), травма `Bandage`, момент `Zap`. Скорость: 1 игровая минута = 150 мс; кнопки «×2», «×4» (300/600 мс… наоборот ×2=75 мс) и **«К итогу»** (мгновенно досмотреть).
- **Итог** (`'result'`): счёт, `Table` статистики (владение — двумя полосами-`Progress` навстречу, удары/в створ/угловые/фолы/карточки), события матча (тот же `MatchTimeline` целиком), влияние: изменения морали (Badge), деньги за тур (билеты), `Button` «Продолжить» → `activeTab='dashboard'`.
- Данные: `lastMatch` из стора (ответ `/api/game/simulate`). Никакого поллинга — всё уже посчитано.

### 5.6. Лига (LeagueScreen)

- **Внутренние вкладки** (`Tabs`): «Таблица» | «Календарь».
- **Таблица:** `Table` sticky-header, зебра, колонки: # | Клуб (`TeamCrest`+имя, строка игрока подсвечена) | И | В | Н | П | М (З:П) | ± | О (semibold) | `FormDots`. Цветная полоса слева по зонам (1–3 зелёная «ЛЧ», 4–6 жёлтая «ЛЕ», 14–16 красная «вылет»).
- **Календарь:** селектор тура (`Button`-шевроны ‹ › + «Тур N/30», только сыгранные и текущий для viewing); список 8 матчей тура: счёт (или «vs» если не сыгран), клик по **сыгранному** матчу → `Dialog` с `MatchTimeline` (у ИИ-матчей — только голы) + счёт; матч игрока — полная статистика. Данные: `GET /api/game/match?id=`.

### 5.7. Трансферы (TransfersScreen)

- **Внутренние вкладки** (`Tabs`): «Рынок» | «Мои продажи».
- **Рынок:** панель фильтров: `Select` позиция (Все/GK/DEF/MID/FWD), `Select` «Макс. цена» (≤5M, ≤15M, ≤40M, ≤100M, Все), `Select` «Мин. OVR» (45/55/65/75), `Select` сортировка (OVR/цена/возраст). Таблица: `OvrBadge` | игрок (имя, возраст, `[нац]`) | `PositionBadge` | атрибуты-выжимка (финиш/отбор/скорость — 3 числа) | срок годности лота (`Badge` «N туров») | цена | `Button` «Купить». Клик по строке → `PlayerDialog` (readonly-режим с кнопкой покупки). «Купить» → `AlertDialog` подтверждение (цена, остаток бюджета) → `POST /api/game/market/buy`. Недоступные (дороже бюджета) — кнопка disabled + tooltip «Не хватает бюджета».
- **Мои продажи:** список своих лотов (игрок, запрошенная цена, вероятностная подсказка «интерес высокий/средний/низкий» по формуле 4.12) + секция «Выставить игрока» (mini-таблица состава с кнопкой «Продать» → диалог со `Slider` цены 0.75×–2.5×value и превью «вероятность продажи ~N%»).

### 5.8. Финансы (FinancesScreen)

- **Строка StatCard ×4:** Баланс (красный при < 0), Бюджет трансферов (40%), Недельные зарплаты, Недельный доход (спонсор + ср. билеты).
- **Индикатор здоровья:** `Progress` «Зарплаты / доход» с алертом при > 70% (`Alert` warning).
- **Журнал операций:** `Table` последних 30 `FinanceRecord`: тур | категория (`Badge` с иконкой: спонсор Handshake, билеты Ticket, зарплаты Wallet, трансферы ArrowLeftRight, призовые Trophy) | описание | сумма (+зелёный/−красный, tabular-nums).
- **Сводка сезона:** доходы/расходы нарастающим итогом (2 числа + мини-`Progress` соотношения).

### 5.9. GameShell и page.tsx

- `page.tsx` ('use client'): на маунте `hydrate()`; если `phase='start'` — `StartScreen`; иначе `GameShell` с активным экраном. Загрузка — `Skeleton`-каркас. Ошибка API — `Alert` + кнопка «Повторить».
- `GameShell`: **desktop ≥1024px** — верхняя навигация: логотип (иконка `Trophy` + «ФМ»), 7 пунктов (Дашборд, Состав, Тактика, Матч, Лига, Трансферы, Финансы — `Button` variant ghost/active-primary) + справа `Badge` «Сезон N · Тур N/30» и баланс. **Мобильный <768px** — фиксированный нижний таб-бар из 5: Дашборд, Состав, Тактика, Матч, «Ещё…» (открывает `Sheet` с Лига/Трансферы/Финансы). Контент: `max-w-6xl mx-auto p-4`, тапы ≥44px.
- Экран «Матч» всегда доступен, но кнопка «Играть» активна только пока матч тура не сыгран.

---

## 6. Состояние — Zustand (`src/lib/store.ts`)

```ts
type TabId = 'dashboard' | 'squad' | 'tactics' | 'match' | 'league' | 'transfers' | 'finances';
type Phase = 'start' | 'club-select' | 'playing';
type MatchView = 'prematch' | 'live' | 'result';

interface GameStore {
  // Навигация
  activeTab: TabId;                        // default 'dashboard'
  setTab: (t: TabId) => void;
  // Фаза игры
  phase: Phase;                            // 'start' до создания сейва
  hydrated: boolean;                       // первый GET /state завершён
  loading: boolean;                        // любой запрос в полёте
  error: string | null;
  // Данные (снапшот сервера)
  saveId: string | null;
  managerName: string;
  clubs: ClubDTO[];                        // для экрана выбора (фаза club-select)
  snapshot: GameSnapshot | null;           // основной источник данных экранов
  // Матч
  matchView: MatchView;
  lastMatch: WeekResultPayload | null;     // ответ simulate
  market: MarketListingDTO[];              // кэш рынка для TransfersScreen
  // ── Actions (все ходят через src/lib/game/api.ts) ──
  createGame: (managerName: string) => Promise<void>;   // POST /new → phase='club-select', clubs
  selectClub: (teamId: string) => Promise<void>;        // POST /select → phase='playing' → hydrate
  hydrate: () => Promise<void>;                        // GET /state → snapshot; 404 → phase='start'
  playWeek: () => Promise<void>;                       // POST /simulate → lastMatch, matchView='live', hydrate
  setMatchView: (v: MatchView) => void;                // live → result → prematch
  saveTactics: (payload: TacticPayload) => Promise<void>; // POST /tactic → hydrate
  buyPlayer: (playerId: string) => Promise<void>;      // POST /market/buy → hydrate + market refetch
  listPlayer: (playerId: string, price: number) => Promise<void>; // POST /market/sell → hydrate
  fetchMarket: (filters?: MarketFilters) => Promise<void>;        // GET /market → market
}
```

`GameSnapshot` (ответ GET /state, тип в `types.ts`):

```ts
interface GameSnapshot {
  save: { id, managerName, season, week, totalWeeks: 30, balance, transferBudget, status };
  myTeam: TeamDTO;                 // с тактикой и lineup/bench (id[])
  myPlayers: PlayerDTO[];          // 20–25, сортировка OVR↓
  teams: TeamBriefDTO[];           // 16: id, name, shortName, colors, strength, isUser
  standings: StandingRow[];
  fixtures: FixtureDTO[];          // 8 матчей текущего тура (с счётом, если сыграны)
  nextMatch: FixtureDTO | null;    // матч клуба игрока в текущем туре (null, если тур сыгран)
  news: NewsDTO[];                 // последние 10
  finances: { weeklyWages, weeklyIncome, wageRatio, records: FinanceDTO[] }; // последние 20 записей
  squadWarnings: string[];         // подсказки ассистента для дашборда
}
```

Правила: стор — единственный источник данных для экранов; экраны не делают `fetch` сами (кроме `fetchMarket` через экшен). Все экшены: `loading=true` → запрос → мутация стора → `loading=false`; ошибки → `error` + sonner-toast.

---

## 7. API-контракты (`src/app/api/game/*`)

Общие правила: все роуты — `export async function POST/GET`; тело — JSON, валидация **zod**; клиент Prisma — `import { db } from '@//lib/db'`; успешный ответ — `{ ok: true, ...payload }`, ошибка — `{ ok: false, error: 'КОД' }` со статусом 400/404/409. Никакого z-ai-web-dev-sdk.

| Роут | Метод | Тело/Query | Ответ | Ошибки |
|---|---|---|---|---|
| `/api/game/new` | POST | `{ managerName: string(1..40) }` | `{ ok, saveId, clubs: ClubDTO[16] }` — удаляет старые сейвы, генерирует мир (4.3), status='setup' | 400 `INVALID_NAME` |
| `/api/game/select` | POST | `{ saveId, teamId }` | `{ ok }` — ставит isUserTeam, стартовый баланс, дефолтную тактику 4-4-2 + автосостав, status='active', первая новость-приветствие | 404 `SAVE_NOT_FOUND`, 409 `ALREADY_SELECTED` |
| `/api/game/state` | GET | — | `{ ok, snapshot: GameSnapshot }`; если сейва нет — `{ ok: false, error:'NO_SAVE' }` 404 (клиент → phase='start') | 404 `NO_SAVE` |
| `/api/game/tactic` | POST | `{ lineup: string[11], bench: string[≤7], formation, mentality, tempo, pressing, defLine, playStyle }` | `{ ok, teamStrength }` | 400 `INVALID_LINEUP` (не 11/дубли/травмированный/чужой игрок), 404 `NO_SAVE` |
| `/api/game/simulate` | POST | `{}` | `{ ok, result: WeekResultPayload }` (ниже) | 409 `WEEK_ALREADY_PLAYED`, 404 `NO_SAVE` |
| `/api/game/market` | GET | `?position=&maxPrice=&minOvr=&sort=` | `{ ok, listings: MarketListingDTO[] }` (≤70) | — |
| `/api/game/market/buy` | POST | `{ playerId }` | `{ ok, snapshot }` (обновлённый) | 409 `NOT_FOR_SALE / SQUAD_FULL / INSUFFICIENT_BUDGET` |
| `/api/game/market/sell` | POST | `{ playerId, price }` | `{ ok, snapshot }` | 409 `SQUAD_MIN_VIOLATION / PRICE_OUT_OF_BAND / PLAYER_INJURED`, 400 `NOT_YOUR_PLAYER` |
| `/api/game/match` | GET | `?id=` | `{ ok, match: { teams, счёт, events, stats } }` | 404 `MATCH_NOT_FOUND` |

**WeekResultPayload** (ответ `/simulate`):

```ts
{
  userMatch: { matchId, home: TeamBriefDTO, away: TeamBriefDTO, homeGoals, awayGoals,
               events: MatchEvent[], stats: MatchStats | null },
  weekResults: { homeId, awayId, homeGoals, awayGoals }[],   // все 8 матчей тура
  finances: { wages, sponsor, tickets, net },                 // изменения за тур
  news: NewsDTO[],                                            // новости тура
  transfers: string[],                                        // тексты сделок (покупки ИИ, продажа своих)
  seasonEnded: { standings: StandingRow[], place, prize } | null
}
```

---

## 8. Поток данных — цикл игры

```
СТАРТ
  page.tsx mount → GET /api/game/state
   ├─ 404 NO_SAVE → phase='start' → StartScreen
   │     «Начать карьеру» → POST /new (генерация мира) → phase='club-select'
   │     выбор клуба → POST /select (баланс, тактика по умолчанию, автосостав)
   └─ 200 → phase='playing' → snapshot → Дашборд

НЕДЕЛЬНЫЙ ЦИКЛ (тур N = 1..30)
  1. ПОДГОТОВКА (клиент, без запросов):
     Состав (PlayerDialog: в старт/в запас) · Тактика (поле+слайдеры → POST /tactic)
     Трансферы (POST /market/buy, /market/sell — можно в любой момент)
  2. МАТЧ: Дашборд/Матч → «Сыграть матч» → POST /simulate
     сервер (одна транзакция): автосоставы ИИ → матч игрока (4.8) → 7 матчей ИИ
       → пост-матч (мораль/состояние/статистика) → финансы (зарплаты/спонсор/билеты)
       → рынок (истечение, догенерация, офферы, покупки ИИ) → новости
       → week++ (или сезонный переход 4.11)
     ответ → store.lastMatch → MatchScreen 'live' (клиентский «показ» событий)
     «Продолжить» → hydrate() → Дашборд (обновлённые таблица/новости/финансы)
  3. Сезон закончен (week > 30): в payload приходит seasonEnded
     → экран Итоги сезона (Dialog на дашборде: место, призовые) → новый сезон, week=1

ПРАВИЛА ЦИКЛА:
  - «Сыграть матч» доступна только если nextMatch != null (тур не сыгран);
    после симуляции до следующего тура игрок свободно ходит по вкладкам.
  - Все мутации идут через API; клиент всегда ре-гидрируется из GET /state.
  - Слом сети: error + toast, состояние не портится (сервер — источник истины).
```

---

## 9. Дизайн-токены (`globals.css`, тема «стадион под прожекторами»)

Заменить секцию `:root` (shadcn CSS-переменные, тёмная тема, **без синего/индиго**):

```css
:root {
  --background: #0D1210;          /* фон страницы */
  --foreground: #F0F0E0;          /* меловой текст */
  --card: #151D18;                /* поверхности */
  --card-foreground: #F0F0E0;
  --popover: #151D18;
  --popover-foreground: #F0F0E0;
  --primary: #2E9E5B;             /* акцент «газон» — только интерактив */
  --primary-foreground: #0D1210;
  --secondary: #1C2620;           /* углубления: таблицы, инпуты */
  --secondary-foreground: #F0F0E0;
  --muted: #1C2620;
  --muted-foreground: #93A39A;    /* подписи, метаданные */
  --accent: #37B96B;              /* hover-оттенок акцента */
  --accent-foreground: #0D1210;
  --destructive: #F87171;         /* поражение, вылет, минус */
  --border: #2A382F;
  --input: #1C2620;
  --ring: #2E9E5B;
  --radius: 0.5rem;
  /* игровые доп. цвета */
  --success: #4ADE80;  --warning: #FACC15;  --gold: #EAB308;
  --field-a: #1A5A2A;  --field-b: #3A8A4A;  /* газонный градиент поля */
}
```

Утилиты (добавить в globals.css): `.tabular { font-variant-numeric: tabular-nums; }`,
`.pitch { background: repeating-linear-gradient(180deg, var(--field-a) 0 12.5%, var(--field-b) 12.5% 25%); }`.

Прочие правила темы:
- Шрифт: **Inter** (next/font/google), замена Geist в `layout.tsx`; `lang="ru"`; metadata: title «Футбольный Менеджер», description «Браузерный футбольный менеджер: лига, трансферы, тактика».
- `OvrBadge` цвет числа: ≥85 `#EAB308` (золото), 75–84 `#4ADE80`, 65–74 `#93A39A`, <65 `#F87171`.
- `PositionBadge` цвета: GK `#FACC15`, DEF `#8FA3AD` (приглушённый серо-голубой — единственный «холодный», это транспортная кодировка из исследования), MID `#4ADE80`, FWD `#FB923C` (тёплый оранжевый).
- `AttributeBar` цвет полосы: ≥80 `#4ADE80`, 60–79 `#FACC15`, <60 `#93A39A`.
- Таблицы: зебра `rgba(255,255,255,0.02)`, sticky-header, все числа `.tabular`.
- Акцент `#2E9E5B` — только интерактив и данные; большие поверхности — `--card`/`--secondary`.

---

## 10. План реализации (порядок для Агента-Разработчика, Task 3)

Порядок строго снизу вверх: данные → логика → API → компоненты → сборка. Каждый шаг компилируем и проверяем самостоятельно.

| # | Файл(ы) | Что делаем | Объём |
|---|---|---|---|
| 1 | `prisma/schema.prisma` | Заменить схемой из раздела 3; `bun run db:push` | XS (15 мин) |
| 2 | `src/lib/game/constants.ts`, `types.ts` | Все константы (4.1) и типы (MatchEvent, DTO, Snapshot, StandingRow и т.д.) | S (40 мин) |
| 3 | `src/lib/game/data.ts` | Массивы имён/городов/цветов/шаблонов (4.3) | S (30 мин) |
| 4 | `src/lib/game/rng.ts`, `poisson.ts` | mulberry32, gauss, hash, samplePoisson (4.2) | XS (20 мин) |
| 5 | `src/lib/game/players.ts`, `generate.ts` | Генерация игрока/состава/лиги/календаря (4.3–4.4); unit-проверка: 16 команд, 20–22 игрока, 240 матчей | M (90 мин) |
| 6 | `src/lib/game/strength.ts` | Вклад игрока, линии, модификаторы (4.6–4.7); проверка: силы в шкале 50..90, 5-3-2 > 4-4-3 по обороне | M (60 мин) |
| 7 | `src/lib/game/match.ts` | Полный движок матча (4.8); проверка: 1000 прогонов равных команд → ~25% ничьих, счёт 0–5 реалистичен | M (90 мин) |
| 8 | `src/lib/game/progression.ts`, `finances.ts`, `transfers.ts`, `standings.ts` | Пост-матч, сезоны, экономика, таблица (4.10–4.14) | M (90 мин) |
| 9 | `src/lib/game/week.ts` | Оркестратор тура (4.9) — вся транзакция | M (90 мин) |
| 10 | API-роуты (9 файлов) | Контракты раздела 7 + zod | M (90 мин) |
| 11 | `globals.css`, `layout.tsx` | Токены темы, Inter, ru, metadata (раздел 9) | XS (20 мин) |
| 12 | `src/lib/game/api.ts`, `src/lib/store.ts` | Клиент + стор (раздел 6) | S (45 мин) |
| 13 | `components/game/shared/*` (7 файлов) | Позиционные бейджи, OVR, полосы, точки, гербы, StatCard | S (60 мин) |
| 14 | `StartScreen.tsx` + `ClubCard.tsx` | Стартовый флоу | S (45 мин) |
| 15 | `GameShell.tsx` + `page.tsx` | Каркас навигации, фазы, скелетоны | S (45 мин) |
| 16 | `SquadScreen.tsx` + `PlayerDialog.tsx` | Таблица + карточка игрока | M (90 мин) |
| 17 | `TacticsScreen.tsx` + `PitchField.tsx` + `PlayerChip.tsx` | Поле, клик-клик, слайдеры, сила | L (120 мин) |
| 18 | `MatchScreen.tsx` + `MatchTimeline.tsx` | Пре-матч/лайв/итог с таймером показа | M (90 мин) |
| 19 | `LeagueScreen.tsx` | Таблица + календарь + диалог матча | M (60 мин) |
| 20 | `TransfersScreen.tsx` | Рынок + продажи | M (75 мин) |
| 21 | `FinancesScreen.tsx` | Баланс/ведомость/журнал | S (45 мин) |
| 22 | Финальная сборка | Проверка всего цикла: новая игра → 30 туров → новый сезон; dev-сервер без ошибок | S (30 мин) |

Суммарно ~16–18 часов агентской работы. Критерии готовности MVP (для QA, Task 4): полный цикл «новая игра → выбор клуба → 30 туров → сезон №2» без ошибок; матч игрока даёт ленту событий и статистику; таблица совпадает с суммой результатов; покупки/продажи меняют баланс и состав с валидациями; палитра без синего; все экраны работают на мобильной ширине (375px).

## 11. Что НЕ делаем в MVP (задел V1.1+)

Замены в матче по ходу игры и live-вмешательство; тренировки с прокачкой; торг по трансферам и трансферные окна; бомбардиры лиги; несколько сейвов/мультиплеер; скаутинг, академия, персонал, апгрейды стадиона; 3D/2D-визуализация; кубки; монетизация. Архитектура это допускает: поля тактики расширяемы, `events` — JSON-массив, `FinanceRecord.category` — открытый список.

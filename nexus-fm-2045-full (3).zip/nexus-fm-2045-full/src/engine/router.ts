/**
 * Виртуальный API движка (спека §1.5, этап D-4): карта «эндпоинт-метод →
 * хендлер» — порт логики серверных route.ts 1:1 (та же zod-валидация, те же
 * коды ApiGameError и статусы, те же DTO-ответы). HTTP-обвязка выброшена:
 * движок живёт в процессе клиента, «запрос» — plain-объект EngineRequest
 * (query-параметры и body — полями объекта).
 *
 * Слоты (§2): каждый saveId живёт в своём слоте; хендлеры начинают с
 * ensureSlotFor(saveId) — ленивая «селект»-семантика (engine.loadSlot), когда
 * запрошенная карьера ещё не активна. Легаси-фолбэк «без saveId» (Фаза 1)
 * адресуется к активному слоту — как resolveSave(null) в api-helpers.
 *
 * Автосейв/rollback (§2.3): хендлеры-мутации вызывают markDirty() — запись
 * слота планируется в microtask ПОСЛЕ ответа (single-flight, не стартует,
 * пока выполняются хендлеры); непредвиденная ошибка — откат перезагрузкой
 * активного слота (engine.reload). GET /state — touch lastOpenedAt (как роут)
 * + автосейв. POST /saves / DELETE / PATCH записывают себя сами через фасад.
 *
 * Легаси POST /new не портируется (§1.5: фронт не использует; setup-сейвы без
 * клуба несовместимы со слот-моделью §2.1 — карточка карьеры требует клуб) —
 * полная замена это POST /saves. POST /select — движковая семантика: загрузить
 * слот по saveId + touch lastOpenedAt.
 */

import { z } from 'zod';
import {
  buildEuroSnapshot, buildSnapshot, getEngine, matchPlanOf, normalizeErrorCode,
  resolvePlayingSave, resolveSave, simulateWeek,
} from './index';
import { db, type EngineOp } from './db';
import type { TeamRecord } from './models';
import {
  BUILDING_IDS, BUILDING_MAX_LEVEL, absoluteDayOf, buildingById, daysOf, parseBuildings,
  priceOf, scoutSlotsBonus, serializeBuildings,
} from './buildings';
import {
  ASSETS, MANAGER_PRESTIGE_MARKET_DISCOUNT, MANAGER_PRESTIGE_MARKET_STAR,
  MANAGER_SON_ACADEMY_AGE, assetById, boardWarnBelowOf, clampPrestige, contractsPrestigeMult,
  createManagerState, managerMarketPrice, netWeeklyOf, parseManager, prestigeLabelOf,
  sellPrestigeOf, sellPriceOf, serializeManager, type ManagerState,
} from './manager';
import { PRESS_ARCHIVE_LIMIT, parseMoments, parseMotm } from './press';
import { boardDtoOf, toPlayerDTO, toScoutedPlayerDTO, toTeamBrief } from './snapshot';
import {
  stadiumDaysOf, stadiumFits, stadiumPriceOf, type StadiumSeats,
} from '@/lib/game/stadium';
import { ApiGameError } from '@/lib/game/error';
import { buildSeasonPlan, cupRoundsOf } from '@/lib/game/calendar';
import {
  CONTRACT_MAX_YEARS, CONTRACT_MIN_YEARS, CONTRACT_OFFER_MAX_RATIO,
  CONTRACT_OFFER_MIN_RATIO, CONTRACT_RENEWABLE_YEARS_LEFT, LISTING_TTL, SALARY_ROUND,
  SQUAD_MAX, START_BALANCE_BASE, START_BALANCE_PER_STRENGTH, TRAIN_CONDITION_DELTA,
  TRAIN_INJURY_RISK, TRAIN_INTENSITY_FACTOR, TRAIN_REST_COND, TRAIN_REST_MORALE,
  TRANSFER_BUDGET_RATIO, coerceDefLine, coerceFormation, coerceMentality, coercePlayStyle,
  coercePressing, coerceTempo,
} from '@/lib/game/constants';
import { LEAGUES, leagueAvgStrength, leagueByCode } from '@/lib/game/leagues';
import {
  autoLineup, broadGroupOf, canSellPlayer, freeShirtNumber, isLineupValid,
  type PlayerLike,
} from '@/lib/game/players';
import { computeLines } from '@/lib/game/strength';
import {
  ATTR_LABELS, AWARD_TYPE_LABELS, parseEvents, parseLineup, parseMatchPlan, parseStats,
  parseTrainingXp,
} from '@/lib/game/types';
import {
  bosmanProbability, bosmanRiskOf, contractUntilFromYears, contractYearsRoll, maxRenewYears,
  ovrRankOf, renewDemand, renewalOutcome, teamAppsOf, yearsLeftOf,
} from '@/lib/game/contracts';
import { sellPriceBounds } from '@/lib/game/transfers';
import { aiSigningSalaryOf } from '@/lib/game/ai-market';
import {
  CONTRACT_RANK_STAR, INCOMING_OFFER_REJECT_MORALE_HIT, INCOMING_OFFER_UNHAPPY_MORALE,
  SCOUT_BUY_KNOWLEDGE,
} from '@/lib/game/constants';
import { knowledgeTierOf, scoutSlotsOf } from '@/lib/game/scouting';
import { evaluateSigningOffer, signingDemandOf } from '@/lib/game/negotiation';
import {
  staffRoleFull, staffTrainingEffectsOf, staffWagesOf, type StaffLikeRecord,
} from '@/lib/game/staff';
import {
  staffFireCompensationOf, staffHireBonusOf, staffRenewSalaryOf, validStaffYears,
} from '@/lib/game/staff-market';
import { STAFF_FIRE_MIN_WEEKS, STAFF_ROLE_MAX } from '@/lib/game/constants';
import type { StaffRecord } from './models';
import { liveCupScorers, liveEuroScorers, liveLeaders, type LeaderTeamInfo } from '@/lib/game/awards';
import { careerTotalsOf, type SeasonRecordRow } from '@/lib/game/history';
import {
  FOCUS_ATTRS, TRAINING_FOCUS_LABELS, TRAINING_INTENSITY_LABELS, attrsForPlayer,
  coerceTrainingFocus, coerceTrainingIntensity,
} from '@/lib/game/training';
import { starsOf } from '@/lib/game/academy';
import { hashString, mulberry32 } from '@/lib/game/rng';
import type {
  AcademyPlayerDTO, AcademyResponse, AwardsResponse, BoardResponse, ContractInfoDTO,
  ContractsResponse, EuroResponse, FormationId, LeagueCatalogDTO, LeagueClubDTO, MarketListingDTO,
  MarketPositionFilter, MarketSort, MatchDetailsDTO, MatchPlanDTO, MatchPlanResponse, Mentality,
  ManagerAssetResponse, ManagerDTO, ManagerResponse, MediaResponse, NewspaperClippingDTO,
  NewsDTO, NegotiationDTO, PlayStyle, PlayerDialogDTO, PlayerDialogResponse, PlayerHistoryDTO,
  PlayerLeaderDTO, Position, PressCompetition, PressMomentDTO, PressMotmDTO, ScoutReportDTO,
  ScoutResponse, SeasonAwardDTO, SetMatchPlanResponse, StadiumResponse, TrainingFocus,
  TrainingHintsDTO, TrainingIntensity, TrainingPlayerDTO, TrainingStateDTO, TransferOfferDTO,
  TransferOffersResponse, StaffActionResponse, StaffDTO, StaffResponse, StaffRole,
  SetPlayerTrainingResponse,
} from '@/lib/game/types';
import type { AttrKey } from '@/lib/game/types';

// ── Модуль 3: единая абсолютная неделя для ScoutReport/TransferOffer ────────

/** Абсолютная неделя сейва (та же шкала, что absoluteWeekOf в недельном цикле). */
function absWeekOfSave(save: { leagueCode: string; season: number; week: number }): number {
  const plan = buildSeasonPlan(save.leagueCode);
  return (save.season - 1) * plan.totalWeeks + save.week;
}

// ── Модуль 4: сборка ответа персонала (GET /staff + hire/fire/renew) ────────

const STAFF_ROLE_ORDER: StaffRole[] = ['head_coach', 'assistant', 'fitness', 'physio', 'scout'];

function staffDtoOf(s: StaffRecord, season: number, employed: boolean): StaffDTO {
  return {
    id: s.id,
    role: s.role as StaffRole,
    firstName: s.firstName,
    lastName: s.lastName,
    nationality: s.nationality,
    age: s.age,
    rating: s.rating,
    specialty: s.specialty,
    salary: s.salary,
    contractUntil: s.contractUntil,
    yearsLeft: employed ? Math.max(0, s.contractUntil - season + 1) : 0,
  };
}

/** Полный снимок штата/рынка/эффектов/слотов (без ok). */
async function buildStaffPayload(saveId: string): Promise<Omit<StaffResponse, 'ok'>> {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, include: { team: true } });
  if (!save || !save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

  const staffRows = await db.staff.findMany({ where: { saveId, teamId: save.teamId } });
  const marketRows = await db.staff.findMany({ where: { saveId, teamId: null } });

  const staffLike = staffRows as unknown as StaffLikeRecord[];
  const effects = staffTrainingEffectsOf(staffLike);

  // слоты наблюдения скаутов (использовано = активные отчёты);
  // Модуль 5: бонус слотов от скаут-центра клуба игрока
  const reports = await db.scoutReport.findMany({ where: { saveId } });
  const scoutCount = staffRows.filter((s) => s.role === 'scout').length;
  const used = reports.filter((r) => r.watched).length;
  const centerBonus = scoutSlotsBonus(parseBuildings(save.team?.buildings ?? null).scoutcenter.level);

  return {
    season: save.season,
    week: save.week,
    staff: staffRows
      .map((s) => staffDtoOf(s, save.season, true))
      .sort((a, b) => STAFF_ROLE_ORDER.indexOf(a.role) - STAFF_ROLE_ORDER.indexOf(b.role) || b.rating - a.rating),
    market: marketRows
      .map((s) => staffDtoOf(s, save.season, false))
      .sort((a, b) => STAFF_ROLE_ORDER.indexOf(a.role) - STAFF_ROLE_ORDER.indexOf(b.role) || b.rating - a.rating),
    effects: {
      xpMult: effects.xpMult,
      youthXpMult: effects.youthXpMult,
      injuryRiskMult: effects.injuryRiskMult,
      recoveryBonus: effects.recoveryBonus,
      healChance: effects.healChance,
      bestScoutRating: effects.bestScoutRating,
      scoutSlots: { used, total: scoutSlotsOf(scoutCount, centerBonus) },
    },
    slots: STAFF_ROLE_ORDER.map((role) => ({
      role,
      used: staffRows.filter((s) => s.role === role).length,
      max: STAFF_ROLE_MAX[role] ?? 1,
    })),
    weeklyWages: staffWagesOf(staffLike),
    balance: save.balance,
  };
}

// ── Контракт диспетчера (§1.5) ─────────────────────────────────────────────

/** Виртуальный запрос: query-параметры и body — полями объекта. */
export interface EngineRequest {
  saveId?: string | null;
  [key: string]: unknown;
}

/** Хендлер виртуального роута: бросает ApiGameError(code, httpStatus). */
export type EngineHandler = (req: EngineRequest) => Promise<unknown>;

// ── zod-схемы (порты из route.ts как есть, §6.2) ───────────────────────────

const savesPostSchema = z.object({
  leagueCode: z.string().trim().min(1),
  clubIndex: z.number().int(),
  managerName: z.string().trim(),
  careerName: z.string().trim().optional(),
});

const savesPatchSchema = z.object({
  careerName: z.string().trim(),
});

const simulateSchema = z.object({
  saveId: z.string().min(1),
});

const matchplanPostSchema = z.object({
  saveId: z.string().min(1).optional(),
  leadMode: z.enum(['park', 'hold']).optional(),
  chaseMode: z.enum(['allout', 'steady']).optional(),
  fatigueSubs: z.boolean().optional(),
});

const tacticSchema = z.object({
  saveId: z.string().min(1).optional(),
  formation: z.enum(['4-4-2', '4-3-3', '4-2-3-1', '4-5-1', '3-5-2', '5-3-2', '4-1-4-1', '3-4-3']).optional(),
  mentality: z.enum(['defensive', 'cautious', 'balanced', 'attacking', 'allout']).optional(),
  tempo: z.enum(['low', 'medium', 'high']).optional(),
  pressing: z.enum(['low', 'medium', 'high']).optional(),
  defLine: z.enum(['low', 'medium', 'high']).optional(),
  playStyle: z.enum(['balanced', 'wing', 'passing', 'long', 'counter']).optional(),
  lineup: z.array(z.string()).length(11).optional(),
  bench: z.array(z.string()).max(7).optional(),
});

const trainingPostSchema = z.object({
  saveId: z.string().min(1),
  focus: z.enum(['attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest']),
  intensity: z.enum(['light', 'normal', 'hard']),
});

// ── Модуль 4: персонал и индивидуальные программы ──

const staffHireSchema = z.object({
  saveId: z.string().min(1).optional(),
  staffId: z.string().min(1),
  years: z.number().int(),
});

const staffFireSchema = z.object({
  saveId: z.string().min(1).optional(),
  staffId: z.string().min(1),
});

const trainingPlayerPostSchema = z
  .object({
    saveId: z.string().min(1).optional(),
    playerId: z.string().min(1),
    focus: z.enum(['attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest']).nullable(),
    intensity: z.enum(['light', 'normal', 'hard']).nullable(),
  })
  .refine((v) => (v.focus === null) === (v.intensity === null), {
    message: 'программа задаётся парой focus+intensity (или оба null — сброс)',
  });

const marketBuySchema = z
  .object({
    saveId: z.string().min(1).optional(),
    playerId: z.string().min(1).optional(),
    listingId: z.string().min(1).optional(),
    // ── Модуль 3: контрактное предложение (переговоры). Все четыре поля
    // должны прийти вместе; без них — легаси-автоподписание (Фаза 1). ──
    salary: z.number().int().min(0).optional(),
    years: z.number().int().min(CONTRACT_MIN_YEARS).max(CONTRACT_MAX_YEARS).optional(),
    goalBonus: z.number().int().min(0).optional(),
    cleanSheetBonus: z.number().int().min(0).optional(),
  })
  .refine((v) => v.playerId !== undefined || v.listingId !== undefined, {
    message: 'playerId или listingId обязателен',
  })
  .refine((v) => {
    const hasAny = v.salary !== undefined || v.years !== undefined
      || v.goalBonus !== undefined || v.cleanSheetBonus !== undefined;
    const hasAll = v.salary !== undefined && v.years !== undefined
      && v.goalBonus !== undefined && v.cleanSheetBonus !== undefined;
    return !hasAny || hasAll;
  }, { message: 'контрактные поля передаются вместе' });

const marketSellSchema = z.object({
  saveId: z.string().min(1).optional(),
  playerId: z.string().min(1),
  price: z.number().int().positive(),
});

// ── Модуль 3: скаутинг и входящие офферы ──────────────────────────────────

const scoutWatchSchema = z.object({
  saveId: z.string().min(1).optional(),
  playerId: z.string().min(1),
});

const transferOfferSchema = z.object({
  saveId: z.string().min(1).optional(),
  offerId: z.string().min(1),
});

const contractsRenewSchema = z.object({
  saveId: z.string().min(1),
  playerId: z.string().min(1),
  years: z.number().int().min(CONTRACT_MIN_YEARS).max(CONTRACT_MAX_YEARS),
  salary: z.number().int().min(0),
});

// D-5 «Территория» (§3.6): saveId опционален — легаси-фолбэк активного слота
const buildingsPostSchema = z.object({
  saveId: z.string().min(1).optional(),
  buildingId: z.string().min(1),
});

// Модуль 5 (§ «Инфраструктура 2.0»): запуск расширения стадиона — блок трибун
// из каталога 3000/5000/8000 мест; saveId опционален (легаси-фолбэк слота)
const stadiumPostSchema = z.object({
  saveId: z.string().min(1).optional(),
  seats: z.union([z.literal(3000), z.literal(5000), z.literal(8000)]),
});

// D-6 «Тренер» (§4.6): покупка/продажа актива — saveId опционален (легаси-фолбэк)
const managerAssetPostSchema = z.object({
  saveId: z.string().min(1).optional(),
  assetId: z.string().min(1),
  action: z.enum(['buy', 'sell']),
});

// ── D-6 «Тренер»: состояние менеджера сейва (ленивая инициализация §4.5) ──

/** Загрузить ManagerState сейва (легаси null → дефолт по stature клуба). */
async function loadManagerState(save: {
  id: string;
  manager: string | null;
  teamId: string | null;
}): Promise<{ manager: ManagerState; team: TeamRecord }> {
  if (save.teamId === null) throw new ApiGameError('SAVE_NOT_FOUND', 404);
  const team = await db.team.findUnique({ where: { id: save.teamId } });
  if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);
  return {
    manager: parseManager(save.manager, team.strength) ?? createManagerState(team.strength),
    team,
  };
}

/** ManagerDTO (§4.6): всё посчитано в движке — UI ничего не считает. */
function managerDtoOf(
  save: { managerName: string; season: number },
  teamName: string,
  manager: ManagerState,
): ManagerDTO {
  return {
    name: save.managerName,
    clubName: teamName,
    season: save.season,
    age: manager.age,
    wallet: manager.wallet,
    salary: manager.salary,
    // ×10 → отображение с 1 знаком (400 → 40.0)
    prestige: Math.round(manager.prestige) / 10,
    prestigeLabel: prestigeLabelOf(manager.prestige),
    assets: ASSETS.map((spec) => ({
      id: spec.id,
      name: spec.name,
      category: spec.category,
      price: spec.price,
      prestige: spec.prestige,
      upkeepWeekly: spec.upkeep,
      owned: manager.assets.includes(spec.id),
      sellPrice: sellPriceOf(spec),
    })),
    family: (manager.family.marriedAtWeek !== null || manager.family.child !== null)
      ? {
          marriedAtWeek: manager.family.marriedAtWeek,
          spouseName: manager.family.spouseName,
          child: manager.family.child === null ? null : {
            name: manager.family.child.name,
            gender: manager.family.child.gender,
            age: manager.family.child.age,
            bornAtWeek: manager.family.child.bornAtWeek,
            joinedAcademyPlayerId: manager.family.child.joinedAcademyPlayerId,
            seasonsToAcademy: manager.family.child.joinedAcademyPlayerId === null
              ? Math.max(0, MANAGER_SON_ACADEMY_AGE - manager.family.child.age)
              : null,
          },
        }
      : null,
    netWeekly: netWeeklyOf(manager),
    effects: {
      contractsDemandMult: contractsPrestigeMult(manager.prestige),
      marketDiscount: manager.prestige >= MANAGER_PRESTIGE_MARKET_DISCOUNT,
      marketStarPremium: manager.prestige < MANAGER_PRESTIGE_MARKET_STAR,
      boardWarnBelow: boardWarnBelowOf(manager.prestige),
    },
  };
}

// ── Разбор «query» из EngineRequest ───────────────────────────────────────

/** Строковый параметр запроса (аналог searchParams.get; null — отсутствует). */
function queryStr(req: EngineRequest, key: string): string | null {
  const v = req[key];
  return typeof v === 'string' ? v : null;
}

/** saveId запроса: trim, пусто/отсутствует → null (как saveIdFromQuery). */
function saveIdOf(req: EngineRequest): string | null {
  const raw = queryStr(req, 'saveId');
  const value = raw?.trim();
  return value ? value : null;
}

/**
 * Ленивая «селект»-семантика (§1.6): убедиться, что слот с saveId активен.
 * null — легаси-фолбэк (активный слот должен быть уже загружен; нет — 404,
 * как legacyActiveSave → null в роутах). quiet — слот не найден не бросает
 * (изоляция GET /match сама даст MATCH_NOT_FOUND, как роут на общей БД).
 */
async function ensureSlotFor(
  saveId: string | null,
  options: { quiet?: boolean } = {},
): Promise<string | null> {
  const engine = getEngine();
  if (saveId === null) {
    if (!engine.store && !options.quiet) throw new ApiGameError('SAVE_NOT_FOUND', 404);
    return null;
  }
  if (engine.saveId === saveId) return saveId;
  const metas = await engine.listSlots();
  const meta = metas.find((m) => m.card.id === saveId);
  if (!meta) {
    if (options.quiet) return null;
    throw new ApiGameError('SAVE_NOT_FOUND', 404);
  }
  await engine.loadSlot(meta.slot);
  return saveId;
}

// ── Автосейв (§2.3): markDirty → microtask → engine.saveSlot ──────────────

let dirty = false;
let saving: Promise<void> | null = null;
/** Глубина выполнения хендлеров: сейв не стартует, пока > 0 (§1.6/§2.3). */
let mutatingDepth = 0;

/** Пометить активную карьеру «грязной» — автосейв после ответа хендлера. */
function markDirty(): void {
  dirty = true;
  queueMicrotask(() => {
    void flushSave();
  });
}

/** Single-flight запись активного слота; ошибки — повтор при следующей мутации. */
async function flushSave(): Promise<void> {
  const engine = getEngine();
  if (!engine.store) {
    dirty = false; // активной карьеры нет — сохранять нечего
    return;
  }
  if (mutatingDepth > 0 || saving || !dirty) return;
  dirty = false;
  const run = (async () => {
    try {
      await engine.saveSlot();
    } catch (error) {
      console.error('[engine] автосейв не удался (повтор при следующей мутации)', error);
      dirty = true;
    } finally {
      saving = null;
      if (dirty) queueMicrotask(() => { void flushSave(); });
    }
  })();
  saving = run;
  await run;
}

/** Откат активного слота с диска при непредвиденной ошибке хендлера (§1.6). */
async function rollbackActiveSlot(): Promise<void> {
  try {
    const engine = getEngine();
    if (engine.store) {
      dirty = false;
      await engine.reload();
    }
  } catch (error) {
    console.error('[engine] rollback не удался', error);
  }
}

// ── Карта роутов (§1.5) ────────────────────────────────────────────────────

export const engineRoutes: Record<string, EngineHandler> = {
  // ── Каталог и карьеры ──
  'GET /leagues': async () => {
    const leagues: LeagueCatalogDTO[] = LEAGUES.map((def) => {
      const clubs: LeagueClubDTO[] = def.clubs.map((club, index) => ({
        index,
        name: club.name,
        city: club.city,
        shortName: club.short,
        colorPrimary: club.c1,
        colorSecondary: club.c2,
        strength: club.str,
        stadiumCapacity: club.cap,
        startBalance:
          START_BALANCE_BASE + Math.max(0, club.str - 55) * START_BALANCE_PER_STRENGTH,
      }));
      return {
        code: def.code,
        nameRu: def.nameRu,
        nameEn: def.nameEn,
        country: def.country,
        flag: def.flag,
        teamCount: def.teamCount,
        leagueWeeks: def.leagueWeeks,
        cupRounds: cupRoundsOf(def.teamCount),
        cupName: def.cupName,
        avgStrength: leagueAvgStrength(def),
        difficulty: def.difficulty,
        clubs,
      };
    });
    return { ok: true as const, leagues };
  },

  /** Карточки занятых слотов из meta.json (+конверт), сортировка как GET /saves. */
  'GET /saves': async () => {
    const metas = await getEngine().listSlots();
    const saves = metas.map((m) => m.card);
    return { ok: true as const, saves };
  },

  /** Создание карьеры: валидация + генерация + слот + активация (career.ts). */
  'POST /saves': async (req) => {
    const parsed = savesPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_PAYLOAD', 400);
    const { leagueCode, clubIndex, managerName, careerName } = parsed.data;

    // createCareer: порядок валидации и коды — как POST /saves
    // (INVALID_LEAGUE → INVALID_NAME → INVALID_CAREER_NAME; лимит 8 слотов —
    // SAVE_LIMIT_REACHED 409 в slots.create). Слот пишется созданием.
    const result = await getEngine().createCareer({ leagueCode, clubIndex, managerName, careerName });

    return {
      ok: true as const,
      saveId: result.saveId,
      careerName: result.careerName,
      league: result.league,
      club: result.club,
      ...(result.save ? { save: result.save } : {}),
    };
  },

  /** Переименование (1–60): meta сразу, careerName в слоте — лениво (§2.2). */
  'PATCH /saves/:id': async (req) => {
    const id = queryStr(req, 'id') ?? '';
    const parsed = savesPatchSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_CAREER_NAME', 400);
    const careerName = parsed.data.careerName;
    if (careerName.length < 1 || careerName.length > 60) {
      throw new ApiGameError('INVALID_CAREER_NAME', 400);
    }

    const engine = getEngine();
    const metas = await engine.listSlots();
    const meta = metas.find((m) => m.card.id === id);
    if (!meta) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    await engine.renameSlot(meta.slot, careerName);
    return { ok: true as const };
  },

  /** Удаление слота каскадом (in-memory хранилище одно на слот; активный — unload). */
  'DELETE /saves/:id': async (req) => {
    const id = queryStr(req, 'id') ?? '';
    const engine = getEngine();
    const metas = await engine.listSlots();
    const meta = metas.find((m) => m.card.id === id);
    if (!meta) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    await engine.removeSlot(meta.slot);
    return { ok: true as const };
  },

  // ── Игра ──
  'GET /state': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    const statusOk = save.status === 'active' || save.status === 'finished';
    if (!statusOk || !save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    // Touch lastOpenedAt (сортировка «недавно открытые») — как роут; персистентность
    // через автосейв (§2.3: GET /state — триггер сохранения).
    await getEngine().touchSlot(new Date());
    markDirty();

    const snapshot = await buildSnapshot(save.id);
    return { ok: true as const, snapshot };
  },

  'POST /simulate': async (req) => {
    const parsed = simulateSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_PAYLOAD', 400);

    const saveId = await ensureSlotFor(parsed.data.saveId);
    const save = await resolvePlayingSave(saveId);
    const result = await simulateWeek(save.id);
    markDirty(); // §2.3: всегда после успешной симуляции
    return { ok: true as const, result };
  },

  'GET /match': async (req) => {
    const id = queryStr(req, 'id') ?? '';
    if (!id) throw new ApiGameError('MATCH_NOT_FOUND', 404);

    // Изоляция карьер: матч обязан принадлежать saveId. Слот под saveId лениво
    // загружается (quiet: неизвестный saveId → матч не найден, как в роуте).
    const saveId = saveIdOf(req);
    if (!getEngine().store && saveId === null) {
      throw new ApiGameError('MATCH_NOT_FOUND', 404); // нет активной карьеры — БД пуста
    }
    const ensured = await ensureSlotFor(saveId, { quiet: true });

    const match = await db.match.findUnique({ where: { id } });
    if (!match) throw new ApiGameError('MATCH_NOT_FOUND', 404);
    if (ensured && match.saveId !== ensured) throw new ApiGameError('MATCH_NOT_FOUND', 404);

    const home = await db.team.findUnique({ where: { id: match.homeTeamId } });
    const away = await db.team.findUnique({ where: { id: match.awayTeamId } });
    if (!home || !away) throw new ApiGameError('MATCH_NOT_FOUND', 404);

    const dto: MatchDetailsDTO = {
      id: match.id,
      week: match.week,
      season: match.season,
      competition: match.competition === 'cup' ? 'cup' : 'league',
      cupRound: match.cupRound,
      home: toTeamBrief(home),
      away: toTeamBrief(away),
      homeGoals: match.homeGoals ?? 0,
      awayGoals: match.awayGoals ?? 0,
      homePens: match.homePens,
      awayPens: match.awayPens,
      winnerTeamId: match.winnerTeamId,
      isNeutral: match.isNeutral,
      played: match.status === 'played',
      events: parseEvents(match.events),
      stats: parseStats(match.stats),
    };

    return { ok: true as const, match: dto };
  },

  // ── План на матч (Фаза 4) ──
  'GET /matchplan': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolvePlayingSave(saveId);
    const plan = await matchPlanOf(save);
    const response: MatchPlanResponse = { ok: true, plan };
    return response;
  },

  'POST /matchplan': async (req) => {
    const parsed = matchplanPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_MATCH_PLAN', 400);

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);
    const team = await db.team.findUnique({
      where: { id: save.teamId },
      select: { id: true, matchPlan: true },
    });
    if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    // Частичное обновление поверх текущего плана
    const current = parseMatchPlan(team.matchPlan);
    const plan: MatchPlanDTO = {
      leadMode: parsed.data.leadMode ?? current.leadMode,
      chaseMode: parsed.data.chaseMode ?? current.chaseMode,
      fatigueSubs: parsed.data.fatigueSubs ?? current.fatigueSubs,
    };

    await db.team.update({
      where: { id: team.id },
      data: { matchPlan: JSON.stringify(plan) },
    });
    markDirty();

    const response: SetMatchPlanResponse = { ok: true, plan };
    return response;
  },

  // ── Тактика ──
  'POST /tactic': async (req) => {
    const parsed = tacticSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_LINEUP', 400);

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);
    const team = await db.team.findUnique({ where: { id: save.teamId } });
    if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const squad = (await db.player.findMany({
      where: { saveId: save.id, teamId: team.id },
    })) as unknown as PlayerLike[];

    const formation: FormationId = parsed.data.formation ?? coerceFormation(team.formation);
    const mentality: Mentality = parsed.data.mentality ?? coerceMentality(team.mentality);
    const tempo = parsed.data.tempo ?? coerceTempo(team.tempo);
    const pressing = parsed.data.pressing ?? coercePressing(team.pressing);
    const defLine = parsed.data.defLine ?? coerceDefLine(team.defLine);
    const playStyle: PlayStyle = parsed.data.playStyle ?? coercePlayStyle(team.playStyle);

    let lineup: string[] | null = parsed.data.lineup ?? null;
    let bench: string[] = parsed.data.bench ?? [];

    if (lineup) {
      // Валидация стартового состава
      if (!isLineupValid(lineup, squad)) throw new ApiGameError('INVALID_LINEUP', 400);
      // Валидация скамейки: свои игроки, без пересечения со стартом
      const squadIds = new Set(squad.map((p) => p.id));
      const lineupSet = new Set(lineup);
      if (!bench.every((id) => squadIds.has(id)) || bench.some((id) => lineupSet.has(id))) {
        throw new ApiGameError('INVALID_LINEUP', 400);
      }
    } else {
      // Состав не передан — сохраняем прежний, если он валиден
      const saved = parseLineup(team.lineup);
      lineup = saved && isLineupValid(saved, squad) ? saved : null;
      bench = parseLineup(team.bench) ?? [];
    }

    await db.team.update({
      where: { id: team.id },
      data: {
        formation,
        mentality,
        tempo,
        pressing,
        defLine,
        playStyle,
        ...(lineup ? { lineup: JSON.stringify(lineup) } : {}),
        ...(parsed.data.bench !== undefined ? { bench: JSON.stringify(bench) } : {}),
      },
    });
    markDirty();

    const effectiveLineup = lineup ?? autoLineup(squad, formation).lineup;
    const lines = computeLines({
      teamId: team.id,
      players: squad,
      formation,
      mentality,
      tempo,
      pressing,
      defLine,
      playStyle,
      lineup: effectiveLineup,
    });

    return { ok: true as const, teamStrength: lines.overall };
  },

  // ── Тренировки ──
  'GET /training': async (req) => {
    const saveId = saveIdOf(req);
    if (!saveId) throw new ApiGameError('INVALID_PAYLOAD', 400);
    const ensured = await ensureSlotFor(saveId);
    const save = await resolvePlayingSave(ensured);

    const team = await db.team.findUnique({ where: { id: save.teamId } });
    if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const squad = await db.player.findMany({
      where: { saveId: save.id, teamId: team.id },
      orderBy: [{ ovr: 'desc' }, { shirtNumber: 'asc' }],
    });

    // Модуль 4: индивидуальные программы состава
    const individualRows = await db.playerTraining.findMany({ where: { saveId: save.id } });
    const individualBy = new Map(
      individualRows.map((r) => [
        r.playerId,
        {
          focus: coerceTrainingFocus(r.focus),
          intensity: coerceTrainingIntensity(r.intensity),
        },
      ] as const),
    );

    const training: TrainingStateDTO = {
      focus: coerceTrainingFocus(team.trainingFocus),
      intensity: coerceTrainingIntensity(team.trainingIntensity),
    };

    // xp — только по атрибутам ТЕКУЩЕГО фокуса (+ GK-атрибуты для вратарей)
    const squadDto: TrainingPlayerDTO[] = squad.map((p) => {
      const xp = parseTrainingXp(p.trainingXp);
      const attrs = attrsForPlayer(p as unknown as PlayerLike, training.focus);
      const filtered: Partial<Record<AttrKey, number>> = {};
      for (const attr of attrs) {
        filtered[attr] = xp[attr] ?? 0;
      }
      return {
        id: p.id,
        firstName: p.firstName,
        lastName: p.lastName,
        position: p.position as Position,
        age: p.age,
        ovr: p.ovr,
        potential: p.potential,
        morale: p.morale,
        condition: p.condition,
        injuryWeeks: p.injuryWeeks,
        trainingXp: filtered,
        individual: individualBy.get(p.id) ?? null,
      };
    });

    return {
      ok: true as const,
      training,
      squad: squadDto,
      hints: trainingHints(),
    };
  },

  'POST /training': async (req) => {
    const parsed = trainingPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_TRAINING', 400);

    const saveId = await ensureSlotFor(parsed.data.saveId);
    const save = await resolvePlayingSave(saveId);
    const { focus, intensity } = parsed.data;

    await db.team.update({
      where: { id: save.teamId },
      data: { trainingFocus: focus, trainingIntensity: intensity },
    });
    markDirty();

    return { ok: true as const, training: { focus, intensity } };
  },

  // ── Модуль 4: индивидуальные программы тренировок ──
  'POST /training/player': async (req) => {
    const parsed = trainingPlayerPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('PLAYER_TRAINING_INVALID', 400);
    const { playerId, focus, intensity } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const player = await db.player.findUnique({ where: { id: playerId } });
    if (!player || player.saveId !== save.id || player.teamId !== save.teamId) {
      throw new ApiGameError('NOT_YOUR_PLAYER', 403);
    }

    const existing = await db.playerTraining.findFirst({
      where: { saveId: save.id, playerId },
    });

    if (focus === null || intensity === null) {
      // сброс к командной программе
      if (existing) {
        await db.$transaction([
          db.playerTraining.delete({ where: { id: existing.id } }),
        ]);
        markDirty();
      }
      return { ok: true as const, playerId, individual: null };
    }

    const data = { focus, intensity };
    if (existing) {
      await db.$transaction([
        db.playerTraining.update({ where: { id: existing.id }, data }),
      ]);
    } else {
      await db.$transaction([
        db.playerTraining.create({ data: { id: crypto.randomUUID(), saveId: save.id, playerId, ...data } }),
      ]);
    }
    markDirty();
    const response: SetPlayerTrainingResponse = {
      ok: true,
      playerId,
      individual: { focus, intensity },
    };
    return response;
  },

  // ── Модуль 4: персонал и рынок труда ──
  'GET /staff': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolvePlayingSave(saveId);
    const payload = await buildStaffPayload(save.id);
    return { ok: true as const, ...payload };
  },

  'POST /staff/hire': async (req) => {
    const parsed = staffHireSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_PAYLOAD', 400);
    const { staffId, years } = parsed.data;
    if (!validStaffYears(years)) throw new ApiGameError('INVALID_STAFF_YEARS', 400);

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const candidate = await db.staff.findUnique({ where: { id: staffId } });
    if (!candidate || candidate.saveId !== save.id) throw new ApiGameError('STAFF_NOT_FOUND', 404);
    if (candidate.teamId !== null) throw new ApiGameError('STAFF_ALREADY_HIRED', 409);

    // слот роли (главтренер/ассистент/фитнес/физио — 1, скауты — 3)
    const employed = await db.staff.findMany({
      where: { saveId: save.id, teamId: save.teamId, role: candidate.role },
    });
    if (staffRoleFull(candidate.role, employed.length)) {
      throw new ApiGameError('STAFF_SLOT_FULL', 409);
    }

    // подписной бонус — сразу с баланса
    const bonus = staffHireBonusOf(candidate);
    if (save.balance < bonus) throw new ApiGameError('INSUFFICIENT_FUNDS', 402);

    const ops: EngineOp[] = [
      db.staff.update({
        where: { id: candidate.id },
        data: { teamId: save.teamId, contractUntil: save.season + years },
      }),
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance - bonus },
      }),
    ];
    await db.$transaction(ops);
    markDirty();

    const payload = await buildStaffPayload(save.id);
    const response: StaffActionResponse = { ok: true, staff: payload, balanceDelta: -bonus };
    return response;
  },

  'POST /staff/fire': async (req) => {
    const parsed = staffFireSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_PAYLOAD', 400);
    const { staffId } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const employee = await db.staff.findUnique({ where: { id: staffId } });
    if (!employee || employee.saveId !== save.id) throw new ApiGameError('STAFF_NOT_FOUND', 404);
    if (employee.teamId !== save.teamId) throw new ApiGameError('STAFF_NOT_EMPLOYED', 403);

    // компенсация: зарплата × оставшиеся недели сезона (минимум 4)
    const plan = buildSeasonPlan(save.leagueCode);
    const weeksLeft = Math.max(STAFF_FIRE_MIN_WEEKS, plan.totalWeeks - save.week);
    const payout = staffFireCompensationOf(employee, weeksLeft);
    if (save.balance < 0) throw new ApiGameError('INSUFFICIENT_FUNDS', 402);

    const ops: EngineOp[] = [
      db.staff.delete({ where: { id: employee.id } }),
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance - payout },
      }),
    ];
    await db.$transaction(ops);
    markDirty();

    const payload = await buildStaffPayload(save.id);
    const response: StaffActionResponse = { ok: true, staff: payload, balanceDelta: -payout };
    return response;
  },

  'POST /staff/renew': async (req) => {
    const parsed = staffHireSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_PAYLOAD', 400);
    const { staffId, years } = parsed.data;
    if (!validStaffYears(years)) throw new ApiGameError('INVALID_STAFF_YEARS', 400);

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const employee = await db.staff.findUnique({ where: { id: staffId } });
    if (!employee || employee.saveId !== save.id) throw new ApiGameError('STAFF_NOT_FOUND', 404);
    if (employee.teamId !== save.teamId) throw new ApiGameError('STAFF_NOT_EMPLOYED', 403);

    const salary = staffRenewSalaryOf(employee);
    await db.$transaction([
      db.staff.update({
        where: { id: employee.id },
        data: { salary, contractUntil: save.season + years },
      }),
    ]);
    markDirty();

    const payload = await buildStaffPayload(save.id);
    const response: StaffActionResponse = { ok: true, staff: payload, balanceDelta: 0 };
    return response;
  },

  // ── Правление ──
  'GET /board': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    if (!save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const teams = await db.team.findMany({
      where: { saveId: save.id },
      select: { id: true, strength: true },
    });
    const teamCount = teams.length;

    const newsRows = await db.newsItem.findMany({
      where: { saveId: save.id, type: 'board' },
      orderBy: [{ season: 'desc' }, { week: 'desc' }, { createdAt: 'desc' }],
      take: 10,
    });
    const news: NewsDTO[] = newsRows.map((n) => ({
      id: n.id,
      season: n.season,
      week: n.week,
      type: n.type as NewsDTO['type'],
      message: n.message,
    }));

    const board = boardDtoOf(save, teamCount, teams);
    const response: BoardResponse = { ok: true, board, news };
    return response;
  },

  // ── Рынок ──
  'GET /market': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolvePlayingSave(saveId);

    const positionParam = queryStr(req, 'position') ?? 'ALL';
    const maxPriceParam = typeof req.maxPrice === 'number'
      ? req.maxPrice
      : Number(queryStr(req, 'maxPrice') ?? '');
    const minOvrParam = typeof req.minOvr === 'number'
      ? req.minOvr
      : Number(queryStr(req, 'minOvr') ?? '');
    const sortParam = queryStr(req, 'sort') ?? 'ovr';

    const position: MarketPositionFilter = POSITIONS.includes(positionParam as MarketPositionFilter)
      ? (positionParam as MarketPositionFilter)
      : 'ALL';
    const maxPrice = Number.isFinite(maxPriceParam) && maxPriceParam > 0 ? maxPriceParam : null;
    const minOvr = Number.isFinite(minOvrParam) && minOvrParam > 0 ? minOvrParam : null;
    const sort: MarketSort = SORTS.includes(sortParam as MarketSort) ? (sortParam as MarketSort) : 'ovr';

    const listings = await db.transferListing.findMany({
      where: { saveId: save.id, status: 'active' },
      include: { player: true },
    });

    // Модуль 3: туман войны — знания о чужих игроках (свои лоты → 100)
    const scoutReports = await db.scoutReport.findMany({ where: { saveId: save.id } });
    const reportByPlayer = new Map(scoutReports.map((r) => [r.playerId, r] as const));

    let dtos: MarketListingDTO[] = listings.map((l) => ({
      listingId: l.id,
      price: l.price,
      source: l.source as MarketListingDTO['source'], // market | user | free (Фаза 3)
      expiresAt: l.expiresAt,
      // Модуль 3: свои лоты — точные данные; чужие — туман войны
      player: l.player.teamId === save.teamId
        ? toPlayerDTO(l.player)
        : toScoutedPlayerDTO(
          l.player,
          reportByPlayer.get(l.playerId) ?? null,
          absWeekOfSave(save), // сид недели: оценки обновляются раз в неделю
        ),
    }));

    if (position !== 'ALL') {
      dtos = dtos.filter((l) => broadGroupOf(l.player.position) === position);
    }
    if (maxPrice !== null) {
      dtos = dtos.filter((l) => l.price <= maxPrice);
    }
    if (minOvr !== null) {
      dtos = dtos.filter((l) => l.player.ovr >= minOvr);
    }

    dtos.sort((a, b) => {
      if (sort === 'price') return a.price - b.price;
      if (sort === 'age') return a.player.age - b.player.age;
      return b.player.ovr - a.player.ovr;
    });

    return { ok: true as const, listings: dtos };
  },

  'POST /market/buy': async (req) => {
    const parsed = marketBuySchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('NOT_FOR_SALE', 409);

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    // listingId → playerId (контракт Task 10-a-2: { saveId, listingId })
    let playerId = parsed.data.playerId ?? null;
    if (!playerId && parsed.data.listingId) {
      const byListing = await db.transferListing.findUnique({
        where: { id: parsed.data.listingId },
      });
      if (!byListing || byListing.saveId !== save.id || byListing.status !== 'active') {
        throw new ApiGameError('NOT_FOR_SALE', 409);
      }
      playerId = byListing.playerId;
    }

    const listing = await db.transferListing.findFirst({
      where: { playerId: playerId as string, status: 'active' },
      include: { player: true },
    });
    if (!listing || listing.saveId !== save.id) throw new ApiGameError('NOT_FOR_SALE', 409);
    if (listing.player.teamId !== null) throw new ApiGameError('NOT_FOR_SALE', 409);

    const squadCount = await db.player.count({
      where: { saveId: save.id, teamId: save.teamId },
    });
    if (squadCount >= SQUAD_MAX) throw new ApiGameError('SQUAD_FULL', 409);

    const budget = Math.max(0, Math.floor(save.balance * TRANSFER_BUDGET_RATIO));
    if (listing.price > budget) throw new ApiGameError('INSUFFICIENT_BUDGET', 409);

    const squad = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    });
    const shirtNumber = freeShirtNumber(squad as unknown as PlayerLike[]);
    const name = `${listing.player.firstName} ${listing.player.lastName}`;

    // D-6 (§4.3): цена с учётом престижа менеджера — p ≥ 75.0 → база ×0.95
    // (floor до €1 000); p < 60.0 и OVR ≥ 80 → база ×1.10 («звезда не хочет
    // перехода»). Бюджет-граница floor(balance×0.4) считается от БАЗОВОЙ цены
    // лота (проверка выше); списание/записи — по модифицированной цене
    const { manager: managerForPrice } = await loadManagerState(save);
    const pricePaid = managerMarketPrice(
      managerForPrice.prestige,
      listing.price,
      listing.player.ovr,
    );

    // Фаза 3: покупка = новый контракт (детерминированный бросок срока по возрасту)
    const buyRng = mulberry32(hashString(`${save.id}:contractbuy:${listing.playerId}`));
    const contractUntil = contractUntilFromYears(
      save.season,
      contractYearsRoll(buyRng, listing.player.age),
    );

    // ── Модуль 3: контрактные переговоры. Легаси-запрос (без полей контракта)
    // подписывает автоматически по спросу. Явное предложение оценивает агент:
    // accepted / counter (точный спрос) / rejected (причина). ──
    const negotiated = parsed.data.salary !== undefined;
    const buyerSquad = squad as unknown as PlayerLike[];
    const top11 = [...buyerSquad].sort((a, b) => b.ovr - a.ovr).slice(0, 11);
    const buyerTop11Avg = top11.length > 0
      ? top11.reduce((s, p) => s + p.ovr, 0) / top11.length
      : 50;
    const demand = signingDemandOf({ player: listing.player as unknown as PlayerLike, buyerTop11Avg });

    if (negotiated) {
      const offerRng = mulberry32(hashString(`${save.id}:agent:${listing.playerId}:${save.season}:${save.week}`));
      const decision = evaluateSigningOffer({
        player: listing.player as unknown as PlayerLike,
        demand,
        offer: {
          salary: parsed.data.salary as number,
          years: parsed.data.years as number,
          goalBonus: parsed.data.goalBonus as number,
          cleanSheetBonus: parsed.data.cleanSheetBonus as number,
        },
        rng: offerRng,
      });
      if (decision.kind !== 'accepted') {
        return {
          ok: true as const,
          negotiation: {
            kind: decision.kind,
            demand: decision.kind === 'counter' ? decision.demand : null,
            reason: decision.kind === 'rejected' ? decision.reason : null,
            message: decision.message,
          },
        };
      }
    }

    // Принято (или легаси): зарплата/бонусы/срок — из спроса либо предложения
    const salary = negotiated ? (parsed.data.salary as number) : demand.salary;
    const years = negotiated ? (parsed.data.years as number) : demand.years;
    const goalBonus = negotiated ? (parsed.data.goalBonus as number) : demand.goalBonus;
    const cleanSheetBonus = negotiated
      ? (parsed.data.cleanSheetBonus as number)
      : demand.cleanSheetBonus;
    const contractUntilFinal = negotiated
      ? contractUntilFromYears(save.season, years)
      : contractUntil;

    // Модуль 3: покупка даёт стартовое знание о игроке (знакомство) —
    // отчёт создаётся/обновляется до транзакции (ленивые ops, паритет Prisma)
    const priorReport = await db.scoutReport.findFirst({
      where: { saveId: save.id, playerId: listing.playerId },
    });
    const scoutBuyOp = priorReport
      ? db.scoutReport.update({
        where: { id: priorReport.id },
        data: {
          knowledge: SCOUT_BUY_KNOWLEDGE,
          watched: false,
          lastWeek: absWeekOfSave(save),
        },
      })
      : db.scoutReport.create({
        data: {
          saveId: save.id,
          playerId: listing.playerId,
          knowledge: SCOUT_BUY_KNOWLEDGE,
          lastWeek: absWeekOfSave(save),
          watched: false,
        },
      });

    await db.$transaction([
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance - pricePaid },
      }),
      db.player.update({
        where: { id: listing.playerId },
        data: {
          teamId: save.teamId,
          shirtNumber,
          contractUntil: contractUntilFinal,
          salary,
          goalBonus,
          cleanSheetBonus,
        },
      }),
      db.transferListing.update({
        where: { id: listing.id },
        data: { status: 'sold' },
      }),
      scoutBuyOp,
      db.financeRecord.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          kind: 'expense',
          category: 'transfer_out',
          amount: pricePaid,
          description: `Покупка игрока: ${name}`,
        },
      }),
      db.newsItem.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'transfer',
          message: `${name} подписал контракт! Сумма трансфера — €${pricePaid.toLocaleString('ru-RU')}.`,
        },
      }),
    ]);
    markDirty();

    const snapshot = await buildSnapshot(save.id);
    if (negotiated) {
      return {
        ok: true as const,
        snapshot,
        negotiation: {
          kind: 'accepted' as const,
          demand: null,
          reason: null,
          message: `${name} принял условия контракта.`,
        },
      };
    }
    return { ok: true as const, snapshot };
  },

  'POST /market/sell': async (req) => {
    const parsed = marketSellSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('PRICE_OUT_OF_BAND', 409);
    const { playerId, price } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const player = await db.player.findUnique({ where: { id: playerId } });
    if (!player || player.saveId !== save.id || player.teamId !== save.teamId) {
      throw new ApiGameError('NOT_YOUR_PLAYER', 400);
    }
    if (player.injuryWeeks > 0) throw new ApiGameError('PLAYER_INJURED', 409);

    // Фикс QA-8: валидация цены ДО проверки «уже выставлен» —
    // иначе ALREADY_LISTED маскировал реальную причину (цену вне диапазона).
    const bounds = sellPriceBounds(player.value);
    if (price < bounds.min || price > bounds.max) throw new ApiGameError('PRICE_OUT_OF_BAND', 409);

    const existing = await db.transferListing.findFirst({
      where: { playerId, status: 'active' },
    });
    if (existing) throw new ApiGameError('ALREADY_LISTED', 409);

    const squad = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    });
    if (!canSellPlayer(squad as unknown as PlayerLike[], playerId)) {
      throw new ApiGameError('SQUAD_MIN_VIOLATION', 409);
    }

    const name = `${player.firstName} ${player.lastName}`;

    // playerId уникален в TransferListing: если лот уже был (продан/истёк) —
    // переиспользуем строку, иначе создаём новую.
    const priorRow = await db.transferListing.findFirst({ where: { playerId } });
    const listingOp = priorRow
      ? db.transferListing.update({
          where: { id: priorRow.id },
          data: { price, source: 'user', status: 'active', expiresAt: LISTING_TTL },
        })
      : db.transferListing.create({
          data: {
            saveId: save.id,
            playerId,
            price,
            askFactor: 1.0,
            source: 'user',
            status: 'active',
            expiresAt: LISTING_TTL,
          },
        });
    await db.$transaction([
      listingOp,
      db.newsItem.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'transfer',
          message: `${name} выставлен на трансферный рынок за €${price.toLocaleString('ru-RU')}.`,
        },
      }),
    ]);
    markDirty();

    const snapshot = await buildSnapshot(save.id);
    return { ok: true as const, snapshot };
  },

  // ── Модуль 3: скаутинг (туман войны) ──
  'GET /scout': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolvePlayingSave(saveId);

    const reports = await db.scoutReport.findMany({ where: { saveId: save.id } });
    const staff = await db.staff.findMany({ where: { saveId: save.id, teamId: save.teamId } });
    const scoutCount = staff.filter((s) => s.role === 'scout').length;
    // Модуль 5: слоты расширяет скаут-центр (L3 +1 · L5 +2)
    const teamRow = await db.team.findUnique({
      where: { id: save.teamId as string },
      select: { buildings: true },
    });
    const slotsTotal = scoutSlotsOf(
      scoutCount,
      scoutSlotsBonus(parseBuildings(teamRow?.buildings ?? null).scoutcenter.level),
    );
    const used = reports.filter((r) => r.watched).length;

    const players = await db.player.findMany({ where: { saveId: save.id } });
    const playerById = new Map(players.map((p) => [p.id, p] as const));
    const weekSeed = absWeekOfSave(save);

    const dtos: ScoutReportDTO[] = [];
    for (const r of reports) {
      const player = playerById.get(r.playerId);
      if (!player || player.teamId === save.teamId) continue; // свой — не нужен
      dtos.push({
        playerId: r.playerId,
        knowledge: r.knowledge,
        tier: knowledgeTierOf(r.knowledge),
        watched: r.watched,
        player: toScoutedPlayerDTO(player, r, weekSeed),
      });
    }
    dtos.sort((a, b) => b.knowledge - a.knowledge);

    const response: ScoutResponse = {
      ok: true,
      season: save.season,
      week: save.week,
      reports: dtos,
      slots: { used, total: slotsTotal },
    };
    return response;
  },

  'POST /scout/watch': async (req) => {
    const parsed = scoutWatchSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('NOT_FOR_SALE', 400);
    const { playerId } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const player = await db.player.findUnique({ where: { id: playerId } });
    if (!player || player.saveId !== save.id) throw new ApiGameError('NOT_FOR_SALE', 404);
    if (player.teamId === save.teamId) throw new ApiGameError('NOT_YOUR_PLAYER', 400);

    const existing = await db.scoutReport.findFirst({
      where: { saveId: save.id, playerId },
    });
    if (existing?.watched) return { ok: true as const };

    // Guard слотов: активных наблюдений не больше scoutSlotsOf (+скаут-центр)
    if (!existing) {
      const reports = await db.scoutReport.findMany({ where: { saveId: save.id } });
      const staff = await db.staff.findMany({ where: { saveId: save.id, teamId: save.teamId } });
      const teamRow = await db.team.findUnique({
        where: { id: save.teamId as string },
        select: { buildings: true },
      });
      const slotsTotal = scoutSlotsOf(
        staff.filter((s) => s.role === 'scout').length,
        scoutSlotsBonus(parseBuildings(teamRow?.buildings ?? null).scoutcenter.level),
      );
      const used = reports.filter((r) => r.watched).length;
      if (used >= slotsTotal) throw new ApiGameError('SCOUT_SLOTS_FULL', 409);
    }

    const weekSeed = absWeekOfSave(save);
    if (existing) {
      await db.$transaction([
        db.scoutReport.update({ where: { id: existing.id }, data: { watched: true } }),
      ]);
    } else {
      await db.$transaction([
        db.scoutReport.create({
          data: {
            saveId: save.id,
            playerId,
            // первичный осмотр: 10 знания сразу, дальше — рост по неделям
            knowledge: 10,
            lastWeek: weekSeed,
            watched: true,
          },
        }),
      ]);
    }
    markDirty();
    return { ok: true as const };
  },

  'POST /scout/unwatch': async (req) => {
    const parsed = scoutWatchSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('NOT_FOR_SALE', 400);
    const { playerId } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const existing = await db.scoutReport.findFirst({
      where: { saveId: save.id, playerId },
    });
    if (!existing || !existing.watched) return { ok: true as const };

    // Знание < 10 при снятии наблюдения не храним — «нулевое досье» ни к чему
    const ops: EngineOp[] = existing.knowledge < 10
      ? [db.scoutReport.delete({ where: { id: existing.id } })]
      : [db.scoutReport.update({ where: { id: existing.id }, data: { watched: false } })];
    await db.$transaction(ops);
    markDirty();
    return { ok: true as const };
  },

  // ── Модуль 3: входящие офферы ИИ ──
  'GET /transfer-offers': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolvePlayingSave(saveId);

    const offers = await db.transferOffer.findMany({
      where: { saveId: save.id, status: 'pending' },
      include: { player: true },
    });
    const teams = await db.team.findMany({ where: { saveId: save.id } });
    const teamById = new Map(teams.map((t) => [t.id, t] as const));
    const absWeek = absWeekOfSave(save);

    const dtos: TransferOfferDTO[] = [];
    for (const o of offers) {
      if (o.player.teamId !== save.teamId) continue; // уже уехал — погасится в цикле
      const team = teamById.get(o.fromTeamId);
      if (!team) continue;
      dtos.push({
        offerId: o.id,
        amount: o.amount,
        fromTeam: team.name,
        player: toPlayerDTO(o.player),
        expiresIn: Math.max(0, o.expiresWeek - absWeek),
      });
    }
    dtos.sort((a, b) => b.amount - a.amount);

    const response: TransferOffersResponse = { ok: true, offers: dtos };
    return response;
  },

  'POST /transfer-offers/accept': async (req) => {
    const parsed = transferOfferSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('NOT_FOR_SALE', 400);
    const { offerId } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const offer = await db.transferOffer.findUnique({
      where: { id: offerId },
      include: { player: true },
    });
    if (!offer || offer.saveId !== save.id || offer.status !== 'pending') {
      throw new ApiGameError('OFFER_NOT_PENDING', 409);
    }
    if (offer.player.teamId !== save.teamId) {
      throw new ApiGameError('NOT_YOUR_PLAYER', 409);
    }

    // Guard состава: минимумы линий после ухода игрока
    const squad = (await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    })) as unknown as PlayerLike[];
    if (!canSellPlayer(squad, offer.playerId)) {
      throw new ApiGameError('SQUAD_MIN_VIOLATION', 409);
    }

    const buyer = await db.team.findUnique({ where: { id: offer.fromTeamId } });
    if (!buyer) throw new ApiGameError('NOT_FOR_SALE', 409);

    const name = `${offer.player.firstName} ${offer.player.lastName}`;
    const buyerSquad = (await db.player.findMany({
      where: { saveId: save.id, teamId: buyer.id },
    })) as unknown as PlayerLike[];
    const shirtNumber = freeShirtNumber(buyerSquad);
    const salary = aiSigningSalaryOf(offer.player as unknown as PlayerLike);
    const signRng = mulberry32(hashString(`${save.id}:contractbuy:${offer.playerId}`));
    const contractUntil = contractUntilFromYears(
      save.season,
      contractYearsRoll(signRng, offer.player.age),
    );
    // Активный лот игрока (если был выставлен) гасим как sold
    const activeListing = await db.transferListing.findFirst({
      where: { playerId: offer.playerId, status: 'active' },
    });
    const listingOp: EngineOp[] = activeListing
      ? [db.transferListing.update({ where: { id: activeListing.id }, data: { status: 'sold' } })]
      : [];

    await db.$transaction([
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance + offer.amount },
      }),
      db.player.update({
        where: { id: offer.playerId },
        data: {
          teamId: buyer.id,
          shirtNumber,
          contractUntil,
          salary,
          preContractTeamId: null,
          morale: 70,
        },
      }),
      db.transferOffer.update({
        where: { id: offer.id },
        data: { status: 'accepted' },
      }),
      ...listingOp,
      db.financeRecord.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          kind: 'income',
          category: 'transfer_in',
          amount: offer.amount,
          description: `Продажа игрока: ${name}`,
        },
      }),
      db.newsItem.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'transfer',
          message: `${name} продан в ${buyer.name} за €${offer.amount.toLocaleString('ru-RU')}.`,
        },
      }),
    ]);
    markDirty();

    const snapshot = await buildSnapshot(save.id);
    return { ok: true as const, snapshot };
  },

  'POST /transfer-offers/reject': async (req) => {
    const parsed = transferOfferSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('NOT_FOR_SALE', 400);
    const { offerId } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const offer = await db.transferOffer.findUnique({
      where: { id: offerId },
      include: { player: true },
    });
    if (!offer || offer.saveId !== save.id || offer.status !== 'pending') {
      throw new ApiGameError('OFFER_NOT_PENDING', 409);
    }

    // Отказ злит star-игрока с низкой моралью (заблокировали переход)
    const squad = (await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    })) as unknown as PlayerLike[];
    const rank = ovrRankOf(offer.player as unknown as PlayerLike, squad);
    const moraleHit = rank <= CONTRACT_RANK_STAR && offer.player.morale < INCOMING_OFFER_UNHAPPY_MORALE
      ? INCOMING_OFFER_REJECT_MORALE_HIT
      : 0;

    const name = `${offer.player.firstName} ${offer.player.lastName}`;
    const buyer = await db.team.findUnique({ where: { id: offer.fromTeamId } });

    await db.$transaction([
      db.transferOffer.update({ where: { id: offer.id }, data: { status: 'rejected' } }),
      ...(moraleHit > 0
        ? [db.player.update({
          where: { id: offer.playerId },
          data: { morale: Math.max(0, offer.player.morale - moraleHit) },
        })]
        : []),
      db.newsItem.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'transfer',
          message: `Предложение ${buyer?.name ?? 'клуба'} на ${name} отклонено.${moraleHit > 0 ? ` Игрок недоволен отказом (мораль −${moraleHit}).` : ''}`,
        },
      }),
    ]);
    markDirty();

    const snapshot = await buildSnapshot(save.id);
    return { ok: true as const, snapshot };
  },

  // ── Контракты (Фаза 3) ──
  'GET /contracts': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    if (!save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const squadRows = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
      orderBy: [{ ovr: 'desc' }],
    });
    const squad = squadRows as unknown as PlayerLike[];
    const teamApps = teamAppsOf(squad);
    // D-6 (§4.3): спрос с эффектом престижа менеджера (p ≥ 60.0 → ×0.95;
    // p < 40.0 → ×1.05) — тот же множитель в POST /contracts/renew
    const { manager: managerForContracts } = await loadManagerState(save);
    const prestigeMult = contractsPrestigeMult(managerForContracts.prestige);

    const contracts: ContractInfoDTO[] = squad
      .map((p) => {
        const yearsLeft = yearsLeftOf(p.contractUntil, save.season);
        const preContract = p.preContractTeamId !== null;
        const renewable = yearsLeft <= 2 && !preContract;
        // риск Босмана имеет смысл только в последний год контракта
        const bosmanRisk = yearsLeft <= 1
          ? bosmanRiskOf(bosmanProbability({ player: p, teamApps }))
          : 'low';
        return {
          playerId: p.id,
          name: `${p.firstName} ${p.lastName}`,
          position: p.position,
          age: p.age,
          ovr: p.ovr,
          value: p.value,
          salary: p.salary,
          contractUntil: p.contractUntil,
          yearsLeft,
          renewable,
          demand: renewable ? renewDemand({ player: p, squad, teamApps, prestigeMult }) : null,
          maxRenewYears: maxRenewYears(p.age),
          preContract,
          bosmanRisk,
        } satisfies ContractInfoDTO;
      })
      .sort((a, b) => a.yearsLeft - b.yearsLeft || b.ovr - a.ovr);

    const response: ContractsResponse = { ok: true, season: save.season, contracts };
    return response;
  },

  'POST /contracts/renew': async (req) => {
    const parsed = contractsRenewSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_CONTRACT', 400);
    const { saveId, playerId, years, salary } = parsed.data;

    const ensured = await ensureSlotFor(saveId);
    const save = await resolvePlayingSave(ensured);

    const playerRow = await db.player.findFirst({
      where: { id: playerId, saveId: save.id, teamId: save.teamId },
    });
    if (!playerRow) throw new ApiGameError('NOT_YOUR_PLAYER', 404);
    const player = playerRow as unknown as PlayerLike;

    if (player.preContractTeamId !== null) throw new ApiGameError('CONTRACT_PRECONTRACT', 409);
    if (yearsLeftOf(player.contractUntil, save.season) > CONTRACT_RENEWABLE_YEARS_LEFT) {
      throw new ApiGameError('CONTRACT_NOT_RENEWABLE', 400);
    }
    if (years < CONTRACT_MIN_YEARS || years > maxRenewYears(player.age)) {
      throw new ApiGameError('INVALID_CONTRACT', 400);
    }

    const squadRows = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    });
    const squad = squadRows as unknown as PlayerLike[];
    const teamApps = teamAppsOf(squad);
    // D-6 (§4.3): престиж применяется ДО слайдера — спрос/границы/исход
    // считаются от модифицированного значения (тот же множитель в GET)
    const { manager: managerForRenew } = await loadManagerState(save);
    const demand = renewDemand({
      player,
      squad,
      teamApps,
      prestigeMult: contractsPrestigeMult(managerForRenew.prestige),
    });

    // Границы слайдера UI (80–130% спроса), округление к SALARY_ROUND
    const salaryMin = Math.floor((CONTRACT_OFFER_MIN_RATIO * demand) / SALARY_ROUND) * SALARY_ROUND;
    const salaryMax = Math.ceil((CONTRACT_OFFER_MAX_RATIO * demand) / SALARY_ROUND) * SALARY_ROUND;
    if (salary < salaryMin || salary > salaryMax) {
      throw new ApiGameError('INVALID_CONTRACT', 400);
    }

    const outcome = renewalOutcome(salary, demand);
    if (outcome === 'accepted') {
      await db.player.update({
        where: { id: player.id },
        data: {
          contractUntil: save.season + years,
          salary,
        },
      });
      markDirty(); // §2.3: автосейв только ветки accepted
      const snapshot = await buildSnapshot(save.id);
      return { ok: true as const, outcome, demand, snapshot };
    }

    return { ok: true as const, outcome, demand };
  },

  // ── Академия (Фаза 3) ──
  'GET /academy': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    if (!save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const rows = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId, isAcademy: true },
      orderBy: [{ potential: 'desc' }, { ovr: 'desc' }],
    });

    const graduates: AcademyPlayerDTO[] = rows.map((p) => ({
      id: p.id,
      name: `${p.firstName} ${p.lastName}`,
      position: p.position as Position,
      age: p.age,
      ovr: p.ovr,
      potential: p.potential,
      stars: starsOf(p.potential),
      contractUntil: p.contractUntil,
      yearsLeft: yearsLeftOf(p.contractUntil, save.season),
      value: p.value,
      salary: p.salary,
    }));

    const response: AcademyResponse = { ok: true, graduates };
    return response;
  },

  // ── D-5 «Территория» (§3.6): покупка/апгрейд здания клуба игрока ──
  'POST /buildings': async (req) => {
    const parsed = buildingsPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('BUILDING_NOT_FOUND', 404);

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const spec = buildingById(parsed.data.buildingId);
    if (!spec) throw new ApiGameError('BUILDING_NOT_FOUND', 404);

    const team = await db.team.findUnique({ where: { id: save.teamId as string } });
    if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    // Правила строительства §3.3: апгрейд на 1 уровень; MAX_LEVEL → 409;
    // одна активная стройка на клуб → 409; оплата с баланса (НЕ бюджет) → 402
    const state = parseBuildings(team.buildings);
    const st = state[spec.id];
    if (st.level >= BUILDING_MAX_LEVEL) throw new ApiGameError('BUILDING_MAX_LEVEL', 409);
    for (const other of BUILDING_IDS) {
      if (state[other].upgradeEndsAtDay !== null) {
        throw new ApiGameError('BUILDING_IN_PROGRESS', 409);
      }
    }

    const nextLevel = st.level + 1;
    const price = priceOf(spec.id, nextLevel);
    if (price > save.balance) throw new ApiGameError('INSUFFICIENT_FUNDS', 402);

    // Таймер: текущий absoluteDay + дни постройки (§3.3; totalWeeks — лига сейва);
    // уровень поднимается тиком недели при завершении стройки (§3.3)
    const def = leagueByCode(save.leagueCode);
    if (!def) throw new ApiGameError('NO_SAVE', 404);
    const plan = buildSeasonPlan(def.code);
    st.upgradeEndsAtDay = absoluteDayOf(save.season, save.week, plan.totalWeeks)
      + daysOf(spec.id, nextLevel);
    const buildings = serializeBuildings(state);

    await db.$transaction([
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance - price },
      }),
      db.team.update({
        where: { id: team.id },
        data: { buildings },
      }),
      db.financeRecord.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          kind: 'expense',
          category: 'construction',
          amount: price,
          description: `Стройка: ${spec.name} ур. ${nextLevel}`,
        },
      }),
    ]);
    markDirty();

    // Свежий снапшот — как buy/sell (§3.6)
    const snapshot = await buildSnapshot(save.id);
    return { ok: true as const, snapshot };
  },

  // ── Модуль 5 (§ «Инфраструктура 2.0»): запуск расширения стадиона ──
  'POST /stadium': async (req) => {
    const parsed = stadiumPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('INVALID_STADIUM_SEATS', 400);
    const seats: StadiumSeats = parsed.data.seats;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const team = await db.team.findUnique({ where: { id: save.teamId as string } });
    if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    // Гварды (§ stadium.ts): уже идёт стройка → 409; лимит 90 000 → 409;
    // оплата с баланса (НЕ бюджет) → 402. Стадион и здания — независимые
    // стройки (разные бригады), блокируют только сами себя.
    if (team.stadiumPending > 0 || team.stadiumUpgradeEndsAtDay !== null) {
      throw new ApiGameError('STADIUM_IN_PROGRESS', 409);
    }
    if (!stadiumFits(team.stadiumCapacity, seats)) {
      throw new ApiGameError('STADIUM_TOO_BIG', 409);
    }
    const price = stadiumPriceOf(team.stadiumCapacity, seats);
    if (price > save.balance) throw new ApiGameError('INSUFFICIENT_FUNDS', 402);

    // Таймер: текущий absoluteDay + дни блока (56/70/84); вместимость
    // поднимается тиком недели при завершении (week.ts, «Трибуны расширены»)
    const def = leagueByCode(save.leagueCode);
    if (!def) throw new ApiGameError('NO_SAVE', 404);
    const plan = buildSeasonPlan(def.code);
    const upgradeEndsAtDay = absoluteDayOf(save.season, save.week, plan.totalWeeks)
      + stadiumDaysOf(seats);

    await db.$transaction([
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance - price },
      }),
      db.team.update({
        where: { id: team.id },
        data: { stadiumPending: seats, stadiumUpgradeEndsAtDay: upgradeEndsAtDay },
      }),
      db.financeRecord.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          kind: 'expense',
          category: 'construction',
          amount: price,
          description: `Расширение стадиона: +${seats.toLocaleString('ru-RU')} мест`,
        },
      }),
      db.newsItem.create({
        data: {
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'info',
          message: `Началось расширение трибун: +${seats.toLocaleString('ru-RU')} мест. Стройка завершится через ${stadiumDaysOf(seats)} дней.`,
        },
      }),
    ]);
    markDirty();

    const snapshot = await buildSnapshot(save.id);
    const response: StadiumResponse = {
      ok: true,
      capacityAfter: team.stadiumCapacity + seats,
      pending: seats,
      upgradeEndsAtDay,
      balance: save.balance - price,
      snapshot,
    };
    return response;
  },

  // ── D-6 «Тренер» (§4.6): профиль менеджера (ленивый, НЕ в /state) ──
  'GET /manager': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    if (!save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const team = await db.team.findUnique({ where: { id: save.teamId } });
    if (!team) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const manager = parseManager(save.manager, team.strength)
      ?? createManagerState(team.strength);
    const response: ManagerResponse = {
      ok: true,
      manager: managerDtoOf(save, team.name, manager),
    };
    return response;
  },

  // ── D-6 «Тренер» (§4.6): покупка/продажа актива (кошелёк менеджера) ──
  'POST /manager/asset': async (req) => {
    const parsed = managerAssetPostSchema.safeParse(req);
    if (!parsed.success) throw new ApiGameError('ASSET_NOT_FOUND', 404);
    const { assetId, action } = parsed.data;

    const saveId = await ensureSlotFor(parsed.data.saveId ?? null);
    const save = await resolvePlayingSave(saveId);

    const spec = assetById(assetId);
    if (!spec) throw new ApiGameError('ASSET_NOT_FOUND', 404);

    const { manager, team } = await loadManagerState(save);

    // Правила §4.2: покупка при wallet ≥ price (иначе 402; владеть можно
    // несколькими активами одновременно); продажа — за 70 % цены, престиж
    // −ceil(начислено/2); повторная покупка проданного — полная цена и
    // престиж заново. Кошелёк менеджера — ОТДЕЛЬНО от баланса клуба.
    const owned = manager.assets.includes(spec.id);
    const ops: EngineOp[] = [];
    if (action === 'buy') {
      if (owned) throw new ApiGameError('ASSET_ALREADY_OWNED', 409);
      if (spec.price > manager.wallet) throw new ApiGameError('INSUFFICIENT_WALLET', 402);
      manager.wallet -= spec.price;
      manager.assets = [...manager.assets, spec.id];
      manager.prestige = clampPrestige(manager.prestige + spec.prestige);
      ops.push(
        db.newsItem.create({
          data: {
            saveId: save.id,
            season: save.season,
            week: save.week,
            type: 'manager',
            message: `${save.managerName} приобрёл ${spec.name}`,
          },
        }),
      );
    } else {
      if (!owned) throw new ApiGameError('ASSET_NOT_OWNED', 409);
      manager.wallet += sellPriceOf(spec);
      manager.assets = manager.assets.filter((a) => a !== spec.id);
      manager.prestige = clampPrestige(manager.prestige - sellPrestigeOf(spec));
      ops.push(
        db.newsItem.create({
          data: {
            saveId: save.id,
            season: save.season,
            week: save.week,
            type: 'manager',
            message: `Продано: ${spec.name}`,
          },
        }),
      );
    }

    ops.push(
      db.gameSave.update({
        where: { id: save.id },
        data: { manager: serializeManager(manager) },
      }),
    );
    await db.$transaction(ops);
    markDirty();

    const response: ManagerAssetResponse = {
      ok: true,
      manager: managerDtoOf(save, team.name, manager),
    };
    return response;
  },

  // ── D-7 «Медиа» (§5.6): архив газет (ленивый, пагинация) ──
  'GET /media': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolvePlayingSave(saveId);

    // offset=0&limit=1 — дефолты §5.6; числа приходят полями запроса (getMarket)
    const numParam = (key: string, fallback: number): number => {
      const v = req[key];
      if (typeof v === 'number') return v;
      const s = queryStr(req, key);
      return s === null ? fallback : Number(s);
    };
    const offset = numParam('offset', 0);
    const limit = numParam('limit', 1);
    if (!Number.isInteger(offset) || offset < 0) throw new ApiGameError('INVALID_PAYLOAD', 400);
    if (!Number.isInteger(limit) || limit < 1 || limit > PRESS_ARCHIVE_LIMIT) {
      throw new ApiGameError('INVALID_PAYLOAD', 400);
    }

    // Сорт §5.6: season desc, week desc, createdAt desc; срез offset/limit
    const rows = await db.newspaperClipping.findMany({
      where: { saveId: save.id },
      orderBy: [{ season: 'desc' }, { week: 'desc' }, { createdAt: 'desc' }],
    });
    const total = rows.length;
    const clippings: NewspaperClippingDTO[] = rows
      .slice(offset, offset + limit)
      .map((r) => {
        const motm = parseMotm(r.motm);
        const motmDto: PressMotmDTO | null = motm !== null
          ? {
            playerId: motm.playerId,
            name: motm.name,
            position: motm.position as Position,
            // ×10 → /10 (78 → 7.8, §5.6 «DTO = запись с rating/10»)
            rating: motm.rating / 10,
          }
          : null;
        return {
          id: r.id,
          season: r.season,
          week: r.week,
          matchId: r.matchId,
          competition: r.competition as PressCompetition,
          context: r.context,
          headline: r.headline,
          subheadline: r.subheadline,
          homeName: r.homeName,
          awayName: r.awayName,
          homeGoals: r.homeGoals,
          awayGoals: r.awayGoals,
          homePens: r.homePens,
          awayPens: r.awayPens,
          motm: motmDto,
          excerpt: r.excerpt,
          moments: parseMoments(r.moments) as PressMomentDTO[],
          createdAt: r.createdAt.toISOString(),
        };
      });

    const response: MediaResponse = { ok: true, clippings, total };
    return response;
  },

  // ── Награды ──
  'GET /awards': async (req) => {
    const saveId = saveIdOf(req);
    if (!saveId) throw new ApiGameError('INVALID_PAYLOAD', 400);
    const ensured = await ensureSlotFor(saveId);
    const save = await resolvePlayingSave(ensured);

    const seasonParam = queryStr(req, 'season');
    let season: number | null = null;
    if (seasonParam !== null && seasonParam.trim() !== '') {
      const n = Number(seasonParam);
      if (!Number.isInteger(n) || n < 1) throw new ApiGameError('INVALID_PAYLOAD', 400);
      season = n;
    }

    const rows = await db.seasonAward.findMany({
      where: { saveId: save.id, ...(season !== null ? { season } : {}) },
      orderBy: [{ season: 'asc' }, { createdAt: 'asc' }],
    });

    const teams = await db.team.findMany({ where: { saveId: save.id } });
    const teamName = new Map(teams.map((t) => [t.id, t.name]));

    // Игроки-лауреаты могли завершить карьеру (FK SeasonAward.playerId → SetNull)
    const playerIds = [...new Set(rows.map((r) => r.playerId).filter((x): x is string => !!x))];
    const players = playerIds.length > 0
      ? await db.player.findMany({ where: { id: { in: playerIds } } })
      : [];
    const playerName = new Map(players.map((p) => [p.id, `${p.firstName} ${p.lastName}`]));

    const awards: SeasonAwardDTO[] = rows.map((r) => ({
      id: r.id,
      season: r.season,
      type: r.type,
      typeName: AWARD_TYPE_LABELS[r.type] ?? r.type,
      playerId: r.playerId,
      playerName: r.playerId ? (playerName.get(r.playerId) ?? null) : null,
      teamId: r.teamId,
      teamName: teamName.get(r.teamId) ?? '',
      value: r.value,
      label: r.label,
    }));

    // Live-лидеры текущего сезона (топ-5, на лету).
    // Фаза 4 (§5.5 ТЗ, QA P4-5): лиговые лидеры — ТОЛЬКО не-гости
    // (team.isEuroGuest=false, как в snapshot.ts); topEuroScorers — все,
    // включая гостей (бомбардиры Кубка Европы для экрана «Европа»).
    const allPlayers = await db.player.findMany({
      where: { saveId: save.id, teamId: { not: null } },
    });
    const guestTeamIds = new Set(teams.filter((t) => t.isEuroGuest).map((t) => t.id));
    const leaguePlayersLike = allPlayers
      .filter((p) => !guestTeamIds.has(p.teamId ?? '')) as unknown as PlayerLike[];
    const allPlayersLike = allPlayers as unknown as PlayerLike[];
    const leaderTeams = new Map<string, LeaderTeamInfo>(
      teams.map((t) => [
        t.id,
        {
          name: t.name,
          shortName: t.shortName,
          c1: t.colorPrimary,
          c2: t.colorSecondary,
          isUser: t.isUserTeam,
        },
      ]),
    );
    const leaders = liveLeaders({ players: leaguePlayersLike, teams: leaderTeams, take: 5 });
    const topCupScorers: PlayerLeaderDTO[] = liveCupScorers({
      players: leaguePlayersLike,
      teams: leaderTeams,
      take: 5,
    });
    const topEuroScorers: PlayerLeaderDTO[] = liveEuroScorers({
      players: allPlayersLike,
      teams: leaderTeams,
      take: 10,
    });

    const response: AwardsResponse = {
      ok: true,
      awards,
      live: { ...leaders, topCupScorers, topEuroScorers },
    };
    return response;
  },

  // ── Диалог игрока (Фаза 3) ──
  'GET /player': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    if (!save.teamId) throw new ApiGameError('SAVE_NOT_FOUND', 404);

    const playerId = queryStr(req, 'id')?.trim();
    if (!playerId) throw new ApiGameError('INVALID_PAYLOAD', 400);

    const playerRow = await db.player.findFirst({
      where: { id: playerId, saveId: save.id },
    });
    if (!playerRow) throw new ApiGameError('PLAYER_NOT_FOUND', 404);

    // Запрошенная цена, если игрок выставлен на рынок
    const listing = await db.transferListing.findFirst({
      where: { playerId: playerRow.id, status: 'active' },
      select: { price: true },
    });

    // История по сезонам (по возрастанию)
    const recordRows = await db.playerSeasonRecord.findMany({
      where: { playerId: playerRow.id, saveId: save.id },
      orderBy: [{ season: 'asc' }],
    });
    const history: PlayerHistoryDTO[] = recordRows.map((r) => ({
      season: r.season,
      teamName: r.teamName,
      age: r.age,
      position: r.position,
      apps: r.apps,
      goals: r.goals,
      assists: r.assists,
      cupGoals: r.cupGoals,
      cupAssists: r.cupAssists,
      // ── Фаза 4: евросезон в карточке игрока ──
      euroGoals: r.euroGoals,
      euroAssists: r.euroAssists,
      cleanSheets: r.cleanSheets,
      yellowCards: r.yellowCards,
      redCards: r.redCards,
      avgRating: r.avgRating > 0 ? r.avgRating / 10 : null,
    }));

    // Карьерные итоги из строк истории
    const rows: SeasonRecordRow[] = recordRows.map((r) => ({
      playerId: r.playerId,
      teamId: r.teamId,
      teamName: r.teamName,
      age: r.age,
      position: r.position,
      apps: r.apps,
      goals: r.goals,
      assists: r.assists,
      cupGoals: r.cupGoals,
      cupAssists: r.cupAssists,
      euroGoals: r.euroGoals, // Фаза 4 (§5.6-3)
      euroAssists: r.euroAssists,
      cleanSheets: r.cleanSheets,
      yellowCards: r.yellowCards,
      redCards: r.redCards,
      avgRating: r.avgRating,
    }));
    const totals = careerTotalsOf(rows);

    // Награды игрока за все сезоны
    const awardRows = await db.seasonAward.findMany({
      where: { playerId: playerRow.id, saveId: save.id },
      orderBy: [{ season: 'asc' }, { createdAt: 'asc' }],
    });
    const teams = await db.team.findMany({
      where: { saveId: save.id },
      select: { id: true, name: true },
    });
    const teamName = new Map(teams.map((t) => [t.id, t.name]));
    const playerName = `${playerRow.firstName} ${playerRow.lastName}`;
    const awards: SeasonAwardDTO[] = awardRows.map((r) => ({
      id: r.id,
      season: r.season,
      type: r.type,
      typeName: AWARD_TYPE_LABELS[r.type] ?? r.type,
      playerId: r.playerId,
      playerName,
      teamId: r.teamId,
      teamName: teamName.get(r.teamId) ?? '',
      value: r.value,
      label: r.label,
    }));

    const dialog: PlayerDialogDTO = {
      player: toPlayerDTO(playerRow, listing ? listing.price : null),
      history,
      totals,
      awards,
    };
    const response: PlayerDialogResponse = { ok: true, dialog };
    return response;
  },

  // ── Кубок Европы (Фаза 4; resolveSave — finished-сейвы доступны) ──
  'GET /euro': async (req) => {
    const saveId = await ensureSlotFor(saveIdOf(req));
    const save = await resolveSave(saveId);
    const euro = await buildEuroSnapshot(save);
    const response: EuroResponse = { ok: true, euro };
    return response;
  },

  // ── Служебные (§1.6/§2.3: селект слота, rollback, выход, принудительный сейв) ──
  /** Движковая «селект»-семантика: загрузить слот saveId + touch lastOpenedAt. */
  'POST /select': async (req) => {
    const saveId = saveIdOf(req);
    const ensured = await ensureSlotFor(saveId);
    await resolveSave(ensured);
    await getEngine().touchSlot(new Date());
    markDirty();
    return { ok: true as const };
  },

  /** Полная перезагрузка АКТИВНОГО слота с диска (rollback/гость/отладка). */
  'POST /reload': async () => {
    if (!getEngine().store) throw new ApiGameError('SAVE_NOT_FOUND', 404);
    await getEngine().reload();
    return { ok: true as const };
  },

  /** Сброс активной карьеры (выход к списку карьер). */
  'POST /unload': async () => {
    getEngine().unload();
    return { ok: true as const };
  },

  /** Отметка «недавно открытый» (gameSave.lastOpenedAt + конверт слота). */
  'POST /touch': async () => {
    if (!getEngine().store) throw new ApiGameError('SAVE_NOT_FOUND', 404);
    await getEngine().touchSlot(new Date());
    markDirty();
    return { ok: true as const };
  },

  /** Принудительный автосейв активной карьеры (выполняется сразу после ответа). */
  'POST /save': async () => {
    if (!getEngine().store) throw new ApiGameError('SAVE_NOT_FOUND', 404);
    markDirty();
    return { ok: true as const };
  },
};

// ── Локальные константы/хелперы (порты из route.ts) ───────────────────────

const POSITIONS: MarketPositionFilter[] = ['ALL', 'GK', 'DEF', 'MID', 'FWD'];
const SORTS: MarketSort[] = ['ovr', 'price', 'age'];

const TRAINING_FOCUS_CODES: TrainingFocus[] = [
  'attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest',
];
const TRAINING_INTENSITY_CODES: TrainingIntensity[] = ['light', 'normal', 'hard'];

/** Подсказки эффектов: подписи фокусов/интенсивностей + числовые эффекты. */
function trainingHints(): TrainingHintsDTO {
  return {
    focuses: TRAINING_FOCUS_CODES.map((code) => ({
      code,
      label: TRAINING_FOCUS_LABELS[code],
      attrLabels: FOCUS_ATTRS[code].map((attr) => ATTR_LABELS[attr]),
    })),
    intensities: TRAINING_INTENSITY_CODES.map((code) => ({
      code,
      label: TRAINING_INTENSITY_LABELS[code],
      growthFactor: TRAIN_INTENSITY_FACTOR[code],
      conditionDelta: TRAIN_CONDITION_DELTA[code],
      injuryRiskPct: Math.round(TRAIN_INJURY_RISK[code] * 1000) / 10,
    })),
    restConditionBonus: TRAIN_REST_COND,
    restMoraleBonus: TRAIN_REST_MORALE,
  };
}

// ── Диспетчер (§1.5) ───────────────────────────────────────────────────────

interface CompiledRoute {
  method: string;
  segments: string[];
  handler: EngineHandler;
}

function compileRoutes(): CompiledRoute[] {
  const out: CompiledRoute[] = [];
  for (const [key, handler] of Object.entries(engineRoutes)) {
    const space = key.indexOf(' ');
    const method = key.slice(0, space);
    const segments = key.slice(space + 1).split('/').filter((s) => s.length > 0);
    out.push({ method, segments, handler });
  }
  return out;
}

const compiledRoutes: CompiledRoute[] = compileRoutes();

function decodeSegment(segment: string): string {
  try {
    return decodeURIComponent(segment);
  } catch {
    return segment;
  }
}

/**
 * Диспетчер виртуального API: `engineDispatch('POST', '/simulate', { saveId })`.
 * Матчит путь по карте (сегменты ':param' захватываются в req); ошибки — как в
 * роутах: ApiGameError → нормализованный код (NO_SAVE → SAVE_NOT_FOUND);
 * непредвиденное — console.error + откат активного слота + UNKNOWN 500.
 * Хендлеры выполняются под счётчиком глубины: автосейв не стартует внутри.
 */
export async function engineDispatch(
  method: string,
  path: string,
  req: EngineRequest = {},
): Promise<unknown> {
  const m = method.toUpperCase();
  const segs = path.split('/').filter((s) => s.length > 0).map(decodeSegment);

  let handler: EngineHandler | null = null;
  let callReq: EngineRequest = req;
  for (const route of compiledRoutes) {
    if (route.method !== m || route.segments.length !== segs.length) continue;
    const params: Record<string, string> = {};
    let matched = true;
    for (let i = 0; i < segs.length; i++) {
      const pattern = route.segments[i];
      if (pattern.startsWith(':')) {
        params[pattern.slice(1)] = segs[i];
      } else if (pattern !== segs[i]) {
        matched = false;
        break;
      }
    }
    if (!matched) continue;
    handler = route.handler;
    callReq = Object.keys(params).length > 0 ? { ...req, ...params } : req;
    break;
  }

  if (!handler) {
    console.error(`[engine] нет хендлера для ${m} ${path}`);
    throw new ApiGameError('UNKNOWN', 500);
  }

  mutatingDepth += 1;
  try {
    return await handler(callReq);
  } catch (error) {
    if (error instanceof ApiGameError) {
      throw new ApiGameError(normalizeErrorCode(error.code), error.status);
    }
    console.error(`[engine ${m} ${path}]`, error);
    await rollbackActiveSlot();
    throw new ApiGameError('UNKNOWN', 500);
  } finally {
    mutatingDepth -= 1;
    if (dirty) {
      queueMicrotask(() => {
        void flushSave();
      });
    }
  }
}

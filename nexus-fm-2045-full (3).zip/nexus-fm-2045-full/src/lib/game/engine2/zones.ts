/**
 * ENGINE 2.0 — зоны поля и привязка игроков к зонам.
 *
 * Модель: 3 трети поля (DEF/MID/ATT — с точки ВЛАДЕЮЩЕЙ команды) × 3 коридора
 * (L/C/R) = 9 зон + BOX (штрафная соперника) = 10 зон. Мяч живёт в зоне;
 * действия выбираются по зоне, исполнители — по совместимости позиции со
 * слотом формации (слоты FORMATIONS уже несут координаты x/y — они же
 * используются 2D-радаром).
 */

import { FORMATIONS } from '../constants';
import type { Position, FormationId } from '../types';

// ── Зоны ──────────────────────────────────────────────────────────────────

export type ZoneLane = 'L' | 'C' | 'R';
export type ZoneId = 'DC' | 'DL' | 'DR' | 'MC' | 'ML' | 'MR' | 'AC' | 'AL' | 'AR' | 'BOX';

/** Зона → координата центра (атакующее направление, x: 0 свои ворота → 100 чужие). */
export const ZONE_XY: Record<ZoneId, { x: number; y: number }> = {
  DL: { x: 22, y: 16 },
  DC: { x: 22, y: 50 },
  DR: { x: 22, y: 84 },
  ML: { x: 47, y: 15 },
  MC: { x: 47, y: 50 },
  MR: { x: 47, y: 85 },
  AL: { x: 74, y: 18 },
  AC: { x: 74, y: 50 },
  AR: { x: 74, y: 82 },
  BOX: { x: 89, y: 50 },
};

export function zoneLaneOf(zone: ZoneId): ZoneLane {
  return zone === 'BOX' ? 'C' : (zone[1] as ZoneLane);
}

export function zoneIsFlank(zone: ZoneId): boolean {
  return zone.endsWith('L') || zone.endsWith('R');
}

/** Треть зоны (глубина). */
export function zoneThirdOf(zone: ZoneId): 'DEF' | 'MID' | 'ATT' {
  if (zone === 'BOX') return 'ATT';
  return zone[0] === 'D' ? 'DEF' : zone[0] === 'M' ? 'MID' : 'ATT';
}

// ── Совместимость позиций с зонами ────────────────────────────────────────

/**
 * Вес позиции в зоне (0 — не играет здесь, 1 — профильная, 2 — основная).
 * Зона описана в атакующих терминах ВЛАДЕЮЩЕЙ команды; для подбора
 * ЗАЩИТНИКА используется та же карта (защитник «привязан» к своей трети).
 */
const POSITION_ZONE: Record<Position, Partial<Record<ZoneId, number>>> = {
  GK: {},
  DC: { DC: 2, DL: 0.6, DR: 0.6, MC: 0.35, BOX: 1.2 },
  DL: { DL: 2, ML: 1, DR: 0.4, AL: 0.35, BOX: 0.3 },
  DR: { DR: 2, MR: 1, DL: 0.4, AR: 0.35, BOX: 0.3 },
  DML: { ML: 1.8, DL: 1, MR: 0.4, AL: 0.5 },
  DMC: { MC: 2, DC: 1.2, ML: 0.5, MR: 0.5, AC: 0.35 },
  DMR: { MR: 1.8, DR: 1, ML: 0.4, AR: 0.5 },
  ML: { ML: 2, DL: 0.7, AL: 1, MC: 0.5, AC: 0.2 },
  MC: { MC: 2, ML: 0.6, MR: 0.6, AC: 0.8, DC: 0.3 },
  MR: { MR: 2, DR: 0.7, AR: 1, MC: 0.5, AC: 0.2 },
  AML: { AL: 2, ML: 1.2, AR: 0.25, AC: 0.3, BOX: 0.5 },
  AMC: { AC: 2, MC: 1.2, BOX: 0.9, AL: 0.3, AR: 0.3 },
  AMR: { AR: 2, MR: 1.2, AL: 0.25, AC: 0.3, BOX: 0.5 },
  ST: { BOX: 2, AC: 1.4, AL: 0.5, AR: 0.5 },
};

/** Итоговый вес игрока позиции P в зоне Z (0 если позиция там не играет). */
export function positionZoneWeight(position: Position, zone: ZoneId): number {
  return POSITION_ZONE[position][zone] ?? 0;
}

// ── Занятость зон состава (по слотам формации) ────────────────────────────

/**
 * Карта занятости: зона → список позиций слотов XI, которые её «закрывают».
 * Строится из FORMATIONS[formation].slots (позиция слота сама говорит,
 * какую зону игрок держит). Пересчитывается при заменах.
 */
export type ZoneOccupancy = Map<ZoneId, Position[]>;

export function buildZoneOccupancy(formation: FormationId, lineup: (string | null)[]): ZoneOccupancy {
  const slots = FORMATIONS[formation].slots;
  const occ: ZoneOccupancy = new Map();
  const allZones: ZoneId[] = ['DC', 'DL', 'DR', 'MC', 'ML', 'MR', 'AC', 'AL', 'AR', 'BOX'];
  for (const z of allZones) occ.set(z, []);
  for (let i = 0; i < slots.length && i < lineup.length; i++) {
    const pid = lineup[i];
    if (!pid) continue;
    const slotPos = slots[i].position;
    for (const z of allZones) {
      if (positionZoneWeight(slotPos, z) >= 1) occ.get(z)!.push(slotPos);
    }
  }
  return occ;
}

/** Плотность зоны: сколько игроков XI закрывают зону (0..5). */
export function zoneDensity(occ: ZoneOccupancy, zone: ZoneId): number {
  return occ.get(zone)?.length ?? 0;
}

// ── Соседство и прогрессия ────────────────────────────────────────────────

const LANE_ORDER: Record<ZoneLane, number> = { L: 0, C: 1, R: 2 };

/** Разница коридоров (0 — тот же, 1 — соседний, 2 — диагональ). */
export function laneDistance(a: ZoneId, b: ZoneId): number {
  return Math.abs(LANE_ORDER[zoneLaneOf(a)] - LANE_ORDER[zoneLaneOf(b)]);
}

/** Целевые зоны безопасного паса из зоны z (назад/в сторону, без риска). */
export function safePassTargets(zone: ZoneId): ZoneId[] {
  switch (zone) {
    case 'DL':
    case 'DR':
      return ['DC', 'ML', 'MR', 'MC'];
    case 'DC':
      return ['DL', 'DR', 'MC', 'DC'];
    case 'ML':
    case 'MR':
      return ['MC', 'DL', 'DR'];
    case 'MC':
      return ['ML', 'MR', 'DC', 'MC'];
    case 'AL':
      return ['ML', 'AC', 'MC'];
    case 'AR':
      return ['MR', 'AC', 'MC'];
    case 'AC':
      return ['MC', 'AL', 'AR'];
    case 'BOX':
      return ['AC', 'AL', 'AR'];
  }
}

/** Целевые зоны прогрессирующего паса (вперёд на одну треть). */
export function progPassTargets(zone: ZoneId): ZoneId[] {
  switch (zone) {
    case 'DL':
      return ['ML', 'MC'];
    case 'DR':
      return ['MR', 'MC'];
    case 'DC':
      return ['MC'];
    case 'ML':
      return ['AL', 'AC'];
    case 'MR':
      return ['AR', 'AC'];
    case 'MC':
      return ['AC', 'AL', 'AR', 'BOX'];
    case 'AL':
      return ['BOX'];
    case 'AR':
      return ['BOX'];
    case 'AC':
      return ['BOX'];
    case 'BOX':
      return [];
  }
}

/** Зеркальная зона: те же мировые координаты в терминах ДРУГОЙ команды. */
export function flipZone(zone: ZoneId): ZoneId {
  switch (zone) {
    case 'DL': return 'AR';
    case 'DC': return 'AC';
    case 'DR': return 'AL';
    case 'ML': return 'MR';
    case 'MC': return 'MC';
    case 'MR': return 'ML';
    case 'AL': return 'DR';
    case 'AC': return 'DC';
    case 'AR': return 'DL';
    case 'BOX': return 'DC';
  }
}

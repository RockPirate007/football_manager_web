// Dev-утилита для легаси SQLite (db/custom.db): сервер удалён в D-4, клиент
// Prisma создаётся локально (в src/ импортов @prisma/client больше нет).
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

async function main() {
  const saves = await db.gameSave.findMany({ select: { id: true, managerName: true, leagueCode: true, status: true, season: true, week: true } });
  console.log('saves:', JSON.stringify(saves, null, 2));
  const counts = {
    teams: await db.team.count(),
    players: await db.player.count(),
    matches: await db.match.count(),
    awards: await db.seasonAward.count(),
  };
  console.log('counts:', counts);
  await db.$disconnect();
}
main();

'use client';

/**
 * Модуль 4 «Персонал»: штат клуба + рынок труда тренеров.
 * Эффекты штата (XP/травмы/восстановление/скаутинг), слоты ролей,
 * найм (срок 1–3, подписной бонус), увольнение (компенсация),
 * продление контракта. Живёт вкладкой внутри TrainingScreen.
 */

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, Bandage, ClipboardCheck, Dumbbell, Eye, Handshake, Loader2, RefreshCw, UserRound,
  UserRoundMinus, UserRoundPlus, Users, Wallet,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { STAFF_ROLE_LABELS, STAFF_SPECIALTY_LABELS, type StaffRoleCode } from '@/lib/game/staff';
import { formatMoneyExact } from '@/lib/game/format';
import type { StaffDTO, StaffRole } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const ROLE_ORDER: StaffRole[] = ['head_coach', 'assistant', 'fitness', 'physio', 'scout'];

const ROLE_ICONS: Record<StaffRole, typeof ClipboardCheck> = {
  head_coach: ClipboardCheck,
  assistant: UserRound,
  fitness: Dumbbell,
  physio: Bandage,
  scout: Eye,
};

function ratingToneOf(rating: number): string {
  if (rating >= 78) return 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]';
  if (rating >= 60) return 'border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]';
  if (rating >= 45) return 'border-border bg-secondary text-foreground';
  return 'border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]';
}

/** Рейтинг-бейдж + спец-подпись. */
function StaffRating({ rating, specialty }: { rating: number; specialty: string | null }) {
  return (
    <div className="flex items-center gap-1.5">
      <Badge className={cn('border text-[10px] font-bold tabular', ratingToneOf(rating))}>
        {rating}
      </Badge>
      {specialty !== null ? (
        <span className="text-[10px] text-muted-foreground">
          {STAFF_SPECIALTY_LABELS[specialty] ?? specialty}
        </span>
      ) : null}
    </div>
  );
}

/** Один слот роли: сотрудник ИЛИ «вакансия». */
function StaffCard({
  member,
  onRenew,
  onFire,
}: {
  member: StaffDTO;
  onRenew: (s: StaffDTO) => void;
  onFire: (s: StaffDTO) => void;
}) {
  const Icon = ROLE_ICONS[member.role] ?? UserRound;
  const expiring = member.yearsLeft <= 1;
  return (
    <Card className="border-border/70">
      <CardContent className="space-y-2 p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Icon className="size-4 shrink-0 text-primary" aria-hidden />
              <span className="truncate text-sm font-semibold">
                {member.firstName} {member.lastName}
              </span>
            </div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">
              {STAFF_ROLE_LABELS[member.role as StaffRoleCode] ?? member.role} · {member.age} лет
            </div>
          </div>
          <StaffRating rating={member.rating} specialty={member.specialty} />
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-muted-foreground">Зарплата</span>
          <span className="font-semibold tabular">{formatMoneyExact(member.salary)}/нед</span>
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-muted-foreground">Контракт</span>
          <span
            className={cn(
              'font-semibold tabular',
              expiring && 'text-[#EF4444]',
            )}
          >
            {expiring ? 'истекает' : `до сезона ${member.contractUntil}`}
          </span>
        </div>
        <div className="flex gap-2 pt-1">
          <Button
            variant="outline"
            size="sm"
            className="h-7 flex-1 text-[11px]"
            onClick={() => onRenew(member)}
          >
            <RefreshCw className="size-3" aria-hidden />
            Продлить
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-7 flex-1 border-[#EF4444]/40 text-[11px] text-[#EF4444] hover:bg-[#EF4444]/10 hover:text-[#EF4444]"
            onClick={() => onFire(member)}
          >
            <UserRoundMinus className="size-3" aria-hidden />
            Уволить
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/** Кандидат рынка. */
function CandidateCard({
  member,
  slotFull,
  onHire,
}: {
  member: StaffDTO;
  slotFull: boolean;
  onHire: (s: StaffDTO) => void;
}) {
  const Icon = ROLE_ICONS[member.role] ?? UserRound;
  return (
    <Card className={cn('border-border/70', slotFull && 'opacity-60')}>
      <CardContent className="space-y-2 p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Icon className="size-4 shrink-0 text-muted-foreground" aria-hidden />
              <span className="truncate text-sm font-semibold">
                {member.firstName} {member.lastName}
              </span>
            </div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">
              {STAFF_ROLE_LABELS[member.role as StaffRoleCode] ?? member.role} · {member.age} лет
            </div>
          </div>
          <StaffRating rating={member.rating} specialty={member.specialty} />
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-muted-foreground">Спрос</span>
          <span className="font-semibold tabular">{formatMoneyExact(member.salary)}/нед</span>
        </div>
        <Button
          size="sm"
          className="h-7 w-full text-[11px]"
          disabled={slotFull}
          title={slotFull ? 'Слот роли занят — сначала уволите текущего сотрудника' : undefined}
          onClick={() => onHire(member)}
        >
          <UserRoundPlus className="size-3" aria-hidden />
          {slotFull ? 'Слот занят' : 'Нанять'}
        </Button>
      </CardContent>
    </Card>
  );
}

/** Диалог выбора срока (найм/продление). */
function YearsDialog({
  open,
  onClose,
  title,
  description,
  confirmLabel,
  years,
  setYears,
  onConfirm,
  busy,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description: string;
  confirmLabel: string;
  years: number;
  setYears: (y: number) => void;
  onConfirm: () => void;
  busy: boolean;
}) {
  return (
    <Dialog open={open} onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-base">{title}</DialogTitle>
          <DialogDescription className="text-xs leading-relaxed">{description}</DialogDescription>
        </DialogHeader>
        <div className="flex items-center gap-2">
          {[1, 2, 3].map((y) => (
            <button
              key={y}
              type="button"
              aria-pressed={years === y}
              onClick={() => setYears(y)}
              className={cn(
                'h-9 flex-1 rounded-lg border text-sm font-semibold transition-colors',
                years === y
                  ? 'border-primary bg-primary/10 text-primary'
                  : 'border-border/60 bg-secondary/30 hover:border-primary/40',
              )}
            >
              {y} {y === 1 ? 'сезон' : 'сезона'}
            </button>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={busy}>
            Отмена
          </Button>
          <Button onClick={onConfirm} disabled={busy}>
            {busy ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Вкладка «Персонал» экрана тренировок. */
export function StaffTab() {
  const staffCache = useGameStore((s) => s.staffCache);
  const staffLoading = useGameStore((s) => s.staffLoading);
  const fetchStaff = useGameStore((s) => s.fetchStaff);
  const hireStaff = useGameStore((s) => s.hireStaff);
  const fireStaff = useGameStore((s) => s.fireStaff);
  const renewStaff = useGameStore((s) => s.renewStaff);
  const loading = useGameStore((s) => s.loading);
  const snapshot = useGameStore((s) => s.snapshot);

  const totalWeeks = snapshot?.save.totalWeeks ?? 44;
  const currentWeek = staffCache?.week ?? snapshot?.save.week ?? 1;
  /** Осталось недель в сезоне (для оценки компенсации при увольнении). */
  const weeksLeftInSeason = Math.max(4, totalWeeks - currentWeek);

  const [roleFilter, setRoleFilter] = useState<'all' | StaffRole>('all');
  const [hireTarget, setHireTarget] = useState<StaffDTO | null>(null);
  const [hireYears, setHireYears] = useState(2);
  const [renewTarget, setRenewTarget] = useState<StaffDTO | null>(null);
  const [renewYears, setRenewYears] = useState(2);
  const [fireTarget, setFireTarget] = useState<StaffDTO | null>(null);

  useEffect(() => {
    void fetchStaff();
  }, [fetchStaff]);

  const data = staffCache;
  const slotByRole = useMemo(() => {
    const map = new Map<string, { used: number; max: number }>();
    for (const s of data?.slots ?? []) map.set(s.role, { used: s.used, max: s.max });
    return map;
  }, [data]);

  const market = useMemo(() => {
    const rows = data?.market ?? [];
    return roleFilter === 'all' ? rows : rows.filter((m) => m.role === roleFilter);
  }, [data, roleFilter]);

  const staff = data?.staff ?? [];

  if (staffLoading && !data) {
    return (
      <div className="flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Загружаем штаб и рынок персонала…
      </div>
    );
  }

  if (!data) {
    return (
      <p className="py-8 text-center text-xs text-muted-foreground">
        Данные персонала появятся после загрузки.
      </p>
    );
  }

  const e = data.effects;
  const xpPct = Math.round((e.xpMult - 1) * 100);
  const injuryPct = Math.round((e.injuryRiskMult - 1) * 100);

  return (
    <div className="space-y-4">
      {/* Эффекты штата */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Activity className="size-3.5" aria-hidden />
              Рост (XP)
            </div>
            <div className={cn('mt-1 text-sm font-bold tabular', xpPct >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]')}>
              {xpPct >= 0 ? '+' : ''}{xpPct}%
            </div>
            <div className="text-[10px] text-muted-foreground">главный тренер · U23 ×{e.youthXpMult.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Bandage className="size-3.5" aria-hidden />
              Риск травм
            </div>
            <div className={cn('mt-1 text-sm font-bold tabular', injuryPct <= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]')}>
              {injuryPct >= 0 ? '+' : ''}{injuryPct}%
            </div>
            <div className="text-[10px] text-muted-foreground">
              физио{e.healChance > 0 ? ` · лечение +${Math.round(e.healChance * 100)}%` : ''}
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Dumbbell className="size-3.5" aria-hidden />
              Восстановление
            </div>
            <div className={cn('mt-1 text-sm font-bold tabular', e.recoveryBonus >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]')}>
              {e.recoveryBonus >= 0 ? '+' : ''}{e.recoveryBonus}/нед
            </div>
            <div className="text-[10px] text-muted-foreground">фитнес-тренер</div>
          </CardContent>
        </Card>
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Eye className="size-3.5" aria-hidden />
              Скауты
            </div>
            <div className="mt-1 text-sm font-bold tabular">
              {e.scoutSlots.used}/{e.scoutSlots.total}
            </div>
            <div className="text-[10px] text-muted-foreground">
              {e.bestScoutRating === null ? 'глаз клуба (45)' : `лучший скаут ${e.bestScoutRating}`}
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Users className="size-3.5" aria-hidden />
              Штат
            </div>
            <div className="mt-1 text-sm font-bold tabular">
              {staff.length}/{data.slots.reduce((s, x) => s + x.max, 0)}
            </div>
            <div className="text-[10px] text-muted-foreground">
              ведомость {formatMoneyExact(data.weeklyWages)}/нед
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Wallet className="size-3.5" aria-hidden />
              Баланс клуба
            </div>
            <div className="mt-1 text-sm font-bold tabular">{formatMoneyExact(data.balance)}</div>
            <div className="text-[10px] text-muted-foreground">найм: бонус 4 нед. зарплаты</div>
          </CardContent>
        </Card>
      </div>

      {/* Мой штаб */}
      <Card className="border-border/70">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Мой штаб</CardTitle>
        </CardHeader>
        <CardContent>
          {staff.length === 0 ? (
            <p className="py-4 text-center text-xs text-muted-foreground">
              Штаб пуст — весь персонал покинул клуб. Наймите замену на рынке ниже.
            </p>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {staff.map((m) => (
                <StaffCard
                  key={m.id}
                  member={m}
                  onRenew={(s) => {
                    setRenewTarget(s);
                    setRenewYears(2);
                  }}
                  onFire={(s) => setFireTarget(s)}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Рынок персонала */}
      <Card className="border-border/70">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            Рынок персонала
            <Badge variant="secondary" className="text-[10px]">{market.length} кандидатов</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="Фильтр роли">
            <button
              type="button"
              aria-pressed={roleFilter === 'all'}
              onClick={() => setRoleFilter('all')}
              className={cn(
                'rounded-full border px-3 py-1 text-[11px] font-medium transition-colors',
                roleFilter === 'all'
                  ? 'border-primary bg-primary/10 text-primary'
                  : 'border-border/60 bg-secondary/30 hover:border-primary/40',
              )}
            >
              Все роли
            </button>
            {ROLE_ORDER.map((role) => {
              const slot = slotByRole.get(role);
              const full = slot ? slot.used >= slot.max : false;
              return (
                <button
                  key={role}
                  type="button"
                  aria-pressed={roleFilter === role}
                  onClick={() => setRoleFilter(role)}
                  className={cn(
                    'rounded-full border px-3 py-1 text-[11px] font-medium transition-colors',
                    roleFilter === role
                      ? 'border-primary bg-primary/10 text-primary'
                      : 'border-border/60 bg-secondary/30 hover:border-primary/40',
                    full && roleFilter === 'all' ? 'border-[#EAB308]/40 text-[#EAB308]' : '',
                  )}
                  title={full ? 'Слот роли занят в вашем клубе' : undefined}
                >
                  {STAFF_ROLE_LABELS[role as StaffRoleCode]} {full ? '· полно' : ''}
                </button>
              );
            })}
          </div>

          {market.length === 0 ? (
            <p className="py-4 text-center text-xs text-muted-foreground">
              Свободных кандидатов этой роли сейчас нет — рынок обновляется каждую неделю.
            </p>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
            >
              {market.map((m) => {
                const slot = slotByRole.get(m.role);
                const full = slot ? slot.used >= slot.max : true;
                return (
                  <CandidateCard
                    key={m.id}
                    member={m}
                    slotFull={full}
                    onHire={(s) => {
                      setHireTarget(s);
                      setHireYears(2);
                    }}
                  />
                );
              })}
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Диалог найма */}
      <YearsDialog
        open={hireTarget !== null}
        onClose={() => setHireTarget(null)}
        title={hireTarget ? `${hireTarget.firstName} ${hireTarget.lastName} — найм` : ''}
        description={
          hireTarget
            ? `Подписной бонус €${formatMoneyExact(hireTarget.salary * 4)} спишется сразу. `
              + `Зарплата ${formatMoneyExact(hireTarget.salary)}/нед (категория «Зарплаты штата»). `
              + `Рейтинг ${hireTarget.rating}${hireTarget.specialty ? `, специализация: ${STAFF_SPECIALTY_LABELS[hireTarget.specialty] ?? hireTarget.specialty}` : ''}.`
            : ''
        }
        confirmLabel="Принять в штаб"
        years={hireYears}
        setYears={setHireYears}
        busy={loading}
        onConfirm={async () => {
          if (!hireTarget) return;
          const ok = await hireStaff(hireTarget.id, hireYears);
          if (ok) setHireTarget(null);
        }}
      />

      {/* Диалог продления */}
      <YearsDialog
        open={renewTarget !== null}
        onClose={() => setRenewTarget(null)}
        title={renewTarget ? `${renewTarget.firstName} ${renewTarget.lastName} — продление` : ''}
        description={
          renewTarget
            ? `Новая зарплата ≈ ${formatMoneyExact(Math.round(Math.max(renewTarget.salary, renewTarget.rating * 40) * 1.05))}/нед. `
              + 'Контракт вступает в силу до конца указанного сезона включительно.'
            : ''
        }
        confirmLabel="Продлить контракт"
        years={renewYears}
        setYears={setRenewYears}
        busy={loading}
        onConfirm={async () => {
          if (!renewTarget) return;
          const ok = await renewStaff(renewTarget.id, renewYears);
          if (ok) setRenewTarget(null);
        }}
      />

      {/* Подтверждение увольнения */}
      <AlertDialog open={fireTarget !== null} onOpenChange={(v) => (v ? undefined : setFireTarget(null))}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Уволить {fireTarget ? `${fireTarget.firstName} ${fireTarget.lastName}?` : ''}
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-relaxed">
              Компенсация ≈ €
              {fireTarget
                ? formatMoneyExact(fireTarget.salary * weeksLeftInSeason)
                : '0'}{' '}
              ({weeksLeftInSeason} нед. × {fireTarget ? formatMoneyExact(fireTarget.salary) : '—'}). Эффекты роли пропадут со следующей недели.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              className="bg-[#EF4444] text-white hover:bg-[#EF4444]/90"
              onClick={() => {
                if (fireTarget) void fireStaff(fireTarget.id);
                setFireTarget(null);
              }}
            >
              <Handshake className="size-4" aria-hidden />
              Уволить с компенсацией
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

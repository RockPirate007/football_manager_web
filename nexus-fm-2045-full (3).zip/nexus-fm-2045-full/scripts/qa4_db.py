#!/usr/bin/env python3
"""QA Фаза 4 (Task P4-5) — прямой доступ к db/custom.db (sqlite3) для
scripts/smoke_phase4.sh. Каждая команда печатает «key=value» строки.
Запуск: python3 scripts/qa4_db.py <cmd> <saveId> [args...]
"""
import json
import sqlite3
import sys
import os

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'db', 'custom.db')
STYLES = {'balanced', 'gegenpress', 'tikitaka', 'bus', 'vertical'}
RECOGNIZABLE = {'gegenpress', 'tikitaka', 'bus', 'vertical'}


def con():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def rows(c, sql, args=()):
    return c.execute(sql, args).fetchall()


def one(c, sql, args=()):
    r = c.execute(sql, args).fetchone()
    return r[0] if r is not None else None


def user_team_id(c, save_id):
    return one(c, 'SELECT teamId FROM GameSave WHERE id=?', (save_id,))


def parse_ids(raw):
    if not raw:
        return []
    try:
        v = json.loads(raw)
        return v if isinstance(v, list) else []
    except Exception:
        return []


def cmd_styles(save_id):
    c = con()
    teams = rows(c, 'SELECT * FROM Team WHERE saveId=? AND isEuroGuest=0', (save_id,))
    ai = [t for t in teams if not t['isUserTeam']]
    user = [t for t in teams if t['isUserTeam']]
    valid = sum(1 for t in ai if t['aiStyle'] in STYLES)
    coach_missing = sum(1 for t in ai if not (t['aiCoachName'] or '').strip())
    recognizable = sum(1 for t in ai if t['aiStyle'] in RECOGNIZABLE)
    dist = {}
    for t in ai:
        dist[t['aiStyle'] or 'null'] = dist.get(t['aiStyle'] or 'null', 0) + 1
    print(f'teams_total={len(teams)}')
    print(f'ai_teams={len(ai)}')
    print(f'ai_style_valid={valid}')
    print(f'ai_coach_missing={coach_missing}')
    print(f'ai_recognizable_pct={round(100 * recognizable / max(1, len(ai)))}')
    print(f'user_matchplan_null={sum(1 for t in user if t["matchPlan"] is None)}')
    print(f'user_aiStyle={user[0]["aiStyle"] if user else "none"}')
    print('style_dist=' + ' '.join(f'{k}:{v}' for k, v in sorted(dist.items())))


def cmd_snapcond(save_id):
    """Срез состояния клуба игрока: id condition stamina apps (в stdout)."""
    c = con()
    tid = user_team_id(c, save_id)
    for r in rows(c, 'SELECT id, condition, stamina, apps FROM Player WHERE teamId=? ORDER BY id', (tid,)):
        print(f'{r["id"]} {r["condition"]} {r["stamina"]} {r["apps"]}')


def _mins_for(events, team_id, pid):
    """Минуты игрока в матче по событиям ЕГО команды.
    Корректно для игроков, УЧАВСТВОВАВШИХ в матче (apps+): отсутствие событий
    замены/удаления = полный матч (90)."""
    in_m = out_m = off_m = None
    for e in events:
        if e.get('teamId') != team_id:
            continue
        t = e.get('type')
        if t == 'sub':
            if e.get('playerId') == pid and in_m is None:
                in_m = e['minute']
            if e.get('subOutId') == pid and out_m is None:
                out_m = e['minute']
        elif t in ('red', 'injury') and e.get('playerId') == pid:
            off_m = min(off_m if off_m is not None else 999, e['minute'])
    m = (90 - in_m) if in_m is not None else 90
    if out_m is not None:
        m = min(m, out_m)
    if off_m is not None:
        m = min(m, off_m)
    return max(0, m)


def cmd_congestion(save_id, cup_id, euro_id, before_file):
    """Инвариант §9.8: recovery +8 ровно ОДИН раз при 2 матчах.
    Для каждого игрока, сыгравшего ОБА матча (apps +2), минуты восстанавливаются
    из событий (замены/удаления), drain = max(8, 22 − stamina/12) (tempo/pressing
    medium), ожидаемая дельта = −rate×(m1+m2)/90 + 8; допуск ±2 (зажимы 30/100
    исключены фильтром expected ∈ [35, 95])."""
    c = con()
    tid = user_team_id(c, save_id)
    team = rows(c, 'SELECT * FROM Team WHERE id=?', (tid,))[0]
    tempo, pressing = team['tempo'], team['pressing']
    # Тренировка тоже двигает condition каждую неделю (Фаза 2):
    # rest → +10 (TRAIN_REST_COND); иначе TRAIN_CONDITION_DELTA[intensity]
    if team['trainingFocus'] == 'rest':
        train_cond = 10
    else:
        train_cond = {'light': 5, 'normal': 0, 'hard': -8}.get(team['trainingIntensity'], 0)
    before = {}
    with open(before_file, encoding='utf-8') as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 4:
                before[parts[0]] = (float(parts[1]), int(parts[2]), int(parts[3]))
    now = {r['id']: (r['condition'], r['apps']) for r in rows(
        c, 'SELECT id, condition, apps FROM Player WHERE teamId=?', (tid,))}
    events = {}
    for mid in (cup_id, euro_id):
        raw = one(c, 'SELECT events FROM Match WHERE id=?', (mid,))
        events[mid] = json.loads(raw or '[]')
    tempo_mod = 2 if tempo == 'high' else (-2 if tempo == 'low' else 0)
    press_mod = 3 if pressing == 'high' else 0

    qualified, within, mismatches, bench_neither = 0, 0, [], 0
    for pid, (cond0, stamina, apps0) in before.items():
        if pid not in now:
            continue
        cond1, apps1 = now[pid]
        rate = max(8.0, 22 - stamina / 12.0) + tempo_mod + press_mod
        if apps1 - apps0 == 2:
            # играл ОБА матча: минуты точны из событий (без события = полный матч)
            m1 = _mins_for(events[cup_id], tid, pid)
            m2 = _mins_for(events[euro_id], tid, pid)
            if m1 + m2 == 0:
                continue
            expected = -rate * (m1 + m2) / 90.0 + 8 + train_cond
            after_exp = cond0 + expected
            if not (35 <= after_exp <= 95):
                continue
            qualified += 1
            if abs((cond1 - cond0) - expected) <= 2:
                within += 1
            else:
                mismatches.append(f'{pid}:delta={cond1 - cond0:.1f},exp={expected:.1f}')
        elif apps1 - apps0 == 0:
            bench_neither += 1
    print(f'qualified={qualified}')
    print(f'within2={within}')
    print(f'bench_neither={bench_neither}')
    print(f'tempo={tempo} pressing={pressing} training={team["trainingFocus"]}/{team["trainingIntensity"]} (+{train_cond})')
    for m in mismatches[:5]:
        print('mismatch=' + m)


def cmd_euroweek(save_id, season, week):
    c = con()
    tid = user_team_id(c, save_id)
    em = rows(c, "SELECT * FROM Match WHERE saveId=? AND season=? AND week=? AND competition='euro'", (save_id, season, week))
    print(f'euro_matches={len(em)}')
    played = sum(1 for m in em if m['status'] == 'played')
    print(f'euro_played={played}')
    winners = sum(1 for m in em if m['winnerTeamId'])
    print(f'euro_winners={winners}')
    pens = sum(1 for m in em if m['homePens'] is not None)
    print(f'euro_pens={pens}')
    same_league = 0
    for m in em:
        lc = [one(c, 'SELECT leagueCode FROM Team WHERE id=?', (x,)) for x in (m['homeTeamId'], m['awayTeamId'])]
        if lc[0] and lc[1] and lc[0] == lc[1]:
            same_league += 1
    print(f'same_league_pairs={same_league}')
    save = rows(c, 'SELECT * FROM GameSave WHERE id=?', (save_id,))[0]
    parts = parse_ids(save['euroParticipants'])
    alive = parse_ids(save['euroAliveTeamIds'])
    print(f'participants={len(parts)}')
    print(f'alive={len(alive)}')
    print(f'euro_season={save["euroSeason"]}')
    print(f'euro_round={save["euroRound"]}')
    own = 0
    if parts:
        qmarks = ','.join('?' * len(parts))
        own = one(c, f'SELECT COUNT(*) FROM Team WHERE id IN ({qmarks}) AND saveId=? AND isEuroGuest=0', (*parts, save_id))
    print(f'own_teams={own}')
    guests = rows(c, 'SELECT id, name, leagueCode FROM Team WHERE saveId=? AND isEuroGuest=1', (save_id,))
    print(f'guests={len(guests)}')
    leagues = sorted({g['leagueCode'] for g in guests})
    print('guest_leagues=' + ','.join(str(x) for x in leagues))
    min_squad = None
    for g in guests:
        n = one(c, 'SELECT COUNT(*) FROM Player WHERE teamId=?', (g['id'],))
        min_squad = n if min_squad is None else min(min_squad, n)
    print(f'guest_min_squad={min_squad}')
    # матч клуба игрока — полный движок
    user_m = [m for m in em if m['homeTeamId'] == tid or m['awayTeamId'] == tid]
    print(f'user_euro_match={len(user_m)}')
    if user_m:
        m = user_m[0]
        print(f'user_stats_nonnull={int(m["stats"] is not None)}')
        evs = json.loads(m['events'] or '[]')
        types = {e['type'] for e in evs}
        print(f'user_events={len(evs)}')
        print(f'user_has_sub={"sub" in types}')
        print(f'user_has_yellow={"yellow" in types}')
        print(f'user_has_halftime={int("halftime" in types)}')
    ai_stats_null = sum(1 for m in em if m['homeTeamId'] != tid and m['awayTeamId'] != tid and m['stats'] is not None)
    print(f'ai_stats_nonnull={ai_stats_null}')
    eg = one(c, 'SELECT COALESCE(SUM(euroGoals),0) FROM Player WHERE saveId=?', (save_id,))
    ea = one(c, 'SELECT COALESCE(SUM(euroAssists),0) FROM Player WHERE saveId=?', (save_id,))
    print(f'euro_goals_sum={eg}')
    print(f'euro_assists_sum={ea}')


def cmd_financeeuro(save_id):
    c = con()
    n = one(c, "SELECT COUNT(*) FROM FinanceRecord WHERE saveId=? AND category='euro_prize'", (save_id,))
    s = one(c, "SELECT COALESCE(SUM(amount),0) FROM FinanceRecord WHERE saveId=? AND category='euro_prize'", (save_id,))
    print(f'euro_prize_records={n}')
    print(f'euro_prize_sum={s}')


def cmd_eventscheck(save_id, *match_ids):
    c = con()
    tid = user_team_id(c, save_id)
    team_lineup = {}
    for r in rows(c, 'SELECT id, lineup, bench FROM Team WHERE saveId=?', (save_id,)):
        team_lineup[r['id']] = (
            set(x for x in json.loads(r['lineup'] or '[]') if x),
            set(x for x in json.loads(r['bench'] or '[]') if x),
        )
    players_by_team = {}
    for r in rows(c, 'SELECT id, teamId FROM Player WHERE saveId=? AND teamId IS NOT NULL', (save_id,)):
        players_by_team.setdefault(r['teamId'], set()).add(r['id'])
    total_ok = 0
    for mid in match_ids:
        m = rows(c, 'SELECT * FROM Match WHERE id=?', (mid,))
        if not m:
            print(f'match={mid} missing=1')
            continue
        m = m[0]
        evs = json.loads(m['events'] or '[]')
        known = {'kickoff', 'goal', 'yellow', 'red', 'injury', 'chance', 'halftime',
                 'fulltime', 'pen_goal', 'pen_miss', 'pen_save', 'sub'}
        types_ok = all(e.get('type') in known for e in evs)
        # kickoff=0 by design; пенальти-серия после 90+; прочие — 1..93
        minutes_ok = all(e['type'] == 'kickoff' or 1 <= e['minute'] <= 93 or (e['type'].startswith('pen_') and e['minute'] >= 95) for e in evs)
        sorted_ok = all(evs[i]['minute'] <= evs[i + 1]['minute'] for i in range(len(evs) - 1))
        subs = {}
        for e in evs:
            if e['type'] == 'sub':
                subs[e.get('teamId')] = subs.get(e.get('teamId'), 0) + 1
        subs_max = max(subs.values()) if subs else 0
        subs_pair_ok = all(e['type'] != 'sub' or (e.get('playerId') and e.get('subOutId') and e.get('playerName') and e.get('subOutName')) for e in evs)
        goals_bad = 0
        user_goals_bad = 0
        for e in evs:
            if e['type'] != 'goal':
                continue
            t = e.get('teamId')
            if not e.get('playerId') or t not in players_by_team or e['playerId'] not in players_by_team[t]:
                goals_bad += 1
            if t == tid and e['playerId'] not in (team_lineup.get(tid, (set(), set()))[0] | team_lineup.get(tid, (set(), set()))[1]):
                user_goals_bad += 1
        print(f'match={mid} type={m["competition"]} events={len(evs)} types_ok={int(types_ok)} '
              f'minutes_ok={int(minutes_ok)} sorted_ok={int(sorted_ok)} subs_max={subs_max} '
              f'subs_pair_ok={int(subs_pair_ok)} goals_bad={goals_bad} user_goals_bad={user_goals_bad}')
        if types_ok and minutes_ok and sorted_ok and subs_max <= 5 and subs_pair_ok and goals_bad == 0 and user_goals_bad == 0:
            total_ok += 1
    print(f'eventscheck_ok={total_ok}/{len(match_ids)}')


def cmd_yellowstats(save_id):
    c = con()
    ms = rows(c, 'SELECT stats FROM Match WHERE saveId=? AND stats IS NOT NULL', (save_id,))
    total, n = 0, 0
    for m in ms:
        st = json.loads(m['stats'])
        total += st.get('yellowsHome', 0) + st.get('yellowsAway', 0)
        n += 1
    print(f'full_engine_matches={n}')
    print(f'yellows_total={total}')
    print(f'yellows_avg={round(total / n, 2) if n else 0}')


def cmd_seasonend(save_id, season):
    c = con()
    tid = user_team_id(c, save_id)
    save = rows(c, 'SELECT * FROM GameSave WHERE id=?', (save_id,))[0]
    finals = rows(c, "SELECT * FROM Match WHERE saveId=? AND season=? AND competition='euro' AND cupRound=4", (save_id, season))
    final_played = bool(finals) and finals[0]['status'] == 'played'
    champion = None
    if final_played:
        champion = one(c, 'SELECT name FROM Team WHERE id=?', (finals[0]['winnerTeamId'],))
    print(f'euro_final_played={int(final_played)}')
    print(f'euro_champion={champion or "none"}')
    print(f'euro_season_next={save["euroSeason"]}')
    print(f'euro_round_next={save["euroRound"]}')
    parts = parse_ids(save['euroParticipants'])
    alive = parse_ids(save['euroAliveTeamIds'])
    print(f'participants_next={len(parts)}')
    print(f'alive_next={len(alive)}')
    own_next = 0
    if parts:
        qmarks = ','.join('?' * len(parts))
        own_next = one(c, f'SELECT COUNT(*) FROM Team WHERE id IN ({qmarks}) AND isEuroGuest=0', parts)
    print(f'own_teams_next={own_next}')
    user_in_next = tid in parts
    print(f'user_qualified_next={int(user_in_next)}')
    guests = rows(c, 'SELECT id FROM Team WHERE saveId=? AND isEuroGuest=1', (save_id,))
    print(f'guests={len(guests)}')
    min_squad = None
    for g in guests:
        n = one(c, 'SELECT COUNT(*) FROM Player WHERE teamId=?', (g['id'],))
        min_squad = n if min_squad is None else min(min_squad, n)
    print(f'guest_min_squad={min_squad}')
    ai_min = one(c, """SELECT MIN(n) FROM (SELECT COUNT(*) n FROM Player p JOIN Team t ON p.teamId=t.id
        WHERE t.saveId=? AND t.isEuroGuest=0 AND t.isUserTeam=0 GROUP BY t.id)""", (save_id,))
    print(f'ai_min_squad={ai_min}')
    free_agents = one(c, 'SELECT COUNT(*) FROM Player WHERE saveId=? AND teamId IS NULL', (save_id,))
    print(f'free_agents={free_agents}')
    recs = rows(c, 'SELECT * FROM PlayerSeasonRecord WHERE saveId=? AND season=?', (save_id, season))
    print(f'records={len(recs)}')
    rec_euro_goals = sum(r['euroGoals'] or 0 for r in recs)
    print(f'records_euro_goals={rec_euro_goals}')
    guest_recs = 0
    gidset = {g['id'] for g in guests}
    for r in recs:
        if r['teamId'] in gidset:
            guest_recs += 1
    print(f'guest_records={guest_recs}')
    # возраст снапшота = возраст ДО старения (инвариант №5 Фазы 3, §9.13)
    cur_age = {r['id']: r['age'] for r in rows(c, 'SELECT id, age FROM Player WHERE saveId=?', (save_id,))}
    age_violations = sum(1 for r in recs if r['playerId'] in cur_age and r['age'] != cur_age[r['playerId']] - 1)
    print(f'age_violations={age_violations}')
    # распределение стилей после перехода (смена p=0.25 — фиксируем)
    ai_teams = rows(c, 'SELECT aiStyle FROM Team WHERE saveId=? AND isEuroGuest=0 AND isUserTeam=0', (save_id,))
    dist = {}
    for t in ai_teams:
        dist[t['aiStyle'] or 'null'] = dist.get(t['aiStyle'] or 'null', 0) + 1
    print('style_dist=' + ' '.join(f'{k}:{v}' for k, v in sorted(dist.items())))


def cmd_isolation(save_id, standings_file, market_file, cup_file, leaders_file):
    c = con()
    guest_ids = {r['id'] for r in rows(c, 'SELECT id FROM Team WHERE saveId=? AND isEuroGuest=1', (save_id,))}
    print(f'guest_ids={len(guest_ids)}')

    def ids_from(path):
        with open(path, encoding='utf-8') as f:
            return {x for x in json.load(f) if x}

    st = ids_from(standings_file)
    print(f'standings_guests={len(st & guest_ids)}')
    mk = ids_from(market_file)
    print(f'market_guests={len(mk & guest_ids)}')
    cp = ids_from(cup_file)
    print(f'cup_guests={len(cp & guest_ids)}')
    ld = ids_from(leaders_file)
    print(f'leaders_guests={len(ld & guest_ids)}')
    bosman = one(c, 'SELECT COUNT(*) FROM Player WHERE saveId=? AND teamId IN ({}) AND preContractTeamId IS NOT NULL'.format(
        ','.join('?' * len(guest_ids)) or 'NULL'), (save_id, *guest_ids)) if guest_ids else 0
    print(f'bosman_guests={bosman}')
    academy = one(c, 'SELECT COUNT(*) FROM Player WHERE saveId=? AND teamId IN ({}) AND isAcademy=1'.format(
        ','.join('?' * len(guest_ids)) or 'NULL'), (save_id, *guest_ids)) if guest_ids else 0
    print(f'academy_guests={academy}')
    bad_contract = one(c, 'SELECT COUNT(*) FROM Player WHERE saveId=? AND teamId IN ({}) AND contractUntil != 99'.format(
        ','.join('?' * len(guest_ids)) or 'NULL'), (save_id, *guest_ids)) if guest_ids else 0
    print(f'guest_bad_contracts={bad_contract}')


def cmd_euroscorers(save_id, awards_file):
    """Гости в topEuroScorers (должны быть при euroGoals>0); в лиговых лидерах — нет."""
    c = con()
    guest_ids = {r['id'] for r in rows(c, 'SELECT id FROM Team WHERE saveId=? AND isEuroGuest=1', (save_id,))}
    with open(awards_file, encoding='utf-8') as f:
        data = json.load(f)
    # тело ответа {ok, live, ...} — берём именно .live (раньше искали в корне → всегда 0)
    live = data.get('live') if isinstance(data, dict) and 'live' in data else data
    euro = [p for p in live.get('topEuroScorers', [])]
    league = ([p for p in live.get('topScorers', [])] + [p for p in live.get('topAssists', [])]
              + [p for p in live.get('topCupScorers', [])])
    print(f'topEuroScorers_len={len(euro)}')
    print(f'topEuroScorers_guests={sum(1 for p in euro if p.get("teamId") in guest_ids)}')
    print(f'league_leaders_guests={sum(1 for p in league if p.get("teamId") in guest_ids)}')


def cmd_cascade(save_id):
    c = con()
    for t in ('Team', 'Player', 'Match', 'PlayerSeasonRecord', 'FinanceRecord', 'NewsItem', 'TransferListing', 'SeasonAward'):
        n = one(c, f'SELECT COUNT(*) FROM {t} WHERE saveId=?', (save_id,))
        print(f'{t}={n}')


def main():
    if len(sys.argv) < 3:
        print('usage: qa4_db.py <cmd> <saveId> [args...]', file=sys.stderr)
        sys.exit(2)
    cmd, save_id = sys.argv[1], sys.argv[2]
    rest = sys.argv[3:]
    fn = {
        'styles': cmd_styles,
        'snapcond': cmd_snapcond,
        'congestion': cmd_congestion,
        'euroweek': cmd_euroweek,
        'financeeuro': cmd_financeeuro,
        'eventscheck': cmd_eventscheck,
        'yellowstats': cmd_yellowstats,
        'seasonend': cmd_seasonend,
        'isolation': cmd_isolation,
        'euroscorers': cmd_euroscorers,
        'cascade': cmd_cascade,
    }.get(cmd)
    if not fn:
        print(f'unknown cmd {cmd}', file=sys.stderr)
        sys.exit(2)
    fn(save_id, *rest)


if __name__ == '__main__':
    main()

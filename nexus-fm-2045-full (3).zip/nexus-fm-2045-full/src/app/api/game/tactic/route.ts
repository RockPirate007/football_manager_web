import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolvePlayingSave } from '@/lib/game/api-helpers';
import {
  coerceDefLine, coerceFormation, coerceMentality, coercePlayStyle, coercePressing, coerceTempo,
} from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { autoLineup, isLineupValid, type PlayerLike } from '@/lib/game/players';
import { computeLines } from '@/lib/game/strength';
import { parseLineup } from '@/lib/game/types';
import type { FormationId, Mentality, PlayStyle } from '@/lib/game/types';

const bodySchema = z.object({
  saveId: z.string().min(1).optional(),
  formation: z.enum(['4-4-2', '4-3-3', '4-2-3-1', '4-5-1', '3-5-2', '5-3-2', '4-1-4-1', '3-4-3']).optional(),
  mentality: z.enum(['defensive', 'cautious', 'balanced', 'attacking', 'allout']).optional(),
  tempo: z.enum(['low', 'medium', 'high']).optional(),
  pressing: z.enum(['low', 'medium', 'high']).optional(),
  defLine: z.enum(['low', 'medium', 'high']).optional(),
  playStyle: z.enum(['balanced', 'wing', 'passing', 'long', 'counter']).optional(),
  lineup: z.array(z.string()).length(11).optional(),
  bench: z.array(z.string()).max(7).optional(),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/tactic — сохранение состава и тактики клуба игрока.
 * Body: { saveId, formation?, mentality?, tempo?, pressing?, defLine?,
 * playStyle?, lineup?, bench? } — отсутствующие поля берутся из текущих
 * настроек команды (частичное обновление). Без saveId (легаси-клиент
 * Фазы 1) — последний открытый активный сейв.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('INVALID_LINEUP', 400);

    const save = await resolvePlayingSave(parsed.data.saveId ?? null);
    const team = await db.team.findUnique({ where: { id: save.teamId } });
    if (!team) return fail('SAVE_NOT_FOUND', 404);

    const squad = (await db.player.findMany({
      where: { saveId: save.id, teamId: team.id },
    })) as unknown as PlayerLike[];

    const formation: FormationId = parsed.data.formation ?? coerceFormation(team.formation);
    const mentality: Mentality = parsed.data.mentality ?? coerceMentality(team.mentality);
    const tempo = parsed.data.tempo ?? coerceTempo(team.tempo);
    const pressing = parsed.data.pressing ?? coercePressing(team.pressing);
    const defLine = parsed.data.defLine ?? coerceDefLine(team.defLine);
    const playStyle: PlayStyle = parsed.data.playStyle ?? coercePlayStyle(team.playStyle);

    let lineup: string[] | null = parsed.data.lineup ?? null;
    let bench: string[] = parsed.data.bench ?? [];

    if (lineup) {
      // Валидация стартового состава
      if (!isLineupValid(lineup, squad)) return fail('INVALID_LINEUP', 400);
      // Валидация скамейки: свои игроки, без пересечения со стартом
      const squadIds = new Set(squad.map((p) => p.id));
      const lineupSet = new Set(lineup);
      if (!bench.every((id) => squadIds.has(id)) || bench.some((id) => lineupSet.has(id))) {
        return fail('INVALID_LINEUP', 400);
      }
    } else {
      // Состав не передан — сохраняем прежний, если он валиден
      const saved = parseLineup(team.lineup);
      lineup = saved && isLineupValid(saved, squad) ? saved : null;
      bench = parseLineup(team.bench) ?? [];
    }

    await db.team.update({
      where: { id: team.id },
      data: {
        formation,
        mentality,
        tempo,
        pressing,
        defLine,
        playStyle,
        ...(lineup ? { lineup: JSON.stringify(lineup) } : {}),
        ...(parsed.data.bench !== undefined ? { bench: JSON.stringify(bench) } : {}),
      },
    });

    const effectiveLineup = lineup ?? autoLineup(squad, formation).lineup;
    const lines = computeLines({
      teamId: team.id,
      players: squad,
      formation,
      mentality,
      tempo,
      pressing,
      defLine,
      playStyle,
      lineup: effectiveLineup,
    });

    return NextResponse.json({ ok: true, teamStrength: lines.overall });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/tactic]', error);
    return fail('UNKNOWN', 500);
  }
}

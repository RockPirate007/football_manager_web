import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';

const bodySchema = z.object({
  careerName: z.string().trim(),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/** PATCH /api/game/saves/[id] — переименовать карьеру (1–60 символов). §6.2. */
export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;

    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('INVALID_CAREER_NAME', 400);
    const careerName = parsed.data.careerName;
    if (careerName.length < 1 || careerName.length > 60) {
      return fail('INVALID_CAREER_NAME', 400);
    }

    const save = await db.gameSave.findUnique({ where: { id } });
    if (!save) return fail('SAVE_NOT_FOUND', 404);

    await db.gameSave.update({ where: { id }, data: { careerName } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/saves PATCH]', error);
    return fail('UNKNOWN', 500);
  }
}

/** DELETE /api/game/saves/[id] — удалить карьеру каскадом (все таблицы по saveId). §6.2. */
export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;

    const save = await db.gameSave.findUnique({ where: { id } });
    if (!save) return fail('SAVE_NOT_FOUND', 404);

    // Явный порядок дочерних таблиц: Match ссылается на Team, поэтому матчи
    // удаляются раньше команд; GameSave последним.
    await db.$transaction([
      db.match.deleteMany({ where: { saveId: id } }),
      db.seasonAward.deleteMany({ where: { saveId: id } }),
      db.transferListing.deleteMany({ where: { saveId: id } }),
      db.newsItem.deleteMany({ where: { saveId: id } }),
      db.financeRecord.deleteMany({ where: { saveId: id } }),
      db.player.deleteMany({ where: { saveId: id } }),
      db.team.deleteMany({ where: { saveId: id } }),
      db.gameSave.delete({ where: { id } }),
    ]);
    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/saves DELETE]', error);
    return fail('UNKNOWN', 500);
  }
}

/**
 * D-5 «Территория» — инфраструктура клуба (спека §3): каталог 8 зданий × 5
 * уровней (цены/дни/содержание — канонические числа §3.1), эффекты по уровням
 * (§3.2), стартовые уровни по stature клуба, состояние BuildingsState на Team
 * (JSON, паттерн lineup/matchPlan — §3.4) и правила строительства (§3.3).
 *
 * Эффекты применяются ТОЛЬКО к клубу игрока; ИИ-клубы получают статичные
 * стартовые уровни по своей силе (v1, фиксация объёма §3). Престиж-бонус
 * VIP-лож (+2·L при достройке) относится к ManagerState D-6 — будет подключён
 * этапом D-6 (§4), здесь не начисляется.
 *
 * Пресет чисел: «Баланс» (research §6а). Все деньги — Int €.
 *
 * Модуль 5 (§ «Инфраструктура»): 9-е здание «Скаут-центр» — синергия с
 * Модулем 3 (туман войны): множитель скорости роста знания скаутинга
 * (1 + 0.06·L). Добавлено В КОНЕЦ каталога — порядок первых 8 сохранён
 * (легаси-JSON BuildingsState без ключа → parseBuildings даёт L0).
 */

// ── Типы состояния (§3.4) ──────────────────────────────────────────────────

export type BuildingId =
  | 'training' | 'medical' | 'fitness' | 'academy'
  | 'hotel' | 'parking' | 'fanshop' | 'vip'
  | 'scoutcenter'; // Модуль 5: синергия с туманом войны (М3)

/** Состояние одного здания: уровень 0..5 + таймер стройки (null = стройки нет). */
export interface BuildingState {
  level: number;
  upgradeEndsAtDay: number | null;
}

/** Состояние всех 8 зданий (хранится на Team как JSON-строка). */
export type BuildingsState = Record<BuildingId, BuildingState>;

// ── Каталог (§3.1 — канонические числа) ────────────────────────────────────

export interface BuildingSpec {
  readonly id: BuildingId;
  /** Русское название (UI/новости/FinanceRecord). */
  readonly name: string;
  /** lucide-иконка плитки (§3.6): имя компонента — маппинг в TerritoryScreen. */
  readonly icon: 'Dumbbell' | 'Stethoscope' | 'Activity' | 'GraduationCap'
    | 'Hotel' | 'Car' | 'Store' | 'Crown' | 'Radar';
  /** Цена постройки уровня 1..5 (€). */
  readonly prices: readonly [number, number, number, number, number];
  /** Дни постройки уровня 1..5. */
  readonly days: readonly [number, number, number, number, number];
}

/** Максимальный уровень здания (§3.3: L0→L1…L4→L5). */
export const BUILDING_MAX_LEVEL = 5;

/** Еженедельное содержание = 0.25 % × price(L) по каждому зданию (§3.2). */
export const BUILDING_UPKEEP_RATIO = 0.0025;

export const BUILDINGS: readonly BuildingSpec[] = [
  {
    id: 'training',
    name: 'Тренировочный комплекс',
    icon: 'Dumbbell',
    prices: [2_000_000, 3_500_000, 6_100_000, 10_600_000, 18_500_000],
    days: [14, 21, 28, 35, 42],
  },
  {
    id: 'medical',
    name: 'Медицинский центр',
    icon: 'Stethoscope',
    prices: [3_000_000, 5_000_000, 8_500_000, 14_300_000, 24_000_000],
    days: [21, 28, 35, 42, 49],
  },
  {
    id: 'fitness',
    name: 'Фитнес-центр',
    icon: 'Activity',
    prices: [1_500_000, 2_600_000, 4_600_000, 8_000_000, 14_000_000],
    days: [14, 21, 28, 35, 42],
  },
  {
    id: 'academy',
    name: 'Корпус академии',
    icon: 'GraduationCap',
    prices: [2_500_000, 4_400_000, 7_700_000, 13_400_000, 23_500_000],
    days: [21, 28, 35, 42, 49],
  },
  {
    id: 'hotel',
    name: 'Отель для команды',
    icon: 'Hotel',
    prices: [2_000_000, 3_500_000, 6_100_000, 10_600_000, 18_500_000],
    days: [14, 21, 28, 35, 42],
  },
  {
    id: 'parking',
    name: 'Парковка стадиона',
    icon: 'Car',
    prices: [800_000, 1_400_000, 2_500_000, 4_300_000, 7_500_000],
    days: [10, 15, 20, 25, 30],
  },
  {
    id: 'fanshop',
    name: 'Фан-шоп',
    icon: 'Store',
    prices: [1_000_000, 1_800_000, 3_100_000, 5_400_000, 9_500_000],
    days: [10, 15, 20, 25, 30],
  },
  {
    id: 'vip',
    name: 'VIP-ложи',
    icon: 'Crown',
    prices: [3_000_000, 5_200_000, 9_100_000, 15_900_000, 27_800_000],
    days: [21, 28, 35, 42, 49],
  },
  {
    id: 'scoutcenter',
    name: 'Скаут-центр',
    icon: 'Radar',
    prices: [1_800_000, 3_100_000, 5_400_000, 9_500_000, 16_600_000],
    days: [14, 21, 28, 35, 42],
  },
];

const SPEC_BY_ID: ReadonlyMap<BuildingId, BuildingSpec> = new Map(
  BUILDINGS.map((b) => [b.id, b]),
);

export const BUILDING_IDS: readonly BuildingId[] = BUILDINGS.map((b) => b.id);

/** Спецификация здания по id (null — неизвестный id → BUILDING_NOT_FOUND). */
export function buildingById(id: string): BuildingSpec | null {
  return SPEC_BY_ID.get(id as BuildingId) ?? null;
}

/** Цена постройки уровня level (1..5). */
export function priceOf(id: BuildingId, level: number): number {
  const spec = SPEC_BY_ID.get(id);
  if (!spec || level < 1 || level > BUILDING_MAX_LEVEL) return 0;
  return spec.prices[level - 1];
}

/** Дни постройки уровня level (1..5). */
export function daysOf(id: BuildingId, level: number): number {
  const spec = SPEC_BY_ID.get(id);
  if (!spec || level < 1 || level > BUILDING_MAX_LEVEL) return 0;
  return spec.days[level - 1];
}

// ── Стартовые уровни по stature (§3.2) ─────────────────────────────────────

/** Пороги stature: ≥ 84 топ · 74–83 середняк · < 74 аутсайдер. */
export const BUILDING_TIER_STR = { top: 84, mid: 74 } as const;

/** Стартовые уровни 9 зданий по stature клуба (фиксируются при создании). */
export function startLevelsByStrength(strength: number): BuildingsState {
  const top = strength >= BUILDING_TIER_STR.top;
  const mid = !top && strength >= BUILDING_TIER_STR.mid;
  return {
    training: { level: top ? 2 : 1, upgradeEndsAtDay: null },
    medical: { level: top ? 2 : 1, upgradeEndsAtDay: null },
    fitness: { level: top ? 2 : mid ? 1 : 0, upgradeEndsAtDay: null },
    academy: { level: top ? 2 : mid ? 1 : 0, upgradeEndsAtDay: null },
    hotel: { level: top ? 1 : 0, upgradeEndsAtDay: null },
    parking: { level: top ? 2 : mid ? 1 : 0, upgradeEndsAtDay: null },
    fanshop: { level: top ? 2 : mid ? 1 : 0, upgradeEndsAtDay: null },
    vip: { level: top ? 2 : mid ? 1 : 0, upgradeEndsAtDay: null },
    scoutcenter: { level: top ? 2 : mid ? 1 : 0, upgradeEndsAtDay: null },
  };
}

// ── Сериализация (§3.4: парсер по паттерну parseMatchPlan) ─────────────────

function emptyState(): BuildingsState {
  const out = {} as BuildingsState;
  for (const id of BUILDING_IDS) out[id] = { level: 0, upgradeEndsAtDay: null };
  return out;
}

/**
 * Парсер состояния зданий: толерантен к null/битому JSON/лишним ключам —
 * все уровни 0 (паттерн parseMatchPlan). Уровень клампится 0..5.
 */
export function parseBuildings(raw: string | null | undefined): BuildingsState {
  if (raw === null || raw === undefined) return emptyState();
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return emptyState();
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return emptyState();
  }
  const out = emptyState();
  const rec = parsed as Record<string, unknown>;
  for (const id of BUILDING_IDS) {
    const src = rec[id];
    if (src === null || typeof src !== 'object') continue;
    const level = (src as Record<string, unknown>).level;
    const ends = (src as Record<string, unknown>).upgradeEndsAtDay;
    if (typeof level === 'number' && Number.isFinite(level)) {
      out[id].level = Math.min(BUILDING_MAX_LEVEL, Math.max(0, Math.trunc(level)));
    }
    if (typeof ends === 'number' && Number.isFinite(ends)) {
      out[id].upgradeEndsAtDay = Math.trunc(ends);
    }
  }
  return out;
}

/** Канонический JSON состояния (все 8 ключей, фикс. порядок каталога). */
export function serializeBuildings(state: BuildingsState): string {
  const out: Record<string, { level: number; upgradeEndsAtDay: number | null }> = {};
  for (const id of BUILDING_IDS) out[id] = { ...state[id] };
  return JSON.stringify(out);
}

// ── Эффекты по уровням (§3.2) ──────────────────────────────────────────────

/** training: множитель тренировочного XP (TRAIN_XP_MULT = 1 + 0.04·L). */
export function trainXpMult(level: number): number {
  return 1 + 0.04 * level;
}

/** medical: множитель риска травм — матч и тренировки (1 − 0.04·L). */
export function injuryRiskMult(level: number): number {
  return 1 - 0.04 * level;
}

/** medical: множитель длительности травм (1 − 0.10·L). */
export function injuryDurMult(level: number): number {
  return 1 - 0.1 * level;
}

/** fitness: доп. недельное восстановление сверх +8 (0.4·L). */
export function recoveryBonus(level: number): number {
  return 0.4 * level;
}

/** hotel: доп. восстановление в congestion-неделю (0.6·L). */
export function hotelCongestionBonus(level: number): number {
  return 0.6 * level;
}

/** hotel: доп. восстановление в неделю с евроматчем (0.3·L). */
export function hotelEuroBonus(level: number): number {
  return 0.3 * level;
}

/** academy: доп. игроки в наборе — SIZE_BONUS [0,0,0,1,1,2] по уровню 0..5. */
const ACADEMY_SIZE_BONUS: readonly number[] = [0, 0, 0, 1, 1, 2];
export function academySizeBonus(level: number): number {
  return ACADEMY_SIZE_BONUS[Math.min(BUILDING_MAX_LEVEL, Math.max(0, level))];
}

/** academy: бонус POT выпускника (0.8·L; кап POT 93 — в academy.ts). */
export function academyPotBonus(level: number): number {
  return 0.8 * level;
}

/** academy: множитель шанса «жемчужины» (1 + 0.15·L). */
export function academyGemMult(level: number): number {
  return 1 + 0.15 * level;
}

/** parking: множитель билетной выручки домашнего матча (1 + 0.015·L). */
export function ticketMult(level: number): number {
  return 1 + 0.015 * level;
}

/** fanshop: еженедельный доход мерчандайза (30 000·L €/нед). */
export function merchWeekly(level: number): number {
  return 30_000 * level;
}

/** vip: доплата за домашний матч (160 000·L €). */
export function vipPerMatch(level: number): number {
  return 160_000 * level;
}

/** Модуль 5 · scoutcenter: множитель скорости роста знания скаутинга (1 + 0.06·L). */
export function scoutSpeedMult(level: number): number {
  return 1 + 0.06 * level;
}

/** Модуль 5 · scoutcenter: доп. слоты наблюдения (0·L2 + [0,0,0,1,1,2] по уровню 0..5). */
const SCOUTCENTER_SLOT_BONUS: readonly number[] = [0, 0, 0, 1, 1, 2];
export function scoutSlotsBonus(level: number): number {
  return SCOUTCENTER_SLOT_BONUS[Math.min(BUILDING_MAX_LEVEL, Math.max(0, level))];
}

// ── Содержание и деньги (§3.2) ─────────────────────────────────────────────

/** Еженедельное содержание одного здания (0.25 % × price(L); L=0 → 0). */
export function upkeepWeeklyOfBuilding(id: BuildingId, level: number): number {
  if (level <= 0) return 0;
  return Math.round(priceOf(id, level) * BUILDING_UPKEEP_RATIO);
}

/** Суммарное еженедельное содержание всех зданий (одна запись «building»). */
export function upkeepWeeklyTotal(state: BuildingsState): number {
  let sum = 0;
  for (const id of BUILDING_IDS) sum += upkeepWeeklyOfBuilding(id, state[id].level);
  return sum;
}

// ── Время (§3.3) ───────────────────────────────────────────────────────────

/**
 * Абсолютный день карьеры: (season − 1) × totalWeeks × 7 + (week − 1) × 7
 * (totalWeeks — константа лиги 34/39/43). Прогон недели = +7 дней.
 */
export function absoluteDayOf(season: number, week: number, totalWeeks: number): number {
  return (season - 1) * totalWeeks * 7 + (week - 1) * 7;
}

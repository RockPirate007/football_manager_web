/**
 * Финансы клуба игрока: недельная ведомость, билеты, спонсор.
 * Раздел 4.13 docs/architecture.md + масштабирование под размер лиги N (§3.5 Фазы 2).
 */

import {
  SPONSOR_BASE, SPONSOR_PER_PLACE, TICKET_PRICE, TV_MONEY_BY_LEAGUE,
  TV_PLACE_MULT, WAGE_ALERT_RATIO,
} from './constants';
import type { PlayerLike } from './players';
import type { FinanceCategory, FinanceKind, LeagueCode } from './types';

export interface FinanceRecordGen {
  kind: FinanceKind;
  category: FinanceCategory;
  amount: number; // всегда положительное
  description: string;
}

export interface WeekFinanceResult {
  wages: number;
  sponsor: number;
  tickets: number;
  /** Модуль 5: ТВ-отчисления лиги (каждую неделю). */
  tv: number;
  cupPrize: number;
  net: number;
  records: FinanceRecordGen[];
}

/**
 * Посещаемость по месту в таблице (квартили от N): q1=ceil(N/4) → 0.92,
 * q2=ceil(N/2) → 0.80, q3=ceil(3N/4) → 0.68, иначе 0.55 (±5%).
 * Для N=16 в точности даёт прежние границы 4/8/12.
 */
export function attendanceRate(place: number, teamCount: number, rng: () => number): number {
  const q1 = Math.ceil(teamCount / 4);
  const q2 = Math.ceil(teamCount / 2);
  const q3 = Math.ceil((teamCount * 3) / 4);
  const base = place <= q1 ? 0.92 : place <= q2 ? 0.8 : place <= q3 ? 0.68 : 0.55;
  const noise = 1 + (rng() * 2 - 1) * 0.05;
  return base * noise;
}

/** Спонсор = SPONSOR_BASE + (N − place) × SPONSOR_PER_PLACE. */
export function sponsorIncome(place: number, teamCount: number): number {
  return SPONSOR_BASE + Math.max(0, teamCount - place) * SPONSOR_PER_PLACE;
}

/**
 * Модуль 5: ТВ-отчисления недели — база лиги (TV_MONEY_BY_LEAGUE) × класс
 * места: топ-кварталь ×1.3 · середина ×1.0 · низ ×0.85. Детерминированная
 * формула (без rng): стабильный доход, вокруг которого строится бюджет.
 */
export function tvIncomeOf(place: number, teamCount: number, league: LeagueCode): number {
  const base = TV_MONEY_BY_LEAGUE[league] ?? TV_MONEY_BY_LEAGUE.RPL;
  const q1 = Math.ceil(teamCount / 4);
  const q3 = Math.ceil((teamCount * 3) / 4);
  const mult = place <= q1 ? TV_PLACE_MULT.top : place <= q3 ? TV_PLACE_MULT.mid : TV_PLACE_MULT.low;
  return Math.round(base * mult);
}

export function weeklyWages(players: PlayerLike[]): number {
  return players.reduce((s, p) => s + p.salary, 0);
}

/** Недельный доход для снапшота: спонсор + средние билеты (половина туров — дома). */
export function weeklyIncomeEstimate(place: number, stadiumCapacity: number, teamCount: number): number {
  const q1 = Math.ceil(teamCount / 4);
  const q2 = Math.ceil(teamCount / 2);
  const q3 = Math.ceil((teamCount * 3) / 4);
  const attendance = place <= q1 ? 0.92 : place <= q2 ? 0.8 : place <= q3 ? 0.68 : 0.55;
  const avgTickets = (stadiumCapacity * attendance * TICKET_PRICE) / 2;
  return Math.round(sponsorIncome(place, teamCount) + avgTickets);
}

export function wageRatio(wages: number, income: number): number {
  if (income <= 0) return wages > 0 ? 1 : 0;
  return wages / income;
}

export function isWageAlert(wages: number, income: number): boolean {
  return wageRatio(wages, income) > WAGE_ALERT_RATIO;
}

/**
 * Финансы недели клуба игрока: зарплаты, спонсор, билеты (если домашний матч —
 * лиговый ИЛИ кубковый), ТВ-отчисления (Модуль 5 — каждую неделю, категория
 * 'tv'). place — текущее место в ЛИГОВОЙ таблице.
 *
 * D-5 «Территория» (§3.5): опц. ticketMult (парковка: 1 + 0.015·L) умножает
 * билетную выручку домашнего матча; опц. vipPerMatch (VIP-ложи: 160 000·L)
 * добавляет запись дохода категории 'vip' за домашный матч и входит в net.
 * Модуль 5: опц. tvBase — включённые в неделю ТВ-деньги (tvIncomeOf уже
 * посчитан в engine; здесь только запись/net). Без полей — как раньше
 * (обратная совместимость, tv = 0).
 */
export function computeWeekFinance(opts: {
  players: PlayerLike[];
  place: number;
  teamCount: number;
  isHomeMatch: boolean;
  stadiumCapacity: number;
  rng: () => number;
  ticketMult?: number;
  vipPerMatch?: number;
  tvBase?: number;
}): WeekFinanceResult {
  const { players, place, teamCount, isHomeMatch, stadiumCapacity, rng } = opts;
  const ticketMult = opts.ticketMult ?? 1;
  const vipPerMatch = opts.vipPerMatch ?? 0;
  const tv = opts.tvBase ?? 0;
  const records: FinanceRecordGen[] = [];

  const wages = weeklyWages(players);
  const sponsor = sponsorIncome(place, teamCount);
  let tickets = 0;

  if (isHomeMatch) {
    tickets = Math.round(
      stadiumCapacity * attendanceRate(place, teamCount, rng) * TICKET_PRICE * ticketMult,
    );
  }

  records.push({
    kind: 'expense',
    category: 'wages',
    amount: wages,
    description: `Зарплаты игроков за неделю (место в таблице: ${place})`,
  });
  records.push({
    kind: 'income',
    category: 'sponsor',
    amount: sponsor,
    description: `Спонсорские отчисления (место ${place})`,
  });
  // Модуль 5: ТВ-отчисления — стабильная статья, грант бюджета строится от неё
  if (tv > 0) {
    records.push({
      kind: 'income',
      category: 'tv',
      amount: tv,
      description: 'Телевещание: отчисления лиги',
    });
  }
  if (tickets > 0) {
    records.push({
      kind: 'income',
      category: 'tickets',
      amount: tickets,
      description: `Продажа билетов (${stadiumCapacity.toLocaleString('ru-RU')} мест)`,
    });
  }
  // D-5: VIP-ложи — доплата за домашний матч (категория 'vip', §3.5)
  if (isHomeMatch && vipPerMatch > 0) {
    records.push({
      kind: 'income',
      category: 'vip',
      amount: vipPerMatch,
      description: 'Доход VIP-лож за домашний матч',
    });
  }

  const net = sponsor + tv + tickets + vipPerMatch - wages;
  return { wages, sponsor, tickets, tv, cupPrize: 0, net, records };
}

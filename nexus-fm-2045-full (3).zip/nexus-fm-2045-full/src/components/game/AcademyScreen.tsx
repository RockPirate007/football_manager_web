'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Gem, GraduationCap, Loader2, Sparkles, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { PlayerDialog } from '@/components/game/PlayerDialog';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { PositionBadge } from '@/components/game/shared/PositionBadge';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { talentLabelOf } from '@/lib/game/development';
import { formatMoney } from '@/lib/game/format';
import type { AcademyPlayerDTO, PlayerDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Потенциал ≥ 85 — «жемчужина» набора (ACADEMY_GEM_POT / 5 звёзд). */
function isGem(g: AcademyPlayerDTO): boolean {
  return g.stars >= 5;
}

/** Звёзды потенциала: ★×N золотом, пустые — приглушённые. */
function Stars({ stars }: { stars: number }) {
  return (
    <span
      className="tabular tracking-wide text-[#EAB308]"
      aria-label={`Потенциал: ${stars} из 5`}
      title={`Потенциал: ${stars}/5`}
    >
      {Array.from({ length: 5 }, (_, i) => (
        <span key={i} className={cn(i < stars ? 'text-[#EAB308]' : 'text-muted-foreground/30')}>
          ★
        </span>
      ))}
    </span>
  );
}

/** Карточка воспитанника академии. */
function GraduateCard({
  graduate,
  index,
  onOpen,
}: {
  graduate: AcademyPlayerDTO;
  index: number;
  onOpen: () => void;
}) {
  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, delay: Math.min(index * 0.04, 0.25) }}
      onClick={onOpen}
      className="flex w-full flex-col gap-2.5 rounded-lg border border-border/70 bg-card p-4 text-left transition-colors hover:border-primary/40 hover:bg-primary/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40"
      aria-label={`${graduate.name}, ${graduate.position}, ${graduate.age} лет, OVR ${graduate.ovr}`}
    >
      <div className="flex items-start gap-3">
        <OvrBadge ovr={graduate.ovr} size="md" />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-sm font-semibold">{graduate.name}</span>
            {isGem(graduate) ? (
              <Badge className="shrink-0 border border-[#EAB308]/40 bg-[#EAB308]/10 text-[10px] text-[#EAB308]">
                <Gem className="size-3" aria-hidden />
                Жемчужина
              </Badge>
            ) : null}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
            <PositionBadge position={graduate.position} />
            <span className="tabular">{graduate.age} лет</span>
            <span className="text-border" aria-hidden>·</span>
            <span>
              Контракт до <span className="tabular font-semibold text-foreground">{graduate.contractUntil}</span>
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 border-t border-border/50 pt-2.5">
        <div className="flex items-center gap-1.5">
          <Sparkles className="size-3.5 text-[#EAB308]" aria-hidden />
          <Stars stars={graduate.stars} />
          <span className="text-[10px] text-muted-foreground">
            {talentLabelOf(graduate.stars)}
          </span>
        </div>
        <div className="text-right">
          <div className="text-[10px] text-muted-foreground">Стоимость</div>
          <div className="tabular text-xs font-bold text-[#EAB308]">
            {formatMoney(graduate.value)}
          </div>
        </div>
      </div>
    </motion.button>
  );
}

/** Экран «Академия»: выпускники клуба (isAcademy) текущего набора (§7.4). */
export function AcademyScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const academyCache = useGameStore((s) => s.academyCache);
  const academyLoading = useGameStore((s) => s.academyLoading);
  const fetchAcademy = useGameStore((s) => s.fetchAcademy);

  const [selected, setSelected] = useState<PlayerDTO | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    void fetchAcademy();
  }, [fetchAcademy]);

  const graduates = academyCache?.graduates ?? [];
  const myPlayers = snapshot.myPlayers;

  const openGraduate = (id: string) => {
    // Воспитанники — игроки клуба: полный PlayerDTO берём из снапшота.
    const player = myPlayers.find((p) => p.id === id) ?? null;
    if (!player) return;
    setSelected(player);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Академия"
        subtitle="Набор воспитанников — 4-я неделя каждого сезона"
        action={
          <Badge variant="outline" className="hidden text-[11px] sm:inline-flex">
            <GraduationCap className="size-3.5" aria-hidden />
            {graduates.length > 0 ? `${graduates.length} воспитанников` : 'набор в неделю 4'}
          </Badge>
        }
      />

      {academyLoading && !academyCache ? (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-lg" />
          ))}
        </div>
      ) : graduates.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-lg border border-border/70 bg-card px-4 py-12 text-center">
          <div className="flex size-14 items-center justify-center rounded-full bg-secondary/60">
            <GraduationCap className="size-7 text-muted-foreground" aria-hidden />
          </div>
          <p className="text-sm font-semibold">Воспитанников пока нет</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            Воспитанники появятся после первого набора — 4-я неделя сезона.
            Скауты академии готовят новых игроков к подписанию контракта.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {graduates.map((g, i) => (
            <GraduateCard
              key={g.id}
              graduate={g}
              index={i}
              onOpen={() => openGraduate(g.id)}
            />
          ))}
        </div>
      )}

      {academyLoading && academyCache ? (
        <p className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="size-3.5 animate-spin" aria-hidden />
          Обновляем список воспитанников…
        </p>
      ) : null}

      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Star className="size-3.5 text-[#EAB308]" aria-hidden />
        Звёзды — потолок развития: чем больше, тем выше потенциал воспитанника.
        Тап по карточке открывает полный профиль игрока.
      </p>

      <PlayerDialog
        key={`ac:${selected?.id ?? 'none'}:${dialogOpen}`}
        player={selected}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode="squad"
      />
    </div>
  );
}

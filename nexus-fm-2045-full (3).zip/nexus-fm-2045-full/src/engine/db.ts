/**
 * SaveStore — prisma-подобный адаптер поверх in-memory коллекций (спека §1.2).
 * Поддерживает ровно инвентарь паттернов «грязных» файлов (week.ts / роуты):
 * findMany / findUnique / findFirst / create / createMany / update / updateMany /
 * delete / deleteMany / count / $transaction; where — AND-конъюнкция равенств
 * (вкл. null), { not }, { in }; orderBy — массив ключей; take/skip; select —
 * подмножество скаляров; include — только { player } (TransferListing) и
 * { team } (GameSave). Unique-нарушения эмулируются EngineUniqueError
 * (P2002-совместимо): Match-композит, TransferListing.playerId, GameSave.teamId.
 *
 * Семантика PrismaPromise (D-3c): операции ЛЕНИВЫЕ — вызов строит операцию со
 * снимком аргументов, применение при первом await ИЛИ в $transaction
 * ПОСЛЕДОВАТЕЛЬНО в порядке массива; $transaction([ops]) сама ленива.
 * Числовая коэрция записи — как Prisma+SQLite: Int-поля усекают дробные
 * (Math.trunc), Float — 16 значащих цифр. Изоморфно: никаких Node API.
 */

import {
  DUMP_KEY_BY_MODEL, MODEL_SPECS, type ModelSpec,
  type FinanceRecordRecord, type GameSaveRecord, type MatchRecord, type ModelName,
  type StaffRecord,
  type NewsItemRecord, type NewspaperClippingRecord, type PlayerRecord, type PlayerTrainingRecord,
  type PlayerSeasonRecordRecord, type ScoutReportRecord, type SeasonAwardRecord,
  type TeamRecord, type TransferListingRecord, type TransferOfferRecord,
} from './models';

// ── Публичные типы адаптера (спека §1.2, сигнатуры 1:1) ────────────────────

export type SortDir = 'asc' | 'desc';
export type WhereVal = number | string | boolean | null;

/** Вложенный фильтр по отношению (D-3b: snapshot.ts `team: { isEuroGuest: false }`). */
export interface RelationWhere {
  [field: string]: WhereField;
}

export type WhereField = WhereVal | { not: WhereVal } | { in: WhereVal[] } | RelationWhere;
export interface Where { [field: string]: WhereField }

export interface QueryArgs {
  where?: Where;
  orderBy?: Record<string, SortDir>[];
  take?: number;
  skip?: number;
  /** Только скалярные поля → частичный объект (include при select игнорируется). */
  select?: Record<string, true>;
  include?: { player?: true } | { team?: true };
}

/** Отложенный вызов БД (аналог PrismaPromise; применяется немедленно, §1.2). */
export type EngineOp = Promise<unknown>;

export interface Table<T> {
  findMany(args?: QueryArgs): Promise<T[]>;
  findUnique(args: { where: Record<string, string> } & QueryArgs): Promise<T | null>;
  findFirst(args?: QueryArgs): Promise<T | null>;
  create(args: { data: Partial<T> }): Promise<T>;
  createMany(args: { data: Partial<T>[] }): Promise<{ count: number }>;
  update(args: { where: Record<string, string>; data: Partial<T> }): Promise<T>;
  updateMany(args: { where: Where; data: Partial<T> }): Promise<{ count: number }>;
  delete(args: { where: Record<string, string> }): Promise<T>;
  deleteMany(args: { where: Where }): Promise<{ count: number }>;
  count(args?: { where: Where }): Promise<number>;
}

/** Отношения, используемые портируемым кодом (§1.2: ровно два). */
export type GameSaveWithTeam = GameSaveRecord & { team: TeamRecord | null };
/** Player — обязательная связь (как в типах Prisma): playerId NOT NULL. */
export type TransferListingWithPlayer = TransferListingRecord & { player: PlayerRecord };
/** ScoutReport/TransferOffer — Модуль 3: include { player } (аналог Listing). */
export type ScoutReportWithPlayer = ScoutReportRecord & { player: PlayerRecord };
export type TransferOfferWithPlayer = TransferOfferRecord & { player: PlayerRecord };

/** GameSave-таблица с типизированным include { team } (перегрузки — include-вариант первым). */
export interface GameSaveTable extends Omit<Table<GameSaveRecord>, 'findUnique' | 'findFirst' | 'findMany'> {
  findUnique(args: { where: Record<string, string>; include: { team: true } }): Promise<GameSaveWithTeam | null>;
  findUnique(args: { where: Record<string, string> } & QueryArgs): Promise<GameSaveRecord | null>;
  findFirst(args: QueryArgs & { include: { team: true } }): Promise<GameSaveWithTeam | null>;
  findFirst(args?: QueryArgs): Promise<GameSaveRecord | null>;
  findMany(args: QueryArgs & { include: { team: true } }): Promise<GameSaveWithTeam[]>;
  findMany(args?: QueryArgs): Promise<GameSaveRecord[]>;
}

/** TransferListing-таблица с типизированным include { player }. */
export interface TransferListingTable extends Omit<Table<TransferListingRecord>, 'findUnique' | 'findFirst' | 'findMany'> {
  findUnique(args: { where: Record<string, string>; include: { player: true } }): Promise<TransferListingWithPlayer | null>;
  findUnique(args: { where: Record<string, string> } & QueryArgs): Promise<TransferListingRecord | null>;
  findFirst(args: QueryArgs & { include: { player: true } }): Promise<TransferListingWithPlayer | null>;
  findFirst(args?: QueryArgs): Promise<TransferListingRecord | null>;
  findMany(args: QueryArgs & { include: { player: true } }): Promise<TransferListingWithPlayer[]>;
  findMany(args?: QueryArgs): Promise<TransferListingRecord[]>;
}

/** ScoutReport-таблица с типизированным include { player } (Модуль 3). */
export interface ScoutReportTable extends Omit<Table<ScoutReportRecord>, 'findUnique' | 'findFirst' | 'findMany'> {
  findUnique(args: { where: Record<string, string>; include: { player: true } }): Promise<ScoutReportWithPlayer | null>;
  findUnique(args: { where: Record<string, string> } & QueryArgs): Promise<ScoutReportRecord | null>;
  findFirst(args: QueryArgs & { include: { player: true } }): Promise<ScoutReportWithPlayer | null>;
  findFirst(args?: QueryArgs): Promise<ScoutReportRecord | null>;
  findMany(args: QueryArgs & { include: { player: true } }): Promise<ScoutReportWithPlayer[]>;
  findMany(args?: QueryArgs): Promise<ScoutReportRecord[]>;
}

/** TransferOffer-таблица с типизированным include { player } (Модуль 3). */
export interface TransferOfferTable extends Omit<Table<TransferOfferRecord>, 'findUnique' | 'findFirst' | 'findMany'> {
  findUnique(args: { where: Record<string, string>; include: { player: true } }): Promise<TransferOfferWithPlayer | null>;
  findUnique(args: { where: Record<string, string> } & QueryArgs): Promise<TransferOfferRecord | null>;
  findFirst(args: QueryArgs & { include: { player: true } }): Promise<TransferOfferWithPlayer | null>;
  findFirst(args?: QueryArgs): Promise<TransferOfferRecord | null>;
  findMany(args: QueryArgs & { include: { player: true } }): Promise<TransferOfferWithPlayer[]>;
  findMany(args?: QueryArgs): Promise<TransferOfferRecord[]>;
}

/** Канонический дамп всех «таблиц» (ключи дампа — §2.1). */
export interface CareerDump {
  gameSave: GameSaveRecord[];
  teams: TeamRecord[];
  players: PlayerRecord[];
  matches: MatchRecord[];
  transferListings: TransferListingRecord[];
  scoutReports: ScoutReportRecord[];
  transferOffers: TransferOfferRecord[];
  playerSeasonRecords: PlayerSeasonRecordRecord[];
  newsItems: NewsItemRecord[];
  financeRecords: FinanceRecordRecord[];
  seasonAwards: SeasonAwardRecord[];
  newspaperClippings: NewspaperClippingRecord[];
  staff: StaffRecord[];
}

export interface SaveStore {
  gameSave: GameSaveTable;
  team: Table<TeamRecord>;
  player: Table<PlayerRecord>;
  match: Table<MatchRecord>;
  transferListing: TransferListingTable;
  scoutReport: ScoutReportTable;
  transferOffer: TransferOfferTable;
  playerTraining: Table<PlayerTrainingRecord>;
  playerSeasonRecord: Table<PlayerSeasonRecordRecord>;
  newsItem: Table<NewsItemRecord>;
  financeRecord: Table<FinanceRecordRecord>;
  seasonAward: Table<SeasonAwardRecord>;
  newspaperClipping: Table<NewspaperClippingRecord>;
  staff: Table<StaffRecord>;
  /** Промисы применяются немедленно; атомарность — архитектурно (§1.2). */
  $transaction(ops: readonly EngineOp[]): Promise<unknown[]>;
  /** Канонический дамп: стабильный порядок ключей записей (спека §2.1). */
  toJSON(): CareerDump;
}

// ── Ошибки (софт-совместимы с Prisma) ──────────────────────────────────────

/** Нарушение unique-ограничения (Prisma P2002). */
export class EngineUniqueError extends Error {
  readonly code = 'P2002';
  readonly meta: { target: string[] };

  constructor(target: string[]) {
    super(`Unique constraint failed on the fields: (${target.join(',')})`);
    this.name = 'EngineUniqueError';
    this.meta = { target };
  }
}

/** Запись не найдена для update/delete (Prisma P2025). */
export class EngineRecordNotFoundError extends Error {
  readonly code = 'P2025';
  readonly meta: { cause: string };

  constructor(cause: string) {
    super(`An operation failed because it depends on one or more records that were required but not found. ${cause}`);
    this.name = 'EngineRecordNotFoundError';
    this.meta = { cause };
  }
}

// ── Ленивые операции (семантика PrismaPromise, Д-3c) ──────────────────────

/**
 * Отложенная операция БД — аналог PrismaPromise: вызов метода таблицы только
 * строит операцию; применение — при первом await/then (или в $transaction,
 * ПОСЛЕДОВАТЕЛЬНО в порядке массива). Ключевой кейс: сезонные extraOps в
 * week.ts строятся до дифф-апдейтов, но применяются ПОСЛЕ них (порядок массива
 * ops, а не порядок построения) — иначе update удалённой строки даёт P2025.
 */
class LazyOp<T> implements Promise<T> {
  private promise: Promise<T> | null = null;
  private readonly exec: () => T | Promise<T>;

  constructor(exec: () => T | Promise<T>) {
    this.exec = exec;
  }

  private run(): Promise<T> {
    if (this.promise === null) this.promise = Promise.resolve().then(this.exec);
    return this.promise;
  }

  then<R1 = T, R2 = never>(
    onfulfilled?: ((value: T) => R1 | PromiseLike<R1>) | null,
    onrejected?: ((reason: unknown) => R2 | PromiseLike<R2>) | null,
  ): Promise<R1 | R2> {
    return this.run().then(onfulfilled, onrejected);
  }

  catch<R2 = never>(
    onrejected?: ((reason: unknown) => R2 | PromiseLike<R2>) | null,
  ): Promise<T | R2> {
    return this.run().catch(onrejected);
  }

  finally(onfinally?: (() => void) | null): Promise<T> {
    return this.run().finally(onfinally);
  }

  get [Symbol.toStringTag](): string {
    return 'EngineOp';
  }
}

/** Снимок аргументов вызова: Prisma сериализует аргументы В МОМЕНТ вызова. */
function snapshotArgs<A extends object>(args: A | undefined): A | undefined {
  if (args === undefined) return undefined;
  const out: Record<string, unknown> = { ...(args as Record<string, unknown>) };
  for (const key of ['where', 'data', 'orderBy', 'select', 'include']) {
    const v = out[key];
    if (v === null || typeof v !== 'object') continue;
    out[key] = Array.isArray(v)
      ? (v as Record<string, unknown>[]).map((x) => ({ ...x }))
      : { ...(v as Record<string, unknown>) };
  }
  return out as A;
}

// ── Where / orderBy ────────────────────────────────────────────────────────

/** Скалярные условия одного поля (без отношений). */
function matchScalarField(value: unknown, cond: WhereField): boolean {
  if (cond !== null && typeof cond === 'object' && !Array.isArray(cond)) {
    if ('not' in cond) {
      if (value === (cond as { not: WhereVal }).not) return false;
    } else if ('in' in cond) {
      const list = (cond as { in: WhereVal[] }).in;
      if (!list.includes(value as WhereVal)) return false;
    }
    return true;
  }
  return value === cond;
}

/** Сравнение значений: null/undefined — наименьшие (семантика SQLite ASC). */
function compareValues(a: unknown, b: unknown): number {
  const aEmpty = a === null || a === undefined;
  const bEmpty = b === null || b === undefined;
  if (aEmpty && bEmpty) return 0;
  if (aEmpty) return -1;
  if (bEmpty) return 1;
  if (a instanceof Date && b instanceof Date) return a.getTime() - b.getTime();
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  if (typeof a === 'boolean' && typeof b === 'boolean') return (a ? 1 : 0) - (b ? 1 : 0);
  const sa = String(a);
  const sb = String(b);
  return sa < sb ? -1 : sa > sb ? 1 : 0;
}

function sortRows<T>(rows: readonly T[], orderBy?: Record<string, SortDir>[]): T[] {
  if (!orderBy || orderBy.length === 0) return [...rows];
  const out = [...rows];
  out.sort((a, b) => {
    const ra = a as Record<string, unknown>;
    const rb = b as Record<string, unknown>;
    for (const spec of orderBy) {
      for (const field of Object.keys(spec)) {
        const cmp = compareValues(ra[field], rb[field]);
        if (cmp !== 0) return spec[field] === 'desc' ? -cmp : cmp;
      }
    }
    return 0; // стабильный tiebreak (V8 sort стабилен; код всегда даёт свой)
  });
  return out;
}

/** Ключ unique-индекса; null = любой из полей NULL → ограничения нет (SQLite). */
function uniqueKeyOf(fields: readonly string[], rec: Record<string, unknown>): string | null {
  const values: unknown[] = [];
  for (const f of fields) {
    const v = rec[f];
    if (v === null || v === undefined) return null;
    values.push(v);
  }
  return JSON.stringify(values);
}

// ── Реализация таблицы ─────────────────────────────────────────────────────

interface UniqueIndex {
  readonly fields: readonly string[];
  readonly map: Map<string, unknown>;
}

/** Unique-индексы по схеме (§1.2): Match-композит, Listing.playerId, GameSave.teamId. */
const UNIQUE_INDEXES: Record<ModelName, readonly (readonly string[])[]> = {
  gameSave: [['teamId']],
  team: [],
  player: [],
  match: [['saveId', 'season', 'week', 'homeTeamId', 'competition']],
  transferListing: [['playerId']],
  scoutReport: [['saveId', 'playerId']],
  transferOffer: [],
  playerTraining: [['saveId', 'playerId']],
  playerSeasonRecord: [],
  newsItem: [],
  financeRecord: [],
  seasonAward: [],
  newspaperClipping: [],
  staff: [],
};

/** Поля @updatedAt (бампаются при каждом update). */
const AUTO_UPDATE_FIELDS: Record<ModelName, readonly string[]> = {
  gameSave: ['updatedAt'],
  team: [],
  player: [],
  match: [],
  transferListing: [],
  scoutReport: ['updatedAt'],
  transferOffer: ['updatedAt'],
  playerTraining: ['updatedAt'],
  playerSeasonRecord: [],
  newsItem: [],
  financeRecord: [],
  seasonAward: [],
  newspaperClipping: [],
  staff: [],
};

class TableImpl<T> {
  readonly rows: T[] = [];
  private readonly name: ModelName;
  private readonly spec: ModelSpec;
  private readonly clock: () => Date;
  private readonly uniques: UniqueIndex[] = [];
  private readonly autoUpdate: readonly string[];
  private readonly idIndex = new Map<string, T>();
  /** Источник отношения для include (линкуется фабрикой хранилища). */
  playerSource: TableImpl<PlayerRecord> | null = null;
  teamSource: TableImpl<TeamRecord> | null = null;
  /** Отношения для where-фильтров (D-3b): имя → FK-поле + таблица-источник. */
  readonly relationByField = new Map<string, { fkField: string; source: TableImpl<never> }>();
  /**
   * Каскады FK при удалении строки (onDelete схемы, D-3c): Player →
   * PlayerSeasonRecord (Cascade) и SeasonAward (SetNull). Удаления команд/
   * сейвов геймплеем не происходят (слот удаляется целиком без каскадов).
   */
  cascades: readonly { source: TableImpl<never>; fkField: string; mode: 'cascade' | 'setNull' }[] = [];

  constructor(name: ModelName, clock: () => Date) {
    this.name = name;
    this.spec = MODEL_SPECS[name];
    this.clock = clock;
    this.autoUpdate = AUTO_UPDATE_FIELDS[name];
    for (const fields of UNIQUE_INDEXES[name]) {
      this.uniques.push({ fields, map: new Map<string, unknown>() });
    }
  }

  // ── чтение/запись: ЛЕНИВЫЕ операции (аналог PrismaPromise, Д-3c) ──────
  // Вызов лишь строит операцию со снимком аргументов; применение — при первом
  // await/then ИЛИ в $transaction ПОСЛЕДОВАТЕЛЬНО в порядке массива. Так
  // воспроизводится семантика Prisma: сезонные extraOps (delete пенсионеров)
  // строятся раньше дифф-апдейтов, но в транзакции идут ПОСЛЕ них.

  findMany(args?: QueryArgs): Promise<T[]> {
    const a = snapshotArgs(args);
    return new LazyOp(() => this.selectRows(this.query(a), a));
  }

  findFirst(args?: QueryArgs): Promise<T | null> {
    const a = snapshotArgs(args);
    return new LazyOp(() => {
      const rows = this.query(a);
      return rows.length > 0 ? this.project(rows[0], a) : null;
    });
  }

  findUnique(args: { where: Record<string, string> } & QueryArgs): Promise<T | null> {
    const a = snapshotArgs(args) as { where: Record<string, string> } & QueryArgs;
    return new LazyOp(() => {
      const row = this.rowByWhere(a.where);
      return row ? this.project(row, a) : null;
    });
  }

  count(args?: { where: Where }): Promise<number> {
    const a = snapshotArgs(args);
    return new LazyOp(() => {
      if (!a?.where) return this.rows.length;
      let n = 0;
      for (const row of this.rows) if (this.whereMatch(row, a.where)) n += 1;
      return n;
    });
  }

  create(args: { data: Partial<T> }): Promise<T> {
    const a = snapshotArgs(args) as { data: Partial<T> };
    return new LazyOp(() => {
      const row = this.buildRow(a.data as Record<string, unknown>);
      this.insertRow(row);
      return this.shallowCopy(row);
    });
  }

  createMany(args: { data: Partial<T>[] }): Promise<{ count: number }> {
    const a = snapshotArgs(args) as { data: Partial<T>[] };
    return new LazyOp(() => {
      for (const data of a.data) {
        this.insertRow(this.buildRow(data as Record<string, unknown>));
      }
      return { count: a.data.length };
    });
  }

  update(args: { where: Record<string, string>; data: Partial<T> }): Promise<T> {
    const a = snapshotArgs(args) as { where: Record<string, string>; data: Partial<T> };
    return new LazyOp(() => this.execUpdate(a));
  }

  updateMany(args: { where: Where; data: Partial<T> }): Promise<{ count: number }> {
    const a = snapshotArgs(args) as { where: Where; data: Partial<T> };
    return new LazyOp(async () => {
      const rows = this.rows.filter((r) => this.whereMatch(r, a.where));
      let count = 0;
      for (const row of rows) {
        const id = (row as Record<string, unknown>).id;
        if (typeof id !== 'string') continue;
        await this.execUpdate({ where: { id }, data: a.data });
        count += 1;
      }
      return { count };
    });
  }

  delete(args: { where: Record<string, string> }): Promise<T> {
    const a = snapshotArgs(args) as { where: Record<string, string> };
    return new LazyOp(() => {
      const row = this.rowByWhere(a.where);
      if (!row) throw new EngineRecordNotFoundError(`delete ${this.name}: ${JSON.stringify(a.where)}`);
      this.removeRow(row);
      return this.shallowCopy(row);
    });
  }

  deleteMany(args: { where: Where }): Promise<{ count: number }> {
    const a = snapshotArgs(args) as { where: Where };
    return new LazyOp(() => {
      const rows = this.rows.filter((r) => this.whereMatch(r, a.where));
      for (const row of rows) this.removeRow(row);
      return { count: rows.length };
    });
  }

  /** Синхронное применение update (вызывается лениво): undefined = не трогать. */
  private execUpdate(a: { where: Record<string, string>; data: Partial<T> }): T {
    const row = this.rowByWhere(a.where);
    if (!row) throw new EngineRecordNotFoundError(`update ${this.name}: ${JSON.stringify(a.where)}`);
    const rec = row as Record<string, unknown>;
    const data = a.data as Record<string, unknown>;

    const oldId = typeof rec.id === 'string' ? rec.id : null;
    const oldKeys = this.uniques.map((u) => uniqueKeyOf(u.fields, rec));

    // Проба нового состояния: unique-проверка до мутации.
    // Семантика Prisma: undefined в data = «поле не трогать» (week.ts:
    // playedMatchOps передаёт stats: undefined для ИИ-матчей).
    const probe: Record<string, unknown> = { ...rec };
    for (const f of this.spec.fields) {
      if (data[f] !== undefined) probe[f] = this.coerceField(f, data[f]);
    }
    for (const f of this.autoUpdate) probe[f] = this.clock();
    this.assertUniques(probe, row, oldId);

    for (const f of this.spec.fields) {
      if (data[f] !== undefined) rec[f] = this.coerceField(f, data[f]);
    }
    for (const f of this.autoUpdate) rec[f] = probe[f];

    // Перестройка индексов строки
    const newId = typeof rec.id === 'string' ? rec.id : null;
    if (oldId !== null && newId !== null && oldId !== newId) {
      this.idIndex.delete(oldId);
      this.idIndex.set(newId, row);
    }
    for (let i = 0; i < this.uniques.length; i++) {
      const u = this.uniques[i];
      const newKey = uniqueKeyOf(u.fields, rec);
      if (oldKeys[i] === newKey) continue;
      if (oldKeys[i] !== null) u.map.delete(oldKeys[i] as string);
      if (newKey !== null) u.map.set(newKey, row);
    }
    return this.shallowCopy(row);
  }

  // ── канонизация / загрузка ───────────────────────────────────────────────

  /** Каноническая копия: ключи в порядке полей схемы, undefined отброшены. */
  canonicalRow(row: T): Record<string, unknown> {
    const rec = row as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const f of this.spec.fields) {
      const v = rec[f];
      if (v !== undefined) out[f] = v;
    }
    return out;
  }

  /** Загрузка строки из дампа: канонизация + ревайв Date (§1.2). */
  loadRow(raw: unknown): void {
    if (raw === null || typeof raw !== 'object') {
      throw new Error(`loadRow ${this.name}: ожидается объект`);
    }
    const src = raw as Record<string, unknown>;
    const merged: Record<string, unknown> = { ...this.spec.defaults, ...src };
    const row: Record<string, unknown> = {};
    for (const f of this.spec.fields) {
      const v = merged[f];
      if (v === undefined) continue;
      // null-даты остаются null (new Date(null) = epoch — ловушка D-3c)
      if (v !== null && this.spec.dateFields.includes(f) && !(v instanceof Date)) {
        row[f] = new Date(v as string);
      } else {
        row[f] = this.coerceField(f, v);
      }
    }
    this.insertRow(row as unknown as T);
  }

  // ── внутреннее ───────────────────────────────────────────────────────────

  /** WHERE-матчер этой таблицы: скаляры + вложенные фильтры по отношениям. */
  private whereMatch(row: unknown, where: Where | undefined): boolean {
    if (!where) return true;
    const rec = row as Record<string, unknown>;
    for (const field of Object.keys(where)) {
      const cond: WhereField = where[field];
      const relation = this.relationByField.get(field);
      if (relation) {
        if (!this.matchRelation(rec, relation, cond)) return false;
        continue;
      }
      if (!matchScalarField(rec[field], cond)) return false;
    }
    return true;
  }

  /**
   * Отношение в where (Prisma-семантика to-one): объект — вложенный фильтр по
   * связанной строке (связи нет → строка исключена); null — связи нет.
   * Использование: snapshot.ts `player.findMany({ where: { team: { isEuroGuest: false } } })`.
   */
  private matchRelation(
    rec: Record<string, unknown>,
    relation: { fkField: string; source: TableImpl<never> },
    cond: WhereField,
  ): boolean {
    const fk = rec[relation.fkField];
    if (cond === null) return fk === null || fk === undefined;
    const related = typeof fk === 'string' ? relation.source.findById(fk) : undefined;
    if (!related) return false;
    if (cond !== null && typeof cond === 'object' && !Array.isArray(cond)) {
      return relation.source.whereMatch(related, cond as Where);
    }
    return false; // скаляр поверх отношения не используется
  }

  private query(args?: QueryArgs): T[] {
    const filtered = args?.where ? this.rows.filter((r) => this.whereMatch(r, args.where)) : this.rows;
    const sorted = sortRows(filtered, args?.orderBy);
    const skip = args?.skip !== undefined && args.skip > 0 ? args.skip : 0;
    if (args?.take !== undefined || skip > 0) {
      const take = args?.take !== undefined && args.take >= 0 ? args.take : undefined;
      return take !== undefined ? sorted.slice(skip, skip + take) : sorted.slice(skip);
    }
    return sorted;
  }

  private selectRows(rows: readonly T[], args?: QueryArgs): T[] {
    return rows.map((row) => this.project(row, args));
  }

  /** select-подмножество / include-отношения / копия записи (семантика Prisma). */
  private project(row: T, args?: QueryArgs): T {
    const rec = row as Record<string, unknown>;
    if (args?.select) {
      const out: Record<string, unknown> = {};
      for (const f of this.spec.fields) {
        if (args.select[f]) out[f] = rec[f];
      }
      return out as unknown as T;
    }
    const out: Record<string, unknown> = { ...rec };
    const include = args?.include as { player?: true; team?: true } | undefined;
    if (include?.player && this.playerSource) {
      const pid = rec.playerId;
      out.player = typeof pid === 'string' ? (this.playerSource.findById(pid) ?? null) : null;
    }
    if (include?.team && this.teamSource) {
      const tid = rec.teamId;
      out.team = typeof tid === 'string' ? (this.teamSource.findById(tid) ?? null) : null;
    }
    return out as unknown as T;
  }

  private buildRow(data: Record<string, unknown>): T {
    const merged: Record<string, unknown> = { ...this.spec.defaults, ...data };
    // Паритет Prisma @default(cuid()) (D-8 fix): id генерируется при отсутствии —
    // иначе портированные вызовы create без id (новости/финансы/лоты роутов)
    // писали строки без id → undefined-ключи React и дыры в idIndex.
    // crypto.randomUUID патчится в engine-smoke — детерминизм сохраняется.
    if (merged.id === undefined) merged.id = crypto.randomUUID();
    for (const f of this.spec.clockFields) {
      if (merged[f] === undefined) merged[f] = this.clock();
    }
    const row: Record<string, unknown> = {};
    for (const f of this.spec.fields) {
      if (merged[f] !== undefined) row[f] = this.coerceField(f, merged[f]);
    }
    return row as unknown as T;
  }

  /**
   * Числовая коэрция записи — семантика Prisma+SQLite (паритет D-3c):
   * Int-поля усекают дробные к целому (Math.trunc), Float-поля округляются
   * до 16 значащих цифр (проба: 1.2000000000000002 → 1.2, 90.91666… → 90).
   */
  private coerceField(field: string, value: unknown): unknown {
    if (typeof value !== 'number') return value;
    if (this.spec.intFields.includes(field)) {
      return Number.isInteger(value) ? value : Math.trunc(value);
    }
    if (this.spec.floatFields.includes(field)) {
      return Number(value.toPrecision(16));
    }
    return value;
  }

  private insertRow(row: T): void {
    const rec = row as Record<string, unknown>;
    // Валидация ВСЕХ ограничений до мутации индексов (атомарность отказа)
    if (typeof rec.id === 'string' && this.idIndex.has(rec.id)) {
      throw new EngineUniqueError(['id']);
    }
    const keys: (string | null)[] = [];
    for (const u of this.uniques) {
      const key = uniqueKeyOf(u.fields, rec);
      if (key === null) {
        keys.push(null);
        continue;
      }
      if (u.map.has(key)) throw new EngineUniqueError([...u.fields]);
      keys.push(key);
    }
    if (typeof rec.id === 'string') this.idIndex.set(rec.id, row);
    for (let i = 0; i < this.uniques.length; i++) {
      if (keys[i] !== null) this.uniques[i].map.set(keys[i] as string, row);
    }
    this.rows.push(row);
  }

  private removeRow(row: T): void {
    const rec = row as Record<string, unknown>;
    const rowId = typeof rec.id === 'string' ? rec.id : null;
    if (rowId !== null) this.idIndex.delete(rowId);
    for (const u of this.uniques) {
      const key = uniqueKeyOf(u.fields, rec);
      if (key !== null) u.map.delete(key);
    }
    const idx = this.rows.indexOf(row);
    if (idx >= 0) this.rows.splice(idx, 1);
    if (rowId !== null) this.applyCascades(rowId);
  }

  /** FK onDelete схемы: PlayerSeasonRecord — Cascade, SeasonAward — SetNull. */
  private applyCascades(deletedId: string): void {
    for (const c of this.cascades) {
      const source = c.source as unknown as TableImpl<Record<string, unknown>>;
      if (c.mode === 'setNull') {
        for (const target of source.rows) {
          if (target[c.fkField] === deletedId) target[c.fkField] = null;
        }
        continue;
      }
      const victims = source.rows.filter((target) => target[c.fkField] === deletedId);
      for (const victim of victims) source.removeRow(victim as never);
    }
  }

  private assertUniques(probe: Record<string, unknown>, self: T, selfId: string | null): void {
    if (typeof probe.id === 'string') {
      const holder = this.idIndex.get(probe.id);
      if (holder !== undefined && holder !== self) throw new EngineUniqueError(['id']);
    } else if (selfId !== null) {
      throw new Error(`update ${this.name}: id не может стать пустым`);
    }
    for (const u of this.uniques) {
      const key = uniqueKeyOf(u.fields, probe);
      if (key === null) continue;
      const holder = u.map.get(key);
      if (holder !== undefined && holder !== self) throw new EngineUniqueError([...u.fields]);
    }
  }

  private rowByWhere(where: Record<string, string>): T | undefined {
    const keys = Object.keys(where);
    if (keys.length === 1 && keys[0] === 'id' && typeof where.id === 'string') {
      return this.idIndex.get(where.id);
    }
    return this.rows.find((row) => {
      const rec = row as Record<string, unknown>;
      return keys.every((k) => rec[k] === where[k]);
    });
  }

  findById(id: string): T | undefined {
    return this.idIndex.get(id);
  }

  private shallowCopy(row: T): T {
    return { ...(row as Record<string, unknown>) } as unknown as T;
  }
}

// ── Фабрики хранилища ──────────────────────────────────────────────────────

const MODEL_NAMES: ModelName[] = [
  'gameSave', 'team', 'player', 'match', 'transferListing', 'scoutReport', 'transferOffer',
  'playerSeasonRecord', 'newsItem', 'financeRecord', 'seasonAward', 'newspaperClipping', 'staff',
  'playerTraining',
];

export interface SaveStoreOptions {
  /** Часы хранилища для @default(now())/@updatedAt; дефолт — системное время. */
  clock?: () => Date;
}

/** Пустое хранилище (новая карьера). */
export function createSaveStore(options: SaveStoreOptions = {}): SaveStore {
  const clock = options.clock ?? (() => new Date());

  const tables = new Map<ModelName, TableImpl<never>>();
  for (const name of MODEL_NAMES) {
    tables.set(name, new TableImpl<never>(name, clock));
  }
  // Отношения include (§1.2): TransferListing.player, GameSave.team;
  // отношения where-фильтров (D-3b): те же + Player.team (изоляция гостей).
  (tables.get('gameSave') as TableImpl<GameSaveRecord>).teamSource =
    tables.get('team') as TableImpl<TeamRecord>;
  (tables.get('transferListing') as TableImpl<TransferListingRecord>).playerSource =
    tables.get('player') as TableImpl<PlayerRecord>;
  // Модуль 3: include { player } для отчётов скаутинга и входящих офферов
  (tables.get('scoutReport') as TableImpl<ScoutReportRecord>).playerSource =
    tables.get('player') as TableImpl<PlayerRecord>;
  (tables.get('transferOffer') as TableImpl<TransferOfferRecord>).playerSource =
    tables.get('player') as TableImpl<PlayerRecord>;
  (tables.get('gameSave') as TableImpl<GameSaveRecord>).relationByField.set('team', {
    fkField: 'teamId',
    source: tables.get('team') as TableImpl<never>,
  });
  (tables.get('transferListing') as TableImpl<TransferListingRecord>).relationByField.set('player', {
    fkField: 'playerId',
    source: tables.get('player') as TableImpl<never>,
  });
  (tables.get('player') as TableImpl<PlayerRecord>).relationByField.set('team', {
    fkField: 'teamId',
    source: tables.get('team') as TableImpl<never>,
  });
  // Каскады FK onDelete (D-3c): удаление Player — PlayerSeasonRecord (Cascade)
  // и SeasonAward.playerId (SetNull); лоты week.ts удаляет явно ДО игрока.
  // Модуль 3: Player → ScoutReport/TransferOffer (Cascade, как в Prisma-схеме).
  // Модуль 4: Player → PlayerTraining (Cascade — индивидуальная программа
  // умирает вместе с игроком/при его продаже).
  (tables.get('player') as TableImpl<PlayerRecord>).cascades = [
    { source: tables.get('playerSeasonRecord') as TableImpl<never>, fkField: 'playerId', mode: 'cascade' },
    { source: tables.get('seasonAward') as TableImpl<never>, fkField: 'playerId', mode: 'setNull' },
    { source: tables.get('scoutReport') as TableImpl<never>, fkField: 'playerId', mode: 'cascade' },
    { source: tables.get('transferOffer') as TableImpl<never>, fkField: 'playerId', mode: 'cascade' },
    { source: tables.get('playerTraining') as TableImpl<never>, fkField: 'playerId', mode: 'cascade' },
  ];

  const dump = (): CareerDump => {
    const out: Record<string, unknown> = {};
    for (const name of MODEL_NAMES) {
      const table = tables.get(name) as TableImpl<never>;
      out[DUMP_KEY_BY_MODEL[name]] = table.rows.map((row) => table.canonicalRow(row));
    }
    return out as unknown as CareerDump;
  };

  const store: SaveStore = {
    // Типизация include-перегрузок описана интерфейсами; реализация единая.
    gameSave: tables.get('gameSave') as unknown as GameSaveTable,
    team: tables.get('team') as unknown as Table<TeamRecord>,
    player: tables.get('player') as unknown as Table<PlayerRecord>,
    match: tables.get('match') as unknown as Table<MatchRecord>,
    transferListing: tables.get('transferListing') as unknown as TransferListingTable,
    scoutReport: tables.get('scoutReport') as unknown as ScoutReportTable,
    transferOffer: tables.get('transferOffer') as unknown as TransferOfferTable,
    playerTraining: tables.get('playerTraining') as unknown as Table<PlayerTrainingRecord>,
    playerSeasonRecord: tables.get('playerSeasonRecord') as unknown as Table<PlayerSeasonRecordRecord>,
    newsItem: tables.get('newsItem') as unknown as Table<NewsItemRecord>,
    financeRecord: tables.get('financeRecord') as unknown as Table<FinanceRecordRecord>,
    seasonAward: tables.get('seasonAward') as unknown as Table<SeasonAwardRecord>,
    newspaperClipping: tables.get('newspaperClipping') as unknown as Table<NewspaperClippingRecord>,
    staff: tables.get('staff') as unknown as Table<StaffRecord>,
    $transaction(ops: readonly EngineOp[]): Promise<unknown[]> {
      // Prisma: массив ops применяется ПОСЛЕДОВАТЕЛЬНО в порядке массива —
      // чтения/построение до $transaction видят ДО-транзакционное состояние.
      const list = [...ops];
      return new LazyOp(async () => {
        const results: unknown[] = [];
        for (const op of list) results.push(await op);
        return results;
      });
    },
    toJSON(): CareerDump {
      return dump();
    },
  };
  return store;
}

/** Хранилище из дампа слота: канонизация строк + ревайв Date (§1.2, §2.1). */
export function createSaveStoreFromDump(career: unknown, options: SaveStoreOptions = {}): SaveStore {
  if (career === null || typeof career !== 'object' || Array.isArray(career)) {
    throw new Error('createSaveStoreFromDump: career должен быть объектом');
  }
  const source = career as Record<string, unknown>;
  const store = createSaveStore(options);
  for (const name of MODEL_NAMES) {
    const rows = source[DUMP_KEY_BY_MODEL[name]];
    if (rows === undefined) continue; // аддитивные таблицы могут отсутствовать (легаси)
    if (!Array.isArray(rows)) {
      throw new Error(`createSaveStoreFromDump: ${DUMP_KEY_BY_MODEL[name]} должен быть массивом`);
    }
    const table = (store as unknown as Record<string, TableImpl<never>>)[name];
    for (const raw of rows) table.loadRow(raw);
  }
  return store;
}

// ── Активная карьера движка (спека §1.6, фасад — src/engine/index.ts) ──────

let activeStore: SaveStore | null = null;

/** Установить/сбросить активное хранилище (engine.createCareer / loadSlot / unload). */
export function setActiveStore(store: SaveStore | null): void {
  activeStore = store;
}

/** Активное хранилище движка; throw, если карьера не создана/не загружена. */
export function getActiveStore(): SaveStore {
  if (activeStore === null) {
    throw new Error('SaveStore: активная карьера не загружена (engine.createCareer()/loadSlot())');
  }
  return activeStore;
}

/**
 * Prisma-подобный доступ к АКТИВНОМУ хранилищу для портов week/snapshot/
 * api-helpers: текст вызовов `db.team.findMany({...})` совпадает с оригиналом,
 * меняется только источник импорта (серверный клиент → './db'). Свойства
 * резолвятся лениво на каждый вызов — карьера активируется уже после
 * загрузки модулей.
 */
export const db: SaveStore = new Proxy({} as SaveStore, {
  get(_target: SaveStore, prop: string | symbol): unknown {
    const store = getActiveStore() as unknown as Record<string, unknown>;
    return store[prop as string];
  },
});

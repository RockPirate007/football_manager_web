/**
 * Генерация игрока, расчёт OVR, цен/зарплат, авторегенерация состава.
 * Чистые функции над POJO (разделы 4.3–4.4, 4.12 docs/architecture.md).
 */

import {
  ATTR_MAX, ATTR_MIN, FIELD_GK_ATTR_MOD, FORMATIONS,
  GK_FIELD_ATTR_MOD, KEY_ATTR_THRESHOLD, LINEUP_SIZE, BENCH_MAX, OVR_WEIGHTS,
  POSITION_FIT, ROLE_MOD_KEY, ROLE_MOD_MINOR, SALARY_MIN, SALARY_RATIO, SALARY_ROUND,
  SQUAD_MIN_BY_GROUP, SQUAD_MIN, VALUE_BASE, VALUE_GROWTH,
} from './constants';
import { contractUntilFromYears, contractYearsRoll } from './contracts';
import { NAT_TO_POOL, NAME_POOLS, type NamePoolContext } from './leagues';
import { clamp, gauss, pick, pickWeighted, randInt, type RNG } from './rng';
import type { Attributes, FormationId, Position, PositionGroup } from './types';

/** Все 21 атрибут игрока (для сдвига характеристик; MUST ⊇ ключей OVR_WEIGHTS —
 * иначе нормализация OVR (академия/сын) сдвигает не все слагемые и даёт дрейф). */
export const ATTR_KEYS: (keyof Attributes)[] = [
  'finishing', 'passing', 'dribbling', 'crossing', 'tackling', 'marking',
  'positioning', 'heading', 'pace', 'stamina', 'strength', 'aggression',
  'reflexes', 'rushingOut', 'kicking',
  'vision', 'decisions', 'leadership', 'acceleration', 'jumping', 'handling',
];

/** Игрок как POJO (структурно совместим с моделью Prisma Player). */
export interface PlayerLike extends Attributes {
  id: string;
  teamId: string | null;
  /** Engine 2.0: скрытые параметры (опциональны для совместимости легаси-DTO). */
  injuryProneness?: number;
  consistency?: number;
  firstName: string;
  lastName: string;
  nationality: string;
  position: Position;
  shirtNumber: number;
  age: number;
  potential: number;
  ovr: number;
  morale: number;
  condition: number;
  injuryWeeks: number;
  value: number;
  salary: number;
  goals: number;
  assists: number;
  apps: number;
  yellowCards: number;
  redCards: number;
  /** Накопленный тренировочный опыт (JSON); опционален для совместимости с клиентскими DTO. */
  trainingXp?: string | null;
  cleanSheets: number;
  cupGoals: number;
  cupAssists: number;
  // ── Фаза 4: Кубок Европы ──
  euroGoals: number;
  euroAssists: number;
  // ── Фаза 3 ──
  /** Последний сезон действия контракта ВКЛЮЧИТЕЛЬНО (абсолютная шкала). */
  contractUntil: number;
  /** Босман: клуб предконтракта (null = нет). */
  preContractTeamId: string | null;
  /** Сумма рейтингов матчей ×10 (68 = 6.8). */
  ratingSum: number;
  /** Число матчей с рейтингом (= старты). */
  ratingApps: number;
  /** Воспитанник академии. */
  isAcademy: boolean;
}

/**
 * Минимальный профиль игрока для UI-расчётов автосостава/силы линий (Фаза 3):
 * клиентский PlayerDTO структурно совместим; на сервере подставляется PlayerLike.
 */
export type LineupPlayer = Pick<
  PlayerLike, 'id' | 'position' | 'ovr' | 'condition' | 'morale' | 'injuryWeeks'
>;

// ── Группы позиций ───────────────────────────────────────────────────────

export function positionGroupOf(position: Position): PositionGroup {
  switch (position) {
    case 'GK': return 'GK';
    case 'DL': case 'DC': case 'DR': return 'DEF';
    case 'DML': case 'DMC': case 'DMR': return 'DM';
    case 'ML': case 'MC': case 'MR': return 'MID';
    case 'AML': case 'AMC': case 'AMR': return 'AM';
    case 'ST': return 'ST';
  }
}

/** Широкая группа для фильтров и минимальных требований состава. */
export function broadGroupOf(position: Position): 'GK' | 'DEF' | 'MID' | 'FWD' {
  const g = positionGroupOf(position);
  if (g === 'GK') return 'GK';
  if (g === 'DEF' || g === 'DM') return 'DEF';
  if (g === 'MID' || g === 'AM') return 'MID';
  return 'FWD';
}

// ── OVR ──────────────────────────────────────────────────────────────────

/**
 * OVR = взвешенное среднее атрибутов по весам позиции (таблица 4.4).
 * Для позиций с суммой весов ≠ 100 (погрешность таблицы) делим на фактическую
 * сумму — шкала OVR 1..100 сохраняется для всех позиций.
 */
export function computeOvr(attrs: Attributes, position: Position): number {
  const weights = OVR_WEIGHTS[position];
  let sum = 0;
  let total = 0;
  for (const key of Object.keys(weights) as (keyof Attributes)[]) {
    const w = weights[key as keyof typeof weights] ?? 0;
    if (w === 0) continue;
    sum += attrs[key] * (w as number);
    total += w as number;
  }
  if (total === 0) return 1;
  return clamp(Math.round(sum / total), 1, 100);
}

/** Ключевые атрибуты позиции (вес ≥ 10 в OVR-таблице). */
export function keyAttrsOf(position: Position): (keyof Attributes)[] {
  const weights = OVR_WEIGHTS[position];
  const out: (keyof Attributes)[] = [];
  for (const key of Object.keys(weights) as (keyof Attributes)[]) {
    if ((weights[key as keyof typeof weights] as number) >= KEY_ATTR_THRESHOLD) out.push(key);
  }
  return out;
}

// ── Экономика ────────────────────────────────────────────────────────────

export function ageFactorOf(age: number): number {
  if (age <= 21) return 1.3;
  if (age <= 27) return 1.0;
  if (age <= 30) return 0.75;
  if (age <= 33) return 0.4;
  return 0.15;
}

/** value = 50K × 1.11^OVR × возрастной × потенциальный × формовый (4.12). */
export function computeValue(p: { ovr: number; age: number; potential: number; morale: number }): number {
  const potentialFactor = 1 + clamp((p.potential - p.ovr) * 0.04, 0, 0.5);
  const formFactor = 0.9 + (p.morale / 100) * 0.2;
  const raw = VALUE_BASE * Math.pow(VALUE_GROWTH, p.ovr) * ageFactorOf(p.age) * potentialFactor * formFactor;
  return Math.max(10_000, Math.round(raw));
}

/** salary = max(500, round(value × 0.0002 / 100) × 100) €/нед. */
export function computeSalary(value: number): number {
  return Math.max(SALARY_MIN, Math.round((value * SALARY_RATIO) / SALARY_ROUND) * SALARY_ROUND);
}

/** Пересчитать ovr/value/salary игрока на месте. */
export function refreshEconomy(p: PlayerLike): void {
  p.ovr = computeOvr(p, p.position);
  p.value = computeValue(p);
  p.salary = computeSalary(p.value);
}

// ── Генерация ────────────────────────────────────────────────────────────

const AGE_BANDS = [
  { from: 16, to: 19, weight: 0.1 },
  { from: 20, to: 23, weight: 0.2 },
  { from: 24, to: 27, weight: 0.3 },
  { from: 28, to: 31, weight: 0.25 },
  { from: 32, to: 36, weight: 0.15 },
] as const;

export function sampleAge(rng: RNG): number {
  const band = pickWeighted(rng, AGE_BANDS.map((b) => ({ item: b, weight: b.weight })));
  return randInt(rng, band.from, band.to);
}

function genAttrs(rng: RNG, strength: number, position: Position): Attributes {
  const weights = OVR_WEIGHTS[position];
  const isGk = position === 'GK';
  const attrs = {} as Attributes;
  const keys: (keyof Attributes)[] = [
    'finishing', 'passing', 'dribbling', 'crossing', 'tackling', 'marking',
    'positioning', 'heading', 'pace', 'stamina', 'strength', 'aggression',
    'reflexes', 'rushingOut', 'kicking',
  ];
  for (const key of keys) {
    const w = (weights[key as keyof typeof weights] as number | undefined) ?? 0;
    const roleMod = w >= KEY_ATTR_THRESHOLD ? ROLE_MOD_KEY : ROLE_MOD_MINOR;
    let extraMod = 1;
    const isGkAttr = key === 'reflexes' || key === 'rushingOut' || key === 'kicking';
    if (!isGk && isGkAttr) extraMod = FIELD_GK_ATTR_MOD; // вратарские для полевых ×0.4
    if (isGk && !isGkAttr && w === 0) extraMod = GK_FIELD_ATTR_MOD; // полевые для вратаря ×0.6
    const attr = gauss(rng, strength, 8);
    attrs[key] = clamp(Math.round(attr * roleMod * extraMod), ATTR_MIN, ATTR_MAX);
  }

  // ── Engine 2.0: ментальные/физические атрибуты и надёжность рук ──
  // Генерируются ОТДЕЛЬНО от OVR_WEIGHTS (не влияют на OVR — обратная
  // совместимость баланса), но несут позиционный колорит для дуэлей движка.
  const group = positionGroupOf(position);
  const mental = (base: number, delta: number) =>
    clamp(Math.round(gauss(rng, base, 8) + delta), ATTR_MIN, ATTR_MAX);
  const visionDelta =
    group === 'MID' || group === 'AM' ? 6 : group === 'GK' ? -12 : group === 'DM' ? 3 : -3;
  const decisionsDelta = group === 'DM' || group === 'MID' ? 5 : group === 'GK' ? -5 : 0;
  const leadershipDelta = group === 'GK' || position === 'DC' || group === 'DM' ? 5 : 0;
  const accelDelta =
    group === 'ST' || group === 'AM' ? 6 : group === 'GK' ? -10 : group === 'DEF' ? -4 : 0;
  const jumpDelta = position === 'DC' || group === 'ST' ? 6 : group === 'GK' ? -4 : 0;
  attrs.vision = mental(strength, visionDelta);
  attrs.decisions = mental(strength, decisionsDelta);
  attrs.leadership = mental(strength, leadershipDelta);
  attrs.acceleration = mental(strength, accelDelta);
  attrs.jumping = mental(strength, jumpDelta);
  attrs.handling = isGk
    ? clamp(Math.round(gauss(rng, strength, 8) * ROLE_MOD_KEY), ATTR_MIN, ATTR_MAX)
    : clamp(Math.round(gauss(rng, strength, 8) * FIELD_GK_ATTR_MOD), ATTR_MIN, ATTR_MAX);
  return attrs;
}

export interface GeneratePlayerOptions {
  minAge?: number;
  maxAge?: number;
  idFactory?: () => string;
  /** Пул имён лиги; не задан → пул RU (обратная совместимость). */
  pool?: NamePoolContext;
  // ── Фаза 3 (академия) ──
  /** Фиксированный возраст (вместо sampleAge) — набор академии. */
  fixedAge?: number;
  /** Переопределить потенциал (clamp по ovr..99) — жемчужины/тиры академии. */
  potentialOverride?: number;
  /** Последний сезон контракта; не задан → бросок по возрастной таблице. */
  contractUntil?: number;
}

/** Национальность по foreignMix: накопленный вес, остаток — базовая страна пула. */
function rollNationality(rng: RNG, pool: NamePoolContext): string {
  let acc = 0;
  const roll = rng();
  for (const entry of pool.foreign) {
    acc += entry.weight;
    if (roll < acc) return entry.nat;
  }
  return pool.base;
}

function poolOf(nat: string, fallback: keyof typeof NAME_POOLS): { first: string[]; last: string[] } {
  const code = NAT_TO_POOL[nat] ?? fallback;
  return NAME_POOLS[code];
}

export function generatePlayer(
  rng: RNG,
  strength: number,
  position: Position,
  opts: GeneratePlayerOptions = {},
): PlayerLike {
  const idFactory = opts.idFactory ?? (() => crypto.randomUUID());
  let age: number;
  if (opts.fixedAge !== undefined) {
    age = opts.fixedAge;
  } else {
    age = sampleAge(rng);
    if (opts.minAge !== undefined || opts.maxAge !== undefined) {
      age = clamp(age, opts.minAge ?? 16, opts.maxAge ?? 36);
    }
  }
  const attrs = genAttrs(rng, strength, position);
  const ovr = computeOvr(attrs, position);
  let potential = ovr;
  if (age <= 21) potential = ovr + randInt(rng, 4, 15);
  else if (age <= 24) potential = ovr + randInt(rng, 1, 8);
  potential = clamp(potential, ovr, 99);
  if (opts.potentialOverride !== undefined) {
    potential = clamp(opts.potentialOverride, ovr, 99);
  }
  // Фаза 3: контракт (сезон генерации = 1 для мира; академия передаёт явное значение)
  const contractUntil =
    opts.contractUntil ?? contractUntilFromYears(1, contractYearsRoll(rng, age));

  const morale = 60;
  const value = computeValue({ ovr, age, potential, morale });
  const salary = computeSalary(value);

  const pool: NamePoolContext = opts.pool ?? { base: 'RU', foreign: [] };
  const nationality = rollNationality(rng, pool);
  const names = poolOf(nationality, pool.base);

  return {
    id: idFactory(),
    teamId: null,
    firstName: pick(rng, names.first),
    lastName: pick(rng, names.last),
    nationality,
    position,
    shirtNumber: 0,
    age,
    potential,
    ovr,
    ...attrs,
    // Engine 2.0: скрытые параметры (не зависят от силы клуба)
    injuryProneness: clamp(Math.round(gauss(rng, 50, 16)), 15, 92),
    consistency: clamp(Math.round(gauss(rng, 55, 12)), 22, 90),
    morale,
    condition: 100,
    injuryWeeks: 0,
    value,
    salary,
    goals: 0,
    assists: 0,
    apps: 0,
    yellowCards: 0,
    redCards: 0,
    trainingXp: null,
    cleanSheets: 0,
    cupGoals: 0,
    cupAssists: 0,
    euroGoals: 0,
    euroAssists: 0,
    contractUntil,
    preContractTeamId: null,
    ratingSum: 0,
    ratingApps: 0,
    isAcademy: false,
  };
}

/** Уникальные имя+фамилия внутри команды: перегенерация при коллизии из пула игрока. */
export function ensureUniqueNames(rng: RNG, players: PlayerLike[], pool?: NamePoolContext): void {
  const fallback: NamePoolContext = pool ?? { base: 'RU', foreign: [] };
  const seen = new Set<string>();
  for (const p of players) {
    const names = poolOf(p.nationality, fallback.base);
    let key = `${p.firstName} ${p.lastName}`;
    let guard = 0;
    while (seen.has(key) && guard < 50) {
      p.firstName = pick(rng, names.first);
      p.lastName = pick(rng, names.last);
      key = `${p.firstName} ${p.lastName}`;
      guard++;
    }
    seen.add(key);
  }
}

/** Сквозная нумерация 1..N без повторов в команде. */
export function assignShirtNumbers(players: PlayerLike[]): void {
  const used = new Set<number>();
  let next = 1;
  for (const p of players) {
    while (used.has(next)) next++;
    p.shirtNumber = next;
    used.add(next);
  }
}

/** Свободный минимальный номер для нового игрока. */
export function freeShirtNumber(players: PlayerLike[]): number {
  const used = new Set(players.map((p) => p.shirtNumber));
  for (let n = 1; n <= 99; n++) if (!used.has(n)) return n;
  return 99;
}

// ── Требования к составу ─────────────────────────────────────────────────

export function squadGroupCounts(players: PlayerLike[]): Record<'GK' | 'DEF' | 'MID' | 'FWD', number> {
  const counts = { GK: 0, DEF: 0, MID: 0, FWD: 0 };
  for (const p of players) counts[broadGroupOf(p.position)]++;
  return counts;
}

/** Минимальные требования соблюдены (≥2 GK, ≥4 DEF, ≥4 MID, ≥3 FWD, всего ≥13). */
export function squadMinimumsSatisfied(players: PlayerLike[]): boolean {
  if (players.length < SQUAD_MIN) return false;
  const c = squadGroupCounts(players);
  return c.GK >= SQUAD_MIN_BY_GROUP.GK && c.DEF >= SQUAD_MIN_BY_GROUP.DEF
    && c.MID >= SQUAD_MIN_BY_GROUP.MID && c.FWD >= SQUAD_MIN_BY_GROUP.FWD;
}

/** Можно ли продать игрока: после удаления минимумы соблюдены. */
export function canSellPlayer(squad: PlayerLike[], playerId: string): boolean {
  return squadMinimumsSatisfied(squad.filter((p) => p.id !== playerId));
}

// ── Автосостав ───────────────────────────────────────────────────────────

export function positionFitOf(playerPosition: Position, slotPosition: Position): number {
  return POSITION_FIT[positionGroupOf(playerPosition)][positionGroupOf(slotPosition)];
}

/** Скор «вклада» игрока в слот: OVR × fit × готовность. */
export function slotScore(p: LineupPlayer, slotPosition: Position): number {
  return p.ovr * positionFitOf(p.position, slotPosition) * (p.condition / 100);
}

export interface AutoLineupResult {
  lineup: (string | null)[]; // LINEUP_SIZE
  bench: string[];
}

/**
 * Автосостав: для каждого слота формации — доступный (не травмированный) игрок
 * с максимальным OVR × positionFit × condition/100.
 * При `rotate` — простая ротация уставших (для ИИ): если средняя готовность
 * стартового состава < rotateBelow (55 по умолчанию; евронедели ИИ — 65),
 * самый уставший заменяется лучшим свежим запасным.
 */
export function autoLineup(
  squad: LineupPlayer[],
  formation: FormationId,
  rotate = true,
  rotateBelow = 55,
): AutoLineupResult {
  const slots = FORMATIONS[formation].slots;
  const available = squad.filter((p) => p.injuryWeeks === 0);
  const used = new Set<string>();
  const lineup: (string | null)[] = [];

  for (const slot of slots) {
    let best: LineupPlayer | null = null;
    let bestScore = -1;
    for (const p of available) {
      if (used.has(p.id)) continue;
      const score = slotScore(p, slot.position);
      if (score > bestScore) {
        bestScore = score;
        best = p;
      }
    }
    if (best) {
      used.add(best.id);
      lineup.push(best.id);
    } else {
      lineup.push(null);
    }
  }

  if (rotate) {
    const byId = new Map(squad.map((p) => [p.id, p]));
    const starterConditions = lineup
      .map((id) => (id ? byId.get(id) : undefined))
      .filter((p): p is LineupPlayer => !!p)
      .map((p) => p.condition);
    const avgCondition = starterConditions.length
      ? starterConditions.reduce((s, c) => s + c, 0) / starterConditions.length
      : 100;
    if (avgCondition < rotateBelow) {
      // самый уставший стартёр
      let tiredIdx = -1;
      let tiredCondition = 101;
      lineup.forEach((id, i) => {
        const p = id ? byId.get(id) : undefined;
        if (p && p.condition < tiredCondition) {
          tiredCondition = p.condition;
          tiredIdx = i;
        }
      });
      if (tiredIdx >= 0) {
        const slotPos = slots[tiredIdx].position;
        let fresh: LineupPlayer | null = null;
        let freshScore = -1;
        for (const p of available) {
          if (used.has(p.id) || p.condition < 60) continue;
          const score = slotScore(p, slotPos);
          if (score > freshScore) {
            freshScore = score;
            fresh = p;
          }
        }
        if (fresh) {
          used.delete(lineup[tiredIdx] as string);
          used.add(fresh.id);
          lineup[tiredIdx] = fresh.id;
        }
      }
    }
  }

  // Скамейка: 1 вратарь (если есть) + лучшие полевые по OVR×готовность
  const rest = squad.filter((p) => !used.has(p.id) && p.injuryWeeks === 0);
  const bench: string[] = [];
  const gk = rest
    .filter((p) => p.position === 'GK')
    .sort((a, b) => b.ovr - a.ovr)[0];
  if (gk) bench.push(gk.id);
  const fieldRest = rest
    .filter((p) => p.position !== 'GK')
    .sort((a, b) => b.ovr * (b.condition / 100) - a.ovr * (a.condition / 100));
  for (const p of fieldRest) {
    if (bench.length >= BENCH_MAX) break;
    bench.push(p.id);
  }

  return { lineup, bench };
}

/** Данные для db.player.create из POJO-игрока. */
export function playerCreateData(saveId: string, p: PlayerLike) {
  return {
    id: p.id,
    saveId,
    teamId: p.teamId,
    firstName: p.firstName,
    lastName: p.lastName,
    nationality: p.nationality,
    position: p.position,
    shirtNumber: p.shirtNumber,
    age: p.age,
    potential: p.potential,
    ovr: p.ovr,
    finishing: p.finishing,
    passing: p.passing,
    dribbling: p.dribbling,
    crossing: p.crossing,
    tackling: p.tackling,
    marking: p.marking,
    positioning: p.positioning,
    heading: p.heading,
    pace: p.pace,
    stamina: p.stamina,
    strength: p.strength,
    aggression: p.aggression,
    reflexes: p.reflexes,
    rushingOut: p.rushingOut,
    kicking: p.kicking,
    morale: p.morale,
    condition: p.condition,
    injuryWeeks: p.injuryWeeks,
    value: p.value,
    salary: p.salary,
    goals: p.goals,
    assists: p.assists,
    apps: p.apps,
    yellowCards: p.yellowCards,
    redCards: p.redCards,
    trainingXp: p.trainingXp ?? '{}',
    cleanSheets: p.cleanSheets,
    cupGoals: p.cupGoals,
    cupAssists: p.cupAssists,
    // ── Фаза 4 ──
    euroGoals: p.euroGoals,
    euroAssists: p.euroAssists,
    // ── Engine 2.0: ментальные/физические/скрытые — роняются в запись целиком ──
    vision: p.vision,
    decisions: p.decisions,
    leadership: p.leadership,
    acceleration: p.acceleration,
    jumping: p.jumping,
    handling: p.handling,
    injuryProneness: p.injuryProneness ?? 50,
    consistency: p.consistency ?? 55,
    // ── Фаза 3 ──
    contractUntil: p.contractUntil,
    preContractTeamId: p.preContractTeamId,
    ratingSum: p.ratingSum,
    ratingApps: p.ratingApps,
    isAcademy: p.isAcademy,
  };
}

/** Валиден ли состав для матча: 11 игроков, все свои, не травмированы. */
export function isLineupValid(lineup: (string | null)[] | null, squad: PlayerLike[]): boolean {
  if (!lineup || lineup.length !== LINEUP_SIZE) return false;
  const mine = new Set(squad.map((p) => p.id));
  const seen = new Set<string>();
  for (const id of lineup) {
    if (!id || !mine.has(id) || seen.has(id)) return false;
    const p = squad.find((x) => x.id === id);
    if (!p || p.injuryWeeks > 0) return false;
    seen.add(id);
  }
  return true;
}

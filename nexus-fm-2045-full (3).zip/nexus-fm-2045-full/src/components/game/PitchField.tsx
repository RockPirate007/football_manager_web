'use client';

import { cn } from '@/lib/utils';
import { FORMATIONS } from '@/lib/game/constants';
import { ChipLabel, PlayerChip } from '@/components/game/PlayerChip';
import type { FormationId, PlayerDTO } from '@/lib/game/types';

/**
 * Вертикальное поле с разметкой и 11 слотами формации (чистая отрисовка).
 * x: 0..100 слева→направо, y: 0..100 свои ворота↓ → ворота соперника↑.
 */
export function PitchField({
  formation,
  lineup,
  byId,
  selectedSlot,
  onSlotClick,
  className,
}: {
  formation: FormationId;
  lineup: (string | null)[];
  byId: Map<string, PlayerDTO>;
  selectedSlot: number | null;
  onSlotClick: (index: number) => void;
  className?: string;
}) {
  const slots = FORMATIONS[formation].slots;

  return (
    <div
      className={cn(
        'pitch relative w-full overflow-hidden rounded-2xl border-2 border-[#7bd7ff]/35 shadow-[0_0_28px_rgba(0,212,255,0.18)] shadow-inner',
        className,
      )}
      style={{ aspectRatio: '3 / 4' }}
      role="group"
      aria-label={`Формация ${formation} на поле`}
    >
      {/* Меловая разметка */}
      <div className="pointer-events-none absolute inset-2 rounded-sm border chalk" aria-hidden />
      <div className="pointer-events-none absolute inset-x-2 top-1/2 border-t chalk" aria-hidden />
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 size-[18%] -translate-x-1/2 -translate-y-1/2 rounded-full border chalk"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute left-1/2 top-2 h-[13%] w-[58%] -translate-x-1/2 border chalk"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute bottom-2 left-1/2 h-[13%] w-[58%] -translate-x-1/2 border chalk"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute left-1/2 top-2 h-[5.5%] w-[30%] -translate-x-1/2 border chalk"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute bottom-2 left-1/2 h-[5.5%] w-[30%] -translate-x-1/2 border chalk"
        aria-hidden
      />

      {/* Слоты */}
      {slots.map((slot, i) => {
        const id = lineup[i] ?? null;
        const player = id ? byId.get(id) ?? null : null;
        return (
          <div
            key={i}
            className="absolute flex flex-col items-center"
            style={{
              left: `${slot.x}%`,
              top: `${100 - slot.y}%`,
              transform: 'translate(-50%, -50%)',
              zIndex: selectedSlot === i ? 20 : 10,
            }}
          >
            <PlayerChip
              player={player}
              slotPosition={slot.position}
              selected={selectedSlot === i}
              onClick={() => onSlotClick(i)}
            />
            <ChipLabel player={player} slotPosition={slot.position} />
          </div>
        );
      })}
    </div>
  );
}

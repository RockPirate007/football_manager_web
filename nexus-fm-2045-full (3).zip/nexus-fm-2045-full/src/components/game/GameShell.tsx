'use client';

import { useState, useSyncExternalStore } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeftRight, Building2, ChevronUp, ClipboardList, Dumbbell, Globe, GraduationCap,
  LayoutDashboard, Loader2, LogOut, Medal, MoreHorizontal, Newspaper, PanelLeftClose,
  PanelLeftOpen, PlayCircle, Table2, Trophy, UserRound, Users, Wallet,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger,
} from '@/components/ui/sheet';
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip';
import { CommandPalette } from '@/components/game/CommandPalette';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { formatMoney } from '@/lib/game/format';
import { useGameStore, type TabId } from '@/lib/store';
import { cn } from '@/lib/utils';
import { AcademyScreen } from '@/components/game/AcademyScreen';
import { AwardsScreen } from '@/components/game/AwardsScreen';
import { CareerOverScreen } from '@/components/game/CareerOverScreen';
import { CoachScreen } from '@/components/game/CoachScreen';
import { CupScreen } from '@/components/game/CupScreen';
import { DashboardScreen } from '@/components/game/DashboardScreen';
import { EuroScreen } from '@/components/game/EuroScreen';
import { FinancesScreen } from '@/components/game/FinancesScreen';
import { LeagueScreen } from '@/components/game/LeagueScreen';
import { MatchScreen } from '@/components/game/MatchScreen';
import { MediaScreen } from '@/components/game/MediaScreen';
import { SquadScreen } from '@/components/game/SquadScreen';
import { TacticsScreen } from '@/components/game/TacticsScreen';
import { TerritoryScreen } from '@/components/game/TerritoryScreen';
import { TrainingScreen } from '@/components/game/TrainingScreen';
import { TransfersScreen } from '@/components/game/TransfersScreen';
import { SeasonCeremony } from '@/components/game/SeasonCeremony';

/** Карточка раздела в дереве навигации. */
type TabDef = { id: TabId; label: string; icon: typeof LayoutDashboard };
/** Группа разделов — FM-паттерн «сайдбар по секциям клуба». */
type NavGroup = { title: string; tabs: TabDef[] };

const NAV_GROUPS: NavGroup[] = [
  {
    title: 'Обзор',
    tabs: [
      { id: 'dashboard', label: 'Дашборд', icon: LayoutDashboard },
      { id: 'match', label: 'Матч', icon: PlayCircle },
      { id: 'media', label: 'Медиа', icon: Newspaper },
    ],
  },
  {
    title: 'Команда',
    tabs: [
      { id: 'squad', label: 'Состав', icon: Users },
      { id: 'tactics', label: 'Тактика', icon: ClipboardList },
      { id: 'training', label: 'Тренировки', icon: Dumbbell },
      { id: 'academy', label: 'Академия', icon: GraduationCap },
    ],
  },
  {
    title: 'Соревнования',
    tabs: [
      { id: 'league', label: 'Лига', icon: Table2 },
      { id: 'cup', label: 'Кубок', icon: Trophy },
      { id: 'euro', label: 'Европа', icon: Globe },
      { id: 'awards', label: 'Награды', icon: Medal },
    ],
  },
  {
    title: 'Клуб',
    tabs: [
      { id: 'transfers', label: 'Трансферы', icon: ArrowLeftRight },
      { id: 'finances', label: 'Финансы', icon: Wallet },
      { id: 'territory', label: 'Территория', icon: Building2 },
    ],
  },
  {
    title: 'Менеджер',
    tabs: [{ id: 'coach', label: 'Тренер', icon: UserRound }],
  },
];

const ALL_TABS: TabDef[] = NAV_GROUPS.flatMap((g) => g.tabs);

/** Главные табы нижнего бара (мобайл): + «Ещё…» со всеми секциями. */
const MOBILE_TABS: TabDef[] = ALL_TABS.filter((t) =>
  ['dashboard', 'squad', 'match', 'league'].includes(t.id),
);

const SIDEBAR_KEY = 'fm.sidebarCollapsed';

/* Состояние сайдбара (свернут/развернут) — внешний стор в localStorage.
   useSyncExternalStore — реактовский канонический паттерн (без setState в effect). */
const sidebarListeners = new Set<() => void>();

function subscribeSidebar(cb: () => void): () => void {
  sidebarListeners.add(cb);
  return () => {
    sidebarListeners.delete(cb);
  };
}

function sidebarSnapshot(): boolean {
  try {
    return window.localStorage.getItem(SIDEBAR_KEY) === '1';
  } catch {
    return false;
  }
}

function sidebarServerSnapshot(): boolean {
  return false;
}

function writeSidebar(collapsed: boolean): void {
  try {
    window.localStorage.setItem(SIDEBAR_KEY, collapsed ? '1' : '0');
  } catch {
    /* private mode */
  }
  sidebarListeners.forEach((l) => l());
}

function ScreenSwitch({ tab }: { tab: TabId }) {
  switch (tab) {
    case 'dashboard':
      return <DashboardScreen />;
    case 'squad':
      return <SquadScreen />;
    case 'tactics':
      return <TacticsScreen />;
    case 'match':
      return <MatchScreen />;
    case 'media':
      return <MediaScreen />;
    case 'league':
      return <LeagueScreen />;
    case 'cup':
      return <CupScreen />;
    case 'euro':
      return <EuroScreen />;
    case 'training':
      return <TrainingScreen />;
    case 'academy':
      return <AcademyScreen />;
    case 'territory':
      return <TerritoryScreen />;
    case 'transfers':
      return <TransfersScreen />;
    case 'finances':
      return <FinancesScreen />;
    case 'coach':
      return <CoachScreen />;
    case 'awards':
      return <AwardsScreen />;
  }
}

/** Бейдж-индикатор количества (тревоги/уведомления) — FM-паттерн. */
function NavBadge({ count, tone }: { count: number; tone: 'danger' | 'warning' }) {
  if (count <= 0) return null;
  return (
    <span
      className={cn(
        'ml-auto rounded-full px-1.5 py-0.5 text-[10px] font-bold leading-none tabular',
        tone === 'danger'
          ? 'bg-[#EF4444]/15 text-[#EF4444]'
          : 'bg-[#EAB308]/15 text-[#EAB308]',
      )}
    >
      {count > 99 ? '99+' : count}
    </span>
  );
}

/** Пульсирующая точка «есть несыгранный матч» — как «Следующее действие» в FM. */
function MatchPendingDot() {
  return (
    <span className="relative ml-auto flex size-2" aria-hidden>
      <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-70" />
      <span className="relative inline-flex size-2 rounded-full bg-primary" />
    </span>
  );
}

/** Модуль 6: live-тикер счёта в топбаре — «ЗЕЛ 1:0 КРС · 67'». */
function LiveScoreTicker() {
  const lastMatch = useGameStore((s) => s.lastMatch);
  const liveMinute = useGameStore((s) => s.liveMinute);
  const liveMatchIndex = useGameStore((s) => s.liveMatchIndex);
  if (!lastMatch) return null;
  const userMatches = lastMatch.userMatches;
  const m = userMatches[Math.min(liveMatchIndex, Math.max(0, userMatches.length - 1))];
  if (!m) return null;
  const hg = m.events.filter((e) => (e.type === 'goal' || e.type === 'pen_goal') && e.minute <= liveMinute && e.teamId === m.home.id).length;
  const ag = m.events.filter((e) => (e.type === 'goal' || e.type === 'pen_goal') && e.minute <= liveMinute && e.teamId === m.away.id).length;
  return (
    <Badge
      className="h-9 gap-1.5 border border-[#22C55E]/40 bg-[#22C55E]/10 px-2.5 text-[11px] font-bold tabular text-[#22C55E]"
      title={`${m.home.name} — ${m.away.name}: трансляция идёт`}
    >
      <span className="relative flex size-1.5" aria-hidden>
        <span className="absolute inline-flex size-full animate-ping rounded-full bg-[#22C55E] opacity-75" />
        <span className="relative inline-flex size-1.5 rounded-full bg-[#22C55E]" />
      </span>
      {m.home.shortName} {hg}:{ag} {m.away.shortName}
      <span className="text-[#22C55E]/70">{liveMinute}&apos;</span>
    </Badge>
  );
}

/** Десктопный сайдбар: секции «Обзор/Команда/Соревнования/Клуб/Менеджер»,
 *  бейджи (травмы, контракты), сворачивание в иконочный рельс. */
function SidebarNav({
  collapsed,
  onToggleCollapse,
  disabled,
}: {
  collapsed: boolean;
  onToggleCollapse: () => void;
  disabled: boolean;
}) {
  const activeTab = useGameStore((s) => s.activeTab);
  const setTab = useGameStore((s) => s.setTab);
  const snapshot = useGameStore((s) => s.snapshot)!;
  const matchView = useGameStore((s) => s.matchView);

  const injuredCount = snapshot.myPlayers.filter((p) => p.injuryWeeks > 0).length;
  const expiringCount = snapshot.contractsExpiring.length;
  const matchPending = matchView === 'prematch' && !!snapshot.nextMatch;

  const badgeFor = (id: TabId) => {
    if (id === 'squad') return <NavBadge count={injuredCount} tone="danger" />;
    if (id === 'transfers') return <NavBadge count={expiringCount} tone="warning" />;
    if (id === 'match' && matchPending) return <MatchPendingDot />;
    return null;
  };

  return (
    <TooltipProvider delayDuration={0}>
      <nav
        aria-label="Разделы игры"
        className={cn(
          'flex h-full flex-col overflow-y-auto transition-[width] duration-200',
          collapsed ? 'w-[64px]' : 'w-60',
        )}
      >
        <div className={cn('flex-1 py-3', collapsed ? 'px-2' : 'px-3')}>
          {NAV_GROUPS.map((group) => (
            <div key={group.title} className="mb-1">
              {collapsed ? (
                <div className="mx-2 my-2 h-px bg-border/60" aria-hidden />
              ) : (
                <p className="px-3 pb-1 pt-3 text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground/70">
                  {group.title}
                </p>
              )}
              {group.tabs.map((t) => {
                const active = activeTab === t.id;
                const badge = collapsed ? null : badgeFor(t.id);
                const item = (
                  <button
                    key={t.id}
                    type="button"
                    disabled={disabled}
                    onClick={() => setTab(t.id)}
                    aria-current={active ? 'page' : undefined}
                    aria-label={t.label}
                    title={t.label}
                    className={cn(
                      'mb-0.5 flex w-full items-center gap-2.5 rounded-md border-l-2 py-2 text-[13px] font-medium transition-colors',
                      collapsed
                        ? cn(
                            'justify-center border-transparent px-0 size-10',
                            active
                              ? 'bg-primary/15 text-primary'
                              : 'text-muted-foreground hover:bg-secondary/60 hover:text-foreground',
                          )
                        : cn(
                            'border-transparent px-3',
                            active
                              ? 'border-primary bg-primary/15 text-primary'
                              : 'text-muted-foreground hover:bg-secondary/60 hover:text-foreground',
                          ),
                      disabled && 'cursor-not-allowed opacity-50',
                    )}
                  >
                    <t.icon className="size-4 shrink-0" aria-hidden />
                    {!collapsed ? (
                      <>
                        <span className="truncate">{t.label}</span>
                        {badge}
                      </>
                    ) : null}
                  </button>
                );
                return collapsed ? (
                  <Tooltip key={t.id}>
                    <TooltipTrigger asChild>{item}</TooltipTrigger>
                    <TooltipContent side="right" sideOffset={8}>
                      {t.label}
                      {t.id === 'squad' && injuredCount > 0 ? ` · травмы: ${injuredCount}` : ''}
                      {t.id === 'transfers' && expiringCount > 0
                        ? ` · контракты: ${expiringCount}`
                        : ''}
                    </TooltipContent>
                  </Tooltip>
                ) : (
                  item
                );
              })}
            </div>
          ))}
        </div>

        {/* Сворачивание сайдбара */}
        <div className="sticky bottom-0 mt-auto border-t border-border/60 bg-background/95 p-2 backdrop-blur">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleCollapse}
            className="w-full min-h-9 justify-center text-muted-foreground hover:text-foreground"
            aria-label={collapsed ? 'Развернуть меню' : 'Свернуть меню'}
            title={collapsed ? 'Развернуть меню' : 'Свернуть меню'}
          >
            {collapsed ? (
              <PanelLeftOpen className="size-4" aria-hidden />
            ) : (
              <>
                <PanelLeftClose className="size-4" aria-hidden />
                <span className="text-[11px]">Свернуть</span>
              </>
            )}
          </Button>
        </div>
      </nav>
    </TooltipProvider>
  );
}

/** Лист «Ещё…» (мобайл): все разделы, сгруппированные по секциям клуба. */
function MoreSheet({
  active,
  onSelect,
  disabled,
}: {
  active: TabId;
  onSelect: (t: TabId) => void;
  disabled: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          type="button"
          disabled={disabled}
          className={cn(
            'flex min-h-[56px] flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium',
            !MOBILE_TABS.some((m) => m.id === active) ? 'text-primary' : 'text-muted-foreground',
          )}
          aria-label="Ещё — остальные разделы игры"
        >
          <MoreHorizontal className="size-5" aria-hidden />
          Ещё…
        </button>
      </SheetTrigger>
      <SheetContent side="bottom" className="pb-6">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 text-left">
            <ChevronUp className="size-4 text-primary" aria-hidden />
            Все разделы
          </SheetTitle>
          {/* Описание для скринридеров — также гасит Radix-предупреждение
              «Missing Description for SheetContent». */}
          <SheetDescription className="sr-only">
            Список всех разделов игры, сгруппированных по секциям: обзор, команда,
            соревнования, клуб и менеджер.
          </SheetDescription>
        </SheetHeader>
        <ScrollAreaColumns>
          {NAV_GROUPS.map((group) => (
            <div key={group.title} className="px-1">
              <p className="px-2 pb-1 text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground/70">
                {group.title}
              </p>
              <div className="grid grid-cols-3 gap-2">
                {group.tabs.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      onSelect(t.id);
                      setOpen(false);
                    }}
                    className={cn(
                      'flex min-h-[64px] flex-col items-center justify-center gap-1.5 rounded-lg border bg-secondary/50 p-2 text-xs font-medium transition-colors',
                      active === t.id
                        ? 'border-primary text-primary'
                        : 'border-border/60 text-muted-foreground hover:border-primary/40 hover:text-foreground',
                    )}
                  >
                    <t.icon className="size-4" aria-hidden />
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </ScrollAreaColumns>
      </SheetContent>
    </Sheet>
  );
}

/** Обёртка-«хелпер» листа: колонки секций с прокруткой. */
function ScrollAreaColumns({ children }: { children: React.ReactNode }) {
  return <div className="max-h-[70vh] space-y-3 overflow-y-auto px-4">{children}</div>;
}

/** Каркас игры (FM-стиль): топбар с «Продолжить», сайдбар-секции,
 *  контент, нижний мобильный бар. */
export function GameShell() {
  const activeTab = useGameStore((s) => s.activeTab);
  const setTab = useGameStore((s) => s.setTab);
  const snapshot = useGameStore((s) => s.snapshot);
  const exitToCareers = useGameStore((s) => s.exitToCareers);
  const matchView = useGameStore((s) => s.matchView);
  const playWeek = useGameStore((s) => s.playWeek);
  const loading = useGameStore((s) => s.loading);

  // Состояние сайдбара (свернут/развернут) — в localStorage.
  const collapsed = useSyncExternalStore(
    subscribeSidebar,
    sidebarSnapshot,
    sidebarServerSnapshot,
  );
  const toggleCollapse = () => writeSidebar(!collapsed);

  if (!snapshot) return null;
  const { save, myTeam } = snapshot;
  const isCupWeek = save.weekInfo.type === 'cup';
  // Фаза 4: евронеделя (двойная неделя) — золотой акцент престижа в хедере.
  const isEuroWeek = save.weekInfo.label.includes('Кубок Европы');
  // Карьера завершена (увольнение): вкладки блокируются, поверх — CareerOverScreen.
  const finished = save.status === 'finished';
  const warnLevel = snapshot.board.warnLevel;

  // ── Кнопка «Продолжить» (FM-паттерн): ведёт к матчу, затем играет неделю ──
  const matchPending = matchView === 'prematch' && !!snapshot.nextMatch;
  const continueDisabled = finished || loading || matchView !== 'prematch';
  const continueLabel =
    matchView === 'live'
      ? 'Матч идёт…'
      : matchView === 'result'
        ? 'Итоги недели'
        : matchView === 'ceremony'
          ? 'Церемония'
          : activeTab !== 'match'
            ? 'К матчу'
            : snapshot.nextMatch
              ? 'Играть матч'
              : 'Симулировать неделю';
  const onContinue = () => {
    if (matchView !== 'prematch') return;
    if (activeTab !== 'match') {
      setTab('match');
      return;
    }
    void playWeek();
  };

  return (
    <div className={cn('game-shell flex min-h-screen flex-col bg-background cyber-grid', `game-shell--${activeTab}`)}>
      {/* ── Топбар: клуб · неделя · баланс · «Продолжить» · выход ── */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/85">
        <div className="flex h-16 items-center gap-2 px-3 sm:gap-3 sm:px-4">
          {/* Клуб + менеджер */}
          <div className="flex min-w-0 shrink items-center gap-2.5">
            <TeamCrest
              shortName={myTeam.shortName}
              colorPrimary={myTeam.colorPrimary}
              colorSecondary={myTeam.colorSecondary}
              size="md"
            />
            <div className="min-w-0 leading-tight">
              <span className="block truncate text-sm font-bold">{myTeam.name}</span>
              <span className="hidden truncate text-[10px] text-muted-foreground sm:block">
                {save.managerName} · {save.league.nameRu}
              </span>
            </div>
          </div>

          {/* Недостаток места — логотип-миниатюра по центру (десктоп) */}
          <div className="mx-2 hidden items-baseline gap-1 font-black tracking-tight md:flex">
            <span className="neon-text text-sm text-primary">NEXUS FM</span>
            <span className="text-xs font-bold text-[#FF6B35]">2046</span>
            <span className="ml-1 rounded border border-[#A78BFA]/30 bg-[#A78BFA]/10 px-1.5 py-0.5 text-[8px] font-bold tracking-[0.12em] text-[#A78BFA]">SEASON UPDATE</span>
          </div>

          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            {/* Модуль 6: командная палитра Ctrl+K (десктоп) */}
            <CommandPalette disabled={finished} />
            {/* Модуль 6: live-тикер счёта во время трансляции */}
            {matchView === 'live' ? <LiveScoreTicker /> : null}
            {/* Индикатор недовольства правления (Фаза 3) */}
            {warnLevel !== 'none' ? (
              <span
                className="relative flex size-2 shrink-0"
                role="status"
                title={
                  warnLevel === 'ultimatum'
                    ? 'Правление: ультиматум — исправьте ситуацию!'
                    : 'Правление недовольно результатами'
                }
                aria-label="Правление недовольно"
              >
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-[#EF4444] opacity-60" />
                <span className="relative inline-flex size-2 rounded-full bg-[#EF4444]" />
              </span>
            ) : null}
            {/* Индикатор недели */}
            <Badge
              variant="outline"
              className={cn(
                'hidden shrink-0 text-[11px] tabular sm:inline-flex',
                isEuroWeek
                  ? 'border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#D4AF37]'
                  : isCupWeek && 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]',
              )}
              title={isEuroWeek ? 'Кубок Европы' : isCupWeek ? save.league.cupName : save.league.nameRu}
            >
              {isEuroWeek ? <Globe className="size-3" aria-hidden /> : null}
              {save.weekInfo.label}
            </Badge>
            <Badge variant="outline" className="hidden text-[11px] tabular xl:inline-flex">
              Сезон {save.season}
            </Badge>
            <Badge
              variant="secondary"
              className={cn(
                'tabular text-[11px]',
                save.balance < 0 && 'border border-[#EF4444]/40 text-[#EF4444]',
              )}
              title="Баланс клуба"
            >
              {formatMoney(save.balance)}
            </Badge>

            {/* ── «Продолжить»: главный прогресс-экшен недели ── */}
            <Button
              onClick={onContinue}
              disabled={continueDisabled}
              className={cn(
                'h-10 gap-2 px-3 font-bold sm:px-4',
                !continueDisabled &&
                  'bg-primary text-primary-foreground shadow-[0_0_24px_rgba(0,212,255,0.35)] hover:bg-primary/90 hover:shadow-[0_0_32px_rgba(0,212,255,0.5)]',
                continueDisabled && 'opacity-60',
              )}
              title={
                continueDisabled
                  ? 'Завершите просмотр результата недели'
                  : activeTab !== 'match'
                    ? 'Перейти к экрану матча'
                    : snapshot.nextMatch
                      ? 'Сыграть матч этой недели'
                      : 'Симулировать неделю'
              }
            >
              {loading ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <PlayCircle className="size-4" aria-hidden />
              )}
              <span className="hidden md:inline">{continueLabel}</span>
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="size-9 shrink-0 text-muted-foreground hover:text-foreground"
              onClick={exitToCareers}
              aria-label="Выйти к списку карьер"
              title="Мои карьеры"
            >
              <LogOut className="size-4" aria-hidden />
            </Button>
          </div>
        </div>
      </header>

      {/* ── Сайдбар + контент ── */}
      <div className="flex flex-1">
        <aside
          className={cn(
            'sticky top-16 hidden h-[calc(100vh-4rem)] shrink-0 border-r border-border/60 bg-background/60 lg:flex',
          )}
        >
          <SidebarNav
            collapsed={collapsed}
            onToggleCollapse={toggleCollapse}
            disabled={finished}
          />
        </aside>

        <main className="game-content-stage relative mx-auto w-full max-w-7xl flex-1 p-4 pb-28 lg:pb-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <ScreenSwitch tab={activeTab} />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* ── Нижний таб-бар — только mobile/tablet ── */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-border/60 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/85 lg:hidden"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        aria-label="Основная навигация"
      >
        <div className="mx-auto flex max-w-md items-stretch">
          {MOBILE_TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              disabled={finished}
              onClick={() => setTab(t.id)}
              className={cn(
                'relative flex min-h-[56px] flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors',
                activeTab === t.id ? 'text-primary' : 'text-muted-foreground',
              )}
              aria-current={activeTab === t.id ? 'page' : undefined}
            >
              <t.icon className="size-5" aria-hidden />
              {t.label}
              {t.id === 'match' && matchPending ? (
                <span className="absolute right-1/2 top-1.5 mr-[-14px] flex size-2" aria-hidden>
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-70" />
                  <span className="relative inline-flex size-2 rounded-full bg-primary" />
                </span>
              ) : null}
            </button>
          ))}
          <MoreSheet active={activeTab} onSelect={setTab} disabled={finished} />
        </div>
      </nav>

      {/* ── Церемония наград по итогам сезона ── */}
      {matchView === 'ceremony' ? <SeasonCeremony /> : null}

      {/* ── Фаза 3: карьера завершена (увольнение) — поверх контента,
          но не поверх экрана результата недели/церемонии (§7.5) ── */}
      {finished && matchView === 'prematch' ? <CareerOverScreen /> : null}
    </div>
  );
}

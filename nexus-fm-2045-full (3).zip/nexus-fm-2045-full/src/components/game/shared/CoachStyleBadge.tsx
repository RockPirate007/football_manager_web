'use client';

import { Bus, ChevronsUp, CircleDot, Minus, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AI_STYLES } from '@/lib/game/constants';
import type { AiStyleCode } from '@/lib/game/types';
import { cn } from '@/lib/utils';

/** Иконка стиля ИИ-тренера (§7.2 ТЗ Фазы 4): гегенпресс ⬆ / тики-така ◯ / автобус / вертикальный ⚡ / сбалансированный —. */
const STYLE_ICONS: Record<AiStyleCode, typeof Bus> = {
  gegenpress: ChevronsUp,
  tikitaka: CircleDot,
  bus: Bus,
  vertical: Zap,
  balanced: Minus,
};

/** Компактный бейдж стиля соперника (тёмная тема, outline) с hint-подсказкой. */
export function CoachStyleBadge({
  style,
  className,
}: {
  style: AiStyleCode | null | undefined;
  className?: string;
}) {
  if (!style) return null;
  const def = AI_STYLES[style];
  const Icon = STYLE_ICONS[style] ?? Minus;
  return (
    <Badge
      variant="outline"
      className={cn('gap-1 border-border/70 bg-secondary/40 text-[10px] font-medium text-muted-foreground', className)}
      title={def.hint}
    >
      <Icon className="size-3" aria-hidden />
      {def.label}
    </Badge>
  );
}

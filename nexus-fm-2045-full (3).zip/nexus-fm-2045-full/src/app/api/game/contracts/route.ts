import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolveSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import {
  bosmanProbability, bosmanRiskOf, maxRenewYears, renewDemand, teamAppsOf,
  yearsLeftOf,
} from '@/lib/game/contracts';
import { ApiGameError } from '@/lib/game/error';
import type { PlayerLike } from '@/lib/game/players';
import type { ContractInfoDTO, ContractsResponse } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/contracts?saveId= — контракты состава клуба игрока (Фаза 3, §6.1).
 * Сортировка: yearsLeft asc, затем OVR desc. Без saveId (легаси) — последний
 * открытый активный сейв. finished-сейвы (уволен) доступны для просмотра —
 * как в GET /state (§6.3).
 */
export async function GET(request: Request) {
  try {
    const save = await resolveSave(saveIdFromQuery(request));
    if (!save.teamId) return fail('SAVE_NOT_FOUND', 404);

    const squadRows = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
      orderBy: [{ ovr: 'desc' }],
    });
    const squad = squadRows as unknown as PlayerLike[];
    const teamApps = teamAppsOf(squad);

    const contracts: ContractInfoDTO[] = squad
      .map((p) => {
        const yearsLeft = yearsLeftOf(p.contractUntil, save.season);
        const preContract = p.preContractTeamId !== null;
        const renewable = yearsLeft <= 2 && !preContract;
        // риск Босмана имеет смысл только в последний год контракта
        const bosmanRisk = yearsLeft <= 1
          ? bosmanRiskOf(bosmanProbability({ player: p, teamApps }))
          : 'low';
        return {
          playerId: p.id,
          name: `${p.firstName} ${p.lastName}`,
          position: p.position,
          age: p.age,
          ovr: p.ovr,
          value: p.value,
          salary: p.salary,
          contractUntil: p.contractUntil,
          yearsLeft,
          renewable,
          demand: renewable ? renewDemand({ player: p, squad, teamApps }) : null,
          maxRenewYears: maxRenewYears(p.age),
          preContract,
          bosmanRisk,
        } satisfies ContractInfoDTO;
      })
      .sort((a, b) => a.yearsLeft - b.yearsLeft || b.ovr - a.ovr);

    const response: ContractsResponse = { ok: true, season: save.season, contracts };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/contracts]', error);
    return fail('UNKNOWN', 500);
  }
}

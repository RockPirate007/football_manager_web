import { cn } from '@/lib/utils';

const SIZES: Record<string, string> = {
  sm: 'size-7 text-[10px]',
  md: 'size-9 text-xs',
  lg: 'size-12 text-sm',
};

/** Мини-герб клуба: круг цвета клуба + короткое имя. */
export function TeamCrest({
  shortName,
  colorPrimary,
  colorSecondary,
  size = 'md',
  className,
  title,
}: {
  shortName: string;
  colorPrimary: string;
  colorSecondary: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  title?: string;
}) {
  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center justify-center rounded-full border-2 font-bold leading-none',
        SIZES[size],
        className,
      )}
      style={{
        backgroundColor: colorPrimary,
        color: colorSecondary,
        borderColor: colorSecondary,
      }}
      role="img"
      aria-label={title ?? shortName}
      title={title ?? shortName}
    >
      {shortName.slice(0, 3)}
    </span>
  );
}

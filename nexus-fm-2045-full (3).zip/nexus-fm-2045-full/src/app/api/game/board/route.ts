import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolveSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { boardDtoOf } from '@/lib/game/snapshot';
import type { BoardResponse, NewsDTO } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/board?saveId= — панель «Правление» (Фаза 3, §6.1): цель сезона,
 * confidence, статус должности + последние 10 новостей типа 'board'.
 * Без saveId (легаси) — последний открытый активный сейв.
 */
export async function GET(request: Request) {
  try {
    const save = await resolveSave(saveIdFromQuery(request));
    if (!save.teamId) return fail('SAVE_NOT_FOUND', 404);

    const teams = await db.team.findMany({
      where: { saveId: save.id },
      select: { id: true, strength: true },
    });
    const teamCount = teams.length;

    const newsRows = await db.newsItem.findMany({
      where: { saveId: save.id, type: 'board' },
      orderBy: [{ season: 'desc' }, { week: 'desc' }, { createdAt: 'desc' }],
      take: 10,
    });
    const news: NewsDTO[] = newsRows.map((n) => ({
      id: n.id,
      season: n.season,
      week: n.week,
      type: n.type as NewsDTO['type'],
      message: n.message,
    }));

    const board = boardDtoOf(save, teamCount, teams);
    const response: BoardResponse = { ok: true, board, news };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/board]', error);
    return fail('UNKNOWN', 500);
  }
}

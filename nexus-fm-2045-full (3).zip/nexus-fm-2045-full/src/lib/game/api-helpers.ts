/**
 * Серверные хелперы API-роутов: доступ к сейву по saveId и карточки карьер.
 * §6.3 architecture-upgrade.md (Фаза 2). Легаси-клиент Фазы 1 (запросы без
 * saveId) адресуется к последнему открытому активному сейву — до прихода
 * нового фронтенда приложение не падает.
 */

import { db } from '@/lib/db';
import type { GameSave, Team as TeamModel } from '@prisma/client';
import { buildSeasonPlan, weekLabelOf } from './calendar';
import { EURO_QUOTAS, EURO_ROUNDS, coerceAiStyle } from './constants';
import { euroRoundLabel, euroWeeksOf, parseEuroTeamIds } from './euro';
import { ApiGameError } from './error';
import { LEAGUES, leagueByCode } from './leagues';
import { computeStandings, type StandingMatchInput, type StandingTeamInput } from './standings';
import { parseMatchPlan } from './types';
import type {
  EuroMatchDTO, EuroRoundDTO, EuroSnapshotDTO, EuroTeamDTO, MatchPlanDTO, SaveCardDTO,
} from './types';

/** Сейв в состоянии «идёт карьера» (status active + клуб выбран). */
export interface PlayingSave extends GameSave {
  teamId: string;
}

/** saveId из query-параметров GET-роутов. */
export function saveIdFromQuery(request: Request): string | null {
  const { searchParams } = new URL(request.url);
  const raw = searchParams.get('saveId') ?? searchParams.get('save');
  const value = raw?.trim();
  return value ? value : null;
}

/** Сейв по id; 404 SAVE_NOT_FOUND, если не существует. */
export async function requireSave(saveId: string): Promise<GameSave> {
  const save = await db.gameSave.findUnique({ where: { id: saveId } });
  if (!save) throw new ApiGameError('SAVE_NOT_FOUND', 404);
  return save;
}

/** Последний открытый активный сейв (легаси-режим Фазы 1 — без saveId). */
export async function legacyActiveSave(): Promise<GameSave | null> {
  return db.gameSave.findFirst({
    where: { status: 'active' },
    orderBy: [{ lastOpenedAt: 'desc' }, { createdAt: 'desc' }],
  });
}

/**
 * Резолв сейва: явный saveId → строго findUnique по нему (404 при отсутствии);
 * null → легаси-фолбэк (последний открытый активный сейв).
 */
export async function resolveSave(saveId: string | null): Promise<GameSave> {
  if (saveId) return requireSave(saveId);
  const legacy = await legacyActiveSave();
  if (!legacy) throw new ApiGameError('SAVE_NOT_FOUND', 404);
  return legacy;
}

/** Резолв ИГРАЮЩЕГО сейва (status active и клуб выбран). */
export async function resolvePlayingSave(saveId: string | null): Promise<PlayingSave> {
  const save = await resolveSave(saveId);
  if (save.status !== 'active' || !save.teamId) {
    throw new ApiGameError('SAVE_NOT_FOUND', 404);
  }
  return save as PlayingSave;
}

/** Нормализация кода ошибки для ответов: NO_SAVE (Фаза 1) → SAVE_NOT_FOUND. */
export function normalizeErrorCode(code: string): string {
  return code === 'NO_SAVE' ? 'SAVE_NOT_FOUND' : code;
}

/**
 * Карточка карьеры для GET /saves: место и форма — по ЛИГОВЫМ матчам
 * текущего сезона (competition='league'), метка недели — по плану сезона.
 * null для сейва без клуба (легаси setup) или с неизвестной лигой.
 */
export async function buildSaveCard(save: GameSave): Promise<SaveCardDTO | null> {
  const def = leagueByCode(save.leagueCode);
  if (!def || !save.teamId) return null;
  const plan = buildSeasonPlan(def.code);

  const teams = await db.team.findMany({ where: { saveId: save.id, isEuroGuest: false } });
  const club = teams.find((t) => t.id === save.teamId);
  if (!club) return null;

  const playedLeague = await db.match.findMany({
    where: { saveId: save.id, season: save.season, status: 'played', competition: 'league' },
    select: { homeTeamId: true, awayTeamId: true, homeGoals: true, awayGoals: true, week: true },
  });
  const teamInputs: StandingTeamInput[] = teams.map((t) => ({
    id: t.id,
    name: t.name,
    shortName: t.shortName,
    colorPrimary: t.colorPrimary,
    colorSecondary: t.colorSecondary,
    isUser: t.isUserTeam,
  }));
  const matchInputs: StandingMatchInput[] = playedLeague
    .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
    .map((m) => ({
      homeTeamId: m.homeTeamId,
      awayTeamId: m.awayTeamId,
      homeGoals: m.homeGoals as number,
      awayGoals: m.awayGoals as number,
      week: m.week,
    }));
  const standings = computeStandings(teamInputs, matchInputs);
  const myRow = standings.find((r) => r.teamId === save.teamId);

  const week = Math.min(Math.max(save.week, 1), plan.totalWeeks);

  return {
    id: save.id,
    careerName: save.careerName ?? `${club.name} · Сезон ${save.season}`,
    managerName: save.managerName,
    leagueCode: def.code,
    leagueName: def.nameRu,
    leagueFlag: def.flag,
    teamCount: def.teamCount,
    clubName: club.name,
    clubShort: club.shortName,
    colorPrimary: club.colorPrimary,
    colorSecondary: club.colorSecondary,
    season: save.season,
    week: save.week,
    totalWeeks: plan.totalWeeks,
    weekLabel: weekLabelOf(plan, week),
    place: myRow?.place ?? def.teamCount,
    form: myRow?.form ?? [],
    status: save.status,
    lastOpenedAt: save.lastOpenedAt ? save.lastOpenedAt.toISOString() : null,
    updatedAt: save.updatedAt.toISOString(),
  };
}

/** Карточки всех карьер, отсортированные по lastOpenedAt desc (GET /saves). */
export async function buildSaveCards(): Promise<SaveCardDTO[]> {
  const saves = await db.gameSave.findMany({
    orderBy: [{ lastOpenedAt: 'desc' }, { createdAt: 'desc' }],
  });
  const cards: SaveCardDTO[] = [];
  for (const save of saves) {
    const card = await buildSaveCard(save);
    if (card) cards.push(card);
  }
  return cards;
}

// ── Фаза 4: план на матч и Кубок Европы (§6.1 architecture-phase4.md) ──────

/** Текущий план на матч клуба игрока (Team.matchPlan → MatchPlanDTO; null → дефолт). */
export async function matchPlanOf(save: PlayingSave): Promise<MatchPlanDTO> {
  const team = await db.team.findUnique({
    where: { id: save.teamId },
    select: { matchPlan: true },
  });
  return parseMatchPlan(team?.matchPlan ?? null);
}

/** Карточка участника Кубка Европы (лига — по Team.leagueCode, дефолт — лига сейва). */
function toEuroTeam(team: TeamModel, saveLeagueCode: string): EuroTeamDTO {
  const code = (team.leagueCode ?? saveLeagueCode) as EuroTeamDTO['leagueCode'];
  const def = leagueByCode(code);
  return {
    id: team.id,
    name: team.name,
    shortName: team.shortName,
    leagueCode: code,
    leagueFlag: def?.flag ?? '🌍',
    leagueName: def?.nameRu ?? code,
    colorPrimary: team.colorPrimary,
    colorSecondary: team.colorSecondary,
    strength: team.strength,
    isUser: team.isUserTeam,
    isGuest: team.isEuroGuest,
    coachStyle: team.isUserTeam ? null : coerceAiStyle(team.aiStyle),
    coachName: team.isUserTeam ? null : team.aiCoachName,
  };
}

/**
 * Снапшот Кубка Европы (GET /api/game/euro, §6.1 ТЗ): состояние — по полям
 * GameSave (euroSeason/euroRound/euroAliveTeamIds/euroParticipants), сетка —
 * по Match competition='euro' сезона (cupRound = номер еврораунда 1..4);
 * участники — Team-строки (включая гостей). Ленивой инициализации здесь НЕТ —
 * состояние отражает только уже записанные week.ts данные.
 *
 * Статус клуба игрока: not_started — евро не инициализировано на этот сезон
 * (или клуб не среди участников — сетка/квоты всё равно отдаются); qualified —
 * участник, раундов ещё нет (euroRound=0); alive — жив; eliminated — вылет
 * (myEliminatedRound); winner — победитель финала.
 */
export async function buildEuroSnapshot(save: GameSave): Promise<EuroSnapshotDTO> {
  const plan = buildSeasonPlan(save.leagueCode);
  const euroWeeks = euroWeeksOf(plan.teamCount);
  const userTeamId = save.teamId ?? '';
  const started = save.euroSeason === save.season;

  const participantIds = started ? parseEuroTeamIds(save.euroParticipants) : [];
  const aliveIds = started ? parseEuroTeamIds(save.euroAliveTeamIds) : [];

  const euroMatchRows = started
    ? await db.match.findMany({
        where: { saveId: save.id, season: save.season, competition: 'euro' },
        orderBy: [{ cupRound: 'asc' }, { id: 'asc' }],
      })
    : [];

  const teamRows = participantIds.length > 0
    ? await db.team.findMany({ where: { saveId: save.id, id: { in: participantIds } } })
    : [];
  const teamById = new Map(teamRows.map((t) => [t.id, t]));

  // Сетка: ровно 4 раунда (1/8 → Финал)
  const rounds: EuroRoundDTO[] = [];
  for (let r = 1; r <= EURO_ROUNDS; r++) {
    const rows = euroMatchRows.filter((m) => m.cupRound === r);
    const matches: EuroMatchDTO[] = rows.map((m) => {
      const home = teamById.get(m.homeTeamId);
      const away = teamById.get(m.awayTeamId);
      return {
        id: m.id,
        home: home ? toEuroTeam(home, save.leagueCode) : null,
        away: away ? toEuroTeam(away, save.leagueCode) : null,
        homeGoals: m.homeGoals,
        awayGoals: m.awayGoals,
        homePens: m.homePens,
        awayPens: m.awayPens,
        winnerTeamId: m.winnerTeamId,
        played: m.status === 'played',
        isUserMatch: m.homeTeamId === userTeamId || m.awayTeamId === userTeamId,
        isNeutral: m.isNeutral,
      };
    });
    rounds.push({
      round: r,
      label: euroRoundLabel(r),
      week: euroWeeks[r - 1] ?? plan.totalWeeks,
      drawn: rows.length > 0,
      matches,
    });
  }

  // Статус клуба игрока (§6.1 ТЗ)
  const finalRow = euroMatchRows.find(
    (m) => m.cupRound === EURO_ROUNDS && m.status === 'played',
  ) ?? null;
  const myLosses = euroMatchRows.filter(
    (m) =>
      (m.homeTeamId === userTeamId || m.awayTeamId === userTeamId) &&
      m.status === 'played' &&
      m.winnerTeamId !== null &&
      m.winnerTeamId !== userTeamId,
  );
  const myEliminatedRound =
    myLosses.length > 0 ? Math.max(...myLosses.map((m) => m.cupRound ?? 0)) : null;
  const isWinner = !!finalRow && finalRow.winnerTeamId === userTeamId;
  const inParticipants = participantIds.includes(userTeamId);
  const isAlive = aliveIds.includes(userTeamId);

  let status: EuroSnapshotDTO['status'];
  if (!started) status = 'not_started';
  else if (isWinner) status = 'winner';
  else if (isAlive) status = save.euroRound > 0 ? 'alive' : 'qualified';
  else if (inParticipants) status = 'eliminated';
  else status = 'not_started'; // турнир идёт, но клуб не квалифицировался

  const currentRound = !started || participantIds.length === 0
    ? 0
    : Math.min(save.euroRound + 1, EURO_ROUNDS);

  // Следующий матч клуба: первая запланированная (не сыгранная) европара с его участием
  let nextEuroMatch: EuroSnapshotDTO['nextEuroMatch'] = null;
  if (isAlive) {
    const row = euroMatchRows.find(
      (m) =>
        m.status === 'scheduled' &&
        (m.homeTeamId === userTeamId || m.awayTeamId === userTeamId),
    );
    if (row) {
      const opponentId = row.homeTeamId === userTeamId ? row.awayTeamId : row.homeTeamId;
      const opponent = teamById.get(opponentId);
      const r = Math.min(Math.max(row.cupRound ?? 1, 1), EURO_ROUNDS);
      if (opponent) {
        nextEuroMatch = {
          round: r,
          label: euroRoundLabel(r),
          opponent: toEuroTeam(opponent, save.leagueCode),
          week: euroWeeks[r - 1] ?? plan.totalWeeks,
          isHome: row.homeTeamId === userTeamId,
        };
      }
    }
  }

  const participants: EuroTeamDTO[] = participantIds
    .map((id) => teamById.get(id))
    .filter((t): t is TeamModel => !!t)
    .map((t) => toEuroTeam(t, save.leagueCode));

  const quotas = LEAGUES.map((def) => ({
    code: def.code,
    flag: def.flag,
    quota: EURO_QUOTAS[def.code] ?? 0,
  }));

  return {
    status,
    currentRound,
    myEliminatedRound,
    rounds,
    participants,
    quotas,
    nextEuroMatch,
  };
}

/**
 * Календарь сезона: сквозные недели, типы недель (лига/кубок), CUP_WEEKS.
 * Фаза 2 (§3.1 architecture-upgrade.md). Чистый модуль, кеш планов по leagueCode.
 */

import { leagueByCode, type LeagueDef } from './leagues';
import type { LeagueCode } from './types';

/** Кубковые недели — константа (3 допустимых размера лиги, финал всегда последняя неделя). */
export const CUP_WEEKS: Record<number, number[]> = {
  16: [8, 16, 24, 34],
  18: [7, 15, 24, 32, 39],
  20: [8, 16, 26, 35, 43],
};

/** Fallback для гипотетического иного N: cupWeek(k) = floor(totalWeeks × k / (cupRounds+1)). */
function cupWeeksFor(teamCount: number): number[] {
  const leagueWeeks = (teamCount - 1) * 2;
  const cupRounds = teamCount <= 16 ? 4 : 5;
  const totalWeeks = leagueWeeks + cupRounds;
  const weeks: number[] = [];
  for (let k = 1; k <= cupRounds; k++) {
    const w = k === cupRounds ? totalWeeks : Math.floor((totalWeeks * k) / (cupRounds + 1));
    weeks.push(w);
  }
  // гарантия строгого возрастания и уникальности
  return weeks.filter((w, i) => w >= 1 && w <= totalWeeks && (i === 0 || w > weeks[i - 1]));
}

export interface WeekSlot {
  week: number; // 1..totalWeeks
  type: 'league' | 'cup';
  leagueRound?: number; // 1..(N−1)×2 (для type='league')
  cupRound?: number; // 1..cupRounds (для type='cup')
}

export interface SeasonPlan {
  leagueCode: LeagueCode;
  teamCount: number;
  leagueWeeks: number;
  cupRounds: number;
  totalWeeks: number;
  cupWeeks: number[];
  weeks: WeekSlot[]; // ровно totalWeeks записей
}

export const CUP_ROUND_LABELS: Record<number, string[]> = {
  16: ['1/8 финала', '1/4 финала', '1/2 финала', 'Финал'],
  18: ['Предварительный раунд', '1/8 финала', '1/4 финала', '1/2 финала', 'Финал'],
  20: ['Предварительный раунд', '1/8 финала', '1/4 финала', '1/2 финала', 'Финал'],
};

/** Название раунда кубка по размеру лиги и номеру раунда. */
export function cupRoundLabel(teamCount: number, round: number): string {
  const labels = CUP_ROUND_LABELS[teamCount] ?? CUP_ROUND_LABELS[16];
  return labels[Math.min(Math.max(round, 1), labels.length) - 1] ?? `Раунд ${round}`;
}

/** Число раундов кубка: N≤16 → 4, иначе 5. */
export function cupRoundsOf(teamCount: number): number {
  return teamCount <= 16 ? 4 : 5;
}

/** Кубковые недели для размера лиги (таблица + fallback). */
export function cupWeeksOf(teamCount: number): number[] {
  return CUP_WEEKS[teamCount] ?? cupWeeksFor(teamCount);
}

function buildPlan(def: LeagueDef): SeasonPlan {
  const cupWeeks = cupWeeksOf(def.teamCount);
  const cupRounds = cupRoundsOf(def.teamCount);
  const leagueWeeks = def.leagueWeeks;
  const totalWeeks = leagueWeeks + cupRounds;

  const weeks: WeekSlot[] = [];
  let leagueRound = 0;
  for (let w = 1; w <= totalWeeks; w++) {
    const cupIdx = cupWeeks.indexOf(w);
    if (cupIdx >= 0) {
      weeks.push({ week: w, type: 'cup', cupRound: cupIdx + 1 });
    } else {
      leagueRound++;
      weeks.push({ week: w, type: 'league', leagueRound });
    }
  }

  return {
    leagueCode: def.code,
    teamCount: def.teamCount,
    leagueWeeks,
    cupRounds,
    totalWeeks,
    cupWeeks,
    weeks,
  };
}

const planCache = new Map<string, SeasonPlan>();

/** План сезона по коду лиги — детерминированно, БЕЗ обращения к БД; кешируется. */
export function buildSeasonPlan(leagueCode: LeagueCode | string): SeasonPlan {
  const cached = planCache.get(leagueCode);
  if (cached) return cached;
  const def = leagueByCode(leagueCode);
  if (!def) throw new Error(`buildSeasonPlan: неизвестная лига ${leagueCode}`);
  const plan = buildPlan(def);
  planCache.set(leagueCode, plan);
  return plan;
}

/** Слот недели по её номеру (1..totalWeeks). */
export function weekSlotAt(plan: SeasonPlan, week: number): WeekSlot {
  const slot = plan.weeks[week - 1];
  if (!slot) throw new Error(`weekSlotAt: неделя ${week} вне плана (1..${plan.totalWeeks})`);
  return slot;
}

/** Сквозная неделя лигового тура (1..(N−1)×2 → 1..totalWeeks). */
export function leagueWeekOf(plan: SeasonPlan, leagueRound: number): number {
  const slot = plan.weeks.find((w) => w.type === 'league' && w.leagueRound === leagueRound);
  if (!slot) throw new Error(`leagueWeekOf: тур ${leagueRound} вне плана`);
  return slot.week;
}

/** Подпись недели для хедера: «Тур 12/38» | «Кубок · 1/4 финала» | «Кубок · Финал». */
export function weekLabelOf(plan: SeasonPlan, week: number): string {
  const slot = weekSlotAt(plan, week);
  if (slot.type === 'cup') {
    return `Кубок · ${cupRoundLabel(plan.teamCount, slot.cupRound as number)}`;
  }
  return `Тур ${slot.leagueRound}/${plan.leagueWeeks}`;
}

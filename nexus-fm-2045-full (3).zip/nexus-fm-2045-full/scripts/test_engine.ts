/**
 * P4-3-2 · Движок и разрезка progression — юнит-проверки (запуск: bun scripts/test_engine.ts).
 *
 * 1) ДЕТЕРМИНИЗМ сегментного движка: один и тот же seed → байт-в-байт одинаковые events.
 * 2) ИНВАРИАНТ РАЗРЕЗКИ applyPostMatch (§4.4): для недели с одним матчем без замен
 *    и без удалений/травм старая арифметика (переписана сюда дословно из Фазы 3)
 *    и новая пара applyMatchEffects + applyWeeklyRecovery дают идентичный результат
 *    при одинаковом RNG-сиде.
 * 3) МИНУТЫ: замена на 46' → стартёр 46 минут, вышедший 44, в сумме 90; apps и
 *    рейтинг — обоим; неиспользованный запас — без apps.
 * 4) САННИТИ СЕГМЕНТОВ: голы попадают в границы своих сегментов.
 */
import { applyMatchEffects, applyPostMatch, applyWeeklyRecovery } from '@/lib/game/progression';
import { simulateMatch, type MatchTeamInput } from '@/lib/game/match';
import { generateSquad, poolContextOf } from '@/lib/game/generate';
import { autoLineup } from '@/lib/game/players';
import { leagueByCode } from '@/lib/game/leagues';
import { mulberry32 } from '@/lib/game/rng';
import type { PlayerLike } from '@/lib/game/players';
import type { MatchEvent } from '@/lib/game/types';

let pass = 0;
let fail = 0;

function check(name: string, actual: unknown, expected: unknown): void {
  if (actual === expected) {
    pass += 1;
    console.log(`${name}=${actual}|ok`);
  } else {
    fail += 1;
    console.log(`${name}=${actual}|EXPECTED=${expected}|FAIL`);
  }
}

// ── Фикстуры ─────────────────────────────────────────────────────────────

const EPL = leagueByCode('EPL');
if (!EPL) throw new Error('EPL not found');
const EPL_POOL = poolContextOf(EPL);

function makeTeam(seed: number, strength: number): { players: PlayerLike[]; lineup: (string | null)[]; bench: string[] } {
  const rng = mulberry32(seed);
  const players = generateSquad(rng, strength, EPL_POOL);
  const auto = autoLineup(players, '4-4-2', false);
  return { players, lineup: auto.lineup, bench: auto.bench };
}

function tacticInput(t: { players: PlayerLike[]; lineup: (string | null)[]; bench: string[] }, teamId: string, name: string): MatchTeamInput {
  return {
    teamId,
    name,
    players: t.players,
    formation: '4-4-2',
    mentality: 'balanced',
    tempo: 'medium',
    pressing: 'medium',
    defLine: 'medium',
    playStyle: 'balanced',
    lineup: t.lineup,
    bench: t.bench,
  };
}

const home = makeTeam(1001, 75);
const away = makeTeam(2002, 75);

// ── 1) Детерминизм ───────────────────────────────────────────────────────

{
  const r1 = simulateMatch(mulberry32(42), tacticInput(home, 'H', 'Хозяева'), tacticInput(away, 'A', 'Гости'));
  const r2 = simulateMatch(mulberry32(42), tacticInput(home, 'H', 'Хозяева'), tacticInput(away, 'A', 'Гости'));
  check('determinism_events', JSON.stringify(r1.events) === JSON.stringify(r2.events) ? 'same' : 'diff', 'same');
  check('determinism_score', `${r1.homeGoals}:${r1.awayGoals}` === `${r2.homeGoals}:${r2.awayGoals}` ? 'same' : 'diff', 'same');
  const r3 = simulateMatch(mulberry32(43), tacticInput(home, 'H', 'Хозяева'), tacticInput(away, 'A', 'Гости'));
  check('determinism_other_seed_differs', JSON.stringify(r1.events) === JSON.stringify(r3.events) ? 'same' : 'diff', 'diff');
}

// ── 4) Сегменты: минуты голов в границах, subs ≤ 5, JSON-валидность полей ──

{
  const r = simulateMatch(mulberry32(7), tacticInput(home, 'H', 'Хозяева'), tacticInput(away, 'A', 'Гости'));
  const goalMinutes = r.events.filter((e) => e.type === 'goal').map((e) => e.minute);
  const inBounds = goalMinutes.every((m) => m >= 1 && m <= 93);
  check('goal_minutes_in_bounds', inBounds, true);
  const subsEvents = r.events.filter((e) => e.type === 'sub');
  const subsWellFormed = subsEvents.every(
    (e) => typeof e.subOutId === 'string' && typeof e.subOutName === 'string' && !!e.playerId && !!e.playerName,
  );
  check('sub_events_well_formed', subsWellFormed, true);
  check('subs_within_limit', r.homeSubs.length <= 5 && r.awaySubs.length <= 5, true);
  // Авторы голов — только те, кто на поле в эту минуту (spot-проверка через consistency: sub-out позже не автор до минуты)
  let ghosts = 0;
  const subOut = new Map<string, number>();
  for (const e of r.events) {
    if (e.type === 'sub' && e.subOutId) subOut.set(e.subOutId, e.minute);
    if (e.type === 'goal' && e.playerId) {
      const out = subOut.get(e.playerId);
      if (out !== undefined && out <= e.minute) ghosts += 1;
    }
  }
  check('no_ghost_goal_authors', ghosts, 0);
}

// ── 2) Инвариант разрезки (одиночный матч без замен/удалений/травм) ───────

{
  const players = home.players.map((p) => ({ ...p }));
  const starterIds = new Set(home.lineup.filter((x): x is string => !!x));
  const benchIds = new Set(home.bench);
  const scorer = home.lineup[10];
  const assist = home.lineup[5];
  const events: MatchEvent[] = [
    { minute: 30, type: 'goal', teamId: 'H', playerId: scorer ?? '', playerName: 'S', assistId: assist ?? undefined, text: 'ГОЛ' },
    { minute: 60, type: 'yellow', teamId: 'H', playerId: home.lineup[3] ?? '', playerName: 'Y', text: 'ЖК' },
  ];
  const base = {
    players,
    starterIds,
    benchIds,
    events,
    outcome: 'W' as const,
    tempo: 'medium' as const,
    pressing: 'medium' as const,
    competition: 'league' as const,
    goalsConceded: 0,
  };
  const injuries = new Map<string, number>([[home.lineup[8] ?? '', 3]]);

  // Старая арифметика Фазы 3 — дословно (drain полный, +8 всем, рейтинг стартёрам)
  const oldRun = base.players.map((p) => ({ ...p }));
  {
    const goalDelta = 15;
    for (const p of oldRun) {
      const isStarter = starterIds.has(p.id);
      const isBench = benchIds.has(p.id);
      if (isStarter) {
        const drain = Math.max(12, 22 - p.stamina / 12);
        p.condition = Math.min(100, Math.max(30, p.condition - drain));
        p.apps += 1;
      } else if (isBench) {
        p.condition = Math.min(100, Math.max(30, p.condition + 10));
      }
      p.condition = Math.min(100, Math.max(30, p.condition + 8));
      p.morale = Math.min(100, Math.max(5, p.morale + (isStarter ? goalDelta : Math.round(goalDelta / 2))));
      if (isStarter) {
        p.ratingApps += 1;
        p.ratingSum += 68; // любое детерминированное значение — обе стороны используют один rng-сид
      }
    }
  }

  // Новый путь: applyPostMatch (= applyMatchEffects + applyWeeklyRecovery)
  const newPlayers = base.players.map((p) => ({ ...p }));
  applyPostMatch({ ...base, players: newPlayers }, injuries, mulberry32(555));

  let mismatches = 0;
  for (let i = 0; i < oldRun.length; i++) {
    const a = oldRun[i];
    const b = newPlayers[i];
    if (a.condition !== b.condition || a.apps !== b.apps || a.morale !== b.morale || a.ratingApps !== b.ratingApps) {
      mismatches += 1;
    }
  }
  // Рейтинги зависят от rng — сверяем через повтор нового пути с тем же сидом:
  // старый блок выше ставит константу 68, поэтому сравниваем только СТРУКТУРУ
  // (ratingApps), а числовое совпадение рейтингов проверяем парой прогонов ниже.
  check('split_invariant_no_subs', mismatches, 0);

  const a1 = base.players.map((p) => ({ ...p }));
  const a2 = base.players.map((p) => ({ ...p }));
  applyPostMatch({ ...base, players: a1 }, new Map(), mulberry32(777));
  applyMatchEffects({ ...base, players: a2 }, new Map(), mulberry32(777));
  applyWeeklyRecovery(a2);
  const identical = a1.every((p, i) => p.ratingSum === a2[i].ratingSum && p.condition === a2[i].condition);
  check('wrapper_equals_split', identical, true);
}

// ── 3) Минуты замен ──────────────────────────────────────────────────────

{
  const players = home.players.map((p) => ({ ...p }));
  const starterIds = new Set(home.lineup.filter((x): x is string => !!x));
  const benchIds = new Set(home.bench);
  const outId = home.lineup[10] as string;
  const inId = home.bench[0];
  const events: MatchEvent[] = [
    { minute: 46, type: 'sub', teamId: 'H', playerId: inId, playerName: 'IN', subOutId: outId, subOutName: 'OUT', text: 'Замена' },
  ];
  const injuries = new Map<string, number>();

  const newPlayers = players.map((p) => ({ ...p }));
  applyMatchEffects(
    {
      players: newPlayers,
      starterIds,
      benchIds,
      events,
      outcome: 'D',
      tempo: 'medium',
      pressing: 'medium',
      competition: 'league',
      goalsConceded: null,
      subs: [{ outId, inId, minute: 46, reason: 'fatigue' }],
    },
    injuries,
    mulberry32(999),
  );

  const outP = newPlayers.find((p) => p.id === outId);
  const inP = newPlayers.find((p) => p.id === inId);
  check('sub_out_apps', outP?.apps ?? -1, 1);
  check('sub_in_apps', inP?.apps ?? -1, 1);
  check('sub_out_rating_apps', outP?.ratingApps ?? -1, 1);
  check('sub_in_rating_apps', inP?.ratingApps ?? -1, 1);

  // drain пропорционален минутам: стартёр 46/90, вышедший 44/90
  const outOrig = players.find((p) => p.id === outId);
  const inOrig = players.find((p) => p.id === inId);
  if (outP && inP && outOrig && inOrig) {
    const drainOut = (22 - outOrig.stamina / 12) * (46 / 90);
    const drainIn = (22 - inOrig.stamina / 12) * (44 / 90);
    const condOut = Math.min(100, Math.max(30, outOrig.condition - drainOut));
    const condIn = Math.min(100, Math.max(30, inOrig.condition - drainIn));
    check('sub_out_drain_minutes', Math.abs(outP.condition - condOut) < 1e-9, true);
    check('sub_in_drain_minutes', Math.abs(inP.condition - condIn) < 1e-9, true);
  }
  const unusedBench = newPlayers.find((p) => p.id === home.bench[1]);
  check('unused_bench_no_apps', unusedBench?.apps ?? -1, 0);
}

console.log(`\nPASS=${pass} FAIL=${fail}`);
process.exit(fail > 0 ? 1 : 0);

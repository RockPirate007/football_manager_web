/**
 * Модуль 3 smoke: скаутинг/туман войны, ИИ-менеджеры рынка, контрактные
 * переговоры, входящие офферы. Юниты чистых функций + интеграция через
 * router/db (как S-секции engine-smoke). Запуск: `bun scripts/m3_smoke.ts`.
 */

import { generatePlayer, type PlayerLike } from '@/lib/game/players';
import { mulberry32 } from '@/lib/game/rng';
import {
  knowledgeGrowthOf, knowledgeTierOf, potentialRangeOf, stepScoutReport,
  scoutSlotsOf, fogOfWar, scoutSeedOf,
} from '@/lib/game/scouting';
import {
  aiIncomingOfferOf, pickAiTransferTarget, squadNeedsOf, aiSigningSalaryOf,
} from '@/lib/game/ai-market';
import { evaluateSigningOffer, signingDemandOf, desiredYearsOf, roleForBuyer } from '@/lib/game/negotiation';
import { engineDispatch } from '@/engine/router';
import { getEngine } from '@/engine/index';
import { db } from '@/engine/db';

let pass = 0;
let fail = 0;
const failures: string[] = [];

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    pass += 1;
    console.log(`PASS ${name}`);
  } else {
    fail += 1;
    failures.push(name);
    const suffix = detail !== undefined ? ` :: ${detail}` : '';
    console.log(`FAIL ${name}${suffix}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  check(name, actual === expected, `actual=${String(actual)} expected=${String(expected)}`);
}

// патч uuid (как engine-smoke)
let uuidCounter = 0;
crypto.randomUUID = ((): string => {
  uuidCounter += 1;
  return `00000000-0000-4000-8000-${String(uuidCounter).padStart(12, '0')}`;
}) as typeof crypto.randomUUID;

const NOW = new Date('2025-07-01T12:00:00Z');

// ── U1: туман войны (scouting.ts) ──────────────────────────────────────────

console.log('\n== U1: скаутинг — туман войны ==');

eq('u1_tier_none', knowledgeTierOf(0), 'none');
eq('u1_tier_basic', knowledgeTierOf(25), 'basic');
eq('u1_tier_partial', knowledgeTierOf(55), 'partial');
eq('u1_tier_full', knowledgeTierOf(75), 'full');

// рост: watched → knowledge += growth, lastWeek = week
const grown = stepScoutReport({ knowledge: 10, lastWeek: 1, watched: true, week: 2, growth: 8.5 });
check('u1_growth_watched', grown.knowledge === 19 && grown.lastWeek === 2 && grown.alive,
  `k=${grown.knowledge}`);

// пауза: 26 недель — знания на месте; 27+ — деградация
const idle26 = stepScoutReport({ knowledge: 50, lastWeek: 1, watched: false, week: 27, growth: 8 });
eq('u1_decay_hold_26', idle26.knowledge, 50);
const idle30 = stepScoutReport({ knowledge: 50, lastWeek: 1, watched: false, week: 31, growth: 8 });
eq('u1_decay_after_26', idle30.knowledge, 48);
const dead = stepScoutReport({ knowledge: 2, lastWeek: 1, watched: false, week: 90, growth: 8 });
check('u1_report_dies_at_zero', !dead.alive, `alive=${dead.alive}`);

// рост знания от скаута
eq('u1_growth_no_scout', Math.round(knowledgeGrowthOf(null) * 10) / 10, 7.3);
check('u1_growth_scout85_gt_base', knowledgeGrowthOf(85) > knowledgeGrowthOf(45));

// слоты наблюдения
eq('u1_slots_base', scoutSlotsOf(0), 2);
eq('u1_slots_with_staff', scoutSlotsOf(3), 8);

// вилки потенциала
const rngP = mulberry32(42);
const p100 = generatePlayer(rngP, 60, 'ST', { minAge: 18, maxAge: 18 });
p100.potential = 85;
const [lo40, hi40] = potentialRangeOf(85, 60, 50);
check('u1_range_partial_band', hi40 - lo40 <= 12 && hi40 === 91, `${lo40}..${hi40}`);
const [lo70, hi70] = potentialRangeOf(85, 60, 75);
check('u1_range_full_tight', hi70 - lo70 === 4, `${lo70}..${hi70}`);
const [loB, hiB] = potentialRangeOf(85, 60, 10);
check('u1_range_basic_starts_ovr', loB === 60 && hiB === 97, `${loB}..${hiB}`);

// fogOfWar: детерминизм + уровни
const rngF1 = mulberry32(scoutSeedOf('save1', 'pl1', 5));
const rngF2 = mulberry32(scoutSeedOf('save1', 'pl1', 5));
const target = generatePlayer(mulberry32(7), 66, 'MC', { minAge: 24, maxAge: 24 });
const f1 = fogOfWar({ rng: rngF1, player: target, knowledge: 55 });
const f2 = fogOfWar({ rng: rngF2, player: target, knowledge: 55 });
check('u1_fog_deterministic', JSON.stringify(f1) === JSON.stringify(f2));
const fFull = fogOfWar({ rng: mulberry32(1), player: target, knowledge: 100 });
check('u1_fog_full_exact', fFull.ovr === target.ovr && fFull.attrs.passing === target.passing);
const fBasic = fogOfWar({ rng: mulberry32(2), player: target, knowledge: 10 });
check('u1_fog_basic_hidden', fBasic.attrs.passing === 0);
check('u1_fog_partial_noise', Math.abs(f1.ovr - target.ovr) <= 2, `ovr=${f1.ovr}`);

// ── U2: ИИ-менеджеры (ai-market.ts) ────────────────────────────────────────

console.log('\n== U2: ИИ-менеджеры рынка ==');

// состав с дырой в обороне
const mk = (ovr: number, pos: PlayerLike['position'], age = 26): PlayerLike => {
  const p = generatePlayer(mulberry32(ovr * 131 + pos.length), ovr, pos, { minAge: age, maxAge: age });
  p.ovr = ovr;
  return p;
};
// состав с дырой в обороне (запасной GK есть — вратарская линия не дефицит)
const squad = [
  mk(70, 'GK'), mk(62, 'GK', 31),
  mk(65, 'DC'), mk(64, 'DC'), mk(66, 'DL'), mk(63, 'DR'),
  mk(68, 'MC'), mk(66, 'MC'), mk(65, 'ML'), mk(67, 'ST'), mk(64, 'ST'), mk(60, 'AMC'),
  mk(58, 'MC'), mk(57, 'ST'),
];
const needs = squadNeedsOf(squad, 68);
const defNeed = needs.find((n) => n.group === 'DEF')!;
const gkNeed = needs.find((n) => n.group === 'GK')!;
check('u2_deficit_detected', defNeed.urgency > gkNeed.urgency, `def=${defNeed.urgency} gk=${gkNeed.urgency}`);

// пустая группа — критический дефицит
const needsHole = squadNeedsOf([mk(70, 'GK')], 65);
const fwdNeed = needsHole.find((n) => n.group === 'FWD')!;
check('u2_empty_group_critical', fwdNeed.starter === 30 && fwdNeed.urgency >= 12, `u=${fwdNeed.urgency}`);

// умный выбор: FWD-лот НЕ усиливает атаку (61 ниже стартовой), DEF-лот
// закрывает дефицитную оборону — выбирается защита, а не бесполезный форвард
const listings = [
  { listingId: 'l1', price: 3_000_000, source: 'market', playerId: 'p1', ovr: 59, age: 27, value: 2_800_000, group: 'FWD' as const },
  { listingId: 'l2', price: 6_000_000, source: 'market', playerId: 'p2', ovr: 66, age: 25, value: 5_500_000, group: 'DEF' as const },
  { listingId: 'l3', price: 5_000, source: 'free', playerId: 'p3', ovr: 40, age: 33, value: 200_000, group: 'DEF' as const },
  { listingId: 'l4', price: 25_000_000, source: 'market', playerId: 'p4', ovr: 80, age: 24, value: 15_000_000, group: 'DEF' as const },
];
const pick1 = pickAiTransferTarget(mulberry32(3), { needs, budget: 20_000_000, listings });
check('u2_picks_defensive_need', pick1?.listingId === 'l2', `picked=${pick1?.listingId}`);

// переплата отклоняется (price/value > 1.35)
const pick2 = pickAiTransferTarget(mulberry32(5), { needs, budget: 100_000_000, listings });
check('u2_rejects_overpriced', pick2?.listingId !== 'l4', `picked=${pick2?.listingId}`);

// слабый лот (не усиливает) не берётся даже бесплатно
const pick3 = pickAiTransferTarget(mulberry32(9), { needs, budget: 100, listings });
check('u2_rejects_weak', pick3 === null || pick3.listingId !== 'l3', `picked=${pick3?.listingId}`);

// входящий оффер: Босман-дисконт
const bosmanTarget = mk(72, 'ST', 28);
bosmanTarget.contractUntil = 1; // последний год
{
  const aiTeams = [{ teamId: 't1', strength: 72 }, { teamId: 't2', strength: 60 }];
  const offers: ReturnType<typeof aiIncomingOfferOf>[] = [];
  for (let i = 0; i < 30; i++) {
    const draft = aiIncomingOfferOf(mulberry32(100 + i), {
      userSquad: [bosmanTarget],
      aiTeams,
      offeredPlayerIds: new Set(),
      userListings: new Map(),
      season: 1,
    });
    if (draft) offers.push(draft);
  }
  check('u2_offer_generated', offers.length >= 25, `n=${offers.length}`);
  const allBosmanCheap = offers.every((o) => o.amount < bosmanTarget.value * 1.0);
  check('u2_bosman_discount', allBosmanCheap, `avg=${offers.reduce((s, o) => s + o.amount, 0) / offers.length}`);
  check('u2_offer_guard_dupes', aiIncomingOfferOf(mulberry32(1), {
    userSquad: [bosmanTarget], aiTeams, offeredPlayerIds: new Set([bosmanTarget.id]),
    userListings: new Map(), season: 1,
  }) === null);
}

// зарплата ИИ-подписания разумная
const salaryAi = aiSigningSalaryOf(mk(70, 'MC'));
check('u2_ai_salary_sane', salaryAi >= 500 && salaryAi <= 100_000, `s=${salaryAi}`);

// ── U3: переговоры (negotiation.ts) ───────────────────────────────────────

console.log('\n== U3: контрактные переговоры ==');

eq('u3_years_young', desiredYearsOf(19), 4);
eq('u3_years_prime', desiredYearsOf(27), 3);
eq('u3_years_veteran', desiredYearsOf(34), 1);

eq('u3_role_star', roleForBuyer(80, 70), 'star');
eq('u3_role_depth', roleForBuyer(60, 70), 'depth');

const signTarget = mk(68, 'ST', 25);
signTarget.potential = 84;
const demand = signingDemandOf({ player: signTarget, buyerTop11Avg: 65 });
check('u3_demand_talent_premium', demand.salary > 0 && demand.goalBonus > demand.cleanSheetBonus,
  `salary=${demand.salary} goal=${demand.goalBonus} cs=${demand.cleanSheetBonus}`);
check('u3_demand_years', demand.years === 3, `y=${demand.years}`);

// принято при полном спросе
const okMood = mulberry32(10); // мягкий/жёсткий — неважно: ровно спрос ≥ порога
const accepted = evaluateSigningOffer({
  player: signTarget, demand,
  offer: { salary: demand.salary, years: demand.years, goalBonus: demand.goalBonus, cleanSheetBonus: demand.cleanSheetBonus },
  rng: okMood,
});
eq('u3_accepted_at_demand', accepted.kind, 'accepted');

// чуть ниже — контрпредложение (порог ≤ 0.92 от спроса)
let counterSeen = false;
for (let i = 0; i < 20; i++) {
  const res = evaluateSigningOffer({
    player: signTarget, demand,
    offer: { salary: Math.round(demand.salary * 0.85), years: demand.years, goalBonus: demand.goalBonus, cleanSheetBonus: demand.cleanSheetBonus },
    rng: mulberry32(500 + i),
  });
  if (res.kind === 'counter') counterSeen = true;
  if (res.kind !== 'counter') {
    check(`u3_counter_or_reject_valid_${i}`, res.kind === 'rejected' || res.kind === 'counter');
  }
}
check('u3_counter_seen', counterSeen);

// сильно ниже — отказ с причиной
let rejectedSalary = false;
for (let i = 0; i < 20; i++) {
  const res = evaluateSigningOffer({
    player: signTarget, demand,
    offer: { salary: Math.round(demand.salary * 0.5), years: demand.years, goalBonus: 0, cleanSheetBonus: 0 },
    rng: mulberry32(900 + i),
  });
  if (res.kind === 'rejected' && res.reason === 'salary') rejectedSalary = true;
}
check('u3_rejected_salary_reason', rejectedSalary);

// бонусы влияют: обнуленные бонусы при полной зарплате → не принято
let bonusMattered = false;
for (let i = 0; i < 20; i++) {
  const res = evaluateSigningOffer({
    player: signTarget, demand,
    offer: { salary: demand.salary, years: demand.years, goalBonus: 0, cleanSheetBonus: 0 },
    rng: mulberry32(1300 + i),
  });
  if (res.kind !== 'accepted') bonusMattered = true;
}
check('u3_bonus_gates_accept', bonusMattered);

// ── I1: интеграция — карьера, watch, неделя, рост знания, офферы ──────────

console.log('\n== I1: интеграция движка ==');

const engine = getEngine();
const created = await engine.createCareer({
  leagueCode: 'RPL',
  clubIndex: 2,
  managerName: 'М3 Смоук',
  seed: 777,
  now: NOW,
});
check('i1_career_created', created.slot >= 1 && created.saveId.length > 0);

// рынок наполняется недельным циклом — играем первую неделю ДО проверок
await engineDispatch('POST', '/simulate', { saveId: created.saveId });

// рынок: лоты без знаний — туман
const market1 = (await engineDispatch('GET', '/market', { saveId: created.saveId, sort: 'ovr' })) as {
  ok: boolean; listings: { listingId: string; price: number; player: { id: string; scoutKnowledge: number; ovr: number } }[];
};
check('i1_market_responds', market1.ok && market1.listings.length > 0, `n=${market1.listings.length}`);
const fogged = market1.listings.filter((l) => l.player.scoutKnowledge < 40);
check('i1_fog_by_default', fogged.length === market1.listings.length, `fogged=${fogged.length}`);

// скаутинг: слот занят, знание 10
const watchRes = await engineDispatch('POST', '/scout/watch', {
  saveId: created.saveId,
  playerId: market1.listings[0].player.id,
}) as { ok: boolean };
check('i1_watch_ok', watchRes.ok);
const scout1 = (await engineDispatch('GET', '/scout', { saveId: created.saveId })) as {
  ok: boolean; reports: { knowledge: number; watched: boolean }[]; slots: { used: number; total: number };
};
check('i1_scout_report_created',
  scout1.reports.length === 1 && scout1.reports[0].knowledge === 10 && scout1.reports[0].watched
  && scout1.slots.used === 1 && scout1.slots.total === 2,
  `reports=${scout1.reports.length} k=${scout1.reports[0]?.knowledge} slots=${scout1.slots.used}/${scout1.slots.total}`);

// слоты кончаются: второй слот занимает watch [1], третий отказ SCOUT_SLOTS_FULL
await engineDispatch('POST', '/scout/watch', { saveId: created.saveId, playerId: market1.listings[1].player.id });
let slotsFull = false;
try {
  await engineDispatch('POST', '/scout/watch', { saveId: created.saveId, playerId: market1.listings[2].player.id });
} catch (e) {
  slotsFull = (e as { code?: string }).code === 'SCOUT_SLOTS_FULL';
}
check('i1_slots_guard', slotsFull);

// офферы: пустой список
const offers1 = (await engineDispatch('GET', '/transfer-offers', { saveId: created.saveId })) as {
  ok: boolean; offers: unknown[];
};
check('i1_offers_empty_initial', offers1.ok && offers1.offers.length === 0);

// 6 недель: знание растёт, оффер может прийти (неделя 6 = 3k, валидный бросок)
for (let w = 0; w < 6; w++) {
  await engineDispatch('POST', '/simulate', { saveId: created.saveId });
}
const scout2 = (await engineDispatch('GET', '/scout', { saveId: created.saveId })) as {
  ok: boolean; reports: { knowledge: number }[];
};
const growth = scout2.reports.length > 0 ? scout2.reports[0].knowledge : 0;
check('i1_knowledge_grows', growth >= 10 + 6 * 7, `k=${growth}`); // 7.3/нед × 6

// погашение: unwatch → watched=false
const unwatch = await engineDispatch('POST', '/scout/unwatch', {
  saveId: created.saveId, playerId: market1.listings[1].player.id,
}) as { ok: boolean };
check('i1_unwatch_ok', unwatch.ok);
const scout3 = (await engineDispatch('GET', '/scout', { saveId: created.saveId })) as {
  ok: boolean; reports: { watched: boolean }[];
};
check('i1_unwatched_flag', scout3.reports.some((r) => !r.watched));

// сериализация слота: новые таблицы в дампе
const dump = engine.requireStore().toJSON();
check('i1_dump_has_scout_reports', Array.isArray(dump.scoutReports) && dump.scoutReports.length >= 1);
check('i1_dump_has_offers_table', Array.isArray(dump.transferOffers));

// переговоры: покупка с заниженной зарплатой → counter/rejected, сделка не прошла
const cheapOffer = { salary: 100, years: 4, goalBonus: 0, cleanSheetBonus: 0 };
let negotiationBlocked = false;
let listingToBuy = market1.listings[4] ?? market1.listings[0];
try {
  const res = (await engineDispatch('POST', '/market/buy', {
    saveId: created.saveId,
    playerId: listingToBuy.player.id,
    ...cheapOffer,
  })) as { ok: boolean; negotiation?: { kind: string } };
  negotiationBlocked = res.ok === true && res.negotiation !== undefined && res.negotiation.kind !== 'accepted';
} catch {
  negotiationBlocked = true; // ошибка бюджета/состава тоже блокирует
}
check('i1_negotiation_blocks_cheap', negotiationBlocked);

await engine.removeSlot(created.slot);
console.log(`\nИтого: PASS=${pass} FAIL=${fail}`);
if (fail > 0) {
  console.log(`Провалены: ${failures.join(', ')}`);
  process.exit(1);
}

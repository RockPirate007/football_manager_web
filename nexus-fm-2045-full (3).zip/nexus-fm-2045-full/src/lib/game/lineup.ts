/**
 * Хелперы состава для UI: эффективный состав (сохранённый или автосостав).
 */

import { autoLineup, isLineupValid, type PlayerLike } from './players';
import type { PlayerDTO, TeamDTO } from './types';

export interface EffectiveLineup {
  lineup: (string | null)[];
  bench: string[];
}

/** Сохранённый состав, если валиден — иначе авторегенерация (как на сервере). */
export function effectiveLineup(team: TeamDTO, players: PlayerDTO[]): EffectiveLineup {
  const squad = players as unknown as PlayerLike[];
  const saved = team.lineup;
  if (saved && saved.length === 11 && isLineupValid(saved, squad)) {
    return { lineup: saved, bench: team.bench ?? [] };
  }
  const auto = autoLineup(squad, team.formation);
  return { lineup: auto.lineup, bench: auto.bench };
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolveSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { buildSnapshot } from '@/lib/game/snapshot';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/state?saveId= — полный снапшот состояния карьеры.
 * Обновляет lastOpenedAt (touch для сортировки «недавно открытые»).
 * Без saveId (легаси-клиент Фазы 1) — последний открытый активный сейв.
 * Фаза 3: finished-сейвы (уволен) доступны для просмотра — как в buildSnapshot.
 */
export async function GET(request: Request) {
  try {
    const saveId = saveIdFromQuery(request);
    const save = await resolveSave(saveId);
    const statusOk = save.status === 'active' || save.status === 'finished';
    if (!statusOk || !save.teamId) return fail('SAVE_NOT_FOUND', 404);

    await db.gameSave.update({ where: { id: save.id }, data: { lastOpenedAt: new Date() } });

    const snapshot = await buildSnapshot(save.id);
    return NextResponse.json({ ok: true, snapshot });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/state]', error);
    return fail('UNKNOWN', 500);
  }
}

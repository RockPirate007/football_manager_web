/**
 * ENGINE 2.0 — разрешение дуэлей атрибутов.
 *
 * Каждое действие на поле — это микроматч конкретных скиллов:
 *   пас ↔ перехват (marking/positioning/tackling),
 *   дриблинг ↔ отбор (tackling/strength),
 *   удар ↔ вратарь (reflexes/handling),
 *   навес ↔ верховая дуэль (heading/jumping).
 * Вероятность — логистическая кривая от разницы эффективных атрибутов
 * (эффективность = атрибут × усталость × мораль). Порядок rng-бросков
 * фиксирован (детерминизм движка).
 */

import type { PlayerLike } from '../players';
import type { RNG } from '../rng';
import {
  DUEL_BIAS,
  DUEL_P_MAX,
  DUEL_P_MIN,
  DUEL_SLOPE,
  EFF_MULT_FLOOR,
  EFF_MULT_SPAN,
  MORALE_MULT_FLOOR,
  MORALE_MULT_SPAN,
} from './constants';

// ── Эффективность игрока в конкретный момент матча ───────────────────────

/** Множитель уставшего игрока: 0.52..1.0. */
export function effMultOf(energy: number): number {
  return EFF_MULT_FLOOR + EFF_MULT_SPAN * Math.max(0, Math.min(100, energy)) / 100;
}

/** Множитель морали команды: 0.93..1.07. */
export function moraleMultOf(matchMorale: number): number {
  return MORALE_MULT_FLOOR + MORALE_MULT_SPAN * Math.max(0, Math.min(100, matchMorale)) / 100;
}

/**
 * Форма игрока на матч (Модуль 2): бросок на старте матча, амплитуда — от
 * СКРЫТОГО параметра consistency. Надёжный (90) качается ±1%, нестабильный
 * (20) — ±8%. Роллится в MatchEngine.buildSide — порядок бросков фиксирован.
 */
export function rollForm(rng: RNG, consistency: number | undefined): number {
  const amp = ((100 - (consistency ?? 55)) / 100) * 0.1;
  return 1 + (rng() * 2 - 1) * amp;
}

/**
 * Эффективное значение атрибута игрока с учётом энергии, морали команды и
 * формы матча (consistency). Если атрибут не задан (легаси-DTO) — нейтральное 50.
 */
export function eff(
  p: PlayerLike,
  attr: keyof PlayerLike,
  energy: number,
  matchMorale: number,
  form = 1,
): number {
  const raw = p[attr];
  const v = typeof raw === 'number' ? raw : 50;
  return v * effMultOf(energy) * moraleMultOf(matchMorale) * form;
}

// ── Ядро дуэли ────────────────────────────────────────────────────────────

/**
 * Логистическая дуэль: p = k·e^(Δ/s) / (1 + k·e^(Δ/s)),
 * Δ = сумма атакующих атрибутов − сумма защитных, k — bias действия.
 */
export function duelProb(atkSum: number, defSum: number, bias: number): number {
  const delta = atkSum - defSum;
  const odds = bias * Math.exp(delta / DUEL_SLOPE);
  const p = odds / (1 + odds);
  return Math.max(DUEL_P_MIN, Math.min(DUEL_P_MAX, p));
}

/** Бросок дуэли: true = атакующий преуспел. */
export function rollDuel(rng: RNG, atkSum: number, defSum: number, bias: number): boolean {
  return rng() < duelProb(atkSum, defSum, bias);
}

/** Комбинированный атрибут двух скиллов (пас+видение и т.п.). */
export function pairOf(
  a: number,
  b: number,
  weightA = 0.5,
): number {
  return weightA * a + (1 - weightA) * b;
}

// ── Профили дуэлей по типам действий ─────────────────────────────────────

export interface DuelSide {
  p: PlayerLike;
  energy: number;
  morale: number;
  /** Домашнее преимущество владельца роли (odds ×1.13). */
  homeAdv?: boolean;
  /** Форма игрока на матч (Модуль 2, rollForm по consistency); 1 = нейтрально. */
  form?: number;
}

export interface DuelSides {
  /** Атакующий (владелец мяча). */
  atk: DuelSide;
  /** Защитник (соперник). */
  def: DuelSide;
  /** Вратарь (для удара) — опционален. */
  gk?: DuelSide;
}

/** Множитель домашнего преимущества в дуэлях (odds). */
export const HOME_DUEL_ODDS = 1.13;

/** Итоговый odds-множитель дуэли с учётом домашек обеих сторон. */
function homeOddsOf(s: DuelSides): number {
  return ((s.atk.homeAdv ? HOME_DUEL_ODDS : 1) / (s.def.homeAdv ? HOME_DUEL_ODDS : 1));
}

/**
 * Разрешение ПРОТИВ ПЕРЕХВАТА (пас любого вида).
 * Пас/видение/решения пасующего против опека/позиционирования/отбора перехватчика.
 */
export function resolvePass(rng: RNG, s: DuelSides, kind: 'safe' | 'prog' | 'through'): boolean {
  const a = s.atk;
  const d = s.def;
  const atkSum =
    eff(a.p, 'passing', a.energy, a.morale, a.form) +
    0.6 * eff(a.p, 'vision', a.energy, a.morale, a.form) +
    0.3 * eff(a.p, 'decisions', a.energy, a.morale, a.form);
  const defSum =
    0.7 * eff(d.p, 'marking', d.energy, d.morale, d.form) +
    0.6 * eff(d.p, 'positioning', d.energy, d.morale, d.form) +
    0.3 * eff(d.p, 'tackling', d.energy, d.morale, d.form);
  const bias =
    kind === 'safe' ? DUEL_BIAS.safePass : kind === 'prog' ? DUEL_BIAS.progPass : DUEL_BIAS.throughBall;
  return rollDuel(rng, atkSum, defSum, bias * homeOddsOf(s));
}

/** Дриблинг против отбора: дриблинг/ускорение/скорость ↔ отбор/сила/скорость. */
export function resolveDribble(rng: RNG, s: DuelSides): boolean {
  const a = s.atk;
  const d = s.def;
  const atkSum =
    1.1 * eff(a.p, 'dribbling', a.energy, a.morale, a.form) +
    0.6 * eff(a.p, 'acceleration', a.energy, a.morale, a.form) +
    0.3 * eff(a.p, 'pace', a.energy, a.morale, a.form);
  const defSum =
    1.1 * eff(d.p, 'tackling', d.energy, d.morale, d.form) +
    0.5 * eff(d.p, 'strength', d.energy, d.morale, d.form) +
    0.4 * eff(d.p, 'acceleration', d.energy, d.morale, d.form);
  return rollDuel(rng, atkSum, defSum, DUEL_BIAS.dribble * homeOddsOf(s));
}

/** Верховая дуэль (навес/длинный мяч/угловой): прыжок+голова ↔ прыжок+голова+опека. */
export function resolveAerial(rng: RNG, s: DuelSides): boolean {
  const a = s.atk;
  const d = s.def;
  const atkSum =
    eff(a.p, 'jumping', a.energy, a.morale, a.form) +
    1.2 * eff(a.p, 'heading', a.energy, a.morale, a.form) +
    0.25 * eff(a.p, 'strength', a.energy, a.morale, a.form);
  const defSum =
    0.9 * eff(d.p, 'jumping', d.energy, d.morale, d.form) +
    1.1 * eff(d.p, 'heading', d.energy, d.morale, d.form) +
    0.5 * eff(d.p, 'marking', d.energy, d.morale, d.form);
  return rollDuel(rng, atkSum, defSum, 1.0 * homeOddsOf(s));
}

/**
 * Разрешение УДАРА: гол / сейв / блок / мимо.
 * finishing (+позиционирование) против вратаря (рефлексы + надёжность).
 */
export type ShotOutcome = 'goal' | 'save' | 'blocked' | 'off';

export function resolveShot(
  rng: RNG,
  s: DuelSides,
  xg: number,
): ShotOutcome {
  const a = s.atk;
  const g = s.gk ?? s.def; // без вратаря — полевой в «рамке» (дежурный случай)
  const fin = eff(a.p, 'finishing', a.energy, a.morale, a.form);
  const pos = eff(a.p, 'positioning', a.energy, a.morale, a.form);
  const gkSkill =
    0.6 * eff(g.p, 'reflexes', g.energy, g.morale, g.form) + 0.4 * eff(g.p, 'handling', g.energy, g.morale, g.form);
  // фактор нападающий vs вратарь: 0.75..1.25 (домашка атакующего учитывается)
  const homeBoost = s.atk.homeAdv && !s.gk?.homeAdv ? 1.06 : 1;
  const finFactor = Math.max(0.75, Math.min(1.25, 0.75 + (1.0 * (fin + 0.25 * pos) - gkSkill) / 90)) * homeBoost;
  const pGoal = Math.max(0.01, Math.min(0.85, xg * finFactor));
  const r = rng();
  if (r < pGoal) return 'goal';
  if (r < pGoal + 0.34) return 'save';
  if (r < pGoal + 0.34 + 0.21) return 'blocked';
  return 'off';
}

/** Простой бросок вероятности (обёртка для единообразия вызовов rng). */
export function chance(rng: RNG, p: number): boolean {
  return rng() < p;
}

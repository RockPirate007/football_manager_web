'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  ArrowRight, Globe, Loader2, Pencil, Plus, Trash2, Trophy, Users, Zap,
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { FormDots } from '@/components/game/shared/FormDots';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import type { SaveCardDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const MAX_SAVES = 8;

function formatDate(iso: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('ru-RU', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '—';
  }
}

function safeDate(iso: string | null, fallback: string): number {
  const t = iso ? Date.parse(iso) : NaN;
  return Number.isNaN(t) ? Date.parse(fallback) || 0 : t;
}

/* ────────────────────────────────────────────────────────────────────────────
 * Диалоги переименования/удаления (общие для всех карточек карьер).
 * ──────────────────────────────────────────────────────────────────────── */
function SaveDialogs({
  save,
  renameOpen,
  setRenameOpen,
  deleteOpen,
  setDeleteOpen,
}: {
  save: SaveCardDTO;
  renameOpen: boolean;
  setRenameOpen: (v: boolean) => void;
  deleteOpen: boolean;
  setDeleteOpen: (v: boolean) => void;
}) {
  const renameSave = useGameStore((s) => s.renameSave);
  const deleteSave = useGameStore((s) => s.deleteSave);
  const [renameValue, setRenameValue] = useState(save.careerName);
  const [renameBusy, setRenameBusy] = useState(false);

  const submitRename = async () => {
    const trimmed = renameValue.trim();
    if (trimmed.length < 1 || trimmed.length > 60) return;
    setRenameBusy(true);
    const ok = await renameSave(save.id, trimmed);
    setRenameBusy(false);
    if (ok) setRenameOpen(false);
  };

  return (
    <>
      {/* Переименование */}
      <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Переименовать карьеру</DialogTitle>
            <DialogDescription>Новое название — от 1 до 60 символов.</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            <Label htmlFor={`rename-${save.id}`}>Название</Label>
            <Input
              id={`rename-${save.id}`}
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              maxLength={60}
              autoComplete="off"
              className="h-11 bg-secondary"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" className="min-h-11" onClick={() => setRenameOpen(false)}>
              Отмена
            </Button>
            <Button
              className="min-h-11"
              onClick={() => void submitRename()}
              disabled={renameBusy || renameValue.trim().length < 1}
            >
              {renameBusy ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Удаление */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить карьеру «{save.careerName}»?</AlertDialogTitle>
            <AlertDialogDescription>
              Карьера удаляется навсегда — вместе с клубом, составом, результатами и историей
              сезонов. Это действие нельзя отменить.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="min-h-11">Оставить</AlertDialogCancel>
            <AlertDialogAction
              className="min-h-11 bg-[#EF4444] text-white hover:bg-[#DC2626]"
              onClick={(e) => {
                e.preventDefault();
                setDeleteOpen(false);
                void deleteSave(save.id);
              }}
            >
              <Trash2 className="size-4" aria-hidden />
              Удалить навсегда
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
 * «Продолжить» — большая карточка последней карьеры (FM-паттерн).
 * ──────────────────────────────────────────────────────────────────────── */
function ContinueCard({ save }: { save: SaveCardDTO }) {
  const openSave = useGameStore((s) => s.openSave);
  const loading = useGameStore((s) => s.loading);
  const finished = save.status === 'finished';

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      <Card
        className={cn(
          'relative overflow-hidden border-primary/30 bg-card/90 shadow-[0_0_40px_rgba(0,212,255,0.12)] backdrop-blur',
          finished && 'border-[#EF4444]/40',
        )}
      >
        <CardContent className="p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between gap-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-primary/80">
              Продолжить карьеру
            </span>
            <FormDots form={save.form} />
          </div>

          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <TeamCrest
              shortName={save.clubShort}
              colorPrimary={save.colorPrimary}
              colorSecondary={save.colorSecondary}
              size="lg"
              className="size-14 text-base sm:size-16 sm:text-lg"
              title={save.clubName}
            />
            <div className="min-w-0 flex-1">
              <div className="truncate text-lg font-black leading-tight sm:text-xl">
                {save.clubName}
              </div>
              <div className="mt-0.5 truncate text-xs text-muted-foreground">
                <span aria-hidden>{save.leagueFlag}</span> {save.leagueName} · {save.managerName}
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span>
                  Сезон <span className="font-semibold text-foreground tabular">{save.season}</span>
                </span>
                <span className="text-border" aria-hidden>·</span>
                <span className="tabular">{save.weekLabel}</span>
                <span className="text-border" aria-hidden>·</span>
                <span>
                  <span className="font-semibold text-foreground tabular">{save.place}</span>-е место
                </span>
                <span className="text-border" aria-hidden>·</span>
                <span className="hidden sm:inline">
                  заход: {formatDate(save.lastOpenedAt)}
                </span>
              </div>
            </div>

            <Button
              size="lg"
              className={cn(
                'h-12 gap-2 px-6 text-base font-bold',
                !finished &&
                  'bg-primary text-primary-foreground shadow-[0_0_28px_rgba(0,212,255,0.4)] hover:bg-primary/90 hover:shadow-[0_0_36px_rgba(0,212,255,0.55)]',
              )}
              onClick={() => void openSave(save.id)}
              disabled={loading}
              variant={finished ? 'outline' : 'default'}
            >
              {loading ? (
                <Loader2 className="size-5 animate-spin" aria-hidden />
              ) : (
                <ArrowRight className="size-5" aria-hidden />
              )}
              {finished ? 'Просмотр итогов' : 'Продолжить'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
 * Компактная строка-карточка остальных карьер.
 * ──────────────────────────────────────────────────────────────────────── */
function CareerRow({ save, index }: { save: SaveCardDTO; index: number }) {
  const openSave = useGameStore((s) => s.openSave);
  const loading = useGameStore((s) => s.loading);
  const [renameOpen, setRenameOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const finished = save.status === 'finished';

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.05, 0.3) }}
    >
      <Card
        className={cn(
          'h-full border-border/70 transition-colors hover:border-primary/40',
          finished && 'border-[#EF4444]/40',
        )}
      >
        <CardContent className="flex h-full flex-col gap-2 p-3 sm:p-4">
          <button
            type="button"
            className="flex min-w-0 items-center gap-3 text-left"
            onClick={() => void openSave(save.id)}
            disabled={loading}
            aria-label={`Открыть карьеру «${save.careerName}»`}
          >
            <TeamCrest
              shortName={save.clubShort}
              colorPrimary={save.colorPrimary}
              colorSecondary={save.colorSecondary}
              size="md"
              title={save.clubName}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="truncate text-sm font-bold leading-tight">{save.careerName}</span>
                {finished ? (
                  <Badge className="shrink-0 border border-[#EF4444]/40 bg-[#EF4444]/10 text-[10px] text-[#EF4444]">
                    Уволен
                  </Badge>
                ) : null}
              </div>
              <div className="mt-0.5 truncate text-[11px] text-muted-foreground">
                {save.clubName} · {save.managerName}
              </div>
              <div className="mt-1 truncate text-[11px] text-muted-foreground tabular">
                <span aria-hidden>{save.leagueFlag}</span> {save.leagueName} · сезон {save.season} ·{' '}
                {save.place}-е место
              </div>
            </div>
          </button>

          <div className="mt-auto flex items-center justify-between gap-2">
            <FormDots form={save.form} />
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-muted-foreground hover:text-foreground"
                onClick={() => setRenameOpen(true)}
                aria-label={`Переименовать карьеру «${save.careerName}»`}
              >
                <Pencil className="size-3.5" aria-hidden />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-muted-foreground hover:bg-[#EF4444]/10 hover:text-[#EF4444]"
                onClick={() => setDeleteOpen(true)}
                aria-label={`Удалить карьеру «${save.careerName}»`}
              >
                <Trash2 className="size-3.5" aria-hidden />
              </Button>
              <SaveDialogs
                save={save}
                renameOpen={renameOpen}
                setRenameOpen={setRenameOpen}
                deleteOpen={deleteOpen}
                setDeleteOpen={setDeleteOpen}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ────────────────────────────────────────────────────────────────────────────
 * Экран «Главное меню»: hero-заставка, «Продолжить», сетка карьер,
 * «Новая карьера», слоты.
 * ──────────────────────────────────────────────────────────────────────── */
export function CareersScreen() {
  const saves = useGameStore((s) => s.saves);
  const savesLoading = useGameStore((s) => s.savesLoading);
  const startNewCareer = useGameStore((s) => s.startNewCareer);
  const loading = useGameStore((s) => s.loading);

  // Последняя открытая карьера — первой (FM «Continue»).
  const sorted = useMemo(
    () =>
      [...saves].sort(
        (a, b) =>
          safeDate(b.lastOpenedAt, b.updatedAt) - safeDate(a.lastOpenedAt, a.updatedAt),
      ),
    [saves],
  );
  const continueSave = sorted[0] ?? null;
  const rest = sorted.slice(1);
  const limitReached = saves.length >= MAX_SAVES;
  const hasSaves = sorted.length > 0;

  return (
    <main className="relative min-h-screen overflow-hidden bg-background cyber-grid p-4 sm:p-6">
      {/* Прожекторы стадиона (декор) */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute -top-32 left-[8%] h-[460px] w-[220px] rotate-12 bg-gradient-to-b from-primary/15 via-primary/5 to-transparent blur-2xl" />
        <div className="absolute -top-32 right-[8%] h-[460px] w-[220px] -rotate-12 bg-gradient-to-b from-[#FF6B35]/15 via-[#FF6B35]/5 to-transparent blur-2xl" />
        <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-primary/5 to-transparent" />
      </div>

      <div className="relative mx-auto flex w-full max-w-5xl flex-col gap-6">
        {/* ── Hero: логотип ── */}
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="visual-panel overflow-hidden rounded-2xl border border-primary/20 bg-card/70 px-5 py-8 text-center shadow-[0_18px_60px_rgba(0,0,0,.3)] sm:px-10 sm:py-12"
          style={{ backgroundImage: "url('/visuals/stadium-night.svg')" }}
        >
          <p className="relative mb-3 flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-primary"><span className="live-dot" /> Career hub // 2046 season</p>
          <h1 className="relative flex flex-wrap items-baseline justify-center gap-x-2 text-4xl font-black tracking-tight sm:text-6xl">
            <span className="neon-text text-primary">NEXUS FM</span>
            <span className="neon-text-orange text-[#FF6B35]">2046</span>
          </h1>
          <p className="relative mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Главный экран карьеры: один клик до последнего сейва, нового клуба или следующего большого футбольного проекта.
          </p>
          <Badge
            variant="outline"
            className="relative mt-4 border-primary/30 bg-primary/10 text-[10px] font-bold uppercase tracking-[0.18em] text-primary/90"
          >
            Ultimate Manager Edition
          </Badge>
        </motion.div>

        {savesLoading && saves.length === 0 ? (
          /* Скелетоны загрузки */
          <div className="space-y-4">
            <Skeleton className="h-36 rounded-lg" />
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Skeleton className="h-28 rounded-lg" />
              <Skeleton className="h-28 rounded-lg" />
            </div>
          </div>
        ) : !hasSaves ? (
          /* ── Пустое состояние: приглашение создать первую карьеру ── */
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.1 }}
            className="space-y-4"
          >
            <Card className="border-primary/30 bg-card/90 shadow-[0_0_40px_rgba(0,212,255,0.12)] backdrop-blur">
              <CardContent className="flex flex-col items-center gap-4 py-10 text-center">
                <span className="flex size-16 items-center justify-center rounded-full bg-primary/10 text-primary shadow-[0_0_24px_rgba(0,212,255,0.25)]">
                  <Trophy className="size-8" aria-hidden />
                </span>
                <div>
                  <p className="text-lg font-black">Начните свою первую карьеру</p>
                  <p className="mt-1 max-w-md text-sm text-muted-foreground">
                    Выберите одну из 6 лиг — от Английской Премьер-лиги до Российской, —
                    возглавьте клуб и приведите его к трофеям.
                  </p>
                </div>
                <Button
                  size="lg"
                  className="h-12 gap-2 px-6 text-base font-bold bg-primary text-primary-foreground shadow-[0_0_28px_rgba(0,212,255,0.4)] hover:bg-primary/90"
                  onClick={startNewCareer}
                >
                  <Plus className="size-5" aria-hidden />
                  Создать карьеру
                </Button>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              {(
                [
                  [Globe, '6 лиг', 'АПЛ, Ла Лига, Серия А, Бундеслига, Лига 1, РПЛ'],
                  [Zap, 'Живая неделя', 'трансляции матчей, тренировки, рынок, пресса'],
                  [Trophy, 'Трофеи', 'чемпионство, кубки, Кубок Европы, награды'],
                ] as const
              ).map(([Icon, title, text], i) => (
                <motion.div
                  key={title}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.08 }}
                >
                  <Card className="h-full border-border/70">
                    <CardContent className="flex h-full flex-col gap-1.5 p-4">
                      <Icon className="size-4 text-primary" aria-hidden />
                      <span className="text-sm font-bold">{title}</span>
                      <span className="text-xs text-muted-foreground">{text}</span>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        ) : (
          <>
            {/* ── Продолжить (последняя карьера) ── */}
            {continueSave ? <ContinueCard save={continueSave} /> : null}

            {/* ── Новая карьера ── */}
            <motion.button
              type="button"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              onClick={startNewCareer}
              disabled={limitReached || loading}
              title={
                limitReached ? 'Достигнут лимит 8 карьер — удалите одну из них' : undefined
              }
              className={cn(
                'group flex w-full flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-5 transition-colors',
                limitReached
                  ? 'cursor-not-allowed border-border/60 opacity-50'
                  : 'border-primary/30 bg-primary/[0.03] hover:border-primary/60 hover:bg-primary/[0.07]',
              )}
              aria-label="Начать новую карьеру"
            >
              <span className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary transition-transform group-hover:scale-110">
                <Plus className="size-5" aria-hidden />
              </span>
              <span className="text-base font-bold">Новая карьера</span>
              <span className="text-xs text-muted-foreground">
                <span className="mr-1.5 tracking-widest" aria-hidden>
                  🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇪🇸 🇮🇹 🇩🇪 🇫🇷 🇷🇺
                </span>
                6 лиг · 112 клубов · выбор любого клуба
              </span>
            </motion.button>

            {/* ── Остальные карьеры ── */}
            {rest.length > 0 ? (
              <section aria-label="Другие карьеры">
                <div className="mb-3 flex items-center gap-2 px-1">
                  <Users className="size-3.5 text-muted-foreground" aria-hidden />
                  <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">
                    Другие карьеры
                  </h2>
                  <span className="text-xs text-muted-foreground/70 tabular">
                    ({rest.length})
                  </span>
                </div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {rest.map((save, i) => (
                    <CareerRow key={save.id} save={save} index={i} />
                  ))}
                </div>
              </section>
            ) : null}
          </>
        )}

        {/* ── Футер: слоты ── */}
        <footer className="mt-2 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 pb-4 text-center text-[11px] text-muted-foreground/70">
          <span className="tabular">
            Слоты карьер: {saves.length} из {MAX_SAVES}
          </span>
          <span className="text-border" aria-hidden>·</span>
          <span>NEXUS FM 2046 · Ultimate Manager Edition</span>
        </footer>
      </div>
    </main>
  );
}

'use client';

import { useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Award, Footprints, Goal, Hand, Loader2, Medal, Shield, Sparkles, Star, Trophy,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import type { PlayerLeaderDTO, SeasonAwardDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Иконки 8 наград сезона (§5.5). */
const AWARD_ICONS: Record<string, typeof Trophy> = {
  top_scorer: Footprints,
  top_assist: Goal,
  mvp: Star,
  young: Sparkles,
  golden_glove: Hand,
  cup_scorer: Goal,
  champion: Trophy,
  cup_winner: Shield,
};

/** Порядок церемонии вручения. */
const AWARD_ORDER: Record<string, number> = {
  champion: 0,
  cup_winner: 1,
  top_scorer: 2,
  top_assist: 3,
  mvp: 4,
  young: 5,
  golden_glove: 6,
  cup_scorer: 7,
};

function awardIcon(type: string): typeof Trophy {
  return AWARD_ICONS[type] ?? Medal;
}

/** Таблица live-лидеров (топ-5). */
function LeadersTable({
  title,
  rows,
  valueLabel,
}: {
  title: string;
  rows: PlayerLeaderDTO[];
  valueLabel: string;
}) {
  const top5 = rows.slice(0, 5);
  return (
    <Card className="border-border/70">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {top5.length === 0 ? (
          <p className="py-4 text-center text-xs text-muted-foreground">Статистика ещё пуста.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="h-9 w-8 text-center text-[11px]">#</TableHead>
                <TableHead className="h-9 text-[11px]">Игрок</TableHead>
                <TableHead className="h-9 text-[11px]">Клуб</TableHead>
                <TableHead className="h-9 w-12 text-center text-[11px]">{valueLabel}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="zebra">
              {top5.map((p, i) => (
                <TableRow
                  key={p.playerId}
                  className={cn('h-10 border-border/40', p.isUser && 'bg-primary/10 hover:bg-primary/10')}
                >
                  <TableCell className="text-center text-xs font-semibold tabular">{i + 1}</TableCell>
                  <TableCell>
                    <span className={cn('flex items-center gap-1.5 text-xs', p.isUser && 'font-bold text-primary')}>
                      <OvrBadge ovr={p.ovr} size="sm" />
                      {p.name}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="flex items-center gap-1.5">
                      <TeamCrest
                        shortName={p.teamShort}
                        colorPrimary={p.colorPrimary}
                        colorSecondary={p.colorSecondary}
                        size="sm"
                        title={p.teamName}
                      />
                      <span className="truncate text-xs text-muted-foreground">{p.teamName}</span>
                    </span>
                  </TableCell>
                  <TableCell className="text-center text-xs font-bold tabular">
                    {valueLabel === 'Голы' ? p.goals : p.assists}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

/** Live-лидеры текущего сезона. */
function LiveSeason() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { leaders, save } = snapshot;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      <p className="text-xs text-muted-foreground">
        Лидеры по ходу сезона {save.season}. Официальные награды вручатся по итогам сезона —
        на церемонии после финала кубка.
      </p>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <LeadersTable title="Бомбардиры" rows={leaders.topScorers} valueLabel="Голы" />
        <LeadersTable title="Ассистенты" rows={leaders.topAssists} valueLabel="Пасы" />
      </div>
    </motion.div>
  );
}

/** Зал славы: карточки завершённых сезонов с 8 лауреатами. */
function HallOfFame() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const awardsCache = useGameStore((s) => s.awardsCache);
  const awardsLoading = useGameStore((s) => s.awardsLoading);

  const seasons = useMemo(() => {
    const awards = awardsCache?.awards ?? [];
    const map = new Map<number, SeasonAwardDTO[]>();
    for (const a of awards) {
      const list = map.get(a.season) ?? [];
      list.push(a);
      map.set(a.season, list);
    }
    return [...map.entries()].sort((a, b) => b[0] - a[0]);
  }, [awardsCache]);

  // Трофеи моего клуба по завершённым сезонам.
  const myTrophies = useMemo(() => {
    const awards = awardsCache?.awards ?? [];
    const myId = snapshot.myTeam.id;
    return {
      titles: awards.filter((a) => a.type === 'champion' && a.teamId === myId).length,
      cups: awards.filter((a) => a.type === 'cup_winner' && a.teamId === myId).length,
    };
  }, [awardsCache, snapshot.myTeam.id]);

  if (awardsLoading && !awardsCache) {
    return (
      <div className="flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Загружаем зал славы…
      </div>
    );
  }

  if (seasons.length === 0) {
    return (
      <Card className="border-border/70">
        <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
          <Medal className="size-10 text-muted-foreground" aria-hidden />
          <p className="text-sm font-semibold">Награды вручатся по итогам сезона</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            Первый сезон ещё не завершён. Золотая бутса, «Игрок сезона», «Золотая перчатка»,
            чемпионство и кубок — всё определится на церемонии после финала.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      {myTrophies.titles + myTrophies.cups > 0 ? (
        <div className="flex flex-wrap items-center gap-2">
          <Badge className="border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
            <Trophy className="size-3" aria-hidden />
            Чемпионств: {myTrophies.titles}
          </Badge>
          <Badge className="border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
            <Shield className="size-3" aria-hidden />
            Кубков: {myTrophies.cups}
          </Badge>
        </div>
      ) : null}

      {seasons.map(([season, awards], idx) => {
        const ordered = [...awards].sort(
          (a, b) => (AWARD_ORDER[a.type] ?? 99) - (AWARD_ORDER[b.type] ?? 99),
        );
        return (
          <motion.div
            key={season}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(idx * 0.06, 0.3) }}
          >
            <Card className="border-border/70">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Award className="size-4 text-[#EAB308]" aria-hidden />
                  Сезон {season}
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {ordered.map((a) => {
                  const Icon = awardIcon(a.type);
                  return (
                    <div
                      key={a.id}
                      className={cn(
                        'flex items-center gap-3 rounded-lg border border-border/60 bg-secondary/30 p-3',
                        a.teamId === snapshot.myTeam.id && 'border-primary/40 bg-primary/5',
                      )}
                    >
                      <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[#EAB308]/10">
                        <Icon className="size-4 text-[#EAB308]" aria-hidden />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-bold">{a.typeName}</div>
                        <div className="truncate text-[11px] text-muted-foreground">{a.label}</div>
                      </div>
                      <span className="shrink-0 text-sm font-bold tabular text-[#EAB308]">
                        {a.value}
                      </span>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </motion.div>
  );
}

/** Экран «Награды»: live-лидеры сезона + зал славы. */
export function AwardsScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const fetchAwards = useGameStore((s) => s.fetchAwards);

  useEffect(() => {
    void fetchAwards();
  }, [fetchAwards]);

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Награды"
        subtitle={`Личные призы и трофеи · ${snapshot.save.league.nameRu}`}
      />
      <Tabs defaultValue="live">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="live" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Star className="size-4" aria-hidden />
            Этот сезон
          </TabsTrigger>
          <TabsTrigger value="hall" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Medal className="size-4" aria-hidden />
            Зал славы
          </TabsTrigger>
        </TabsList>
        <TabsContent value="live">
          <LiveSeason />
        </TabsContent>
        <TabsContent value="hall">
          <HallOfFame />
        </TabsContent>
      </Tabs>
    </div>
  );
}

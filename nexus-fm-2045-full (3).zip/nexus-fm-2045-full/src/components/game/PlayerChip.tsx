'use client';

import { Bandage } from 'lucide-react';
import { cn } from '@/lib/utils';
import { positionFitOf } from '@/lib/game/strength';
import { positionGroupOf } from '@/lib/game/players';
import { ovrColor } from '@/lib/game/format';
import type { PlayerDTO, Position } from '@/lib/game/types';

/** Цвет рамки по соответствию позиции слоту (палитра NEXUS FM 2045). */
function fitBorderColor(playerPosition: Position, slotPosition: Position): string {
  const fit = positionFitOf(positionGroupOf(playerPosition), positionGroupOf(slotPosition));
  if (fit >= 1.0) return '#22C55E';
  if (fit >= 0.75) return '#FACC15';
  return '#FF6B35';
}

/** «Фишка» игрока на поле: круг 44px с OVR + подпись. */
export function PlayerChip({
  player,
  slotPosition,
  selected,
  onClick,
  className,
}: {
  player: PlayerDTO | null;
  slotPosition: Position;
  selected?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  if (!player) {
    return (
      <button
        type="button"
        onClick={onClick}
        className={cn(
          'flex size-11 items-center justify-center rounded-full border-2 border-dashed border-[#F0F6FC]/40 bg-black/25 text-[10px] font-bold text-[#F0F6FC]/70 outline-none transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-[#F0F6FC]/60',
          selected && 'scale-110 border-[#F0F6FC] bg-black/50',
          className,
        )}
        aria-label={`Пустой слот ${slotPosition}`}
      >
        {slotPosition}
      </button>
    );
  }

  const injured = player.injuryWeeks > 0;
  const borderColor = injured ? '#EF4444' : fitBorderColor(player.position, slotPosition);

  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'group relative flex size-12 items-center justify-center rounded-xl border-2 bg-gradient-to-br from-[#1e3b50]/95 to-[#0A0E17]/95 font-bold tabular outline-none transition-all hover:-translate-y-0.5 hover:scale-105 focus-visible:ring-2 focus-visible:ring-[#F0F6FC]/60',
        selected && 'scale-110 ring-2 ring-[#F0F6FC]',
        className,
      )}
       style={{ borderColor, boxShadow: `0 0 12px ${borderColor}44, inset 0 -10px 20px ${borderColor}12` }}
      aria-label={`${player.firstName} ${player.lastName}, рейтинг ${player.ovr}, слот ${slotPosition}`}
    >
      <span className="absolute left-1 top-1 text-[8px] text-[#F0F6FC]/60">{player.position}</span>
      <span style={{ color: ovrColor(player.ovr) }} className="text-base leading-none">
        {player.ovr}
      </span>
      {injured ? (
        <span className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-[#EF4444]">
          <Bandage className="size-2.5 text-[#0A0E17]" aria-hidden />
        </span>
      ) : null}
    </button>
  );
}

/** Подпись под фишкой: фамилия + позиция слота. */
export function ChipLabel({
  player,
  slotPosition,
  className,
}: {
  player: PlayerDTO | null;
  slotPosition: Position;
  className?: string;
}) {
  return (
    <div className={cn('pointer-events-none mt-1 max-w-[72px] text-center', className)}>
      <div className="truncate text-[10px] font-semibold leading-tight text-[#F0F6FC] drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
        {player ? player.lastName : slotPosition}
      </div>
      {player ? (
        <div className="text-[9px] leading-tight text-[#F0F6FC]/70 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
          {player.position}
        </div>
      ) : (
        <div className="text-[9px] leading-tight text-[#F0F6FC]/50">пусто</div>
      )}
    </div>
  );
}

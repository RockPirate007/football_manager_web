/**
 * Модуль 4 «Тренировки и персонал»: рынок труда тренерского штата.
 * Кандидаты — Staff-записи с teamId = null. Пул живёт своей жизнью:
 * межсезонье полностью обновляет возраст/рейтинги, каждую неделю лёгкий churn
 * (кто-то уходит, приходят новые до целевого размера — STAFF_MARKET_TARGET).
 *
 * Чистые функции; все броски RNG — в РАЗНЫЕ потоки от игровой генерации
 * (вызывающий код week.ts/career.ts передаёт собственный rng, сиды которых
 * не пересекаются с игроками/матчами/рынком игроков).
 */

import {
  STAFF_FIRE_MIN_WEEKS, STAFF_HIRE_BONUS_WEEKS, STAFF_MARKET_CHURN, STAFF_MARKET_ROLES,
  STAFF_MARKET_TARGET, STAFF_RENEW_MULT, STAFF_YEARS_MAX, STAFF_YEARS_MIN,
} from './constants';
import { NAME_POOLS, type PoolCode } from './leagues';
import { clamp, gauss, pick, randInt, type RNG } from './rng';
import { staffSalaryOf, type StaffLikeRecord, type StaffRoleCode } from './staff';

/** Специализации по ролям (косметика + лёгкие эффекты staff.ts). */
const SPECIALTIES: Record<StaffRoleCode, (string | null)[]> = {
  head_coach: ['tech', 'mental', 'phys', 'gk', 'youth', 'youth'],
  assistant: ['tech', 'mental', 'youth', 'youth', null, null],
  fitness: ['recovery', 'conditioning', null],
  physio: ['treatment', 'prevention', null],
  scout: ['talent', 'first-team', 'data', null],
};

/** Возрастные диапазоны по ролям. */
const AGE_SPAN: Record<StaffRoleCode, [number, number]> = {
  head_coach: [42, 62],
  assistant: [33, 58],
  fitness: [30, 55],
  physio: [30, 55],
  scout: [32, 60],
};

/** Все роли рынка (порядок стабильный для UI). */
export const STAFF_MARKET_ORDER: StaffRoleCode[] = [
  'head_coach', 'assistant', 'fitness', 'physio', 'scout',
];

export interface GenerateCandidateArgs {
  saveId: string;
  role: StaffRoleCode;
  /** Якорь рейтинга (сила клуба или рыночный 62). */
  anchor?: number;
  pool: PoolCode;
  idFactory: () => string;
  /** Сезон для contractUntil рынка (кандидаты без клуба — до сезона+1). */
  season: number;
}

/** Один свободный кандидат рынка (teamId = null). */
export function generateStaffCandidate(
  rng: RNG,
  args: GenerateCandidateArgs,
): StaffLikeRecord {
  const { saveId, role, pool, idFactory, season } = args;
  const anchor = args.anchor ?? 62;
  const names = NAME_POOLS[pool];
  const rating = clamp(Math.round(gauss(rng, anchor, 11)), 30, 92);
  const [ageFrom, ageTo] = AGE_SPAN[role];
  const specialties = SPECIALTIES[role];
  const specialty = pick(rng, specialties as (string | null)[]);
  // аппетит зарплаты: сильные просят больше номинала (1.0..1.25)
  const askFactor = 1 + rng() * 0.25;
  const salary = Math.round((staffSalaryOf(rating) * askFactor) / 100) * 100;
  return {
    id: idFactory(),
    saveId,
    teamId: null,
    role,
    firstName: pick(rng, names.first),
    lastName: pick(rng, names.last),
    nationality: pool,
    age: randInt(rng, ageFrom, ageTo),
    rating,
    specialty: specialty ?? null,
    salary: Math.max(600, salary),
    contractUntil: season + 1,
  };
}

/** Стартовый рынок при создании мира: STAFF_MARKET_ROLES → кандидаты. */
export function generateStaffMarket(
  rng: RNG,
  args: { saveId: string; pool: PoolCode; idFactory: () => string; season: number },
): StaffLikeRecord[] {
  const out: StaffLikeRecord[] = [];
  for (const { role, count } of STAFF_MARKET_ROLES) {
    for (let i = 0; i < count; i++) {
      out.push(generateStaffCandidate(rng, {
        saveId: args.saveId,
        role: role as StaffRoleCode,
        pool: args.pool,
        idFactory: args.idFactory,
        season: args.season,
      }));
    }
  }
  return out;
}

// ── Найм / увольнение / продление (чистые вычисления) ───────────────────────

/** Подписной бонус при найме: 4 недели зарплаты (сразу с баланса). */
export function staffHireBonusOf(candidate: { salary: number }): number {
  return Math.max(0, Math.round(candidate.salary * STAFF_HIRE_BONUS_WEEKS));
}

/** Компенсация при увольнении: зарплата × оставшиеся недели сезона (минимум 4). */
export function staffFireCompensationOf(
  employee: { salary: number },
  weeksLeftInSeason: number,
): number {
  const weeks = Math.max(STAFF_FIRE_MIN_WEEKS, weeksLeftInSeason);
  return Math.max(0, Math.round(employee.salary * weeks));
}

/** Зарплата продления: номинал по рейтингу × 1.05 (инфляция), округление к 100. */
export function staffRenewSalaryOf(employee: { rating: number; salary: number }): number {
  const nominal = staffSalaryOf(employee.rating);
  const base = Math.max(employee.salary, nominal);
  return Math.round((base * STAFF_RENEW_MULT) / 100) * 100;
}

/** Валидный срок контракта персонала. */
export function validStaffYears(years: number): boolean {
  return Number.isInteger(years) && years >= STAFF_YEARS_MIN && years <= STAFF_YEARS_MAX;
}

// ── Еженедельная ротация рынка (churn) ──────────────────────────────────────

export interface StaffMarketChurnResult {
  /** Уходящие кандидаты (delete). */
  leavingIds: string[];
  /** Новые кандидаты (create) — до целевого размера. */
  arrivals: StaffLikeRecord[];
}

/**
 * Живость рынка персонала за неделю: каждый кандидат уходит с шансом
 * STAFF_MARKET_CHURN, затем пул пополняется до STAFF_MARKET_TARGET
 * (роль новой крови — по циклу STAFF_MARKET_ROLES, чтобы роли не вымирали).
 */
export function staffMarketChurn(rng: RNG, args: {
  saveId: string;
  season: number;
  pool: PoolCode;
  idFactory: () => string;
  market: { id: string; role: string }[];
}): StaffMarketChurnResult {
  const leavingIds: string[] = [];
  for (const c of args.market) {
    if (rng() < STAFF_MARKET_CHURN) leavingIds.push(c.id);
  }
  const stayCount = args.market.length - leavingIds.length;
  let toAdd = Math.max(0, STAFF_MARKET_TARGET - stayCount);
  const arrivals: StaffLikeRecord[] = [];
  // циклический выбор ролей — пропорции пула сохраняются
  const flat: StaffRoleCode[] = STAFF_MARKET_ROLES.flatMap((r) =>
    Array.from({ length: r.count }, () => r.role as StaffRoleCode));
  let idx = randInt(rng, 0, flat.length - 1);
  while (toAdd > 0) {
    arrivals.push(generateStaffCandidate(rng, {
      saveId: args.saveId,
      role: flat[idx % flat.length],
      pool: args.pool,
      idFactory: args.idFactory,
      season: args.season,
    }));
    idx += 1;
    toAdd -= 1;
  }
  return { leavingIds, arrivals };
}

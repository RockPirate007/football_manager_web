'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Plus, Shield, Trash2, Trophy } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { readCareerSummary, useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/**
 * Полноэкранный экран «Карьера завершена» — увольнение правлением (§7.5).
 * Рендерится GameShell'ом при snapshot.save.status === 'finished':
 * поверх контента, но не поверх результата недели/церемонии.
 */
export function CareerOverScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const lastMatch = useGameStore((s) => s.lastMatch);
  const exitToCareers = useGameStore((s) => s.exitToCareers);
  const startNewCareer = useGameStore((s) => s.startNewCareer);
  const deleteSave = useGameStore((s) => s.deleteSave);
  const awardsCache = useGameStore((s) => s.awardsCache);
  const awardsLoading = useGameStore((s) => s.awardsLoading);
  const fetchAwards = useGameStore((s) => s.fetchAwards);
  const saves = useGameStore((s) => s.saves);

  const [deleteOpen, setDeleteOpen] = useState(false);

  const { save, myTeam, standings, board } = snapshot;

  // Награды: /awards доступен только активным карьерам — для уволенных
  // используем кеш сессии или список последней церемонии (fallback).
  useEffect(() => {
    if (!awardsCache) void fetchAwards(false, true);
  }, [awardsCache, fetchAwards]);

  // Сохранённые итоги карьеры (§7.5): переживают выход к списку карьер и
  // повторное открытие finished-сейва — для переходного увольнения это
  // единственный источник места/трофеев/доверия последнего сезона.
  const summary = useMemo(() => readCareerSummary(save.id), [save.id]);

  // Переходное увольнение: сессия (церемония только что закрыта) ИЛИ
  // сохранённые итоги (сейв переоткрыли из списка карьер).
  const sessionEnded = lastMatch?.seasonEnded ?? null;
  const transitionSack =
    sessionEnded?.boardVerdict?.code === 'sacked' || (summary?.transitionSacked ?? false);

  const place = useMemo(() => {
    if (transitionSack) return sessionEnded?.place ?? summary?.lastPlace ?? null;
    return standings.find((r) => r.isUser)?.place ?? null;
  }, [transitionSack, sessionEnded, summary, standings]);

  const season = transitionSack
    ? (lastMatch?.season ?? summary?.lastSeason ?? save.season - 1)
    : save.season;

  // Доверие на момент увольнения: итоговый апдейт недели (сессия/сводка),
  // иначе текущий бейдж правления (mid-season — сейв заморожен, значение честное).
  const confidence = transitionSack
    ? (lastMatch?.board?.confidence ?? summary?.lastConfidence ?? board.confidence)
    : board.confidence;

  const { seasonsAtHelm, championships, cups, awardsKnown } = useMemo(() => {
    if (awardsCache) {
      const mine = awardsCache.awards.filter(
        (a) => a.teamId === myTeam.id && (a.type === 'champion' || a.type === 'cup_winner'),
      );
      return {
        seasonsAtHelm: transitionSack ? (lastMatch?.season ?? summary?.seasonsCompleted ?? save.season - 1) : save.season,
        championships: mine.filter((a) => a.type === 'champion').length,
        cups: mine.filter((a) => a.type === 'cup_winner').length,
        awardsKnown: true,
      };
    }
    if (sessionEnded) {
      const mine = sessionEnded.awards.filter(
        (a) => a.teamId === myTeam.id && (a.type === 'champion' || a.type === 'cup_winner'),
      );
      // summary уже включает трофеи этого сезона (persistCareerSummary при
      // seasonEnded) — берём накопленное; при недоступном localStorage — только церемонию.
      return {
        seasonsAtHelm: lastMatch?.season ?? save.season,
        championships: summary?.championships ?? mine.filter((a) => a.type === 'champion').length,
        cups: summary?.cups ?? mine.filter((a) => a.type === 'cup_winner').length,
        awardsKnown: true,
      };
    }
    if (summary) {
      return {
        seasonsAtHelm: transitionSack
          ? summary.seasonsCompleted
          : summary.seasonsCompleted + 1,
        championships: summary.championships,
        cups: summary.cups,
        awardsKnown: true,
      };
    }
    return {
      seasonsAtHelm: transitionSack ? save.season - 1 : save.season,
      championships: 0,
      cups: 0,
      awardsKnown: false,
    };
  }, [awardsCache, sessionEnded, lastMatch, summary, transitionSack, myTeam.id, save.season]);

  const trophies = championships + cups;
  const limitReached = saves.length >= 8;

  const handleDelete = () => {
    setDeleteOpen(false);
    exitToCareers();
    void deleteSave(save.id);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-background/95 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Карьера завершена"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="mx-auto flex min-h-full w-full max-w-lg flex-col justify-center p-4"
      >
        <Card className="border-[#EF4444]/30">
          <CardHeader className="text-center">
            <motion.div
              initial={{ scale: 0, rotate: 8 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.15, type: 'spring', stiffness: 200, damping: 15 }}
              className="mx-auto mb-2 flex size-16 items-center justify-center rounded-full bg-[#EF4444]/15"
            >
              <Briefcase className="size-8 text-[#EF4444]" aria-hidden />
            </motion.div>
            <CardTitle className="text-xl">Карьера завершена</CardTitle>
            <div className="mt-2 flex items-center justify-center gap-2">
              <TeamCrest
                shortName={myTeam.shortName}
                colorPrimary={myTeam.colorPrimary}
                colorSecondary={myTeam.colorSecondary}
                size="sm"
              />
              <span className="truncate text-sm text-muted-foreground">
                {save.careerName} · {myTeam.name}
              </span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Правление отправило вас в отставку
              {transitionSack ? (
                <>
                  . Сезон <span className="font-bold text-foreground tabular">{season}</span>
                  {place !== null ? (
                    <>
                      , <span className="font-bold text-foreground tabular">{place}</span>-е место
                    </>
                  ) : null}
                  , доверие{' '}
                  <span className="font-bold text-[#EF4444] tabular">{confidence}/100</span>.
                </>
              ) : (
                <>
                  {' '}после{' '}
                  <span className="font-bold text-foreground tabular">{save.week - 1}</span>{' '}
                  недель сезона{' '}
                  <span className="font-bold text-foreground tabular">{season}</span>
                  {place !== null ? (
                    <>
                      , <span className="font-bold text-foreground tabular">{place}</span>-е место
                    </>
                  ) : null}
                  , доверие{' '}
                  <span className="font-bold text-[#EF4444] tabular">{confidence}/100</span>.
                </>
              )}
            </p>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Сводка карьеры */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
                <div className="tabular text-xl font-bold text-foreground">{seasonsAtHelm}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">Сезонов у руля</div>
              </div>
              <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
                {awardsLoading && !awardsCache ? (
                  <Skeleton className="mx-auto h-7 w-10" />
                ) : (
                  <div className="tabular text-xl font-bold text-[#EAB308]">
                    {awardsKnown ? trophies : '—'}
                  </div>
                )}
                <div className="mt-0.5 text-[11px] text-muted-foreground">Трофеев</div>
              </div>
              <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
                <div className="tabular text-xl font-bold text-foreground">
                  {place !== null ? place : '—'}
                </div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">Место в лиге</div>
              </div>
            </div>

            {/* Трофеи (если известны) */}
            {awardsKnown && trophies > 0 ? (
              <div className="flex flex-wrap items-center justify-center gap-2">
                {championships > 0 ? (
                  <Badge className="border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
                    <Trophy className="size-3" aria-hidden />
                    Чемпион ×{championships}
                  </Badge>
                ) : null}
                {cups > 0 ? (
                  <Badge className="border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
                    <Shield className="size-3" aria-hidden />
                    Кубок ×{cups}
                  </Badge>
                ) : null}
              </div>
            ) : null}

            {/* Действия */}
            <div className="flex flex-col gap-2">
              <Button
                size="lg"
                className="h-12 w-full text-base"
                onClick={startNewCareer}
                disabled={limitReached}
                title={limitReached ? 'Достигнут лимит 8 карьер — удалите одну из них' : undefined}
              >
                <Plus className="size-5" aria-hidden />
                Новая карьера
              </Button>
              <Button
                size="lg"
                variant="secondary"
                className="h-12 w-full text-base"
                onClick={exitToCareers}
              >
                К списку карьер
              </Button>
              <Button
                variant="outline"
                className="min-h-11 w-full border-[#EF4444]/40 text-[#EF4444] hover:bg-[#EF4444]/10"
                onClick={() => setDeleteOpen(true)}
              >
                <Trash2 className="size-4" aria-hidden />
                Удалить карьеру
              </Button>
            </div>

            <p className={cn('text-center text-[11px] leading-relaxed text-muted-foreground')}>
              Все серверные действия в этой карьере заблокированы — статистика и история
              сезонов остались в базе для памяти.
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Подтверждение удаления */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить карьеру «{save.careerName}»?</AlertDialogTitle>
            <AlertDialogDescription>
              Карьера удаляется навсегда — вместе с клубом, составом, результатами и
              историей сезонов. Это действие нельзя отменить.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="min-h-11">Оставить</AlertDialogCancel>
            <AlertDialogAction
              className="min-h-11 bg-[#C0392B] text-white hover:bg-[#A93226]"
              onClick={(e) => {
                e.preventDefault();
                handleDelete();
              }}
            >
              <Trash2 className="size-4" aria-hidden />
              Удалить навсегда
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

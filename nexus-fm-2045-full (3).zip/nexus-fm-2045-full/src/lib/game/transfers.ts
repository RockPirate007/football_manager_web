/**
 * Трансферы: генерация рынка, формула стоимости, покупка/продажа.
 * Раздел 4.12 docs/architecture.md.
 */

import {
  LISTING_TTL, MARKET_SIZE_MAX, MARKET_SIZE_MIN, SELL_PRICE_MAX_RATIO,
  SELL_PRICE_MIN_RATIO,
} from './constants';
import { generatePlayer, type PlayerLike } from './players';
import { pick, pickWeighted, randInt, type RNG } from './rng';
import { clamp } from './rng';
import type { NamePoolContext } from './leagues';
import type { Position } from './types';

export { computeValue, computeSalary } from './players';

export interface MarketListingGen {
  player: PlayerLike; // teamId = null
  price: number;
  askFactor: number;
  expiresAt: number;
}

/** Распределение позиций рынка: GK 10%, DEF 30%, MID 35%, FWD 25%. */
export function marketPosition(rng: RNG): Position {
  const roll = rng();
  if (roll < 0.1) return 'GK';
  if (roll < 0.4) return pick(rng, ['DL', 'DC', 'DR'] as Position[]);
  if (roll < 0.75) {
    return pick(rng, ['DML', 'DMC', 'DMR', 'ML', 'MC', 'MR', 'AML', 'AMC', 'AMR'] as Position[]);
  }
  return 'ST';
}

/** Новый лот рынка: OVR-цель 45..75, возраст 16..34, askFactor 1.0..1.3 (пул имён лиги). */
export function generateMarketListing(rng: RNG, pool?: NamePoolContext): MarketListingGen {
  const targetOvr = randInt(rng, 45, 75);
  const position = marketPosition(rng);
  const player = generatePlayer(rng, targetOvr, position, { minAge: 16, maxAge: 34, pool });
  player.teamId = null;
  const askFactor = 0.1 * randInt(rng, 10, 13);
  const price = Math.max(10_000, Math.round(player.value * askFactor));
  return { player, price, askFactor, expiresAt: LISTING_TTL };
}

/** Догенерация рынка до MARKET_SIZE_MIN..MAX активных лотов. */
export function marketTopUpCount(rng: RNG, currentActive: number): number {
  const target = randInt(rng, MARKET_SIZE_MIN, MARKET_SIZE_MAX);
  return Math.max(0, target - currentActive);
}

/** Вероятность оффера на свой лот за тур. */
export function sellOfferProbability(price: number, value: number): number {
  const ratio = value > 0 ? price / value : SELL_PRICE_MAX_RATIO;
  return clamp(0.9 - 0.35 * (ratio - SELL_PRICE_MIN_RATIO), 0.15, 0.95);
}

/** Подсказка интереса для UI. */
export function interestLevel(price: number, value: number): 'высокий' | 'средний' | 'низкий' {
  const p = sellOfferProbability(price, value);
  if (p >= 0.7) return 'высокий';
  if (p >= 0.4) return 'средний';
  return 'низкий';
}

/** Границы цены продажи своего игрока. */
export function sellPriceBounds(value: number): { min: number; max: number } {
  return {
    min: Math.round(value * SELL_PRICE_MIN_RATIO),
    max: Math.round(value * SELL_PRICE_MAX_RATIO),
  };
}

/** Случайная ИИ-команда покупает самый дешёвый «по карману» лот (market ИЛИ free — дренаж рынка фри-агентов, Фаза 3). */
export function pickAiPurchase(
  rng: RNG,
  aiBudgets: { teamId: string; budget: number }[],
  listings: { listingId: string; price: number; source: string }[],
): { teamId: string; listingId: string; price: number } | null {
  const affordable = new Set<string>();
  for (const team of aiBudgets) {
    if (team.budget <= 0) continue;
    affordable.add(team.teamId);
  }
  if (affordable.size === 0) return null;

  const marketListings = listings
    .filter((l) => l.source === 'market' || l.source === 'free')
    .sort((a, b) => a.price - b.price);
  if (marketListings.length === 0) return null;

  const cheapest = marketListings[0];
  const buyers = aiBudgets.filter((t) => t.budget >= cheapest.price);
  if (buyers.length === 0) return null;

  const buyer = pickWeighted(
    rng,
    buyers.map((b) => ({ item: b, weight: 1 })),
  );
  return { teamId: buyer.teamId, listingId: cheapest.listingId, price: cheapest.price };
}

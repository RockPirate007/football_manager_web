import { cn } from '@/lib/utils';
import { positionGroupOf } from '@/lib/game/players';
import type { Position, PositionGroup } from '@/lib/game/types';

/** Цвета групп позиций — палитра NEXUS FM 2045 (GK — жёлтый, DEF — стальной,
 * MID — неон-циан, AM — фиолет, ST — оранж). */
const GROUP_STYLE: Record<PositionGroup, string> = {
  GK: 'bg-[#FACC15]/15 text-[#FACC15] border-[#FACC15]/30',
  DEF: 'bg-[#7B8CA3]/15 text-[#7B8CA3] border-[#7B8CA3]/30',
  DM: 'bg-[#7B8CA3]/15 text-[#7B8CA3] border-[#7B8CA3]/30',
  MID: 'bg-[#00D4FF]/15 text-[#00D4FF] border-[#00D4FF]/30',
  AM: 'bg-[#A78BFA]/15 text-[#A78BFA] border-[#A78BFA]/30',
  ST: 'bg-[#FF6B35]/15 text-[#FF6B35] border-[#FF6B35]/30',
};

/** Цветной бейдж позиции: GK — жёлтый, DEF — серо-голубой, MID — зелёный, FWD — оранжевый. */
export function PositionBadge({
  position,
  className,
}: {
  position: Position;
  className?: string;
}) {
  const group = positionGroupOf(position);
  return (
    <span
      className={cn(
        'inline-flex h-5 min-w-9 items-center justify-center rounded border px-1 text-[10px] font-bold tracking-wide',
        GROUP_STYLE[group],
        className,
      )}
      aria-label={`Позиция ${position}`}
    >
      {position}
    </span>
  );
}

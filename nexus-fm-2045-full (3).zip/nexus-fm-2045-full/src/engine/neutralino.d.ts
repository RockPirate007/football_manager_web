/**
 * Минимальные ambient-декларации Neutralino client API (v6) — только то, что
 * использует src/engine/storage.ts (спека §2.2, скопы §7). Полный набор
 * (window, events, storage, os, computer...) не нужен движку.
 * /neutralino.js подключается layout.tsx на этапе D-4.
 */

/** Neutralino filesystem API (неймспейс window.Neutralino.filesystem). */
interface NeutralinoFilesystem {
  createDirectory(path: string): Promise<void>;
  readFile(path: string): Promise<string>;
  writeFile(path: string, data: string): Promise<void>;
  /** Атомарная запись: пишем в .tmp, затем move на целевой путь. */
  move(source: string, destination: string): Promise<void>;
  removeFile(path: string): Promise<void>;
}

/** Neutralino client API (глобал window.Neutralino). */
interface NeutralinoApi {
  /** Подключение к нативному серверу (WebSocket); вызывается один раз при bootstrap. */
  init(): Promise<void>;
  readonly filesystem: NeutralinoFilesystem;
}

interface Window {
  /** Инжектируется /neutralino.js; отсутствует в браузере без десктоп-обёртки. */
  Neutralino?: NeutralinoApi;
}

/** Neutralino-глобал, инжектируемый в режиме приложения (mode.window). */
declare const NL_APPDATA: string | undefined;

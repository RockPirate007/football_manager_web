/**
 * Все типы игры «Футбольный Менеджер» (DTO, события матча, снапшот).
 * Модуль изоморфный (используется и на сервере, и на клиенте).
 * Соответствует разделам 3–7 docs/architecture.md + Фаза 3 (architecture-phase3.md §6).
 */

import type { AiStyleCode, BoardTargetCode } from './constants';
import { MATCH_PLAN_DEFAULT } from './constants';

export type { AiStyleCode, BoardTargetCode };

// ── Позиции ──────────────────────────────────────────────────────────────

export type Position =
  | 'GK' | 'DL' | 'DC' | 'DR' | 'DML' | 'DMC' | 'DMR'
  | 'ML' | 'MC' | 'MR' | 'AML' | 'AMC' | 'AMR' | 'ST';

/** 6 групп позиций (для positionFit и фильтров UI). */
export type PositionGroup = 'GK' | 'DEF' | 'DM' | 'MID' | 'AM' | 'ST';

export const ALL_POSITIONS: Position[] = [
  'GK', 'DL', 'DC', 'DR', 'DML', 'DMC', 'DMR',
  'ML', 'MC', 'MR', 'AML', 'AMC', 'AMR', 'ST',
];

// ── Атрибуты ─────────────────────────────────────────────────────────────

export type FieldAttrKey =
  | 'finishing' | 'passing' | 'dribbling' | 'crossing' | 'tackling'
  | 'marking' | 'positioning' | 'heading' | 'pace' | 'stamina'
  | 'strength' | 'aggression'
  // ── Engine 2.0: ментальные ──
  | 'vision' | 'decisions' | 'leadership'
  // ── Engine 2.0: физические ──
  | 'acceleration' | 'jumping';

export type GkAttrKey = 'reflexes' | 'rushingOut' | 'kicking' | 'handling';

export type AttrKey = FieldAttrKey | GkAttrKey;

/** Скрытые параметры — не показываются в UI напрямую, туман войны скаутинга. */
export type HiddenAttrKey = 'injuryProneness' | 'consistency';

export const ATTR_LABELS: Record<AttrKey, string> = {
  finishing: 'Финиш',
  passing: 'Пас',
  dribbling: 'Дриблинг',
  crossing: 'Кроссы',
  tackling: 'Отбор',
  marking: 'Опека',
  positioning: 'Позиционирование',
  heading: 'Игра головой',
  pace: 'Скорость',
  stamina: 'Выносливость',
  strength: 'Сила',
  aggression: 'Агрессия',
  // ── Engine 2.0: ментальные ──
  vision: 'Видение поля',
  decisions: 'Решения',
  leadership: 'Лидерство',
  // ── Engine 2.0: физические ──
  acceleration: 'Ускорение',
  jumping: 'Прыгучесть',
  // ── вратарские ──
  reflexes: 'Рефлексы',
  rushingOut: 'Выходы',
  kicking: 'Ввод мяча',
  handling: 'Надёжность рук',
};

/** Группы атрибутов для карточки игрока (Engine 2.0). */
export const ATTR_GROUPS: { key: 'tech' | 'mental' | 'phys' | 'gk'; label: string; keys: AttrKey[] }[] = [
  { key: 'tech', label: 'Технические', keys: ['finishing', 'passing', 'dribbling', 'crossing', 'tackling', 'marking', 'heading'] },
  { key: 'mental', label: 'Ментальные', keys: ['vision', 'decisions', 'positioning', 'leadership', 'aggression'] },
  { key: 'phys', label: 'Физические', keys: ['pace', 'acceleration', 'stamina', 'strength', 'jumping'] },
  { key: 'gk', label: 'Вратарские', keys: ['reflexes', 'rushingOut', 'kicking', 'handling'] },
];

export interface Attributes {
  finishing: number;
  passing: number;
  dribbling: number;
  crossing: number;
  tackling: number;
  marking: number;
  positioning: number;
  heading: number;
  pace: number;
  stamina: number;
  strength: number;
  aggression: number;
  // ── Engine 2.0: ментальные ──
  vision: number;
  decisions: number;
  leadership: number;
  // ── Engine 2.0: физические ──
  acceleration: number;
  jumping: number;
  // ── вратарские ──
  reflexes: number;
  rushingOut: number;
  kicking: number;
  handling: number;
}

// ── Тактика ──────────────────────────────────────────────────────────────

export type FormationId =
  | '4-4-2' | '4-3-3' | '4-2-3-1' | '4-5-1'
  | '3-5-2' | '5-3-2' | '4-1-4-1' | '3-4-3';

export type FormationClass =
  | 'balanced' | 'flank_attack' | 'center_attack'
  | 'defensive' | 'flank_mid' | 'dense';

export type Mentality = 'defensive' | 'cautious' | 'balanced' | 'attacking' | 'allout';
export type TempoLevel = 'low' | 'medium' | 'high';
export type PressingLevel = 'low' | 'medium' | 'high';
export type DefLineLevel = 'low' | 'medium' | 'high';
export type PlayStyle = 'balanced' | 'wing' | 'passing' | 'long' | 'counter';
export type WidthLevel = 'narrow' | 'normal' | 'wide';

export const WIDTH_LABELS: Record<WidthLevel, string> = {
  narrow: 'Узко',
  normal: 'Обычно',
  wide: 'Широко',
};

export const MENTALITY_LABELS: Record<Mentality, string> = {
  defensive: 'Оборонительный',
  cautious: 'Осторожный',
  balanced: 'Сбалансированный',
  attacking: 'Атакующий',
  allout: 'Тотальный',
};

export const TEMPO_LABELS: Record<TempoLevel, string> = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий',
};

export const PRESSING_LABELS: Record<PressingLevel, string> = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий',
};

export const DEF_LINE_LABELS: Record<DefLineLevel, string> = {
  low: 'Низкая',
  medium: 'Средняя',
  high: 'Высокая',
};

export const PLAY_STYLE_LABELS: Record<PlayStyle, string> = {
  balanced: 'Обычный',
  wing: 'Фланги',
  passing: 'Владение',
  long: 'Длинный мяч',
  counter: 'Контратаки',
};

export interface TacticSettings {
  formation: FormationId;
  mentality: Mentality;
  tempo: TempoLevel;
  pressing: PressingLevel;
  defLine: DefLineLevel;
  playStyle: PlayStyle;
}

/** Тело POST /api/game/tactic. */
export interface TacticPayload extends TacticSettings {
  lineup: string[]; // ровно 11 id (порядок = слоты формации)
  bench: string[]; // до 7 id
}

// ── Игрок / команды (DTO) ────────────────────────────────────────────────

export interface PlayerDTO extends Attributes {
  id: string;
  teamId: string | null;
  firstName: string;
  lastName: string;
  nationality: string;
  position: Position;
  shirtNumber: number;
  age: number;
  potential: number;
  ovr: number;
  morale: number;
  condition: number;
  injuryWeeks: number;
  value: number;
  salary: number;
  goals: number;
  assists: number;
  apps: number;
  yellowCards: number;
  redCards: number;
  cleanSheets: number;
  cupGoals: number;
  cupAssists: number;
  // ── Фаза 4: Кубок Европы ──
  euroGoals: number;
  euroAssists: number;
  /** Запрошенная цена, если игрок выставлен на продажу (активный лот). */
  askingPrice: number | null;
  // ── Фаза 3 ──
  contractUntil: number; // последний сезон действия контракта (включительно)
  /** Средний рейтинг текущего сезона (6.8) или null — не играл. */
  avgRating: number | null;
  /** Босман: уходит в конце сезона по предконтракту. */
  preContract: boolean;
  // ── Engine 2.0: контрактные бонусы + туман войны ──
  /** Премия за гол, €/шт. */
  goalBonus: number;
  /** Премия за сухой матч, €/шт. */
  cleanSheetBonus: number;
  /** Знания о игроке 0..100 (100 = свой игрок или полностью проскаутлен). */
  scoutKnowledge: number;
  /** При знании <70 атрибуты/потенциал в DTO — детерминированные ОЦЕНКИ (не точные). */
  potentialRange: [number, number];
  /** Id назначенного скаута (null = не наблюдается). */
  scoutedBy: string | null;
}

// ── D-5 «Территория»: здания клуба (§3.6) ──────────────────────────────────

/** Карточка здания для UI: всё посчитано в snapshot.ts — UI ничего не считает. */
export interface BuildingCardDTO {
  id: string; // BuildingId из каталога §3.1
  name: string;
  /** Текущий уровень 0..5. */
  level: number;
  /** Абсолютный день окончания стройки (null = стройки нет). */
  upgradeEndsAtDay: number | null;
  /** Цена следующего уровня (null на L5 — максимум). */
  priceNext: number | null;
  /** Дни постройки следующего уровня (null на L5; при стройке = её длительность). */
  daysNext: number | null;
  /** Еженедельное содержание этого здания (0 при L=0). */
  upkeepWeekly: number;
}

/** Массив 8 карточек зданий клуба игрока (порядок каталога §3.1). */
export type BuildingsDTO = BuildingCardDTO[];

export interface TeamDTO extends TacticSettings {
  id: string;
  name: string;
  shortName: string;
  city: string | null;
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  isUserTeam: boolean;
  stadiumCapacity: number;
  lineup: string[] | null;
  bench: string[] | null;
  // ── Фаза 4: стиль/план (клуб игрока: balanced + план из Team.matchPlan) ──
  aiStyle: AiStyleCode;
  aiCoachName: string | null;
  matchPlan: MatchPlanDTO;
  // ── D-5 «Территория»: инфраструктура клуба (8 карточек, §3.6) ──
  buildings: BuildingsDTO;
  // ── Модуль 5: расширение стадиона ──
  /** Места в стройке (0 = стройки нет). */
  stadiumPending: number;
  /** Абсолютный день окончания стройки (null = стройки нет). */
  stadiumUpgradeEndsAtDay: number | null;
}

export interface TeamBriefDTO {
  id: string;
  name: string;
  shortName: string;
  city: string | null;
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  isUser: boolean;
  /** Тактика соперника для превью матча. */
  formation: FormationId;
  mentality: Mentality;
  // ── Фаза 4: бейдж стиля тренера (null у клуба игрока) ──
  coachStyle?: AiStyleCode | null;
  coachName?: string | null;
}

export interface ClubDTO {
  id: string;
  name: string;
  shortName: string;
  city: string | null;
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  stadiumCapacity: number;
  startBalance: number;
}

// ── D-6 «Тренер»: личная жизнь менеджера (§4.6) ──────────────────────────

/** Карточка актива: каталог + владение (всё посчитано в движке, §4.6). */
export interface AssetDTO {
  id: string; // AssetId каталога §4.2
  name: string;
  category: 'realty' | 'auto' | 'yacht';
  /** Цена покупки (€). */
  price: number;
  /** Престиж при покупке (×10 → отображение /10). */
  prestige: number;
  /** Содержание (€/нед). */
  upkeepWeekly: number;
  owned: boolean;
  /** Цена продажи 70 % (§4.2). */
  sellPrice: number;
}

/** Семья менеджера: таймлайн для экрана «Тренер» (§4.7). */
export interface FamilyDTO {
  marriedAtWeek: number | null;
  spouseName: string | null;
  child: {
    name: string;
    gender: 'м' | 'д';
    age: number;
    bornAtWeek: number;
    joinedAcademyPlayerId: string | null;
    /** Сезонов до академии (14 − age; null — уже в академии). */
    seasonsToAcademy: number | null;
  } | null;
}

/** Шкала эффектов престижа для подписей UI (§4.3/§4.7). */
export interface ManagerEffectsDTO {
  /** Множитель зарплатного спроса при продлении (0.95 | 1 | 1.05). */
  contractsDemandMult: number;
  /** p ≥ 75.0: цена на рынке ×0.95. */
  marketDiscount: boolean;
  /** p < 60.0: звёзды (OVR ≥ 80) не хотят перехода — цена ×1.10. */
  marketStarPremium: boolean;
  /** Эффективный порог предупреждения правления (30 | 25). */
  boardWarnBelow: number;
}

/** Профиль менеджера (GET /manager, §4.6): UI ничего не считает. */
export interface ManagerDTO {
  /** Имя менеджера (профиль-карточка). */
  name: string;
  /** Клуб менеджера (профиль-карточка). */
  clubName: string;
  /** Текущий сезон = «стаж» в клубе. */
  season: number;
  age: number;
  /** ЛИЧНЫЙ кошелёк (отдельно от баланса клуба). */
  wallet: number;
  salary: number;
  /** Престиж 0..100 (хранение ×10 → /10, 1 знак). */
  prestige: number;
  prestigeLabel: string;
  assets: AssetDTO[];
  family: FamilyDTO | null;
  /** Чистый недельный поток кошелька: зарплата − содержание активов. */
  netWeekly: number;
  effects: ManagerEffectsDTO;
}

export interface ManagerResponse {
  ok: true;
  manager: ManagerDTO;
}

export interface ManagerAssetResponse {
  ok: true;
  manager: ManagerDTO;
}

// ── D-7 «Медиа»: газетные вырезки (§5.4/§5.6) ─────────────────────────────

/** Соревнование вырезки; 'academy' — спецвыпуск «сын в академии» (matchId=null). */
export type PressCompetition = 'league' | 'cup' | 'euro' | 'academy';

/** Карточка-момент полосы (§5.3): минута + готовый event.text движка. */
export interface PressMomentDTO {
  minute: number;
  kind: 'goal' | 'red' | 'pens' | 'injury' | 'yellow';
  text: string;
}

/** Игрок матча (§5.3): rating 4.5–10.0 (хранение ×10 → DTO /10). */
export interface PressMotmDTO {
  playerId: string;
  name: string;
  position: Position;
  rating: number;
}

/** Вырезка газеты (GET /media, §5.6): DTO = запись с rating/10. */
export interface NewspaperClippingDTO {
  id: string;
  season: number;
  week: number;
  /** null для special_son (academy). */
  matchId: string | null;
  competition: PressCompetition;
  /** Контекст классификатора §5.2 (11 значений). */
  context: string;
  /** ≤70 знаков (§5.2). */
  headline: string;
  /** ≤120 знаков (§5.2). */
  subheadline: string;
  homeName: string;
  awayName: string;
  homeGoals: number;
  awayGoals: number;
  homePens: number | null;
  awayPens: number | null;
  motm: PressMotmDTO | null;
  /** Выдержка с топ-2 оценками + фраза-клише (§5.3). */
  excerpt: string;
  moments: PressMomentDTO[];
  /** ISO — время создания выпуска. */
  createdAt: string;
}

/** GET /media (§5.6): страница архива (сорт season desc, week desc, createdAt desc). */
export interface MediaResponse {
  ok: true;
  clippings: NewspaperClippingDTO[];
  total: number;
}

// ── Лиги (Фаза 2) ───────────────────────────────────────────────────────

/** Код лиги (leagues.ts — единственный источник данных лиг). */
export type LeagueCode = 'EPL' | 'LAL' | 'SEA' | 'BUN' | 'FL1' | 'RPL';

// ── Матч ─────────────────────────────────────────────────────────────────

export type MatchEventType =
  | 'kickoff' | 'goal' | 'yellow' | 'red' | 'injury'
  | 'chance' | 'halftime' | 'fulltime'
  | 'pen_goal' | 'pen_miss' | 'pen_save'
  | 'sub' // ── Фаза 4: замена
  // ── Engine 2.0: детальные события ленты/радара ──
  | 'shot_on' // удар в створ (сейв вратаря)
  | 'shot_off' // удар мимо створа
  | 'save' // эффектный сейв (gkName)
  | 'corner' // угловой
  | 'offside' // офсайд
  | 'duel' // ключевая дуэль (отбор/дриблинг) — «искры» матча
  | 'momentum'; // перелом хода игры (для momentum-бара)

export interface MatchEvent {
  minute: number; // 0..93 (пенальти: 95+)
  type: MatchEventType;
  teamId?: string;
  playerId?: string;
  playerName?: string;
  assistId?: string;
  assistName?: string;
  /** Имя вратаря для событий pen_save / save. */
  gkName?: string;
  /** Фаза 4: замена — playerId/playerName = кто ВЫШЕЛ, subOut* = кто сошёл. */
  subOutId?: string;
  subOutName?: string;
  /** Engine 2.0: координаты события на поле 0..100 (2D-радар); X — атака хозяев слева направо. */
  x?: number;
  y?: number;
  text: string;
}

export interface MatchStats {
  possessionHome: number;
  shotsHome: number;
  shotsAway: number;
  sotHome: number;
  sotAway: number;
  cornersHome: number;
  cornersAway: number;
  foulsHome: number;
  foulsAway: number;
  yellowsHome: number;
  yellowsAway: number;
  redsHome: number;
  redsAway: number;
  /** Engine 2.0: ожидаемые голы ×10 (13 = 1.3); отсутствует у легаси-матчей. */
  xgHome?: number;
  xgAway?: number;
}

/** Тип соревнования (Фаза 4: + 'euro'). */
export type Competition = 'league' | 'cup' | 'euro';

export interface FixtureDTO {
  id: string;
  week: number;
  competition: Competition;
  cupRound: number | null;
  homeTeamId: string;
  homeName: string;
  homeShort: string;
  homePrimary: string;
  homeSecondary: string;
  awayTeamId: string;
  awayName: string;
  awayShort: string;
  awayPrimary: string;
  awaySecondary: string;
  homeGoals: number | null;
  awayGoals: number | null;
  homePens: number | null;
  awayPens: number | null;
  played: boolean;
  isUserMatch: boolean;
  isNeutral: boolean;
}

/** Компактная запись матча сезона — для календаря лиги и кубка. */
export interface SeasonMatchDTO {
  id: string;
  week: number;
  competition: Competition;
  cupRound: number | null;
  homeTeamId: string;
  awayTeamId: string;
  homeGoals: number | null;
  awayGoals: number | null;
  played: boolean;
}

export interface MatchDetailsDTO {
  id: string;
  week: number;
  season: number;
  competition: Competition;
  cupRound: number | null;
  home: TeamBriefDTO;
  away: TeamBriefDTO;
  homeGoals: number;
  awayGoals: number;
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string | null;
  isNeutral: boolean;
  played: boolean;
  events: MatchEvent[];
  stats: MatchStats | null;
}

// ── Лига ─────────────────────────────────────────────────────────────────

export type FormResult = 'W' | 'D' | 'L';

export interface StandingRow {
  teamId: string;
  name: string;
  shortName: string;
  colorPrimary: string;
  colorSecondary: string;
  isUser: boolean;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDiff: number;
  points: number;
  place: number;
  form: FormResult[];
}

// ── Новости / финансы ────────────────────────────────────────────────────

export type NewsType =
  | 'result' | 'transfer' | 'injury' | 'market' | 'finance' | 'info'
  | 'training' | 'cup' | 'board' | 'academy'
  | 'euro' // ── Фаза 4: Кубок Европы
  | 'manager'; // ── D-6 «Тренер»: личная жизнь (покупки/семья/кошелёк)

export interface NewsDTO {
  id: string;
  season: number;
  week: number;
  type: NewsType;
  message: string;
}

export type FinanceKind = 'income' | 'expense';
export type FinanceCategory =
  | 'sponsor' | 'tickets' | 'prize' | 'cup_prize' | 'euro_prize' | 'transfer_in' | 'transfer_out' | 'wages'
  // ── D-5 «Территория» (§3.2/§3.5): содержание/стройка/мерчандайз/VIP ──
  | 'building' | 'construction' | 'merch' | 'vip'
  // ── D-6 «Тренер» (§4): зарплата менеджера — категория объявлена заранее ──
  | 'coach_wages'
  // ── Модуль 4: зарплаты тренерского штата ──
  | 'staff_wages'
  // ── Модуль 5: ТВ-отчисления лиги ──
  | 'tv';

export interface FinanceDTO {
  id: string;
  season: number;
  week: number;
  kind: FinanceKind;
  category: FinanceCategory;
  amount: number;
  description: string;
}

export interface FinanceSummaryDTO {
  weeklyWages: number;
  weeklyIncome: number;
  wageRatio: number;
  records: FinanceDTO[];
  seasonIncome: number;
  seasonExpense: number;
  // ── Модуль 5: бюджеты правления + отчёт по статьям ──
  /** Итоги сезона по статьям (сортировка по убыванию оборота). */
  byCategory: FinanceCategoryRowDTO[];
  /** Трансферный бюджет (остаток, €). */
  transferBudget: number;
  /** Зарплатный бюджет (потолок ведомости, €/нед). */
  wageBudget: number;
  /** Фактическая ведомость игроков €/нед (для шкалы использования). */
  wagesActual: number;
  // ── Модуль 6: недельный поток для графика (текущий сезон, по возрастанию недели) ──
  weekly: FinanceWeekPointDTO[];
}

/** Точка недельного финансового ряда (Модуль 6: Recharts). */
export interface FinanceWeekPointDTO {
  week: number;
  income: number;
  expense: number;
  net: number;
}

/** Строка отчёта по статье бюджета сезона (Модуль 5). */
export interface FinanceCategoryRowDTO {
  category: FinanceCategory;
  label: string;
  income: number;
  expense: number;
}

// ── Снапшот состояния игры (GET /api/game/state) ─────────────────────────

// ── Кубок / тренировки / награды / недели (Фаза 2) ────────────────────────

export interface WeekInfoDTO {
  week: number;
  totalWeeks: number;
  type: 'league' | 'cup';
  label: string; // 'Тур 12/38' | 'Кубок · 1/4 финала' | 'Кубок · Финал'
  leagueRound: number | null;
  cupRound: number | null;
  cupRoundLabel: string | null;
}

export interface LeagueInfoDTO {
  code: LeagueCode;
  nameRu: string;
  country: string;
  flag: string;
  teamCount: number;
  leagueWeeks: number;
  cupName: string;
  difficulty: string;
}

export interface CupMatchDTO {
  id: string;
  home: TeamBriefDTO | null; // null = пара ещё не разведена
  away: TeamBriefDTO | null;
  homeGoals: number | null;
  awayGoals: number | null;
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string | null;
  played: boolean;
  isUserMatch: boolean;
  isNeutral: boolean;
}

export interface CupRoundDTO {
  round: number;
  label: string;
  week: number;
  drawn: boolean;
  matches: CupMatchDTO[];
}

export interface CupSnapshotDTO {
  cupName: string;
  currentRound: number; // следующий к игре (или последний сыгранный)
  myStatus: 'not_started' | 'alive' | 'eliminated' | 'winner';
  myEliminatedRound: number | null;
  rounds: CupRoundDTO[];
}

// ── План на матч (Фаза 4, §3.2 architecture-phase4.md) ────────────────────

export interface MatchPlanDTO {
  leadMode: 'park' | 'hold';
  chaseMode: 'allout' | 'steady';
  fatigueSubs: boolean;
}

export interface MatchPlanResponse {
  ok: true;
  plan: MatchPlanDTO;
}

export interface SetMatchPlanResponse {
  ok: true;
  plan: MatchPlanDTO;
}

/** Толерантный парсер Team.matchPlan (JSON) — легаси/null/битый JSON → дефолт. */
export function parseMatchPlan(raw: string | null | undefined): MatchPlanDTO {
  const fallback: MatchPlanDTO = { ...MATCH_PLAN_DEFAULT };
  if (!raw) return fallback;
  try {
    const data: unknown = JSON.parse(raw);
    if (typeof data !== 'object' || data === null) return fallback;
    const rec = data as Record<string, unknown>;
    if (
      (rec.leadMode !== 'park' && rec.leadMode !== 'hold')
      || (rec.chaseMode !== 'allout' && rec.chaseMode !== 'steady')
      || typeof rec.fatigueSubs !== 'boolean'
    ) {
      return fallback;
    }
    return {
      leadMode: rec.leadMode,
      chaseMode: rec.chaseMode,
      fatigueSubs: rec.fatigueSubs,
    };
  } catch {
    return fallback;
  }
}

// ── Кубок Европы (Фаза 4, §3.4 architecture-phase4.md) ───────────────────

export interface EuroTeamDTO {
  id: string;
  name: string;
  shortName: string;
  leagueCode: LeagueCode;
  leagueFlag: string;
  leagueName: string; // «гость из Ла Лиги»
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  isUser: boolean;
  isGuest: boolean;
  coachStyle: AiStyleCode | null;
  coachName: string | null;
}

/** Аналог CupMatchDTO с флагами лиг (для бейджей «гость из …»). */
export interface EuroMatchDTO {
  id: string;
  home: EuroTeamDTO | null; // null = пара ещё не разведена
  away: EuroTeamDTO | null;
  homeGoals: number | null;
  awayGoals: number | null;
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string | null;
  played: boolean;
  isUserMatch: boolean;
  isNeutral: boolean;
}

export interface EuroRoundDTO {
  round: number;
  label: string;
  week: number;
  drawn: boolean;
  matches: EuroMatchDTO[];
}

export interface EuroSnapshotDTO {
  status: 'not_started' | 'qualified' | 'alive' | 'eliminated' | 'winner';
  currentRound: number;
  myEliminatedRound: number | null;
  rounds: EuroRoundDTO[]; // ровно 4
  /** 16 участников сезона (после жеребьёвки 1/8; до — по квалификации). */
  participants: EuroTeamDTO[];
  quotas: { code: LeagueCode; flag: string; quota: number }[];
  nextEuroMatch: { round: number; label: string; opponent: EuroTeamDTO; week: number; isHome: boolean } | null;
}

export interface EuroResponse {
  ok: true;
  euro: EuroSnapshotDTO;
}

export type TrainingFocus = 'attack' | 'defense' | 'possession' | 'physical' | 'goalkeepers' | 'rest';
export type TrainingIntensity = 'light' | 'normal' | 'hard';

export interface TrainingStateDTO {
  focus: TrainingFocus;
  intensity: TrainingIntensity;
}

export interface PlayerLeaderDTO {
  playerId: string;
  name: string;
  teamId: string;
  teamName: string;
  teamShort: string;
  colorPrimary: string;
  colorSecondary: string;
  isUser: boolean;
  goals: number;
  assists: number;
  apps: number;
  ovr: number;
}

export interface LeagueLeadersDTO {
  topScorers: PlayerLeaderDTO[];
  topAssists: PlayerLeaderDTO[];
}

export interface SeasonAwardDTO {
  id: string;
  season: number;
  type: string;
  typeName: string;
  playerId: string | null;
  playerName: string | null;
  teamId: string;
  teamName: string;
  value: number;
  label: string;
}

export const AWARD_TYPE_LABELS: Record<string, string> = {
  top_scorer: 'Золотая бутса',
  top_assist: 'Лучший ассистент',
  mvp: 'Игрок сезона',
  young: 'Лучший молодой игрок',
  golden_glove: 'Золотая перчатка',
  cup_scorer: 'Бомбардир кубка',
  champion: 'Чемпион',
  cup_winner: 'Обладатель кубка',
};

export interface MatchPreviewDTO {
  opponent: TeamBriefDTO;
  opponentLines: { attack: number; midfield: number; defence: number };
  myLines: { attack: number; midfield: number; defence: number };
}

export interface GameSnapshot {
  save: {
    id: string;
    managerName: string;
    careerName: string;
    season: number;
    week: number;
    totalWeeks: number;
    balance: number;
    transferBudget: number;
    status: string;
    weekInfo: WeekInfoDTO;
    league: LeagueInfoDTO;
  };
  myTeam: TeamDTO;
  myPlayers: PlayerDTO[];
  teams: TeamBriefDTO[];
  standings: StandingRow[]; // ТОЛЬКО лига (competition='league')
  fixtures: FixtureDTO[]; // матчи текущей недели (лига ИЛИ кубок)
  seasonMatches: SeasonMatchDTO[];
  cup: CupSnapshotDTO;
  training: TrainingStateDTO;
  leaders: LeagueLeadersDTO;
  nextMatch: FixtureDTO | null; // null на кубковой неделе без участия клуба игрока
  nextMatchPreview: MatchPreviewDTO | null;
  news: NewsDTO[];
  finances: FinanceSummaryDTO;
  squadWarnings: string[];
  // ── Фаза 3 ──
  board: BoardDTO;
  contractsExpiring: ContractExpiringDTO[]; // yearsLeft ≤ 1
}

// ── Правление (Фаза 3, §6.2 architecture-phase3.md) ──────────────────────

/** Код финансовой цели сезона правления (Модуль 5). */
export type FinanceTargetCode = 'no_debt' | 'wage_control';

/** Точка графика доверия (Модуль 5): неделя сезона → confidence 0..100. */
export interface BoardPointDTO {
  week: number;
  confidence: number;
}

export interface BoardDTO {
  target: BoardTargetCode;
  targetLabel: string; // BOARD_TARGET_LABELS
  targetPlace: number;
  confidence: number; // 0..100
  jobStatus: string; // код из BOARD_JOB_STATUSES
  jobStatusLabel: string; // «Под давлением» и т.д.
  honeymoonWeeksLeft: number; // max(0, honeymoonUntilWeek − week)
  warnLevel: 'none' | 'warning' | 'ultimatum';
  // ── Модуль 5: история доверия + финансовая цель ──
  /** Точки текущего сезона (≤ totalWeeks) для графика; пусто у легаси-сейвов. */
  history: BoardPointDTO[];
  /** Финцель сезона (null — правление не ставит доп. требований). */
  financeTarget: { code: FinanceTargetCode; label: string } | null;
  /** Трансферный/зарплатный бюджеты, утверждённые правлением (§ «Финансы 2.0»). */
  transferBudget: number;
  wageBudget: number;
}

export interface ContractExpiringDTO {
  playerId: string;
  name: string;
  position: Position;
  age: number;
  ovr: number;
  value: number;
  salary: number;
  contractUntil: number;
  yearsLeft: number;
  demand: number;
  maxRenewYears: number;
  preContract: boolean;
}

// ── Трансферный рынок ────────────────────────────────────────────────────

export type MarketPositionFilter = 'ALL' | 'GK' | 'DEF' | 'MID' | 'FWD';
export type MarketSort = 'ovr' | 'price' | 'age';

export interface MarketFilters {
  position: MarketPositionFilter;
  maxPrice: number | null;
  minOvr: number | null;
  sort: MarketSort;
}

export interface MarketListingDTO {
  listingId: string;
  price: number;
  source: 'market' | 'user' | 'free';
  expiresAt: number;
  player: PlayerDTO;
}

// ── Результат недели (POST /api/game/simulate) ───────────────────────────

export interface UserMatchResultDTO {
  matchId: string;
  home: TeamBriefDTO;
  away: TeamBriefDTO;
  homeGoals: number;
  awayGoals: number;
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string | null;
  isNeutral: boolean;
  events: MatchEvent[];
  stats: MatchStats | null;
  /** Фаза 4: подпись экрана матча (двойная неделя: кубок → евро). */
  competition: Competition;
  // ── Модуль 6: стартовые XI для 2D-радара (позиции = слоты формации) ──
  homeXI: RadarPlayerDTO[];
  awayXI: RadarPlayerDTO[];
}

/** Игрок стартового состава для 2D-радара (Модуль 6). */
export interface RadarPlayerDTO {
  /** Индекс слота формации (порядок FORMATIONS[formation].slots). */
  slot: number;
  playerId: string | null;
  /** Полное имя (или заглушка при пустом слоте — autoLineup не даёт пустых). */
  name: string;
  position: Position;
  /** Номер на фишке (null — рисуем позицию). */
  number: number | null;
}

export interface WeekFinancesDTO {
  wages: number;
  sponsor: number;
  tickets: number;
  // ── Модуль 5: ТВ-отчисления лиги ──
  tv: number;
  cupPrize: number;
  euroPrize: number;
  // ── D-5 «Территория» (§3.5): содержание зданий и мерчандайз — в net включены ──
  buildingsUpkeep: number;
  merch: number;
  net: number;
}

export interface WeekResultPayload {
  season: number;
  week: number;
  weekType: 'league' | 'cup';
  weekLabel: string;
  /** Фаза 4: 0..2 матча клуба игрока в порядке игры ([лига] | [кубок?] | [кубок?, евро?]). */
  userMatches: UserMatchResultDTO[];
  weekResults: {
    homeId: string;
    awayId: string;
    homeGoals: number;
    awayGoals: number;
    homePens: number | null;
    awayPens: number | null;
  }[];
  /** Жеребьёвка СЛЕДУЮЩЕГО раунда (пары) — для экрана кубка. */
  cupRound: { round: number; label: string; drawn: boolean; pairs: CupMatchDTO[] } | null;
  /** Фаза 4: жеребьёвка следующего раунда Кубка Европы (пары) — для экрана «Европа». */
  euroRound: { round: number; label: string; drawn: boolean; pairs: EuroMatchDTO[] } | null;
  finances: WeekFinancesDTO;
  news: NewsDTO[];
  transfers: string[];
  // ── Фаза 3 ──
  /** null при неинициализированном правлении (легаси-сейв до первой недели). */
  board: { confidence: number; delta: number; jobStatusLabel: string } | null;
  sacked: boolean;
  seasonEnded: {
    standings: StandingRow[];
    place: number;
    prize: number;
    awards: SeasonAwardDTO[];
    boardVerdict: { code: 'met' | 'missed' | 'over' | 'sacked'; label: string; bonus: number } | null;
    /** Фаза 4: итог Кубка Европы + квалификация в следующий сезон. */
    euro: { qualifiedNext: boolean; label: string } | null;
  } | null;
}

// ── Ответы API ───────────────────────────────────────────────────────────

export interface NewGameResponse {
  ok: true;
  saveId: string;
  clubs: ClubDTO[];
}

export interface SelectClubResponse {
  ok: true;
}

/** Карточка клуба в каталоге лиги (GET /leagues). */
export interface LeagueClubDTO {
  index: number;
  name: string;
  city: string;
  shortName: string;
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  stadiumCapacity: number;
  startBalance: number;
}

export interface LeagueCatalogDTO {
  code: LeagueCode;
  nameRu: string;
  nameEn: string;
  country: string;
  flag: string;
  teamCount: number;
  leagueWeeks: number;
  cupRounds: number;
  cupName: string;
  avgStrength: number;
  difficulty: string;
  clubs: LeagueClubDTO[];
}

export interface LeagueCatalogResponse {
  ok: true;
  leagues: LeagueCatalogDTO[];
}

/** Карточка карьеры (GET /saves). */
export interface SaveCardDTO {
  id: string;
  careerName: string;
  managerName: string;
  leagueCode: LeagueCode;
  leagueName: string;
  leagueFlag: string;
  teamCount: number;
  clubName: string;
  clubShort: string;
  colorPrimary: string;
  colorSecondary: string;
  season: number;
  week: number;
  totalWeeks: number;
  weekLabel: string;
  place: number;
  form: FormResult[];
  status: string;
  lastOpenedAt: string | null;
  /** Аддитивно (Фаза 2): дата последнего изменения строки сейва. */
  updatedAt: string;
}

export interface SavesListResponse {
  ok: true;
  saves: SaveCardDTO[];
}

export interface CreateSaveResponse {
  ok: true;
  saveId: string;
  careerName: string;
  league: { code: string; nameRu: string; flag: string };
  club: { name: string; shortName: string };
  /** Аддитивно (Фаза 2): полная карточка новой карьеры — как GET /saves. */
  save?: SaveCardDTO;
}

/** Игрок в ответе GET /training. */
export interface TrainingPlayerDTO {
  id: string;
  firstName: string;
  lastName: string;
  position: Position;
  age: number;
  ovr: number;
  potential: number;
  morale: number;
  condition: number;
  injuryWeeks: number;
  /** xp только по атрибутам ТЕКУЩЕГО фокуса (+ GK-атрибуты для вратарей). */
  trainingXp: Partial<Record<AttrKey, number>>;
  /** Модуль 4: индивидуальная программа (null = командная). */
  individual: IndividualTrainingDTO | null;
}

/** Подсказки эффектов тренировок (GET /training, аддитивно к §4.7). */
export interface TrainingHintsDTO {
  focuses: { code: TrainingFocus; label: string; attrLabels: string[] }[];
  intensities: {
    code: TrainingIntensity;
    label: string;
    growthFactor: number;
    conditionDelta: number;
    injuryRiskPct: number;
  }[];
  restConditionBonus: number;
  restMoraleBonus: number;
}

export interface TrainingStateResponse {
  ok: true;
  training: TrainingStateDTO;
  squad: TrainingPlayerDTO[];
  /** Аддитивно (Фаза 2): подписи и числовые эффекты фокусов/интенсивностей. */
  hints?: TrainingHintsDTO;
}

export interface SetTrainingResponse {
  ok: true;
  /** Аддитивно (Фаза 2): новое состояние тренировки после записи. */
  training?: TrainingStateDTO;
}

export interface AwardsResponse {
  ok: true;
  awards: SeasonAwardDTO[];
  live: {
    topScorers: PlayerLeaderDTO[];
    topAssists: PlayerLeaderDTO[];
    topCupScorers: PlayerLeaderDTO[];
    /** Фаза 4: бомбардиры Кубка Европы (вкл. гостей). */
    topEuroScorers: PlayerLeaderDTO[];
  };
}

export interface TacticResponse {
  ok: true;
  teamStrength: number;
}

export interface SimulateResponse {
  ok: true;
  result: WeekResultPayload;
}

export interface MarketResponse {
  ok: true;
  listings: MarketListingDTO[];
}

export interface BuyResponse {
  ok: true;
  snapshot: GameSnapshot;
}

export interface SellResponse {
  ok: true;
  snapshot: GameSnapshot;
}

// ── Модуль 5: стадион + бюджеты ─────────────────────────────────────────

/** Ответ запуска стройки стадиона (POST /stadium). */
export interface StadiumResponse {
  ok: true;
  /** Новая вместимость после завершения стройки. */
  capacityAfter: number;
  /** Число строящихся мест. */
  pending: number;
  /** Абсолютный день окончания стройки. */
  upgradeEndsAtDay: number;
  /** Баланс после оплаты стройки. */
  balance: number;
  snapshot: GameSnapshot;
}

// ── Модуль 3: скаутинг, переговоры, входящие офферы ──────────────────────

/** Ответ переговоров при подписании (POST /market/buy с контракт-полями). */
export interface NegotiationDTO {
  kind: 'accepted' | 'counter' | 'rejected';
  /** Контрпредложение агента (kind = 'counter'). */
  demand: {
    salary: number;
    years: number;
    goalBonus: number;
    cleanSheetBonus: number;
  } | null;
  /** Причина отказа (kind = 'rejected'). */
  reason: 'salary' | 'bonus' | 'years' | null;
  message: string;
}

/** Расширенный ответ покупки: сделка ИЛИ раунд переговоров. */
export interface BuyNegotiatedResponse {
  ok: true;
  /** Есть при kind='accepted' — новый снапшот после сделки. */
  snapshot?: GameSnapshot;
  negotiation: NegotiationDTO;
}

/** Игрок в списке наблюдения со знанием (туман снят пропорционально). */
export interface ScoutReportDTO {
  playerId: string;
  /** Знание 0..100. */
  knowledge: number;
  /** Уровень: none|basic|partial|full (подпись UI). */
  tier: 'none' | 'basic' | 'partial' | 'full';
  /** Активное наблюдение (когда true — знание растёт). */
  watched: boolean;
  player: PlayerDTO;
}

export interface ScoutResponse {
  ok: true;
  season: number;
  week: number;
  reports: ScoutReportDTO[];
  slots: { used: number; total: number };
}

/** Входящий оффер ИИ-клуба на игрока клуба игрока. */
export interface TransferOfferDTO {
  offerId: string;
  amount: number;
  /** Имя клуба-покупателя. */
  fromTeam: string;
  /** Игрок (свой — знание 100). */
  player: PlayerDTO;
  /** Осталось недель до погашения. */
  expiresIn: number;
}

export interface TransferOffersResponse {
  ok: true;
  offers: TransferOfferDTO[];
}

// ── Модуль 4: персонал и рынок труда тренеров ─────────────────────────────

export type StaffRole = 'head_coach' | 'assistant' | 'fitness' | 'physio' | 'scout';

/** Сотрудник/кандидат рынка персонала (GET /staff). */
export interface StaffDTO {
  id: string;
  role: StaffRole;
  firstName: string;
  lastName: string;
  nationality: string;
  age: number;
  rating: number;
  specialty: string | null;
  salary: number;
  contractUntil: number;
  /** Сезонов контракта осталось (0 = истекает в это межсезонье). */
  yearsLeft: number;
}

/** Сводные эффекты тренерского штата на клуб. */
export interface StaffEffectsDTO {
  /** Множитель XP тренировок (главный тренер). */
  xpMult: number;
  /** Доп. множитель XP для молодых ≤23 (ассистент). */
  youthXpMult: number;
  /** Множитель риска травм (физио). */
  injuryRiskMult: number;
  /** Прибавка к еженедельному восстановлению (фитнес-тренер). */
  recoveryBonus: number;
  /** Шанс ускорить лечение на 1 неделю (физио 'treatment'). */
  healChance: number;
  bestScoutRating: number | null;
  scoutSlots: { used: number; total: number };
}

export interface StaffResponse {
  ok: true;
  season: number;
  week: number;
  /** Штат клуба игрока. */
  staff: StaffDTO[];
  /** Свободные кандидаты рынка (teamId = null). */
  market: StaffDTO[];
  effects: StaffEffectsDTO;
  slots: { role: StaffRole; used: number; max: number }[];
  /** Недельная ведомость штата, €. */
  weeklyWages: number;
  /** Баланс клуба (для guard-подсказок найма/увольнения). */
  balance: number;
}

/** Ответ найма/увольнения/продления: свежий снимок персонала + баланс. */
export interface StaffActionResponse {
  ok: true;
  staff: Omit<StaffResponse, 'ok'>;
  /** Изменение баланса (бонус найма / компенсация). */
  balanceDelta: number;
}

/** Индивидуальная программа игрока в GET /training. */
export interface IndividualTrainingDTO {
  focus: TrainingFocus;
  intensity: TrainingIntensity;
}

export interface SetPlayerTrainingResponse {
  ok: true;
  playerId: string;
  individual: IndividualTrainingDTO | null;
}

export interface MatchResponse {
  ok: true;
  match: MatchDetailsDTO;
}

export interface StateResponse {
  ok: true;
  snapshot: GameSnapshot;
}

// ── Контракты (Фаза 3, §6.1 architecture-phase3.md) ──────────────────────

export interface ContractInfoDTO {
  playerId: string;
  name: string;
  position: Position;
  age: number;
  ovr: number;
  value: number;
  salary: number;
  contractUntil: number;
  yearsLeft: number;
  /** yearsLeft ≤ CONTRACT_RENEWABLE_YEARS_LEFT && preContractTeamId === null. */
  renewable: boolean;
  /** Зарплатный спрос (заполняется для renewable). */
  demand: number | null;
  maxRenewYears: number; // maxRenewYears(age)
  preContract: boolean; // Босман: уйдёт в конце сезона
  bosmanRisk: 'low' | 'medium' | 'high';
}

export interface ContractsResponse {
  ok: true;
  season: number;
  contracts: ContractInfoDTO[];
}

export interface RenewResponse {
  ok: true;
  outcome: 'accepted' | 'counter';
  /** Всегда возвращаем спрос (для контрпредложения UI). */
  demand: number;
  /** Только при accepted (состояние изменилось). */
  snapshot?: GameSnapshot;
}

// ── Правление (Фаза 3) ──────────────────────────────────────────────────

export interface BoardResponse {
  ok: true;
  board: BoardDTO; // тот же DTO, что в снапшоте /state
  news: NewsDTO[]; // последние 10 новостей типа 'board'
}

// ── Академия (Фаза 3) ───────────────────────────────────────────────────

export interface AcademyPlayerDTO {
  id: string;
  name: string;
  position: Position;
  age: number;
  ovr: number;
  potential: number;
  stars: number; // 1..5 (starsOf)
  contractUntil: number;
  yearsLeft: number;
  value: number;
  salary: number;
}

export interface AcademyResponse {
  ok: true;
  graduates: AcademyPlayerDTO[];
}

// ── Диалог игрока: история по сезонам (Фаза 3) ──────────────────────────

export interface PlayerHistoryDTO {
  season: number;
  teamName: string;
  age: number;
  position: string;
  apps: number;
  goals: number;
  assists: number;
  cupGoals: number;
  cupAssists: number;
  euroGoals: number;
  euroAssists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  /** 6.8 (не ×10); null = 0 матчей. */
  avgRating: number | null;
}

export interface CareerTotalsDTO {
  apps: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  avgRating: number | null;
  seasons: number;
}

export interface PlayerDialogDTO {
  player: PlayerDTO;
  /** По возрастанию сезона. */
  history: PlayerHistoryDTO[];
  totals: CareerTotalsDTO;
  /** Награды игрока за все сезоны. */
  awards: SeasonAwardDTO[];
}

export interface PlayerDialogResponse {
  ok: true;
  dialog: PlayerDialogDTO;
}

export interface ApiErrorResponse {
  ok: false;
  error: string;
}

// ── Безопасный парсинг JSON-полей из БД ──────────────────────────────────

/** Накопленный тренировочный опыт: разреженный map атрибут → дробь 0..1. */
export function parseTrainingXp(raw: string | null | undefined): Record<string, number> {
  if (!raw) return {};
  try {
    const data: unknown = JSON.parse(raw);
    if (typeof data !== 'object' || data === null || Array.isArray(data)) return {};
    const out: Record<string, number> = {};
    for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
      if (typeof value === 'number' && Number.isFinite(value) && value >= 0) {
        out[key] = value;
      }
    }
    return out;
  } catch {
    return {};
  }
}

/** Список id участников кубка из GameSave.cupAliveTeamIds (JSON string[]). */
export function parseTeamIdList(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const data: unknown = JSON.parse(raw);
    if (!Array.isArray(data)) return [];
    return data.filter((x): x is string => typeof x === 'string');
  } catch {
    return [];
  }
}

export function parseLineup(raw: string | null | undefined): string[] | null {
  if (!raw) return null;
  try {
    const data: unknown = JSON.parse(raw);
    if (!Array.isArray(data)) return null;
    if (!data.every((x): x is string => typeof x === 'string')) return null;
    return data;
  } catch {
    return null;
  }
}

/** Известные типы событий (Фаза 4 + Engine 2.0): события с неизвестным type
 *  пропускаются (легаси-совместимость вперёд). Модуль 6: сюда же вошли типы
 *  движка 2.0 — иначе parseEvents резал ленты сохранённых матчей. */
const KNOWN_EVENT_TYPES = new Set<string>([
  'kickoff', 'goal', 'yellow', 'red', 'injury', 'chance', 'halftime', 'fulltime',
  'pen_goal', 'pen_miss', 'pen_save', 'sub',
  'shot_on', 'shot_off', 'save', 'corner', 'offside', 'duel', 'momentum',
]);

export function parseEvents(raw: string | null | undefined): MatchEvent[] {
  if (!raw) return [];
  try {
    const data: unknown = JSON.parse(raw);
    if (!Array.isArray(data)) return [];
    const out: MatchEvent[] = [];
    for (const item of data) {
      if (typeof item !== 'object' || item === null) continue;
      const rec = item as Record<string, unknown>;
      if (typeof rec.minute !== 'number' || typeof rec.type !== 'string' || typeof rec.text !== 'string') continue;
      if (!KNOWN_EVENT_TYPES.has(rec.type)) continue; // легаси-сейвы вперёд совместимы
      out.push({
        minute: rec.minute,
        type: rec.type as MatchEventType,
        teamId: typeof rec.teamId === 'string' ? rec.teamId : undefined,
        playerId: typeof rec.playerId === 'string' ? rec.playerId : undefined,
        playerName: typeof rec.playerName === 'string' ? rec.playerName : undefined,
        assistId: typeof rec.assistId === 'string' ? rec.assistId : undefined,
        assistName: typeof rec.assistName === 'string' ? rec.assistName : undefined,
        gkName: typeof rec.gkName === 'string' ? rec.gkName : undefined,
        subOutId: typeof rec.subOutId === 'string' ? rec.subOutId : undefined,
        subOutName: typeof rec.subOutName === 'string' ? rec.subOutName : undefined,
        // Модуль 6: координаты 2D-радара (0..100) — переживают сохранение матча
        x: typeof rec.x === 'number' ? rec.x : undefined,
        y: typeof rec.y === 'number' ? rec.y : undefined,
        text: rec.text,
      });
    }
    return out;
  } catch {
    return [];
  }
}

export function parseStats(raw: string | null | undefined): MatchStats | null {
  if (!raw) return null;
  try {
    const data: unknown = JSON.parse(raw);
    if (typeof data !== 'object' || data === null) return null;
    const rec = data as Record<string, unknown>;
    const num = (v: unknown): number => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
    return {
      possessionHome: num(rec.possessionHome),
      shotsHome: num(rec.shotsHome),
      shotsAway: num(rec.shotsAway),
      sotHome: num(rec.sotHome),
      sotAway: num(rec.sotAway),
      cornersHome: num(rec.cornersHome),
      cornersAway: num(rec.cornersAway),
      foulsHome: num(rec.foulsHome),
      foulsAway: num(rec.foulsAway),
      yellowsHome: num(rec.yellowsHome),
      yellowsAway: num(rec.yellowsAway),
      redsHome: num(rec.redsHome),
      redsAway: num(rec.redsAway),
    };
  } catch {
    return null;
  }
}


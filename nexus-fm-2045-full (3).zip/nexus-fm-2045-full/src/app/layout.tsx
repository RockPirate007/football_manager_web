import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const interSans = Inter({
  variable: "--font-inter-sans",
  subsets: ["latin", "cyrillic"],
});

const interMono = Inter({
  variable: "--font-inter-mono",
  subsets: ["latin", "cyrillic"],
});

export const metadata: Metadata = {
  title: "NEXUS FM 2046 — Футбольный менеджер",
  description:
    "NEXUS FM 2046 — большая эволюция браузерного футбольного менеджера: 6 лиг, 112 клубов, трансферы, тактика и командный центр.",
  keywords: ["футбол", "менеджер", "футбольный менеджер", "NEXUS FM", "NEXUS FM 2046", "лига", "трансферы", "тактика"],
  authors: [{ name: "NEXUS FM 2046" }],
  openGraph: {
    title: "NEXUS FM 2046",
    description: "Киберпанк-футбольный менеджер нового поколения: командный центр, лиги, трансферы и тактика",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${interSans.variable} ${interMono.variable} font-sans antialiased bg-background text-foreground`}
      >
        {/* D-9 (спека §7.1, прим. 2): клиент Neutralino для десктоп-сборки.
            Plain script с defer (не next/script) — SSR-совместимо и не ломает
            static export. В браузере/dev файл отдаётся из public/ (200) либо
            отсутствует (404) — в обоих случаях безвреден: движок делает
            try/catch на window.Neutralino.init() и падает в IndexedDB
            (WebSocket ws://localhost:undefined бросает SyntaxError синхронно). */}
        <script src="/neutralino.js" defer />
        {children}
        {/* Фикс QA-10: тосты снизу с отступом — не перекрывают верхнюю навигацию
            и нижний мобильный таб-бар */}
        <Toaster position="bottom-center" richColors closeButton offset={96} />
      </body>
    </html>
  );
}

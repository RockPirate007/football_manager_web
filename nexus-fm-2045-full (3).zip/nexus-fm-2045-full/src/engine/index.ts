/**
 * Фасад движка (спека §1.1/§1.6, D-3b): активная игра — singleton SaveStore
 * (db-прокси из './db' резолвится сюда), карьера/слоты/сейвы одной точкой.
 * Публичный API для будущего router.ts (D-4): createCareer/loadSlot/saveSlot/
 * touchSlot/removeSlot/renameSlot + simulateWeek/buildSnapshot/api-helpers.
 * Автосейв/mutating-флаг/rollback-обёртки — ответственность router.ts (§2.3).
 * Изоморфно: хранилище — StorageAdapter (Neutralino | IndexedDB | Memory).
 */

import type { GameSnapshot, WeekResultPayload } from '@/lib/game/types';
import {
  buildEuroSnapshot,
  matchPlanOf,
  normalizeErrorCode,
  requireSave,
  resolvePlayingSave,
  resolveSave,
  saveIdFromQuery,
  type PlayingSave,
} from './api-helpers';
import { buildSaveCard, buildSaveCards, createCareer, type CreateCareerInput, type CreateCareerResult } from './career';
import { getActiveStore, setActiveStore, type SaveStore } from './db';
import { buildSnapshot } from './snapshot';
import {
  createSlots, touchSlot as touchEnvelope, type SaveSlots, type SlotHandle,
} from './save';
import { createStorage, type SlotMeta, type StorageAdapter } from './storage';
import { simulateWeek } from './week';

// ── Публичный API движка для router.ts (D-4) ───────────────────────────────

export {
  // career/slots (мутации карьер)
  createCareer, buildSaveCard, buildSaveCards,
  // api-helpers (валидация/резолв сейва, коды 1:1)
  requireSave, resolveSave, resolvePlayingSave, normalizeErrorCode, saveIdFromQuery,
  matchPlanOf, buildEuroSnapshot,
  // оркестратор и снапшот
  simulateWeek, buildSnapshot,
};
export type { CreateCareerInput, CreateCareerResult, PlayingSave };

/** Результат createCareer фасада: результат ядра + номер слота. */
export type CreateCareerEngineResult = CreateCareerResult & { slot: number };

export interface Engine {
  /** Активное in-memory хранилище (null — карьера не создана/не загружена). */
  readonly store: SaveStore | null;
  /** Номер активного слота 1..8 (null — нет активной карьеры). */
  readonly slot: number | null;
  /** saveId активной карьеры (null — нет активной карьеры). */
  readonly saveId: string | null;
  /** Активная БД строго (throw — как GET /saves без карьер, §1.6). */
  requireStore(): SaveStore;

  // ── слоты (§2) ──
  /** Карточки занятых слотов (сортировка как GET /saves). */
  listSlots(): Promise<SlotMeta[]>;
  /** Создать карьеру в свободный слот и активировать её. */
  createCareer(input: CreateCareerInput): Promise<CreateCareerEngineResult>;
  /** Загрузить слот в память и активировать (clock — для тестов детерминизма). */
  loadSlot(slot: number, options?: { clock?: () => Date }): Promise<SlotHandle>;
  /** Полная перезагрузка АКТИВНОГО слота с диска (rollback, §1.6). */
  reload(options?: { clock?: () => Date }): Promise<void>;
  /** Сброс активной карьеры (выход к списку карьер). */
  unload(): void;
  /** Канонический дамп активного слота → slot-N.json + meta.json. */
  saveSlot(options?: { touch?: boolean; now?: Date }): Promise<void>;
  /** Отметка «недавно открытый»: gameSave.lastOpenedAt + конверт слота. */
  touchSlot(now?: Date): Promise<void>;
  /** Удалить слот (каскад в памяти не нужен — хранилище одно на слот). */
  removeSlot(slot: number): Promise<void>;
  /** Переименовать (1–60; meta сразу, careerName в слоте лениво). */
  renameSlot(slot: number, careerName: string): Promise<void>;

  // ── игра (обёртки оркестратора/снапшота поверх активной карьеры) ──
  /** POST /simulate: симуляция недели активной карьеры. */
  simulateActiveWeek(): Promise<WeekResultPayload>;
  /** GET /state: снапшот активной карьеры. */
  snapshotActive(): Promise<GameSnapshot>;
}

// ── Реализация ─────────────────────────────────────────────────────────────

function createEngine(): Engine {
  let slotsPromise: Promise<SaveSlots> | null = null;
  const slots = (): Promise<SaveSlots> => {
    if (!slotsPromise) slotsPromise = createStorage().then((s: StorageAdapter) => createSlots(s));
    return slotsPromise;
  };

  let active: SlotHandle | null = null;
  let activeSaveId: string | null = null;

  const saveIdOf = async (store: SaveStore): Promise<string> => {
    const row = await store.gameSave.findFirst();
    if (!row) throw new Error('engine: в хранилище нет строки gameSave (карьера не создана)');
    return row.id;
  };

  const activate = (handle: SlotHandle, saveId: string): void => {
    active = handle;
    activeSaveId = saveId;
    setActiveStore(handle.store);
  };

  const engine: Engine = {
    get store(): SaveStore | null {
      return active ? active.store : null;
    },
    get slot(): number | null {
      return active ? active.slot : null;
    },
    get saveId(): string | null {
      return activeSaveId;
    },
    requireStore(): SaveStore {
      return getActiveStore();
    },

    async listSlots(): Promise<SlotMeta[]> {
      return (await slots()).list();
    },

    async createCareer(input: CreateCareerInput): Promise<CreateCareerEngineResult> {
      const result = await createCareer(input);
      const handle = await (await slots()).create(result.store, { now: input.now });
      activate(handle, result.saveId);
      return { ...result, slot: handle.slot };
    },

    async loadSlot(slot: number, options: { clock?: () => Date } = {}): Promise<SlotHandle> {
      const handle = await (await slots()).load(slot, options);
      activate(handle, await saveIdOf(handle.store));
      return handle;
    },

    async reload(options: { clock?: () => Date } = {}): Promise<void> {
      if (!active) throw new Error('engine.reload: активная карьера не загружена');
      await this.loadSlot(active.slot, options);
    },

    unload(): void {
      active = null;
      activeSaveId = null;
      setActiveStore(null);
    },

    async saveSlot(options: { touch?: boolean; now?: Date } = {}): Promise<void> {
      if (!active) throw new Error('engine.saveSlot: активная карьера не загружена');
      if (options.touch) await this.touchSlot(options.now);
      await (await slots()).save(active);
    },

    async touchSlot(now: Date = new Date()): Promise<void> {
      if (!active) throw new Error('engine.touchSlot: активная карьера не загружена');
      if (activeSaveId !== null) {
        await active.store.gameSave.update({
          where: { id: activeSaveId },
          data: { lastOpenedAt: now },
        });
      }
      touchEnvelope(active, now);
    },

    async removeSlot(slot: number): Promise<void> {
      await (await slots()).remove(slot);
      if (active && active.slot === slot) this.unload();
    },

    async renameSlot(slot: number, careerName: string): Promise<void> {
      await (await slots()).rename(slot, careerName);
    },

    async simulateActiveWeek(): Promise<WeekResultPayload> {
      const saveId = getActiveStore() && activeSaveId;
      if (!saveId) throw new Error('engine.simulateActiveWeek: активная карьера не загружена');
      return simulateWeek(saveId);
    },

    async snapshotActive(): Promise<GameSnapshot> {
      const saveId = getActiveStore() && activeSaveId;
      if (!saveId) throw new Error('engine.snapshotActive: активная карьера не загружена');
      return buildSnapshot(saveId);
    },
  };
  return engine;
}

let engineInstance: Engine | null = null;

/** Синглтон движка (module-level, §1.6): одна активная карьера на процесс. */
export function getEngine(): Engine {
  if (!engineInstance) engineInstance = createEngine();
  return engineInstance;
}

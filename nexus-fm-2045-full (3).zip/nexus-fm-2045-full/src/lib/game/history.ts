/**
 * История игрока по сезонам: строки снапшота и карьерные итоги.
 * Чистые функции (§3.4 architecture-phase3.md). avgRating везде ×10 (68 = 6.8).
 */

import type { PlayerLike } from './players';

export interface SeasonRecordRow {
  playerId: string;
  teamId: string | null;
  teamName: string;
  age: number;
  position: string;
  apps: number;
  goals: number;
  assists: number;
  cupGoals: number;
  cupAssists: number;
  /** Фаза 4: еврокубковые голы/ассисты сезона (§5.6-3). */
  euroGoals: number;
  euroAssists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  /** ×10; 0 = не играл (ratingApps = 0). */
  avgRating: number;
}

/** Название клуба в снапшоте истории: свободный агент — «Свободный агент». */
export const FREE_AGENT_TEAM_NAME = 'Свободный агент';

/**
 * Снапшот ВСЕХ игроков сейва для PlayerSeasonRecord (createMany).
 * squadPlayers — из ctxs (команды), freeAgents — рыночные (teamId = null,
 * teamName «Свободный агент»). avgRating = ratingApps > 0 ? round(ratingSum /
 * ratingApps) : 0 (уже ×10).
 */
export function buildSeasonRecords(args: {
  season: number;
  squadPlayers: PlayerLike[];
  freeAgents: PlayerLike[];
  teamNameById: Map<string, string>;
}): SeasonRecordRow[] {
  void args.season; // сезон проставляется на месте записи (createMany data)
  const rows: SeasonRecordRow[] = [];
  const rowOf = (p: PlayerLike, teamId: string | null, teamName: string): SeasonRecordRow => ({
    playerId: p.id,
    teamId,
    teamName,
    age: p.age,
    position: p.position,
    apps: p.apps,
    goals: p.goals,
    assists: p.assists,
    cupGoals: p.cupGoals,
    cupAssists: p.cupAssists,
    euroGoals: p.euroGoals,
    euroAssists: p.euroAssists,
    cleanSheets: p.cleanSheets,
    yellowCards: p.yellowCards,
    redCards: p.redCards,
    avgRating: p.ratingApps > 0 ? Math.round(p.ratingSum / p.ratingApps) : 0,
  });

  for (const p of args.squadPlayers) {
    const teamId = p.teamId;
    const teamName = teamId ? (args.teamNameById.get(teamId) ?? FREE_AGENT_TEAM_NAME) : FREE_AGENT_TEAM_NAME;
    rows.push(rowOf(p, teamId, teamName));
  }
  for (const p of args.freeAgents) {
    rows.push(rowOf(p, null, FREE_AGENT_TEAM_NAME));
  }
  return rows;
}

/** Карьерные итоги: суммы по сезонам + средний рейтинг (round до 0.1) + число сезонов. */
export function careerTotalsOf(rows: SeasonRecordRow[]): {
  apps: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  /** 6.8 (не ×10) или null при 0 матчей; среднее взвешено по числу матчей сезона. */
  avgRating: number | null;
  seasons: number;
} {
  const sum = (fn: (r: SeasonRecordRow) => number): number =>
    rows.reduce((s, r) => s + fn(r), 0);

  const played = rows.filter((r) => r.avgRating > 0 && r.apps > 0);
  const playedApps = played.reduce((s, r) => s + r.apps, 0);
  const weightedX10 = playedApps > 0
    ? played.reduce((s, r) => s + r.avgRating * r.apps, 0) / playedApps
    : null;

  return {
    apps: sum((r) => r.apps),
    goals: sum((r) => r.goals),
    assists: sum((r) => r.assists),
    cleanSheets: sum((r) => r.cleanSheets),
    yellowCards: sum((r) => r.yellowCards),
    redCards: sum((r) => r.redCards),
    avgRating: weightedX10 !== null ? Math.round(weightedX10) / 10 : null,
    seasons: rows.length,
  };
}

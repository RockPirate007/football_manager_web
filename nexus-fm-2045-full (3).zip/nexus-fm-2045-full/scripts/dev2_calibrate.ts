/**
 * Модуль 2 — калибровка системы развития игроков (bun):
 *  1. Вундеркинд (age 16, PA 88): 10 сезонов — рост к PA к 24–26 годам;
 *  2. Ветеран (age 31): физика падает после 30–32, ментальные живут;
 *  3. Матчёвый XP: играющий молодой растёт заметно быстрее неиграющего;
 *  4. Инварианты: OVR ≤ potential всегда; GK позже на пенсию.
 */
import { developPlayerSeasonal, applyMatchDevelopment, growthMultOf } from '../src/lib/game/development';
import { generatePlayer, computeOvr, type PlayerLike } from '../src/lib/game/players';
import { applyWeeklyTraining } from '../src/lib/game/training';
import { retires } from '../src/lib/game/progression';
import { mulberry32, type RNG } from '../src/lib/game/rng';

let failures = 0;
function check(name: string, ok: boolean, detail: string): void {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name} :: ${detail}`);
  if (!ok) failures += 1;
}

// ── 1. Вундеркинд: 16 лет, PA 88, 10 межсезоний + недельные тренировки ──
{
  const rng = mulberry32(42);
  const p = generatePlayer(rng, 55, 'AMC', { fixedAge: 16, potentialOverride: 88 });
  const ovrByAge = new Map<number, number>();
  const devRng = mulberry32(777);
  for (let season = 0; season < 12; season++) {
    // 30 недель тренировок (possession, normal) + 30 матчей × 90 минут
    for (let w = 0; w < 30; w++) {
      applyWeeklyTraining(mulberry32(1000 + season * 100 + w), 'possession', 'normal', [p]);
      applyMatchDevelopment(devRng, p, 90);
    }
    p.ovr = computeOvr(p, p.position);
    ovrByAge.set(p.age, p.ovr);
    developPlayerSeasonal(rng, p); // межсезонье
    p.age += 1;
    ovrByAge.set(p.age, computeOvr(p, p.position));
  }
  const at23 = ovrByAge.get(23) ?? 0;
  const at26 = ovrByAge.get(26) ?? 0;
  const peak = Math.max(...ovrByAge.values());
  check('m2_wonderkid_grows', at23 >= 68 && at26 >= 74,
    `16→55 ovr, PA=88: age23=${at23} age26=${at26} peak=${peak} (ожидание ~75+ к 26)`);
  check('m2_wonderkid_ceiling', peak <= 88, `peak=${peak} ≤ PA=88`);
}

// ── 2. Ветеран: 31 → 38 — физика падает, ментальные держатся ──
{
  const rng = mulberry32(777);
  const p = generatePlayer(rng, 80, 'MC', { fixedAge: 31 });
  const start = { pace: p.pace, acceleration: p.acceleration, stamina: p.stamina, vision: p.vision, decisions: p.decisions, ovr: p.ovr };
  for (let season = 0; season < 7; season++) {
    developPlayerSeasonal(rng, p);
    p.age += 1;
  }
  const physDrop = (start.pace + start.acceleration + start.stamina) / 3
    - (p.pace + p.acceleration + p.stamina) / 3;
  const mentalDelta = (p.vision + p.decisions) / 2 - (start.vision + start.decisions) / 2;
  check('m2_veteran_phys_decline', physDrop >= 3,
    `31→38: физика −${physDrop.toFixed(1)} (pace ${start.pace}→${p.pace}, accel ${start.acceleration}→${p.acceleration}, стамина ${start.stamina}→${p.stamina})`);
  check('m2_veteran_mental_alive', mentalDelta > -2,
    `ментальные дельта ${mentalDelta.toFixed(1)} (vision ${start.vision}→${p.vision}, решения ${start.decisions}→${p.decisions})`);
  check('m2_veteran_ovr_decline', p.ovr < start.ovr, `ovr ${start.ovr}→${p.ovr}`);
}

// ── 3. Матчёвый XP: играющий молодой обгоняет неиграющего ──
{
  const mk = (seed: number): PlayerLike => {
    const p = generatePlayer(mulberry32(seed), 58, 'ST', { fixedAge: 18, potentialOverride: 84 });
    return p;
  };
  const starter = mk(11);
  const benchwarmer = mk(11); // тот же сид → одинаковый старт
  const devRng = mulberry32(31337);
  for (let match = 0; match < 30; match++) {
    applyMatchDevelopment(devRng, starter, 90); // полный матч
    applyMatchDevelopment(devRng, benchwarmer, 0); // не играл
  }
  const xpSum = (p: PlayerLike): number => {
    const xp = p.trainingXp ? JSON.parse(p.trainingXp) : {};
    return Object.values(xp as Record<string, number>).reduce((s, v) => s + v, 0);
  };
  check('m2_match_xp_playing', xpSum(starter) > 1.5, `30 матчей × 90' → xp=${xpSum(starter).toFixed(2)}`);
  check('m2_match_xp_bench', xpSum(benchwarmer) === 0, `не играл → xp=${xpSum(benchwarmer).toFixed(2)}`);
}

// ── 4. Инварианты ──
{
  const rng = mulberry32(2024);
  let ceilingOk = true;
  for (let i = 0; i < 200; i++) {
    const p = generatePlayer(rng, 60, 'MC', { fixedAge: 17, potentialOverride: 70 });
    for (let s = 0; s < 15; s++) {
      for (let w = 0; w < 30; w++) applyWeeklyTraining(mulberry32(i * 500 + s * 30 + w), 'possession', 'hard', [p]);
      developPlayerSeasonal(rng, p);
      p.age += 1;
      if (computeOvr(p, p.position) > p.potential) { ceilingOk = false; break; }
    }
  }
  check('m2_ceiling_invariant', ceilingOk, 'OVR ≤ potential на 200 игроках × 15 сезонов');

  // GK на пенсию позже
  let gkRetired = 0;
  let fieldRetired = 0;
  for (let i = 0; i < 100; i++) {
    const rng2 = mulberry32(500 + i);
    const gk = generatePlayer(mulberry32(5), 70, 'GK', { fixedAge: 36 });
    const field = generatePlayer(mulberry32(5), 70, 'ST', { fixedAge: 36 });
    if (retires(gk, rng2)) gkRetired += 1;
    if (retires(field, rng2)) fieldRetired += 1;
  }
  check('m2_gk_retires_later', fieldRetired === 100 && gkRetired >= 25 && gkRetired <= 55,
    `36 лет × 100: полевой=${fieldRetired}% GK=${gkRetired}% (поле всегда, GK ~40%)`);

  // кривые: физика раньше плато, ментальные дольше
  const physAt30 = growthMultOf('phys', 30, false);
  const mentalAt30 = growthMultOf('mental', 30, false);
  check('m2_curves_order', physAt30 < 0.2 && mentalAt30 >= 0.8,
    `рост в 30: физ=${physAt30} мент=${mentalAt30} (физика плато, ментальные живы)`);
}

console.log(`\nИтого: ${failures === 0 ? 'ВСЁ ПРОШЛО' : `ПРОВАЛОВ: ${failures}`}`);
process.exit(failures === 0 ? 0 : 1);

/**
 * Контракты: сроки, зарплатный спрос, решения ИИ, Босман.
 * Чистые функции над PlayerLike (§3.1 architecture-phase3.md): без Prisma,
 * без fetch; RNG — только явно в параметрах; мутации игроков — на месте
 * (дифф-механизм week.ts запишет).
 */
import {
  BOSMAN_BASE_P, BOSMAN_LOW_APPS_ADD, BOSMAN_LOW_APPS_RATIO, BOSMAN_LOW_MORALE_ADD,
  BOSMAN_LOW_WAGE_ADD, BOSMAN_LOW_WAGE_RATIO, BOSMAN_P_CAP,
  CONTRACT_ACCEPT_RATIO, CONTRACT_AGE_MULT_32, CONTRACT_AGE_MULT_35,
  CONTRACT_AI_SQUAD_FLOOR, CONTRACT_AI_UNHAPPY_MULT, CONTRACT_AI_WAGE_RATIO,
  CONTRACT_AI_WANT, CONTRACT_AI_WANT_DEFAULT, CONTRACT_LOW_APPS_MULT,
  CONTRACT_LOW_APPS_RATIO, CONTRACT_LOW_MORALE, CONTRACT_LOW_MORALE_MULT,
  CONTRACT_MAX_YEARS, CONTRACT_MIN_YEARS, CONTRACT_RANK_ROTATION,
  CONTRACT_RANK_STAR, CONTRACT_RANK_STARTER, CONTRACT_ROLE_MULT,
  CONTRACT_SALARY_FLOOR_RATIO, CONTRACT_TALENT_AGE, CONTRACT_TALENT_GAP,
  CONTRACT_TALENT_MULT, CONTRACT_VETERAN_MAX_YEARS, CONTRACT_YEARS_DISTRIBUTION,
  SALARY_MIN, SALARY_ROUND, contractAiYears,
} from './constants';
import { computeSalary, positionGroupOf, type PlayerLike } from './players';
import { pickWeighted, type RNG } from './rng';

/** Срок контракта при генерации/покупке по возрастной таблице CONTRACT_YEARS_DISTRIBUTION. */
export function contractYearsRoll(rng: RNG, age: number): number {
  const band = CONTRACT_YEARS_DISTRIBUTION.find((b) => age <= b.maxAge)
    ?? CONTRACT_YEARS_DISTRIBUTION[CONTRACT_YEARS_DISTRIBUTION.length - 1];
  return pickWeighted(
    rng,
    band.weights.map((w, i) => ({ item: i + 1, weight: w })),
  );
}

/** Последний сезон действия: контракт начинается С сезона season (years clamp 1..4). */
export function contractUntilFromYears(season: number, years: number): number {
  const y = Math.min(Math.max(years, CONTRACT_MIN_YEARS), CONTRACT_MAX_YEARS);
  return season + y - 1;
}

/** Осталось лет (включая текущий сезон); 0 = истёк. */
export function yearsLeftOf(contractUntil: number, season: number): number {
  return Math.max(0, contractUntil - season + 1);
}

export type ContractRole = 'star' | 'starter' | 'rotation' | 'depth';

/** Ранг игрока по OVR в составе (1 = сильнейший; стабильная сортировка по ovr desc). */
export function ovrRankOf(player: PlayerLike, squad: PlayerLike[]): number {
  const sorted = [...squad].sort((a, b) => b.ovr - a.ovr);
  const idx = sorted.findIndex((p) => p.id === player.id);
  return idx < 0 ? squad.length + 1 : idx + 1;
}

/** Роль по рангу OVR в составе: rank ≤ 3 star · ≤ 11 starter · ≤ 18 rotation · глубже depth. */
export function contractRoleOf(player: PlayerLike, squad: PlayerLike[]): ContractRole {
  const rank = ovrRankOf(player, squad);
  if (rank <= CONTRACT_RANK_STAR) return 'star';
  if (rank <= CONTRACT_RANK_STARTER) return 'starter';
  if (rank <= CONTRACT_RANK_ROTATION) return 'rotation';
  return 'depth';
}

/**
 * «Число матчей команды» для demand/риска Босмана (§6.1): стартовое ядро —
 * сумма apps 11 игроков с наибольшими apps / 11 (запасные не искажают знаменатель).
 */
export function teamAppsOf(squad: PlayerLike[]): number {
  const top = [...squad].sort((a, b) => b.apps - a.apps).slice(0, 11);
  const sum = top.reduce((s, p) => s + p.apps, 0);
  return Math.ceil(sum / 11);
}

/**
 * Зарплатный спрос при продлении (единая формула для клуба игрока и ИИ):
 *   base = max(player.salary × 1.15, computeSalary(value) × roleMult)
 *   × (age ≥ 35 ? 0.75 : age ≥ 32 ? 0.90 : 1)
 *   × (morale < 40 ? 1.15 : 1) × (apps < 0.5 × teamApps ? 1.10 : 1)
 *   × ((pot − ovr) ≥ 8 && age ≤ 23 ? 1.20 : 1)
 *   → max(SALARY_MIN, round(x / SALARY_ROUND) × SALARY_ROUND)
 * D-6 (§4.3): prestigeMult — эффект престижа менеджера (применяется в
 * роуте продления до слайдера: p ≥ 600 → ×0.95, p < 400 → ×1.05); без
 * аргумента поведение байт-в-байт прежнее (×1).
 */
export function renewDemand(args: {
  player: PlayerLike;
  squad: PlayerLike[];
  teamApps: number;
  prestigeMult?: number;
}): number {
  const { player, squad, teamApps } = args;
  const prestigeMult = args.prestigeMult ?? 1;
  const roleMult = CONTRACT_ROLE_MULT[contractRoleOf(player, squad)];
  const nominal = computeSalary(player.value);
  let x = Math.max(player.salary * CONTRACT_SALARY_FLOOR_RATIO, nominal * roleMult);
  if (player.age >= 35) x *= CONTRACT_AGE_MULT_35;
  else if (player.age >= 32) x *= CONTRACT_AGE_MULT_32;
  if (player.morale < CONTRACT_LOW_MORALE) x *= CONTRACT_LOW_MORALE_MULT;
  if (player.apps < CONTRACT_LOW_APPS_RATIO * teamApps) x *= CONTRACT_LOW_APPS_MULT;
  if (player.potential - player.ovr >= CONTRACT_TALENT_GAP && player.age <= CONTRACT_TALENT_AGE) {
    x *= CONTRACT_TALENT_MULT;
  }
  x *= prestigeMult;
  return Math.max(SALARY_MIN, Math.round(x / SALARY_ROUND) * SALARY_ROUND);
}

/** Максимум лет продления: 30+ → 2, иначе 4. */
export function maxRenewYears(age: number): number {
  return age >= 30 ? CONTRACT_VETERAN_MAX_YEARS : CONTRACT_MAX_YEARS;
}

/** Результат предложения: 'accepted' при offer ≥ 0.92 × demand, иначе 'counter'. */
export function renewalOutcome(offer: number, demand: number): 'accepted' | 'counter' {
  return offer >= CONTRACT_ACCEPT_RATIO * demand ? 'accepted' : 'counter';
}

/**
 * Вероятность Босман-ухода в конце сезона (последний год контракта):
 * 0.10 + 0.30(morale<40) + 0.25(зарплата<0.7 номинала) + 0.20(apps<40% матчей), кап 0.75.
 */
export function bosmanProbability(args: { player: PlayerLike; teamApps: number }): number {
  const { player, teamApps } = args;
  let p = BOSMAN_BASE_P;
  if (player.morale < CONTRACT_LOW_MORALE) p += BOSMAN_LOW_MORALE_ADD;
  if (player.salary < BOSMAN_LOW_WAGE_RATIO * computeSalary(player.value)) p += BOSMAN_LOW_WAGE_ADD;
  if (player.apps < BOSMAN_LOW_APPS_RATIO * teamApps) p += BOSMAN_LOW_APPS_ADD;
  return Math.min(BOSMAN_P_CAP, p);
}

/** Риск для бейджа UI: p < 0.2 'low' · p < 0.45 'medium' · иначе 'high'. */
export function bosmanRiskOf(p: number): 'low' | 'medium' | 'high' {
  if (p < 0.2) return 'low';
  if (p < 0.45) return 'medium';
  return 'high';
}

/** Вероятность «хочет продлить» по рангу OVR × возраст (CONTRACT_AI_WANT). */
function aiWantOf(rank: number, age: number): number {
  for (const row of CONTRACT_AI_WANT) {
    if (rank <= row.maxRank && age <= row.maxAge) return row.p;
  }
  return CONTRACT_AI_WANT_DEFAULT;
}

export interface AiContractDecisions {
  /** Продления (мутации contractUntil/salary уже применены к PlayerLike на месте). */
  renewed: { player: PlayerLike; years: number; salary: number }[];
  /** Истекающие (contractUntil === season), которых клуб НЕ продлил. */
  expired: PlayerLike[];
}

/**
 * ИИ-продления для ОДНОГО клуба в сезонном переходе:
 *  1. кандидаты = contractUntil === season;
 *  2. p = want-матрица CONTRACT_AI_WANT (ранг по OVR × возраст) × (morale < 40 ? 0.5 : 1);
 *  3. guard бюджета: пропускаем продление, если суммарные зарплаты после него
 *     превысят CONTRACT_AI_WAGE_RATIO × income (проверять по нарастающей, начиная с лучших);
 *  4. guard состава: если после всех истечений в клубе < CONTRACT_AI_SQUAD_FLOOR игроков —
 *     лучший истекающий продлевается принудительно (p = 1);
 *  5. продление: contractUntil = season + contractAiYears(age), salary = renewDemand
 *     (ИИ не торгуется).
 * Клуб игрока НЕ обрабатывается этой функцией (продления — только вручную через API).
 */
export function aiContractDecisions(args: {
  rng: RNG;
  squad: PlayerLike[];
  season: number;
  /** Оценочный недельный доход клуба (weeklyIncomeEstimate). */
  income: number;
}): AiContractDecisions {
  const { rng, squad, season, income } = args;
  const renewed: AiContractDecisions['renewed'] = [];
  const expired: PlayerLike[] = [];

  const expiring = squad
    .filter((p) => p.contractUntil === season)
    .map((p) => ({ p, rank: ovrRankOf(p, squad) }))
    .sort((a, b) => a.rank - b.rank);
  if (expiring.length === 0) return { renewed, expired };

  // Guard состава (фикс QA №20 Фазы 3): после всех истечений останется < 15 →
  // продлеваем принудительно не одного лучшего, а столько лучших истекающих,
  // сколько не хватает до CONTRACT_AI_SQUAD_FLOOR (продления дешевле подписаний)
  const forcedCount = Math.min(
    Math.max(CONTRACT_AI_SQUAD_FLOOR - (squad.length - expiring.length), 0),
    expiring.length,
  );
  const forcedIds = new Set(expiring.slice(0, forcedCount).map((e) => e.p.id));

  // Guard бюджета: зарплаты не-истекающих + уже продлённых (по нарастающей)
  const expiringIds = new Set(expiring.map((e) => e.p.id));
  let wageAcc = squad
    .filter((p) => !expiringIds.has(p.id))
    .reduce((s, p) => s + p.salary, 0);
  const teamApps = teamAppsOf(squad);

  for (const { p, rank } of expiring) {
    const want = aiWantOf(rank, p.age)
      * (p.morale < CONTRACT_LOW_MORALE ? CONTRACT_AI_UNHAPPY_MULT : 1);
    const forced = forcedIds.has(p.id);
    if (!forced && rng() >= want) {
      expired.push(p);
      continue;
    }
    const demand = renewDemand({ player: p, squad, teamApps });
    if (!forced && wageAcc + demand > CONTRACT_AI_WAGE_RATIO * income) {
      expired.push(p); // guard бюджета: пропускаем продление
      continue;
    }
    const years = contractAiYears(p.age);
    p.contractUntil = season + years;
    p.salary = demand;
    wageAcc += demand;
    renewed.push({ player: p, years, salary: demand });
  }

  return { renewed, expired };
}

// ── Пополнение составов ИИ свободными агентами (фикс QA-инварианта №20) ───

type CoarseGroup = 'GK' | 'DEF' | 'MID' | 'FWD';

/** Грубая группа позиций для балансировки пополнения (6 позиционных → 4 линей). */
function coarseGroupOf(position: PlayerLike['position']): CoarseGroup {
  const g = positionGroupOf(position); // GK | DEF | DM | MID | AM | ST
  if (g === 'GK') return 'GK';
  if (g === 'DEF' || g === 'DM') return 'DEF';
  if (g === 'MID') return 'MID';
  return 'FWD'; // AM | ST
}

/** Минимумы линей для пополнения (соответствуют SQUAD_MIN_BY_GROUP). */
const REPLENISH_GROUP_MIN: Record<CoarseGroup, number> = { GK: 2, DEF: 4, MID: 4, FWD: 3 };

/**
 * Пополнение состава ИИ свободными агентами в сезонном переходе (§6.1):
 * жадный выбор — сначала закрываем дефицит позиционных групп (GK/DEF/MID/FWD
 * до минимумов), внутри группы и вне дефицитов — максимум OVR. Пул передаётся
 * уже отфильтрованным вызывающим (без активных лотов, проданных, дренированных).
 * Чистая функция: пул не мутирует (работает с копией), результата достаточно
 * для target-записей week.ts (шаг 6b).
 */
export function aiReplenishmentPicks(args: {
  squad: PlayerLike[];
  freeAgents: PlayerLike[];
  target: number;
  maxSignings: number;
}): PlayerLike[] {
  const { squad, freeAgents, target, maxSignings } = args;
  const need = Math.min(target - squad.length, maxSignings);
  if (need <= 0 || freeAgents.length === 0) return [];

  const counts: Record<CoarseGroup, number> = { GK: 0, DEF: 0, MID: 0, FWD: 0 };
  for (const p of squad) counts[coarseGroupOf(p.position)]++;

  const pool = [...freeAgents];
  const picks: PlayerLike[] = [];
  while (picks.length < need && pool.length > 0) {
    // группа с наибольшим дефицитом до минимума; null — берём любого лучшего
    let group: CoarseGroup | null = null;
    let worst = 0;
    for (const g of ['GK', 'DEF', 'MID', 'FWD'] as const) {
      const deficit = REPLENISH_GROUP_MIN[g] - counts[g];
      if (deficit > worst) {
        worst = deficit;
        group = g;
      }
    }
    let idx = -1;
    let bestOvr = -1;
    for (let i = 0; i < pool.length; i++) {
      if (group !== null && coarseGroupOf(pool[i].position) !== group) continue;
      if (pool[i].ovr > bestOvr) {
        bestOvr = pool[i].ovr;
        idx = i;
      }
    }
    if (idx === -1 && group !== null) {
      // нужной группы нет в пуле — берём любого лучшего
      for (let i = 0; i < pool.length; i++) {
        if (pool[i].ovr > bestOvr) {
          bestOvr = pool[i].ovr;
          idx = i;
        }
      }
    }
    if (idx === -1) break;
    const chosen = pool.splice(idx, 1)[0];
    picks.push(chosen);
    counts[coarseGroupOf(chosen.position)]++;
  }
  return picks;
}

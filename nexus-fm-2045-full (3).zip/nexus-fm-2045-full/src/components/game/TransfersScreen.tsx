'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Eye, EyeOff, Handshake, Inbox, Loader2, ShoppingBag, Tag, TrendingUp,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { PlayerDialog } from '@/components/game/PlayerDialog';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { PositionBadge } from '@/components/game/shared/PositionBadge';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { formatMoney, formatMoneyExact } from '@/lib/game/format';
import { canSellPlayer } from '@/lib/game/players';
import { KNOWLEDGE_TIER_LABELS, knowledgeTierOf } from '@/lib/game/scouting';
import type {
  MarketPositionFilter, MarketSort, PlayerDTO, TransferOfferDTO,
} from '@/lib/game/types';
import { interestLevel } from '@/lib/game/transfers';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const PRICE_OPTIONS = [
  { value: 'all', label: 'Любая' },
  { value: '5', label: '≤ €5M' },
  { value: '15', label: '≤ €15M' },
  { value: '40', label: '≤ €40M' },
  { value: '100', label: '≤ €100M' },
] as const;

const OVR_OPTIONS = [
  { value: '0', label: 'Любой' },
  { value: '45', label: '≥ 45' },
  { value: '55', label: '≥ 55' },
  { value: '65', label: '≥ 65' },
  { value: '75', label: '≥ 75' },
] as const;

function interestBadge(price: number, value: number) {
  const level = interestLevel(price, value);
  if (level === 'высокий') {
    return <Badge className="border border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]">высокий</Badge>;
  }
  if (level === 'средний') {
    return <Badge className="border border-[#FACC15]/40 bg-[#FACC15]/10 text-[#FACC15]">средний</Badge>;
  }
  return <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]">низкий</Badge>;
}

function keyAttrs(p: PlayerDTO): [string, string, string] {
  if (p.scoutKnowledge < 40) return ['?', '?', '?'];
  if (p.position === 'GK') return [String(p.reflexes), String(p.rushingOut), String(p.pace)];
  return [String(p.finishing), String(p.tackling), String(p.pace)];
}

/** Цвет среднего рейтинга сезона: ≥7.2 — зелёный, ≥6.8 — обычный, ниже — приглушённый. */
function avgRatingClass(rating: number): string {
  if (rating >= 7.2) return 'text-[#22C55E]';
  if (rating >= 6.8) return 'text-foreground';
  return 'text-muted-foreground';
}

/** Бейдж досье скаутов (туман войны): цвет по уровню знания. */
function scoutKnowledgeBadge(player: PlayerDTO) {
  const k = player.scoutKnowledge;
  if (k >= 70) {
    return (
      <Badge className="border border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]" title={`Знание ${k}%: точные данные`}>
        {k}%
      </Badge>
    );
  }
  if (k >= 40) {
    return (
      <Badge className="border border-[#FACC15]/40 bg-[#FACC15]/10 text-[#FACC15]" title={`Знание ${k}%: оценки (±6)`}>
        {k}%
      </Badge>
    );
  }
  return (
    <Badge className="border border-border/60 bg-secondary/50 text-muted-foreground" title={`Знание ${k}%: только OVR-вилка`}>
      {k}%
    </Badge>
  );
}

/** Переключатель наблюдения за игроком рынка (Модуль 3). */
function WatchButton({ player }: { player: PlayerDTO }) {
  const scoutCache = useGameStore((s) => s.scoutCache);
  const scoutWatch = useGameStore((s) => s.scoutWatch);
  const scoutUnwatch = useGameStore((s) => s.scoutUnwatch);
  const watched = scoutCache?.reports.find((r) => r.playerId === player.id)?.watched ?? false;
  return (
    <Button
      size="sm"
      variant={watched ? 'secondary' : 'ghost'}
      className="min-h-9 px-2"
      aria-label={watched ? 'Снять наблюдение' : 'Следить'}
      title={
        watched
          ? 'Наблюдается — знания растут каждую неделю'
          : `Назначить наблюдение (досье: ${KNOWLEDGE_TIER_LABELS[knowledgeTierOf(player.scoutKnowledge)]})`
      }
      onClick={(e) => {
        e.stopPropagation();
        if (watched) void scoutUnwatch(player.id);
        else void scoutWatch(player.id);
      }}
    >
      {watched ? (
        <Eye className="size-4 text-[#22C55E]" aria-hidden />
      ) : (
        <EyeOff className="size-4 text-muted-foreground" aria-hidden />
      )}
    </Button>
  );
}

function MarketTab() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const market = useGameStore((s) => s.market);
  const marketLoading = useGameStore((s) => s.marketLoading);
  const fetchMarket = useGameStore((s) => s.fetchMarket);

  const [position, setPosition] = useState<MarketPositionFilter>('ALL');
  const [maxPrice, setMaxPrice] = useState<string>('all');
  const [minOvr, setMinOvr] = useState<string>('0');
  const [sort, setSort] = useState<MarketSort>('ovr');
  const [selected, setSelected] = useState<{ player: PlayerDTO; price: number } | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    void fetchMarket({
      position,
      maxPrice: maxPrice === 'all' ? null : Number(maxPrice) * 1_000_000,
      minOvr: minOvr === '0' ? null : Number(minOvr),
      sort,
    });
  }, [position, maxPrice, minOvr, sort, fetchMarket]);

  // Модуль 3: досье скаутов для кнопок наблюдения
  const fetchScout = useGameStore((s) => s.fetchScout);
  useEffect(() => {
    void fetchScout();
  }, [fetchScout]);

  // Только свободные агенты рынка (без собственных лотов)
  const listings = useMemo(
    () => market.filter((l) => l.player.teamId === null),
    [market],
  );

  const budget = snapshot.save.transferBudget;

  return (
    <div className="space-y-4">
      {/* Фильтры */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <div>
          <Select value={position} onValueChange={(v) => setPosition(v as MarketPositionFilter)}>
            <SelectTrigger className="min-h-10 w-full" aria-label="Позиция">
              <SelectValue placeholder="Позиция" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Все позиции</SelectItem>
              <SelectItem value="GK">Вратари</SelectItem>
              <SelectItem value="DEF">Защитники</SelectItem>
              <SelectItem value="MID">Полузащитники</SelectItem>
              <SelectItem value="FWD">Нападающие</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Select value={maxPrice} onValueChange={setMaxPrice}>
            <SelectTrigger className="min-h-10 w-full" aria-label="Максимальная цена">
              <SelectValue placeholder="Цена" />
            </SelectTrigger>
            <SelectContent>
              {PRICE_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Select value={minOvr} onValueChange={setMinOvr}>
            <SelectTrigger className="min-h-10 w-full" aria-label="Минимальный рейтинг">
              <SelectValue placeholder="OVR" />
            </SelectTrigger>
            <SelectContent>
              {OVR_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>OVR {o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Select value={sort} onValueChange={(v) => setSort(v as MarketSort)}>
            <SelectTrigger className="min-h-10 w-full" aria-label="Сортировка">
              <SelectValue placeholder="Сортировка" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ovr">По рейтингу</SelectItem>
              <SelectItem value="price">По цене</SelectItem>
              <SelectItem value="age">По возрасту</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          Найдено лотов: <span className="tabular font-semibold text-foreground">{listings.length}</span>
        </span>
        <span>
          Бюджет: <span className="tabular font-semibold text-[#22C55E]">{formatMoney(budget)}</span>
        </span>
      </div>

      {/* Таблица рынка */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="scroll-thin overflow-x-auto rounded-lg border border-border/70 bg-card"
      >
        {marketLoading ? (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
            <Loader2 className="size-5 animate-spin" aria-hidden />
            Загружаем рынок…
          </div>
        ) : listings.length === 0 ? (
          <div className="py-10 text-center text-sm text-muted-foreground">
            Лотов не найдено — попробуйте изменить фильтры.
          </div>
        ) : (
          <Table className="min-w-[900px]">
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="h-10 w-12 text-center text-[11px]">OVR</TableHead>
                <TableHead className="h-10 text-[11px]">Игрок</TableHead>
                <TableHead className="h-10 w-14 text-center text-[11px]">Поз</TableHead>
                <TableHead className="h-10 text-center text-[11px]">Удар / Отбор / Скор.</TableHead>
                <TableHead className="h-10 w-16 text-center text-[11px]">Рейтинг</TableHead>
                <TableHead className="h-10 w-20 text-center text-[11px]">Срок</TableHead>
                <TableHead className="h-10 w-16 text-center text-[11px]">Досье</TableHead>
                <TableHead className="h-10 w-20 text-right text-[11px]">Цена</TableHead>
                <TableHead className="h-10 w-24 text-right text-[11px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="zebra">
              {listings.map((l) => {
                const p = l.player;
                const [a1, a2, a3] = keyAttrs(p);
                const affordable = l.price <= budget;
                return (
                  <TableRow
                    key={l.listingId}
                    onClick={() => {
                      setSelected({ player: p, price: l.price });
                      setDialogOpen(true);
                    }}
                    className="cursor-pointer border-border/40 transition-colors hover:bg-primary/5"
                  >
                    <TableCell className="py-2 text-center">
                      <OvrBadge ovr={p.ovr} size="sm" />
                    </TableCell>
                    <TableCell className="py-2">
                      <div className="flex min-w-0 items-center gap-2">
                        <span className="truncate text-xs font-medium">
                          {p.firstName} {p.lastName}
                        </span>
                        <span className="tabular text-[10px] text-muted-foreground">
                          {p.age} л · [{p.nationality}]
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="py-2 text-center">
                      <PositionBadge position={p.position} />
                    </TableCell>
                    <TableCell className="py-2 text-center text-xs tabular text-muted-foreground">
                      {a1} / {a2} / {a3}
                    </TableCell>
                    <TableCell
                      className={cn(
                        'py-2 text-center text-xs tabular font-semibold',
                        p.avgRating === null ? 'text-muted-foreground/60' : avgRatingClass(p.avgRating),
                      )}
                      title={
                        p.avgRating === null
                          ? 'Нет матчей в текущем сезоне'
                          : 'Средний рейтинг текущего сезона'
                      }
                    >
                      {p.avgRating === null ? '—' : p.avgRating.toFixed(1)}
                    </TableCell>
                    <TableCell className="py-2 text-center">
                      <Badge variant="secondary" className="tabular text-[10px]">
                        {l.expiresAt} т.
                      </Badge>
                    </TableCell>
                    <TableCell className="py-2 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {scoutKnowledgeBadge(p)}
                        <WatchButton player={p} />
                      </div>
                    </TableCell>
                    <TableCell className="py-2 text-right text-xs font-semibold tabular text-[#EAB308]">
                      {formatMoney(l.price)}
                    </TableCell>
                    <TableCell className="py-2 text-right">
                      <TooltipProvider delayDuration={200}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              className="min-h-9"
                              disabled={!affordable}
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelected({ player: p, price: l.price });
                                setDialogOpen(true);
                              }}
                            >
                              <ShoppingBag className="size-3.5" aria-hidden />
                              Купить
                            </Button>
                          </TooltipTrigger>
                          {!affordable ? (
                            <TooltipContent>Не хватает бюджета</TooltipContent>
                          ) : (
                            <TooltipContent>Открыть карточку и купить</TooltipContent>
                          )}
                        </Tooltip>
                      </TooltipProvider>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </motion.div>

      <PlayerDialog
        key={`mk:${selected?.player.id ?? 'none'}:${dialogOpen}`}
        player={selected?.player ?? null}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode="market"
        price={selected?.price}
        onBought={() => {
          void fetchMarket({
            position,
            maxPrice: maxPrice === 'all' ? null : Number(maxPrice) * 1_000_000,
            minOvr: minOvr === '0' ? null : Number(minOvr),
            sort,
          });
        }}
      />
    </div>
  );
}

/** Входящие офферы ИИ-клубов на игроков клуба игрока (Модуль 3). */
function OffersTab() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const offers = useGameStore((s) => s.transferOffers);
  const offersLoading = useGameStore((s) => s.transferOffersLoading);
  const fetchTransferOffers = useGameStore((s) => s.fetchTransferOffers);
  const acceptTransferOffer = useGameStore((s) => s.acceptTransferOffer);
  const rejectTransferOffer = useGameStore((s) => s.rejectTransferOffer);
  const loading = useGameStore((s) => s.loading);

  useEffect(() => {
    void fetchTransferOffers(true);
  }, [fetchTransferOffers]);

  if (offersLoading && offers.length === 0) {
    return (
      <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Проверяем предложения клубов…
      </div>
    );
  }

  if (offers.length === 0) {
    return (
      <Card className="border-border/70">
        <CardContent className="py-10 text-center text-sm text-muted-foreground">
          <Inbox className="mx-auto mb-2 size-6 text-muted-foreground/60" aria-hidden />
          Пока ни одного предложения. Скауты других клубов следят за вашими
          лидерами — особенно за недовольными и игроками последних лет контракта.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {offers.map((o: TransferOfferDTO) => {
        const player = o.player;
        const value = player.value;
        const premium = o.amount >= value;
        return (
          <motion.div
            key={o.offerId}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-wrap items-center gap-3 rounded-lg border border-border/60 bg-card p-3"
          >
            <OvrBadge ovr={player.ovr} size="sm" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="truncate text-sm font-semibold">
                  {player.firstName} {player.lastName}
                </span>
                <PositionBadge position={player.position} />
                <span className="tabular text-[10px] text-muted-foreground">
                  {player.age} л · стоимость {formatMoney(value)}
                </span>
              </div>
              <div className="mt-0.5 text-xs text-muted-foreground">
                <span className="font-medium text-foreground">{o.fromTeam}</span>
                {premium
                  ? ' предлагает больше рыночной стоимости'
                  : ' хочет приобрести игрока'}
                {' · ответ нужен '}
                <span className={cn('tabular font-semibold', o.expiresIn <= 1 && 'text-[#EF4444]')}>
                  {o.expiresIn} тур(а)
                </span>
              </div>
            </div>
            <span className="tabular text-base font-bold text-[#EAB308]">
              {formatMoneyExact(o.amount)}
            </span>
            <div className="flex gap-2">
              <Button
                size="sm"
                className="min-h-9"
                disabled={loading}
                onClick={() => void acceptTransferOffer(o.offerId)}
              >
                <Handshake className="size-3.5" aria-hidden />
                Принять
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="min-h-9"
                disabled={loading}
                onClick={() => void rejectTransferOffer(o.offerId)}
                title={
                  player.ovr >= 70 && player.morale < 45
                    ? 'Отказ может разозлить игрока'
                    : undefined
                }
              >
                Отклонить
              </Button>
            </div>
          </motion.div>
        );
      })}
      <p className="text-[11px] text-muted-foreground">
        Отказ по лидеру с низкой моралью бьёт по его настроению — он хотел смену клуба.
      </p>
    </div>
  );
}

function MySalesTab() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { myPlayers, myTeam } = snapshot;

  const listed = useMemo(
    () => myPlayers.filter((p) => p.askingPrice !== null),
    [myPlayers],
  );
  const sellable = useMemo(
    () =>
      myPlayers.filter(
        (p) => p.askingPrice === null && p.injuryWeeks === 0 && canSellPlayer(myPlayers as never, p.id),
      ),
    [myPlayers],
  );

  const [selected, setSelected] = useState<PlayerDTO | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <div className="space-y-4">
      {/* Мои лоты */}
      <Card className="border-border/70">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm">
            <Tag className="size-4 text-primary" aria-hidden />
            Выставлены на продажу ({listed.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {listed.length === 0 ? (
            <p className="py-4 text-center text-xs text-muted-foreground">
              Пока никто не выставлен. Продавайте лишних игроков — это пополнит баланс клуба.
            </p>
          ) : (
            <ul className="space-y-2">
              {listed.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center gap-2.5 rounded-lg border border-border/60 bg-secondary/30 p-2.5"
                >
                  <OvrBadge ovr={p.ovr} size="sm" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-medium">
                      {p.firstName} {p.lastName}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      Рыночная стоимость: {formatMoney(p.value)}
                    </div>
                  </div>
                  <PositionBadge position={p.position} />
                  <span className="tabular text-xs font-bold text-[#EAB308]">
                    {formatMoneyExact(p.askingPrice ?? 0)}
                  </span>
                  <span className="flex items-center gap-1">
                    <TrendingUp className="size-3 text-muted-foreground" aria-hidden />
                    {interestBadge(p.askingPrice ?? 0, p.value)}
                  </span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
            Каждый тур клубы изучают лоты: чем ближе цена к 75% стоимости, тем выше шанс
            предложения. Сделка проходит мгновенно по заявленной цене.
          </p>
        </CardContent>
      </Card>

      {/* Выставить игрока */}
      <Card className="border-border/70">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm">
            <Handshake className="size-4 text-primary" aria-hidden />
            Выставить игрока ({sellable.length} доступно)
          </CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          {sellable.length === 0 ? (
            <p className="px-6 py-4 text-center text-xs text-muted-foreground">
              Некого выставить: игроки травмированы или состав на минимуме.
            </p>
          ) : (
            <div className="scroll-thin overflow-x-auto">
              <Table className="min-w-[560px]">
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="h-9 w-12 text-center text-[11px]">OVR</TableHead>
                    <TableHead className="h-9 text-[11px]">Игрок</TableHead>
                    <TableHead className="h-9 w-14 text-center text-[11px]">Поз</TableHead>
                    <TableHead className="h-9 w-20 text-right text-[11px]">Стоимость</TableHead>
                    <TableHead className="h-9 w-20 text-right text-[11px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody className="zebra">
                  {sellable.map((p) => (
                    <TableRow
                      key={p.id}
                      onClick={() => {
                        setSelected(p);
                        setDialogOpen(true);
                      }}
                      className="cursor-pointer border-border/40 transition-colors hover:bg-primary/5"
                    >
                      <TableCell className="py-2 text-center">
                        <OvrBadge ovr={p.ovr} size="sm" />
                      </TableCell>
                      <TableCell className="py-2">
                        <div className="flex min-w-0 items-center gap-2">
                          <span className="truncate text-xs font-medium">
                            {p.firstName} {p.lastName}
                          </span>
                          <span className="tabular text-[10px] text-muted-foreground">{p.age} л</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-2 text-center">
                        <PositionBadge position={p.position} />
                      </TableCell>
                      <TableCell className="py-2 text-right text-xs tabular text-[#EAB308]">
                        {formatMoney(p.value)}
                      </TableCell>
                      <TableCell className="py-2 text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          className="min-h-9"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelected(p);
                            setDialogOpen(true);
                          }}
                        >
                          Продать
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <p className="text-[11px] text-muted-foreground">
        Клуб: {myTeam.name} · баланс {formatMoney(snapshot.save.balance)}
      </p>

      <PlayerDialog
        key={`sl:${selected?.id ?? 'none'}:${dialogOpen}`}
        player={selected}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode="squad"
        defaultSellMode
      />
    </div>
  );
}

/** Экран «Трансферы»: рынок с фильтрами + предложения клубов + мои продажи. */
export function TransfersScreen() {
  const offersCount = useGameStore((s) => s.transferOffers.length);
  const fetchTransferOffers = useGameStore((s) => s.fetchTransferOffers);

  useEffect(() => {
    void fetchTransferOffers(true);
  }, [fetchTransferOffers]);

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Трансферы"
        subtitle="Рынок со скаутингом, предложения клубов и продажа своих игроков"
        action={
          <Badge variant="outline" className="hidden text-[11px] sm:inline-flex">
            обновление рынка — каждый тур
          </Badge>
        }
      />
      <Tabs defaultValue="market">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="market" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <ShoppingBag className="size-4" aria-hidden />
            Рынок
          </TabsTrigger>
          <TabsTrigger value="offers" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Inbox className="size-4" aria-hidden />
            Предложения
            {offersCount > 0 ? (
              <Badge className="ml-0.5 border border-[#22C55E]/40 bg-[#22C55E]/10 px-1.5 text-[10px] text-[#22C55E]">
                {offersCount}
              </Badge>
            ) : null}
          </TabsTrigger>
          <TabsTrigger value="sales" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <TrendingUp className="size-4" aria-hidden />
            Мои продажи
          </TabsTrigger>
        </TabsList>
        <TabsContent value="market">
          <MarketTab />
        </TabsContent>
        <TabsContent value="offers">
          <OffersTab />
        </TabsContent>
        <TabsContent value="sales">
          <MySalesTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/**
 * Цели правления, board confidence, статусы должности, вердикт сезона.
 * Чистые функции (§3.2 architecture-phase3.md): без Prisma; вызываются
 * из week.ts (еженедельный апдейт + вердикт перехода) и снапшота (статус).
 */

import {
  BOARD_AMBITION_MIN_RANK, BOARD_CONF_MAX, BOARD_CONF_MIN, BOARD_DELTA_CUP_FINAL,
  BOARD_DELTA_CUP_ROUND, BOARD_DELTA_CUP_UPSET_LOSS, BOARD_DELTA_DRAW_DOWN,
  BOARD_DELTA_DRAW_EVEN, BOARD_DELTA_DRAW_UP, BOARD_DELTA_EURO_UPSET_LOSS,
  BOARD_DELTA_FINANCE_TARGET, BOARD_DELTA_HARMONY, BOARD_DELTA_LOSS,
  BOARD_DELTA_LOSS_DOWN, BOARD_DELTA_NEG_BALANCE, BOARD_DELTA_WAGES,
  BOARD_DELTA_WIN, BOARD_DELTA_WIN_UPSET, BOARD_FINANCE_TARGET_BONUS,
  BOARD_HARMONY_MORALE, BOARD_HONEYMOON_FLOOR, BOARD_HONEYMOON_WEEKS,
  BOARD_JOB_STATUSES, BOARD_OVER_BONUS, BOARD_OVER_CONF, BOARD_OVER_PLACES,
  BOARD_PACE_AHEAD, BOARD_PACE_BEHIND, BOARD_PACE_INTERVAL, BOARD_PACE_NEAR,
  BOARD_PACE_ON_TARGET, BOARD_PACE_REL_ZONE, BOARD_SACK_CONF, BOARD_SACK_CONF_HARD,
  BOARD_SACK_MISS_PLACES, BOARD_STRENGTH_GAP, BOARD_TARGET_LABELS, BOARD_WARN_BELOW,
  FINANCE_TARGET_DEBT_BALANCE, FINANCE_TARGET_LABELS, FINANCE_TARGET_WAGE_RATIO,
  WAGE_ALERT_RATIO, type BoardTargetCode, type FinanceTargetCode,
} from './constants';
import { clamp } from './rng';

// BOARD_HONEYMOON_WEEKS используется в week.ts (переход); реэкспорт для удобства
export { BOARD_HONEYMOON_WEEKS };
// Модуль 5: финцель переиспользуется week.ts через board (тип реэкспортирован
// из constants, чтобы цепочка board→constants→types осталась единой)
export type { FinanceTargetCode } from './constants';

export interface BoardTargetInfo {
  code: BoardTargetCode;
  place: number;
  label: string;
}

/** Ранг клуба по силе в лиге (1 = сильнейший). */
export function strengthRankOf(teams: { id: string; strength: number }[], userTeamId: string): number {
  const sorted = [...teams].sort((a, b) => b.strength - a.strength);
  const idx = sorted.findIndex((t) => t.id === userTeamId);
  return idx < 0 ? teams.length : idx + 1;
}

/**
 * Матрица целей: r=1 → champion(место 1) · 2–3 → ucl(3) · 4–6 → uel(6) ·
 * 7..⌈N/2⌉ → upper(⌈N/2⌉) · ≤ N−3 → safe(N−4) · последние 3 → survive(N−3).
 */
export function boardTargetFor(rank: number, teamCount: number): BoardTargetInfo {
  const N = teamCount;
  const r = clamp(Math.round(rank), 1, N);
  const half = Math.ceil(N / 2);
  let code: BoardTargetCode;
  let place: number;
  if (r === 1) {
    code = 'champion';
    place = 1;
  } else if (r <= 3) {
    code = 'ucl';
    place = 3;
  } else if (r <= 6) {
    code = 'uel';
    place = 6;
  } else if (r <= half) {
    code = 'upper';
    place = half;
  } else if (r <= N - 3) {
    code = 'safe';
    place = N - 4;
  } else {
    code = 'survive';
    place = N - 3;
  }
  return { code, place, label: BOARD_TARGET_LABELS[code] };
}

/** Потолок амбиций по силе клуба: ≥ 84 → 1 · 74–83 → 4 · < 74 → 7. */
export function ambitionMinRankOf(strength: number): number {
  if (strength >= 84) return BOARD_AMBITION_MIN_RANK.top;
  if (strength >= 74) return BOARD_AMBITION_MIN_RANK.mid;
  return BOARD_AMBITION_MIN_RANK.low;
}

/**
 * Цель следующего сезона: базовый ранг = место прошлого сезона (сезон 1 — ранг силы),
 * перевыполнение ужесточает на 1; клампы:
 *   r_min = BOARD_AMBITION_MIN_RANK по силе клуба (сила ≥ 84 → 1 · 74–83 → 4 · < 74 → 7),
 *   r_max = ранг силы + 3 («правление не ждёт чуда» в обе стороны).
 */
export function nextSeasonTarget(args: {
  teamCount: number;
  teams: { id: string; strength: number }[];
  userTeamId: string;
  /** null для сезона 1 (база — ранг силы). */
  prevPlace: number | null;
  harderByOverperformance: boolean;
}): BoardTargetInfo {
  const my = args.teams.find((t) => t.id === args.userTeamId);
  const strengthRank = strengthRankOf(args.teams, args.userTeamId);
  let base = args.prevPlace ?? strengthRank;
  if (args.harderByOverperformance) base -= 1;
  const rMin = ambitionMinRankOf(my?.strength ?? 60);
  const rMax = Math.max(rMin, strengthRank + 3);
  const rank = clamp(Math.round(base), rMin, rMax);
  return boardTargetFor(rank, args.teamCount);
}

/** Статус должности из confidence (7 градаций BOARD_JOB_STATUSES). */
export function jobStatusOf(confidence: number): { code: string; label: string } {
  for (const row of BOARD_JOB_STATUSES) {
    if (confidence >= row.min) return { code: row.code, label: row.label };
  }
  const last = BOARD_JOB_STATUSES[BOARD_JOB_STATUSES.length - 1];
  return { code: last.code, label: last.label };
}

/**
 * Уровень тревоги для UI: 'none' | 'warning' (< warnBelow) | 'ultimatum' (< 20).
 * D-6 (§4.3): warnBelow — эффективный порог предупреждения (по умолчанию
 * BOARD_WARN_BELOW = 30; престиж менеджера ≥ 70.0 снижает его до 25).
 */
export function boardWarnLevel(
  confidence: number,
  warnBelow: number = BOARD_WARN_BELOW,
): 'none' | 'warning' | 'ultimatum' {
  if (confidence < 20) return 'ultimatum';
  if (confidence < warnBelow) return 'warning';
  return 'none';
}

export interface BoardMatchInput {
  outcome: 'W' | 'D' | 'L';
  myStrength: number;
  oppStrength: number;
  /** Фаза 4: += 'euro' (двойная неделя — кубковый и еврокубковый матчи отдельно). */
  competition: 'league' | 'cup' | 'euro';
  /** Кубок/евро: клуб прошёл раунд. */
  roundPassed: boolean;
  /** Кубок/евро: выигран финал. */
  wonFinal: boolean;
  /** Кубок/евро: вылет от соперника слабее на ≥ BOARD_STRENGTH_GAP. */
  upsetCupLoss: boolean;
}

export interface BoardWeeklyInput {
  confidence: number;
  week: number;
  totalWeeks: number;
  honeymoonUntilWeek: number;
  /** Текущее место в ЛИГОВОЙ таблице. */
  place: number;
  targetPlace: number;
  targetCode: BoardTargetCode;
  teamCount: number;
  /** Матч клуба игрока этой недели (лига ИЛИ кубок); null = кубковая неделя без участия. */
  match: BoardMatchInput | null;
  /** Баланс после недели (в минусе → −3). */
  balance: number;
  /** Зарплаты / доход (> 0.7 → −1). */
  wageRatio: number;
  /** Средняя мораль состава (< 45 → −1). */
  avgMorale: number;
  // ── Модуль 5: финансовая цель сезона ──
  /** Финцель сезона (null — правление не ставило): выполняется → +1 в pace-интервал. */
  financeTarget?: FinanceTargetCode | null;
}

/**
 * МАТЧЕВАЯ дельта confidence (Фаза 4, §5.8 ТЗ): W/D/L по разнице сил
 * (W +2/+3 · D +1/0/−1 · L −2/−3) + надбавки турнира: кубок — раунд +4 /
 * финал +8 / обидный вылет −3; евро — раунд +4 / финал +8 / обидный
 * вылет −4 (BOARD_DELTA_EURO_UPSET_LOSS: «Европа обиднее»); лига — без
 * надбавок. Вызывается на КАЖДЫЙ матч недели (в двойную — 2 раза).
 */
export function boardMatchDeltaOf(m: BoardMatchInput): { delta: number; notes: string[] } {
  const notes: string[] = [];
  let delta = 0;

  const gap = m.oppStrength - m.myStrength;
  if (m.outcome === 'W') {
    if (gap >= BOARD_STRENGTH_GAP) {
      delta += BOARD_DELTA_WIN_UPSET;
      notes.push('победа над более сильным соперником');
    } else {
      delta += BOARD_DELTA_WIN;
      notes.push('победа');
    }
  } else if (m.outcome === 'D') {
    if (gap >= BOARD_STRENGTH_GAP) {
      delta += BOARD_DELTA_DRAW_UP;
      notes.push('ничья с более сильным соперником');
    } else if (-gap >= BOARD_STRENGTH_GAP) {
      delta += BOARD_DELTA_DRAW_DOWN;
      notes.push('потеря очков со слабым соперником');
    } else {
      delta += BOARD_DELTA_DRAW_EVEN;
    }
  } else {
    if (-gap >= BOARD_STRENGTH_GAP) {
      delta += BOARD_DELTA_LOSS_DOWN;
      notes.push('поражение от более слабого соперника');
    } else {
      delta += BOARD_DELTA_LOSS;
      notes.push('поражение');
    }
  }

  if (m.competition === 'cup') {
    if (m.wonFinal) {
      delta += BOARD_DELTA_CUP_FINAL;
      notes.push('триумф в финале кубка');
    } else if (m.roundPassed) {
      delta += BOARD_DELTA_CUP_ROUND;
      notes.push('выход в следующий раунд кубка');
    }
    if (m.upsetCupLoss) {
      delta += BOARD_DELTA_CUP_UPSET_LOSS;
      notes.push('обидный вылет из кубка');
    }
  } else if (m.competition === 'euro') {
    if (m.wonFinal) {
      delta += BOARD_DELTA_CUP_FINAL;
      notes.push('триумф в финале Кубка Европы');
    } else if (m.roundPassed) {
      delta += BOARD_DELTA_CUP_ROUND;
      notes.push('выход в следующий раунд Кубка Европы');
    }
    if (m.upsetCupLoss) {
      delta += BOARD_DELTA_EURO_UPSET_LOSS;
      notes.push('обидный вылет из Кубка Европы');
    }
  }

  return { delta, notes };
}

/**
 * НЕДЕЛЬНЫЕ дельты confidence (Фаза 4, §5.8 ТЗ) — ОДИН раз в неделю
 * независимо от числа матчей: темп к цели (week % BOARD_PACE_INTERVAL),
 * финансы (отрицательный баланс, зарплаты) и гармония (мораль).
 */
export function boardWeeklyExtras(args: Omit<BoardWeeklyInput, 'match'>): {
  delta: number;
  notes: string[];
} {
  const notes: string[] = [];
  let delta = 0;

  // Темп к цели — раз в 4 недели
  if (args.week % BOARD_PACE_INTERVAL === 0 && args.week >= BOARD_PACE_INTERVAL) {
    const rel = args.place - args.targetPlace;
    const relZone = args.place >= args.teamCount - 2; // зона вылета [N−2, N]
    if (relZone && args.targetCode !== 'survive') {
      delta += BOARD_PACE_REL_ZONE;
      notes.push('команда в зоне вылета — правление в ярости');
    } else if (rel <= -3) {
      delta += BOARD_PACE_AHEAD;
      notes.push('опережаем график достижения цели');
    } else if (rel <= 0) {
      delta += BOARD_PACE_ON_TARGET;
      notes.push('идём по графику цели');
    } else if (rel <= 3) {
      delta += BOARD_PACE_NEAR;
      notes.push('рядом с целевым местом');
    } else {
      delta += BOARD_PACE_BEHIND;
      notes.push('отстаём от цели сезона');
    }
    // Модуль 5: финцель — вместе с обзором темпа (+1 если выполняется)
    const ft = args.financeTarget ?? null;
    if (ft !== null && financeTargetOnTrack(ft, args.balance, args.wageRatio)) {
      delta += BOARD_DELTA_FINANCE_TARGET;
      notes.push('финансовая цель выполняется');
    }
  }

  if (args.balance < 0) {
    delta += BOARD_DELTA_NEG_BALANCE;
    notes.push('отрицательный баланс клуба');
  }
  if (args.wageRatio > WAGE_ALERT_RATIO) {
    delta += BOARD_DELTA_WAGES;
    notes.push('зарплаты превышают 70% дохода');
  }
  if (args.avgMorale < BOARD_HARMONY_MORALE) {
    delta += BOARD_DELTA_HARMONY;
    notes.push('низкая мораль в раздевалке');
  }

  return { delta, notes };
}

/**
 * Еженедельный пересчёт confidence (Фаза 3; Фаза 4 — разрезан на
 * boardMatchDeltaOf × N + boardWeeklyExtras, см. §5.8 ТЗ):
 *  - матчевые дельты КАЖДОГО матча недели (args.matches — 1..2; иначе args.match);
 *  - недельные дельты — темп/финансы/гармония (ровно один раз);
 *  - honeymoon: если week ≤ honeymoonUntilWeek → confidence ≥ BOARD_HONEYMOON_FLOOR;
 *  - clamp 0..100.
 * При одном матче итог бит-в-бит идентичен Фазе 3 (порядок notes сохранён).
 * Возвращает notes — причины дельты для новости «Правление: …».
 */
export function weeklyBoardUpdate(
  args: BoardWeeklyInput & { matches?: BoardMatchInput[] },
): {
  confidence: number;
  delta: number;
  notes: string[];
} {
  const notes: string[] = [];
  let delta = 0;

  // Фаза 4: массив матчей (кубок + евро в двойную неделю); легаси-путь — одиночный match
  const matchInputs =
    args.matches && args.matches.length > 0 ? args.matches : args.match ? [args.match] : [];
  for (const m of matchInputs) {
    const r = boardMatchDeltaOf(m);
    delta += r.delta;
    notes.push(...r.notes);
  }

  const extras = boardWeeklyExtras(args);
  delta += extras.delta;
  notes.push(...extras.notes);

  let confidence = clamp(args.confidence + delta, BOARD_CONF_MIN, BOARD_CONF_MAX);

  // Медовый месяц: иммунитет первых недель сезона
  if (args.week <= args.honeymoonUntilWeek && confidence < BOARD_HONEYMOON_FLOOR) {
    confidence = BOARD_HONEYMOON_FLOOR;
    notes.push('медовый месяц: правление терпеливо');
  }

  const realDelta = confidence - args.confidence;
  return { confidence, delta: realDelta, notes };
}

export interface BoardVerdict {
  sacked: boolean;
  verdict: 'met' | 'missed' | 'over';
  confidenceNext: number;
  /** BOARD_OVER_BONUS при перевыполнении, иначе 0. */
  bonus: number;
  /** Тексты новостей (вердикт, премия, отставка, цель следующего сезона). */
  news: string[];
  nextTarget: BoardTargetInfo;
}

/**
 * Вердикт цели в сезонном переходе:
 *  miss = place − targetPlace;
 *  over = miss ≤ −BOARD_OVER_PLACES; met = miss ≤ 0;
 *  sacked = (miss ≥ BOARD_SACK_MISS_PLACES && confidence < BOARD_SACK_CONF)
 *           || confidence < BOARD_SACK_CONF_HARD;
 *  confidenceNext: over → 70 · met → max(confidence, 60) · missed → без изменений;
 *  бонус €2M (категория prize) при over; nextTarget через nextSeasonTarget
 *  (harderByOverperformance; база — место только что завершившегося сезона).
 * Примечание реализации: targetPlace/targetCode текущего сезона передаются
 * явно (save.boardTargetPlace/save.boardTarget) — формула вердикта «miss =
 * place − targetPlace» из §3.2 требует цель завершившегося сезона.
 */
export function evaluateSeasonTarget(args: {
  /** Финальное место клуба игрока. */
  place: number;
  /** Цель завершившегося сезона: код + целевое место (save.boardTarget/…Place). */
  targetCode: BoardTargetCode;
  targetPlace: number;
  /** confidence ПОСЛЕ недельного апдейта финальной недели. */
  confidence: number;
  teamCount: number;
  teams: { id: string; strength: number }[];
  userTeamId: string;
  /** Место прошлого сезона (для расчёта следующей цели). */
  prevPlace: number | null;
}): BoardVerdict {
  const miss = args.place - args.targetPlace;
  const over = miss <= -BOARD_OVER_PLACES;
  const met = miss <= 0;
  const verdict: BoardVerdict['verdict'] = over ? 'over' : met ? 'met' : 'missed';
  const sacked =
    (miss >= BOARD_SACK_MISS_PLACES && args.confidence < BOARD_SACK_CONF)
    || args.confidence < BOARD_SACK_CONF_HARD;

  const confidenceNext = over
    ? BOARD_OVER_CONF
    : met
      ? Math.max(args.confidence, 60)
      : args.confidence;

  const bonus = over ? BOARD_OVER_BONUS : 0;

  const nextTarget = nextSeasonTarget({
    teamCount: args.teamCount,
    teams: args.teams,
    userTeamId: args.userTeamId,
    prevPlace: args.prevPlace ?? args.place, // база следующей цели — место завершившегося сезона
    harderByOverperformance: over,
  });

  const targetLabel = BOARD_TARGET_LABELS[args.targetCode];
  const news: string[] = [];
  if (over) {
    news.push(
      `Правление: цель сезона перевыполнена! Премия правления — €${BOARD_OVER_BONUS.toLocaleString('ru-RU')}.`,
    );
  } else if (met) {
    news.push(`Правление: цель сезона выполнена — «${targetLabel}».`);
  } else {
    news.push(
      `Правление: цель сезона провалена — ${args.place}-е место вместо топ-${args.targetPlace}.`,
    );
  }
  if (sacked) {
    news.push('Правление отправило вас в отставку. Карьера завершена.');
  }
  news.push(`Цель следующего сезона: «${nextTarget.label}».`);

  return { sacked, verdict, confidenceNext, bonus, news, nextTarget };
}

// ── Модуль 5: финансовая цель сезона + история доверия ────────────────────

/**
 * Назначение финцели сезона (при переходе): баланс < €5M → no_debt
 * («правление в панике»); wageRatio > 0.65 → wage_control. Иначе null —
 * правление не ставит доп. финансовых требований. При конфликте приоритет —
 * no_debt (долг опаснее раздутой ведомости).
 */
export function assignFinanceTargetOf(args: {
  balance: number;
  wageRatio: number;
}): FinanceTargetCode | null {
  if (args.balance < FINANCE_TARGET_DEBT_BALANCE) return 'no_debt';
  if (args.wageRatio > FINANCE_TARGET_WAGE_RATIO) return 'wage_control';
  return null;
}

/** Выполняется ли финцель НА ДАННЫЙ момент (для темп-бонуса pace-интервала). */
export function financeTargetOnTrack(
  target: FinanceTargetCode | null,
  balance: number,
  wageRatio: number,
): boolean {
  if (target === 'no_debt') return balance >= 0;
  if (target === 'wage_control') return wageRatio <= FINANCE_TARGET_WAGE_RATIO;
  return false;
}

/** Вердикт финцели по итогам сезона: выполнена? (для бонуса confidence). */
export function financeTargetMet(
  target: FinanceTargetCode | null,
  finalBalance: number,
  finalWageRatio: number,
): boolean {
  return financeTargetOnTrack(target, finalBalance, finalWageRatio);
}

// ── История доверия (график сезона) ───────────────────────────────────────

/** Состояние истории (JSON на GameSave.boardHistory, Модуль 5). */
export interface BoardHistoryState {
  season: number;
  points: { w: number; c: number }[];
}

/** Толерантный парсер boardHistory (null/битый JSON → пустая история). */
export function parseBoardHistory(
  raw: string | null | undefined,
  currentSeason: number,
): BoardHistoryState {
  if (raw === null || raw === undefined) return { season: currentSeason, points: [] };
  try {
    const parsed = JSON.parse(raw) as { season?: unknown; points?: unknown };
    const season = typeof parsed.season === 'number' ? Math.trunc(parsed.season) : currentSeason;
    const points = Array.isArray(parsed.points)
      ? parsed.points
          .filter(
            (p): p is { w: number; c: number } =>
              typeof p === 'object' && p !== null
              && typeof (p as Record<string, unknown>).w === 'number'
              && typeof (p as Record<string, unknown>).c === 'number',
          )
          .map((p) => ({ w: Math.trunc(p.w), c: clamp(Math.trunc(p.c), 0, 100) }))
      : [];
    return { season, points };
  } catch {
    return { season: currentSeason, points: [] };
  }
}

/**
 * Append точки недели (мутабельная копия→новый стейт): сезон сменился →
 * история начинается заново; дубликат недели — заменяется (идемпотентность
 * при повторном прогоне). Сортировка по неделе.
 */
export function appendBoardPoint(
  state: BoardHistoryState,
  season: number,
  week: number,
  confidence: number,
): BoardHistoryState {
  if (state.season !== season) return { season, points: [{ w: week, c: confidence }] };
  const points = state.points.filter((p) => p.w !== week);
  points.push({ w: week, c: confidence });
  points.sort((a, b) => a.w - b.w);
  return { season, points };
}

/** Канонический JSON истории (для GameSave.boardHistory). */
export function serializeBoardHistory(state: BoardHistoryState): string {
  return JSON.stringify({ season: state.season, points: state.points });
}

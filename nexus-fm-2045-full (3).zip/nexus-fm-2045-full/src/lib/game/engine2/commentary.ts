/**
 * ENGINE 2.0 — текстовая трансляция (генерация текстов событий).
 * Стилистика: живой комментатор, короткие фразы, без воды. Все шаблоны —
 * функции от контекста действия (исполнитель, адресат, зона, вратарь).
 */

import type { PlayerLike } from '../players';
import { pick, type RNG } from '../rng';

export function nameOf(p: PlayerLike): string {
  return `${p.firstName} ${p.lastName}`;
}

export function shortName(p: PlayerLike): string {
  return `${p.firstName[0]}. ${p.lastName}`;
}

const ZONE_NAME: Record<string, string> = {
  DL: 'на левом фланге своей трети',
  DC: 'в центре обороны',
  DR: 'на правом фланге своей трети',
  ML: 'слева в центре поля',
  MC: 'в центре поля',
  MR: 'справа в центре поля',
  AL: 'на левом краю чужой трети',
  AC: 'в атакующей трети',
  AR: 'на правом краю чужой трети',
  BOX: 'в штрафной!',
};

export function zoneName(zone: string): string {
  return ZONE_NAME[zone] ?? 'на поле';
}

// ── Розыгрыш / фоновые ────────────────────────────────────────────────────

export function textPossession(rng: RNG, team: string, zone: string): string {
  return pick(rng, [
    `«${team}» неторопливо контролируют мяч ${zoneName(zone)}.`,
    `«${team}» раскатывают комбинацию ${zoneName(zone)}.`,
    `${team} держат мяч, соперник пока только смотрит.`,
    `Пауза в игре: «${team}» ищут свободную зону ${zoneName(zone)}.`,
  ]);
}

export function textMomentum(rng: RNG, team: string): string {
  return pick(rng, [
    `Перелом! «${team}» подхватывают инициативу и несутся вперёд.`,
    `«${team}» прибавили — соперник прижат к своей штрафной!`,
    `Ход игры изменился: теперь всё держит «${team}».`,
  ]);
}

// ── Пасы ──────────────────────────────────────────────────────────────────

export function textProgPass(rng: RNG, p: PlayerLike, target: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} разворачивает атаку — острый пас на ${shortName(target)}.`,
    `${nameOf(p)} пасом вразрез находит ${shortName(target)} — мяч летит вперёд!`,
    `${shortName(p)} переводит игру на ${shortName(target)} — соперник отступает.`,
    `${nameOf(p)} делает пас в скорость ${shortName(target)}.`,
  ]);
}

export function textSafePass(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `${shortName(p)} играет аккуратно — назад, без риска.`,
    `${shortName(p)} перепасовка, темп снизили.`,
    `«Пас на своего»: ${shortName(p)} оставляет мяч команде.`,
  ]);
}

export function textIntercept(rng: RNG, d: PlayerLike, team: string): string {
  return pick(rng, [
    `${nameOf(d)} читает передачу и перехватывает мяч! «${team}» теряют атаку.`,
    `Отличная читка игры от ${shortName(d)} — перехват!`,
    `Пас разобран: ${shortName(d)} на перехвате — чисто.`,
  ]);
}

export function textThroughPass(rng: RNG, p: PlayerLike, target: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} — шикарный пас вразрез на ${shortName(target)}! Тот выходит на ударную позицию!`,
    `Разрезающая передача ${shortName(p)}: ${shortName(target)} убегает на ворота!`,
    `Вертикаль! ${shortName(p)} протаскивает мяч между линиями на ${shortName(target)}.`,
  ]);
}

export function textThroughCut(rng: RNG, d: PlayerLike): string {
  return pick(rng, [
    `${shortName(d)} выбивает мяч в последний момент — вертикальный пас прерван!`,
    `${nameOf(d)} начисто накрывает передачу вразрез.`,
    `Перехват на линии: ${shortName(d)} читает игру.`,
  ]);
}

// ── Дриблинг / дуэли ──────────────────────────────────────────────────────

export function textDribbleWin(rng: RNG, p: PlayerLike, d: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} обыгрывает ${shortName(d)} на замахе — красиво!`,
    `${shortName(p)} уходит в дриблинге от ${shortName(d)} и тащит мяч дальше!`,
    `Финт от ${shortName(p)}! ${shortName(d)} остался ни с чем.`,
    `${nameOf(p)} протаскивает мяч мимо ${shortName(d)} — зал аплодирует!`,
  ]);
}

export function textTackleWin(rng: RNG, d: PlayerLike): string {
  return pick(rng, [
    `${nameOf(d)} отбирает мяч чистым подкатом!`,
    `Жёсткий, но корректный отбор от ${shortName(d)}.`,
    `${shortName(d)} выбивает мяч — соперник остановлен.`,
  ]);
}

export function textDuelSpark(rng: RNG, p: PlayerLike, d: PlayerLike): string {
  return pick(rng, [
    `Верховая дуэль: ${shortName(p)} против ${shortName(d)} — искры летят!`,
    `Стенка! ${shortName(p)} и ${shortName(d)} сходятся в жёстком единоборстве.`,
  ]);
}

// ── Навесы и угловые ──────────────────────────────────────────────────────

export function textCrossIn(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} навешивает в штрафную — там сутолока!`,
    `Подача ${shortName(p)}: мяч летит к дальней штанге!`,
    `${shortName(p)} с фланга забрасывает мяч в чужую штрафную.`,
  ]);
}

export function textHeaderGoal(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `ГОЛОВОЙ! ${nameOf(p)} выигрывает воздух и переправляет мяч в сетку!`,
    `${nameOf(p)} выше всех на второй этаж — ГОЛ головой!`,
  ]);
}

export function textHeaderMiss(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} бьёт головой — чуть выше перекладины!`,
    `Верхом — мимо: ${shortName(p)} не попадает в створ с навеса.`,
  ]);
}

export function textCorner(rng: RNG, p: PlayerLike, team: string): string {
  return pick(rng, [
    `Угловой у «${team}». ${shortName(p)} идёт подавать.`,
    `Мяч за лицевой — корнер. Подача на ${shortName(p)}.`,
  ]);
}

export function textCornerCleared(rng: RNG, d: PlayerLike): string {
  return pick(rng, [
    `Угловой разыгран — ${shortName(d)} выносит мяч из штрафной.`,
    `Подача на дальнюю штангу… нет, ${shortName(d)} снимает мяч с головы нападающему.`,
  ]);
}

// ── Удары ─────────────────────────────────────────────────────────────────

export function textShotGoal(rng: RNG, p: PlayerLike, team: string): string {
  return pick(rng, [
    `ГОЛ! ${nameOf(p)} расстреливает угол — вратарь бессилен! (${team})`,
    `ГОЛ! Хлёсткий удар ${nameOf(p)} — точно в дальний! (${team})`,
    `ГОЛ! ${nameOf(p)} замыкает атаку «${team}» — точно в цель!`,
    `ГОЛ! ${nameOf(p)} проталкивает мяч мимо голкипера! (${team})`,
  ]);
}

export function textShotSave(rng: RNG, p: PlayerLike, gk: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} бьёт — но ${shortName(gk)} тащит! Фантастический сейв!`,
    `Удар ${shortName(p)} в угол — и невероятное отражение от ${nameOf(gk)}!`,
    `${shortName(gk)} на месте! Удар ${shortName(p)} — сейв.`,
    `Бьёт ${shortName(p)}… нет! ${nameOf(gk)} в красивом прыжке забирает мяч.`,
  ]);
}

export function textShotOff(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} пробивает — рядом со штангой!`,
    `Удар ${shortName(p)} — выше трибун!`,
    `${shortName(p)} бьёт с ходу — мимо створа.`,
    `Раскатались! ${nameOf(p)} из убойной позиции — выше перекладины!`,
  ]);
}

export function textShotBlocked(rng: RNG, p: PlayerLike, d: PlayerLike): string {
  return pick(rng, [
    `Удар ${shortName(p)} блокирует ${shortName(d)} — самоотверженно!`,
    `Бьёт ${shortName(p)} — и ${shortName(d)} ложится под мяч!`,
  ]);
}

export function textBigMiss(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `УБОЙНЫЙ момент… ${nameOf(p)} мимо! Такое надо реализовывать!`,
    `${nameOf(p)} перед пустым углом — и мимо! Трибуны хватаются за головы.`,
  ]);
}

// ── Пенальти / штрафные ───────────────────────────────────────────────────

export function textPenaltyAwarded(rng: RNG, p: PlayerLike, fouler: PlayerLike): string {
  return pick(rng, [
    `Фол в штрафной! Арбитр указывает на точку — ${shortName(fouler)} срезал ${shortName(p)}.`,
    `ПЕНАЛЬТИ! ${nameOf(fouler)} завалил ${shortName(p)} в чужой штрафной!`,
  ]);
}

export function textPenaltyGoal(rng: RNG, p: PlayerLike, team: string): string {
  return pick(rng, [
    `Пенальти! ${nameOf(p)} хладнокровно реализует — ГОЛ! (${team})`,
    `С точки — ГОЛ! ${nameOf(p)} не дрогнул. (${team})`,
  ]);
}

export function textPenaltySave(rng: RNG, p: PlayerLike, gk: PlayerLike): string {
  return pick(rng, [
    `Пенальти! Бьёт ${shortName(p)} — и ${nameOf(gk)} ТРАЩИТ удар! Невероятно!`,
    `С точки ${shortName(p)}… прочитано! ${nameOf(gk)} отражает!`,
  ]);
}

export function textPenaltyMiss(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `Пенальти мимо! ${nameOf(p)} посылает мяч выше перекладины — трибуны в шоке.`,
    `${nameOf(p)} не забивает с точки — каркас!`,
  ]);
}

export function textFreeKickShot(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `Штрафной! ${nameOf(p)} навешивает под удар.`,
    `Стандарт у штрафной — ${shortName(p)} готовится пробить.`,
  ]);
}

// ── Карточки / фолы / травмы ─────────────────────────────────────────────

export function textFoul(rng: RNG, d: PlayerLike, victim: PlayerLike): string {
  return pick(rng, [
    `Фол: ${shortName(d)} срубает ${shortName(victim)}. Свободный.`,
    `${nameOf(d)} задерживает ${shortName(victim)} за футболку — свисток.`,
    `Остановка игры: ${shortName(d)} играет грубо против ${shortName(victim)}.`,
  ]);
}

export function textYellow(rng: RNG, d: PlayerLike, victim: PlayerLike): string {
  return pick(rng, [
    `Жёлтая! ${nameOf(d)} за фол на ${shortName(victim)}.`,
    `Предупреждение ${shortName(d)} — арбитр устал терпеть.`,
  ]);
}

export function textRed(rng: RNG, d: PlayerLike): string {
  return pick(rng, [
    `КРАСНАЯ! ${nameOf(d)} отправляется отдыхать раньше времени!`,
    `Удаление! ${nameOf(d)} — прямая красная, команда в меньшинстве!`,
  ]);
}

export function textSecondYellow(rng: RNG, d: PlayerLike): string {
  return pick(rng, [
    `Вторая жёлтая — и ${nameOf(d)} покидает поле!`,
    `${shortName(d)} зарабатывает второе предупреждение — удаление!`,
  ]);
}

export function textInjury(rng: RNG, p: PlayerLike): string {
  return pick(rng, [
    `${nameOf(p)} на газоне — похоже, травма. Врачи на поле.`,
    `Беда: ${shortName(p)} повредился в единоборстве и не может продолжить игру.`,
  ]);
}

// ── Офсайды / выносы ──────────────────────────────────────────────────────

export function textOffside(rng: RNG, p: PlayerLike, team: string): string {
  return pick(rng, [
    `Офсайд. ${shortName(p)} забрался за спину защите «${team}».`,
    `Флажок поднял лайнсмен: ${nameOf(p)} в положении вне игры.`,
  ]);
}

export function textClearance(rng: RNG, d: PlayerLike): string {
  return pick(rng, [
    `${shortName(d)} выносит подальше от своих ворот.`,
    `Вынос от ${shortName(d)} — прочь из опасной зоны!`,
  ]);
}

export function textGkDistribution(rng: RNG, gk: PlayerLike, long: boolean): string {
  return long
    ? pick(rng, [
        `${nameOf(gk)} выбивает далеко — борьба на чужой половине.`,
        `Длинный ввод от ${shortName(gk)} — верховой мяч за спину защиты.`,
      ])
    : pick(rng, [
        `${nameOf(gk)} начинает розыгрыш с задней линии.`,
        `${shortName(gk)} играет коротко на защитника.`,
      ]);
}

// ── Рамки матча ───────────────────────────────────────────────────────────

export const KICKOFF_TEXT = 'Свисток! Матч начался — мяч в игре.';
export const HALFTIME_TEXT = 'Перерыв. Команды уходят в раздевалки.';
export const FULLTIME_TEXT = 'Финальный свисток! Матч завершён.';
export const KICKOFF_2ND_TEXT = 'Второй тайм в пути!';

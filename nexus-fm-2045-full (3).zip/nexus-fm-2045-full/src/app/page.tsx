'use client';

import { useEffect } from 'react';
import { AlertTriangle, RotateCw, Trophy } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { CareersScreen } from '@/components/game/CareersScreen';
import { GameShell } from '@/components/game/GameShell';
import { NewCareerFlow } from '@/components/game/NewCareerFlow';
import { useGameStore } from '@/lib/store';

function BootSkeleton() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-background cyber-grid p-4">
      <div className="w-full max-w-md space-y-4">
        <div className="flex items-center gap-3">
          <Skeleton className="size-12 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-40" />
            <Skeleton className="h-3 w-24" />
          </div>
        </div>
        <Skeleton className="h-24 w-full rounded-lg" />
        <div className="grid grid-cols-2 gap-3">
          <Skeleton className="h-20 rounded-lg" />
          <Skeleton className="h-20 rounded-lg" />
        </div>
        <Skeleton className="h-40 w-full rounded-lg" />
      </div>
    </main>
  );
}

export default function Home() {
  const phase = useGameStore((s) => s.phase);
  const hydrated = useGameStore((s) => s.hydrated);
  const error = useGameStore((s) => s.error);
  const saves = useGameStore((s) => s.saves);
  const hydrate = useGameStore((s) => s.hydrate);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  if (!hydrated) {
    return <BootSkeleton />;
  }

  // Ошибка загрузки списка карьер (сеть/сервер) — экран с повтором.
  if (phase === 'careers' && error && saves.length === 0) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background cyber-grid p-4">
        <Alert className="w-full max-w-md border-[#EF4444]/40">
          <AlertTriangle className="size-4 text-[#EF4444]" aria-hidden />
          <AlertTitle>Не удалось загрузить игру</AlertTitle>
          <AlertDescription className="mt-1">{error}</AlertDescription>
          <Button onClick={() => void hydrate()} className="mt-3 min-h-11 w-full">
            <RotateCw className="size-4" aria-hidden />
            Повторить
          </Button>
        </Alert>
      </main>
    );
  }

  if (phase === 'playing') {
    return <GameShell />;
  }

  if (phase === 'careers') {
    return <CareersScreen />;
  }

  // league-select | club-select | manager-setup
  return <NewCareerFlow />;
}

/**
 * Решения ИИ-тренера по ходу матча (Фаза 4): FSM «счёт × фаза» (9 состояний)
 * + Utility-таблица кандидатов с шумом, выбор замен, ленивое угадывание стилей
 * легаси-Team и смена стилей в сезонном переходе.
 * Чистый модуль (без Prisma и без движка) — §4.1 architecture-phase4.md.
 */

import {
  AI_COACH_RENAME_P, AI_STYLES, AI_STYLE_CHANGE_P, AI_STYLE_CHANGE_TOP_P,
  AI_STYLE_CODES, AI_STYLE_LEAGUE_BIAS, AI_STYLE_LEAGUE_BIAS_P, AI_STYLE_ASSIGN,
  AI_STYLE_TOP_RANK, FORMATIONS, MATCH_PLAN_DEFAULT, MENTALITY_ORDER,
  SUB_MAX, SUB_FATIGUE_MINUTE, UTILITY_MENTALITY, UTILITY_NOTHING, UTILITY_NOISE,
  UTILITY_SUB_CHASE, UTILITY_SUB_DEFENSIVE, UTILITY_SUB_FATIGUE,
  type AiStyleCode, type AiStyleDef,
} from './constants';
import { assignAiStyle } from './generate';
import { positionGroupOf, slotScore, type LineupPlayer, type PlayerLike } from './players';
import { clamp, type RNG } from './rng';
import type {
  DefLineLevel, FormationId, LeagueCode, MatchPlanDTO, Mentality, PositionGroup, TempoLevel,
} from './types';

// ── Состояние стороны для решений ───────────────────────────────────────────

export interface CoachSideState {
  teamId: string;
  style: AiStyleDef;
  /** Для клуба игрока — из Team.matchPlan; для ИИ — MATCH_PLAN_DEFAULT. */
  plan: MatchPlanDTO;
  /** Текущий менталитет в матче (сдвигается решениями). */
  mentality: Mentality;
  tempo: TempoLevel;
  formation: FormationId;
  /** Текущая XI (слоты формации). */
  onField: (string | null)[];
  /** Доступные запасные (не травмированные) — для выбора замены. */
  bench: PlayerLike[];
  /** Игроки текущей XI по id (включая вышедших). */
  byId: Map<string, LineupPlayer>;
  /** Ушедшие с поля: удаления/травмы этой стороны (в кандидаты замены не попадают). */
  offPitch: Set<string>;
  subsUsed: number;
  /** Счёт НА момент контрольной точки. */
  scored: number;
  conceded: number;
  /** effCond игрока на поле: стартёр = condition − drain×сегментов; вышедший = min(cond,92) − drain×(сегментов после входа). */
  effCondOf(playerId: string): number;
}

export interface SubPlan {
  outId: string;
  inId: string;
  reason: 'fatigue' | 'chase' | 'defensive';
}

export interface CoachDecision {
  /** −2..+2 шагов по MENTALITY_ORDER (уже прокламплено к defensive..allout). */
  mentalityShift: number;
  /** Сушка: темп в low (в связке со сдвигом вниз). */
  tempoLow: boolean;
  /** Погоня: темп в high. */
  tempoHigh: boolean;
  /** '3-4-3' при панике (иначе null). */
  formationSwitch: FormationId | null;
  subs: SubPlan[];
  /** Активировать «сушку» λ с этой КТ. */
  parkBus: boolean;
  /** Активировать «погоню» λ с этой КТ. */
  chase: boolean;
}

/** Дефолтный ИИ-план (паритет: движок применяет его и к клубу игрока при null). */
export function aiDefaultPlan(): MatchPlanDTO {
  return { ...MATCH_PLAN_DEFAULT };
}

// ── Вспомогательные выборы игроков ──────────────────────────────────────────

/** Пул текущей XI без уже заменённых в этом решении и ушедших с поля. */
function fieldCandidates(side: CoachSideState, usedOut: Set<string>): LineupPlayer[] {
  const out: LineupPlayer[] = [];
  for (const id of side.onField) {
    if (!id || usedOut.has(id) || side.offPitch.has(id)) continue;
    const p = side.byId.get(id);
    if (p) out.push(p);
  }
  return out;
}

/** Доступные запасные: не травмированные, не игравшие, не выходившие в этом решении. */
function benchCandidates(side: CoachSideState, usedIn: Set<string>): PlayerLike[] {
  const onFieldIds = new Set(side.onField);
  return side.bench.filter(
    (p) => p.injuryWeeks === 0 && !usedIn.has(p.id) && !onFieldIds.has(p.id) && !side.offPitch.has(p.id),
  );
}

/** Лучший запасной под СЛОТ out (по slotScore). */
function bestBenchForSlot(side: CoachSideState, usedIn: Set<string>, slotIndex: number): PlayerLike | null {
  const slotPos = FORMATIONS[side.formation].slots[slotIndex]?.position;
  if (!slotPos) return null;
  const pool = benchCandidates(side, usedIn);
  let best: PlayerLike | null = null;
  let bestScore = -1;
  for (const p of pool) {
    const s = slotScore(p, slotPos);
    if (s > bestScore) {
      bestScore = s;
      best = p;
    }
  }
  return best;
}

/** Лучший запасной широких групп (по OVR). */
function bestBenchOfGroups(side: CoachSideState, usedIn: Set<string>, groups: PositionGroup[]): PlayerLike | null {
  const pool = benchCandidates(side, usedIn).filter((p) => groups.includes(positionGroupOf(p.position)));
  if (pool.length === 0) return null;
  return [...pool].sort((a, b) => b.ovr - a.ovr)[0];
}

/** Худший по effCond из полевых стартёров (GK — только при effCond < 45). */
function worstByCond(side: CoachSideState, usedOut: Set<string>, groups: PositionGroup[] | null): LineupPlayer | null {
  const pool = fieldCandidates(side, usedOut).filter(
    (p) => (groups ? groups.includes(positionGroupOf(p.position)) : positionGroupOf(p.position) !== 'GK'),
  );
  const gk = fieldCandidates(side, usedOut).find((p) => p.position === 'GK' && side.effCondOf(p.id) < 45);
  if (gk && !groups) pool.push(gk);
  if (pool.length === 0) return null;
  return [...pool].sort((a, b) => side.effCondOf(a.id) - side.effCondOf(b.id))[0];
}

function slotIndexOf(side: CoachSideState, playerId: string): number {
  return side.onField.indexOf(playerId);
}

/** Усталостная замена: out = худший полевой стартёр, in = лучший под его слот. */
function fatigueSub(side: CoachSideState, usedOut: Set<string>, usedIn: Set<string>): SubPlan | null {
  const out = worstByCond(side, usedOut, null);
  if (!out) return null;
  const idx = slotIndexOf(side, out.id);
  const inP = idx >= 0 ? bestBenchForSlot(side, usedIn, idx) : null;
  if (!inP) return null;
  return { outId: out.id, inId: inP.id, reason: 'fatigue' };
}

/** Атакующая замена: out = min effCond из {DEF, DM}, in = лучший из {AM, ST, MID}. */
function chaseSub(side: CoachSideState, usedOut: Set<string>, usedIn: Set<string>): SubPlan | null {
  const out = worstByCond(side, usedOut, ['DEF', 'DM']);
  if (!out) return null;
  const inP = bestBenchOfGroups(side, usedIn, ['AM', 'ST', 'MID']);
  if (!inP) return null;
  return { outId: out.id, inId: inP.id, reason: 'chase' };
}

/** Оборонительная замена: out = min effCond из {AM, ST}, in = лучший из {DEF, DM}. */
function defensiveSub(side: CoachSideState, usedOut: Set<string>, usedIn: Set<string>): SubPlan | null {
  const out = worstByCond(side, usedOut, ['AM', 'ST']);
  if (!out) return null;
  const inP = bestBenchOfGroups(side, usedIn, ['DEF', 'DM']);
  if (!inP) return null;
  return { outId: out.id, inId: inP.id, reason: 'defensive' };
}

// ── Главное решение контрольной точки ───────────────────────────────────────

/**
 * FSM «счёт × фаза» задаёт ПАКЕТ допустимых действий; Utility-скоры с шумом ±10
 * выбирают, сработает ли каждое (порог + консерватизм «ничего»). Порядок бросков
 * rng зафиксирован: sub_fatigue → sub_chase → sub_defensive → mentality_up →
 * mentality_down → nothing (по одному броску на кандидата, независимо от применимости).
 */
export function coachDecide(
  rng: RNG,
  checkpoint: 46 | 70,
  side: CoachSideState,
  oppDefLine: DefLineLevel,
): CoachDecision {
  void oppDefLine; // зарезервировано ТЗ (дельты vertical против высокой линии применяются в match.ts)

  const late = checkpoint === 70;
  const diff = side.scored - side.conceded;
  const style = side.style;
  const plan = side.plan;

  // Шум кандидатов — фиксированный порядок бросков (детерминизм §4.2)
  const noiseOf = (): number => (rng() * 2 - 1) * UTILITY_NOISE;
  const nFatigue = noiseOf();
  const nChase = noiseOf();
  const nDefensive = noiseOf();
  const nMUp = noiseOf();
  const nMDown = noiseOf();
  const nNothing = noiseOf();
  const nothingScore = UTILITY_NOTHING + nNothing;

  const decision: CoachDecision = {
    mentalityShift: 0,
    tempoLow: false,
    tempoHigh: false,
    formationSwitch: null,
    subs: [],
    parkBus: false,
    chase: false,
  };

  const usedOut = new Set<string>();
  const usedIn = new Set<string>();
  let slotsLeft = Math.min(SUB_MAX - side.subsUsed, 3); // за одну КТ максимум 3 замены

  const pushSub = (sub: SubPlan | null): boolean => {
    if (!sub || slotsLeft <= 0) return false;
    usedOut.add(sub.outId);
    usedIn.add(sub.inId);
    decision.subs.push(sub);
    slotsLeft -= 1;
    return true;
  };

  // ── Усталостная замена: только на КТ ≥ SUB_FATIGUE_MINUTE (т.е. на 70') ──
  if (plan.fatigueSubs && checkpoint >= SUB_FATIGUE_MINUTE) {
    const out = worstByCond(side, usedOut, null);
    if (out) {
      const worstEff = side.effCondOf(out.id);
      const score = 40 + 60 * (1 - worstEff / 100) + nFatigue;
      if (score >= UTILITY_SUB_FATIGUE && score >= nothingScore) {
        pushSub(fatigueSub(side, usedOut, usedIn));
      }
    }
  }

  if (diff > 0) {
    // ═══ ВЕДЁМ ═══
    const mDownScore = 15 + 8 * diff + 12 * (late ? 1 : 0) + nMDown;
    const mDownOk = plan.leadMode !== 'hold'
      && mDownScore >= UTILITY_MENTALITY && mDownScore >= nothingScore;
    if (mDownOk) {
      decision.mentalityShift = mDownScore >= 55 ? -2 : -1;
      if (late) decision.tempoLow = true;
    }
    if (late && plan.leadMode !== 'hold') {
      const defScore = 20 + 10 * diff + 15 + nDefensive;
      if (defScore >= UTILITY_SUB_DEFENSIVE && defScore >= nothingScore) {
        pushSub(defensiveSub(side, usedOut, usedIn));
      }
      decision.parkBus = true; // plan.leadMode === 'park' (hold отфильтрован выше)
    }
  } else if (diff === 0) {
    // ═══ НИЧЬЯ ═══
    if (late) {
      const dScore = 15 + 12 + style.mentalityDownDrawDelta + nMDown;
      if (plan.leadMode !== 'hold' && dScore >= UTILITY_MENTALITY && dScore >= nothingScore) {
        decision.mentalityShift = -1;
        decision.tempoLow = style.parkAtDraw;
      }
      if (style.parkAtDraw && plan.leadMode !== 'hold') {
        const defScore = 20 + 15 + nDefensive;
        if (defScore >= UTILITY_SUB_DEFENSIVE && defScore >= nothingScore) {
          pushSub(defensiveSub(side, usedOut, usedIn));
        }
        decision.parkBus = true;
      }
    }
    // drawing·mid — решений нет
  } else {
    // ═══ ПРОИГРЫВАЕМ ═══
    if (plan.chaseMode !== 'steady') {
      const mUpScore = 15 + 10 * Math.abs(diff) + nMUp;
      if (mUpScore >= UTILITY_MENTALITY && mUpScore >= nothingScore) {
        decision.mentalityShift = late ? 2 : mUpScore >= 55 ? 2 : 1;
        decision.tempoHigh = true;
      }
      const chaseScore = 25 + 12 * Math.abs(diff) + 15 * (late ? 1 : 0) + nChase;
      if (chaseScore >= UTILITY_SUB_CHASE && chaseScore >= nothingScore) {
        const maxChase = late ? 3 : 2;
        for (let i = 0; i < maxChase && slotsLeft > 0; i++) {
          if (!pushSub(chaseSub(side, usedOut, usedIn))) break;
        }
      }
      if (late) {
        decision.chase = true; // plan.chaseMode === 'allout' (steady отфильтрован выше)
      }
    }
  }

  // Кламп сдвига менталитета к границам MENTALITY_ORDER
  const curIdx = MENTALITY_ORDER.indexOf(side.mentality);
  const rawIdx = clamp(curIdx + decision.mentalityShift, 0, MENTALITY_ORDER.length - 1);
  decision.mentalityShift = rawIdx - curIdx;
  const finalMentality = MENTALITY_ORDER[rawIdx];

  // «4-2-4»-паника: КТ 70, итоговый менталитет allout И ≥1 погоня-замена
  if (late && finalMentality === 'allout' && decision.subs.some((s) => s.reason === 'chase')) {
    decision.formationSwitch = '3-4-3';
  }

  return decision;
}

// ── Перестроение формации ───────────────────────────────────────────────────

/**
 * Жадное назначение текущей XI на слоты новой формации по slotScore
 * (по убыванию скоров; каждый игрок — в один слот). Чистая функция.
 */
export function remapForFormation(
  lineup: (string | null)[],
  players: PlayerLike[],
  formation: FormationId,
): (string | null)[] {
  const slots = FORMATIONS[formation].slots;
  const byId = new Map(players.map((p) => [p.id, p]));
  const members = lineup
    .map((id) => (id ? byId.get(id) : undefined))
    .filter((p): p is PlayerLike => !!p);
  if (members.length === 0) return new Array(slots.length).fill(null);

  const cands: { playerIdx: number; slotIdx: number; score: number }[] = [];
  members.forEach((p, pi) => {
    slots.forEach((slot, si) => {
      cands.push({ playerIdx: pi, slotIdx: si, score: slotScore(p, slot.position) });
    });
  });
  cands.sort((a, b) => b.score - a.score);

  const playerTaken = new Set<number>();
  const slotTaken = new Set<number>();
  const out: (string | null)[] = new Array(slots.length).fill(null);
  for (const c of cands) {
    if (playerTaken.has(c.playerIdx) || slotTaken.has(c.slotIdx)) continue;
    playerTaken.add(c.playerIdx);
    slotTaken.add(c.slotIdx);
    out[c.slotIdx] = members[c.playerIdx].id;
  }
  return out;
}

// ── Ленивая миграция легаси-стилей ─────────────────────────────────────────

/** Угадывание стиля легаси-Team по текущим тактическим полям (§4.5 ТЗ). */
export function guessAiStyle(t: {
  formation: string;
  mentality: string;
  tempo: string;
  pressing: string;
  playStyle: string;
}): AiStyleCode {
  if ((t.formation === '5-3-2' || t.formation === '4-5-1') && t.mentality === 'defensive') {
    return 'bus';
  }
  if (t.formation === '4-3-3' && t.mentality === 'attacking' && t.pressing === 'high') {
    return 'gegenpress';
  }
  if (t.formation === '4-2-3-1' && t.playStyle === 'passing') {
    return 'tikitaka';
  }
  if ((t.formation === '4-2-3-1' || t.formation === '4-4-2') && t.playStyle === 'counter') {
    return 'vertical';
  }
  return 'balanced';
}

// ── Смена стилей в сезонном переходе ────────────────────────────────────────

/**
 * Смена стилей ИИ-клубов в переходе: топ-6 по силе — p=0.10, остальные p=0.25;
 * при смене новый стиль ≠ текущий (переброс при совпадении); renameCoach — флаг
 * нового имени тренера (имя генерирует week.ts из пула лиги).
 * rng seed: `${saveId}:stylechg:${season}`.
 */
export function aiStyleChangesFor(
  rng: RNG,
  leagueCode: LeagueCode,
  teams: { id: string; strength: number; aiStyle: AiStyleCode }[],
): { teamId: string; nextStyle: AiStyleCode; renameCoach: boolean }[] {
  const sorted = [...teams].sort((a, b) => b.strength - a.strength);
  const out: { teamId: string; nextStyle: AiStyleCode; renameCoach: boolean }[] = [];
  for (let i = 0; i < sorted.length; i++) {
    const t = sorted[i];
    const p = i < AI_STYLE_TOP_RANK ? AI_STYLE_CHANGE_TOP_P : AI_STYLE_CHANGE_P;
    if (rng() >= p) continue;
    let next = assignAiStyle(rng, t.strength, leagueCode);
    let guard = 0;
    while (next === t.aiStyle && guard < 8) {
      next = assignAiStyle(rng, t.strength, leagueCode);
      guard++;
    }
    if (next === t.aiStyle) {
      next = AI_STYLE_CODES.find((c) => c !== t.aiStyle) ?? 'balanced';
    }
    const renameCoach = rng() < AI_COACH_RENAME_P;
    out.push({ teamId: t.id, nextStyle: next, renameCoach });
  }
  return out;
}

// ── Реэкспорт профиля стиля (обвязка AI_STYLES для движка) ─────────────────

export { AI_STYLES, AI_STYLE_CODES, AI_STYLE_LEAGUE_BIAS, AI_STYLE_LEAGUE_BIAS_P, AI_STYLE_ASSIGN };
export type { AiStyleCode, AiStyleDef };

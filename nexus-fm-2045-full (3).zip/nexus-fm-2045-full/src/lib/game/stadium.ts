/**
 * Модуль 5 «Инфраструктура 2.0»: расширение стадиона клуба игрока.
 * Три варианта блока трибун (+3 000 / +5 000 / +8 000 мест), цена растёт с
 * вместимостью (§ constants STADIUM_*), стройка занимает 56/70/84 дня.
 *
 * Чистые функции: engine/router.ts (POST /stadium — гварды/списание),
 * engine/week.ts (завершение стройки по absoluteDay), TerritoryScreen (каталог).
 */

import {
  STADIUM_BASE_SEAT_PRICE, STADIUM_DAYS_PER, STADIUM_MAX_CAPACITY,
  STADIUM_PRICE_ROUND, STADIUM_SIZE_GROWTH,
} from './constants';

/** Вариант расширения: сколько мест добавляет блок трибун. */
export type StadiumSeats = 3000 | 5000 | 8000;

/** Допустимые варианты (каталог). */
export const STADIUM_SEATS_OPTIONS: readonly StadiumSeats[] = [3000, 5000, 8000];

export function isStadiumSeats(v: unknown): v is StadiumSeats {
  return v === 3000 || v === 5000 || v === 8000;
}

/**
 * Цена блока на `seats` мест при текущей вместимости `capacity`:
 *   seats × 900€ × (1 + capacity / 100 000), округление до €1 000.
 * Чем больше стадион — тем дороже каждый следующий блок (земля/инфраструктура).
 */
export function stadiumPriceOf(capacity: number, seats: StadiumSeats): number {
  const raw = seats * STADIUM_BASE_SEAT_PRICE * (1 + capacity / STADIUM_SIZE_GROWTH);
  return Math.round(raw / STADIUM_PRICE_ROUND) * STADIUM_PRICE_ROUND;
}

/** Дни стройки блока (56 / 70 / 84). */
export function stadiumDaysOf(seats: StadiumSeats): number {
  return STADIUM_DAYS_PER[seats];
}

/** Гвард: влезает ли блок в лимит вместимости 90 000. */
export function stadiumFits(capacity: number, seats: number): boolean {
  return capacity + seats <= STADIUM_MAX_CAPACITY;
}

/**
 * Максимально доступный блок при текущей вместимости (для UI): наибольший
 * вариант каталога, который ещё влезает в лимит; null — стадион максимален.
 */
export function maxStadiumSeatsFor(capacity: number): StadiumSeats | null {
  const fits = STADIUM_SEATS_OPTIONS.filter((s) => stadiumFits(capacity, s));
  return fits.length > 0 ? fits[fits.length - 1] : null;
}

/** Все варианты каталога, доступные при вместимости (UI-фильтр). */
export function availableStadiumOptions(
  capacity: number,
): { seats: StadiumSeats; price: number; days: number }[] {
  return STADIUM_SEATS_OPTIONS.filter((s) => stadiumFits(capacity, s)).map((seats) => ({
    seats,
    price: stadiumPriceOf(capacity, seats),
    days: stadiumDaysOf(seats),
  }));
}

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolvePlayingSave } from '@/lib/game/api-helpers';
import {
  CONTRACT_MAX_YEARS, CONTRACT_MIN_YEARS,
  CONTRACT_OFFER_MAX_RATIO, CONTRACT_OFFER_MIN_RATIO, CONTRACT_RENEWABLE_YEARS_LEFT,
  SALARY_ROUND,
} from '@/lib/game/constants';
import { maxRenewYears, renewDemand, renewalOutcome, teamAppsOf, yearsLeftOf } from '@/lib/game/contracts';
import { ApiGameError } from '@/lib/game/error';
import type { PlayerLike } from '@/lib/game/players';
import { buildSnapshot } from '@/lib/game/snapshot';

const bodySchema = z.object({
  saveId: z.string().min(1),
  playerId: z.string().min(1),
  years: z.number().int().min(CONTRACT_MIN_YEARS).max(CONTRACT_MAX_YEARS),
  salary: z.number().int().min(0),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/contracts/renew — предложить продление контракта (Фаза 3, §6.1).
 * Stateless: accepted при offer ≥ 0.92 × demand (запись + свежий снапшот),
 * иначе counter с demand (контракт не меняется). «3 раунда / повтор через
 * 4 недели» — правило UI-диалога: формула demand детерминирована.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('INVALID_CONTRACT', 400);
    const { saveId, playerId, years, salary } = parsed.data;

    const save = await resolvePlayingSave(saveId);

    const playerRow = await db.player.findFirst({
      where: { id: playerId, saveId: save.id, teamId: save.teamId },
    });
    if (!playerRow) return fail('NOT_YOUR_PLAYER', 404);
    const player = playerRow as unknown as PlayerLike;

    if (player.preContractTeamId !== null) return fail('CONTRACT_PRECONTRACT', 409);
    if (yearsLeftOf(player.contractUntil, save.season) > CONTRACT_RENEWABLE_YEARS_LEFT) {
      return fail('CONTRACT_NOT_RENEWABLE', 400);
    }
    if (years < CONTRACT_MIN_YEARS || years > maxRenewYears(player.age)) {
      return fail('INVALID_CONTRACT', 400);
    }

    const squadRows = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    });
    const squad = squadRows as unknown as PlayerLike[];
    const teamApps = teamAppsOf(squad);
    const demand = renewDemand({ player, squad, teamApps });

    // Границы слайдера UI (80–130% спроса), округление к SALARY_ROUND
    const salaryMin = Math.floor((CONTRACT_OFFER_MIN_RATIO * demand) / SALARY_ROUND) * SALARY_ROUND;
    const salaryMax = Math.ceil((CONTRACT_OFFER_MAX_RATIO * demand) / SALARY_ROUND) * SALARY_ROUND;
    if (salary < salaryMin || salary > salaryMax) {
      return fail('INVALID_CONTRACT', 400);
    }

    const outcome = renewalOutcome(salary, demand);
    if (outcome === 'accepted') {
      await db.player.update({
        where: { id: player.id },
        data: {
          contractUntil: save.season + years,
          salary,
        },
      });
      const snapshot = await buildSnapshot(save.id);
      return NextResponse.json({ ok: true, outcome, demand, snapshot });
    }

    return NextResponse.json({ ok: true, outcome, demand });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/contracts/renew]', error);
    return fail('UNKNOWN', 500);
  }
}

import { generateSquad, poolContextOf } from '../src/lib/game/generate';
import { weeklyWages, weeklyIncomeEstimate } from '../src/lib/game/finances';
import { mulberry32 } from '../src/lib/game/rng';
import { LEAGUES } from '../src/lib/game/leagues';

const rng = mulberry32(2024);
for (const code of ['RPL', 'EPL'] as const) {
  const def = LEAGUES.find(l => l.code === code)!;
  const pool = poolContextOf(def);
  for (const club of [def.clubs[0], def.clubs[Math.floor(def.clubs.length/2)]]) {
    const squad = generateSquad(rng, club.str, pool);
    const wages = weeklyWages(squad);
    const income = weeklyIncomeEstimate(Math.ceil(def.teamCount/2), club.cap, def.teamCount);
    console.log(`${code} ${club.name}: str=${club.str} squad=${squad.length} avgOvr=${(squad.reduce((s,p)=>s+p.ovr,0)/squad.length).toFixed(1)} wages=${(wages/1000).toFixed(0)}K income=${(income/1000).toFixed(0)}K ratio=${(wages/income).toFixed(2)}`);
  }
}

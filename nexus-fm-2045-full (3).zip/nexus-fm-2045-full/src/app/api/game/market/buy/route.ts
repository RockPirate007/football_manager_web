import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolvePlayingSave } from '@/lib/game/api-helpers';
import { SQUAD_MAX, TRANSFER_BUDGET_RATIO } from '@/lib/game/constants';
import { contractUntilFromYears, contractYearsRoll } from '@/lib/game/contracts';
import { ApiGameError } from '@/lib/game/error';
import { freeShirtNumber, type PlayerLike } from '@/lib/game/players';
import { hashString, mulberry32 } from '@/lib/game/rng';
import { buildSnapshot } from '@/lib/game/snapshot';

const bodySchema = z
  .object({
    saveId: z.string().min(1).optional(),
    playerId: z.string().min(1).optional(),
    listingId: z.string().min(1).optional(),
  })
  .refine((v) => v.playerId !== undefined || v.listingId !== undefined, {
    message: 'playerId или listingId обязателен',
  });

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/market/buy — покупка игрока с трансферного рынка.
 * Body: { saveId, playerId } (§6.3) либо { saveId, listingId } — оба варианта
 * резолвятся в один лот. Без saveId (легаси-клиент Фазы 1) — последний
 * открытый активный сейв.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('NOT_FOR_SALE', 409);

    const save = await resolvePlayingSave(parsed.data.saveId ?? null);

    // listingId → playerId (контракт Task 10-a-2: { saveId, listingId })
    let playerId = parsed.data.playerId ?? null;
    if (!playerId && parsed.data.listingId) {
      const byListing = await db.transferListing.findUnique({
        where: { id: parsed.data.listingId },
      });
      if (!byListing || byListing.saveId !== save.id || byListing.status !== 'active') {
        return fail('NOT_FOR_SALE', 409);
      }
      playerId = byListing.playerId;
    }

    const listing = await db.transferListing.findFirst({
      where: { playerId: playerId as string, status: 'active' },
      include: { player: true },
    });
    if (!listing || listing.saveId !== save.id) return fail('NOT_FOR_SALE', 409);
    if (listing.player.teamId !== null) return fail('NOT_FOR_SALE', 409);

    const squadCount = await db.player.count({
      where: { saveId: save.id, teamId: save.teamId },
    });
    if (squadCount >= SQUAD_MAX) return fail('SQUAD_FULL', 409);

    const budget = Math.max(0, Math.floor(save.balance * TRANSFER_BUDGET_RATIO));
    if (listing.price > budget) return fail('INSUFFICIENT_BUDGET', 409);

    const squad = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    });
    const shirtNumber = freeShirtNumber(squad as unknown as PlayerLike[]);
    const name = `${listing.player.firstName} ${listing.player.lastName}`;

    // Фаза 3: покупка = новый контракт (детерминированный бросок срока по возрасту)
    const buyRng = mulberry32(hashString(`${save.id}:contractbuy:${listing.playerId}`));
    const contractUntil = contractUntilFromYears(
      save.season,
      contractYearsRoll(buyRng, listing.player.age),
    );

    await db.$transaction([
      db.gameSave.update({
        where: { id: save.id },
        data: { balance: save.balance - listing.price },
      }),
      db.player.update({
        where: { id: listing.playerId },
        data: { teamId: save.teamId, shirtNumber, contractUntil },
      }),
      db.transferListing.update({
        where: { id: listing.id },
        data: { status: 'sold' },
      }),
      db.financeRecord.create({
        data: {
          id: crypto.randomUUID(),
          saveId: save.id,
          season: save.season,
          week: save.week,
          kind: 'expense',
          category: 'transfer_out',
          amount: listing.price,
          description: `Покупка игрока: ${name}`,
        },
      }),
      db.newsItem.create({
        data: {
          id: crypto.randomUUID(),
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'transfer',
          message: `${name} подписал контракт! Сумма трансфера — €${listing.price.toLocaleString('ru-RU')}.`,
        },
      }),
    ]);

    const snapshot = await buildSnapshot(save.id);
    return NextResponse.json({ ok: true, snapshot });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/market/buy]', error);
    return fail('UNKNOWN', 500);
  }
}

import { NextResponse } from 'next/server';
import { buildEuroSnapshot, normalizeErrorCode, resolveSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import type { EuroResponse } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/euro?saveId= — снапшот Кубка Европы (Фаза 4, §6.1
 * architecture-phase4.md): статус клуба игрока, сетка 4 раундов сезона
 * (Match competition='euro', cupRound = еврораунд), 16 участников (вкл.
 * гостей), квоты лиг и следующий матч клуба. resolveSave (НЕ Playing) —
 * finished-сейвы доступны для просмотра. Ленивой инициализации здесь нет:
 * состояние строго по полям GameSave (евро стартует в week.ts).
 */
export async function GET(request: Request) {
  try {
    const save = await resolveSave(saveIdFromQuery(request));
    const euro = await buildEuroSnapshot(save);
    const response: EuroResponse = { ok: true, euro };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/euro]', error);
    return fail('UNKNOWN', 500);
  }
}

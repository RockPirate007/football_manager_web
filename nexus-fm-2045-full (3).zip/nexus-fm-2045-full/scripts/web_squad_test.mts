import { generateSquad, poolContextOf } from '../src/lib/game/generate';
import { mulberry32 } from '../src/lib/game/rng';
import { LEAGUES } from '../src/lib/game/leagues';

const def = LEAGUES.find(l => l.code === 'RPL')!;
const pool = poolContextOf(def);
const rng = mulberry32(12345);
const squad = generateSquad(rng, 82, pool);
const p = squad[0];
console.log('WEB first player:', p.firstName, p.lastName, p.position, 'age', p.age, 'ovr', p.ovr, 'pot', p.potential, 'value', p.value, 'salary', p.salary);
console.log('WEB squad: n=', squad.length, 'sumOvr=', squad.reduce((s,x)=>s+x.ovr,0), 'sumValue=', squad.reduce((s,x)=>s+x.value,0), 'sumSalary=', squad.reduce((s,x)=>s+x.salary,0));

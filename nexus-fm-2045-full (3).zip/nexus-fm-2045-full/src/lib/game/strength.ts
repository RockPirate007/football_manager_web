/**
 * Сила линий команды из состава и тактики + тактические модификаторы.
 * Модуль изоморфный (без серверных зависимостей) — используется и в
 * движке матча, и на клиенте (экран Тактики).
 * Разделы 4.6–4.7 docs/architecture.md.
 */

import {
  COUNTER_DEF_BONUS, DEF_LINE_MOD, EFF_ATK, EFF_DEF, EMPTY_SLOT_STRENGTH,
  FORMATIONS, FORMATION_CLASS, FORMATION_CLASS_RULES, HOME_ADVANTAGE,
  LINE_REF, LINE_WEIGHT, MENTALITY_MODS, POSITION_FIT, PRESSING_DEF_MOD,
  PRESSING_OPP_ATTACK_MOD, SLOT_LINE_WEIGHT, STYLE_MATRIX,
} from './constants';
import { positionGroupOf, type LineupPlayer, type PlayerLike } from './players';
import type {
  DefLineLevel, FormationId, Mentality, PlayStyle, Position, PositionGroup,
  PressingLevel, TempoLevel,
} from './types';

export function positionFitOf(playerGroup: PositionGroup, slotGroup: PositionGroup): number {
  return POSITION_FIT[playerGroup][slotGroup];
}

/** Полное тактическое состояние команды для расчёта силы (Фаза 3: параметризовано — P = PlayerLike на сервере, LineupPlayer-совместимые DTO на клиенте). */
export interface TeamTacticState<P extends LineupPlayer = PlayerLike> {
  teamId: string;
  players: P[];
  formation: FormationId;
  mentality: Mentality;
  tempo: TempoLevel;
  pressing: PressingLevel;
  defLine: DefLineLevel;
  playStyle: PlayStyle;
  lineup: (string | null)[]; // порядок = слоты формации
}

export interface TeamLines {
  attack: number;
  midfield: number;
  defence: number;
  overall: number;
}

/**
 * Шаг 1–2 (4.6): вклад игрока в слот → вклад слота в линии → нормализация
 * на эталон 4-4-2 (LINE_REF). Пустой слот = EMPTY_SLOT_STRENGTH.
 */
export function computeLines(state: TeamTacticState<LineupPlayer>): TeamLines {
  const slots = FORMATIONS[state.formation].slots;
  const byId = new Map(state.players.map((p) => [p.id, p]));
  let attack = 0;
  let midfield = 0;
  let defence = 0;

  slots.forEach((slot, i) => {
    const pid = state.lineup[i] ?? null;
    const p = pid ? byId.get(pid) : undefined;
    let contribution: number;
    if (p) {
      const fit = positionFitOf(positionGroupOf(p.position), positionGroupOf(slot.position));
      contribution =
        p.ovr * fit * (p.condition / 100) * (0.9 + (0.2 * p.morale) / 100);
    } else {
      contribution = EMPTY_SLOT_STRENGTH;
    }
    const w = SLOT_LINE_WEIGHT[positionGroupOf(slot.position)];
    attack += contribution * w.attack;
    midfield += contribution * w.midfield;
    defence += contribution * w.defence;
  });

  const atk = attack / LINE_REF.attack;
  const mid = midfield / LINE_REF.midfield;
  const def = defence / LINE_REF.defence;
  const overall = Math.round(
    LINE_WEIGHT.attack * atk + LINE_WEIGHT.midfield * mid + LINE_WEIGHT.defence * def,
  );
  return { attack: atk, midfield: mid, defence: def, overall };
}

/** Модифицированные эффективные силы (после 4.7). */
export interface ModifiedLines {
  effAtk: number;
  effDef: number;
  effMid: number;
}

interface SideMods {
  atk: number;
  def: number;
  mid: number;
}

function sideMods(me: TeamTacticState, opp: TeamTacticState, applyHomeAdv: boolean): SideMods {
  let atk = applyHomeAdv ? HOME_ADVANTAGE : 1;
  let def = applyHomeAdv ? HOME_ADVANTAGE : 1;
  let mid = applyHomeAdv ? HOME_ADVANTAGE : 1;

  const ment = MENTALITY_MODS[me.mentality];
  atk *= ment.attack;
  def *= ment.defence;
  mid *= ment.midfield;

  const dl = DEF_LINE_MOD[me.defLine];
  atk *= dl.attack;
  def *= dl.defence;

  def *= PRESSING_DEF_MOD[me.pressing]; // прессинг low → своя оборона ×1.02

  atk *= STYLE_MATRIX[me.playStyle][opp.playStyle]; // матрица стилей на мою атаку

  // Классы формаций
  const myClass = FORMATION_CLASS[me.formation];
  const oppClass = FORMATION_CLASS[opp.formation];
  for (const rule of FORMATION_CLASS_RULES) {
    if (rule.mine === myClass && rule.opp === oppClass) {
      if (rule.atk) atk *= rule.atk;
      if (rule.def) def *= rule.def;
    }
  }

  // Контратаки сильны против атакующих менталитетов
  if (me.playStyle === 'counter' && (opp.mentality === 'attacking' || opp.mentality === 'allout')) {
    def *= COUNTER_DEF_BONUS;
  }

  // Высокий прессинг соперника снижает мою атаку
  atk *= PRESSING_OPP_ATTACK_MOD[opp.pressing];

  return { atk, def, mid };
}

/**
 * Шаг 3 (4.6) + модификаторы (4.7): effectiveAttack/Defence/Midfield обеих команд.
 * Вызывается движком матча перед расчётом λ. При opts.neutral домашнее
 * преимущество НЕ применяется (финал кубка — нейтральное поле).
 */
export function applyModifiers(
  home: TeamTacticState,
  away: TeamTacticState,
  opts?: { neutral?: boolean },
): { home: ModifiedLines; away: ModifiedLines } {
  const homeLines = computeLines(home);
  const awayLines = computeLines(away);
  const hm = sideMods(home, away, !opts?.neutral);
  const am = sideMods(away, home, false);

  return {
    home: {
      effAtk: (EFF_ATK.attack * homeLines.attack + EFF_ATK.midfield * homeLines.midfield) * hm.atk,
      effDef: (EFF_DEF.defence * homeLines.defence + EFF_DEF.midfield * homeLines.midfield) * hm.def,
      effMid: homeLines.midfield * hm.mid,
    },
    away: {
      effAtk: (EFF_ATK.attack * awayLines.attack + EFF_ATK.midfield * awayLines.midfield) * am.atk,
      effDef: (EFF_DEF.defence * awayLines.defence + EFF_DEF.midfield * awayLines.midfield) * am.def,
      effMid: awayLines.midfield * am.mid,
    },
  };
}

/** Вклад игрока в слот (для UI-подсказок). */
export function playerContribution(p: LineupPlayer, slotPosition: Position): number {
  const fit = positionFitOf(positionGroupOf(p.position), positionGroupOf(slotPosition));
  return p.ovr * fit * (p.condition / 100) * (0.9 + (0.2 * p.morale) / 100);
}

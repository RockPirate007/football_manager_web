'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, CheckCircle2, FileSignature, HeartPulse, LayoutGrid, List, ShieldCheck, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { PlayerDialog } from '@/components/game/PlayerDialog';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { PositionBadge } from '@/components/game/shared/PositionBadge';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { broadGroupOf, squadMinimumsSatisfied } from '@/lib/game/players';
import { yearsLeftOf } from '@/lib/game/contracts';
import { formatMoney } from '@/lib/game/format';
import type { PlayerDTO, Position } from '@/lib/game/types';
import { effectiveLineup } from '@/lib/game/lineup';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

type PosFilter = 'ALL' | 'GK' | 'DEF' | 'MID' | 'FWD';
type SortKey = 'ovr' | 'position' | 'age' | 'value' | 'morale' | 'contract';

const POSITION_ORDER: Record<Position, number> = {
  GK: 0, DL: 1, DC: 2, DR: 3, DML: 4, DMC: 5, DMR: 6,
  ML: 7, MC: 8, MR: 9, AML: 10, AMC: 11, AMR: 12, ST: 13,
};

function moraleBadge(morale: number): { label: string; className: string } {
  if (morale >= 70) return { label: `↑ ${morale}`, className: 'text-[#22C55E]' };
  if (morale >= 40) return { label: `— ${morale}`, className: 'text-muted-foreground' };
  return { label: `↓ ${morale}`, className: 'text-[#EF4444]' };
}

function conditionBar(condition: number): { className: string } {
  return {
    className:
      condition >= 70 ? 'bg-[#22C55E]' : condition >= 45 ? 'bg-[#FACC15]' : 'bg-[#EF4444]',
  };
}

/** Бейдж срока контракта (Фаза 3): «до {сезон}», «истекает» — жёлтый (§7.1), «уходит» — красный при предконтракте. */
function contractBadge(
  p: PlayerDTO,
  season: number,
): { label: string; title: string; className: string } {
  // Та же шкала, что на сервере: текущий сезон входит в срок контракта.
  const yearsLeft = yearsLeftOf(p.contractUntil, season);
  if (p.preContract) {
    return {
      label: 'уходит',
      title: 'Предконтракт с другим клубом — покинет команду в конце сезона (правило Босмана)',
      className: 'border-[#EF4444]/50 bg-[#EF4444]/10 text-[#EF4444]',
    };
  }
  if (yearsLeft <= 1) {
    return {
      label: 'истекает',
      title: `Контракт истекает по окончании сезона ${p.contractUntil} — продлите его в карточке игрока`,
      className: 'border-[#EAB308]/50 bg-[#EAB308]/10 text-[#EAB308]',
    };
  }
  return {
    label: `до ${p.contractUntil}`,
    title:
      yearsLeft === 2
        ? `Контракт до конца сезона ${p.contractUntil} — окно продления уже открыто`
        : `Контракт до конца сезона ${p.contractUntil} (ещё ${yearsLeft} г. с текущим)`,
    className: 'border-border/60 bg-secondary/50 text-muted-foreground',
  };
}

/** Цвет среднего рейтинга сезона: ≥7.2 — зелёный, ≥6.8 — обычный, ниже — приглушённый. */
function avgRatingClass(rating: number): string {
  if (rating >= 7.2) return 'text-[#22C55E]';
  if (rating >= 6.8) return 'text-foreground';
  return 'text-muted-foreground';
}

function SquadVisualHeader({
  players,
  starters,
  onSelect,
}: {
  players: PlayerDTO[];
  starters: Set<string>;
  onSelect: (player: PlayerDTO) => void;
}) {
  const featured = [...players]
    .sort((a, b) => b.ovr - a.ovr || b.condition - a.condition)
    .slice(0, 6);
  const averageCondition = players.length
    ? Math.round(players.reduce((sum, player) => sum + player.condition, 0) / players.length)
    : 0;
  const averageMorale = players.length
    ? Math.round(players.reduce((sum, player) => sum + player.morale, 0) / players.length)
    : 0;
  const fit = players.filter((player) => player.injuryWeeks === 0 && player.condition >= 70).length;

  return (
    <section className="visual-panel rounded-2xl border border-primary/20 bg-card p-4 shadow-[0_18px_50px_rgba(0,0,0,.2)] sm:p-5" style={{ backgroundImage: "url('/visuals/stadium-night.svg')" }}>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-primary"><Sparkles className="size-3.5" aria-hidden /> Состав // live view</p>
          <h2 className="mt-1 text-xl font-black">Командный профиль</h2>
          <p className="mt-1 text-xs text-muted-foreground">Лидеры, готовность и форма перед следующей игровой неделей</p>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          {[
            { label: 'Готовы', value: fit, icon: ShieldCheck, tone: 'text-[#22C55E]' },
            { label: 'Готовность', value: `${averageCondition}%`, icon: Activity, tone: 'text-primary' },
            { label: 'Мораль', value: `${averageMorale}%`, icon: HeartPulse, tone: 'text-[#A78BFA]' },
          ].map((metric) => {
            const Icon = metric.icon;
            return <div key={metric.label} className="min-w-[68px] rounded-lg border border-border/60 bg-background/55 px-2 py-2"><Icon className={`mx-auto mb-1 size-3.5 ${metric.tone}`} aria-hidden /><div className="tabular text-sm font-bold">{metric.value}</div><div className="text-[9px] uppercase tracking-wide text-muted-foreground">{metric.label}</div></div>;
          })}
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {featured.map((player) => {
          const conditionTone = player.condition >= 70 ? 'bg-[#22C55E]' : player.condition >= 45 ? 'bg-[#FACC15]' : 'bg-[#EF4444]';
          return (
            <button key={player.id} type="button" onClick={() => onSelect(player)} className="player-card-surface group flex min-h-[102px] items-center gap-3 rounded-xl border border-border/60 p-3 text-left transition-all hover:-translate-y-0.5 hover:border-primary/45">
              <div className="relative flex size-14 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/10">
                <OvrBadge ovr={player.ovr} size="lg" />
                <span className="absolute -bottom-1 -right-1 rounded-md border border-background bg-secondary px-1.5 py-0.5 text-[9px] font-bold text-muted-foreground">#{player.shirtNumber}</span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2"><p className="truncate text-xs font-bold group-hover:text-primary">{player.lastName}</p><PositionBadge position={player.position} /></div>
                <p className="mt-1 text-[10px] text-muted-foreground">{starters.has(player.id) ? 'В стартовом составе' : `Возраст ${player.age}`}</p>
                <div className="mt-2 flex items-center gap-2"><div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary"><div className={`h-full rounded-full ${conditionTone}`} style={{ width: `${player.condition}%` }} /></div><span className="tabular text-[10px] text-muted-foreground">{player.condition}%</span></div>
              </div>
              <span className="hidden text-right sm:block"><span className="block tabular text-[10px] font-bold text-[#22C55E]">{player.goals}G</span><span className="block tabular text-[10px] text-muted-foreground">{player.assists}A</span></span>
            </button>
          );
        })}
      </div>
      <div className="mt-4 flex items-center justify-between border-t border-border/50 pt-3 text-[10px] uppercase tracking-wide text-muted-foreground"><span>Самый сильный профиль обновляется автоматически</span><span className="text-primary">Кликните игрока для анализа</span></div>
    </section>
  );
}

/** Экран «Состав»: таблица всех игроков + карточка по клику. */
export function SquadScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const expiringOnly = useGameStore((s) => s.squadExpiringOnly);
  const setExpiringOnly = useGameStore((s) => s.setSquadExpiringOnly);
  const [posFilter, setPosFilter] = useState<PosFilter>('ALL');
  const [sortKey, setSortKey] = useState<SortKey>('ovr');
  const [rosterView, setRosterView] = useState<'cards' | 'table'>('cards');
  const [selected, setSelected] = useState<PlayerDTO | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { myPlayers, myTeam, save } = snapshot;
  const season = save.season;
  const expiringCount = snapshot.contractsExpiring.length;
  const eff = useMemo(
    () => effectiveLineup(myTeam, myPlayers),
    [myTeam, myPlayers],
  );
  const lineupSet = useMemo(() => new Set(eff.lineup.filter((x): x is string => !!x)), [eff.lineup]);
  const benchSet = useMemo(() => new Set(eff.bench), [eff.bench]);

  const players = useMemo(() => {
    let list = [...myPlayers];
    if (posFilter !== 'ALL') {
      list = list.filter((p) => broadGroupOf(p.position) === posFilter);
    }
    if (expiringOnly) {
      // Тот же критерий, что у снапшотного contractsExpiring: yearsLeft ≤ 1 (включительно).
      list = list.filter((p) => yearsLeftOf(p.contractUntil, season) <= 1);
    }
    switch (sortKey) {
      case 'position':
        list.sort((a, b) => POSITION_ORDER[a.position] - POSITION_ORDER[b.position] || b.ovr - a.ovr);
        break;
      case 'age':
        list.sort((a, b) => a.age - b.age || b.ovr - a.ovr);
        break;
      case 'value':
        list.sort((a, b) => b.value - a.value);
        break;
      case 'morale':
        list.sort((a, b) => b.morale - a.morale);
        break;
      case 'contract':
        list.sort((a, b) => a.contractUntil - b.contractUntil || b.ovr - a.ovr);
        break;
      default:
        list.sort((a, b) => b.ovr - a.ovr);
    }
    return list;
  }, [myPlayers, posFilter, sortKey, expiringOnly, season]);

  const minimumsOk = squadMinimumsSatisfied(myPlayers as never);

  return (
    <div className="space-y-4">
      <SquadVisualHeader
        players={myPlayers}
        starters={lineupSet}
        onSelect={(player) => {
          setSelected(player);
          setDialogOpen(true);
        }}
      />
      <SectionHeader
        title="Заявка команды"
        subtitle={`${myTeam.name} · ${myPlayers.length} игроков · формация ${myTeam.formation}`}
      />

      {/* Фильтры */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:flex-wrap">
        <ToggleGroup
          type="single"
          value={posFilter}
          onValueChange={(v) => v && setPosFilter(v as PosFilter)}
          variant="outline"
          className="justify-start"
        >
          <ToggleGroupItem value="ALL" className="min-h-9" aria-label="Все позиции">Все</ToggleGroupItem>
          <ToggleGroupItem value="GK" className="min-h-9" aria-label="Вратари">Вр</ToggleGroupItem>
          <ToggleGroupItem value="DEF" className="min-h-9" aria-label="Защитники">Защ</ToggleGroupItem>
          <ToggleGroupItem value="MID" className="min-h-9" aria-label="Полузащитники">Пз</ToggleGroupItem>
          <ToggleGroupItem value="FWD" className="min-h-9" aria-label="Нападающие">Нап</ToggleGroupItem>
        </ToggleGroup>
        <div className="flex items-center gap-2 sm:ml-auto">
          <div className="flex h-10 items-center gap-1 rounded-md border border-border/60 bg-card p-1" role="group" aria-label="Вид списка игроков">
            <Button type="button" size="icon" variant={rosterView === 'cards' ? 'secondary' : 'ghost'} className="size-8" onClick={() => setRosterView('cards')} aria-label="Карточки игроков" aria-pressed={rosterView === 'cards'} title="Карточки игроков"><LayoutGrid className="size-4" aria-hidden /></Button>
            <Button type="button" size="icon" variant={rosterView === 'table' ? 'secondary' : 'ghost'} className="size-8" onClick={() => setRosterView('table')} aria-label="Таблица игроков" aria-pressed={rosterView === 'table'} title="Таблица игроков"><List className="size-4" aria-hidden /></Button>
          </div>
          {expiringCount > 0 ? (
            <Button
              variant={expiringOnly ? 'default' : 'outline'}
              size="sm"
              className="min-h-10 gap-1.5"
              onClick={() => setExpiringOnly(!expiringOnly)}
              aria-pressed={expiringOnly}
              title="Игроки, чьи контракты истекают (осталось ≤ 1 года)"
            >
              <FileSignature className="size-4" aria-hidden />
              Истекают {expiringCount}
            </Button>
          ) : null}
          <div className="w-full sm:w-52">
            <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
              <SelectTrigger className="min-h-10 w-full" aria-label="Сортировка">
                <SelectValue placeholder="Сортировка" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ovr">По рейтингу (OVR)</SelectItem>
                <SelectItem value="position">По позиции</SelectItem>
                <SelectItem value="age">По возрасту</SelectItem>
                <SelectItem value="value">По стоимости</SelectItem>
                <SelectItem value="morale">По морали</SelectItem>
                <SelectItem value="contract">По сроку контракта</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {rosterView === 'cards' ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {players.map((player) => {
            const isStarter = lineupSet.has(player.id);
            const isBench = benchSet.has(player.id);
            const cond = conditionBar(player.condition);
            return (
              <button key={player.id} type="button" onClick={() => { setSelected(player); setDialogOpen(true); }} className="player-card-surface group relative flex min-h-[160px] flex-col rounded-xl border border-border/70 p-4 pb-7 text-left transition-all hover:-translate-y-1 hover:border-primary/45">
                <div className="absolute right-3 top-3 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">#{player.shirtNumber}</div>
                <div className="flex items-start gap-3 pr-8">
                  <OvrBadge ovr={player.ovr} size="lg" />
                  <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold group-hover:text-primary">{player.firstName} {player.lastName}</p><div className="mt-1 flex flex-wrap items-center gap-1.5"><PositionBadge position={player.position} /><span className="text-[10px] text-muted-foreground">{player.age} лет</span></div></div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 border-y border-border/50 py-2.5 text-center">
                  <div><p className="tabular text-xs font-bold">{player.goals}</p><p className="text-[9px] uppercase text-muted-foreground">Голы</p></div>
                  <div><p className="tabular text-xs font-bold">{player.assists}</p><p className="text-[9px] uppercase text-muted-foreground">Ассисты</p></div>
                  <div><p className={cn('tabular text-xs font-bold', player.avgRating === null ? 'text-muted-foreground' : avgRatingClass(player.avgRating))}>{player.avgRating?.toFixed(1) ?? '—'}</p><p className="text-[9px] uppercase text-muted-foreground">Рейтинг</p></div>
                </div>
                <div className="mt-auto flex items-center gap-2 pt-3">
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary"><div className={cn('h-full rounded-full', cond.className)} style={{ width: `${player.condition}%` }} /></div>
                  <span className="tabular text-[10px] text-muted-foreground">{player.condition}%</span>
                  <span className={cn('ml-1 text-[9px] font-bold uppercase', isStarter ? 'text-primary' : isBench ? 'text-[#FACC15]' : 'text-muted-foreground')}>{isStarter ? 'Старт' : isBench ? 'Запас' : 'Ротация'}</span>
                </div>
                {player.injuryWeeks > 0 ? <span className="absolute bottom-3 left-4 text-[9px] font-semibold text-[#EF4444]">Травма · {player.injuryWeeks} нед.</span> : null}
              </button>
            );
          })}
        </motion.div>
      ) : <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="scroll-thin overflow-x-auto rounded-lg border border-border/70 bg-card"
      >
        <Table className="min-w-[940px]">
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="h-10 w-10 text-center text-[11px]">№</TableHead>
              <TableHead className="h-10 w-12 text-center text-[11px]">OVR</TableHead>
              <TableHead className="h-10 text-[11px]">Игрок</TableHead>
              <TableHead className="h-10 w-14 text-center text-[11px]">Поз</TableHead>
              <TableHead className="h-10 text-[11px]">Статус</TableHead>
              <TableHead className="h-10 w-24 text-[11px]">Готовность</TableHead>
              <TableHead className="h-10 w-14 text-center text-[11px]">Мораль</TableHead>
              <TableHead className="h-10 w-14 text-center text-[11px]">Г (А)</TableHead>
              <TableHead className="h-10 w-14 text-center text-[11px]">Рейтинг</TableHead>
              <TableHead className="h-10 w-20 text-right text-[11px]">Цена</TableHead>
              <TableHead className="h-10 w-20 text-right text-[11px]">З/П</TableHead>
              <TableHead className="h-10 w-24 text-center text-[11px]">Контракт</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="zebra">
            {players.length === 0 ? (
              <TableRow>
                <TableCell colSpan={12} className="py-8 text-center text-sm text-muted-foreground">
                  Нет игроков по выбранным фильтрам
                </TableCell>
              </TableRow>
            ) : (
              players.map((p) => {
                const morale = moraleBadge(p.morale);
                const cond = conditionBar(p.condition);
                const isStarter = lineupSet.has(p.id);
                const isBench = benchSet.has(p.id);
                const contract = contractBadge(p, season);
                return (
                  <TableRow
                    key={p.id}
                    onClick={() => {
                      setSelected(p);
                      setDialogOpen(true);
                    }}
                    className="cursor-pointer border-border/40 transition-colors hover:bg-primary/5"
                  >
                    <TableCell className="py-2 text-center text-xs tabular text-muted-foreground">
                      {p.shirtNumber}
                    </TableCell>
                    <TableCell className="py-2 text-center">
                      <OvrBadge ovr={p.ovr} size="sm" />
                    </TableCell>
                    <TableCell className="py-2">
                      <div className="flex min-w-0 items-center gap-2">
                        <span className={cn('truncate text-xs font-medium', isStarter && 'text-primary')}>
                          {p.firstName} {p.lastName}
                        </span>
                        <span className="tabular text-[10px] text-muted-foreground">{p.age} л</span>
                        {p.injuryWeeks > 0 ? (
                          <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 px-1 text-[9px] text-[#EF4444]">
                            🩹{p.injuryWeeks}
                          </Badge>
                        ) : null}
                      </div>
                    </TableCell>
                    <TableCell className="py-2 text-center">
                      <PositionBadge position={p.position} />
                    </TableCell>
                    <TableCell className="py-2">
                      <span
                        className={cn(
                          'text-[10px] font-semibold',
                          isStarter ? 'text-primary' : isBench ? 'text-[#FACC15]' : 'text-muted-foreground',
                        )}
                      >
                        {isStarter ? 'СТАРТ' : isBench ? 'ЗАП' : '—'}
                      </span>
                    </TableCell>
                    <TableCell className="py-2">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                          <div
                            className={cn('h-full rounded-full', cond.className)}
                            style={{ width: `${p.condition}%` }}
                          />
                        </div>
                        <span className="w-8 text-right text-[10px] tabular text-muted-foreground">
                          {p.condition}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className={cn('py-2 text-center text-xs tabular font-semibold', morale.className)}>
                      {morale.label}
                    </TableCell>
                    <TableCell className="py-2 text-center text-xs tabular">
                      {p.goals} <span className="text-muted-foreground">({p.assists})</span>
                    </TableCell>
                    <TableCell
                      className={cn(
                        'py-2 text-center text-xs tabular font-semibold',
                        p.avgRating === null ? 'text-muted-foreground/60' : avgRatingClass(p.avgRating),
                      )}
                      title={p.avgRating === null ? 'Ещё не играл в этом сезоне' : 'Средний рейтинг текущего сезона'}
                    >
                      {p.avgRating === null ? '—' : p.avgRating.toFixed(1)}
                    </TableCell>
                    <TableCell className="py-2 text-right text-xs tabular text-[#EAB308]">
                      {formatMoney(p.value)}
                    </TableCell>
                    <TableCell className="py-2 text-right text-xs tabular text-muted-foreground">
                      {formatMoney(p.salary)}
                    </TableCell>
                    <TableCell className="py-2 text-center">
                      <Badge
                        variant="outline"
                        className={cn('tabular text-[10px]', contract.className)}
                        title={contract.title}
                      >
                        {contract.label}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </motion.div>}

      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
        {minimumsOk ? (
          <>
            <CheckCircle2 className="size-3.5 text-[#22C55E]" aria-hidden />
            Состав: {myPlayers.length}/25 · Минимум соблюдён ✓
          </>
        ) : (
          <span className="text-[#FACC15]">
            Состав: {myPlayers.length}/25 · Нарушены минимальные требования (≥2 Вр, ≥4 Защ, ≥4 Пз, ≥3 Нап)
          </span>
        )}
      </p>

      <PlayerDialog
        key={`sq:${selected?.id ?? 'none'}:${dialogOpen}`}
        player={selected}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode="squad"
      />
    </div>
  );
}

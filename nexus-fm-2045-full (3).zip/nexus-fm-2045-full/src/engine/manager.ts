/**
 * D-6 «Личная жизнь тренера» (спека §4): ManagerState на GameSave
 * (JSON, §4.1), каталог 7 активов (§4.2), престиж 0–100 в шкале ×10 (§4.3),
 * семья (§4.4) и чистые функции эффектов престижа (контракты/рынок/правление).
 *
 * Кошелёк менеджера — ОТДЕЛЬНО от баланса клуба; зарплату платит клуб
 * (FinanceRecord category coach_wages), кошелёк копится в simulateWeek.
 * Престиж хранится ×10 (400 = 40.0), clamp 0..1000, без RNG (кроме семьи).
 *
 * Пресет чисел: «Баланс» (research §6б). Все деньги — Int €.
 */

import { pickWeighted, pick, randInt, clamp, type RNG } from '@/lib/game/rng';
import type { NamePoolContext, PoolCode } from '@/lib/game/leagues';
import {
  ATTR_KEYS, computeOvr, computeSalary, computeValue, generatePlayer, type PlayerLike,
} from '@/lib/game/players';

// ── Типы состояния (§4.1) ──────────────────────────────────────────────────

export type AssetId =
  | 're_flat' | 're_house' | 're_villa'
  | 'car_compact' | 'car_sport' | 'car_lux'
  | 'yacht';

/** Ребёнок менеджера (§4.1; один ребёнок в v1). */
export interface ManagerChildState {
  /** Абсолютная неделя рождения (сквозной счётчик с начала карьеры). */
  bornAtWeek: number;
  name: string;
  gender: 'м' | 'д';
  /** +1 в каждый сезонный переход. */
  age: number;
  /** id игрока академии, когда ребёнок попал в академию клуба (§4.4). */
  joinedAcademyPlayerId: string | null;
}

/** Семья менеджера: брак (null = не женат) + ребёнок (null = нет). */
export interface ManagerFamilyState {
  marriedAtWeek: number | null;
  spouseName: string | null;
  child: ManagerChildState | null;
}

/** Состояние менеджера (GameSaveRecord.manager = JSON.stringify(ManagerState)). */
export interface ManagerState {
  age: number;
  wallet: number;
  salary: number;
  /** 0..1000 в шкале ×10 (400 = 40.0). */
  prestige: number;
  assets: AssetId[];
  family: ManagerFamilyState;
}

// ── Константы (§4.1–4.4 — канонические числа) ──────────────────────────────

/** Стартовый профиль: возраст/кошелёк/престиж (§4.1/§4.5). */
export const MANAGER_AGE_START = 45;
export const MANAGER_WALLET_START = 50_000;
export const MANAGER_PRESTIGE_START = 400;
export const MANAGER_PRESTIGE_MAX = 1000;

/** Пороги stature клуба (те же, что BUILDING_TIER_STR §3.2). */
export const MANAGER_TIER_STR = { top: 84, mid: 74 } as const;

/** Недельная зарплата по stature клуба (§4.1; фиксируется при создании карьеры). */
export const MANAGER_SALARY_BY_TIER = {
  top: 120_000,
  mid: 45_000,
  low: 12_000,
} as const;

/** Зарплата менеджера по силе клуба (top ≥ 84 · mid 74–83 · low < 74). */
export function managerSalaryFor(strength: number): number {
  if (strength >= MANAGER_TIER_STR.top) return MANAGER_SALARY_BY_TIER.top;
  if (strength >= MANAGER_TIER_STR.mid) return MANAGER_SALARY_BY_TIER.mid;
  return MANAGER_SALARY_BY_TIER.low;
}

/** Дельты престижа (§4.3, шкала ×10). */
export const PRESTIGE_DELTA = {
  leagueChampion: 80,
  cupWinner: 50,
  euroChampion: 150,
  euroFinalist: 80,
  euroExitR18: -80,
  euroExitR14: -30,
  winWeekly: 1,
  heavyLossWeekly: -2,
  boardHighWeekly: 2, // boardConfidence ≥ 70 (еженедельно)
  boardLowWeekly: -3, // boardConfidence < 30 (еженедельно)
  walletNegativeWeekly: -10,
  marriage: 20,
  childBorn: 30,
} as const;

/** VIP-ложи: +20·L престижа при достройке уровня L (§4.3; = +2.0·L отображения). */
export const PRESTIGE_VIP_PER_LEVEL = 20;

/** Пороги эффектов престижа (§4.3). */
export const MANAGER_PRESTIGE_CONTRACT_LOW = 400; // demand ×1.05 при p < 400
export const MANAGER_PRESTIGE_CONTRACT_HIGH = 600; // demand ×0.95 при p ≥ 600 («звёзды слушаются»)
export const MANAGER_PRESTIGE_MARKET_DISCOUNT = 750; // цена ×0.95 при p ≥ 750
export const MANAGER_PRESTIGE_MARKET_STAR = 600; // звезда не хочет перехода при p < 600
export const MANAGER_MARKET_STAR_OVR = 80;
export const MANAGER_MARKET_DISCOUNT_MULT = 0.95;
export const MANAGER_MARKET_STAR_MULT = 1.10;
export const MANAGER_MARKET_FLOOR_STEP = 1_000; // floor скидки до €1 000
export const MANAGER_PRESTIGE_BOARD_WARN = 700; // порог предупреждения 30 → 25
export const MANAGER_BOARD_WARN_EFFECTIVE = 25;

/** Пороги confidence для еженедельных дельт престижа (§4.3). */
export const MANAGER_BOARD_HIGH = 70; // +2 при confidence ≥ 70
export const MANAGER_BOARD_LOW = 30; // −3 при confidence < 30

/** Семья (§4.4). */
export const MANAGER_MARRIAGE_MIN_WEEKS = 26;
export const MANAGER_MARRIAGE_PRESTIGE = 500;
export const MANAGER_MARRIAGE_P = 0.04;
export const MANAGER_CHILD_AFTER_WEEKS = 40;
export const MANAGER_SON_ACADEMY_AGE = 14;

/** Продажа актива — 70 % цены (§4.2). */
export const MANAGER_SELL_RATIO = 0.7;

// ── Каталог активов (§4.2 — канонические числа) ────────────────────────────

export interface AssetSpec {
  readonly id: AssetId;
  readonly category: 'realty' | 'auto' | 'yacht';
  readonly name: string;
  /** Цена покупки (€). */
  readonly price: number;
  /** Престиж при покупке (шкала ×10). */
  readonly prestige: number;
  /** Содержание (€/нед). */
  readonly upkeep: number;
}

export const ASSETS: readonly AssetSpec[] = [
  {
    id: 're_flat', category: 'realty', name: 'Квартира в городе',
    price: 250_000, prestige: 30, upkeep: 1_000,
  },
  {
    id: 're_house', category: 'realty', name: 'Загородный дом',
    price: 1_500_000, prestige: 80, upkeep: 4_000,
  },
  {
    id: 're_villa', category: 'realty', name: 'Вилла на побережье',
    price: 6_000_000, prestige: 180, upkeep: 12_000,
  },
  {
    id: 'car_compact', category: 'auto', name: 'Компакт-класс',
    price: 40_000, prestige: 10, upkeep: 200,
  },
  {
    id: 'car_sport', category: 'auto', name: 'Спорткар',
    price: 200_000, prestige: 40, upkeep: 1_000,
  },
  {
    id: 'car_lux', category: 'auto', name: 'Представительский седан',
    price: 500_000, prestige: 80, upkeep: 2_500,
  },
  {
    id: 'yacht', category: 'yacht', name: 'Яхта',
    price: 3_000_000, prestige: 150, upkeep: 8_000,
  },
];

const ASSET_IDS: readonly AssetId[] = ASSETS.map((a) => a.id);
const SPEC_BY_ID: ReadonlyMap<AssetId, AssetSpec> = new Map(ASSETS.map((a) => [a.id, a]));

/** Спецификация актива по id (null → ASSET_NOT_FOUND). */
export function assetById(id: string): AssetSpec | null {
  return SPEC_BY_ID.get(id as AssetId) ?? null;
}

/** Цена продажи актива — 70 % цены (§4.2). */
export function sellPriceOf(spec: AssetSpec): number {
  return Math.round(spec.price * MANAGER_SELL_RATIO);
}

/** Престиж, снимаемый при продаже: −ceil(начислено/2) (§4.2). */
export function sellPrestigeOf(spec: AssetSpec): number {
  return Math.ceil(spec.prestige / 2);
}

/** Суммарное содержание активов менеджера (€/нед). */
export function assetsUpkeepTotal(assets: readonly AssetId[]): number {
  let sum = 0;
  for (const id of assets) {
    const spec = SPEC_BY_ID.get(id);
    if (spec) sum += spec.upkeep;
  }
  return sum;
}

/** Чистый недельный поток кошелька: зарплата − содержание активов (§4.6). */
export function netWeeklyOf(manager: ManagerState): number {
  return manager.salary - assetsUpkeepTotal(manager.assets);
}

// ── Женские имена (§4.4: spouseName — женское имя пула лиги) ───────────────
// Пулы NAME_POOLS содержат только мужские имена — женские добавлены здесь
// (косметика, по одной таблице на PoolCode; русский транслит).

export const FEMALE_NAME_POOLS: Record<PoolCode, readonly string[]> = {
  EN: ['Елена', 'Шарлотта', 'Оливия', 'Эмили', 'Софи', 'Грейс', 'Роза', 'Айрин', 'Дейзи', 'Мэри', 'Люси', 'Анна', 'Клара', 'Элис', 'Джулия', 'Флоренс'],
  ES: ['Кармен', 'Лусия', 'Мария', 'Долорес', 'Инесс', 'Пилар', 'Роса', 'Тереза', 'Алба', 'Хулия', 'Ана', 'Лаура', 'Паула', 'Сара', 'Клара', 'Элена'],
  IT: ['Джулия', 'Кьяра', 'Франческа', 'София', 'Валентина', 'Алессия', 'Марта', 'Анна', 'Роза', 'Лукреция', 'Бьянка', 'Элиза', 'Карла', 'Сильвия', 'Мария', 'Паола'],
  DE: ['Анна', 'Мария', 'София', 'Шарлотта', 'Ева', 'Эмилия', 'Ханна', 'Клара', 'Марта', 'Грета', 'Лена', 'Ингрид', 'Хильда', 'Урсула', 'Рената', 'Бритта'],
  FR: ['Мари', 'Софи', 'Клэр', 'Жюли', 'Камиль', 'Одри', 'Натали', 'Изабель', 'Шарлотта', 'Анна', 'Полин', 'Лора', 'Селин', 'Эмма', 'Леа', 'Манон'],
  RU: ['Елена', 'Ольга', 'Анна', 'Мария', 'Наталья', 'Татьяна', 'Ирина', 'Светлана', 'Екатерина', 'Анастасия', 'Дарья', 'Марина', 'Оксана', 'Полина', 'Виктория', 'Алиса'],
};

// ── Сериализация (§4.1: парсер по паттерну parseBuildings) ─────────────────

/** Дефолтное состояние семьи (не женат, ребёнка нет). */
function emptyFamily(): ManagerFamilyState {
  return { marriedAtWeek: null, spouseName: null, child: null };
}

/** Стартовый профиль менеджера по stature клуба (§4.1/§4.5). */
export function createManagerState(strength: number): ManagerState {
  return {
    age: MANAGER_AGE_START,
    wallet: MANAGER_WALLET_START,
    salary: managerSalaryFor(strength),
    prestige: MANAGER_PRESTIGE_START,
    assets: [],
    family: emptyFamily(),
  };
}

function parseChild(raw: unknown): ManagerChildState | null {
  if (raw === null || typeof raw !== 'object') return null;
  const rec = raw as Record<string, unknown>;
  const bornAtWeek = typeof rec.bornAtWeek === 'number' && Number.isFinite(rec.bornAtWeek)
    ? Math.trunc(rec.bornAtWeek) : null;
  if (bornAtWeek === null) return null;
  return {
    bornAtWeek,
    name: typeof rec.name === 'string' && rec.name.length > 0 ? rec.name : 'Артём',
    gender: rec.gender === 'д' ? 'д' : 'м',
    age: typeof rec.age === 'number' && Number.isFinite(rec.age)
      ? Math.max(0, Math.trunc(rec.age)) : 0,
    joinedAcademyPlayerId: typeof rec.joinedAcademyPlayerId === 'string'
      ? rec.joinedAcademyPlayerId : null,
  };
}

/**
 * Парсер состояния менеджера: толерантен к null/битому JSON/лишним ключам —
 * дефолт-профиль prestige 400 (паттерн parseBuildings/parseMatchPlan).
 */
export function parseManager(raw: string | null | undefined, strength: number): ManagerState | null {
  if (raw === null || raw === undefined) return null;
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return null;
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return null;
  }
  const fallback = createManagerState(strength);
  const rec = parsed as Record<string, unknown>;
  const num = (v: unknown, def: number): number =>
    typeof v === 'number' && Number.isFinite(v) ? Math.trunc(v) : def;

  const familyRaw = rec.family;
  let family = emptyFamily();
  if (familyRaw !== null && typeof familyRaw === 'object' && !Array.isArray(familyRaw)) {
    const f = familyRaw as Record<string, unknown>;
    family = {
      marriedAtWeek: typeof f.marriedAtWeek === 'number' && Number.isFinite(f.marriedAtWeek)
        ? Math.trunc(f.marriedAtWeek) : null,
      spouseName: typeof f.spouseName === 'string' && f.spouseName.length > 0 ? f.spouseName : null,
      child: parseChild(f.child),
    };
  }

  const assetsRaw = Array.isArray(rec.assets)
    ? rec.assets.filter((x): x is AssetId => typeof x === 'string' && SPEC_BY_ID.has(x as AssetId))
    : [];

  return {
    age: Math.max(20, num(rec.age, fallback.age)),
    wallet: num(rec.wallet, fallback.wallet),
    salary: Math.max(0, num(rec.salary, fallback.salary)),
    prestige: clamp(num(rec.prestige, fallback.prestige), 0, MANAGER_PRESTIGE_MAX),
    assets: assetsRaw,
    family,
  };
}

/** Канонический JSON состояния (ключи в порядке §4.1). */
export function serializeManager(state: ManagerState): string {
  return JSON.stringify({
    age: state.age,
    wallet: state.wallet,
    salary: state.salary,
    prestige: state.prestige,
    assets: state.assets,
    family: {
      marriedAtWeek: state.family.marriedAtWeek,
      spouseName: state.family.spouseName,
      child: state.family.child === null ? null : {
        bornAtWeek: state.family.child.bornAtWeek,
        name: state.family.child.name,
        gender: state.family.child.gender,
        age: state.family.child.age,
        joinedAcademyPlayerId: state.family.child.joinedAcademyPlayerId,
      },
    },
  });
}

// ── Время (§4.1: сквозной счётчик недель карьеры) ──────────────────────────

/** Абсолютная неделя карьеры: (season − 1) × totalWeeks + week. */
export function absoluteWeekOf(season: number, week: number, totalWeeks: number): number {
  return (season - 1) * totalWeeks + week;
}

// ── Эффекты престижа (§4.3 — чистые функции) ───────────────────────────────

/** Продление контрактов: ×0.95 при p ≥ 600 · ×1.05 при p < 400 · иначе 1. */
export function contractsPrestigeMult(prestige: number): number {
  if (prestige >= MANAGER_PRESTIGE_CONTRACT_HIGH) return MANAGER_MARKET_DISCOUNT_MULT;
  if (prestige < MANAGER_PRESTIGE_CONTRACT_LOW) return 1.05;
  return 1;
}

/**
 * Цена покупки на рынке (§4.3): p ≥ 750 → база ×0.95 (floor до €1 000);
 * p < 600 и OVR ≥ 80 → база ×1.10 («звезда не хочет перехода»); иначе база.
 */
export function managerMarketPrice(prestige: number, basePrice: number, ovr: number): number {
  if (prestige >= MANAGER_PRESTIGE_MARKET_DISCOUNT) {
    return Math.floor((basePrice * MANAGER_MARKET_DISCOUNT_MULT) / MANAGER_MARKET_FLOOR_STEP)
      * MANAGER_MARKET_FLOOR_STEP;
  }
  if (prestige < MANAGER_PRESTIGE_MARKET_STAR && ovr >= MANAGER_MARKET_STAR_OVR) {
    return Math.round(basePrice * MANAGER_MARKET_STAR_MULT);
  }
  return basePrice;
}

/** Правление: эффективный порог предупреждения (30 → 25 при p ≥ 700). */
export function boardWarnBelowOf(prestige: number): number {
  return prestige >= MANAGER_PRESTIGE_BOARD_WARN ? MANAGER_BOARD_WARN_EFFECTIVE : 30;
}

/** Подпись престижа для UI (зоны §4.7: <40 серая · 40–60 зелёная · ≥60 золотая). */
export function prestigeLabelOf(prestige: number): string {
  if (prestige < MANAGER_PRESTIGE_CONTRACT_LOW) return 'Скромный авторитет';
  if (prestige < MANAGER_PRESTIGE_CONTRACT_HIGH) return 'Уважаемый тренер';
  return 'Звёздный тренер';
}

/** Кламп престижа 0..1000 (§4.3). */
export function clampPrestige(prestige: number): number {
  return clamp(prestige, 0, MANAGER_PRESTIGE_MAX);
}

// ── Сын менеджера в академии (§4.4) ────────────────────────────────────────

/** Таблица позиций сына: GK 1/12 · DEF 4/12 · MID 4/12 · AM 2/12 · ST 1/12. */
const SON_GROUP_POSITIONS: Record<'GK' | 'DEF' | 'MID' | 'AM' | 'ST', readonly string[]> = {
  GK: ['GK'],
  DEF: ['DL', 'DC', 'DR'],
  MID: ['ML', 'MC', 'MR'],
  AM: ['AML', 'AMC', 'AMR'],
  ST: ['ST'],
};

/** Границы OVR сына (§4.4): randInt(40, 50) — инвариант после шума genAttrs. */
const SON_OVR_MIN = 40;
const SON_OVR_MAX = 50;

/** Нормализация OVR сына в [40, 50] (сдвиг атрибутов; паттерн normalizeAcademyOvr). */
function normalizeSonOvr(p: PlayerLike): void {
  if (p.ovr >= SON_OVR_MIN && p.ovr <= SON_OVR_MAX) return;
  const target = clamp(p.ovr, SON_OVR_MIN, SON_OVR_MAX);
  const delta = target - p.ovr;
  for (const key of ATTR_KEYS) {
    p[key] = clamp(p[key] + delta, 1, 99);
  }
  p.ovr = computeOvr(p, p.position);
  p.potential = Math.max(p.potential, p.ovr);
  p.value = computeValue({ ovr: p.ovr, age: p.age, potential: p.potential, morale: p.morale });
  p.salary = computeSalary(p.value);
}

/**
 * Игрок академии — сын менеджера (§4.4): фамилия = последнее слово managerName,
 * имя ребёнка; позиция pickWeighted (GK 1/12, DEF 4/12, MID 4/12, AM 2/12,
 * ST 1/12); age 14; OVR randInt(40,50) (нормализован); POT: p=0.5 →
 * randInt(85,93) «жемчужина» (втрое выше обычного топ-клуба), иначе
 * randInt(70,84); contractUntil = season+3; isAcademy = true.
 * Сид вызывающий: `${saveId}:family:academy:${season}`.
 */
export function buildSonAcademyPlayer(args: {
  rng: RNG;
  managerName: string;
  child: { name: string; gender: 'м' | 'д' };
  season: number;
  pool: NamePoolContext;
  idFactory: () => string;
}): PlayerLike {
  const { rng, managerName, child, season, pool, idFactory } = args;

  const group = pickWeighted(rng, [
    { item: 'GK' as const, weight: 1 },
    { item: 'DEF' as const, weight: 4 },
    { item: 'MID' as const, weight: 4 },
    { item: 'AM' as const, weight: 2 },
    { item: 'ST' as const, weight: 1 },
  ]);
  const position = pick(rng, SON_GROUP_POSITIONS[group]) as PlayerLike['position'];

  const lastName = managerName.trim().split(/\s+/).pop() ?? managerName.trim();
  const ovrTarget = randInt(rng, SON_OVR_MIN, SON_OVR_MAX);
  const potential = rng() < 0.5 ? randInt(rng, 85, 93) : randInt(rng, 70, 84);

  const player = generatePlayer(rng, ovrTarget, position, {
    fixedAge: MANAGER_SON_ACADEMY_AGE,
    potentialOverride: potential,
    contractUntil: season + 3,
    pool,
    idFactory,
  });
  player.firstName = child.name;
  player.lastName = lastName;
  player.isAcademy = true;
  normalizeSonOvr(player);
  return player;
}

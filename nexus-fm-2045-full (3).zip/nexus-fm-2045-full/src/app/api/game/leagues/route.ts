import { NextResponse } from 'next/server';
import { cupRoundsOf } from '@/lib/game/calendar';
import { START_BALANCE_BASE, START_BALANCE_PER_STRENGTH } from '@/lib/game/constants';
import { LEAGUES, leagueAvgStrength } from '@/lib/game/leagues';
import type { LeagueCatalogDTO, LeagueClubDTO } from '@/lib/game/types';

/** GET /api/game/leagues — статический каталог 6 лиг (112 клубов). §6.2. */
export async function GET() {
  const leagues: LeagueCatalogDTO[] = LEAGUES.map((def) => {
    const clubs: LeagueClubDTO[] = def.clubs.map((club, index) => ({
      index,
      name: club.name,
      city: club.city,
      shortName: club.short,
      colorPrimary: club.c1,
      colorSecondary: club.c2,
      strength: club.str,
      stadiumCapacity: club.cap,
      startBalance:
        START_BALANCE_BASE + Math.max(0, club.str - 55) * START_BALANCE_PER_STRENGTH,
    }));
    return {
      code: def.code,
      nameRu: def.nameRu,
      nameEn: def.nameEn,
      country: def.country,
      flag: def.flag,
      teamCount: def.teamCount,
      leagueWeeks: def.leagueWeeks,
      cupRounds: cupRoundsOf(def.teamCount),
      cupName: def.cupName,
      avgStrength: leagueAvgStrength(def),
      difficulty: def.difficulty,
      clubs,
    };
  });
  return NextResponse.json({ ok: true, leagues });
}

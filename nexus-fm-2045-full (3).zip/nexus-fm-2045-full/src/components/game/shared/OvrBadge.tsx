import { cn } from '@/lib/utils';
import { ovrColor } from '@/lib/game/format';

const SIZES: Record<string, string> = {
  sm: 'size-7 text-[11px]',
  md: 'size-9 text-sm',
  lg: 'size-11 text-base',
};

/** Гексагон (как на карточках референсов FM2045/FMX25). */
const HEX = 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)';

/** Шестиугольный неоновый бейдж OVR: цвет по величине (см. ovrColor), glow-ободок. */
export function OvrBadge({
  ovr,
  size = 'md',
  className,
}: {
  ovr: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}) {
  const color = ovrColor(ovr);
  return (
    <span
      className={cn(
        'relative inline-flex shrink-0 items-center justify-center font-bold tabular',
        SIZES[size],
        className,
      )}
      style={{
        backgroundColor: color,
        clipPath: HEX,
        filter: `drop-shadow(0 0 4px ${color}55)`,
      }}
      role="img"
      aria-label={`Рейтинг ${ovr}`}
    >
      <span
        className="absolute inset-[2px] flex items-center justify-center"
        style={{ backgroundColor: '#0B1220', clipPath: HEX }}
      >
        <span style={{ color }}>{ovr}</span>
      </span>
    </span>
  );
}

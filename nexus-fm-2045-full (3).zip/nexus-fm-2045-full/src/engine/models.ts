/**
 * Записи «таблиц» SaveStore — зеркало prisma/schema.prisma (поля 1:1, порядок
 * канонический = порядок полей схемы) + NewspaperClippingRecord (спека §1.2/§5.4,
 * «таблица» D-7). Date-поля — настоящие Date (текущий код зовёт .toISOString());
 * канонический дамп (db.toJSON) сериализует их в ISO, загрузка — ревайвит.
 * Спецификация: docs/desktop/02-spec.md §1.2–§1.3.
 */

// ── GameSave ───────────────────────────────────────────────────────────────

/** Карьера = 1 строка gameSave на слот (спека §1.2). */
export interface GameSaveRecord {
  id: string;
  managerName: string;
  /** Клуб игрока; null до выбора (FK-трюк POST /saves). */
  teamId: string | null;
  season: number;
  week: number;
  balance: number;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  careerName: string | null;
  leagueCode: string;
  lastOpenedAt: Date | null;
  cupRound: number;
  /** JSON string[] — участники следующего раунда; null = кубок сброшен. */
  cupAliveTeamIds: string | null;
  /** Код цели: champion|ucl|uel|upper|safe|survive; null → ленивая инициализация. */
  boardTarget: string | null;
  boardTargetPlace: number | null;
  boardConfidence: number;
  boardWarnings: number;
  boardLowStreak: number;
  honeymoonUntilWeek: number | null;
  finishReason: string | null;
  euroSeason: number | null;
  euroRound: number;
  /** JSON string[] — участники следующего раунда; null = завершён/сброшен. */
  euroAliveTeamIds: string | null;
  /** JSON string[] — 16 id участников сезона. */
  euroParticipants: string | null;
  /** JSON ManagerState (D-6 §4.1): кошелёк/зарплата/престиж ×10/активы/семья. */
  manager: string | null;
  // ── Модуль 5: бюджеты правления + история доверия + финцель ──
  /** € на трансферы (тратят buy; продажи +80%); 0 = ленивая миграция легаси. */
  transferBudget: number;
  /** Потолок зарплатной ведомости €/нед; 0 = ленивая миграция легаси. */
  wageBudget: number;
  /** JSON BoardHistoryState {season, points:[{w,c}]} — график доверия; null = пусто. */
  boardHistory: string | null;
  /** no_debt|wage_control|null — финцель сезона правления. */
  financeTarget: string | null;
}

// ── Team ───────────────────────────────────────────────────────────────────

export interface TeamRecord {
  id: string;
  saveId: string;
  name: string;
  shortName: string;
  city: string | null;
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  isUserTeam: boolean;
  stadiumCapacity: number;
  // ── Модуль 5: расширение стадиона ──
  /** Места в стройке (0 = стройки нет). */
  stadiumPending: number;
  /** Абсолютный день окончания стройки; null = стройки нет. */
  stadiumUpgradeEndsAtDay: number | null;
  formation: string;
  mentality: string;
  tempo: string;
  pressing: string;
  defLine: string;
  playStyle: string;
  /** JSON string[] — id 11 игроков стартового состава. */
  lineup: string | null;
  /** JSON string[] — id до 7 запасных. */
  bench: string | null;
  trainingFocus: string;
  trainingIntensity: string;
  aiStyle: string;
  aiCoachName: string | null;
  isEuroGuest: boolean;
  leagueCode: string | null;
  /** JSON MatchPlanSettings { leadMode, chaseMode, fatigueSubs } (только клуб игрока). */
  matchPlan: string | null;
  /** JSON BuildingsState (D-5 §3.4): уровни 8 зданий + таймеры строек. */
  buildings: string | null;
  /** Engine 2.0: ширина игры narrow|normal|wide (undefined в легаси-дампах → normal). */
  width?: string;
}

// ── Player ─────────────────────────────────────────────────────────────────

export interface PlayerRecord {
  id: string;
  saveId: string;
  teamId: string | null;
  firstName: string;
  lastName: string;
  nationality: string;
  position: string;
  shirtNumber: number;
  age: number;
  potential: number;
  ovr: number;
  finishing: number;
  passing: number;
  dribbling: number;
  crossing: number;
  tackling: number;
  marking: number;
  positioning: number;
  heading: number;
  pace: number;
  stamina: number;
  strength: number;
  aggression: number;
  reflexes: number;
  rushingOut: number;
  kicking: number;
  morale: number;
  condition: number;
  injuryWeeks: number;
  value: number;
  salary: number;
  goals: number;
  assists: number;
  apps: number;
  yellowCards: number;
  redCards: number;
  /** JSON { [attrKey]: number } — накопленный дробный опыт 0..1. */
  trainingXp: string | null;
  cleanSheets: number;
  cupGoals: number;
  cupAssists: number;
  /** Последний сезон действия контракта ВКЛЮЧИТЕЛЬНО. */
  contractUntil: number;
  /** Босман: клуб предконтракта (null = нет); скаляр без FK. */
  preContractTeamId: string | null;
  /** Сумма рейтингов матчей ×10 (68 = 6.8). */
  ratingSum: number;
  ratingApps: number;
  isAcademy: boolean;
  euroGoals: number;
  euroAssists: number;
  // ── Engine 2.0: ментальные/физические/скрытые (генерация v2) ──
  vision: number;
  decisions: number;
  leadership: number;
  acceleration: number;
  jumping: number;
  handling: number;
  injuryProneness: number;
  consistency: number;
  // ── Engine 2.0: контрактные бонусы (€ за гол / за сухой матч) ──
  goalBonus: number;
  cleanSheetBonus: number;
}

// ── Staff (Модуль 2: Персонал; Prisma-модель Staff) ───────────────────────

export type StaffRole = 'head_coach' | 'assistant' | 'fitness' | 'physio' | 'scout';

/** Персонал клуба (Engine 2.0): тренеры/физио/скауты. teamId null — рынок персонала. */
export interface StaffRecord {
  id: string;
  saveId: string;
  teamId: string | null;
  role: string;
  firstName: string;
  lastName: string;
  nationality: string;
  age: number;
  rating: number;
  specialty: string | null;
  salary: number;
  contractUntil: number;
  createdAt: Date;
}

const STAFF_FIELDS = [
  'id', 'saveId', 'teamId', 'role', 'firstName', 'lastName', 'nationality', 'age',
  'rating', 'specialty', 'salary', 'contractUntil', 'createdAt',
] as const;

const STAFF_INT_FIELDS = ['age', 'rating', 'salary', 'contractUntil'] as const;

// ── Match ──────────────────────────────────────────────────────────────────

export interface MatchRecord {
  id: string;
  saveId: string;
  season: number;
  week: number;
  homeTeamId: string;
  awayTeamId: string;
  homeGoals: number | null;
  awayGoals: number | null;
  status: string;
  /** JSON MatchEvent[] (полный для матча игрока, только голы для ИИ). */
  events: string | null;
  /** JSON MatchStats (только матчи клуба игрока). */
  stats: string | null;
  createdAt: Date;
  competition: string;
  cupRound: number | null;
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string | null;
  isNeutral: boolean;
}

// ── TransferListing ────────────────────────────────────────────────────────

export interface TransferListingRecord {
  id: string;
  saveId: string;
  playerId: string;
  price: number;
  /** «Жадность» 1.0..1.3 (Float схемы). */
  askFactor: number;
  source: string;
  status: string;
  expiresAt: number;
  createdAt: Date;
}

// ── ScoutReport (Модуль 3: туман войны) ──────────────────────────────────────

export interface ScoutReportRecord {
  id: string;
  saveId: string;
  playerId: string;
  /** Знания 0..100: 0..39 OVR-вилка; 40..69 атрибуты ±6; 70..100 точно. */
  knowledge: number;
  /** Абсолютная неделя последнего наблюдения. */
  lastWeek: number;
  /** Модуль 3: активное наблюдение (false = «архив», деградирует). */
  watched: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// ── PlayerTraining (Модуль 4: индивидуальные программы) ─────────────────────

/** Индивидуальная программа игрока клуба пользователя (переопределяет командную). */
export interface PlayerTrainingRecord {
  id: string;
  saveId: string;
  playerId: string;
  /** attack|defense|possession|physical|goalkeepers|rest. */
  focus: string;
  /** light|normal|hard. */
  intensity: string;
  updatedAt: Date;
}

const PLAYER_TRAINING_FIELDS = ['id', 'saveId', 'playerId', 'focus', 'intensity', 'updatedAt'] as const;

const PLAYER_TRAINING_INT_FIELDS: readonly string[] = [];

// ── TransferOffer (Модуль 3: входящие офферы ИИ) ─────────────────────────────
export interface TransferOfferRecord {
  id: string;
  saveId: string;
  /** Игрок клуба пользователя — цель оффера. */
  playerId: string;
  /** ИИ-клуб-покупатель (скаляр без FK — паттерн Match.winnerTeamId). */
  fromTeamId: string;
  /** Сумма предложения, €. */
  amount: number;
  /** pending | accepted | rejected | expired. */
  status: string;
  /** Абсолютная неделя создания. */
  createdWeek: number;
  /** createdWeek + 2 (погашение в недельном цикле). */
  expiresWeek: number;
  createdAt: Date;
  updatedAt: Date;
}

// ── PlayerSeasonRecord ─────────────────────────────────────────────────────

export interface PlayerSeasonRecordRecord {
  id: string;
  saveId: string;
  season: number;
  playerId: string;
  teamId: string | null;
  teamName: string;
  age: number;
  position: string;
  apps: number;
  goals: number;
  assists: number;
  cupGoals: number;
  cupAssists: number;
  euroGoals: number;
  euroAssists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  /** ×10 (68 = 6.8); 0 = не играл. */
  avgRating: number;
  createdAt: Date;
}

// ── NewsItem ───────────────────────────────────────────────────────────────

export interface NewsItemRecord {
  id: string;
  saveId: string;
  season: number;
  week: number;
  type: string;
  message: string;
  createdAt: Date;
}

// ── FinanceRecord ──────────────────────────────────────────────────────────

export interface FinanceRecordRecord {
  id: string;
  saveId: string;
  season: number;
  week: number;
  kind: string;
  category: string;
  /** Всегда положительное; знак определяется kind. */
  amount: number;
  description: string;
  createdAt: Date;
}

// ── SeasonAward ────────────────────────────────────────────────────────────

export interface SeasonAwardRecord {
  id: string;
  saveId: string;
  season: number;
  type: string;
  playerId: string | null;
  teamId: string;
  value: number;
  label: string;
  createdAt: Date;
}

// ── NewspaperClipping (D-7, спека §5.4) ───────────────────────────────────

/** Вырезка газеты: JSON-поля (motm/moments) — строки по конвенции §1.2. */
export interface NewspaperClippingRecord {
  id: string;
  saveId: string;
  season: number;
  week: number;
  /** null для special_son (academy). */
  matchId: string | null;
  /** league | cup | euro | academy. */
  competition: string;
  context: string;
  headline: string;
  subheadline: string;
  homeName: string;
  awayName: string;
  homeGoals: number;
  awayGoals: number;
  homePens: number | null;
  awayPens: number | null;
  /** JSON { playerId, name, position, rating } (rating ×10). */
  motm: string | null;
  excerpt: string;
  /** JSON [{ minute, kind, text }]. */
  moments: string;
  createdAt: Date;
}

// ── Реестр моделей: канонический порядок полей + дефолты схемы ─────────────

/** Имена «таблиц» SaveStore (§1.2). */
export type ModelName =
  | 'gameSave'
  | 'team'
  | 'player'
  | 'match'
  | 'transferListing'
  | 'scoutReport'
  | 'transferOffer'
  | 'playerTraining'
  | 'playerSeasonRecord'
  | 'newsItem'
  | 'financeRecord'
  | 'seasonAward'
  | 'newspaperClipping'
  | 'staff';

/** Ключи дампа слота (§2.1) по именам таблиц. */
export const DUMP_KEY_BY_MODEL: Record<ModelName, string> = {
  gameSave: 'gameSave',
  team: 'teams',
  player: 'players',
  match: 'matches',
  transferListing: 'transferListings',
  scoutReport: 'scoutReports',
  transferOffer: 'transferOffers',
  playerTraining: 'playerTrainings',
  playerSeasonRecord: 'playerSeasonRecords',
  newsItem: 'newsItems',
  financeRecord: 'financeRecords',
  seasonAward: 'seasonAwards',
  newspaperClipping: 'newspaperClippings',
  staff: 'staff',
};

/** Спецификация таблицы для db.ts: канонический порядок полей и дефолты. */
export interface ModelSpec {
  /** Канонический порядок ключей записи (= порядок полей prisma-схемы). */
  readonly fields: readonly string[];
  /** Date-поля записи (ревайв ISO → Date при загрузке, §1.2). */
  readonly dateFields: readonly string[];
  /** Date-поля, заполняемые при create из часов хранилища (аналог @default(now())). */
  readonly clockFields: readonly string[];
  /** Статические дефолты схемы @default(...) — без дат. */
  readonly defaults: Readonly<Record<string, unknown>>;
  /** Int-поля схемы: Prisma/SQLite при записи усекает дробные к целому (к нулю). */
  readonly intFields: readonly string[];
  /** Float-поля схемы: Prisma сериализует с округлением до 16 значащих цифр. */
  readonly floatFields: readonly string[];
}

const GAME_SAVE_FIELDS = [
  'id', 'managerName', 'teamId', 'season', 'week', 'balance', 'status', 'createdAt', 'updatedAt',
  'careerName', 'leagueCode', 'lastOpenedAt', 'cupRound', 'cupAliveTeamIds',
  'boardTarget', 'boardTargetPlace', 'boardConfidence', 'boardWarnings', 'boardLowStreak',
  'honeymoonUntilWeek', 'finishReason', 'euroSeason', 'euroRound', 'euroAliveTeamIds',
  'euroParticipants', 'manager',
  // ── Модуль 5: бюджеты правления + история доверия + финцель ──
  'transferBudget', 'wageBudget', 'boardHistory', 'financeTarget',
] as const;

const TEAM_FIELDS = [
  'id', 'saveId', 'name', 'shortName', 'city', 'colorPrimary', 'colorSecondary', 'strength',
  'isUserTeam', 'stadiumCapacity', 'formation', 'mentality', 'tempo', 'pressing', 'defLine',
  'playStyle', 'lineup', 'bench', 'trainingFocus', 'trainingIntensity', 'aiStyle', 'aiCoachName',
  'isEuroGuest', 'leagueCode', 'matchPlan', 'buildings',
  // ── Модуль 5: расширение стадиона ──
  'stadiumPending', 'stadiumUpgradeEndsAtDay',
] as const;

const PLAYER_FIELDS = [
  'id', 'saveId', 'teamId', 'firstName', 'lastName', 'nationality', 'position', 'shirtNumber',
  'age', 'potential', 'ovr', 'finishing', 'passing', 'dribbling', 'crossing', 'tackling',
  'marking', 'positioning', 'heading', 'pace', 'stamina', 'strength', 'aggression',
  'reflexes', 'rushingOut', 'kicking', 'morale', 'condition', 'injuryWeeks', 'value', 'salary',
  'goals', 'assists', 'apps', 'yellowCards', 'redCards', 'trainingXp', 'cleanSheets',
  'cupGoals', 'cupAssists', 'contractUntil', 'preContractTeamId', 'ratingSum', 'ratingApps',
  'isAcademy', 'euroGoals', 'euroAssists',
  // ── Engine 2.0 (Модуль 2 фикс: поля стёрлись buildRow → «анемия» голов) ──
  'vision', 'decisions', 'leadership', 'acceleration', 'jumping', 'handling',
  'injuryProneness', 'consistency', 'goalBonus', 'cleanSheetBonus',
] as const;

const MATCH_FIELDS = [
  'id', 'saveId', 'season', 'week', 'homeTeamId', 'awayTeamId', 'homeGoals', 'awayGoals',
  'status', 'events', 'stats', 'createdAt', 'competition', 'cupRound', 'homePens', 'awayPens',
  'winnerTeamId', 'isNeutral',
] as const;

const TRANSFER_LISTING_FIELDS = [
  'id', 'saveId', 'playerId', 'price', 'askFactor', 'source', 'status', 'expiresAt', 'createdAt',
] as const;

const SCOUT_REPORT_FIELDS = [
  'id', 'saveId', 'playerId', 'knowledge', 'lastWeek', 'watched', 'createdAt', 'updatedAt',
] as const;

const TRANSFER_OFFER_FIELDS = [
  'id', 'saveId', 'playerId', 'fromTeamId', 'amount', 'status', 'createdWeek', 'expiresWeek',
  'createdAt', 'updatedAt',
] as const;

const PLAYER_SEASON_RECORD_FIELDS = [
  'id', 'saveId', 'season', 'playerId', 'teamId', 'teamName', 'age', 'position', 'apps', 'goals',
  'assists', 'cupGoals', 'cupAssists', 'euroGoals', 'euroAssists', 'cleanSheets', 'yellowCards',
  'redCards', 'avgRating', 'createdAt',
] as const;

const NEWS_ITEM_FIELDS = ['id', 'saveId', 'season', 'week', 'type', 'message', 'createdAt'] as const;

const FINANCE_RECORD_FIELDS = [
  'id', 'saveId', 'season', 'week', 'kind', 'category', 'amount', 'description', 'createdAt',
] as const;

const SEASON_AWARD_FIELDS = [
  'id', 'saveId', 'season', 'type', 'playerId', 'teamId', 'value', 'label', 'createdAt',
] as const;

const NEWSPAPER_CLIPPING_FIELDS = [
  'id', 'saveId', 'season', 'week', 'matchId', 'competition', 'context', 'headline', 'subheadline',
  'homeName', 'awayName', 'homeGoals', 'awayGoals', 'homePens', 'awayPens', 'motm', 'excerpt',
  'moments', 'createdAt',
] as const;

// Int-поля по схеме (единственный Float — TransferListing.askFactor): числовая
// коэрция записи зеркалит Prisma+SQLite (Д-3c: паритет с сервером).
const GAME_SAVE_INT_FIELDS = [
  'season', 'week', 'balance', 'cupRound', 'boardTargetPlace', 'boardConfidence',
  'boardWarnings', 'boardLowStreak', 'honeymoonUntilWeek', 'euroSeason', 'euroRound',
  // Модуль 5
  'transferBudget', 'wageBudget',
] as const;
const TEAM_INT_FIELDS = ['strength', 'stadiumCapacity', 'stadiumPending'] as const;
const PLAYER_INT_FIELDS = [
  'shirtNumber', 'age', 'potential', 'ovr', 'finishing', 'passing', 'dribbling', 'crossing',
  'tackling', 'marking', 'positioning', 'heading', 'pace', 'stamina', 'strength', 'aggression',
  'reflexes', 'rushingOut', 'kicking', 'morale', 'condition', 'injuryWeeks', 'value', 'salary',
  'goals', 'assists', 'apps', 'yellowCards', 'redCards', 'cleanSheets', 'cupGoals', 'cupAssists',
  'contractUntil', 'ratingSum', 'ratingApps',
  'vision', 'decisions', 'leadership', 'acceleration', 'jumping', 'handling',
  'injuryProneness', 'consistency', 'goalBonus', 'cleanSheetBonus',
] as const;
const MATCH_INT_FIELDS = [
  'season', 'week', 'homeGoals', 'awayGoals', 'cupRound', 'homePens', 'awayPens',
] as const;
const TRANSFER_LISTING_INT_FIELDS = ['price', 'expiresAt'] as const;
const TRANSFER_LISTING_FLOAT_FIELDS = ['askFactor'] as const;
const SCOUT_REPORT_INT_FIELDS = ['knowledge', 'lastWeek'] as const;
const TRANSFER_OFFER_INT_FIELDS = ['amount', 'createdWeek', 'expiresWeek'] as const;
const PLAYER_SEASON_RECORD_INT_FIELDS = [
  'season', 'age', 'apps', 'goals', 'assists', 'cupGoals', 'cupAssists', 'euroGoals',
  'euroAssists', 'cleanSheets', 'yellowCards', 'redCards', 'avgRating',
] as const;
const NEWS_ITEM_INT_FIELDS = ['season', 'week'] as const;
const FINANCE_RECORD_INT_FIELDS = ['season', 'week', 'amount'] as const;
const SEASON_AWARD_INT_FIELDS = ['season', 'value'] as const;
const NEWSPAPER_CLIPPING_INT_FIELDS = ['season', 'week', 'homeGoals', 'awayGoals', 'homePens', 'awayPens'] as const;

/** Реестр спецификаций всех «таблиц» (единственный источник канона для db.ts). */
export const MODEL_SPECS: Record<ModelName, ModelSpec> = {
  gameSave: {
    fields: GAME_SAVE_FIELDS,
    dateFields: ['createdAt', 'updatedAt', 'lastOpenedAt'],
    clockFields: ['createdAt', 'updatedAt'],
    intFields: GAME_SAVE_INT_FIELDS,
    floatFields: [],
    defaults: {
      teamId: null, season: 1, week: 1, balance: 0, status: 'active', careerName: null,
      lastOpenedAt: null, cupRound: 0, cupAliveTeamIds: null, boardTarget: null,
      boardTargetPlace: null, boardConfidence: 55, boardWarnings: 0, boardLowStreak: 0,
      honeymoonUntilWeek: null, finishReason: null, euroSeason: null, euroRound: 0,
      euroAliveTeamIds: null, euroParticipants: null, manager: null,
      // Модуль 5: 0 = ленивая миграция легаси-сейвов (budget.migrate*)
      transferBudget: 0, wageBudget: 0, boardHistory: null, financeTarget: null,
    },
  },
  team: {
    fields: TEAM_FIELDS,
    dateFields: [],
    clockFields: [],
    intFields: TEAM_INT_FIELDS,
    floatFields: [],
    defaults: {
      shortName: 'FC', city: null, colorPrimary: '#2E9E5B', colorSecondary: '#F0F0E0',
      strength: 65, isUserTeam: false, stadiumCapacity: 25000, formation: '4-4-2',
      mentality: 'balanced', tempo: 'medium', pressing: 'medium', defLine: 'medium',
      playStyle: 'balanced', lineup: null, bench: null, trainingFocus: 'rest',
      trainingIntensity: 'normal', aiStyle: 'balanced', aiCoachName: null, isEuroGuest: false,
      leagueCode: null, matchPlan: null, buildings: null,
      stadiumPending: 0, stadiumUpgradeEndsAtDay: null,
    },
  },
  player: {
    fields: PLAYER_FIELDS,
    dateFields: [],
    clockFields: [],
    intFields: PLAYER_INT_FIELDS,
    floatFields: [],
    defaults: {
      teamId: null, nationality: 'RU', shirtNumber: 0, finishing: 50, passing: 50, dribbling: 50,
      crossing: 50, tackling: 50, marking: 50, positioning: 50, heading: 50, pace: 50,
      stamina: 50, strength: 50, aggression: 50, reflexes: 50, rushingOut: 50, kicking: 50,
      morale: 60, condition: 100, injuryWeeks: 0, value: 0, salary: 0, goals: 0, assists: 0,
      apps: 0, yellowCards: 0, redCards: 0, trainingXp: null, cleanSheets: 0, cupGoals: 0,
      cupAssists: 0, contractUntil: 3, preContractTeamId: null, ratingSum: 0, ratingApps: 0,
      isAcademy: false, euroGoals: 0, euroAssists: 0,
      vision: 50, decisions: 50, leadership: 50, acceleration: 50, jumping: 50, handling: 50,
      injuryProneness: 50, consistency: 50, goalBonus: 0, cleanSheetBonus: 0,
    },
  },
  match: {
    fields: MATCH_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: MATCH_INT_FIELDS,
    floatFields: [],
    defaults: {
      season: 1, homeGoals: null, awayGoals: null, status: 'scheduled', events: null, stats: null,
      competition: 'league', cupRound: null, homePens: null, awayPens: null, winnerTeamId: null,
      isNeutral: false,
    },
  },
  transferListing: {
    fields: TRANSFER_LISTING_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: TRANSFER_LISTING_INT_FIELDS,
    floatFields: TRANSFER_LISTING_FLOAT_FIELDS,
    defaults: { askFactor: 1.15, source: 'market', status: 'active', expiresAt: 6 },
  },
  scoutReport: {
    fields: SCOUT_REPORT_FIELDS,
    dateFields: ['createdAt', 'updatedAt'],
    clockFields: ['createdAt', 'updatedAt'],
    intFields: SCOUT_REPORT_INT_FIELDS,
    floatFields: [],
    defaults: { knowledge: 0, lastWeek: 0, watched: true },
  },
  transferOffer: {
    fields: TRANSFER_OFFER_FIELDS,
    dateFields: ['createdAt', 'updatedAt'],
    clockFields: ['createdAt', 'updatedAt'],
    intFields: TRANSFER_OFFER_INT_FIELDS,
    floatFields: [],
    defaults: { status: 'pending' },
  },
  playerTraining: {
    fields: PLAYER_TRAINING_FIELDS,
    dateFields: ['updatedAt'],
    clockFields: ['updatedAt'],
    intFields: PLAYER_TRAINING_INT_FIELDS,
    floatFields: [],
    defaults: { focus: 'rest', intensity: 'normal' },
  },
  playerSeasonRecord: {
    fields: PLAYER_SEASON_RECORD_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: PLAYER_SEASON_RECORD_INT_FIELDS,
    floatFields: [],
    defaults: { euroGoals: 0, euroAssists: 0 },
  },
  newsItem: {
    fields: NEWS_ITEM_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: NEWS_ITEM_INT_FIELDS,
    floatFields: [],
    defaults: {},
  },
  financeRecord: {
    fields: FINANCE_RECORD_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: FINANCE_RECORD_INT_FIELDS,
    floatFields: [],
    defaults: {},
  },
  seasonAward: {
    fields: SEASON_AWARD_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: SEASON_AWARD_INT_FIELDS,
    floatFields: [],
    defaults: { playerId: null },
  },
  newspaperClipping: {
    fields: NEWSPAPER_CLIPPING_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: NEWSPAPER_CLIPPING_INT_FIELDS,
    floatFields: [],
    defaults: {
      matchId: null, competition: 'league', homePens: null, awayPens: null, motm: null,
      moments: '[]',
    },
  },
  staff: {
    fields: STAFF_FIELDS,
    dateFields: ['createdAt'],
    clockFields: ['createdAt'],
    intFields: STAFF_INT_FIELDS,
    floatFields: [],
    defaults: { teamId: null, nationality: 'RU', specialty: null, salary: 0, contractUntil: 3 },
  },
};

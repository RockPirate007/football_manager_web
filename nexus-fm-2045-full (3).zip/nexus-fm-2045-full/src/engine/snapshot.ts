/**
 * ПОРТ src/lib/game/snapshot.ts в движок (D-3b, спека §1.4): правки только
 * в импортах/типах (db → './db' — активная карьера; Prisma-типы → Record-типы
 * engine). Оригинал живёт до D-4 (сервер).
 *
 * Сборка снапшота состояния игры (GET /api/game/state и ответы buy/sell).
 * §6.4 architecture-upgrade.md (Фаза 2): weekInfo/league/cup/training/
 * leaders/careerName + фильтры competition. Live-лидеры — только лиговые
 * игроки (гости исключены relation-фильтром `team: { isEuroGuest: false }`,
 * P4-QA-1).
 */

import { db } from './db';
import type { GameSaveRecord, PlayerRecord, TeamRecord } from './models';
import { MANAGER_PRESTIGE_START, boardWarnBelowOf, parseManager } from './manager';
import {
  BUILDINGS, BUILDING_MAX_LEVEL, daysOf, merchWeekly, parseBuildings, priceOf,
  upkeepWeeklyOfBuilding, type BuildingsState,
} from './buildings';
import {
  FORMATIONS, coerceAiStyle, coerceDefLine, coerceFormation,
  coerceMentality, coercePlayStyle, coercePressing, coerceTempo,
  BOARD_TARGET_LABELS, FINANCE_CATEGORY_LABELS, FINANCE_TARGET_LABELS, type BoardTargetCode,
  type FinanceCategory, type FinanceTargetCode,
} from '@/lib/game/constants';
import { buildSeasonPlan, cupRoundLabel, weekLabelOf, weekSlotAt } from '@/lib/game/calendar';
import { liveLeaders } from '@/lib/game/awards';
import {
  boardWarnLevel, jobStatusOf, nextSeasonTarget, parseBoardHistory,
} from '@/lib/game/board';
import {
  maxRenewYears, renewDemand, teamAppsOf, yearsLeftOf,
} from '@/lib/game/contracts';
import { euroRoundAt } from '@/lib/game/euro';
import { ApiGameError } from '@/lib/game/error';
import { tvIncomeOf, weeklyIncomeEstimate, weeklyWages } from '@/lib/game/finances';
import { leagueByCode } from '@/lib/game/leagues';
import { migrateTransferBudget, migrateWageBudget } from '@/lib/game/budget';
import { autoLineup, isLineupValid, positionGroupOf, type PlayerLike } from '@/lib/game/players';
import { computeLines, positionFitOf, type TeamTacticState } from '@/lib/game/strength';
import { computeStandings, type StandingMatchInput, type StandingTeamInput } from '@/lib/game/standings';
import { fogOfWar, potentialRangeOf, scoutSeedOf } from '@/lib/game/scouting';
import { mulberry32 } from '@/lib/game/rng';
import { coerceTrainingFocus, coerceTrainingIntensity } from '@/lib/game/training';
import { parseLineup, parseMatchPlan, parseTeamIdList } from '@/lib/game/types';
import type {
  BoardDTO, BuildingCardDTO, BuildingsDTO, ContractExpiringDTO, CupMatchDTO, CupRoundDTO,
  CupSnapshotDTO, FinanceDTO, FixtureDTO, GameSnapshot, LeagueInfoDTO, MatchPreviewDTO, NewsDTO,
  PlayerDTO, PlayerLeaderDTO, Position, SeasonMatchDTO, StandingRow, TeamBriefDTO, TeamDTO,
  TrainingStateDTO, WeekInfoDTO,
} from '@/lib/game/types';

export function toTeamBrief(team: TeamRecord): TeamBriefDTO {
  return {
    id: team.id,
    name: team.name,
    shortName: team.shortName,
    city: team.city,
    colorPrimary: team.colorPrimary,
    colorSecondary: team.colorSecondary,
    strength: team.strength,
    isUser: team.isUserTeam,
    formation: coerceFormation(team.formation),
    mentality: coerceMentality(team.mentality),
    // Фаза 4: бейдж стиля тренера (null у клуба игрока — его «тренер» сам игрок)
    coachStyle: team.isUserTeam ? null : coerceAiStyle(team.aiStyle),
    coachName: team.isUserTeam ? null : team.aiCoachName,
  };
}

export function toPlayerDTO(p: PlayerRecord, askingPrice: number | null = null): PlayerDTO {
  return {
    id: p.id,
    teamId: p.teamId,
    firstName: p.firstName,
    lastName: p.lastName,
    nationality: p.nationality,
    position: p.position as PlayerDTO['position'],
    shirtNumber: p.shirtNumber,
    age: p.age,
    potential: p.potential,
    ovr: p.ovr,
    finishing: p.finishing,
    passing: p.passing,
    dribbling: p.dribbling,
    crossing: p.crossing,
    tackling: p.tackling,
    marking: p.marking,
    positioning: p.positioning,
    heading: p.heading,
    pace: p.pace,
    stamina: p.stamina,
    strength: p.strength,
    aggression: p.aggression,
    reflexes: p.reflexes,
    rushingOut: p.rushingOut,
    kicking: p.kicking,
    handling: p.handling ?? 50,
    // ── Engine 2.0: ментальные/физические ──
    vision: p.vision ?? 50,
    decisions: p.decisions ?? 50,
    leadership: p.leadership ?? 50,
    acceleration: p.acceleration ?? 50,
    jumping: p.jumping ?? 50,
    morale: p.morale,
    condition: p.condition,
    injuryWeeks: p.injuryWeeks,
    value: p.value,
    salary: p.salary,
    goals: p.goals,
    assists: p.assists,
    apps: p.apps,
    yellowCards: p.yellowCards,
    redCards: p.redCards,
    cleanSheets: p.cleanSheets,
    cupGoals: p.cupGoals,
    cupAssists: p.cupAssists,
    // ── Фаза 4: Кубок Европы ──
    euroGoals: p.euroGoals,
    euroAssists: p.euroAssists,
    askingPrice,
    // ── Фаза 3 ──
    contractUntil: p.contractUntil,
    avgRating: p.ratingApps > 0 ? Math.round(p.ratingSum / p.ratingApps) / 10 : null,
    preContract: p.preContractTeamId !== null,
    // ── Engine 2.0: бонусы контракта + туман войны (свой игрок = 100) ──
    goalBonus: p.goalBonus ?? 0,
    cleanSheetBonus: p.cleanSheetBonus ?? 0,
    scoutKnowledge: 100,
    potentialRange: [p.potential, p.potential] as [number, number],
    scoutedBy: null,
  };
}

/**
 * Модуль 3: DTO чужого игрока с «туманом войны» — атрибуты/OVR с шумом
 * (или скрыты при знании <40), потенциал вилкой, знание и флаг наблюдения.
 * seed привязан к неделе: оценки стабильны в течение недели.
 */
export function toScoutedPlayerDTO(
  p: PlayerRecord,
  report: { knowledge: number; watched: boolean } | null,
  week: number,
  askingPrice: number | null = null,
): PlayerDTO {
  const base = toPlayerDTO(p, askingPrice);
  if (report !== null && report.knowledge >= 100) return base;
  const knowledge = report?.knowledge ?? 0; // незнакомец — максимум тумана
  const rng = mulberry32(scoutSeedOf(p.saveId, p.id, week));
  const fog = fogOfWar({ rng, player: p as unknown as PlayerLike, knowledge });
  return {
    ...base,
    ...fog.attrs,
    ovr: fog.ovr,
    potentialRange: potentialRangeOf(p.potential, p.ovr, knowledge),
    scoutKnowledge: knowledge,
    scoutedBy: report?.watched ? 'watching' : null,
  };
}

/** D-5 «Территория» (§3.6): 8 карточек зданий — всё посчитано здесь, UI ничего не считает. */
export function buildingsDtoOf(state: BuildingsState): BuildingsDTO {
  const cards: BuildingCardDTO[] = BUILDINGS.map((spec) => {
    const st = state[spec.id];
    const level = Math.min(BUILDING_MAX_LEVEL, Math.max(0, st.level));
    const next = level < BUILDING_MAX_LEVEL ? level + 1 : null;
    return {
      id: spec.id,
      name: spec.name,
      level,
      upgradeEndsAtDay: st.upgradeEndsAtDay,
      priceNext: next !== null ? priceOf(spec.id, next) : null,
      daysNext: next !== null ? daysOf(spec.id, next) : null,
      upkeepWeekly: upkeepWeeklyOfBuilding(spec.id, level),
    };
  });
  return cards;
}

export function toTeamDTO(team: TeamRecord): TeamDTO {
  return {
    id: team.id,
    name: team.name,
    shortName: team.shortName,
    city: team.city,
    colorPrimary: team.colorPrimary,
    colorSecondary: team.colorSecondary,
    strength: team.strength,
    isUserTeam: team.isUserTeam,
    stadiumCapacity: team.stadiumCapacity,
    formation: coerceFormation(team.formation),
    mentality: coerceMentality(team.mentality),
    tempo: coerceTempo(team.tempo),
    pressing: coercePressing(team.pressing),
    defLine: coerceDefLine(team.defLine),
    playStyle: coercePlayStyle(team.playStyle),
    lineup: parseLineup(team.lineup),
    bench: parseLineup(team.bench),
    // ── Фаза 4: стиль/план (клуб игрока: стиль balanced + план из Team.matchPlan) ──
    aiStyle: coerceAiStyle(team.aiStyle),
    aiCoachName: team.aiCoachName,
    matchPlan: parseMatchPlan(team.matchPlan),
    // ── D-5 «Территория»: карточки зданий клуба (§3.6) ──
    buildings: buildingsDtoOf(parseBuildings(team.buildings)),
    // ── Модуль 5: расширение стадиона ──
    stadiumPending: team.stadiumPending,
    stadiumUpgradeEndsAtDay: team.stadiumUpgradeEndsAtDay,
  };
}

/** Состояние команды для расчёта линий (lineup невалиден → автосостав). */
function tacticStateOf(team: TeamRecord, players: PlayerLike[]): TeamTacticState {
  const formation = coerceFormation(team.formation);
  const saved = parseLineup(team.lineup);
  const lineup =
    team.isUserTeam && isLineupValid(saved, players)
      ? (saved as string[])
      : autoLineup(players, formation).lineup;
  return {
    teamId: team.id,
    players,
    formation,
    mentality: coerceMentality(team.mentality),
    tempo: coerceTempo(team.tempo),
    pressing: coercePressing(team.pressing),
    defLine: coerceDefLine(team.defLine),
    playStyle: coercePlayStyle(team.playStyle),
    lineup,
  };
}

function buildFixture(
  match: {
    id: string;
    week: number;
    competition: string;
    cupRound: number | null;
    homeTeamId: string;
    awayTeamId: string;
    homeGoals: number | null;
    awayGoals: number | null;
    homePens: number | null;
    awayPens: number | null;
    status: string;
    isNeutral: boolean;
  },
  teamById: Map<string, TeamRecord>,
  userTeamId: string,
): FixtureDTO | null {
  const home = teamById.get(match.homeTeamId);
  const away = teamById.get(match.awayTeamId);
  if (!home || !away) return null;
  const competition: FixtureDTO['competition'] =
    match.competition === 'cup' ? 'cup' : match.competition === 'euro' ? 'euro' : 'league';
  return {
    id: match.id,
    week: match.week,
    competition,
    cupRound: match.cupRound,
    homeTeamId: home.id,
    homeName: home.name,
    homeShort: home.shortName,
    homePrimary: home.colorPrimary,
    homeSecondary: home.colorSecondary,
    awayTeamId: away.id,
    awayName: away.name,
    awayShort: away.shortName,
    awayPrimary: away.colorPrimary,
    awaySecondary: away.colorSecondary,
    homeGoals: match.homeGoals,
    awayGoals: match.awayGoals,
    homePens: match.homePens,
    awayPens: match.awayPens,
    played: match.status === 'played',
    isUserMatch: home.id === userTeamId || away.id === userTeamId,
    isNeutral: match.isNeutral,
  };
}

/** Совет ассистента для дашборда (squadWarnings, раздел 5.2 architecture.md). */
function buildSquadWarnings(
  team: TeamRecord,
  players: PlayerLike[],
  lineup: (string | null)[] | null,
): string[] {
  const warnings: string[] = [];
  if (!lineup) return warnings;
  const byId = new Map(players.map((p) => [p.id, p]));
  const slots = FORMATIONS[coerceFormation(team.formation)].slots;
  const starters = lineup
    .map((id, i) => {
      const p = id ? byId.get(id) : undefined;
      return p && slots[i] ? { p, slot: slots[i] } : null;
    })
    .filter((x): x is { p: PlayerLike; slot: (typeof slots)[number] } => !!x);

  if (starters.some((s) => s.p.injuryWeeks > 0)) {
    warnings.push('В составе травмированный игрок');
  }

  const offPosition = starters.filter(
    (s) => positionFitOf(positionGroupOf(s.p.position), positionGroupOf(s.slot.position)) < 0.9,
  );
  if (offPosition.length >= 2) {
    warnings.push(`${offPosition.length} игроков не на своих позициях`);
  }

  if (starters.length > 0) {
    const avgCondition = starters.reduce((s, x) => s + x.p.condition, 0) / starters.length;
    if (avgCondition < 60) warnings.push('Состав устал, подумайте о ротации');
  }

  if (warnings.length === 0) warnings.push('Команда в порядке и готова к матчу');
  return warnings;
}

/** Информация о неделе (label для хедера; Фаза 4: суффикс «· Кубок Европы» на евронеделях). */
function buildWeekInfo(
  save: { week: number; season: number; euroSeason: number | null },
  leagueCode: string,
): WeekInfoDTO {
  const plan = buildSeasonPlan(leagueCode);
  const week = Math.min(Math.max(save.week, 1), plan.totalWeeks);
  const slot = weekSlotAt(plan, week);
  let label = weekLabelOf(plan, week);
  // Евронеделя активного сезона евро — двойная неделя (кубок/еврокубок)
  if (save.euroSeason === save.season && euroRoundAt(plan, week) !== null) {
    label = `${label} · Кубок Европы`;
  }
  return {
    week: save.week,
    totalWeeks: plan.totalWeeks,
    type: slot.type,
    label,
    leagueRound: slot.type === 'league' ? (slot.leagueRound ?? null) : null,
    cupRound: slot.type === 'cup' ? (slot.cupRound ?? null) : null,
    cupRoundLabel: slot.type === 'cup' && slot.cupRound
      ? cupRoundLabel(plan.teamCount, slot.cupRound)
      : null,
  };
}

/**
 * DTO правления (Фаза 3). Легаси-сейвы без boardTarget получают display-фолбэк
 * по рангу силы (идентичен ленивой инициализации simulateWeek — запись там же).
 * Экспортируется для GET /api/game/board.
 * D-6 (§4.3): престиж менеджера ≥ 70.0 снижает порог предупреждения 30 → 25
 * (эффективный warnLevel; цели правления НЕ меняются).
 */
export function boardDtoOf(
  save: Pick<
    GameSaveRecord,
    'boardTarget' | 'boardTargetPlace' | 'boardConfidence' | 'honeymoonUntilWeek' | 'week' | 'teamId' | 'manager' | 'season'
    | 'boardHistory' | 'financeTarget' | 'transferBudget' | 'wageBudget' | 'balance'
  >,
  teamCount: number,
  teams: { id: string; strength: number }[],
): BoardDTO {
  const known = save.boardTarget && save.boardTarget in BOARD_TARGET_LABELS;
  let code: BoardTargetCode;
  let place: number;
  if (known) {
    code = save.boardTarget as BoardTargetCode;
    place = save.boardTargetPlace ?? teamCount;
  } else {
    const fallback = nextSeasonTarget({
      teamCount,
      teams,
      userTeamId: save.teamId as string,
      prevPlace: null,
      harderByOverperformance: false,
    });
    code = fallback.code;
    place = fallback.place;
  }
  const confidence = save.boardConfidence;
  const job = jobStatusOf(confidence);
  // D-6 (§4.3): престиж из ManagerState (легаси null → дефолт 400 → порог 30)
  const managerPrestige = parseManager(save.manager, 0)?.prestige ?? MANAGER_PRESTIGE_START;
  // Модуль 5: история доверия (текущий сезон — толерантный парсер), финцель,
  // бюджеты (легаси-0 → display-миграция, как в simulateWeek)
  const history = parseBoardHistory(save.boardHistory, save.season)
    .points.map((p) => ({ week: p.w, confidence: p.c }));
  const ft: FinanceTargetCode | null =
    save.financeTarget === 'no_debt' || save.financeTarget === 'wage_control'
      ? save.financeTarget
      : null;
  return {
    target: code,
    targetLabel: BOARD_TARGET_LABELS[code],
    targetPlace: place,
    confidence,
    jobStatus: job.code,
    jobStatusLabel: job.label,
    honeymoonWeeksLeft: Math.max(0, (save.honeymoonUntilWeek ?? 0) - save.week),
    warnLevel: boardWarnLevel(confidence, boardWarnBelowOf(managerPrestige)),
    // ── Модуль 5 ──
    history,
    financeTarget: ft !== null ? { code: ft, label: FINANCE_TARGET_LABELS[ft] } : null,
    transferBudget: migrateTransferBudget(save.balance, save.transferBudget),
    wageBudget: save.wageBudget,
  };
}

/** Карточки истекающих контрактов для снапшота (yearsLeft ≤ 1) и GET /contracts. */
export function contractsExpiringOf(
  season: number,
  squad: PlayerLike[],
): ContractExpiringDTO[] {
  const teamApps = teamAppsOf(squad);
  return squad
    .filter((p) => yearsLeftOf(p.contractUntil, season) <= 1)
    .map((p) => ({
      playerId: p.id,
      name: `${p.firstName} ${p.lastName}`,
      position: p.position as Position,
      age: p.age,
      ovr: p.ovr,
      value: p.value,
      salary: p.salary,
      contractUntil: p.contractUntil,
      yearsLeft: yearsLeftOf(p.contractUntil, season),
      demand: renewDemand({ player: p, squad, teamApps }),
      maxRenewYears: maxRenewYears(p.age),
      preContract: p.preContractTeamId !== null,
    }))
    .sort((a, b) => a.yearsLeft - b.yearsLeft || b.ovr - a.ovr);
}

export async function buildSnapshot(saveId: string): Promise<GameSnapshot> {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, include: { team: true } });
  // Фаза 3: finished-сейвы (уволен) остаются доступны для просмотра
  if (
    !save ||
    !save.teamId ||
    !save.team ||
    (save.status !== 'active' && save.status !== 'finished')
  ) {
    throw new ApiGameError('NO_SAVE', 404);
  }

  const def = leagueByCode(save.leagueCode);
  if (!def) throw new ApiGameError('NO_SAVE', 404);
  const plan = buildSeasonPlan(def.code);
  const N = def.teamCount;

  // Фаза 4: все команды сейва (включая гостей — для еврофикстур и превью соперников-гостей)
  const allTeams = await db.team.findMany({ where: { saveId } });
  const teamById = new Map(allTeams.map((t) => [t.id, t]));
  // Лиговые команды: таблица/лидеры/список команд — БЕЗ гостей (изоляция §5.5 ТЗ)
  const teams = allTeams.filter((t) => !t.isEuroGuest);
  const myTeam = save.team;
  const userTeamId = myTeam.id;

  const myPlayerRows = await db.player.findMany({
    where: { saveId, teamId: userTeamId },
    orderBy: [{ ovr: 'desc' }],
  });

  // цены своих лотов
  const myListings = await db.transferListing.findMany({
    where: { saveId, status: 'active', source: 'user' },
    select: { playerId: true, price: true },
  });
  const askingByPlayer = new Map(myListings.map((l) => [l.playerId, l.price]));

  const myPlayers = myPlayerRows.map((p) => toPlayerDTO(p, askingByPlayer.get(p.id) ?? null));
  const myPlayersLike = myPlayerRows as unknown as PlayerLike[];

  // Таблица — ТОЛЬКО лига (competition='league')
  const playedLeagueMatches = await db.match.findMany({
    where: { saveId, season: save.season, status: 'played', competition: 'league' },
    select: { homeTeamId: true, awayTeamId: true, homeGoals: true, awayGoals: true, week: true },
  });
  const standingTeams: StandingTeamInput[] = teams.map((t) => ({
    id: t.id,
    name: t.name,
    shortName: t.shortName,
    colorPrimary: t.colorPrimary,
    colorSecondary: t.colorSecondary,
    isUser: t.isUserTeam,
  }));
  const standingInputs: StandingMatchInput[] = playedLeagueMatches
    .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
    .map((m) => ({
      homeTeamId: m.homeTeamId,
      awayTeamId: m.awayTeamId,
      homeGoals: m.homeGoals as number,
      awayGoals: m.awayGoals as number,
      week: m.week,
    }));
  const standings: StandingRow[] = computeStandings(standingTeams, standingInputs);
  const myPlace = standings.find((s) => s.teamId === userTeamId)?.place ?? N;

  // Матчи текущей недели (лига / кубок / евро) + весь сезон; кубковый матч недели — РАНЬШЕ евро
  const weekFixturesRows = await db.match.findMany({
    where: { saveId, season: save.season, week: save.week },
    orderBy: [{ id: 'asc' }],
  });
  const fixtures: FixtureDTO[] = weekFixturesRows
    .map((m) => buildFixture(m, teamById, userTeamId))
    .filter((f): f is FixtureDTO => !!f)
    .sort((a, b) => {
      const euroRank = (f: FixtureDTO) => (f.competition === 'euro' ? 1 : 0);
      return euroRank(a) - euroRank(b) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    });

  const seasonMatchRows = await db.match.findMany({
    where: { saveId, season: save.season },
    select: {
      id: true, week: true, competition: true, cupRound: true, homeTeamId: true,
      awayTeamId: true, homeGoals: true, awayGoals: true, status: true,
    },
    orderBy: [{ week: 'asc' }, { id: 'asc' }],
  });
  const seasonMatches: SeasonMatchDTO[] = seasonMatchRows.map((m) => ({
    id: m.id,
    week: m.week,
    competition: m.competition === 'cup' ? 'cup' : m.competition === 'euro' ? 'euro' : 'league',
    cupRound: m.cupRound,
    homeTeamId: m.homeTeamId,
    awayTeamId: m.awayTeamId,
    homeGoals: m.homeGoals,
    awayGoals: m.awayGoals,
    played: m.status === 'played',
  }));

  const nextMatch = fixtures.find((f) => f.isUserMatch && !f.played) ?? null;

  // Превью следующего матча: линии соперника по автосоставу
  let nextMatchPreview: MatchPreviewDTO | null = null;
  if (nextMatch) {
    const opponentId = nextMatch.homeTeamId === userTeamId ? nextMatch.awayTeamId : nextMatch.homeTeamId;
    const opponent = teamById.get(opponentId);
    if (opponent) {
      const oppPlayers = await db.player.findMany({ where: { saveId, teamId: opponentId } });
      const oppState = tacticStateOf(opponent, oppPlayers as unknown as PlayerLike[]);
      const oppLines = computeLines(oppState);
      const myState = tacticStateOf(myTeam, myPlayersLike);
      const myLines = computeLines(myState);
      nextMatchPreview = {
        opponent: toTeamBrief(opponent),
        opponentLines: {
          attack: Math.round(oppLines.attack),
          midfield: Math.round(oppLines.midfield),
          defence: Math.round(oppLines.defence),
        },
        myLines: {
          attack: Math.round(myLines.attack),
          midfield: Math.round(myLines.midfield),
          defence: Math.round(myLines.defence),
        },
      };
    }
  }

  // ── Кубок: сетка раундов сезона ──
  const cupMatchRows = await db.match.findMany({
    where: { saveId, season: save.season, competition: 'cup' },
    orderBy: [{ cupRound: 'asc' }, { id: 'asc' }],
  });
  const cupRounds: CupRoundDTO[] = [];
  for (let r = 1; r <= plan.cupRounds; r++) {
    const rows = cupMatchRows.filter((m) => m.cupRound === r);
    const matches: CupMatchDTO[] = rows.map((m) => {
      const home = teamById.get(m.homeTeamId);
      const away = teamById.get(m.awayTeamId);
      return {
        id: m.id,
        home: home ? toTeamBrief(home) : null,
        away: away ? toTeamBrief(away) : null,
        homeGoals: m.homeGoals,
        awayGoals: m.awayGoals,
        homePens: m.homePens,
        awayPens: m.awayPens,
        winnerTeamId: m.winnerTeamId,
        played: m.status === 'played',
        isUserMatch: m.homeTeamId === userTeamId || m.awayTeamId === userTeamId,
        isNeutral: m.isNeutral,
      };
    });
    cupRounds.push({
      round: r,
      label: cupRoundLabel(N, r),
      week: plan.cupWeeks[r - 1],
      drawn: rows.length > 0,
      matches,
    });
  }

  const cupAlive = parseTeamIdList(save.cupAliveTeamIds);
  const myCupLosses = cupMatchRows.filter(
    (m) =>
      (m.homeTeamId === userTeamId || m.awayTeamId === userTeamId) &&
      m.status === 'played' &&
      m.winnerTeamId !== null &&
      m.winnerTeamId !== userTeamId,
  );
  const myEliminatedRound = myCupLosses.length > 0
    ? Math.max(...myCupLosses.map((m) => m.cupRound ?? 0))
    : null;
  const finalRow = cupMatchRows.find((m) => m.cupRound === plan.cupRounds && m.status === 'played');
  const isCupWinner = !!finalRow && finalRow.winnerTeamId === userTeamId;
  const isAlive = cupAlive.includes(userTeamId) && save.cupRound < plan.cupRounds;

  let myStatus: CupSnapshotDTO['myStatus'];
  if (isCupWinner) myStatus = 'winner';
  else if (isAlive) myStatus = 'alive';
  else if (myEliminatedRound !== null) myStatus = 'eliminated';
  else myStatus = 'not_started';

  const currentRound = save.cupRound >= plan.cupRounds ? plan.cupRounds : save.cupRound + 1;

  const cup: CupSnapshotDTO = {
    cupName: def.cupName,
    currentRound,
    myStatus,
    myEliminatedRound,
    rounds: cupRounds,
  };

  // ── Тренировка клуба игрока ──
  const training: TrainingStateDTO = {
    focus: coerceTrainingFocus(myTeam.trainingFocus),
    intensity: coerceTrainingIntensity(myTeam.trainingIntensity),
  };

  // ── Live-лидеры (топ-10) — только игроки ЛИГОВЫХ команд (гости — в topEuroScorers /awards) ──
  const allLeaguePlayers = await db.player.findMany({
    where: { saveId, teamId: { not: null }, team: { isEuroGuest: false } },
  });
  const leaderTeams = new Map(
    teams.map((t) => [
      t.id,
      {
        name: t.name,
        shortName: t.shortName,
        c1: t.colorPrimary,
        c2: t.colorSecondary,
        isUser: t.isUserTeam,
      },
    ]),
  );
  const leaders = liveLeaders({
    players: allLeaguePlayers as unknown as PlayerLike[],
    teams: leaderTeams,
    take: 10,
  });

  // Новости
  const newsRows = await db.newsItem.findMany({
    where: { saveId },
    orderBy: [{ season: 'desc' }, { week: 'desc' }, { createdAt: 'desc' }],
    take: 10,
  });
  const news: NewsDTO[] = newsRows.map((n) => ({
    id: n.id,
    season: n.season,
    week: n.week,
    type: n.type as NewsDTO['type'],
    message: n.message,
  }));

  // Финансы
  const financeRows = await db.financeRecord.findMany({
    where: { saveId, season: save.season },
    orderBy: [{ week: 'desc' }, { createdAt: 'desc' }],
  });
  const wages = weeklyWages(myPlayersLike);
  // Модуль 5: оценка недельного дохода — спонсор + билеты (в среднем) +
  // ТВ-отчисления по месту + мерч фан-шопа (детерминированные статьи — без rng)
  const userBuildings = parseBuildings(myTeam.buildings);
  const tvNow = tvIncomeOf(myPlace, N, def.code);
  const merchNow = merchWeekly(userBuildings.fanshop.level);
  const income = Math.round(
    weeklyIncomeEstimate(myPlace, myTeam.stadiumCapacity, N) + tvNow + merchNow,
  );
  const records: FinanceDTO[] = financeRows.slice(0, 30).map((r) => ({
    id: r.id,
    season: r.season,
    week: r.week,
    kind: r.kind as FinanceDTO['kind'],
    category: r.category as FinanceDTO['category'],
    amount: r.amount,
    description: r.description,
  }));
  const seasonIncome = financeRows.filter((r) => r.kind === 'income').reduce((s, r) => s + r.amount, 0);
  const seasonExpense = financeRows.filter((r) => r.kind === 'expense').reduce((s, r) => s + r.amount, 0);
  // Модуль 5: отчёт по статьям — агрегация всех записей сезона (сорт: оборот ↓)
  const catAcc = new Map<FinanceCategory, { income: number; expense: number }>();
  for (const r of financeRows) {
    const key = r.category as FinanceCategory;
    const acc = catAcc.get(key) ?? { income: 0, expense: 0 };
    if (r.kind === 'income') acc.income += r.amount;
    else acc.expense += r.amount;
    catAcc.set(key, acc);
  }
  const byCategory = [...catAcc.entries()]
    .map(([category, acc]) => ({
      category,
      label: FINANCE_CATEGORY_LABELS[category] ?? category,
      income: acc.income,
      expense: acc.expense,
    }))
    .sort((a, b) => b.income + b.expense - (a.income + a.expense));

  // ── Модуль 6: недельный поток (график «Финансы»): агрегация по неделям
  //  текущего сезона, последние 26 точек, по возрастанию недели. ──
  const weekAcc = new Map<number, { income: number; expense: number }>();
  for (const r of financeRows) {
    const acc = weekAcc.get(r.week) ?? { income: 0, expense: 0 };
    if (r.kind === 'income') acc.income += r.amount;
    else acc.expense += r.amount;
    weekAcc.set(r.week, acc);
  }
  const weekly = [...weekAcc.entries()]
    .sort((a, b) => a[0] - b[0])
    .slice(-26)
    .map(([week, acc]) => ({
      week,
      income: acc.income,
      expense: acc.expense,
      net: acc.income - acc.expense,
    }));

  const lineup = parseLineup(myTeam.lineup);
  const squadWarnings = buildSquadWarnings(myTeam, myPlayersLike, lineup);

  // ── Фаза 3: правление + истекающие контракты ──
  const board = boardDtoOf(save, N, teams.map((t) => ({ id: t.id, strength: t.strength })));
  const contractsExpiring = contractsExpiringOf(save.season, myPlayersLike);

  const league: LeagueInfoDTO = {
    code: def.code,
    nameRu: def.nameRu,
    country: def.country,
    flag: def.flag,
    teamCount: def.teamCount,
    leagueWeeks: def.leagueWeeks,
    cupName: def.cupName,
    difficulty: def.difficulty,
  };

  const weekInfo = buildWeekInfo(save, def.code);

  return {
    save: {
      id: save.id,
      managerName: save.managerName,
      careerName: save.careerName ?? `${myTeam.name} · Сезон ${save.season}`,
      season: save.season,
      week: save.week,
      totalWeeks: plan.totalWeeks,
      balance: save.balance,
      transferBudget: migrateTransferBudget(save.balance, save.transferBudget),
      status: save.status,
      weekInfo,
      league,
    },
    myTeam: toTeamDTO(myTeam),
    myPlayers,
    teams: teams.map(toTeamBrief),
    standings,
    fixtures,
    seasonMatches,
    cup,
    training,
    leaders,
    nextMatch,
    nextMatchPreview,
    news,
    finances: {
      weeklyWages: wages,
      weeklyIncome: income,
      wageRatio: income > 0 ? wages / income : wages > 0 ? 1 : 0,
      records,
      seasonIncome,
      seasonExpense,
      // ── Модуль 5: бюджеты + отчёт по статьям ──
      byCategory,
      transferBudget: migrateTransferBudget(save.balance, save.transferBudget),
      wageBudget: migrateWageBudget(wages, save.wageBudget),
      wagesActual: wages,
      // ── Модуль 6: недельный поток для графика ──
      weekly,
    },
    squadWarnings,
    // ── Фаза 3 ──
    board,
    contractsExpiring,
  };
}

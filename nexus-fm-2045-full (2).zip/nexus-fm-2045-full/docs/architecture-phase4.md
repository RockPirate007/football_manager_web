# Техническое задание Фазы 4 — «Матч-ИИ · Стили тренеров · Кубок Европы · Баланс»

> **Task ID:** P4-2 · **Автор:** Агент-Архитектор (Лагерь 1 — Research & Design) · **Стадия:** Фаза 4
> **Основа:** docs/research-phase4.md (P4-1 — главный вход: ВСЕ формулы, таблицы и числа взяты оттуда), docs/architecture-phase3.md (образец формата/DTO/API-стиля), текущий код (проверен построчно: prisma/schema.prisma — 9 моделей; match.ts 424 стр. — λ один раз, goalMinute 40/52/8, красные на всю λ; strength.ts — applyModifiers/computeLines; week.ts 2054 стр. — пайплайн недели/перехода, applyPostMatch по всем ctxs; constants.ts 697; types.ts 1006; progression.ts — apps только стартёрам, drain −(22−stamina/12), recovery +8 внутри applyPostMatch; calendar.ts — CUP_WEEKS {16:[8,16,24,34], 18:[7,15,24,32,39], 20:[8,16,26,35,43]}; cup.ts — drawCupRound/simulateAiCupMatch/simulatePenaltyShootout; generate.ts — aiTactic/generateSquad; leagues.ts — LeagueDef/112 клубов/пулы имён; players.ts — PlayerLike/autoLineup (rotate при avgCond<55)/generatePlayer; snapshot.ts/api-helpers.ts/error.ts; все 22 эндпоинт-метода API; store.ts/api.ts; GameShell/MatchScreen/MatchTimeline/TacticsScreen/CupScreen/DashboardScreen).
> **Статус:** проект готов к реализации без дополнительных решений. Все поля, формулы, сигнатуры, контракты API, порядок пайплайна, календарь евро и разбиение по блокам зафиксированы. Числа из research-phase4.md обязательны; отклонения перечислены в §0.3 с обоснованием.

---

## 0. Резюме, объём, что НЕ входит

### 0.1. Что строим

| Блок | Содержание |
|---|---|
| **Match AI** | Сегментный движок матча: 3 сегмента [1–45][46–70][71–93] с долями голов 42/28/30%, пересчёт λ на каждом сегменте, симметричная усталость −6 condition/сегмент стартёрам; решения тренера на 2 контрольных точках (перерыв 46', 70'): FSM «счёт×фаза» + Utility-таблица; замены до 5 на команду со событием `'sub'`; «сушка» (self ×0.88 / opp ×0.85) и «погоня» (self ×1.15 / opp ×1.08) как время-взвешенные λ-множители; красные карточки — пре-рейтинг по оставшемуся времени с множителями 0.55/1.30 (ранние) и 0.70/1.15 (поздние) |
| **Стили ИИ-тренеров** | 5 профилей на Team (gegenpress/tikitaka/bus/vertical/balanced) — стиль НАЗНАЧАЕТ тактические поля (без двойного учёта с MENTALITY_MODS) + 1–2 уникальные дельты; ленивая миграция легаси-Team угадыванием по тактическим полям; смена стиля p=0.25/сезон (топ-6 силы p=0.10); бейдж стиля в превью матча и на экране соперника |
| **Кубок Европы** | 16 клубов (квоты EPL/LAL/SEA/BUN по 3 + FL1/RPL по 2), чистый нокаут 4 раунда на мидвиках CUP_WEEKS, totalWeeks НЕ меняется (34/39/43); гостевые клубы = полноценные Team-строки (isEuroGuest) с составами ~20–22 игрока, персистентные весь сейв; призовые: участие €2M + раунды 1/2/3M + финалист €3.5M + чемпион €5M (итог чемпиона €13M); boardConfidence: победа +2/+3, раунд +4, финал +8, обидный вылет −4; двойной drain в евронедели (congestion) |
| **Баланс** | YELLOW_LAMBDA_BASE 1.2→1.9, RED_CARD_PROB 0.025→0.030, RED_LAMBDA 0.85/1.10→0.55/1.30 и 0.93/1.05→0.70/1.15, CONTRACT_DRAIN_AGE 32→30 / OVR 55→60, goalMinute 40/52/8→42/28/30 (сегменты); Monte-Carlo-коридор home 44–48% / draw 24–27% / голы 2.6–2.9 — инвариант QA |

### 0.2. Объём кода-оценка

| Зона | Файлов | Строк (±15%) |
|---|---|---|
| Блок A (backend): schema + constants + types + data + coach.ts (новый) + match.ts (переписан) + progression.ts + euro.ts (новый) + generate.ts/players.ts + board.ts + week.ts + snapshot.ts/api-helpers.ts + 3 роута (2 новых) + правки 6 роутов + scripts/calibrate_segments.ts + смоук | ~19 | ~2500 |
| Блок B (frontend): api.ts + store.ts + MatchTimeline + MatchScreen (+план на матч) + EuroScreen (новый) + GameShell + DashboardScreen + LeagueScreen + SeasonCeremony + PlayerDialog + MatchDetailsDialog | ~11 | ~1400 |
| **Итого** | ~30 файлов | **~3900** |

### 0.3. Ключевые архитектурные решения (сводка)

1. **Сегментный движок — внутри match.ts** (не отдельный matchai.ts): simulateMatch переписывается целиком, общая структура «карточки/травмы вперёд → цикл 3 сегментов → пост-обработка» сохраняет текущую RNG-дисциплину. Вся логика решений тренера — в новом чистом модуле `coach.ts`. Обоснование: сегменты и решения неразделимы (решения меняют входы λ сегментов), а coach.ts остаётся тестируемым без движка.
2. **Время-взвешенные модификаторы** — единый механизм: красные, «сушка»/«погоня», «дефицит из-за травмы» применяются к λ сегмента с весом w = доля сегмента после события/порога: `factor = 1 − w + w × mul`. Это точная реализация «пре-рейтинга по оставшемуся времени» из research §4.3 без минутного тика.
3. **Симметричная усталость не трогает калибровку**: λ = BASE × effAtk_home/effDef_away; деградация стартёров обеих команд на одинаковый множитель сокращает и числитель, и знаменатель → λ и исходы не меняются (доказано Monte-Carlo research §1.3). Усталость влияет только на авторов голов и выбор замен.
4. **Календарь евро (вариант E research §3.2)**: свободных недель НЕТ ни в одном размере лиги (totalWeeks = leagueWeeks + cupRounds точно), поэтому 4 еврораунда совмещаются с кубковыми мидвиками. Раскладка по каждому размеру — §5.1. Congestion (до 2 матчей в неделю у клуба, живого в обоих турнирах) — ОСОЗНАННАЯ механика, а не побочный эффект.
5. **Разрезка applyPostMatch**: per-match (drain по минутам, мораль, статистика, рейтинг, травмы) и per-week (+8 recovery — ровно один раз на команду, сыгравшую ≥1 матч в неделю; отдых несыгравших +10/+2 как сейчас). Двойная неделя = два вызова per-match + один recovery.
6. **Гости — отдельная карта контекстов**: `db.team.findMany({where: {saveId, isEuroGuest: false}})` в week.ts/snapshot.ts/api-helpers.ts — весь существующий код над лиговыми командами не меняется; гости входят ТОЛЬКО в евроветку пайплайна и в сезонный переход (старение/реген/записи истории). Полный список мест-фильтров — §5.5.
7. **Prisma-дифф строго аддитивен** (Team +5, Player +2, PlayerSeasonRecord +2, GameSave +4, Match — только расширение unique-индекса колонкой competition) — `db push` не сбрасывает существующие сейвы. Ленивые миграции легаси — по образцу §1.4 architecture-phase3.md.
8. **План на матч — на Team.matchPlan (JSON)**, 3 органа управления (leadMode/chaseMode/fatigueSubs), дефолт = поведение ИИ (паритет: движок ИИ-решений работает и для клуба игрока). UI — карточка в превью MatchScreen (§7.4).
9. **Эндпоинты**: GET/POST `/api/game/matchplan`, GET `/api/game/euro` (брекет лениво, НЕ в /state — снапшот не раздувается); WeekResultPayload: `userMatches[]` вместо `userMatch` (двойная неделя), `euroRound` (жеребьёвка следующего раунда), finances += euroPrize.
10. **QA-гейт**: scripts/calibrate_segments.ts (bun, импортирует реальные чистые модули, 20k матчей) — коридор home 44–48 / draw 24–27 / 2.6–2.9 гола обязателен до и после включения решений ИИ (§9.1–9.2).

### 0.4. Отклонения от research-phase4.md (зафиксированы, все остальные числа — дословно)

| Пункт research | Решение ТЗ | Обоснование |
|---|---|---|
| §3.4 «~12 гостей × 20 игроков = ~240 строк» | Гостей **13–14** (16 − квота своей лиги 2/3) × 20–22 = **~280 Player-строк**, создаются лениво в неделю 1/8 (для новых сейвов — сезон 1, для легаси — первый достигнутый сезон) | Арифметика квот: 16 участников, своя лига даёт 2–3, остальные 13–14 — всегда из других лиг. Объём приемлем (~280 строк разово) |
| §3.3 «сезон 1 — seed по силе» + §3.7-4 «легаси включается со следующего перехода» | Унифицировано: **евро идёт с сезона 1 для новых сейвов** (ленивая инициализация в неделю 1/8: своя лига — топ-q по Team.strength, другие — топ-q по ClubSeed.str с шумом gauss(0,3)); сезоны 2+ — инициализация в сезонном переходе (своя лига — по итоговой таблице, другие — по силе с шумом). Легаси-сейв пропускает евро текущего сезона, если неделя 1/8 уже прошла | Одна и та же точка инициализации («первая достигнутая неделя 1/8 без состояния» ИЛИ переход) покрывает оба случая; флагштанская фича доступна сразу в новой карьере |
| §3.5 «PlayerSeasonRecord += euroGoals (1 поле)» | **2 поля: euroGoals + euroAssists** | Таблица истории уже показывает ассисты (кубковые — в скобках); симметрия с cupGoals/cupAssists |
| §0 «boardConfidence-дельты как у кубка ×1.5» | Точные числа §3.5: win +2 (+3 апсет), раунд +4, финал +8, обидный вылет −4 | Подробный раздел research точнее резюме; значения совпадают с кубковыми константами (+ новое −4) |
| §2.2 «парковка с 55'», chaseMinute 65/75/80 | Время-взвешенные пороги: parkBusMinute (bus 55, остальные 70) и chaseMinute (65/75/80) задают вес w внутри сегментов — см. §4.4 | Решения принимаются только на КТ 46/70; пороги стилей сохраняют различие через долю времени действия |
| §2.2 «INJURY_PROB ×1.2 при усталости» (gegenpress) | ×1.2, когда средний condition стартового состава на момент броска < 65 | Формализация «при усталости» из §2.3 |

### 0.5. Что НЕ входит в Фазу 4 (осознанно исключено)

- Ручные замены по ходу матча в UI (live-микроменеджмент) — заменён «Планом на матч» (постановка задачи).
- Лига Европы / второй евротурнир / групповая стадия — один турнир «Кубок Европы» (research §3.3).
- 9-я награда «Golden Boot Европы» (research §3.5, опция) — 8 наград остаются; live-бомбардиры евро есть на экране «Европа» (GET /awards live.topEuroScorers).
- «Игрок матча» (MOTM) — не хранится (как в Фазе 3).
- Touchline shouts, изучение тактики игрока ИИ — вне модели.
- Трансферы/Босман/продления для гостевых клубов; академия для гостей (замена — реген, §5.6).
- Изменение totalWeeks / формата национального кубка.

---

## 1. Дифф Prisma-схемы (точный)

Файл: `prisma/schema.prisma`. Все изменения аддитивны; `bunx prisma db push` НЕ требует сброса дев-БД (§10.1 — процедура с перезапуском dev-сервера, кейс stale-клиента из Фазы 2).

### 1.1. Team — 5 новых полей

```prisma
model Team {
  // ...все существующие поля без изменений (строки 54–79)...

  // ── Фаза 4: стиль ИИ-тренера ──
  aiStyle      String  @default("balanced") // gegenpress|tikitaka|bus|vertical|balanced; balanced — дефолт легаси
  aiCoachName  String? // имя тренера (косметика, из пула имён лиги); null у легаси до первой миграции и у клуба игрока

  // ── Фаза 4: Кубок Европы ──
  isEuroGuest Boolean @default(false) // гостевой клуб другой лиги (не участвует в лиге/рынке/кубке)
  leagueCode  String? // код лиги клуба; null = лига сейва (свои клубы); гости — всегда явный код

  // ── Фаза 4: план на матч (только клуб игрока; null = дефолт «как ИИ») ──
  matchPlan   String? // JSON MatchPlanSettings { leadMode, chaseMode, fatigueSubs }
}
```

Семантика:
- `aiStyle` — единственный источник стиля; тактические поля Team (formation/mentality/tempo/pressing/defLine/playStyle) НАЗНАЧАЮТСЯ профилем стиля при генерации и при смене стиля (§2.3). Клуб игрока всегда `'balanced'` (стиль не читается для него — его тренер живой).
- `aiCoachName` — маркер ленивой миграции: у легаси-Team он null → первая же simulateWeek угадывает стиль (§5.4) и записывает имя; у новых сейвов имя присваивается при генерации.
- `leagueCode` — для своих клубов заполняется при генерации (generateLeague) кодом лиги сейва; null трактуется как лига сейва (легаси-совместимость). У гостей — всегда код их лиги из leagues.ts.
- `matchPlan` — только у клуба игрока; ИИ-клубы всегда null (движок подставляет AI-план по умолчанию).

### 1.2. Player — 2 новых поля

```prisma
model Player {
  // ...существующие поля без изменений (строки 90–156)...

  // ── Фаза 4: Кубок Европы ──
  euroGoals   Int @default(0) // голы в еврокубке (сезонные, сброс в applySeasonProgression)
  euroAssists Int @default(0)
}
```

Голы еврокубка дублируются в общие `goals/assists` (как кубковые в cupGoals) — конвенция applyPostMatch (§4.6). У гостевых игроков поле тоже копится.

### 1.3. PlayerSeasonRecord — 2 новых поля

```prisma
model PlayerSeasonRecord {
  // ...существующие поля без изменений (строки 220–238)...

  // ── Фаза 4: евросезон в карточке игрока ──
  euroGoals   Int @default(0)
  euroAssists Int @default(0)
}
```

Гостевые игроки ПОЛУЧАЮТ записи (research §3.4): +260–280 строк/сезон к ~450 лиговым (инвариант №5 Фазы 3 расширяется, §9.13).

### 1.4. GameSave — 4 новых поля

```prisma
model GameSave {
  // ...существующие поля без изменений (строки 14–42)...

  // ── Фаза 4: Кубок Европы (зеркалит паттерн cupRound/cupAliveTeamIds) ──
  euroSeason         Int?    // сезон, на который рассчитано состояние; null = евро ещё не инициализировано
  euroRound          Int     @default(0) // последний ИГРАВШИЙСЯ раунд евро сезона (0 = не было)
  euroAliveTeamIds   String? // JSON string[] — участники следующего раунда; null = турнир завершён/сброшен
  euroParticipants   String? // JSON string[] — 16 id участников сезона (для экрана/квот)
}
```

Отдельная модель EuroState отклонена: паттерн «поля на GameSave» уже доказан кубком (cupRound/cupAliveTeamIds), состояние читается 4 раза за сезон и в одном GET — JOIN не оправдан.

### 1.5. Match — без новых колонок, расширение unique-индекса

```prisma
model Match {
  // ...существующие поля без изменений; competition остаётся String...
  // комментарий схемы: competition  String  @default("league") // league | cup | euro (Фаза 4)
  // euroRound НЕ вводится: номер раунда евро хранится в cupRound (все запросы евро фильтруют competition='euro')

  @@unique([saveId, season, week, homeTeamId, competition]) // было: [saveId, season, week, homeTeamId]
  @@index([saveId, season, week])        // без изменений
  @@index([saveId, season, competition, cupRound]) // без изменений — работает и для евро
}
```

**Причина расширения индекса**: в евронеделю клуб может быть ДОМОМ и в национальном кубке, и в еврокубке — два матча одной недели с одним homeTeamId. Старый unique дал бы P2002. Добавление колонки в unique-индекс ослабляет ограничение (существующие данные не нарушают новый индекс); `db push` пересоздаёт индекс без потери данных.

### 1.6. Косметика комментариев (без изменения типов)

- `FinanceRecord.category` — комментарий: `// ... | euro_prize (Фаза 4)` (поле String, значения свободные).
- `NewsItem.type` — комментарий: `// ... | euro (Фаза 4)`.

### 1.7. Совместимость с существующими сейвами (db push)

1. Все новые поля имеют дефолты (`@default`) — `db push` заполняет их у существующих строк: aiStyle='balanced', isEuroGuest=false, euroGoals=0, euroRound=0, euroSeason=null, euroParticipants=null.
2. После `bunx prisma db push` — обязательная регенерация клиента и **перезапуск dev-сервера** (известный кейс Фазы 2: устаревший Prisma-клиент в памяти даёт PrismaClientValidationError «Unknown argument»). Процедура — §8, шаг A1.
3. Ленивые миграции в рантайме (первая simulateWeek после апгрейда): угадывание стилей легаси-Team (§5.4), ленивая инициализация евро (§5.3). Поля matchPlan/aiCoachName/leagueCode остаются null у легаси до первого касания — читаются с фолбэками.

---

## 2. Константы (constants.ts)

Все новые блоки — в конец файла; правки существующих значений — построчно. Числа из research-phase4.md §5.1–5.4 обязательны.

### 2.1. Правки существующих констант (Блок «баланс», research §5.4)

```ts
// ── Было → Стало (файл constants.ts) ──
export const RED_CARD_PROB = 0.030;          // было 0.025
export const RED_LAMBDA_SELF = 0.55;         // было 0.85  (красная в сегменте 1, ≤45')
export const RED_LAMBDA_OPP = 1.30;          // было 1.10
export const RED_LAMBDA_SELF_LATE = 0.70;    // было 0.93  (красная в сегменте 2, 46–70')
export const RED_LAMBDA_OPP_LATE = 1.15;     // было 1.05
export const YELLOW_LAMBDA_BASE = 1.9;       // было 1.2   (итог ≈3.81 ЖК/матч; факт 4.42)
export const CONTRACT_DRAIN_AGE = 30;        // было 32    (QA §5.1: пул свободных агентов)
export const CONTRACT_DRAIN_OVR = 60;        // было 55
// goalMinute 40/52/8 → 42/28/30 — реализуется сегментами (SEGMENT_SHARES), отдельная функция goalMinute удаляется из match.ts
// YELLOW_CAP = 5, INJURY_PROB = 0.04, TEMPO_CHANCE_MOD, CONDITION_DRAIN_* — БЕЗ изменений (research §4.1 «ок»)
```

### 2.2. Новый блок MATCH_AI_* (сегменты, замены, режимы)

```ts
// ── Фаза 4: сегментный движок (research §1.3, §5.1) ──
export const SEGMENT_BOUNDS = [45, 70, 93] as const;       // границы минут: [1..45][46..70][71..93]
export const SEGMENT_SHARES = [0.42, 0.28, 0.30] as const; // доли голов (сумма строго 1.00)
export const SEGMENTS_COUNT = 3;
export const PER_SEGMENT_COND_DRAIN = 6;   // виртуальная усталость стартёра за сегмент (внутри матча)
export const COND_EFF_FLOOR = 40;          // floor виртуального condition при расчёте линий сегмента
export const SUB_MAX = 5;                  // замен на команду за матч
export const SUB_IN_CONDITION_CAP = 92;    // вышедший играет с effCond = min(condition, 92)
export const SUB_FATIGUE_MINUTE = 60;      // усталостные замены только на контрольной точке ≥ 60' (т.е. на 70')
export const SHORT_HANDED_LAMBDA_MOD = 0.93; // травма без замены (слоты исчерпаны) — к оставшемуся времени

// λ-множители режимов (research §1.3, §5.1)
export const PARKING_BUS_MOD = { self: 0.88, opp: 0.85 } as const; // «сушка» при победе late
export const CHASE_MOD = { self: 1.15, opp: 1.08 } as const;       // «погоня» при отставании ≥1 к 70'

// Utility-пороги (research §1.2, §5.1)
export const UTILITY_SUB_FATIGUE = 55;
export const UTILITY_SUB_CHASE = 40;
export const UTILITY_SUB_DEFENSIVE = 40;
export const UTILITY_MENTALITY = 25;
export const UTILITY_NOTHING = 30;   // консерватизм: скор действия «ничего»
export const UTILITY_NOISE = 10;     // шум ±10 на каждый скор
```

### 2.3. Новый блок STYLE_* (5 профилей ИИ-тренеров)

```ts
// ── Фаза 4: стили ИИ-тренеров (research §2.2, §2.6) ──
export type AiStyleCode = 'gegenpress' | 'tikitaka' | 'bus' | 'vertical' | 'balanced';

export interface AiStyleDef {
  code: AiStyleCode;
  label: string;   // русский для UI
  hint: string;    // строка-подсказка для превью
  /** Тактические поля, КОТОРЫЕ СТИЛЬ НАЗНАЧАЕТ Team при генерации/смене (не суммируются с MODS!) */
  tactic: {
    formation: FormationId; mentality: Mentality; tempo: TempoLevel;
    pressing: PressingLevel; defLine: DefLineLevel; playStyle: PlayStyle;
  };
  /** Уникальные дельты (применяются только в match.ts поверх applyModifiers) */
  yellowLambdaBonus: number;      // к λ ЖК команды (gegenpress +0.4)
  yellowVsPressingHigh: number;   // доп. к λ ЖК, если соперник pressing=high (vertical +0.2)
  condDrainPerSegment: number;    // PER_SEGMENT_COND_DRAIN + это (gegenpress +3)
  injuryProbMult: number;         // множитель INJURY_PROB (gegenpress 1.2 при avgCond<65, иначе 1.0)
  atkDelta: number;               // множитель effAtk (bus 0.95)
  defDelta: number;               // множитель effDef (bus 1.05)
  midDelta: number;               // множитель effMid — только possession (tikitaka 1.05)
  verticalVsHighLine: boolean;    // vertical: atk ×1.05 при opp.defLine === 'high'
  possessionBonus: number;        // п.п. к possession (tikitaka +5)
  shotsBonus: number;             // к ударам в статистике (tikitaka +1)
  sotShareDelta: number;          // п.п. к доле ударов в створ (tikitaka −3)
  chanceCountMult: number;        // множитель числа «опасных моментов» (vertical 1.2)
  /** Параметры Match-AI */
  parkBusMinute: number;          // порог активации «сушки» (bus 55, остальные 70)
  parkAtDraw: boolean;            // bus паркует и при ничьей
  chaseMinute: number;            // порог активации «погони» (65/75/80/70/70)
  mentalityDownDrawDelta: number; // сдвиг скорa mentality_down при ничьей late (bus +15, gegenpress −10)
}

export const AI_STYLES: Record<AiStyleCode, AiStyleDef> = {
  gegenpress: {
    code: 'gegenpress', label: 'Гегенпрессинг', hint: 'Высокая линия и прессинг: ждите темпа и карточек',
    tactic: { formation: '4-3-3', mentality: 'attacking', tempo: 'high', pressing: 'high', defLine: 'high', playStyle: 'passing' },
    yellowLambdaBonus: 0.4, yellowVsPressingHigh: 0, condDrainPerSegment: 3, injuryProbMult: 1.2,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.0, verticalVsHighLine: false,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.0,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 65, mentalityDownDrawDelta: -10,
  },
  tikitaka: {
    code: 'tikitaka', label: 'Тики-така', hint: 'Владение и позиционные атаки: много ударов низкой остроты',
    tactic: { formation: '4-2-3-1', mentality: 'attacking', tempo: 'medium', pressing: 'high', defLine: 'high', playStyle: 'passing' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.05, verticalVsHighLine: false,
    possessionBonus: 5, shotsBonus: 1, sotShareDelta: -0.03, chanceCountMult: 1.0,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 75, mentalityDownDrawDelta: 0,
  },
  bus: {
    code: 'bus', label: 'Автобус', hint: 'Низкий блок и катеначчо: игра на контратаках и сушке счёта',
    tactic: { formation: '5-3-2', mentality: 'defensive', tempo: 'low', pressing: 'low', defLine: 'low', playStyle: 'counter' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 0.95, defDelta: 1.05, midDelta: 1.0, verticalVsHighLine: false,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.0,
    parkBusMinute: 55, parkAtDraw: true, chaseMinute: 80, mentalityDownDrawDelta: 15,
  },
  vertical: {
    code: 'vertical', label: 'Вертикальный', hint: 'Прямые быстрые атаки: опасен против высокой линии обороны',
    tactic: { formation: '4-2-3-1', mentality: 'balanced', tempo: 'high', pressing: 'medium', defLine: 'medium', playStyle: 'counter' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0.2, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.0, verticalVsHighLine: true,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.2,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 70, mentalityDownDrawDelta: 0,
  },
  balanced: {
    code: 'balanced', label: 'Сбалансированный', hint: 'Универсальная игра без яркого почерка',
    tactic: { formation: '4-4-2', mentality: 'balanced', tempo: 'medium', pressing: 'medium', defLine: 'medium', playStyle: 'balanced' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.0, verticalVsHighLine: false,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.0,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 70, mentalityDownDrawDelta: 0,
  },
};

export const AI_STYLE_CODES: AiStyleCode[] = ['gegenpress', 'tikitaka', 'bus', 'vertical', 'balanced'];

export function coerceAiStyle(v: string): AiStyleCode {
  return (AI_STYLE_CODES as string[]).includes(v) ? (v as AiStyleCode) : 'balanced';
}

/** Назначение стиля при генерации/смене (research §2.6-2: сила + «национальный колорит»). */
export const AI_STYLE_ASSIGN: Record<'top' | 'mid' | 'low', readonly { style: AiStyleCode; p: number }[]> = {
  // сила ≥ 84: 40% узнаваемых (gegenpress/tikitaka)
  top: [
    { style: 'gegenpress', p: 0.20 }, { style: 'tikitaka', p: 0.20 },
    { style: 'vertical', p: 0.15 }, { style: 'bus', p: 0.10 }, { style: 'balanced', p: 0.35 },
  ],
  // 74–83: 25% узнаваемых
  mid: [
    { style: 'gegenpress', p: 0.10 }, { style: 'tikitaka', p: 0.10 },
    { style: 'vertical', p: 0.20 }, { style: 'bus', p: 0.25 }, { style: 'balanced', p: 0.35 },
  ],
  // < 74: 60% bus/vertical/balanced
  low: [
    { style: 'gegenpress', p: 0.05 }, { style: 'tikitaka', p: 0.05 },
    { style: 'vertical', p: 0.25 }, { style: 'bus', p: 0.30 }, { style: 'balanced', p: 0.35 },
  ],
};
export const AI_STYLE_LEAGUE_BIAS: Record<string, AiStyleCode> = { RPL: 'vertical', FL1: 'vertical' };
export const AI_STYLE_LEAGUE_BIAS_P = 0.25;   // p=0.25 → сразу vertical для RPL/FL1

/** Смена стиля в сезонном переходе (research §2.4). */
export const AI_STYLE_CHANGE_P = 0.25;         // обычные клубы
export const AI_STYLE_CHANGE_TOP_P = 0.10;     // топ-6 по силе («гранды идеологичны»)
export const AI_STYLE_TOP_RANK = 6;
export const AI_COACH_RENAME_P = 0.15;         // новое имя тренера при смене стиля
```

### 2.4. Новый блок EURO_* (Кубок Европы)

```ts
// ── Фаза 4: Кубок Европы (research §3.2–3.5, §5.3) ──
export const EURO_SIZE = 16;
export const EURO_ROUNDS = 4;
export const EURO_ROUND_LABELS = ['1/8 финала', '1/4 финала', '1/2 финала', 'Финал'] as const;
export const EURO_QUOTAS: Record<LeagueCode, number> = { EPL: 3, LAL: 3, SEA: 3, BUN: 3, FL1: 2, RPL: 2 }; // сумма = 16
export const EURO_TOURNAMENT_NAME = 'Кубок Европы';

/** Евронедели = кубковые недели БЕЗ предварительного раунда (N=18/20) / все (N=16). */
export const EURO_WEEKS: Record<number, number[]> = {
  16: [8, 16, 24, 34],     // RPL
  18: [15, 24, 32, 39],    // BUN/FL1 (кубковая неделя 7 — предварительный раунд, евро нет)
  20: [16, 26, 35, 43],    // EPL/LAL/SEA (кубковая неделя 8 — предварительный раунд, евро нет)
};

export const EURO_PRIZE_PARTICIPATION = 2_000_000; // за квалификацию (кредитуется в неделю 1/8)
export const EURO_PRIZE_ROUND = [1_000_000, 2_000_000, 3_000_000] as const; // победа в 1/8 / 1/4 / 1/2
export const EURO_PRIZE_FINALIST = 3_500_000; // проигравший финал
export const EURO_PRIZE_CHAMPION = 5_000_000; // чемпион (итого чемпиону: 2+1+2+3+5 = €13M)
export const EURO_QUAL_NOISE = 3;     // gauss(0, 3) при отборе участников других лиг
export const EURO_ROTATE_COND = 65;   // порог ротации autoLineup ИИ в евронедели (вместо 55)
export const EURO_GUEST_MIN_SQUAD = 18; // инвариант состава гостей после регена
export const EURO_WEAK_HOME_PROB = 0.7; // «слабый дома» при жеребьёвке евро (как в кубке)

/** Правление: евродельты (research §3.5; победа +2/+3 = BOARD_DELTA_WIN/UPSET, раунд +4 = BOARD_DELTA_CUP_ROUND, финал +8 = BOARD_DELTA_CUP_FINAL). */
export const BOARD_DELTA_EURO_UPSET_LOSS = -4; // вылет от заметно слабого (кубок: −3, Европа обиднее)
```

### 2.5. Новый блок MATCH_PLAN_* (план на матч)

```ts
// ── Фаза 4: план на матч клуба игрока (research §1.6, паритет с ИИ) ──
export type MatchPlanLeadMode = 'park' | 'hold';    // ведём к 70': сушить / играть как есть
export type MatchPlanChaseMode = 'allout' | 'steady'; // отстаём к 70': максимальная атака / без изменений

export const MATCH_PLAN_DEFAULT = { leadMode: 'park', chaseMode: 'allout', fatigueSubs: true } as const;
// Дефолт = поведение ИИ: движок ИИ-решений включается и для клуба игрока (паритет).
export const MATCH_PLAN_LABELS = {
  lead: { park: 'Сушить счёт', hold: 'Играть как есть' },
  chase: { allout: 'Максимальная атака', steady: 'Без паники' },
} as const;
```

---

## 3. Типы/DTO (types.ts — зона Блока A, замораживается до Блока B)

### 3.1. События матча

```ts
export type MatchEventType =
  | 'kickoff' | 'goal' | 'yellow' | 'red' | 'injury'
  | 'chance' | 'halftime' | 'fulltime'
  | 'pen_goal' | 'pen_miss' | 'pen_save'
  | 'sub'; // ── Фаза 4

export interface MatchEvent {
  // ...существующие поля...
  /** Фаза 4: замена — кто сошёл (playerId/playerName = кто ВЫШЕЛ). */
  subOutId?: string;
  subOutName?: string;
}
```

`TYPE_ORDER` в match.ts: `sub: 1` — при равной минуте sub-события встают ПЕРЕД голами (stable sort + порядок push: замены контрольной точки записываются до сэмплирования голов следующего сегмента).

### 3.2. План на матч

```ts
export interface MatchPlanDTO {
  leadMode: 'park' | 'hold';
  chaseMode: 'allout' | 'steady';
  fatigueSubs: boolean;
}
export interface MatchPlanResponse { ok: true; plan: MatchPlanDTO }
export interface SetMatchPlanResponse { ok: true; plan: MatchPlanDTO }

/** Толерантный парсер Team.matchPlan (JSON) — легаси/null/битый JSON → дефолт. */
export function parseMatchPlan(raw: string | null | undefined): MatchPlanDTO {
  // try JSON.parse; проверить leadMode/chaseMode/fatigueSubs по типам;
  // любое несоответствие → { ...MATCH_PLAN_DEFAULT }
}
```

`parseEvents` (types.ts): добавить проброс `subOutId/subOutName` (как assistId) и **пропуск неизвестных type** — валидация по множеству известных типов (`kickoff|goal|yellow|red|injury|chance|halftime|fulltime|pen_goal|pen_miss|pen_save|sub`); события с неизвестным type пропускаются (легаси-сейвы вперёд совместимы).

### 3.3. Расширения соревнований

```ts
// FixtureDTO.competition / SeasonMatchDTO.competition / MatchDetailsDTO.competition /
// UserMatchResultDTO.competition (новое поле):
export type Competition = 'league' | 'cup' | 'euro';

// UserMatchResultDTO += competition: Competition  (для подписи экрана матча)

// NewsType += 'euro'
// FinanceCategory += 'euro_prize'
// WeekFinancesDTO += euroPrize: number
```

### 3.4. DTO Кубка Европы

```ts
export interface EuroTeamDTO {
  id: string; name: string; shortName: string;
  leagueCode: LeagueCode; leagueFlag: string; leagueName: string; // «гость из Ла Лиги»
  colorPrimary: string; colorSecondary: string;
  strength: number; isUser: boolean; isGuest: boolean;
  coachStyle: AiStyleCode | null; coachName: string | null;
}
export interface EuroMatchDTO { // аналог CupMatchDTO с флагами лиг
  id: string;
  home: EuroTeamDTO | null; away: EuroTeamDTO | null;
  homeGoals: number | null; awayGoals: number | null;
  homePens: number | null; awayPens: number | null;
  winnerTeamId: string | null; played: boolean; isUserMatch: boolean; isNeutral: boolean;
}
export interface EuroRoundDTO { round: number; label: string; week: number; drawn: boolean; matches: EuroMatchDTO[] }
export interface EuroSnapshotDTO {
  status: 'not_started' | 'qualified' | 'alive' | 'eliminated' | 'winner';
  currentRound: number;
  myEliminatedRound: number | null;
  rounds: EuroRoundDTO[];            // ровно 4
  participants: EuroTeamDTO[];       // 16 (после жеребьёвки 1/8; до — по квалификации)
  quotas: { code: LeagueCode; flag: string; quota: number }[];
  nextEuroMatch: { round: number; label: string; opponent: EuroTeamDTO; week: number; isHome: boolean } | null;
}
export interface EuroResponse { ok: true; euro: EuroSnapshotDTO }
```

### 3.5. Изменения существующих DTO

```ts
// TeamBriefDTO += (заполняется в toTeamBrief — для превью/бейджей):
  coachStyle?: AiStyleCode | null;  // null у клуба игрока
  coachName?: string | null;

// MatchPreviewDTO — без изменений (opponent: TeamBriefDTO уже несёт coachStyle)

// GameSnapshot — БЕЗ новых обязательных полей (евро — лениво через GET /euro);
// fixtures/seasonMatches уже включают матчи competition='euro' (FixtureDTO.competition += 'euro')

// PlayerDTO += euroGoals: number; euroAssists: number;

// PlayerHistoryDTO += euroGoals: number; euroAssists: number;
// CareerTotalsDTO — без изменений (евро-голы входят в totals.goals)

// AwardsResponse.live += topEuroScorers: PlayerLeaderDTO[]; // incl. гости

// WeekResultPayload ( breaking — Блок B обновляет все места чтения ):
//   УДАЛЯЕТСЯ userMatch: UserMatchResultDTO | null
//   ДОБАВЛЯЕТСЯ userMatches: UserMatchResultDTO[];   // 0..2: [кубок?, еврокубок?] в порядке игры
//   ДОБАВЛЯЕТСЯ euroRound: { round: number; label: string; drawn: boolean; pairs: EuroMatchDTO[] } | null;
//   finances += euroPrize (WeekFinancesDTO)
//   seasonEnded += euro: { qualifiedNext: boolean; label: string } | null;
//     // label: 'Чемпион Европы!' | 'Финалист Кубка Европы' | 'Вылет в 1/2 финала' | 'Не квалифицированы' | null
```

### 3.6. Внутренние типы движка (types.ts или match.ts)

```ts
// match.ts:
export interface SubRecord { outId: string; inId: string; minute: number; reason: 'injury' | 'fatigue' | 'chase' | 'defensive' }
export interface MatchResult {
  homeGoals: number; awayGoals: number;
  events: MatchEvent[];
  stats: MatchStats;
  homeStarters: (string | null)[];   // стартовый состав (как сейчас)
  awayStarters: (string | null)[];
  homeSubs: SubRecord[];             // ── Фаза 4
  awaySubs: SubRecord[];
  injuries: MatchInjury[];
}

// MatchTeamInput += (необязательные — обратная совместимость калибровочного скрипта):
export interface MatchTeamInput extends TeamTacticState {
  name: string;
  bench: string[];                                    // ── Фаза 4: до 7 id запасных (обязательное поле у обоих вызовов week.ts)
  coach?: { style: AiStyleCode; plan: MatchPlanDTO }; // ── Фаза 4: отсутствует → balanced + дефолтный AI-план
}
```

`PlayerLike` (players.ts) += `euroGoals: number; euroAssists: number` (сначала поле добавляется в интерфейс и в `playerCreateData`/`generatePlayer` — все места создания).

---

## 4. Чистые модули: coach.ts (новый), match.ts (сегментный движок), euro.ts (новый)

RNG-дисциплина во всех новых модулях — как в существующих: **rng только параметром**, никаких `Math.random`/модульных singleton. Все решения детерминированыseed'ом недели (§4.5).

### 4.1. coach.ts (~260 строк, новый)

```ts
// Сигнатуры экспортов
export interface CoachSideState {
  teamId: string;
  style: AiStyleDef;
  plan: MatchPlanDTO;               // для клуба игрока — из Team.matchPlan; для ИИ — MATCH_PLAN_DEFAULT
  mentality: Mentality;             // текущий менталитет в матче (мутируется решениями)
  tempo: TempoLevel;
  formation: FormationId;
  onField: (string | null)[];       // текущая XI (слоты формации)
  subsUsed: number;
  scored: number; conceded: number; // счёт НА момент контрольной точки
  /** effCond игрока на поле: стартёр = condition − drain×(сыгранные сегменты); вышедший = min(cond,92) − drain×(сегменты после входа) */
  effCondOf(playerId: string): number;
}

export interface SubPlan { outId: string; inId: string; reason: 'fatigue' | 'chase' | 'defensive' }
export interface CoachDecision {
  mentalityShift: number;   // −2..+2 шагов по MENTALITY_ORDER
  tempoLow: boolean;        // сушка (в связке с mentalityShift < 0)
  formationSwitch: FormationId | null; // '3-4-3' при панике (иначе null)
  subs: SubPlan[];
  parkBus: boolean;         // активировать «сушку» λ с этой КТ
  chase: boolean;           // активировать «погоню» λ с этой КТ
}

export function coachDecide(rng: RNG, checkpoint: 46 | 70, side: CoachSideState, oppDefLine: DefLineLevel): CoachDecision;
export function remapForFormation(lineup: (string | null)[], players: PlayerLike[], formation: FormationId): (string | null)[];
export function aiDefaultPlan(): MatchPlanDTO;  // MATCH_PLAN_DEFAULT
```

**FSM: 9 состояний** (research §1.2) = {`winning` | `drawing` | `losing`} × {`mid` (КТ 46) | `late` (КТ 70)} + раннее (сегмент 1 — решений нет). Матрица «состояние → пакет действий по умолчанию»:

| Состояние | mentality | tempo | Замены | λ-режим |
|---|---|---|---|---|
| winning·mid (46) | −1 шаг, если noisy(mentality_down) ≥ 25 | как есть | 0 (усталостные запрещены до 60') | — |
| winning·late (70) | −1..−2 шага | low | 1 defensive | parkBus |
| drawing·mid (46) | как есть | как есть | 0 | — |
| drawing·late (70) | bus: −1 шаг; остальные: как есть | как есть | bus: 1 defensive (если noisy ≥ 40) | bus: parkBus (parkAtDraw) |
| losing·mid (46) | +1..+2 шага | high | 1–2 chase (по порогу) | — |
| losing·late (70) | +2 шага (до allout) | high | 2–3 chase | chase |

**Utility-скоры** (шум ±10 на каждый, броски rng в фиксированном порядке кандидатов: `sub_fatigue → sub_chase → sub_defensive → mentality_up → mentality_down → nothing`; home решает раньше away):

| Кандидат | Скор | Порог |
|---|---|---|
| sub_injury | 100 (форс) — обрабатывается НЕ здесь, а в момент травмы (§4.4 шаг 2) | всегда |
| sub_fatigue | `40 + 60 × (1 − effCond/100)` худшего полевого стартёра (GK только при effCond < 45) | ≥ 55 И минута КТ ≥ SUB_FATIGUE_MINUTE (т.е. только КТ 70) |
| sub_chase | `25 + 12 × |goalDiff| + 15 × (late ? 1 : 0)` при проигрыше | ≥ 40 |
| sub_defensive | `20 + 10 × goalDiff + 15 × (late ? 1 : 0)` при выигрыше | ≥ 40 |
| mentality_up | `15 + 10 × |goalDiff|` при проигрыше (или ничья·late по стилю) | ≥ 25 |
| mentality_down | `15 + 8 × goalDiff + 12 × (late ? 1 : 0)` при выигрыше; **+ style.mentalityDownDrawDelta при ничьей·late** | ≥ 25 |
| tempo_low | +8 в связке к mentality_down (только late) | в связке |
| ничего | `UTILITY_NOTHING = 30` | — |

Правила исполнения:
1. FSM-состояние определяет ПАКЕТ допустимых действий; каждое действие пакета срабатывает, только если его зашумлённый скор ≥ порога («FSM задаёт цель, Utility выбирает, как»).
2. `mentalityShift`: 2 шага при скор ≥ 55, иначе 1 (кламп по MENTALITY_ORDER: не ниже defensive, не выше allout).
3. Замены выбирают игроков: 
   - `sub_fatigue`: out = худший по effCond полевой стартёр; in = лучший по `slotScore` запасной под СЛОТ out (из bench, не травмирован);
   - `sub_chase`: out = полевой стартёр с min effCond из {DEF, DM}; in = лучший запасной группы {AM, ST, MID};
   - `sub_defensive`: out = стартёр группы {AM, ST} с min effCond; in = лучший запасной группы {DEF, DM};
   - один игрок не может быть и out, и in; общий лимит `SUB_MAX − subsUsed`; за одну КТ максимум 3 замены.
4. `formationSwitch = '3-4-3'` — только при КТ 70, если итоговый менталитет после сдвига = `allout` И выполнено ≥ 1 chase-замены (правило «4-2-4» из FM). Применимо к ЛЮБОЙ стороне (и клубу игрока при plan.chaseMode='allout' — формация меняется только внутри матча, Team.formation в БД не трогается).
5. `parkBus` — при winning (и winning|drawing для bus по style.parkAtDraw); `chase` — при проигрыше ≥ 1. Для клуба игрока:
   - `plan.leadMode='hold'` → parkBus = false, mentality_down/defensive-замены пропускаются, tempo_low = false;
   - `plan.chaseMode='steady'` → chase = false, mentality_up/chase-замены/formationSwitch пропускаются;
   - `plan.fatigueSubs=false` → sub_fatigue не выполняется (sub_injury остаётся всегда).
6. Псевдокод:

```
coachDecide(rng, cp, side, oppDefLine):
  diff = side.scored − side.conceded
  state = (diff > 0 ? 'winning' : diff === 0 ? 'drawing' : 'losing') × (cp === 46 ? 'mid' : 'late')
  // броски шума — фиксированный порядок кандидатов
  noise = { fatigue: ±10, chase: ±10, defensive: ±10, mUp: ±10, mDown: ±10, nothing: ±10 }  // по одному rng() на кандидат
  score(x) = base(x) + noise[x]

  decision = { mentalityShift: 0, tempoLow: false, formationSwitch: null, subs: [], parkBus: false, chase: false }

  switch (state):
    case 'winning·mid':
      if score(mentality_down) ≥ 25: shift = score ≥ 55 ? −2 : −1
    case 'winning·late':
      if score(mentality_down) ≥ 25: shift = score ≥ 55 ? −2 : −1; tempoLow = true
      if score(sub_defensive) ≥ 40: subs += defensiveSub()
      parkBus = plan.leadMode === 'park'
    case 'drawing·mid': // пусто
    case 'drawing·late':
      d = score(mentality_down) + style.mentalityDownDrawDelta   // bus +15 → почти всегда сушит; gegenpress −10
      if d ≥ 25: shift = −1; tempoLow = (style.parkAtDraw)
      if style.parkAtDraw && score(sub_defensive) ≥ 40: subs += defensiveSub()
      if style.parkAtDraw: parkBus = (plan.leadMode === 'park')
    case 'losing·mid':
      if score(mentality_up) ≥ 25: shift = score ≥ 55 ? +2 : +1; tempo = 'high'
      if score(sub_chase) ≥ 40: subs += chaseSub()   // ≤ 2
    case 'losing·late':
      if score(mentality_up) ≥ 25: shift = +2 (кламп allout); tempo = 'high'
      if score(sub_chase) ≥ 40: subs += chaseSub() × ≤3 (по остатку слотов)
      chase = (plan.chaseMode === 'allout')
      if итоговый mentality === 'allout' && сделана chase-замена: formationSwitch = '3-4-3'
  clamp mentalityShift к границам MENTALITY_ORDER (shift не выводит за defensive..allout)
  return decision
```

`remapForFormation(lineup, players, formation)`: жадное назначение XI на слоты новой формации по `slotScore` (по убыванию scores, каждый игрок — в один слот; позиционные группы учитываются через positionFit). Чистая функция.

### 4.2. match.ts — сегментный движок (полный псевдокод)

Существующие части, которые НЕ меняются: `buildRuntime`, `isOnField` (расширяется картой замен), `avgAggression`, `scorerWeight`, `processCards`/`processInjuries` (с дельтами стиля — ниже), статистика (формулы те же), рамки ленты kickoff/halftime/fulltime, `simulateAiMatch`/`simulateAiCupMatch` (только новая goalMinute-логика). УДАЛЯЕТСЯ: `goalMinute(rng)` (заменена сегментами).

```
// ── Вспомогательные структуры ──
TeamRuntime += {
  bench: PlayerLike[];                 // разпарсенный bench (только не травмированные)
  subOutAt: Map<playerId, minute>;     // минута схода (замена)
  subInAt:  Map<playerId, minute>;     // минута входа
  subsUsed: number;
  sentOff / injuredAt / yellowCount / events — как сейчас
}

isOnField(t, p, minute):
  red/injury как сейчас; subOutAt.get(p) ≤ minute → false; иначе true

// Виртуальное состояние сегмента k (0..2) для applyModifiers:
segmentStateOf(rt, k):
  lineup = текущая XI (после замен, сделанных до начала сегмента k)
  players = клон каждого игрока на поле:
    стартёр:  condition_eff = max(COND_EFF_FLOOR, p.condition − (PER_SEGMENT_COND_DRAIN + style.condDrainPerSegment) × k)
    вышедший (в сегменте j ≤ k): condition_eff = max(COND_EFF_FLOOR, min(p.condition, SUB_IN_CONDITION_CAP)
                          − (PER_SEGMENT_COND_DRAIN + style.condDrainPerSegment) × (k − j))
  mentality/tempo/formation — текущие (после решений КТ)
  → TeamTacticState (тот же интерфейс, что и тактика клиента)

// ── Время-взвешенный множитель (ЕДИНЫЙ механизм) ──
segFactor(eventMinute, k, mul):
  [s, e] = границы сегмента k (1..45 / 46..70 / 71..93)
  if eventMinute ≥ e: return 1            // событие позже сегмента — не влияет
  w = clamp((e − max(eventMinute, s)) / (e − s + 1), 0, 1)  // доля сегмента ПОСЛЕ события
  return 1 − w + w × mul

// ── Главный цикл simulateMatch(rng, home, away, opts) ──
styleH = AI_STYLES[home.coach?.style ?? 'balanced'];  planH = home.coach?.plan ?? MATCH_PLAN_DEFAULT
styleA = ...; planA = ...
rtH = buildRuntime(home); rtA = buildRuntime(away); injuries = []

// 1. Карточки и травмы — на ВЕСЬ матч вперёд (порядок RNG: home → away)
processCards(rng, rtH, styleH)   // λ ЖК = YELLOW_LAMBDA_BASE + aggr/200 + pressingBonus
                                 //        + styleH.yellowLambdaBonus
                                 //        + (away.pressing === 'high' ? styleH.yellowVsPressingHigh : 0)
processCards(rng, rtA, styleA)   // симметрично (жёлтые соперника при home.pressing high)
processInjuries(rng, rtH, injuries, styleH)  // INJURY_PROB × style.injuryProbMult(при avgCond стартёров < 65)
processInjuries(rng, rtA, injuries, styleA)

// 2. Вынужденные замены при травмах (порядок: травмы home по минуте, затем away)
for t in [rtH, rtA]: for inj in sorted(t.injuredAt) by minute:
  if t.subsUsed < SUB_MAX и есть подходящий (не травмированный, не игравший) запасной:
    in = лучший по slotScore под СЛОТ травмированного
    subEvent(minute = inj.minute, out = victim, in, reason='injury', шаблон SUB_TEMPLATES[вынужденная])
    t.subOutAt[victim] = inj.minute; t.subInAt[in.id] = inj.minute; t.subsUsed++
    lineup слота victim := in.id   // входит в состав С этого момента (авторы голов — да; λ — со следующего сегмента)
  else:
    shortHanded[t.teamId].push(inj.minute)  // дефицит: λ ×0.93 к оставшемуся времени

// 3. Цикл сегментов
scoreH = 0; scoreA = 0
mentH = home.mentality; tempoH = home.tempo; formH = home.formation   // и для away
parkH = {active: false, minute: 93}; chaseH = {...}; parkA; chaseA    // режимы λ

for k in 0..2:
  // 3а. Контрольные точки (ПЕРЕД сегментами 2 и 3)
  if k === 1 || k === 2:
    cp = (k === 1 ? 46 : 70)
    decH = coachDecide(rng, cp, sideStateH(diff=scoreH−scoreA), away.defLine)   // home решает ПЕРВЫМ
    decA = coachDecide(rng, cp, sideStateA(diff=scoreA−scoreH), formH-defLine-текущий)
    for (rt, dec) in [(rtH, decH), (rtA, decA)]:   // применение: сначала home
      применить mentalityShift/tempoLow/formationSwitch (formation → remapForFormation к текущей XI;
        косметическое событие type='chance', text из FORMATION_SHIFT_TEMPLATES)
      исполнить dec.subs: subEvent(minute = cp, ...), обновить subOutAt/subInAt/lineup/subsUsed
      if dec.parkBus: park[rt].active = true; park[rt].minute = style.parkBusMinute
      if dec.chase:   chase[rt].active = true; chase[rt].minute = style.chaseMinute

  // 3б. λ сегмента
  mods = applyModifiers(segmentStateOf(rtH, k), segmentStateOf(rtA, k), opts)
  // стиль-дельты (research §2.2 — только уникальные, тактические уже в полях):
  atkH = mods.home.effAtk × styleH.atk × (styleH.verticalVsHighLine && awayDefLine === 'high' ? 1.05 : 1)
  defH = mods.home.effDef × styleH.def
  atkA = mods.away.effAtk × styleA.atk × (styleA.verticalVsHighLine && homeDefLine === 'high' ? 1.05 : 1)
  defA = mods.away.effDef × styleA.def
  // awayDefLine/homeDefLine — ТЕКУЩИЕ defLine сторон в матче (после сдвигов — сдвигов defLine нет, берутся из входа)

  λFullH = clamp(BASE_GOALS × atkH / defA, LAMBDA_MIN, LAMBDA_MAX)
  λFullA = clamp(BASE_GOALS × atkA / defH, LAMBDA_MIN, LAMBDA_MAX)

  // факторы сегмента (все — время-взвешенные):
  fH = SEGMENT_SHARES[k]; fA = SEGMENT_SHARES[k]
  for m in rtH.sentOff.values():            // красные home
    (selfMul, oppMul) = redMulOf(m)          // ≤45 → (0.55, 1.30); 46–70 → (0.70, 1.15); 71+ → (1, 1)
    fH ×= segFactor(m, k, selfMul); fA ×= segFactor(m, k, oppMul)
  for m in rtA.sentOff.values(): симметрично
  for m in shortHandedHome:  fH ×= segFactor(m, k, SHORT_HANDED_LAMBDA_MOD)
  for m in shortHandedAway:  fA ×= segFactor(m, k, SHORT_HANDED_LAMBDA_MOD)
  if parkH.active:  fH ×= segFactor(parkH.minute, k, PARKING_BUS_MOD.self); fA ×= segFactor(parkH.minute, k, PARKING_BUS_MOD.opp)
  if parkA.active:  fA ×= segFactor(parkA.minute, k, PARKING_BUS_MOD.self); fH ×= segFactor(parkA.minute, k, PARKING_BUS_MOD.opp)
  if chaseH.active: fH ×= segFactor(chaseH.minute, k, CHASE_MOD.self);      fA ×= segFactor(chaseH.minute, k, CHASE_MOD.opp)
  if chaseA.active: fA ×= segFactor(chaseA.minute, k, CHASE_MOD.self);      fH ×= segFactor(chaseA.minute, k, CHASE_MOD.opp)
  // ВАЖНО: park/chase активируются только если РЕЖИМ ЕЩЁ ДЕЙСТВУЕТ (счёт не поменялся в обратную сторону —
  // режим пересчитывается на каждой КТ; голы внутри сегмента режим НЕ сбрасывают до следующей КТ)

  λH = clamp(λFullH × fH, 0, LAMBDA_MAX); λA = clamp(λFullA × fA, 0, LAMBDA_MAX)

  // 3в. Голы сегмента (порядок RNG: home → away; в рамках команды — по порядку сэмплов)
  goalsH = samplePoisson(rng, λH); goalsA = samplePoisson(rng, λA)
  для каждого гола: minute = randInt(rng, segStart, segEnd)
    pool = on-field игроки на minute (isOnField учитывает red/injury/subOut/subIn)
    автор = pickWeighted(scorerWeight); ассист p=0.5 (pickWeighted по passing, как сейчас)
    scoreH/scoreA обновляются СРАЗУ (влияет на решения следующей КТ)
  // «опасные моменты»: count = round((shotsBase − goals − 2) × 0.5 × TEMPO_CHANCE_MOD[tempo] × style.chanceCountMult)
  // shotsBase = clamp(round(4 + λFull×7), 3, 25) — считается по ΣλFull в §3е
  chances аналогично голам: minute = randInt(rng, segStart, segEnd), автор из pool

// 3е. Статистика (в конце):
shotsH = clamp(round(4 + (λFullH_1 + λFullH_2 + λFullH_3) × 7) + styleH.shotsBonus, 3, 25)  // и для away
sotH = max(goalsH, round(shotsH × (0.35 + rng()×0.2 + styleH.sotShareDelta)))
possessionHome = clamp(round(50 + 1.2 × (mods1.home.effMid × styleH.midDelta − mods1.away.effMid × styleA.midDelta)) + styleH.possessionBonus − styleA.possessionBonus, 25, 75)
  // mods1 — модификаторы СЕГМЕНТА 1 (до сдвигов); fouls/corners/yellows/reds — как сейчас

// 4. Рамки ленты + сортировка (stable) по (minute, TYPE_ORDER) — sub имеет order 1 и push'ится раньше голов той же минуты
return { homeGoals: scoreH, awayGoals: scoreA, events, stats, homeStarters, awayStarters, homeSubs, awaySubs, injuries }
```

**Порядок RNG (детерминизм, зафиксирован)**: cards home → cards away → injuries home → injuries away → forced injury subs (home по минутам, затем away) → [сегмент 1: goals home → goals away → chances home → chances away] → КТ46 (coachDecide home → coachDecide away; внутри каждого — 6 бросков шума фиксированного порядка; исполнение замен home → away) → [сегмент 2 …] → КТ70 … → [сегмент 3 …] → статистика (sot home → sot away, fouls home → away). Один и тот же seed → байт-в-байт одинаковый events JSON.

**Инвариант линейности**: при отключённых решениях (все скоры «ничего») Σ λ_сегментов = λ_старого_движка ± 0.01 — SEGMENT_SHARES строго суммируются в 1.00, стили balanced, красные/парковки/погони не активны (§9.2).

**simulateAiMatch / simulateAiCupMatch** (ИИ-матчи): Пуассон остаётся ОДНОсэмпльным; минуты голов — новая `segmentGoalMinute(rng)`:
```
roll = rng()
roll < 0.42 → randInt(1..45); roll < 0.70 → randInt(46..70); иначе randInt(71..93)
```
Тактический ИИ на ИИ-матчи НЕ распространяется (распределение исходов то же; экономия ~15×/тур — research §1.4).

### 4.3. data.ts — новые шаблоны

```ts
export const SUB_TEMPLATES: string[] = [   // {player} = вышел, {out} = сошёл (research §1.6)
  'Замена: {player} выходит вместо {out} — свежие ноги в атаку.',
  'Замена: {player} вместо {out}. Тактическое усиление обороны.',
  '{out} выдохся — его меняет {player}.',
  '{out} получает аплодисменты трибун, на поле — {player}.',
  'Вынужденная замена: {out} не может продолжать, играет {player}.',
  'Ход тренера: {player} вступает в игру вместо {out}.',
];
export const FORMATION_SHIFT_TEMPLATES: string[] = [
  'Тренер {team} перестраивается в 3-4-3 — тотальная атака!',
  '{team} бросает вперёд всех — схема 3-4-3!',
];
```

### 4.4. progression.ts — разрезка applyPostMatch (per-match / per-week)

```ts
// НОВАЯ структура (вход — с заменами):
export interface PostMatchTeam {
  players: PlayerLike[];
  starterIds: Set<string>;
  benchIds: Set<string>;
  events: MatchEvent[];
  outcome: 'W' | 'D' | 'L';
  tempo: TempoLevel;
  pressing: PressingLevel;
  competition: 'league' | 'cup' | 'euro';   // euro: голы дублируются в euroGoals/euroAssists
  goalsConceded: number | null;
  subs: SubRecord[];                          // ── Фаза 4 (замены матча)
}

// per-match: БЕЗ recovery (+8 убран!)
export function applyPostMatch(team: PostMatchTeam, injuries: Map<string, number>, ratingRng: RNG): void
// per-week: ровно один раз на команду, сыгравшую ≥1 матч в неделе
export function applyWeeklyRecovery(players: PlayerLike[]): void
  // for p: p.condition = clamp(p.condition + CONDITION_WEEKLY_RECOVERY, CONDITION_MIN, CONDITION_MAX)
```

Логика applyPostMatch (полный порядок, мутации на месте):

```
minutesPlayed(playerId):
  стартёр: subOutAt ? subOutMinute : (sentOff|injuredAt ? их минута : 90)   // минута схода
  вышедший: 90 − subInMinute
  не игравший: 0
для каждого p из team.players:
  played = minutesPlayed(p.id) > 0
  if played:
    drain = max(CONDITION_DRAIN_MIN, CONDITION_DRAIN_BASE − p.stamina/12)
            + tempo/pressing поправки (как сейчас)
    p.condition = clamp(p.condition − drain × minutesPlayed(p.id)/90, MIN, MAX)   // ── доля минут
    p.apps += 1
    p.ratingSum += computeMatchRating(...); p.ratingApps += 1      // рейтинг — ВСЕМ игравшим (вышедшим тоже)
  else if benchIds.has(p.id):
    p.condition = clamp(p.condition + CONDITION_BENCH_GAIN, MIN, MAX)
  // recovery +8 ЗДЕСЬ НЕ применяется — переносится в applyWeeklyRecovery
  мораль: played → полная дельта outcome; bench unused → половина (MORALE_BENCH_RATIO)
  статистика из событий (goals/assists/yellows/reds + euroGoals/euroAssists при competition='euro')
  травмы из injuries (как сейчас)
cleanSheet (вне applyPostMatch, в week.ts): GK, ЗАВЕРШИВШИЙ матч в рамке (id на слоте 0 на 90-й) и
  minutesPlayed ≥ 30 и команда пропустила 0 → gk.cleanSheets += 1
```

### 4.5. euro.ts (~300 строк, новый) — сигнатуры и алгоритмы

```ts
export function euroWeeksOf(teamCount: number): number[];            // EURO_WEEKS + fallback cupWeeksOf.slice(-4)
export function euroRoundAt(plan: SeasonPlan, week: number): number | null; // 1..4 | null (неделя не евровая)
export function euroRoundLabel(round: number): string;

/** Квалификация: своя лига — standings/сила; другие — сила + шум. Возвращает 16 id В ПОРЯДКЕ посева. */
export function euroParticipants(args: {
  ownLeague: LeagueCode;
  leagueTeams: { id: string; strength: number; place: number | null }[]; // place = финальная таблица (null = сезон 1)
  rng: RNG;   // seed: `${saveId}:euroqual:${season}` (переход) / `:euroqual:${season}:lazy` (сезон 1)
}): { teamIds: string[]; guestSeeds: { leagueCode: LeagueCode; clubIndex: number; strength: number }[] };
// Алгоритм:
//  1) своя лига: top-q по place (или по strength при place=null)
//  2) каждая другая лига L: sort(clubs of L by str + gauss(rng, 0, EURO_QUAL_NOISE)) → top-q_L
//     (клубы своей лиги из LEAGUES НЕ участвуют — их квота закрыта своими Team сейва)
//  3) вернуть 16 id (свои id + guestSeeds для несуществующих гостей)

/** Жеребьёвка раунда: посев по силе, «сильные в разные пары», РАЗНЫЕ лиги в 1/8 (research §3.7-3). */
export function drawEuroRound(rng: RNG, alive: { id: string; strength: number; leagueCode: string }[], isFinal: boolean): CupPair[];
// Алгоритм:
//  1) seedStrength = strength + gauss(rng, 0, 3); сортировка desc → порядок посева 1..2n
//  2) жадно: сильнейший непарный → слабейший непарный ИЗ ДРУГОЙ ЛИГИ (round 1; раунды 2+ — без ограничения лиг)
//  3) «слабый дома» с p = EURO_WEAK_HOME_PROB (0.7); финал: isNeutral = true, «дом» — монетка
//  Инвариант: пары одной лиги в 1/8 невозможны (у каждой лиги ≤3 участника из 16)

/** Гостевые клубы: чистая генерация POJO (запись в БД — в week.ts). */
export interface EuroGuestTeam {
  leagueCode: LeagueCode; clubIndex: number;
  team: { name; shortName; city; colorPrimary; colorSecondary; strength; stadiumCapacity;
          aiStyle: AiStyleCode; aiCoachName: string; leagueCode: LeagueCode; isEuroGuest: true;
          formation; mentality; tempo; pressing; defLine; playStyle };  // из AI_STYLES[aiStyle].tactic
  players: PlayerLike[];   // generateSquad(rng, strength, poolContextOf(def)); contractUntil = 99
}
export function buildEuroGuests(rng: RNG, seeds: { leagueCode: LeagueCode; clubIndex: number }[]): EuroGuestTeam[];
// rng seed: `${saveId}:euroguests:${season}`; aiStyle = assignAiStyle(rng, strength, leagueCode);
// aiCoachName = `${pick(first)} ${pick(last)}` из NAME_POOLS[def.basePool]

/** Призовые события клуба игрока. */
export function euroPrizeFor(args: { round: number; won: boolean; isFinal: boolean }): number;
// участие €2M (кредитуется один раз в неделю 1/8 при квалификации);
// победа в раунде r (r=1..3): EURO_PRIZE_ROUND[r-1]; финал: won ? EURO_PRIZE_CHAMPION : EURO_PRIZE_FINALIST

/** Сериализация состояния. */
export function parseEuroTeamIds(raw: string | null | undefined): string[];   // как parseTeamIdList
export function serializeEuroTeamIds(ids: string[]): string;
```

**Смена стилей в переходе** (вызывается из week.ts, чистая часть в coach.ts или euro.ts — разместить в `coach.ts`):

```ts
export function aiStyleChangesFor(rng: RNG, teams: { id: string; strength: number; aiStyle: AiStyleCode }[]):
  { teamId: string; nextStyle: AiStyleCode; renameCoach: boolean }[];
// 1) ранг по strength desc; топ-AI_STYLE_TOP_RANK (6) → p=AI_STYLE_CHANGE_TOP_P, остальные p=AI_STYLE_CHANGE_P
// 2) при смене: новый стиль = assignAiStyle(rng, strength, leagueCode), НО ≠ текущий (переброс при совпадении)
// 3) renameCoach = rng() < AI_COACH_RENAME_P
// rng seed: `${saveId}:stylechg:${season}`
```

**Ленивое угадывание стиля легаси-Team** (первая simulateWeek после апгрейда):

```ts
export function guessAiStyle(t: { formation: string; mentality: string; tempo: string; pressing: string; playStyle: string }): AiStyleCode;
// '5-3-2'|'4-5-1' + mentality 'defensive'            → 'bus'
// '4-3-3' + 'attacking' + pressing 'high'            → 'gegenpress'
// '4-2-3-1' + playStyle 'passing'                    → 'tikitaka'
// '4-2-3-1'|'4-4-2' + playStyle 'counter'            → 'vertical'
// иначе → 'balanced'
```

---

## 5. Интеграция в week.ts (пайплайн недели и сезонный переход)

### 5.1. Календарь евро — ТОЧНАЯ раскладка по размерам лиг

Проверка арифметики: `totalWeeks = leagueWeeks + cupRounds` — **свободных недель нет ни в одном размере**; вариант «отдельные недели евро» требует +4 недели (вариант D research — отклонён). Еврораунды ставятся на кубковые недели:

| Лига (N) | leagueWeeks | CUP_WEEKS (раунды кубка 1..R) | EURO_WEEKS (1/8 · 1/4 · 1/2 · Финал) | totalWeeks |
|---|---|---|---|---|
| RPL (16) | 30 | 8, 16, 24, 34 (4 раунда) | **8 · 16 · 24 · 34** | 34 |
| BUN/FL1 (18) | 34 | 7, 15, 24, 32, 39 (5: предварит. + 4) | **15 · 24 · 32 · 39** | 39 |
| EPL/LAL/SEA (20) | 38 | 8, 16, 26, 35, 43 (5: предварит. + 4) | **16 · 26 · 35 · 43** | 43 |

Правила:
- Для N=18/20 еврораунды пропускают кубковую неделю 1 (предварительный раунд, где играют только 4/8 слабейших клубов лиги) — евроклубы отдыхают.
- Еврофинал всегда на ПОСЛЕДНЕЙ неделе вместе с финалом национального кубка («двойной финал» возможен — допускаем, research §3.2).
- **Congestion — явно**: клуб, живой в обоих турнирах, играет 2 матча в евронеделю (макс. за сезон: 4 таких недели; всего матчей до 47 при N=20).
- `buildSeasonPlan` НЕ меняется; EURO_WEEKS — отдельная константа (§2.4), читается через `euroRoundAt(plan, week)`.

### 5.2. Недельный пайплайн simulateWeek — полный порядок Фазы 4

Изменения относительно текущего порядка — помечены **[P4]**.

```
0.  Загрузка: save, teams = db.team.findMany({ saveId, isEuroGuest: false })   [P4] фильтр
    guestTeams = db.team.findMany({ saveId, isEuroGuest: true }) (0 строк до первого евро)
    playerRows = db.player.findMany({ saveId, teamId: { not: null } }) — ВКЛЮЧАЯ гостей (дифф пишет их изменения)
    originals, ленивые миграции P3 (контракты/правление)
0b. [P4] Ленивая миграция стилей: для каждой лиговой Team с aiCoachName === null:
    style = guessAiStyle(team); aiStyle = style; aiCoachName = имя из пула лиги;
    ops += db.team.update (дифф команд — см. §5.7); НОВЫЕ сейвы пропускают (имя уже не null)
0c. [P4] weekMatches — как сейчас (включает scheduled евро-матчи прошлых жеребьёвок)
1.  ctxs — ТОЛЬКО лиговые команды (см. 0); user lineup/bench — как сейчас;
    [P4] у клуба игрока план: parseMatchPlan(team.matchPlan) (в контекст, в tacticInputOf)
2.  ВЕТКА недели:
    А. ЛИГОВАЯ (slot.type === 'league') — как сейчас, но:
       - tacticInputOf(ctx) теперь кладёт coach { style: coerceAiStyle(team.aiStyle), plan } и bench
         (для клуба игрока style = 'balanced', plan из Team.matchPlan; для ИИ plan = aiDefaultPlan())
       - simulateMatch — сегментный (§4.2)
       - applyPostMatch: перерисован (§4.4), вызывается с userResult.homeSubs/awaySubs
       - [P4] ПОСЛЕ цикла пост-матча: applyWeeklyRecovery(ctx.players) для ВСЕХ команд (лиговая неделя — все играли)
    Б. КУБКОВАЯ + [P4] ЕВРО (slot.type === 'cup'):
       1) НАЦИОНАЛЬНЫЙ КУБОК — весь существующий код без изменений (жеребьёвка, матч клуба игрока
          полным движком, ИИ-матчи, пост-матч участников, мораль раунда, отдых НЕучастников
          [P4] отдых — только командам БЕЗ матчей за неделю: !cupParticipants && !euroParticipants)
       2) [P4] ЕВРОРАУНД r = euroRoundAt(plan, week) (null → пропустить блок):
          a. Инициализация состояния (один раз на сезон):
             if save.euroSeason !== season:
               if r === 1:  // ленивая точка входа (сезон 1 / легаси)
                 qualify = euroParticipants({ ownLeague, leagueTeams (place=null → по силе), rng(seed `:euroqual:${season}:lazy`) })
                 guestsToCreate = qualify.guestSeeds
                 ops += создание Team (isEuroGuest, leagueCode, aiStyle, aiCoachName, тактика стиля) и Player
                        (generateSquad через buildEuroGuests; ~280 строк; contractUntil=99)
                 saveUpdates += { euroSeason: season, euroRound: 0, euroParticipants: JSON(16),
                                  euroAliveTeamIds: JSON(16) }
                 новость 'euro': «Жеребьёвка Кубка Европы: {N} клубов, {список первых пар}»
                 (квалификация своей лиги по силе; участие клуба игрока → новость)
               else: БЛОК ПРОПУСКАЕТСЯ (недели 1/8 уже прошли — евро начнётся с перехода)
          b. Пары раунда: scheduled из БД (existingEuro = weekMatches competition='euro' AND cupRound=r)
             или жеребьёвка drawEuroRound(rng(seed `${saveId}:eurodraw:${season}:${r}`), alive, isFinal)
             alive = parseEuroTeamIds(save.euroAliveTeamIds)
          c. Контексты участников: для лиговых клубов — ctxs.get(id) С ПЕРЕСБОРКОЙ состава
             (если клуб играл кубковый матч этой же неделей: lineup = autoLineup(ctx.players, formation, true, EURO_ROTATE_COND));
             для гостей — euroCtx: { team, players (из playerRows), lineup: autoLineup(...), bench: auto.bench,
             aiStyle: team.aiStyle } (строятся лениво в этом блоке)
          d. ПОРЯДОК МАТЧЕЙ НЕДЕЛИ: национальный кубок УЖЕ сыгран (шаг 1) — евроматчи вторые
             (состояния составов после кубкового матча: drain уже применён к ctx.players)
          e. Евроматч клуба игрока (если клуб в парах): ПОЛНЫЙ движок simulateMatch с coach-входами
             (соперник-гость: tacticInputOf(euroCtx)); ничья → simulatePenaltyShootout (как кубок);
             userMatches.push(dto) — ВТОРОЙ элемент (первый — кубковый, если был)
             призовые euroPrizeFor; новости 'result'/'euro'
          f. ИИ-евроматчи остальных пар: simulateAiCupMatch (гости vs лиговые — strength+players)
          g. Пост-матч участников: applyPostMatch (per-match; competition='euro'; subs для полного движка;
             для ИИ-матчей subs=[] — apps стартёрам, события только голы) + мораль раунда
             (CUP_MORALE_WIN/OUT — победа раунда +5 / вылет −5)
          h. Победители → новое euroAliveTeamIds; если r < 4: scheduledCreates += матчи раунда r+1
             (неделя EURO_WEEKS[r], isNeutral = (r+1 === 4)); если r === 4: чемпион — новость 'euro'
       3) [P4] Отдых недели: applyWeeklyRecovery — участникам (кубка и/или евро);
          полный отдых +10/+2 — только командам без матчей
    В. [P4] Гости каждую неделю (не только евровую, если euroSeason !== null):
       for guestTeam: for p of его players: p.condition = clamp(+CONDITION_WEEKLY_RECOVERY)  (+8, как всем)
       (гости НЕ тренируются фокусами — trainingFocus='rest' не вызывается; их развитие — только
        сезонное старение/реген; мораль не трогается вне евроматчей)
3.  ТРЕНИРОВКИ — только ctxs (лиговые команды), как сейчас (гости исключены автоматически)
4.  Декремент давних травм — по ВСЕМ playerRows (включая гостей) [P4] расширение множества
5.  Финансы клуба игрока — как сейчас + [P4] euroPrize (категория 'euro_prize', как cupPrize)
6.  ПРАВЛЕНИЕ [P4]: boardMatchInputs: BoardMatchInput[] (1..2 — кубковый, затем еврокый; в лиговую
    неделю — 1); weeklyBoardUpdate РАЗРЕЗАН (board.ts §5.8): на каждый матч — матчевые дельты
    (win/draw/loss ± раунд/финал/обидный вылет, для евро upset −4), затем ОДИН раз недельные
    (темп/финансы/гармония/honeymoon)
7.  Рынок — без изменений кода (budgets/purchases только из ctxs — гости не покупают)
8.  Босман — клуб игрока (как сейчас; leagueTeams — без гостей)
9.  Академия (неделя 4) — только ctxs (гости исключены)
10. [P4] Сезонный переход — см. §5.6
11. Запись в БД: one transaction; playedMatchOps пишет competition='euro' + cupRound=r
    (переиспользование поля); scheduledCreates евро — competition='euro'
12. Ответ: userMatches[] (0..2), weekResults (вкл. евро), euroRound (пары следующего раунда — DTO),
    finances.euroPrize, board, sacked, seasonEnded(+euro)
```

### 5.3. Ленивая инициализация евро — правила

- Точка входа А (сезон 1 / новая карьера): неделя 1/8 (EURO_WEEKS[0]), `save.euroSeason !== season` → инициализация по силе (своя лига — топ-q по Team.strength; другие — по ClubSeed.str + шум). Гости создаются здесь (~13–14 Team + ~280 Player в транзакции недели).
- Точка входа Б (сезоны 2+): сезонный переход всегда вычисляет участников СЛЕДУЮЩЕГО сезона и создаёт недостающих гостей (обычно 0–1 новый клуб: состав других лиг почти стабилен, но шум gauss(0,3) иногда продвигает 4–5-й клуб лиги).
- Легаси-сейв в середине сезона (неделя 1/8 уже прошла): евро пропускается до перехода (правило «инициализация только на r=1»).
- `save.euroParticipants` хранит 16 id сезона; `euroAliveTeamIds` — живых (после каждого раунда); `euroRound` — последний сыгранный (0..4).

### 5.4. Ленивая миграция стилей легаси

Первая simulateWeek после деплоя Фазы 4 (маркер: `aiCoachName === null` у ИИ-Team): `guessAiStyle` по текущим тактическим полям → `db.team.update({ aiStyle, aiCoachName })` (ops в общую транзакцию). Тактические поля НЕ перезаписываются (нулевое влияние на баланс живых сейвов). Новые сейвы получают стили при генерации (generateLeague, §5.9).

### 5.5. Гости: полный список мест изоляции

| Место | Действие |
|---|---|
| week.ts: запрос teams | `isEuroGuest: false` — все существующие циклы (ctxs/кубок/рынок/босман/академия/переход) работают только с лиговыми |
| week.ts: контексты евро | отдельная карта euroCtx (гости + пересборка лиговых участников) — §5.2 Б.2.c |
| snapshot.ts buildSnapshot | teams-запрос `isEuroGuest: false`; standings/fixtures-команды без гостей; liveLeaders — игроки только лиговых Team (гости не попадают в бомбардиров ЛИГИ; их евро-голы — в topEuroScorers) |
| api-helpers.ts buildSaveCard | teams-запрос `isEuroGuest: false` (место/форма карьеры — только лига) |
| transitions (§5.6) | гости обрабатываются отдельным шагом (старение/реген/записи) — не в цикле контрактов/академии |
| GET /awards live | topScorers/topAssists/topCupScorers — только лиговые; topEuroScorers — все (вкл. гостей) |
| Кубок: жеребьёвка | участники — только ctxs (лиговые) — фильтр автоматический |

### 5.6. Сезонный переход buildSeasonTransition — порядок Фазы 4

Текущий порядок Фазы 3 сохраняется; вставки помечены **[P4]**:

```
1.  Финальная таблица / призовые место
2.  Награды (только лиговые клубы — гости не в ctxs)        [P4] автоматически
3.  СНАПШОТ ИСТОРИИ: buildSeasonRecords({ squadPlayers: лиговые + [P4] ГОСТИ, freeAgents })
    записи гостей: teamId = их Team.id, teamName = имя клуба; поля += euroGoals/euroAssists
4.  Вердикт правления (как Фаза 3)
5.  Контракты: 5a Босман → 5b ИИ-продления → 5c истечения → 5d дренаж (CONTRACT_DRAIN_AGE=30/OVR=60)
    — только ctxs [P4] автоматически; гости не участвуют
6.  [P4] ГОСТИ: собственный шаг:
    - age += 1, applySeasonProgression(rng, guestPlayers) — развитие/пенсии/сброс статов
    - РЕГЕН: за каждого ушедшего — generatePlayer(rng, teamStrength ± 3 gauss, широкая группа позиции
      ушедшего, fixedAge 18–23, pool лиги гостя, contractUntil=99) — состав гостей вечен ~20–22
    - инвариант EURO_GUEST_MIN_SQUAD = 18
6b. Пополнение составов ИИ свободными агентами (Фаза 3) — только ctxs
7.  [P4] СМЕНА СТИЛЕЙ: aiStyleChangesFor(rng(seed `:stylechg:${season}`), лиговые ИИ-Team)
    → для каждой смены: aiStyle = новый, тактические поля = AI_STYLES[new].tactic,
    p=0.15 новое aiCoachName; ops += db.team.update
8.  [P4] ЕВРО следующего сезона:
    - qualify = euroParticipants({ ownLeague, leagueTeams с place = финальная таблица, rng(seed `:euroqual:${season+1}`) })
    - создать недостающих гостей (обычно 0–1 клуба; buildEuroGuests)
    - saveUpdates += { euroSeason: season+1, euroRound: 0, euroParticipants: JSON, euroAliveTeamIds: JSON }
    - новости 'euro': «Кубок Европы: {клуб} квалифицировался!» (если пользователь); список участников
9.  Новый календарь лиги / рынок / призы / новости — как сейчас
10. GameSave.update: + euro-поля (сброс при переходе — евро новое состояние сезона N+1)
```

### 5.7. Диффы игроков/команд в week.ts

- `DYNAMIC_FIELDS` += `'euroGoals', 'euroAssists'` (еженедельные изменения гостей и евроклубов пишутся диффом).
- Изменения Team (стили/план/смена в переходе) пишутся явными `db.team.update` ops (не диффом — Team меняется редко).
- `PlayedMatch`/`playedMatchOps`: `competition: 'league' | 'cup' | 'euro'`; `cupRound` несёт номер еврораунда для competition='euro'.

### 5.8. board.ts — разрезка weeklyBoardUpdate

```ts
// НОВОЕ (экспорт):
export function boardMatchDeltaOf(m: BoardMatchInput, styleEuro: boolean): { delta: number; notes: string[] }
// матчевые дельты текущей weeklyBoardUpdate (W/D/L по разнице сил + надбавки раунда/финала/обидного вылета;
// для евро: BOARD_DELTA_EURO_UPSET_LOSS=−4 вместо кубкового −3; BoardMatchInput.competition: 'league'|'cup'|'euro')

export function boardWeeklyExtras(args: Omit<BoardWeeklyInput, 'match'>): { delta: number; notes: string[] }
// темп (week % 4), финансы, гармония — ОДИН раз в неделю

export function weeklyBoardUpdate(args: BoardWeeklyInput & { matches?: BoardMatchInput[] }): BoardUpdate
// сохранена для одиночных недель; week.ts Фазы 4 вызывает: matches.forEach(m => apply boardMatchDeltaOf)
// затем boardWeeklyExtras + honeymoon + clamp — итог идентичен Фазе 3 при одном матче
```

### 5.9. generate.ts — назначение стилей и гости

- `aiTactic(strength, rng)` УДАЛЯЕТСЯ. Замена:
```ts
export function assignAiStyle(rng: RNG, strength: number, leagueCode: LeagueCode): AiStyleCode {
  if (AI_STYLE_LEAGUE_BIAS[leagueCode] && rng() < AI_STYLE_LEAGUE_BIAS_P) return AI_STYLE_LEAGUE_BIAS[leagueCode];
  const band = strength >= 84 ? 'top' : strength >= 74 ? 'mid' : 'low';
  // pickWeighted по AI_STYLE_ASSIGN[band]
}
```
- `TeamGen` += `aiStyle: AiStyleCode; aiCoachName: string; leagueCode: LeagueCode;`; generateLeague: `tactic = AI_STYLES[assignAiStyle(rng, club.str, def.code)].tactic`; `aiCoachName` — имя из NAME_POOLS[def.basePool].
- POST /saves: в `team.create` data += `aiStyle/aiCoachName/leagueCode` (isEuroGuest/matchPlan — дефолты).

### 5.10. players.ts / snapshot.ts — точечные правки

- `PlayerLike` += euroGoals/euroAssists; `generatePlayer`/`playerCreateData` — поля (0).
- `autoLineup(squad, formation, rotate = true, rotateBelow = 55)` — параметр порога ротации (евронедели ИИ: 65, см. §5.2 Б.2.c).
- `snapshot.ts`: toTeamBrief += coachStyle/coachName (coerceAiStyle; null-скрытие для клуба игрока); weekFixturesRows — евроматчи недели включаются (buildFixture: `competition === 'euro' ? 'euro' : competition === 'cup' ? 'cup' : 'league'`); сортировка fixtures в JS: `(m.competition === 'euro' ? 1 : 0), id asc` (кубковый матч недели — раньше евро); buildWeekInfo label += `' · Кубок Европы'` iff `save.euroSeason === season && euroRoundAt(plan, week) !== null`.
- buildSnapshot teams/leaders — фильтр `isEuroGuest: false` (§5.5).

---

## 6. API-контракты

Стиль — в точности как Фаза 2/3: `{ ok: true, ... }` / `{ ok: false, error }`, zod-валидация тела, `resolveSave`/`resolvePlayingSave`, `normalizeErrorCode` в catch. Легаси-фолбэк без saveId сохраняется для GET-роутов.

### 6.1. Новые эндпоинты (3)

**GET /api/game/matchplan?saveId=** → `MatchPlanResponse`

```ts
{ ok: true, plan: { leadMode: 'park'|'hold', chaseMode: 'allout'|'steady', fatigueSubs: boolean } }
```
Логика: `resolvePlayingSave` → Team клуба игрока → `parseMatchPlan(team.matchPlan)` (null → дефолт). finished-сейвы — 404 (resolvePlayingSave).

**POST /api/game/matchplan** — тело `{ saveId, leadMode, chaseMode, fatigueSubs }` (zod: enum'ы + boolean) → `SetMatchPlanResponse`

```ts
{ ok: true, plan: MatchPlanDTO }
```
Логика: `resolvePlayingSave` → `db.team.update({ where: { id: save.teamId }, data: { matchPlan: JSON.stringify(plan) } })`. Невалидное тело → 400 `INVALID_MATCH_PLAN`. План пишется ТОЛЬКО клубу игрока (ИИ — движок подставляет дефолт).

**GET /api/game/euro?saveId=** → `EuroResponse`

```ts
{ ok: true, euro: EuroSnapshotDTO }   // §3.4
```
Логика: `resolveSave` (finished тоже может смотреть — resolveSave, не Playing); состояние из GameSave (euroSeason/euroRound/euroAliveTeamIds/euroParticipants) + `db.match.findMany({ where: { saveId, season, competition: 'euro' }, orderBy: [{ cupRound: 'asc' }, { id: 'asc' }] })` → 4 раунда; участники (Team-строки всех 16 — вкл. гостей: `db.team.findMany({ where: { saveId, id: { in: participantIds } } })`, их лиги — leagueCode/leagues.ts); `nextEuroMatch` — первая непроигранная пара клуба игрока; статус: not_started (euroSeason=null или ≠season) / alive / eliminated / winner (по winnerTeamId финала) / qualified (сезон начат, раундов ещё нет). Лидеры — в /awards.

### 6.2. Таблица изменений существующих роутов

| Роут | Изменение |
|---|---|
| `POST /simulate` | payload: `userMatch` → **`userMatches: UserMatchResultDTO[]`** (0..2, порядок [кубок, евро]); `UserMatchResultDTO += competition`; += `euroRound: { round, label, drawn, pairs: EuroMatchDTO[] } | null`; `finances += euroPrize`; `seasonEnded += euro: { qualifiedNext, label } | null`. Вся логика — week.ts §5.2 |
| `GET /state` | снапшот: fixtures/seasonMatches включают competition='euro'; toTeamBrief += coachStyle/coachName; fixtures отсортированы (кубок раньше евро); weekInfo.label суффикс; leaders — только лиговые. Новых обязательных полей снапшота нет |
| `GET /match` | `MatchDetailsDTO.competition: 'league'|'cup'|'euro'` (парсинг competition в роуте: `'euro'` → `'euro'`); cupRound несёт еврораунд |
| `GET /awards` | `live += topEuroScorers: PlayerLeaderDTO[]` (топ-10 по Player.euroGoals, вкл. гостей, teamName из Team-строк) |
| `GET /player` | `PlayerHistoryDTO += euroGoals/euroAssists` (из PlayerSeasonRecord); PlayerDTO += euroGoals/euroAssists |
| `POST /saves` | team.create data += aiStyle/aiCoachName/leagueCode (генерация §5.9) |
| `GET /saves`, `PATCH/DELETE /saves/[id]`, `/new`, `/select`, `/leagues` | без изменений (каскад DELETE уже снесёт гостей через Team.saveId) |
| `POST /tactic`, `/training`, `/market*`, `/contracts*`, `/board`, `/academy` | без изменений |

### 6.3. Новые коды ошибок (error.ts)

```ts
// ── Фаза 4 ──
INVALID_MATCH_PLAN: 'Неверные настройки плана на матч',  // 400
```

---

## 7. UI-план (Блок B)

Тема: тёмно-зелёная (#0D1210/#151D18/#1C2620/#2A382F/#2E9E5B/#F0F0E0/#D4AF37), весь текст русский, mobile-first, тачи ≥44px, табулярные цифры. Маппинг на shadcn/ui как в Фазе 2/3.

### 7.1. MatchTimeline.tsx — события замен

- `TYPE_LABEL += sub: 'Замена'`; `EventIcon`: `case 'sub': <ArrowLeftRight className="size-4 text-muted-foreground" />` (иконка ⇄, серый — «без счёта»).
- Карточка события: обычная строка без цветной рамки (как chance), бейдж команды справа. Легаси-события без subOut* рендерятся по text.

### 7.2. MatchScreen.tsx — двойная неделя + бейдж стиля + план на матч

- **Двойной матч**: store `liveMatchIndex`; `Live()` читает `lastMatch.userMatches[liveMatchIndex]`; кнопка «К итогу»: если `liveMatchIndex + 1 < userMatches.length` → `setLiveMatchIndex(+1)` и рестарт ленты (матч 2 играет с минуты 0); иначе → `setMatchView('result')`. Хедер ленты: «Матч 1 из 2 · Кубок · 1/4» / «Матч 2 из 2 · Кубок Европы · 1/4».
- `Result()`: если userMatches.length === 2 — сводная карточка двух матчей (каждая: счёт, пен., кнопка «Трансляция» — открывает Live на нужном индексе); далее — итоги недели как сейчас.
- `Prematch()`: если неделя евро и клуб квалифицирован и жив — вторая карточка превью «Кубок Европы · {раунд}: {соперник}» (из snapshot.fixtures — второй isUserMatch-матч недели; бейдж лиги соперника-гостя: «Гость из Ла Лиги», сила, coachStyle-бейдж из /euro кеша). Кнопка «Начать матч» — одна: играет всю очередь (кубок → евро).
- **Бейдж стиля соперника** (лиговые матчи): в карточке превью под строкой «Соперник: формация …» — бейдж `opponent.coachStyle` (`AI_STYLE_LABELS` + hint одной строкой, цвет — outline, иконка по стилю: gegenpress ⬆ / tikitaka ◯ / bus 🚌 / vertical ⚡ / balanced —). Клуб игрока — бейдж не показывается.
- **План на матч** — карточка «План на матч» в Prematch (после превью, перед составами): 3 контрола:
  - «Ведём к 70-й минуте»: сегмент-переключатель [«Сушить счёт» | «Играть как есть»] (leadMode);
  - «Отстаём к 70-й минуте»: [«Максимальная атака» | «Без паники»] (chaseMode);
  - «Авто-замены уставших»: тумблер (fatigueSubs, Switch);
  - подпись-подсказка: «По умолчанию — как тренеры ИИ. Замены выполняет ассистент по плану; состав и скамейка — из вкладки „Тактика“»;
  - сохранение — кнопка «Сохранить план» (POST /matchplan → toast «План на матч сохранён»); карточка свёрнута по умолчанию (Collapsible), бейдж текущего режима рядом с заголовком.
- Матчи евро в `Prematch` без участия клуба: плашка «Кубок Европы · {раунд} — клуб не участвует / выбыл. Симулировать неделю» (аналог кубковой).

### 7.3. EuroScreen.tsx (новая вкладка «Европа», 12-я)

По образцу CupScreen (bracket):
- `StatusBanner`: статус клуба (не_started — «Квоты лиги: 3 места — зона топ-3 таблицы»; qualified/alive — «Кубок Европы · {раунд}, соперник {имя}»; eliminated — «Вылет в {раунд}»; winner — «Чемпион Европы!» золото #D4AF37).
- Сетка 4 колонок (1/8 → Финал; мобайл — вертикальный список раундов): карточка пары — TeamCrest, имя, бейдж ЛИГИ (флаг + имя лиги; гость — чужой флаг, подпись «гость»), счёт, пен., победитель подсвечен (рамка primary), «путь финала» — подсветка ячеек победителя золотом.
- Секция «Участники» (16 карточек с бейджами лиг/стилей тренера) + «Квоты» (6 лиг × 3/3/3/3/2/2).
- Секция «Бомбардиры» — топ-10 live (GET /awards live.topEuroScorers, вкл. гостей).
- Пары следующего раунда (из WeekResultPayload.euroRound при симуляции / из кеша /euro).
- Skeleton-загрузка; кеш `euroCache` в store (инвалидация при playWeek).

### 7.4. GameShell.tsx

- `TABS` += `{ id: 'euro', label: 'Европа', icon: Globe }` после «Кубка» (12 вкладок; мобайл — в «Ещё…», aria-label листа обновить: «…кубок, еврокубок, тренировки…»).
- Хедер: индикатор недели при евронеделе — бейдж с суффиксом «· Кубок Европы» уже в weekInfo.label.

### 7.5. DashboardScreen.tsx

- `NEWS_ICONS += euro: Globe`.
- Плитка «Кубок Европы» (после NextMatchTile, только при euroSeason активности): раунд + соперник (из euroCache — fetch при монтировании, паттерн BoardPanel), при статусе not_started — квоты/зона квалификации.
- Уведомления: новости 'euro' уже в ленте (иконка Globe).

### 7.6. LeagueScreen.tsx — еврозона

- Таблица: зона еврокубка = места [1, quota] (EURO_QUOTAS[league]) — подсветка строк 1..q (рамка primary, легенда «Кубок Европы (топ-{q})»); существующие зоны ЛЧ/ЛЕ из zonesFor заменяются на: `euro [1,q]` + `rel [N−2,N]` (ucl/uel-зоны Фазы 2 оставляем как есть — они косметические, надписи в легенде корректируются: «Кубок Европы»).

### 7.7. SeasonCeremony.tsx

- Блок «Кубок Европы» (если seasonEnded.euro ≠ null): статусная строка (Чемпион Европы! — золото; Финалист — серебро #D4AF37/50; Вылет в 1/2; Не квалифицированы — muted) + подпись «Следующий сезон: квалификация {да/нет}».

### 7.8. PlayerDialog.tsx / MatchDetailsDialog.tsx / SquadScreen

- HistoryTab: колонка «Голы (куб/евро)» — `goals ({cupGoals}/{euroGoals})` (аналогично ассисты); легенда не меняется.
- MatchDetailsDialog: заголовок «Кубок Европы · {раунд}» при competition='euro'; события замен рендерятся (общий MatchTimeline).
- SquadScreen — без изменений (euroGoals не показываем в составе — только история/награды).

### 7.9. store.ts / api.ts

- `api.ts` += `getMatchPlan/saveMatchPlan/getEuro` (§6.1, стиль Фазы 3).
- `store.ts`: TabId += 'euro'; кеши `matchPlanCache`/`euroCache` + fetch-экшены с guard смены сейва; `liveMatchIndex` (+сброс при playWeek); `playWeek`: `matchView: userMatches.length > 0 ? 'live' : 'result'`; инвалидации: playWeek сбрасывает euro/matchPlan, seasonEnded — playerDialogCache; persistCareerSummary — без изменений (трофеи: чемпион Европы не входит в CareerSummary — осознанно, «Трофеи» = лига+кубок).

---

## 8. Порядок реализации — Блок A (backend) и Блок B (frontend)

Блоки НЕ пересекаются по файлам: A = prisma, src/lib/game/**, src/app/api/game/**, scripts/**; B = src/lib/store.ts, src/lib/game/api.ts (клиент), src/components/game/**, src/app/page.tsx. types.ts — зона A (замораживается после A3 до конца A); api.ts/store.ts — зона B.

### Блок A — backend (~2500 строк, один агент)

- **A1. Prisma + инфраструктура**: дифф схемы (§1) → `bunx prisma db push` → регенерация клиента → перезапуск dev-сервера механизмом P3-3 (start-stop-daemon, порт 3000; НЕ nohup) → GET / 200 → GET /state существующего сейва «Барселона» 200 (легаси жив). Проверка индекса: `PRAGMA index_info` не обязательна — инвариант №12 смоука.
- **A2. constants.ts**: блоки §2 (MATCH_AI_*/STYLE_*/EURO_*/MATCH_PLAN_*/BOARD_DELTA_EURO_UPSET_LOSS) + правки значений §2.1. Зависимость: A1 (для смоука).
- **A3. types.ts**: §3 полностью (MatchEventType 'sub', MatchEvent subOut*, Competition, MatchPlanDTO + parseMatchPlan, EuroDTO, WeekResultPayload userMatches, PlayerDTO/HistoryDTO, parseEvents-толерантность). Заморозка интерфейсов до конца блока A.
- **A4. data.ts + coach.ts**: SUB_TEMPLATES/FORMATION_SHIFT_TEMPLATES; coach.ts — AI_STYLES-обвязка, FSM/utility `coachDecide`, `remapForFormation`, `guessAiStyle`, `aiStyleChangesFor`, `aiDefaultPlan` (§4.1). Чистые функции; юнит-прогон: решение при каждом из 9 состояний на фиктивных входах.
- **A5. match.ts — сегментный движок** (§4.2): полный rewrite simulateMatch; `segmentGoalMinute` для simulateAiMatch/simulateAiCupMatch; TYPE_ORDER sub; MatchTeamInput += bench/coach; MatchResult += homeSubs/awaySubs. Проверка A5: временный скрипт — 3 матча с фиксированным seed → идентичный повтор (детерминизм), замены ≤5, лента валидна.
- **A6. progression.ts**: разрезка applyPostMatch (per-match, минуты/замены/apps/рейтинг вышедшим, cleanSheets GK ≥30 мин финального вратаря) + applyWeeklyRecovery (§4.4).
- **A7. scripts/calibrate_segments.ts** (bun; импорт чистых модулей; БЕЗ Prisma): (1) 20k равных матчей, решения ВЫКЛ (все стили balanced, план hold/steady/no-subs): home/draw/away + среднее голов → коридор 44–48/24–27/2.6–2.9; (2) Σλ-линейность ±0.01; (3) 20k с решениями ВКЛ (оба ИИ): тот же коридор. Фиксация результатов в worklog.
- **A8. euro.ts + generate.ts + players.ts**: euro.ts (§4.5), assignAiStyle, TeamGen += стиль/имя/лига, PlayerLike/euroGoals, autoLineup rotateBelow (§5.9/5.10).
- **A9. board.ts**: разрезка weeklyBoardUpdate (boardMatchDeltaOf + boardWeeklyExtras + массив matches; евро-дельты) — поведение при 1 матче бит-в-бит как Фаза 3 (юнит-сверка).
- **A10. week.ts**: полный пайплайн §5.2 + переход §5.6 + миграции §5.3–5.4 + DYNAMIC_FIELDS + userMatches/euroRound/finances. Самый большой дифф (~450 строк).
- **A11. snapshot.ts + api-helpers.ts**: фильтры гостей, toTeamBrief coachStyle, fixtures евро + сортировка, label-суффикс, leaders (§5.10/5.5).
- **A12. Роуты**: новые matchplan/route.ts (GET+POST), euro/route.ts (GET); правки simulate/state/match/awards/player/saves (§6.2); error.ts += INVALID_MATCH_PLAN.
- **A13. Смоук scripts/smoke_phase4.sh** (по образцу smoke_phase3.sh; идемпотентный, чистит только свои сейвы): (0) легаси «Барселона» read-only; (1) ленивая миграция стилей на даунгрейд-сейве; (2) новая карьера: стили распределены (узнаваемых ≥25%), полный сезон с евро (сезон 1 с недели 1/8): жеребьёвка 8 пар без пар одной лиги, гость в /euro, двойная неделя userMatches=2, apps-инвариант ≤16, drain-дельта, призовые €13M у чемпиона-варианта не обязательна — проверка формулы euroPrizeFor; (3) переход: квалификация по таблице, смена стилей, реген гостей, записи PlayerSeasonRecord с евро-полями; (4) GET /matchplan + POST (валидация/400), GET /euro статусы; (5) сезон 2 евро по таблице. Прогон 3× идемпотентно.
- **A14. Верификация**: `bun run lint` 0; `bunx tsc --noEmit` 0 в src/; dev.log чист; calibrate_segments коридор зелёный; qa_phase3.sh остаётся зелёным (допустимое обновление apps-инварианта Фазы 2 — см. §9.3); запись в worklog (PROGRESS-строки по шагам).

Последовательность строго: A1 → A2 → A3 → (A4, A8) → A5 → A6 → A7 → A9 → A10 → A11 → A12 → A13 → A14. Сегменты (A5) ДО замен — замены требуют каркаса; красные-пре-рейтинг — внутри A5; стили (A4/A8) до A10 (пайплайн читает); матч-план — в A10 (tacticInputOf) и A12 (роут); евро — последним (A8→A10).

### Блок B — frontend (~1400 строк, один агент; стартует после заморозки types.ts = конец A3, код пишет после готовности A)

- **B1. api.ts** (+3 функции §6.1).
- **B2. store.ts**: TabId 'euro'; кеши euro/matchPlan; liveMatchIndex; playWeek-поток userMatches; инвалидации (§7.9).
- **B3. MatchTimeline**: sub-события (§7.1).
- **B4. MatchScreen**: двойная неделя (Live/Result/Prematch), бейдж стиля, карточка «План на матч» (§7.2).
- **B5. EuroScreen.tsx** (новый, ~380 строк): брекет/участники/квоты/бомбардиры (§7.3).
- **B6. GameShell**: 12-я вкладка + aria (§7.4).
- **B7. DashboardScreen**: плитка «Кубок Европы» + NEWS_ICONS (§7.5).
- **B8. LeagueScreen**: еврозона по квоте (§7.6).
- **B9. SeasonCeremony**: блок евро-итога (§7.7).
- **B10. PlayerDialog + MatchDetailsDialog**: евро-колонки истории, заголовок евро-матча (§7.8).
- **B11. Верификация браузером (agent-browser)**: полный флоу — новая карьера до недели 1/8 (curl-догон симуляций API), жеребьёвка/новости, двойная неделя (трансляция матча 1 → матча 2), план на матч (сохранение/тост/влияние — сушка видна по ленте замен), бейджи стилей, вкладка Европа (брекет/гости/бомбардиры), еврозона таблицы, церемония с евро-блоком, мобайл 375px («Ещё…» с 8 пунктами), консоль 0 ошибок; скриншоты docs/phase4-shots/.
- **B12. lint/tsc/worklog**.

---

## 9. QA-инварианты (≥12, проверяемые)

1. **Monte-Carlo-коридор (гейт)**: 20k равных матчей, решения ВКЛ, оба ИИ: home 44–48%, draw 24–27%, среднее голов 2.6–2.9 (scripts/calibrate_segments.ts; прогоны до и после включения решений — A7).
2. **Линейность сегментов**: при выключенных решениях Σ λ_сегментов = λ_старого_движка ± 0.01 (доли 0.42+0.28+0.30 = 1.00).
3. **Замены**: ≤ 5 на команду; каждая замена = событие 'sub' с обоими именами и текстом из SUB_TEMPLATES; заменённый НЕ забивает после минуты схода; вышедший МОЖЕТ забить после минуты входа; игравших ≤ 16; apps растёт ровно у игравших; drain стартёра = drain × минуты/90.
4. **Травма-замена**: при травме и свободных слотах замена в том же сегменте (событие на минуте травмы); при исчерпанных слотах λ следующих сегментов ×0.93 (время-взвешенно).
5. **Красные**: команда, оставшаяся в 10 с 30-й минуты, выигрывает ≤ 35% равных матчей (Monte-Carlo); множители 0.55/1.30 (сегмент 1) и 0.70/1.15 (сегмент 2), применяются только к оставшемуся времени (пре-рейтинг).
6. **Стили**: у каждого ИИ-клуба aiStyle из 5; в новых сейвах узнаваемых (gegenpress/tikitaka/bus/vertical) ≥ 25%; «bus» при лидировании к 70' применяет λ-множители сегмента 3 (проверка по events/Monte-Carlo); gegenpress даёт +0.4 к λ ЖК.
7. **Евро-формат**: 16 участников = квоты 3/3/3/3/2/2; в 1/8 нет пар одной лиги; гости не в таблице лиги, не в трансфер-рынке, не в жеребьёвке кубка, не в наградах лиги, не в топ-лидерах /awards (кроме topEuroScorers); их PlayerSeasonRecord создаются; матчи competition='euro' не попадают в standings; totalWeeks = 34/39/43 не изменился.
8. **Congestion**: клуб с 2 матчами в евронеделю: суммарный drain стартёров ≈ ×2, recovery +8 ровно ОДИН раз (нет двойного +8); средний condition стартёров на старте следующей недели ≥ 15 ниже, чем у «одноматчевого» клуба (допускается ротация, ≤ 15).
9. **Дренаж пула**: после 3 симулированных сезонов пул свободных агентов ≤ 700 (сейчас ≈1100); составы всех клубов ≥ 15 (инвариант №20 Фазы 3); составы гостей ≥ 18 (реген).
10. **Легаси-совместимость**: сейв Фазы 3 без пересоздания: GET /state 200; матч играется; старые события (без 'sub') парсятся; стили угаданы (aiStyle ≠ null после первой недели); евро включается только по правилу §5.3.
11. **RNG-детерминизм**: повторная симуляция с тем же `${saveId}:${season}:${week}:${matchId}` даёт байт-в-байт тот же events JSON (в т.ч. с заменами и решениями ИИ).
12. **Индекс двойной недели**: два домашних матча клуба в евронеделю (кубок + евро) не дают P2002 (unique [saveId, season, week, homeTeamId, competition]).
13. **Инвариант №5 Фазы 3 (расширен)**: PlayerSeasonRecord создаются для ВСЕХ игроков сейва включая гостей (±280 строк/сезон); возраст в записи = до старения; статистика не убывает; евро-поля заполнены у евроклубов/гостей.
14. **Правление**: в евронеделю с 2 матчами матчевые дельты применяются к обоим (кубок затем евро), недельные (темп/финансы/гармония) — один раз; вылет от слабого на ≥4 в евро → −4.
15. **Призовые**: euroPrizeFor: чемпион за сезон = 2+1+2+3+5 = €13M; финалист = 2+1+2+3+3.5 = €11.5M; вылет в 1/8 = €2M; все записи FinanceRecord category='euro_prize'.
16. **Контракты API**: GET/POST /matchplan по §6.1 (дефолт при null; 400 INVALID_MATCH_PLAN при невалидном теле); GET /euro все 5 статусов достижимы в смоук-сценариях.
17. **План на матч**: дефолт = паритет ИИ (движок выполняет решения и для клуба игрока); leadMode='hold' → в Monte-Carlo нет park-λ у клуба игрока; fatigueSubs=false → нет усталостных замен клуба игрока (инвариант по sub-событиям).

---

## 10. Риски и ловушки (и как избегаем)

1. **Уползание калибровки от тактического ИИ** («сушка»/«погоня» асимметричны): обязателен коридор §9.1 ДО/ПОСЛЕ (A7); knobs для тонкой подстройки (если draw > 27%): PARKING_BUS_MOD/CHASE_MOD — единственные числа, допускающие поправку ±0.03 по результату прогона (задокументировать в worklog).
2. **Разрезка applyPostMatch** — самый инвазивный дифф (progression + week + обе ветки недели): паритет одиночной недели проверяется тождеством до/после (юнит: drain/мораль/apps/рейтинг идентичны при 1 матче); qa_phase3.sh должен остаться зелёным.
3. **Двойной recovery** в евронеделю: applyPostMatch больше НЕ содержит +8; recovery применяется один раз — инвариант §9.8 (проверять именно отсутствие двойного +8).
4. **RNG-детерминизм решений**: фиксированный порядок (home→away; 6 бросков шума в порядке кандидатов) закреплён §4.2; любое изменение порядка — регрессия §9.11.
5. **Легаси-события**: parseEvents пропускает неизвестные type + пробрасывает subOut* — старые сейвы читаются; UI MatchTimeline имеет default-case иконки.
6. **Stale Prisma-клиент после db push** (реальный кейс Фазы 2: PrismaClientValidationError на новых полях): A1 обязан перезапустить dev-сервер (start-stop-daemon); при появлении «Unknown argument» в dev.log — перезапуск тем же механизмом.
7. **Уникальный индекс недели**: P2002 при двух домашних матчах одной недели — расширенный индекс §1.5; смоук §9.12.
8. **Утечка гостей в лиговые системы** (таблица/рынок/кубок/награды/лидеры/босман/академия/карьерная карточка): изоляция §5.5 списком мест; инвариант §9.7 прогоняет каждую утечку поимённо.
9. **Congestion-спираль ИИ** (составы без ротации сдуваются): autoLineup порог 65 в евронедели + recovery-модель; инвариант §9.8/9.9; следить за средним condition лиги в смоук-сезоне.
10. **Объём транзакции недели 1/8** (~300 create гостей поверх обычных ops): единая транзакция week.ts уже держит ~700 ops в переходе; создание гостей только на r=1 один раз за сейв; при таймауте SQLite — разбить на отдельную транзакцию ДО основной (задокументировать откат).
11. **Двойная неделя в UI** (застревание matchView): liveMatchIndex-очередь; кнопка «К итогу» всегда ведёт либо к матчу 2, либо к result; ручной тест B11 обязателен.
12. **Смена поведения клуба игрока по умолчанию** (движок ИИ-решений включён для него — паритет): осознанное решение (§0.3-8); «hold/steady/no-subs» возвращает полный контроль; коридор §9.1 включает план-дефолт.
13. **PlayerSeasonRecord-объём** (+~280 строк/сезон с гостями): приемлемо (SQLite, индекс [saveId, season]); инвариант №5 Фазы 3 расширен §9.13.
14. **Пенальти в евро для гостей**: simulatePenaltyShootout требует takers/GK из lineup — у гостей autoLineup всегда даёт GK; вырожденный случай (нет GK) — монетка (защита уже в cup.ts).
15. **score-based циклы** (гол меняет счёт → режим следующей КТ): режимы НЕ пересчитываются внутри сегмента (только на КТ) — зафиксировано §4.2 (простота и детерминизм; влияние ≤ 1 сегмента).

---

## Приложение: соответствие research-phase4.md → разделы ТЗ

| research-phase4.md | ТЗ Фазы 4 |
|---|---|
| §0 Резюме (все 4 блока) | §0.1 |
| §1.1 Как у топов (FM match plans/4-2-4/ротация) | §4.1 (FSM/Utility/правило 3-4-3), §7.2 (план) |
| §1.2 FSM × Utility, таблица кандидатов, матрица 9 состояний | §4.1 (полная спецификация + пороги §2.2) |
| §1.3 Сегменты/λ/усталость/замены/минуты/событие 'sub' | §4.2 (движок), §2.2, §3.1 |
| §1.4 Статистика/пост-матч (apps/минуты/мораль/cleanSheets/goalMinute ИИ) | §4.4, §4.2 (segmentGoalMinute) |
| §1.5 Подводные камни (калибровка/RNG/легаси/apps/порядок) | §9.1–9.3, §9.10–9.11, §10.1–10.5 |
| §1.6 Рекомендация Блока 1 + SUB_TEMPLATES | §4.1, §4.3 (шаблоны дословно) |
| §2.1–2.2 Стили: 5 профилей + таблица дельт | §2.3 (AI_STYLES — все числа), §4.2 (точки применения) |
| §2.3 Риски стилей | §2.3 (yellowLambdaBonus/injuryProbMult/condDrain) |
| §2.4 Coach-объект vs профиль на Team, смена p=0.25/0.10 | §1.1 (Team-поля), §2.3 (вероятности), §5.6 шаг 7 |
| §2.5 UI бейджей | §7.2, §7.3 |
| §2.6 Рекомендация Блока 2 | §4.1, §5.4, §5.9 |
| §3.1 Форматы УЕФА/конкурентов | §0.5 (исключения) |
| §3.2 Варианты календаря, E — рекомендация, раскладка | §5.1 (точная раскладка + арифметика «свободных недель нет») |
| §3.3 Квоты/квалификация/зоны | §2.4 (EURO_QUOTAS), §4.5 (euroParticipants), §7.6 |
| §3.4 Гостевые клубы | §4.5 (buildEuroGuests), §5.5 (изоляция), §5.6 шаг 6 (реген) |
| §3.5 Призовые/правление/усталость/статистика | §2.4, §5.8, §5.2 Б.2, §9.15 |
| §3.6 UI еврокубка | §7.3, §7.5 |
| §3.7 Подводные камни (двойной applyPostMatch/порядок/жеребьёвка/легаси/каскад/производительность) | §4.4, §5.2 Б.2.d, §4.5, §5.3, §6.2, §10.10 |
| §3.8 Рекомендация Блока 3 | §4.5, §5.2–5.3, §6.1 |
| §4.1 Таблица констант (✅/❌) | §2.1 (правки + «оставить как есть») |
| §4.2 QA §5 qa-report-phase3 (пул агентов) | §2.1 (CONTRACT_DRAIN_*), §9.9 |
| §4.3 Красные: Monte-Carlo таблица, пре-рейтинг | §2.1 (значения), §4.2 (segFactor — пре-рейтинг), §9.5 |
| §4.4 Юнит-инварианты (9 шт.) | §9.1–9.10 (расширено до 17) |
| §5.1 Match AI константы/структуры | §2.2, §3.6 |
| §5.2 AI_STYLES | §2.3 |
| §5.3 Еврокубок формат/данные | §2.4, §1.4, §4.5, §5.1 |
| §5.4 Правки констант (код-блок) | §2.1 (дословно) |
| §5.5 Порядок интеграции 5 шагов | §8 (A1→A14: сегменты → красные (в A5) → замены (A5/A6) → стили (A4/A8) → матч-план (A10/A12) → евро (A8/A10–A13) → баланс (A2/A7)) |
| §5.6 Топ-риски | §10.1–10.13 |
| Приложение (источники, Monte-Carlo 200k) | используется как калибровочная база §9.1 (база 46.1/25.0/2.73; красные §4.3) |

**Отклонения от research** — только §0.4 (6 позиций, все с обоснованием); остальные числа/формулы перенесены дословно.

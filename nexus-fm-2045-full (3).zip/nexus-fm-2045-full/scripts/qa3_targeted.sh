#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# QA Фазы 3 — ЦЕЛЕВЫЕ репро-сценарии (Task P3-5, второй проход):
#  A. Истечение контракта: молодой (листинг free 0.25×value TTL 8) + старый
#     35+ (пенсия, без листинга) + деплетия состава и S2W1 (stale lineup → auto).
#  B. Вердикты правления met / missed / over по месту vs boardTargetPlace
#     (targetPlace подставляется под фактическое место после 33-й недели).
#  C. Mid-season sack ПОСЛЕ медового месяца: conf=5 прикалывается перед КАЖДОЙ
#     неделей 9–12 (низ 4 недели подряд → увольнение), затем 404 на play-роутах.
# Идемпотентен: только свои сейвы «P3-QA3 …».
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000/api/game"
DB="bun scripts/qa3_db.ts"
RE="bun scripts/qa3_repro.ts"
PASS=0; FAIL=0
ok()  { PASS=$((PASS + 1)); echo "  ✔ $*"; }
bad() { FAIL=$((FAIL + 1)); echo "  ✘ $*"; }
call() {
  local method="$1" url="$2" body="${3:-}"
  if [ -n "$body" ]; then
    BODY=$(curl -s -m 300 -w $'\n%{http_code}' -X "$method" -H 'Content-Type: application/json' -d "$body" "$url")
  else
    BODY=$(curl -s -m 300 -w $'\n%{http_code}' -X "$method" "$url")
  fi
  CODE=$(echo "$BODY" | tail -n1)
  BODY=$(echo "$BODY" | sed '$d')
}
check_code() {
  if [ "$CODE" = "$2" ]; then ok "$1 (HTTP $CODE)"; else bad "$1: ожидался HTTP $2, получен $CODE"; fi
}
check_json() {
  local desc="$1" expr="$2" expected="$3" actual
  actual=$(echo "$BODY" | jq -r "$expr" 2>/dev/null)
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"; else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}
check_eq() {
  if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1: ожидалось '$3', получено '$2'"; fi
}
simulate() { call POST "$BASE/simulate" "{\"saveId\":\"$1\"}"; }

# ═══ A. Истечение: молодой → free-листинг, старый → пенсия, деплетия ════════
echo
echo "── A. Истечение контрактов (молодой/старый) + деплетия состава ──"
call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":0,"managerName":"QA P3-5","careerName":"P3-QA3 Истечение A"}'
check_code "POST /saves" 200
SID_A=$(echo "$BODY" | jq -r '.saveId')
for W in $(seq 1 33); do simulate "$SID_A" || break; done
check_code "33 недели до перехода" 200

$RE squad "$SID_A" > /tmp/qa3_squad_a.txt 2>/dev/null
# формат: p <id> <age> <ovr> cu=N pre=0|1 v=VALUE
YOUNG_PID=$(grep '^p ' /tmp/qa3_squad_a.txt | awk '$3 <= 28 && $5 == "cu=2" && $6 == "pre=0"' | head -n1 | awk '{print $2}')
if [ -z "$YOUNG_PID" ]; then YOUNG_PID=$(grep '^p ' /tmp/qa3_squad_a.txt | awk '$3 <= 28 && $6 == "pre=0"' | head -n1 | awk '{print $2}'); fi
OLD_PID=$(grep '^p ' /tmp/qa3_squad_a.txt | awk '$6 == "pre=0" {print $2, $3}' | sort -k2 -n | tail -n1 | awk '{print $1}')
OLD_AGE=$(grep "^p $OLD_PID " /tmp/qa3_squad_a.txt | awk '{print $3}')
YOUNG_VALUE=$(grep "^p $YOUNG_PID " /tmp/qa3_squad_a.txt | awk '{print $7}' | sed 's/v=//')
if [ "${OLD_AGE:-0}" -lt 35 ] 2>/dev/null; then $RE ageup "$SID_A" "$OLD_PID" 36 >/dev/null 2>&1; OLD_AGE=36; fi
$RE forceexpire "$SID_A" "$YOUNG_PID" >/dev/null 2>&1
$RE forceexpire "$SID_A" "$OLD_PID" >/dev/null 2>&1
YOUNG_AGE=$(grep "^p $YOUNG_PID " /tmp/qa3_squad_a.txt | awk '{print $3}')
echo "  … кандидаты: молодой $YOUNG_PID (${YOUNG_AGE} л., value €$YOUNG_VALUE), старый $OLD_PID (${OLD_AGE} л.)"

simulate "$SID_A"
check_code "переход (финальная неделя)" 200

$RE playerstate "$SID_A" "$YOUNG_PID" > /tmp/qa3_ps_young.txt 2>/dev/null
if grep -q "player=exists team=null" /tmp/qa3_ps_young.txt; then ok "A: молодой покинул клуб (teamId=null)"; else bad "A: молодой не свободный агент: $(head -n1 /tmp/qa3_ps_young.txt)"; fi
if grep -q '^l free active' /tmp/qa3_ps_young.txt; then ok "A: лот source=free status=active"; else bad "A: нет active free-лота у молодого: $(cat /tmp/qa3_ps_young.txt | tr '\n' ' ')"; fi
TTL_A=$(grep '^l ' /tmp/qa3_ps_young.txt | head -n1 | sed 's/.*ttl=//')
check_eq "A: TTL free-лота = 8" "$TTL_A" "8"
PRICE_A=$(grep '^l ' /tmp/qa3_ps_young.txt | head -n1 | sed 's/.*price=//;s/ ttl=.*//')
EXPECTED_A=$(python3 -c "print(max(10000, round(0.25 * $YOUNG_VALUE)))")
check_eq "A: цена лота = 0.25×value" "$PRICE_A" "$EXPECTED_A"

$RE playerstate "$SID_A" "$OLD_PID" > /tmp/qa3_ps_old.txt 2>/dev/null
if grep -q 'player=deleted' /tmp/qa3_ps_old.txt; then ok "A: старый (35+) истёк → пенсия (удалён, листинга нет — create-then-delete)"; else
  if grep -q '^l free active' /tmp/qa3_ps_old.txt; then ok "A: старый не удалён — ушёл в free-агенты (не пенсия в этом ролле)"; else bad "A: старый не удалён и без лота: $(cat /tmp/qa3_ps_old.txt | tr '\n' ' ')"; fi
fi

$RE squadcheck "$SID_A" > /tmp/qa3_sq_a.txt 2>/dev/null
STALE=$(grep '^stale_lineup_refs=' /tmp/qa3_sq_a.txt | cut -d= -f2)
SQA=$(grep '^squad_size=' /tmp/qa3_sq_a.txt | cut -d= -f2)
echo "  … после перехода: состав клуба игрока $SQA, stale-ссылок в сохранённом составе $STALE"
simulate "$SID_A"
check_code "A: S2W1 после деплетии — HTTP" 200
check_json "A: S2W1 неделя отыграна" '.result.weekType' 'league'
NEWS_AUTO=$(echo "$BODY" | jq -r '[.result.news[] | select(.message | contains("автоматически"))] | length')
if [ "${STALE:-0}" -gt 0 ] && [ "${NEWS_AUTO:-0}" -ge 1 ]; then ok "A: stale lineup ($STALE) → автосостав + новость ассистента"; fi

# ═══ B. Вердикты met / missed / over (место vs targetPlace) ════════════════
echo
echo "── B. Вердикты правления: missed (S1) → met (S2) → over (S3) ──"
call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":15,"managerName":"QA P3-5","careerName":"P3-QA3 Вердикты B"}'
check_code "POST /saves" 200
SID_B=$(echo "$BODY" | jq -r '.saveId')
for S in 1 2 3; do
  for W in $(seq 1 33); do
    # пин уверенности 50 — исключает естественный mid-season sack слабого клуба
    # (сценарий B тестирует формулу вердикта, увольнение — сценарий C)
    $DB setconf "$SID_B" 50 0 >/dev/null 2>&1
    simulate "$SID_B" || break
    if [ "$CODE" != "200" ]; then bad "B: неделя $S/$W HTTP $CODE"; break 2; fi
  done
  call GET "$BASE/state?saveId=$SID_B"
  PLACE_B=$(echo "$BODY" | jq -r '.snapshot.standings[] | select(.isUser == true) | .place')
  case $S in
    1) TP=$((PLACE_B - 1)); WANT="missed";;   # miss = +1
    2) TP=$PLACE_B;      WANT="met";;         # miss = 0
    3) TP=$((PLACE_B + 3)); WANT="over";;     # miss = -3
  esac
  $DB setconf "$SID_B" 50 0 upper "$TP" >/dev/null 2>&1
  simulate "$SID_B"
  check_code "B: переход сезона $S" 200
  GOT=$(echo "$BODY" | jq -r '.result.seasonEnded.boardVerdict.code')
  if [ "$GOT" = "$WANT" ]; then ok "B: сезон $S место $PLACE_B vs топ-$TP → вердикт $GOT"; else bad "B: сезон $S место $PLACE_B vs топ-$TP: вердикт '$GOT', ожидался '$WANT'"; fi
  check_json "B: sacked=false при conf=50 (сезон $S)" '.result.sacked' 'false'
  AIFLOOR_B=$($DB squads "$SID_B" 2>/dev/null | grep '^ai_min_squad=' | cut -d= -f2)
  if [ "${AIFLOOR_B:-0}" -ge 15 ]; then ok "B: ИИ-составы ≥ 15 после S$S (мин $AIFLOOR_B)"; else bad "B: ИИ-составы < 15 после S$S (мин $AIFLOOR_B)"; fi
done

# ═══ C. Mid-season sack ПОСЛЕ медового месяца ══════════════════════════════
echo
echo "── C. Mid-season sack после медового месяца (недели 9–12, conf=5) ──"
call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":14,"managerName":"QA P3-5","careerName":"P3-QA3 Сак C"}'
check_code "POST /saves" 200
SID_C=$(echo "$BODY" | jq -r '.saveId')
for W in $(seq 1 8); do simulate "$SID_C" || break; done
check_code "C: недели 1–8 (медовый месяц)" 200
SACKED_C=0
for W in 9 10 11 12 13; do
  $DB setconf "$SID_C" 5 0 >/dev/null 2>&1
  simulate "$SID_C"
  if [ "$CODE" != "200" ]; then bad "C: неделя $W HTTP $CODE"; break; fi
  if [ "$(echo "$BODY" | jq -r '.result.sacked')" = "true" ]; then SACKED_C=$W; break; fi
done
if [ "$SACKED_C" -gt 0 ]; then ok "C: mid-season sack на неделе $SACKED_C (conf<12 четыре недели подряд)"; else bad "C: mid-season sack не произошёл к неделе 13"; fi
C_STATUS=$($DB save "$SID_C" 2>/dev/null | grep '^save_status=' | cut -d= -f2)
C_REASON=$($DB save "$SID_C" 2>/dev/null | grep '^save_finish_reason=' | cut -d= -f2)
check_eq "C: статус finished" "$C_STATUS" "finished"
check_eq "C: finishReason sacked" "$C_REASON" "sacked"
call POST "$BASE/simulate" "{\"saveId\":\"$SID_C\"}"
check_code "C: POST /simulate после увольнения → 404" 404
call POST "$BASE/tactic" "{\"saveId\":\"$SID_C\"}"
check_code "C: POST /tactic после увольнения → 404" 404

# ═══ Уборка ════════════════════════════════════════════════════════════════
echo
echo "── Уборка своих сейвов ──"
for DEL in "$SID_A" "$SID_B" "$SID_C"; do
  call DELETE "$BASE/saves/$DEL"
  if [ "$CODE" = "200" ]; then ok "удалён $DEL"; else bad "не удалён $DEL (HTTP $CODE)"; fi
done

echo
echo "════ ИТОГ целевых сценариев ════════════════════════════════"
echo "PASS=$PASS  FAIL=$FAIL"
[ "$FAIL" -eq 0 ] && echo "СТАТУС: ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ" || echo "СТАТУС: ЕСТЬ ПРОВАЛЫ"
exit $([ "$FAIL" -eq 0 ] && echo 0 || echo 1)

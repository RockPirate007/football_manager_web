#!/usr/bin/env bash
# ============================================================================
# build-desktop.sh — полный пайплайн десктоп-сборки «Футбольный Менеджер»
# (спека docs/desktop/02-spec.md §7.2; этап D-9).
#
# ЕДИНСТВЕННОЕ легальное место запуска `bun run build` во всём проекте:
# static export (output:'export') → Neutralino v6.9.0 → exe/win64 + linux64
# + zip-дистрибутивы в download/.
#
# Отклонения от §7.1 конфига, зафиксированные D-9 (обоснования — worklog D-9
# и аудит исходников neutralino v6.9.0 / neu CLI 11.7.2):
#   enableServer:true      — false ломает window-режим (navigationUrl остаётся
#                            сырым '/', нативный WebSocket = сам этот сервер);
#   documentRoot:'/resources/' — '../out' работает только в dev dir-режиме,
#                            в release это путь внутрь resources.neu (ASAR);
#   tokenSecurity:'none'   — глобалы эмитятся дважды (injectGlobals + prepend
#                            /neutralino.js), one-time затирал бы токен '';
#   dataLocation:'system' + injectGlobals/injectClientLibrary/injectScript
#                         — в v6.9 нет глобала NL_APPDATA; шим
#                           public/fm-bootstrap.js проксирует NL_DATAPATH;
#   cli.clientLibrary:'resources/js/neutralino.js' — баг CLI c '--runtime'
#                            (d.ts перезаписывает js-файл).
# ============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

echo "==> [1/7] Статический экспорт фронтенда (next build → out/)"
bun run build

echo "==> [2/7] Иконка 512x512 (logo.svg → public/logo.png)"
[ -f public/logo.png ] || bun scripts/svg2png.ts

echo "==> [3/7] Синк статики в Neutralino-проект (out/ → desktop-neutralino/resources/)"
rm -rf desktop-neutralino/resources
mkdir -p desktop-neutralino/resources desktop-neutralino/public
cp -r out/. desktop-neutralino/resources/
cp public/logo.png desktop-neutralino/public/logo.png

echo "==> [4/7] Neutralino: бинарники v6.9.0 + клиентская либа (neu update)"
(cd desktop-neutralino && bunx @neutralinojs/neu update)

echo "==> [5/7] Release-сборка (neu build --release → desktop-neutralino/dist/FootballManager/)"
(cd desktop-neutralino && bunx @neutralinojs/neu build --release)

DIST="desktop-neutralino/dist/FootballManager"
EXE="$DIST/FootballManager-win_x64.exe"
LINUX="$DIST/FootballManager-linux_x64"
RES="$DIST/resources.neu"

echo "==> [6/7] Проверки артефактов"
[ -f "$EXE" ]   || { echo "FAIL: нет $EXE"; exit 1; }
[ -f "$LINUX" ] || { echo "FAIL: нет $LINUX"; exit 1; }
[ -f "$RES" ]   || { echo "FAIL: нет $RES"; exit 1; }
file "$EXE" | grep -q "PE32+ executable" || { echo "FAIL: $EXE не PE32+"; exit 1; }
echo "    exe:   $(du -h "$EXE" | cut -f1)  $(file -b "$EXE" | cut -c1-60)"
echo "    linux: $(du -h "$LINUX" | cut -f1)"
echo "    neu:   $(du -h "$RES" | cut -f1)  (ASAR: весь out/)"

echo "==> [7/7] Zip-дистрибутивы в download/"
mkdir -p download
rm -f download/FM-Desktop-win64.zip download/FM-Desktop-linux64.zip
cp "$EXE" download/FootballManager-win_x64.exe
cp "$LINUX" download/FootballManager-linux_x64
chmod +x download/FootballManager-linux_x64
cp "$RES" download/resources.neu
(cd download \
  && zip -j -q FM-Desktop-win64.zip FootballManager-win_x64.exe resources.neu README-RUN.txt \
  && zip -j -q FM-Desktop-linux64.zip FootballManager-linux_x64 resources.neu README-RUN.txt)
rm -f download/FootballManager-win_x64.exe download/FootballManager-linux_x64 download/resources.neu

echo ""
echo "Готово:"
echo "  download/FM-Desktop-win64.zip   $(du -h download/FM-Desktop-win64.zip | cut -f1)"
echo "  download/FM-Desktop-linux64.zip $(du -h download/FM-Desktop-linux64.zip | cut -f1)"
echo "  (Windows: распаковать → FootballManager-win_x64.exe + resources.neu рядом;"
echo "   нужен Microsoft Edge WebView2 Runtime — см. README-RUN.txt)"

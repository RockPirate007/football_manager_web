import type { NextConfig } from "next";

// D-4 (спека §6.6): static export — фронтенд целиком клиентский, игровых
// API-роутов больше нет; Neutralino отдаёт out/index.html напрямую (file://).
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: false,
  // Разрешаем запросы статики /_next/* с превью-домена space-z.ai
  allowedDevOrigins: ["*.space-z.ai"],
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;

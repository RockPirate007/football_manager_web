import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode } from '@/lib/game/api-helpers';
import { START_BALANCE_BASE, START_BALANCE_PER_STRENGTH } from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { leagueByCode } from '@/lib/game/leagues';
import { autoLineup, type PlayerLike } from '@/lib/game/players';

const bodySchema = z.object({
  saveId: z.string().min(1),
  teamId: z.string().min(1),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/select — ЛЕГАСИ-обёртка Фазы 1 (совместимость со старым
 * фронтендом до прихода Task 10-b): выбор клуба в setup-сейве, созданном
 * роутом /new. Устанавливает teamId, баланс по силе и статус active.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('SAVE_NOT_FOUND', 404);

    const save = await db.gameSave.findUnique({ where: { id: parsed.data.saveId } });
    if (!save) return fail('SAVE_NOT_FOUND', 404);
    if (save.status !== 'setup' || save.teamId) return fail('ALREADY_SELECTED', 409);

    const def = leagueByCode(save.leagueCode);
    if (!def) return fail('SAVE_NOT_FOUND', 404);

    const team = await db.team.findFirst({
      where: { id: parsed.data.teamId, saveId: save.id },
    });
    if (!team) return fail('SAVE_NOT_FOUND', 404);

    const squad = await db.player.findMany({ where: { saveId: save.id, teamId: team.id } });
    const auto = autoLineup(squad as unknown as PlayerLike[], '4-4-2');

    const startBalance =
      START_BALANCE_BASE + Math.max(0, team.strength - 55) * START_BALANCE_PER_STRENGTH;

    await db.$transaction([
      db.team.update({
        where: { id: team.id },
        data: {
          isUserTeam: true,
          formation: '4-4-2',
          mentality: 'balanced',
          tempo: 'medium',
          pressing: 'medium',
          defLine: 'medium',
          playStyle: 'balanced',
          lineup: JSON.stringify(auto.lineup),
          bench: JSON.stringify(auto.bench),
        },
      }),
      db.gameSave.update({
        where: { id: save.id },
        data: {
          teamId: team.id,
          balance: startBalance,
          status: 'active',
          careerName: save.careerName ?? `${team.name} · Сезон 1`,
          lastOpenedAt: new Date(),
        },
      }),
      db.newsItem.create({
        data: {
          id: crypto.randomUUID(),
          saveId: save.id,
          season: 1,
          week: 1,
          type: 'info',
          message: `Добро пожаловать в «${team.name}», ${save.managerName}! Впереди ${def.leagueWeeks} туров и ${def.cupName}!`,
        },
      }),
    ]);

    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/select]', error);
    return fail('UNKNOWN', 500);
  }
}

'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { CalendarDays, ChevronLeft, ChevronRight, Goal, Handshake, Table2 } from 'lucide-react';
import { api } from '@/lib/game/api';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FormDots } from '@/components/game/shared/FormDots';
import { MatchDetailsDialog } from '@/components/game/shared/MatchDetailsDialog';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { EURO_QUOTAS, zonesFor } from '@/lib/game/constants';
import type { MatchDetailsDTO, PlayerLeaderDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Фаза 4: зелёная зона = квота лиги в Кубок Европы (топ-q, q = EURO_QUOTAS);
 *  жёлтая (4–6) — косметическая «зона ЛЕ» Фазы 2; красная — вылет. */
function zoneClass(place: number, N: number, quota: number): string {
  if (place <= quota) return 'bg-[#22C55E]';
  const zones = zonesFor(N);
  if (place >= zones.uel[0] && place <= zones.uel[1]) return 'bg-[#FACC15]';
  if (place >= zones.rel[0] && place <= zones.rel[1]) return 'bg-[#EF4444]';
  return 'bg-transparent';
}

function StandingsTable() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { standings, save } = snapshot;
  const N = standings.length;
  const quota = EURO_QUOTAS[save.league.code] ?? 2;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="scroll-thin overflow-x-auto rounded-lg border border-border/70 bg-card"
    >
      <Table className="min-w-[720px]">
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="h-10 w-10 text-center text-[11px]">#</TableHead>
            <TableHead className="h-10 text-[11px]">Клуб</TableHead>
            <TableHead className="h-10 w-8 text-center text-[11px]">И</TableHead>
            <TableHead className="h-10 w-8 text-center text-[11px]">В</TableHead>
            <TableHead className="h-10 w-8 text-center text-[11px]">Н</TableHead>
            <TableHead className="h-10 w-8 text-center text-[11px]">П</TableHead>
            <TableHead className="h-10 w-14 text-center text-[11px]">М</TableHead>
            <TableHead className="h-10 w-10 text-center text-[11px]">±</TableHead>
            <TableHead className="h-10 w-8 text-center text-[11px]">О</TableHead>
            <TableHead className="h-10 text-right text-[11px]">Форма</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="zebra">
          {standings.map((r) => (
            <TableRow
              key={r.teamId}
              className={cn(
                'h-10 border-border/40',
                r.isUser && 'bg-primary/10 hover:bg-primary/10',
              )}
            >
              <TableCell className="relative py-1 text-center text-xs font-semibold tabular">
                <span className={cn('absolute left-0 top-1 h-8 w-1 rounded-r', zoneClass(r.place, N, quota))} aria-hidden />
                {r.place}
              </TableCell>
              <TableCell className="py-1">
                <div className="flex items-center gap-2">
                  <TeamCrest
                    shortName={r.shortName}
                    colorPrimary={r.colorPrimary}
                    colorSecondary={r.colorSecondary}
                    size="sm"
                  />
                  <span className={cn('truncate text-xs', r.isUser && 'font-bold text-primary')}>
                    {r.name}
                  </span>
                </div>
              </TableCell>
              <TableCell className="py-1 text-center text-xs tabular text-muted-foreground">{r.played}</TableCell>
              <TableCell className="py-1 text-center text-xs tabular">{r.won}</TableCell>
              <TableCell className="py-1 text-center text-xs tabular">{r.drawn}</TableCell>
              <TableCell className="py-1 text-center text-xs tabular">{r.lost}</TableCell>
              <TableCell className="py-1 text-center text-xs tabular text-muted-foreground">
                {r.goalsFor}:{r.goalsAgainst}
              </TableCell>
              <TableCell className="py-1 text-center text-xs tabular">
                <span className={r.goalDiff > 0 ? 'text-[#22C55E]' : r.goalDiff < 0 ? 'text-[#EF4444]' : 'text-muted-foreground'}>
                  {r.goalDiff > 0 ? '+' : ''}{r.goalDiff}
                </span>
              </TableCell>
              <TableCell className="py-1 text-center text-xs font-bold tabular">{r.points}</TableCell>
              <TableCell className="py-1 text-right">
                <FormDots form={r.form} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <ZonesLegend N={N} quota={quota} />
    </motion.div>
  );
}

function ZonesLegend({ N, quota }: { N: number; quota: number }) {
  const zones = zonesFor(N);
  return (
    <div className="flex flex-wrap items-center gap-4 border-t border-border/50 px-4 py-2.5 text-[11px] text-muted-foreground">
      <span className="flex items-center gap-1.5">
        <span className="h-2 w-2 rounded-full bg-[#22C55E]" aria-hidden />
        1–{quota} — Кубок Европы (топ-{quota})
      </span>
      <span className="flex items-center gap-1.5">
        <span className="h-2 w-2 rounded-full bg-[#FACC15]" aria-hidden />
        {zones.uel[0]}–{zones.uel[1]} — зона ЛЕ
      </span>
      <span className="flex items-center gap-1.5">
        <span className="h-2 w-2 rounded-full bg-[#EF4444]" aria-hidden />
        {zones.rel[0]}–{zones.rel[1]} — вылет
      </span>
    </div>
  );
}

function Calendar() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const activeSaveId = useGameStore((s) => s.activeSaveId);
  const { seasonMatches, teams, save } = snapshot;
  const teamById = useMemo(() => new Map(teams.map((t) => [t.id, t])), [teams]);
  const [week, setWeek] = useState(save.week);
  const [matchId, setMatchId] = useState<string | null>(null);
  const [matchData, setMatchData] = useState<MatchDetailsDTO | null>(null);
  const [matchLoading, setMatchLoading] = useState(false);

  const openMatch = (id: string) => {
    if (!activeSaveId) return;
    setMatchId(id);
    setMatchLoading(true);
    setMatchData(null);
    void api
      .getMatch(activeSaveId, id)
      .then((res) => setMatchData(res.match))
      .catch(() => setMatchData(null))
      .finally(() => setMatchLoading(false));
  };

  const closeMatch = () => {
    setMatchId(null);
    setMatchData(null);
    setMatchLoading(false);
  };

  const weekMatches = useMemo(
    () => seasonMatches.filter((m) => m.week === week && m.competition === 'league'),
    [seasonMatches, week],
  );
  const hasCupThisWeek = useMemo(
    () => seasonMatches.some((m) => m.week === week && m.competition === 'cup'),
    [seasonMatches, week],
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-4"
    >
      {/* Селектор тура */}
      <div className="flex items-center justify-center gap-3">
        <Button
          variant="outline"
          size="icon"
          className="size-11"
          onClick={() => setWeek((w) => Math.max(1, w - 1))}
          disabled={week <= 1}
          aria-label="Предыдущий тур"
        >
          <ChevronLeft className="size-4" aria-hidden />
        </Button>
        <div className="min-w-40 text-center">
          <div className="text-sm font-bold tabular">
            Неделя {week}/{save.totalWeeks}
          </div>
          <div className="text-[11px] text-muted-foreground">Сезон {save.season}</div>
        </div>
        <Button
          variant="outline"
          size="icon"
          className="size-11"
          onClick={() => setWeek((w) => Math.min(save.totalWeeks, w + 1))}
          disabled={week >= save.totalWeeks}
          aria-label="Следующий тур"
        >
          <ChevronRight className="size-4" aria-hidden />
        </Button>
      </div>

      <Card className="border-border/70">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm">
            <CalendarDays className="size-4 text-primary" aria-hidden />
            Матчи тура
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {weekMatches.length === 0 ? (
            hasCupThisWeek ? (
              <p className="py-6 text-center text-xs text-muted-foreground">
                Это кубковая неделя — {save.league.cupName}. Результаты смотрите во вкладке «Кубок».
              </p>
            ) : (
              <p className="py-6 text-center text-xs text-muted-foreground">
                Нет данных об этом туре.
              </p>
            )
          ) : (
            weekMatches.map((m) => {
              const home = teamById.get(m.homeTeamId);
              const away = teamById.get(m.awayTeamId);
              const isUser =
                m.homeTeamId === snapshot.myTeam.id || m.awayTeamId === snapshot.myTeam.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => m.played && openMatch(m.id)}
                  disabled={!m.played}
                  className={cn(
                    'flex w-full items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-2.5 text-left transition-colors',
                    m.played && 'hover:border-primary/50',
                    !m.played && 'opacity-60',
                    isUser && 'border-primary/40 bg-primary/5',
                  )}
                  aria-label={
                    m.played
                      ? `${home?.name} против ${away?.name}, счёт ${m.homeGoals}:${m.awayGoals}`
                      : `${home?.name} против ${away?.name}, не сыгран`
                  }
                >
                  <div className="flex min-w-0 flex-1 items-center justify-end gap-2 text-right">
                    <span className={cn('hidden truncate text-xs sm:inline', isUser && 'font-bold text-primary')}>
                      {home?.name ?? '—'}
                    </span>
                    <TeamCrest
                      shortName={home?.shortName ?? '—'}
                      colorPrimary={home?.colorPrimary ?? '#0E7490'}
                      colorSecondary={home?.colorSecondary ?? '#F0F6FC'}
                      size="sm"
                    />
                  </div>
                  <div className="w-20 shrink-0 text-center">
                    {m.played ? (
                      <span className="text-sm font-bold tabular">
                        {m.homeGoals} : {m.awayGoals}
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">vs</span>
                    )}
                  </div>
                  <div className="flex min-w-0 flex-1 items-center gap-2">
                    <TeamCrest
                      shortName={away?.shortName ?? '—'}
                      colorPrimary={away?.colorPrimary ?? '#0E7490'}
                      colorSecondary={away?.colorSecondary ?? '#F0F6FC'}
                      size="sm"
                    />
                    <span className={cn('hidden truncate text-xs sm:inline', isUser && 'font-bold text-primary')}>
                      {away?.name ?? '—'}
                    </span>
                  </div>
                  {isUser ? (
                    <Badge className="shrink-0 bg-primary/15 text-[9px] text-primary">МЫ</Badge>
                  ) : null}
                </button>
              );
            })
          )}
        </CardContent>
      </Card>

      <MatchDetailsDialog
        matchId={matchId}
        match={matchData}
        loading={matchLoading}
        onClose={closeMatch}
      />
    </motion.div>
  );
}

/** Таблица лидеров: бомбардиры или ассистенты. */
function LeadersTable({
  title,
  icon: Icon,
  rows,
  valueLabel,
}: {
  title: string;
  icon: typeof Goal;
  rows: PlayerLeaderDTO[];
  valueLabel: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="overflow-hidden rounded-lg border border-border/70 bg-card"
    >
      <div className="flex items-center gap-2 border-b border-border/50 px-4 py-3">
        <Icon className="size-4 text-primary" aria-hidden />
        <span className="text-sm font-bold">{title}</span>
        <span className="ml-auto text-[11px] text-muted-foreground">сезон · топ-{rows.length}</span>
      </div>
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="h-10 w-10 text-center text-[11px]">#</TableHead>
            <TableHead className="h-10 text-[11px]">Игрок</TableHead>
            <TableHead className="h-10 text-[11px]">Клуб</TableHead>
            <TableHead className="h-10 w-12 text-center text-[11px]">Матчи</TableHead>
            <TableHead className="h-10 w-12 text-center text-[11px]">{valueLabel}</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="zebra">
          {rows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} className="py-6 text-center text-xs text-muted-foreground">
                Статистика ещё пуста.
              </TableCell>
            </TableRow>
          ) : (
            rows.map((p, i) => (
              <TableRow
                key={p.playerId}
                className={cn('h-10 border-border/40', p.isUser && 'bg-primary/10 hover:bg-primary/10')}
              >
                <TableCell className="text-center text-xs font-semibold tabular">{i + 1}</TableCell>
                <TableCell className={cn('text-xs', p.isUser && 'font-bold text-primary')}>
                  {p.name}
                </TableCell>
                <TableCell>
                  <span className="flex items-center gap-1.5">
                    <TeamCrest
                      shortName={p.teamShort}
                      colorPrimary={p.colorPrimary}
                      colorSecondary={p.colorSecondary}
                      size="sm"
                      title={p.teamName}
                    />
                    <span className="truncate text-xs text-muted-foreground">{p.teamName}</span>
                  </span>
                </TableCell>
                <TableCell className="text-center text-xs tabular text-muted-foreground">{p.apps}</TableCell>
                <TableCell className="text-center text-xs font-bold tabular">
                  {valueLabel === 'Голы' ? p.goals : p.assists}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </motion.div>
  );
}

/** Экран «Лига»: таблица, календарь туров, бомбардиры, пасы. */
export function LeagueScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { leaders } = snapshot;

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Лига"
        subtitle={`${snapshot.save.league.flag} ${snapshot.save.league.nameRu} · таблица, календарь и лидеры`}
      />
      <Tabs defaultValue="table">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="table" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Table2 className="size-4" aria-hidden />
            Таблица
          </TabsTrigger>
          <TabsTrigger value="calendar" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <CalendarDays className="size-4" aria-hidden />
            Календарь
          </TabsTrigger>
          <TabsTrigger value="scorers" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Goal className="size-4" aria-hidden />
            Бомбардиры
          </TabsTrigger>
          <TabsTrigger value="assists" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Handshake className="size-4" aria-hidden />
            Пасы
          </TabsTrigger>
        </TabsList>
        <TabsContent value="table">
          <StandingsTable />
        </TabsContent>
        <TabsContent value="calendar">
          <Calendar />
        </TabsContent>
        <TabsContent value="scorers">
          <LeadersTable title="Бомбардиры" icon={Goal} rows={leaders.topScorers} valueLabel="Голы" />
        </TabsContent>
        <TabsContent value="assists">
          <LeadersTable title="Ассистенты" icon={Handshake} rows={leaders.topAssists} valueLabel="Пасы" />
        </TabsContent>
      </Tabs>
    </div>
  );
}

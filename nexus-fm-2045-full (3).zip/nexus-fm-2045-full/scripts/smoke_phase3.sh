#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Smoke-тест Фазы 3, Блок A (Task P3-3): контракты, академия, правление,
# история игроков, сезонный переход. Запуск: bash scripts/smoke_phase3.sh
# Требует: работающий dev-сервер на :3000, jq, bun, python3.
# Идемпотентен: чистит ТОЛЬКО свои тест-сейвы «P3-Smoke RPL» (демо-сейвы
# «Барселона» и пр. не удаляет; для легаси-проверки проигрывает одну неделю).
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000/api/game"
DBC="bun scripts/phase3_db_check.ts"
TMP=$(mktemp -d)
PASS=0
FAIL=0

ok()  { PASS=$((PASS + 1)); echo "  ✔ $*"; }
bad() { FAIL=$((FAIL + 1)); echo "  ✘ $*"; }
section() { echo; echo "── $* ─────────────────────────────────"; }

# HTTP-хелпер: method url [json-body] → BODY, CODE
call() {
  local method="$1" url="$2" body="${3:-}"
  if [ -n "$body" ]; then
    BODY=$(curl -s -m 180 -w $'\n%{http_code}' -X "$method" -H 'Content-Type: application/json' -d "$body" "$url")
  else
    BODY=$(curl -s -m 180 -w $'\n%{http_code}' -X "$method" "$url")
  fi
  CODE=$(echo "$BODY" | tail -n1)
  BODY=$(echo "$BODY" | sed '$d')
}

check() { # check "описание" "jq-expr" "ожидание" — по последнему BODY
  local desc="$1" expr="$2" expected="$3"
  local actual
  actual=$(echo "$BODY" | jq -r "$expr" 2>/dev/null)
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"
  else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}

check_eq() { # check_eq "описание" "фактическое" "ожидание" — по переменным
  local desc="$1" actual="$2" expected="$3"
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"
  else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}

check_code() { # check_code "описание" "код"
  if [ "$CODE" = "$2" ]; then ok "$1 (HTTP $CODE)"
  else bad "$1: ожидался HTTP $2, получен $CODE"; fi
}

dbq() { # dbq <saveId> <команда> <season> <ключ> → значение из БД
  local saveId="$1" cmd="$2" season="$3" key="$4"
  $DBC "$cmd" "$saveId" "$season" 2>/dev/null | grep "^${key}=" | head -n1 | cut -d= -f2
}

# ── 0. Очистка только СВОИХ тест-сейвов ────────────────────────────────────
section "0. Очистка тест-сейвов P3-Smoke (демо-карьеры не трогаем)"

call GET "$BASE/saves"
check_code "GET /saves" 200
SAVES_BODY="$BODY" # список карьер — ДО цикла удалений (BODY перезаписывается DELETE)
for sid in $(echo "$SAVES_BODY" | jq -r '.saves[] | select(.careerName=="P3-Smoke RPL" or .careerName=="P3-Smoke Legacy") | .id'); do
  call DELETE "$BASE/saves/$sid"
  if [ "$CODE" = "200" ]; then ok "удалён тест-сейв $sid"; else bad "не удалось удалить $sid (HTTP $CODE)"; fi
done
LEGACY_BARCA=$(echo "$SAVES_BODY" | jq -r '.saves[] | select(.careerName=="Каталония навсегда") | .id' | head -n1)
DEMO_COUNT=$(echo "$SAVES_BODY" | jq -r '[.saves[] | select(.careerName!="P3-Smoke RPL" and .careerName!="P3-Smoke Legacy")] | length')
echo "  … демо-карьер сохранено: $DEMO_COUNT (легаси «Барселона»: ${LEGACY_BARCA:+найдена})"

# ── 1. Легаси-сейв «Барселона»: ТОЛЬКО ЧТЕНИЕ (недели НЕ симулируем) ───────
section "1. Легаси-сейв Фазы 2 жив: GET /state (read-only, без simulate)"

if [ -n "$LEGACY_BARCA" ]; then
  call GET "$BASE/state?saveId=$LEGACY_BARCA"
  check_code "GET /state легаси-сейва" 200
  check "status active" '.snapshot.save.status' 'active'
  check "правление в снапшоте (цель задана)" '.snapshot.board.target != null' 'true'
  check "confidence 0..100" '.snapshot.board.confidence >= 0 and .snapshot.board.confidence <= 100' 'true'
  check "contractsExpiring присутствует" '(.snapshot.contractsExpiring | type)' 'array'
  LEGACY_SEASON=$(echo "$BODY" | jq -r '.snapshot.save.season')
  BT=$(dbq "$LEGACY_BARCA" save "$LEGACY_SEASON" save_board_target)
  if [ -n "$BT" ] && [ "$BT" != "null" ]; then ok "boardTarget сейва задан → $BT (ленивая инициализация сработала ранее)"; else bad "boardTarget не задан"; fi
  HW=$(dbq "$LEGACY_BARCA" save "$LEGACY_SEASON" save_honeymoon_until)
  if [ -n "$HW" ] && [ "$HW" != "null" ]; then ok "honeymoonUntilWeek задан → $HW"; else bad "honeymoonUntilWeek не задан"; fi
  MIG=$(dbq "$LEGACY_BARCA" mig "$LEGACY_SEASON" stale_contracts)
  check_eq "легаси-контракты в порядке (contractUntil ≥ сезона)" "$MIG" "0"
else
  bad "легаси-сейв «Барселона» не найден — проверка пропущена"
fi

# ── 1b. Легаси-путь на СОБСТВЕННОМ сейве: ленивая миграция + инициализация ──
section "1b. Легаси-фолбэк: даунгрейд своего сейва → simulate → миграция"

call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":3,"managerName":"Legacy Проверка","careerName":"P3-Smoke Legacy"}'
check_code "POST /saves (легаси-тест)" 200
LEGACY_OWN=$(echo "$BODY" | jq -r '.saveId')
if [ -n "$LEGACY_OWN" ] && [ "$LEGACY_OWN" != "null" ]; then
  DOWNGRADED=$($DBC downgrade "$LEGACY_OWN" 2>/dev/null | grep '^stale_set=' | cut -d= -f2)
  ok "сейв даунгрейднут до Фазы 2: «протухших» контрактов $DOWNGRADED, правление сброшено"
  call POST "$BASE/simulate" "{\"saveId\":\"$LEGACY_OWN\"}"
  check_code "POST /simulate легаси-недели" 200
  check "board в payload недели" '.result.board != null' 'true'
  check "sacked=false" '.result.sacked' 'false'
  BT2=$(dbq "$LEGACY_OWN" save 1 save_board_target)
  if [ -n "$BT2" ] && [ "$BT2" != "null" ]; then ok "ленивая инициализация boardTarget → $BT2"; else bad "boardTarget не записан после недели"; fi
  HW2=$(dbq "$LEGACY_OWN" save 1 save_honeymoon_until)
  if [ -n "$HW2" ] && [ "$HW2" != "null" ]; then ok "honeymoonUntilWeek записан → $HW2 (week+8)"; else bad "honeymoonUntilWeek не записан"; fi
  MIG2=$(dbq "$LEGACY_OWN" mig 1 stale_contracts)
  check_eq "ленивая миграция: протухших контрактов не осталось" "$MIG2" "0"
  call GET "$BASE/state?saveId=$LEGACY_OWN"
  check_code "GET /state после легаси-недели" 200
else
  bad "легаси-тест-сейв не создан"
fi

# ── 2. Создание тестовой карьеры (РПЛ, «Зенит») ───────────────────────────
section "2. POST /saves — новая карьера с правлением и контрактами"

call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":1,"managerName":"Smoke Тестер","careerName":"P3-Smoke RPL"}'
check_code "POST /saves" 200
SAVE=$(echo "$BODY" | jq -r '.saveId')
check "карьера создана" '.saveId != null and .ok' 'true'
check "клуб — Зенит" '.club.shortName' 'ZEN'

call GET "$BASE/state?saveId=$SAVE"
check_code "GET /state" 200
check "цель правления в снапшете" '.snapshot.board.target != null' 'true'
check "confidence старта 55" '.snapshot.board.confidence' '55'
check "медовый месяц (7 недель осталось на неделе 1)" '.snapshot.board.honeymoonWeeksLeft' '7'
check "jobStatus задан" '.snapshot.board.jobStatus != null' 'true'
check "welcome-новость с целью правления" '([.snapshot.news[] | select(.message | contains("Правление:"))] | length) > 0' 'true'
check "у всех игроков contractUntil 1–4" '([.snapshot.myPlayers[] | select(.contractUntil >= 1 and .contractUntil <= 4)] | length) == (.snapshot.myPlayers | length)' 'true'
check "avgRating=null в сезоне 1" '[.snapshot.myPlayers[0].avgRating, .snapshot.myPlayers[1].avgRating] | all(. == null)' 'true'

CONTRACT_DIST_OK=$(echo "$BODY" | jq -r '
  [.snapshot.myPlayers[].contractUntil] |
  {y1: (map(select(.==1))|length), y2: (map(select(.==2))|length), y3: (map(select(.==3))|length), y4: (map(select(.==4))|length)} |
  (.y1 >= 1 and .y2 >= 1 and .y3 >= 1 and .y4 >= 1)')
check_eq "распределение сроков 1–4 года (инвариант №2)" "$CONTRACT_DIST_OK" "true"

# ── 3. Недели 1–4: рейтинг матчей + академия в неделю 4 ───────────────────
section "3. Недели 1–4: рейтинг стартёров, академия недели 4"

for w in 1 2 3 4; do
  call POST "$BASE/simulate" "{\"saveId\":\"$SAVE\"}"
  check_code "неделя $w" 200
  check "board в payload недели $w (0..100)" '.result.board.confidence >= 0 and .result.board.confidence <= 100' 'true'
  if [ "$w" = "4" ]; then
    check "новости академии в неделю 4" '([.result.news[] | select(.type=="academy")] | length) > 0' 'true'
  fi
done

RATE_AVG=$(dbq "$SAVE" prestats 1 players_avg_rating)
RATE_CNT=$(dbq "$SAVE" prestats 1 players_rated)
if [ "${RATE_CNT:-0}" -gt 0 ] 2>/dev/null; then ok "рейтинг получили $RATE_CNT игроков (после 4 недель)"; else bad "ни один игрок не получил рейтинг"; fi
RATE_OK=$(python3 -c "print('true' if 6.0 <= float('${RATE_AVG:-0}') <= 7.6 else 'false')" 2>/dev/null)
check_eq "средний рейтинг клуба $RATE_AVG ∈ [6.0, 7.6]" "$RATE_OK" "true"

AI_CNT=$(dbq "$SAVE" academy 1 academy_intake_count)
AI_AGES=$(dbq "$SAVE" academy 1 academy_ages_ok)
AI_OVR=$(dbq "$SAVE" academy 1 academy_ovr_ok)
AI_TEAM=$(dbq "$SAVE" academy 1 academy_with_team)
if [ "${AI_CNT:-0}" -ge 2 ] 2>/dev/null; then ok "набор академии: $AI_CNT воспитанников (≥ 2)"; else bad "набор академии мал: $AI_CNT"; fi
check_eq "возраст воспитанников 16–17" "$AI_AGES" "true"
check_eq "OVR воспитанников 34–52" "$AI_OVR" "true"
check_eq "все воспитанники в клубе" "$AI_TEAM" "$AI_CNT"

call GET "$BASE/academy?saveId=$SAVE"
check_code "GET /academy" 200
check "воспитанники в ответе (≥ 2)" '.graduates | length >= 2' 'true'
check "звёзды 1..5" '[.graduates[].stars] | all(. >= 1 and . <= 5)' 'true'
check "контракты выпускников до сезона 3" '[.graduates[].contractUntil] | all(. == 3)' 'true'

# ── 4. Контракты: список, продление (counter и accepted) ───────────────────
section "4. GET /contracts + POST /contracts/renew"

call GET "$BASE/contracts?saveId=$SAVE"
check_code "GET /contracts" 200
check "сезон 1" '.season' '1'
check "список контрактов непуст" '.contracts | length > 0' 'true'
check "yearsLeft 0..4 у всех" '[.contracts[].yearsLeft] | all(. >= 0 and . <= 4)' 'true'
RENEWABLE=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable==true and .demand != null)] | sort_by(.age) | .[0].playerId // empty')
DEMAND=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable==true and .demand != null)] | sort_by(.age) | .[0].demand // empty')
MAX_YEARS=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable==true and .demand != null)] | sort_by(.age) | .[0].maxRenewYears // 0')
RENEW_YEARS=$(( MAX_YEARS < 3 ? MAX_YEARS : 3 ))
EXPECTED_UNTIL=$(( 1 + RENEW_YEARS ))
if [ -n "$RENEWABLE" ] && [ "$RENEWABLE" != "null" ]; then
  ok "найден продлеваемый игрок (demand=$DEMAND, maxRenewYears=$MAX_YEARS)"
  # контрпредложение: 80% спроса (< 0.92 × demand)
  LOW=$(python3 -c "print(int($DEMAND * 0.8 // 100) * 100)")
  call POST "$BASE/contracts/renew" "{\"saveId\":\"$SAVE\",\"playerId\":\"$RENEWABLE\",\"years\":$RENEW_YEARS,\"salary\":$LOW}"
  check_code "POST /renew (низкое предложение)" 200
  check "outcome=counter" '.outcome' 'counter'
  check "demand возвращён" '.demand' "$DEMAND"
  # принятие: ровно demand
  call POST "$BASE/contracts/renew" "{\"saveId\":\"$SAVE\",\"playerId\":\"$RENEWABLE\",\"years\":$RENEW_YEARS,\"salary\":$DEMAND}"
  check_code "POST /renew (по спросу)" 200
  check "outcome=accepted" '.outcome' 'accepted'
  check "снапшот возвращён" '.snapshot != null' 'true'
  call GET "$BASE/contracts?saveId=$SAVE"
  CU_NEW=$(echo "$BODY" | jq -r ".contracts[] | select(.playerId==\"$RENEWABLE\") | .contractUntil")
  check_eq "контракт продлён до сезона $EXPECTED_UNTIL (S+$RENEW_YEARS)" "$CU_NEW" "$EXPECTED_UNTIL"
  # повторное продление — уже нельзя (yearsLeft > 2)
  call POST "$BASE/contracts/renew" "{\"saveId\":\"$SAVE\",\"playerId\":\"$RENEWABLE\",\"years\":1,\"salary\":$DEMAND}"
  check_code "повторное продление → 400" 400
  check "код CONTRACT_NOT_RENEWABLE" '.error' 'CONTRACT_NOT_RENEWABLE'
else
  bad "в составе нет продлеваемых игроков (yearsLeft ≤ 2) — выборка странная"
fi

# негативные проверки
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SAVE\",\"playerId\":\"no-such-player\",\"years\":2,\"salary\":5000}"
check_code "чужой игрок → 404" 404
check "код NOT_YOUR_PLAYER" '.error' 'NOT_YOUR_PLAYER'
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SAVE\",\"playerId\":\"$RENEWABLE\",\"years\":9,\"salary\":100000}"
check_code "years=9 → 400" 400
call GET "$BASE/contracts?saveId=no-such-save"
check_code "GET /contracts несуществующий сейв → 404" 404

# ── 5. Правление: GET /board ───────────────────────────────────────────────
section "5. GET /board — цель, confidence, статус"

call GET "$BASE/board?saveId=$SAVE"
check_code "GET /board" 200
check "цель задана" '.board.target != null' 'true'
check "метка цели на русском" '.board.targetLabel != ""' 'true'
check "confidence 0..100" '.board.confidence >= 0 and .board.confidence <= 100' 'true'
check "статус должности задан" '.board.jobStatusLabel != ""' 'true'
check "новости типа board — массив" '(.news | type)' 'array'

# ── 6. GET /player: история пустая в сезоне 1 ──────────────────────────────
section "6. GET /player — история пуста в сезоне 1"

PLAYER1=$(curl -s "$BASE/state?saveId=$SAVE" | jq -r '[.snapshot.myPlayers[] | select(.age <= 27 and .apps > 0)] | .[0].id // .snapshot.myPlayers[0].id')
call GET "$BASE/player?saveId=$SAVE&id=$PLAYER1"
check_code "GET /player" 200
check "карточка игрока возвращена" '.dialog.player.id' "$PLAYER1"
check "история пуста в сезоне 1" '.dialog.history | length' '0'
check "итоги: сезонов 0" '.dialog.totals.seasons' '0'
call GET "$BASE/player?saveId=$SAVE&id=no-such-player"
check_code "несуществующий игрок → 404" 404
check "код PLAYER_NOT_FOUND" '.error' 'PLAYER_NOT_FOUND'

# ── 7. Полный сезон → переход (недели 5–34) ────────────────────────────────
section "7. Полный сезон: недели 5–34 и сезонный переход"

TRANSITION_OK=yes
VERDICT="none"
for w in $(seq 5 34); do
  if [ "$w" = "34" ]; then
    # снимки ДО перехода: id+goals всех игроков (инвариант №5) + id для проверки клонов
    $DBC preids "$SAVE" 2>/dev/null | grep -v '^$' > "$TMP/pre_goals.txt"
    $DBC allids "$SAVE" 2>/dev/null | tail -n1 > "$TMP/allids_before.txt"
    echo "  … игроков в сейве до перехода: $(wc -l < "$TMP/pre_goals.txt")"
  fi
  call POST "$BASE/simulate" "{\"saveId\":\"$SAVE\"}"
  if [ "$CODE" != "200" ]; then
    bad "неделя $w: HTTP $CODE — $(echo "$BODY" | head -c 200)"
    TRANSITION_OK=no
    break
  fi
  if [ "$w" = "34" ]; then
    check "неделя 34: сезонный переход в ответе" '.result.seasonEnded != null' 'true'
    check "вердикт правления в seasonEnded" '.result.seasonEnded.boardVerdict != null' 'true'
    VERDICT=$(echo "$BODY" | jq -r '.result.seasonEnded.boardVerdict.code')
    ok "вердикт правления: $VERDICT («$(echo "$BODY" | jq -r '.result.seasonEnded.boardVerdict.label')», место $(echo "$BODY" | jq -r '.result.seasonEnded.place'))"
    check "награды сезона в ответе (8)" '.result.seasonEnded.awards | length >= 6' 'true'
    check "sacked=false в payload" '.result.sacked' 'false'
  fi
done
if [ "$TRANSITION_OK" = "yes" ]; then ok "недели 5–34 симулированы без ошибок"; fi

S_STATUS=$(dbq "$SAVE" save 1 save_status)
S_SEASON=$(dbq "$SAVE" save 1 save_season)
S_WEEK=$(dbq "$SAVE" save 1 save_week)
check_eq "сезон 2 начался" "$S_SEASON" "2"
check_eq "неделя 1 сезона 2" "$S_WEEK" "1"
check_eq "карьера активна (не уволен)" "$S_STATUS" "active"

# Снапшот истории: снят ДО старения и ДО сброса статов (инвариант №5; записи
# пенсионеров/дренажа удаляются каскадом вместе с игроками — намеренно, §1.3 ТЗ;
# финальная неделя играется в том же запросе, поэтому сверка — по монотонности
# goals/apps и равенству возраста, а не по суммам)
SNAPCHK=$($DBC snapshotcheck "$SAVE" 1 "$TMP/pre_goals.txt" 2>/dev/null)
REC_CNT=$(echo "$SNAPCHK" | grep '^records=' | cut -d= -f2)
REC_CNT=${REC_CNT:-$(dbq "$SAVE" snapshot 1 records)}
if [ "${REC_CNT:-0}" -ge 300 ] 2>/dev/null; then ok "PlayerSeasonRecord сезона 1: $REC_CNT строк (все игроки сейва)"; else bad "PlayerSeasonRecord сезона 1: $REC_CNT строк (мало)"; fi
GOALS_MATCH=$(echo "$SNAPCHK" | grep '^goals_match=' | cut -d= -f2)
check_eq "инвариант №5: снапшот до сброса (возраст равен, goals/apps не убывали)" "$GOALS_MATCH" "true"
GONE_CNT=$(echo "$SNAPCHK" | grep '^players_gone=' | cut -d= -f2)
MISSING_CNT=$(echo "$SNAPCHK" | grep '^missing=' | cut -d= -f2)
check_eq "у каждого пережившего переход игрока есть запись истории" "$MISSING_CNT" "0"
echo "  … покинули сейв (пенсии/дренаж, записи ушли каскадом): ${GONE_CNT:-0}; записей goals: $(echo "$SNAPCHK" | grep '^records_goals=' | cut -d= -f2), матчей: $(echo "$SNAPCHK" | grep '^match_goals=' | cut -d= -f2)"
STATS_RESET=$(dbq "$SAVE" reset 1 stats_not_reset)
check_eq "статистика сезона сброшена у всех клубных игроков" "$STATS_RESET" "0"
REC_RATING=$(dbq "$SAVE" snapshot 1 records_avg_rating)
REC_RATING_OK=$(python3 -c "print('true' if 6.0 <= float('${REC_RATING:-0}') <= 7.6 else 'false')" 2>/dev/null)
check_eq "средний рейтинг записей $REC_RATING ∈ [6.0, 7.6]" "$REC_RATING_OK" "true"

# Контракты: истечения → free-листинги, переживают регенерацию
FREE_LIST=$(dbq "$SAVE" contracts 1 free_listings)
if [ "${FREE_LIST:-0}" -ge 1 ] 2>/dev/null; then ok "истёкшие контракты → free-листинги: $FREE_LIST (регенерация не погасила — инвариант №4)"; else bad "free-листингов нет (истечений не было?)"; fi
PREC_CNT=$(dbq "$SAVE" contracts 1 precontracts)
check_eq "предконтракты исполнены (остаток 0)" "$PREC_CNT" "0"
call GET "$BASE/market?saveId=$SAVE"
check_code "GET /market после перехода" 200
FREE_ON_MARKET=$(echo "$BODY" | jq -r '[.listings[] | select(.source=="free")] | length')
if [ "${FREE_ON_MARKET:-0}" -ge 1 ] 2>/dev/null; then ok "free-лоты видны на рынке: $FREE_ON_MARKET"; else bad "free-лоты на рынке не видны"; fi
FREE_TTL_OK=$(echo "$BODY" | jq -r '[.listings[] | select(.source=="free") | .expiresAt] | all(. >= 1 and . <= 8)')
check_eq "TTL free-лотов 1..8" "$FREE_TTL_OK" "true"
FREE_PRICE_OK=$(echo "$BODY" | jq -r '[.listings[] | select(.source=="free") | .price >= 10000] | all')
check_eq "цена free-лотов ≥ €10 000" "$FREE_PRICE_OK" "true"

# Клоны-пенсионеры не генерируются
NEW_TEAM=$($DBC newteam "$SAVE" "$TMP/allids_before.txt" 2>/dev/null | grep '^new_team_players=' | cut -d= -f2)
check_eq "инвариант №7: новых клубных игроков в переходе 0 (клоны удалены)" "$NEW_TEAM" "0"

# Guard состава ИИ
AI_MIN=$(dbq "$SAVE" ai 1 ai_min_squad)
AI_BELOW=$(dbq "$SAVE" ai 1 ai_below_15)
if [ "${AI_MIN:-0}" -ge 15 ] 2>/dev/null; then ok "guard состава ИИ: минимум $AI_MIN игроков"; else bad "ИИ-клуб с $AI_MIN игроками (< 15)"; fi
check_eq "ни один ИИ-клуб не ниже 15 игроков (инвариант №20)" "$AI_BELOW" "0"

# Премия правления при перевыполнении
BONUS=$(dbq "$SAVE" bonus 1 board_bonus)
if [ "$VERDICT" = "over" ]; then
  check_eq "премия €2 000 000 за перевыполнение" "$BONUS" "2000000"
else
  ok "вердикт '$VERDICT' — премии нет ($BONUS)"
fi

# История игрока после перехода
call GET "$BASE/player?saveId=$SAVE&id=$PLAYER1"
check_code "GET /player после перехода" 200
HIST_LEN=$(echo "$BODY" | jq -r '.dialog.history | length')
check_eq "история игрока: 1 запись сезона" "$HIST_LEN" "1"
HIST_APPS=$(echo "$BODY" | jq -r '.dialog.totals.apps // 0')
if [ "${HIST_APPS:-0}" -gt 0 ] 2>/dev/null; then ok "итоги карьеры: матчей $HIST_APPS"; else bad "итоги карьеры пусты"; fi
HIST_RATING=$(echo "$BODY" | jq -r '.dialog.history[0].avgRating // "null"')
ok "avgRating записи сезона 1: $HIST_RATING"

# ── 8. Сезон 2: медовый месяц + академия недели 4 ──────────────────────────
section "8. Сезон 2: цель/confidence обновлены, академия недели 4"

BT2=$(dbq "$SAVE" save 1 save_board_target)
if [ -n "$BT2" ] && [ "$BT2" != "null" ]; then ok "цель сезона 2 зафиксирована: $BT2"; else bad "boardTarget сезона 2 не записан"; fi
HW2=$(dbq "$SAVE" save 1 save_honeymoon_until)
check_eq "медовый месяц сезона 2 (8 недель)" "$HW2" "8"

for w in 1 2 3 4; do
  call POST "$BASE/simulate" "{\"saveId\":\"$SAVE\"}"
  check_code "сезон 2, неделя $w" 200
done
AI2_CNT=$(dbq "$SAVE" academy 2 academy_intake_count)
if [ "${AI2_CNT:-0}" -ge 2 ] 2>/dev/null; then ok "академия сезона 2: набор $AI2_CNT воспитанников (контракт до 4)"; else bad "набор академии сезона 2: $AI2_CNT"; fi
call GET "$BASE/academy?saveId=$SAVE"
check "контракты набора сезона 2 — до сезона 4" '[.graduates[] | select(.contractUntil==4)] | length >= 2' 'true'

call GET "$BASE/state?saveId=$SAVE"
check_code "GET /state (сезон 2)" 200
check "сезон 2 в снапшоте" '.snapshot.save.season' '2'
check "правление в снапшоте" '.snapshot.board.target != null' 'true'
check "contractsExpiring в снапшоте" '(.snapshot.contractsExpiring | type)' 'array'
CE=$(echo "$BODY" | jq -r '.snapshot.contractsExpiring | length')
ok "истекающих контрактов в снапшоте: $CE"

# ── 9. Уборка ──────────────────────────────────────────────────────────────
section "9. Уборка тест-сейвов"

call DELETE "$BASE/saves/$SAVE"
check_code "DELETE тест-сейва" 200
REC_LEFT=$(dbq "$SAVE" records 1 records_total)
check_eq "каскад: записей истории тест-сейва не осталось" "$REC_LEFT" "0"
if [ -n "${LEGACY_OWN:-}" ] && [ "$LEGACY_OWN" != "null" ]; then
  call DELETE "$BASE/saves/$LEGACY_OWN"
  check_code "DELETE легаси-тест-сейва" 200
fi
rm -rf "$TMP"

echo
echo "════════════════════════════════════════════════════════════════"
echo "ИТОГ SMOKE PHASE 3: PASS=$PASS FAIL=$FAIL"
echo "════════════════════════════════════════════════════════════════"
[ "$FAIL" = "0" ]

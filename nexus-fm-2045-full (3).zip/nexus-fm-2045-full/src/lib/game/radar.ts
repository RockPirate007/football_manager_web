/**
 * МОДУЛЬ 6 — 2D-радар матча: чистая деривация без React (тестируется scripts/m6_smoke).
 *
 * Мировые координаты (0..100): X — вдоль поля (0 = ворота ХОЗЯЕВ, 100 = ворота
 * ГОСТЕЙ), Y — поперёк (0 = верхняя кромка при взгляде сверху). Движок эмитит
 * события уже в этих координатах (emit() в MatchEngine: хозяева слева→направо).
 * Фишки ставятся по слотам формации: глубина слота (y: 6 — свои ворота, 80+ —
 * чужая штрафная) становится X, ширина слота (x) становится Y. Гости зеркалятся.
 */

import { FORMATIONS } from './constants';
import type { FormationId, MatchEvent, Position, RadarPlayerDTO } from './types';

// ── Координаты фишек ──────────────────────────────────────────────────────

/** Фишка на радаре: мировые координаты + подпись. */
export interface RadarChip {
  key: string;
  slot: number;
  playerId: string | null;
  name: string;
  short: string;
  position: Position;
  number: number | null;
  /** База формации (без сдвига к мячу). */
  baseX: number;
  baseY: number;
  side: 'home' | 'away';
}

/** Слоты формации → мировые координаты фишек команды. */
export function formationChips(
  formation: FormationId,
  xi: RadarPlayerDTO[],
  side: 'home' | 'away',
): RadarChip[] {
  const slots = FORMATIONS[formation].slots;
  const chips: RadarChip[] = [];
  for (let i = 0; i < slots.length && i < xi.length; i++) {
    const slot = slots[i];
    const p = xi[i];
    // Глубина слота (y: 0 свои → 100 чужие) → X мира; ширина (x) → Y.
    const depth = slot.y;
    const width = slot.x;
    const x = side === 'home' ? depth : 100 - depth;
    const y = side === 'home' ? width : 100 - width;
    chips.push({
      key: `${side}-${i}`,
      slot: i,
      playerId: p.playerId,
      name: p.name,
      short: shortNameOf(p.name),
      position: p.position ?? slot.position,
      number: p.number,
      baseX: clamp(x, 3, 97),
      baseY: clamp(y, 4, 96),
      side,
    });
  }
  return chips;
}

/** Короткая подпись фишки: «И. Петров» → «Петров», «Cristiano Ronaldo» → «Ronaldo». */
export function shortNameOf(fullName: string): string {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 0) return '—';
  if (parts.length === 1) return parts[0].slice(0, 12);
  return parts[parts.length - 1].slice(0, 14);
}

// ── Сдвиг блока к мячу ────────────────────────────────────────────────────

/**
 * Модель «живого поля»: блок команды тянетcя к мячу. Сдвиг по X — четверть
 * дистанции (линия подъезжает/откатывается), по Y — лёгкое тяготение коридора.
 * GK почти не двигается; красная карточка гасит фишку (sent off).
 */
export function shiftedChip(chip: RadarChip, ballX: number, ballY: number, sentOff: boolean): RadarChip {
  if (chip.position === 'GK') {
    return { ...chip, baseX: sentOff ? chip.baseX : chip.baseX, baseY: chip.baseY };
  }
  const kx = 0.22;
  const ky = 0.1;
  const x = sentOff ? chip.baseX : clamp(chip.baseX + (ballX - chip.baseX) * kx, 3, 97);
  const y = sentOff ? chip.baseY : clamp(chip.baseY + (ballY - chip.baseY) * ky, 4, 96);
  return { ...chip, baseX: x, baseY: y };
}

// ── Мяч ───────────────────────────────────────────────────────────────────

/** Типы событий, двигающие мяч (перевод владения/зона). */
const BALL_MOVERS = new Set<string>([
  'chance', 'duel', 'corner', 'offside', 'momentum',
]);

/** События, рисующие маркер на радаре (с координатами). */
export type MarkerTone = 'goal' | 'shot' | 'card' | 'neutral';

export interface RadarMarker {
  id: string;
  minute: number;
  type: string;
  tone: MarkerTone;
  x: number;
  y: number;
  label: string;
}

/** Позиция мяча и маркеры по событиям ≤ liveMinute. */
export interface RadarState {
  ballX: number;
  ballY: number;
  /** Шлейф мяча: последние позиции (старые → новые). */
  trail: Array<{ x: number; y: number }>;
  /** Маркеры последних секунд (ttl — тики минут). */
  markers: RadarMarker[];
  /** Последнее «значимое» событие (комментарий под радаром). */
  lastLine: MatchEvent | null;
  /** playerId последнего события (подсветка фишки). */
  hotPlayerId: string | null;
}

const EMPTY: RadarState = {
  ballX: 50,
  ballY: 50,
  trail: [],
  markers: [],
  lastLine: null,
  hotPlayerId: null,
};

const TONE_OF: Record<string, MarkerTone> = {
  goal: 'goal',
  pen_goal: 'goal',
  pen_miss: 'shot',
  pen_save: 'shot',
  shot_on: 'shot',
  shot_off: 'shot',
  save: 'shot',
  chance: 'shot',
  yellow: 'card',
  red: 'card',
  injury: 'card',
  corner: 'neutral',
  offside: 'neutral',
  duel: 'neutral',
};

const MARKER_LABELS: Record<string, string> = {
  goal: 'ГОЛ',
  pen_goal: 'ГОЛ (пен.)',
  pen_miss: 'Мимо (пен.)',
  pen_save: 'Сейв (пен.)',
  shot_on: 'Удар',
  shot_off: 'Мимо',
  save: 'Сейв',
  chance: 'Момент',
  yellow: 'ЖК',
  red: 'КК',
  injury: 'Травма',
  corner: 'Угл.',
  offside: 'Офс.',
  duel: 'Дуэль',
};

/**
 * Полное состояние радара из ленты событий.
 * @param visible события с minute ≤ liveMinute (уже отфильтрованы)
 * @param markerTtl сколько «минут» живёт маркер (2 = текущая + предыдущая)
 */
export function deriveRadar(
  visible: MatchEvent[],
  markerTtl = 2,
): RadarState {
  if (visible.length === 0) return EMPTY;

  let ballX = 50;
  let ballY = 50;
  const trail: Array<{ x: number; y: number }> = [];
  const markers: RadarMarker[] = [];

  for (const e of visible) {
    if (e.type === 'kickoff' || e.type === 'halftime' || e.type === 'fulltime') {
      ballX = 50;
      ballY = 50;
      continue;
    }
    if (e.x === undefined || e.y === undefined) continue;

    // Мяч: события северо-запада ленты (владение/атаки) двигают мяч;
    // карточки/замены — нет (мяч остаётся, маркер рисуем).
    if (BALL_MOVERS.has(e.type) || e.type === 'goal' || e.type === 'pen_goal'
      || e.type === 'shot_on' || e.type === 'shot_off' || e.type === 'save'
      || e.type === 'chance' || e.type === 'pen_miss' || e.type === 'pen_save') {
      ballX = e.x;
      ballY = e.y;
      if (trail.length === 0 || trail[trail.length - 1].x !== e.x || trail[trail.length - 1].y !== e.y) {
        trail.push({ x: e.x, y: e.y });
      }
    }

    const tone = TONE_OF[e.type];
    if (tone !== undefined) {
      markers.push({
        id: `${e.type}-${e.minute}-${e.x}-${e.y}`,
        minute: e.minute,
        type: e.type,
        tone,
        x: e.x,
        y: e.y,
        label: MARKER_LABELS[e.type] ?? e.type,
      });
    }
  }

  // Шлейф — последние 6 точек
  const recentTrail = trail.slice(-6);
  // Маркеры — окно TTL от последнего события с координатой (замены/свистки
  // минуту не двигают). Голы живут дольше (4 мин) — «вспышка» не гаснет сразу.
  const lastCoordMinute = [...visible].reverse().find((e) => e.x !== undefined)?.minute ?? 0;
  const recentMarkers = markers.filter((m) =>
    lastCoordMinute - m.minute < (m.tone === 'goal' ? Math.max(markerTtl, 4) : markerTtl),
  );
  const lastLine = [...visible].reverse().find(
    (e) => e.type !== 'sub' && e.type !== 'momentum',
  ) ?? null;
  const hotPlayerId = lastLine?.playerId ?? null;

  return {
    ballX,
    ballY,
    trail: recentTrail,
    markers: recentMarkers,
    lastLine,
    hotPlayerId,
  };
}

// ── Замены/удаления поверх стартовых XI ───────────────────────────────────

/** Применить sub-события к чипам: subOutId уходит, playerId входит. */
export function applySubs(chips: RadarChip[], visible: MatchEvent[]): RadarChip[] {
  const subs = visible.filter((e) => e.type === 'sub');
  if (subs.length === 0) return chips;
  return chips.map((chip) => {
    for (const s of subs) {
      if (s.subOutId && chip.playerId === s.subOutId) {
        return {
          ...chip,
          playerId: s.playerId ?? null,
          name: s.playerName ?? chip.name,
          short: s.playerName ? shortNameOf(s.playerName) : chip.short,
        };
      }
    }
    return chip;
  });
}

/** id игроков, удалённых к минуте (красная карточка). */
export function sentOffIds(visible: MatchEvent[]): Set<string> {
  const out = new Set<string>();
  for (const e of visible) {
    if (e.type === 'red' && e.playerId) out.add(e.playerId);
    // Замена после красной сносит playerId фишки — карточка остаётся в истории,
    // но на поле игрока уже нет: помечаем и вышедшего.
    if (e.type === 'sub' && e.subOutId && out.has(e.subOutId)) out.delete(e.subOutId);
  }
  return out;
}

// ── Контраст цветов команд ────────────────────────────────────────────────

/** HEX → [r,g,b] (0 при мусоре — фишка сама даст фон по умолчанию). */
function hexToRgb(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const n = Number.parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/** Цветовая дистанция (0..441): близкие формы неразличимы. */
export function colorDistance(a: string, b: string): number {
  const ca = hexToRgb(a);
  const cb = hexToRgb(b);
  if (!ca || !cb) return 441;
  return Math.sqrt(
    (ca[0] - cb[0]) ** 2 + (ca[1] - cb[1]) ** 2 + (ca[2] - cb[2]) ** 2,
  );
}

/**
 * Цвет формы гостей: если primary конфликтует с primary хозяев (дистанция < 90),
 * берём colorSecondary гостей, иначе primary.
 */
export function awayKitOf(
  homePrimary: string,
  awayPrimary: string,
  awaySecondary: string,
): string {
  return colorDistance(homePrimary, awayPrimary) < 90 ? awaySecondary : awayPrimary;
}

// ── Утилита ───────────────────────────────────────────────────────────────

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

// ── Радар атрибутов игрока (PlayerDialog, FM-стиль) ───────────────────────

import type { Attributes } from './types';

export interface AttrAxis {
  label: string;
  value: number;
}

const FIELD_AXES: Array<{ label: string; keys: Array<keyof Attributes> }> = [
  { label: 'Атака', keys: ['finishing', 'heading'] },
  { label: 'Создание', keys: ['passing', 'vision', 'crossing'] },
  { label: 'Дриблинг', keys: ['dribbling', 'acceleration'] },
  { label: 'Оборона', keys: ['tackling', 'marking', 'positioning'] },
  { label: 'Физика', keys: ['strength', 'stamina', 'jumping', 'pace'] },
  { label: 'Ментал', keys: ['decisions', 'leadership', 'aggression'] },
];

const GK_AXES: Array<{ label: string; keys: Array<keyof Attributes> }> = [
  { label: 'Рефлексы', keys: ['reflexes'] },
  { label: 'Руки', keys: ['handling'] },
  { label: 'Выходы', keys: ['rushingOut'] },
  { label: 'Ввод', keys: ['kicking'] },
  { label: 'Игра ногами', keys: ['passing', 'vision'] },
  { label: 'Характер', keys: ['leadership', 'decisions', 'positioning'] },
];

/**
 * Оси радара атрибутов: 6 нормированных осей (средние групп, 0..20 → 0..100).
 * Вратарь получает свой профиль.
 */
export function attributeRadar(attrs: Attributes, isGk: boolean): AttrAxis[] {
  const axes = isGk ? GK_AXES : FIELD_AXES;
  return axes.map(({ label, keys }) => {
    const vals = keys.map((k) => (attrs[k] as number | undefined) ?? 0);
    const avg = vals.reduce<number>((s, v) => s + v, 0) / Math.max(1, vals.length);
    return { label, value: Math.round(avg * 5) };
  });
}

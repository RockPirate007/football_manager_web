/**
 * Модуль 4 smoke: персонал/рынок труда/индивидуальные тренировки.
 * Юниты чистых функций (staff.ts / staff-market.ts / training.ts) +
 * интеграция через router/db (как S-секции engine-smoke).
 * Запуск: `bun scripts/m4_smoke.ts`.
 */

import { generatePlayer, type PlayerLike } from '@/lib/game/players';
import { mulberry32 } from '@/lib/game/rng';
import {
  neutralStaffEffects, staffRatingDriftOf, staffRoleFull, staffSalaryOf,
  staffTrainingEffectsOf, staffWagesOf, type StaffLikeRecord,
} from '@/lib/game/staff';
import {
  generateStaffMarket, staffFireCompensationOf, staffHireBonusOf,
  staffMarketChurn, staffRenewSalaryOf, validStaffYears,
} from '@/lib/game/staff-market';
import { applyWeeklyTraining } from '@/lib/game/training';
import { engineDispatch } from '@/engine/router';
import { getEngine } from '@/engine/index';

let pass = 0;
let fail = 0;
const failures: string[] = [];

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    pass += 1;
    console.log(`PASS ${name}`);
  } else {
    fail += 1;
    failures.push(name);
    const suffix = detail !== undefined ? ` :: ${detail}` : '';
    console.log(`FAIL ${name}${suffix}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  check(name, actual === expected, `actual=${String(actual)} expected=${String(expected)}`);
}

// патч uuid (как engine-smoke)
let uuidCounter = 0;
crypto.randomUUID = ((): string => {
  uuidCounter += 1;
  return `00000000-0000-4000-8000-${String(uuidCounter).padStart(12, '0')}`;
}) as typeof crypto.randomUUID;

const NOW = new Date('2025-07-01T12:00:00Z');

const mkStaff = (over: Partial<StaffLikeRecord>): StaffLikeRecord => ({
  id: over.id ?? 'st-1',
  saveId: 's1',
  teamId: null,
  role: 'head_coach',
  firstName: 'Иван',
  lastName: 'Тренер',
  nationality: 'RU',
  age: 50,
  rating: 60,
  specialty: null,
  salary: 2400,
  contractUntil: 3,
  ...over,
});

// ── U1: эффекты штата (staff.ts) ──────────────────────────────────────────

console.log('\n== U1: эффекты тренерского штата ==');

const neutral = neutralStaffEffects();
check('u1_neutral_neutral',
  neutral.xpMult === 1 && neutral.injuryRiskMult === 1 && neutral.recoveryBonus === 0
  && neutral.healChance === 0 && neutral.bestScoutRating === null);

const empty = staffTrainingEffectsOf([]);
check('u1_empty_neutral', JSON.stringify(empty) === JSON.stringify(neutral));

const strong = staffTrainingEffectsOf([
  mkStaff({ id: 'c1', role: 'head_coach', rating: 90 }),
  mkStaff({ id: 'a1', role: 'assistant', rating: 88 }),
]);
check('u1_coach_xp_boost', strong.xpMult > 1.05, `xp=${strong.xpMult}`);
check('u1_assistant_youth', strong.youthXpMult > 1.04, `y=${strong.youthXpMult}`);

const weakCoach = staffTrainingEffectsOf([mkStaff({ role: 'head_coach', rating: 30 })]);
check('u1_coach_xp_penalty', weakCoach.xpMult < 1, `xp=${weakCoach.xpMult}`);

const badPhysio = staffTrainingEffectsOf([mkStaff({ role: 'physio', rating: 30 })]);
check('u1_bad_physio_more_injuries', badPhysio.injuryRiskMult > 1, `r=${badPhysio.injuryRiskMult}`);
const goodPhysio = staffTrainingEffectsOf([mkStaff({ role: 'physio', rating: 88 })]);
check('u1_good_physio_less_injuries', goodPhysio.injuryRiskMult < 1, `r=${goodPhysio.injuryRiskMult}`);

const treatPhysio = staffTrainingEffectsOf([mkStaff({ role: 'physio', rating: 70, specialty: 'treatment' })]);
eq('u1_treatment_heal_chance', treatPhysio.healChance, 0.05);

const fitCoach = staffTrainingEffectsOf([mkStaff({ role: 'fitness', rating: 88 })]);
check('u1_fitness_recovery', fitCoach.recoveryBonus >= 2, `rb=${fitCoach.recoveryBonus}`);
const weakFit = staffTrainingEffectsOf([mkStaff({ role: 'fitness', rating: 40 })]);
check('u1_weak_fitness_negative', weakFit.recoveryBonus < 0, `rb=${weakFit.recoveryBonus}`);

const withScout = staffTrainingEffectsOf([
  mkStaff({ role: 'scout', rating: 74 }),
  mkStaff({ role: 'scout', rating: 88 }),
]);
eq('u1_best_scout', withScout.bestScoutRating, 88);

const specCoach = staffTrainingEffectsOf([mkStaff({ role: 'head_coach', rating: 70, specialty: 'tech' })]);
check('u1_specialty_cat_mult', Math.abs(specCoach.catMult.tech - 1.12) < 1e-9, `t=${specCoach.catMult.tech}`);

eq('u1_role_full_head', staffRoleFull('head_coach', 1), true);
eq('u1_role_free_scout2', staffRoleFull('scout', 2), false);
eq('u1_role_full_scout3', staffRoleFull('scout', 3), true);
eq('u1_role_unknown', staffRoleFull('agent', 0), true);

eq('u1_wages_sum', staffWagesOf([
  mkStaff({ salary: 2000 }),
  mkStaff({ salary: 1500 }),
]), 3500);

eq('u1_salary_of_rating90', staffSalaryOf(90), 3600);
check('u1_salary_floor', staffSalaryOf(5) >= 600);

// дрейф рейтинга: молодые 0..+2, старые −3..0
{
  const rng = mulberry32(9);
  let youngMin = 9;
  let youngMax = -9;
  let oldMin = 9;
  let oldMax = -9;
  for (let i = 0; i < 200; i++) {
    const y = staffRatingDriftOf(rng, 40);
    youngMin = Math.min(youngMin, y);
    youngMax = Math.max(youngMax, y);
    const o = staffRatingDriftOf(rng, 60);
    oldMin = Math.min(oldMin, o);
    oldMax = Math.max(oldMax, o);
  }
  check('u1_drift_young_range', youngMin >= 0 && youngMax <= 2, `${youngMin}..${youngMax}`);
  check('u1_drift_old_range', oldMin >= -3 && oldMax <= 0, `${oldMin}..${oldMax}`);
}

// ── U2: рынок персонала (staff-market.ts) ─────────────────────────────────

console.log('\n== U2: рынок персонала ==');

let idSeq = 0;
const idFactory = () => `mkt-${(idSeq += 1)}`;
const market = generateStaffMarket(mulberry32(42), {
  saveId: 's1', pool: 'RU', idFactory, season: 1,
});
eq('u2_market_size', market.length, 17);
check('u2_market_all_free', market.every((m) => m.teamId === null));
eq('u2_market_head_coaches', market.filter((m) => m.role === 'head_coach').length, 3);
eq('u2_market_scouts', market.filter((m) => m.role === 'scout').length, 5);
check('u2_market_ratings_sane', market.every((m) => m.rating >= 30 && m.rating <= 92));
check('u2_market_ages_sane', market.every((m) => m.age >= 30 && m.age <= 62));
check('u2_market_salary_sane', market.every((m) => m.salary >= 600));

// детерминизм генерации
const market2 = generateStaffMarket(mulberry32(42), {
  saveId: 's1', pool: 'RU', idFactory: () => `mkt2-${(idSeq += 1)}`, season: 1,
});
check('u2_market_deterministic',
  JSON.stringify(market.map(({ id: _drop, ...r }) => r)) === JSON.stringify(market2.map(({ id: _d, ...r }) => r)));

eq('u2_hire_bonus', staffHireBonusOf({ salary: 2500 }), 10_000);
eq('u2_fire_comp_weeks', staffFireCompensationOf({ salary: 2000 }, 10), 20_000);
eq('u2_fire_comp_min', staffFireCompensationOf({ salary: 2000 }, 1), 8000);
eq('u2_renew_salary', staffRenewSalaryOf({ rating: 80, salary: 2000 }), Math.round((3200 * 1.05) / 100) * 100);
check('u2_years_valid', validStaffYears(1) && validStaffYears(3) && !validStaffYears(0) && !validStaffYears(4));

// churn: пул поддерживает целевой размер, детерминирован
const churn1 = staffMarketChurn(mulberry32(5), {
  saveId: 's1', season: 1, pool: 'RU', idFactory: () => `ch-${(idSeq += 1)}`,
  market: market.map((m) => ({ id: m.id, role: m.role })),
});
const stay = market.length - churn1.leavingIds.length;
check('u2_churn_target', stay + churn1.arrivals.length === 17, `stay=${stay} add=${churn1.arrivals.length}`);
check('u2_churn_arrivals_free', churn1.arrivals.every((a) => a.teamId === null));
const churn2 = staffMarketChurn(mulberry32(5), {
  saveId: 's1', season: 1, pool: 'RU', idFactory: () => `cx-${(idSeq += 1)}`,
  market: market.map((m) => ({ id: m.id, role: m.role })),
});
eq('u2_churn_deterministic', JSON.stringify(churn1.leavingIds), JSON.stringify(churn2.leavingIds));

// ── U3: индивидуальные тренировки (training.ts) ───────────────────────────

console.log('\n== U3: индивидуальные программы ==');

const xpSumOf = (p: PlayerLike): number => {
  try {
    const xp = p.trainingXp ? (JSON.parse(p.trainingXp) as Record<string, number>) : {};
    return Object.values(xp).reduce((s, v) => s + v, 0);
  } catch {
    return 0;
  }
};

// игрок A — индивидуальная attack/hard, игрок B — командный rest
const mkPlayer = (seed: number, age: number): PlayerLike => {
  const p = generatePlayer(mulberry32(seed), 60, 'ST', { minAge: age, maxAge: age });
  p.potential = 95;
  p.condition = 80;
  return p;
};
const pa = mkPlayer(101, 19);
const pb = mkPlayer(202, 28);
const reportA = applyWeeklyTraining(mulberry32(77), 'rest', 'normal', [pa, pb], {
  individual: (p) => (p.id === pa.id ? { focus: 'attack', intensity: 'hard' } : null),
});
check('u3_individual_grows', xpSumOf(pa) > 0, `xp=${xpSumOf(pa)}`);
eq('u3_team_rest_no_growth', xpSumOf(pb), 0);
check('u3_team_rest_condition', pb.condition === 90, `c=${pb.condition}`);
check('u3_individual_hard_condition', pa.condition === 72, `c=${pa.condition}`);

// индивидуальный rest при командной атаке
const pc = mkPlayer(303, 25);
applyWeeklyTraining(mulberry32(78), 'attack', 'normal', [pc], {
  individual: () => ({ focus: 'rest', intensity: 'light' }),
});
eq('u3_individual_rest_recovers', pc.condition, 90);

// youthXpMult: одинаковые броски → у молодых xp выше при множителе
const young1 = mkPlayer(404, 19);
const young2 = mkPlayer(404, 19);
applyWeeklyTraining(mulberry32(79), 'physical', 'normal', [young1], { youthXpMult: 1.15 });
applyWeeklyTraining(mulberry32(79), 'physical', 'normal', [young2]);
check('u3_youth_mult_applied', xpSumOf(young1) > xpSumOf(young2) && xpSumOf(young2) > 0,
  `${xpSumOf(young1)} vs ${xpSumOf(young2)}`);

// catMult: специализация phys ×2 удваивает вклад физического атрибута
const p1 = mkPlayer(505, 24);
const p2 = mkPlayer(505, 24);
applyWeeklyTraining(mulberry32(80), 'physical', 'normal', [p1], { catMult: { tech: 1, mental: 1, phys: 2, gk: 1 } });
applyWeeklyTraining(mulberry32(80), 'physical', 'normal', [p2]);
const xp1 = p1.trainingXp ? (JSON.parse(p1.trainingXp) as Record<string, number>) : {};
const xp2 = p2.trainingXp ? (JSON.parse(p2.trainingXp) as Record<string, number>) : {};
check('u3_cat_mult_physical', (xp1.stamina ?? 0) > (xp2.stamina ?? 0) + 0.01,
  `${xp1.stamina} vs ${xp2.stamina}`);

// потолок потенциала не пробивается
const cap = mkPlayer(606, 22);
cap.potential = cap.ovr; // потолок = текущий OVR
applyWeeklyTraining(mulberry32(81), 'attack', 'hard', [cap]);
check('u3_potential_cap', cap.ovr <= cap.potential, `ovr=${cap.ovr} pot=${cap.potential}`);

// вызов БЕЗ М4-опций: поведение как раньше (командный rest → восстановление)
const legacy = mkPlayer(707, 26);
applyWeeklyTraining(mulberry32(82), 'rest', 'normal', [legacy]);
eq('u3_legacy_rest', legacy.condition, 90);

// ── I1: интеграция — карьера, найм/увольнение, финансы, программы ─────────

console.log('\n== I1: интеграция движка ==');

const engine = getEngine();
const created = await engine.createCareer({
  leagueCode: 'RPL',
  clubIndex: 2,
  managerName: 'М4 Смоук',
  seed: 4242,
  now: NOW,
});
check('i1_career_created', created.slot >= 1 && created.saveId.length > 0);

type StaffApi = {
  ok: boolean; season: number; week: number;
  staff: { id: string; role: string; rating: number; salary: number; contractUntil: number; yearsLeft: number }[];
  market: { id: string; role: string; rating: number; salary: number }[];
  effects: { xpMult: number; injuryRiskMult: number; bestScoutRating: number | null; scoutSlots: { used: number; total: number } };
  slots: { role: string; used: number; max: number }[];
  weeklyWages: number; balance: number;
};

const staff1 = (await engineDispatch('GET', '/staff', { saveId: created.saveId })) as StaffApi;
check('i1_staff_initial',
  staff1.ok && staff1.staff.length === 2
  && staff1.staff.some((s) => s.role === 'head_coach') && staff1.staff.some((s) => s.role === 'assistant'),
  `n=${staff1.staff.length}`);
eq('i1_market_initial', staff1.market.length, 17);
check('i1_effects_initial', staff1.effects.xpMult !== 1 || staff1.effects.bestScoutRating === null);
check('i1_slots_declared', staff1.slots.some((s) => s.role === 'scout' && s.max === 3));
check('i1_wages_positive', staff1.weeklyWages > 0, `w=${staff1.weeklyWages}`);

// найм скаута
const scoutCandidate = staff1.market.find((m) => m.role === 'scout');
check('i1_scout_candidate_exists', scoutCandidate !== undefined);
const balanceBefore = staff1.balance;
const hire1 = (await engineDispatch('POST', '/staff/hire', {
  saveId: created.saveId, staffId: scoutCandidate!.id, years: 2,
})) as { ok: boolean; staff: StaffApi; balanceDelta: number };
check('i1_hire_ok', hire1.ok && hire1.staff.staff.length === 3, `n=${hire1.staff.staff.length}`);
check('i1_hire_bonus_charged',
  hire1.balanceDelta === -scoutCandidate!.salary * 4 && hire1.staff.balance === balanceBefore + hire1.balanceDelta,
  `delta=${hire1.balanceDelta}`);
eq('i1_hire_slot_scout', hire1.staff.slots.find((s) => s.role === 'scout')?.used, 1);

// скауты: слоты наблюдения выросли 2 → 4
const scoutSlots = (await engineDispatch('GET', '/scout', { saveId: created.saveId })) as {
  slots: { used: number; total: number };
};
eq('i1_scout_slots_grew', scoutSlots.slots.total, 4);

// гварды
let slotFull = false;
const anotherHead = staff1.market.find((m) => m.role === 'head_coach');
try {
  await engineDispatch('POST', '/staff/hire', { saveId: created.saveId, staffId: anotherHead!.id, years: 1 });
} catch (e) {
  slotFull = (e as { code?: string }).code === 'STAFF_SLOT_FULL';
}
check('i1_hire_slot_full', slotFull);

let alreadyHired = false;
try {
  await engineDispatch('POST', '/staff/hire', { saveId: created.saveId, staffId: scoutCandidate!.id, years: 1 });
} catch (e) {
  alreadyHired = (e as { code?: string }).code === 'STAFF_ALREADY_HIRED';
}
check('i1_hire_already_hired', alreadyHired);

let badYears = false;
try {
  await engineDispatch('POST', '/staff/hire', { saveId: created.saveId, staffId: anotherHead!.id, years: 5 });
} catch (e) {
  badYears = (e as { code?: string }).code === 'INVALID_STAFF_YEARS';
}
check('i1_hire_bad_years', badYears);

// индивидуальная программа
const state0 = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as {
  snapshot: { myPlayers: { id: string; firstName: string }[] };
};
const target = state0.snapshot.myPlayers[0];
const setInd = (await engineDispatch('POST', '/training/player', {
  saveId: created.saveId, playerId: target.id, focus: 'attack', intensity: 'hard',
})) as { ok: boolean; individual: { focus: string; intensity: string } | null };
check('i1_set_individual_ok',
  setInd.ok && setInd.individual?.focus === 'attack' && setInd.individual?.intensity === 'hard');

const training = (await engineDispatch('GET', '/training', { saveId: created.saveId })) as {
  squad: { id: string; individual: { focus: string; intensity: string } | null }[];
};
eq('i1_training_individual_visible', training.squad.find((p) => p.id === target.id)?.individual?.focus, 'attack');

// продление ассистента
const assistant = staff1.staff.find((s) => s.role === 'assistant')!;
const renew = (await engineDispatch('POST', '/staff/renew', {
  saveId: created.saveId, staffId: assistant.id, years: 3,
})) as { ok: boolean; staff: StaffApi };
const renewed = renew.staff.staff.find((s) => s.id === assistant.id);
check('i1_renew_ok',
  renew.ok && renewed !== undefined && renewed.contractUntil === staff1.season + 3 && renewed.salary >= assistant.salary,
  `until=${renewed?.contractUntil} sal=${renewed?.salary}`);

// симуляция недели: staff_wages в финансах, программа применилась, рынок наполнен
await engineDispatch('POST', '/simulate', { saveId: created.saveId });
const wagesRecord = await getEngine().requireStore() !== undefined
  ? ((await engineDispatch('GET', '/state', { saveId: created.saveId })) as { snapshot: { finances: unknown } })
  : null;
check('i1_state_after_week', wagesRecord !== null);
type Dump = Record<string, unknown[]>;
const dump1 = engine.requireStore().toJSON() as unknown as Dump;
const financeRows = (dump1.financeRecords ?? []) as { category: string; amount: number }[];
const staffWagesRow = financeRows.find((r) => r.category === 'staff_wages');
check('i1_staff_wages_recorded', staffWagesRow !== undefined && (staffWagesRow.amount ?? 0) > 0,
  `amount=${staffWagesRow?.amount}`);
check('i1_dump_has_player_trainings', Array.isArray(dump1.playerTrainings) && dump1.playerTrainings.length >= 1);

// guard: чужой игрок (рынок уже наполнен недельным циклом)
{
  const marketList = (await engineDispatch('GET', '/market', { saveId: created.saveId })) as {
    listings: { player: { id: string } }[];
  };
  let notYours = false;
  try {
    await engineDispatch('POST', '/training/player', {
      saveId: created.saveId, playerId: marketList.listings[0].player.id, focus: 'attack', intensity: 'normal',
    });
  } catch (e) {
    notYours = (e as { code?: string }).code === 'NOT_YOUR_PLAYER';
  }
  check('i1_training_guard_foreign', notYours);
}

// увольнение скаута: компенсация, запись удалена
const hiredScoutId = scoutCandidate!.id;
const balBeforeFire = ((await engineDispatch('GET', '/staff', { saveId: created.saveId })) as StaffApi).balance;
const fire1 = (await engineDispatch('POST', '/staff/fire', {
  saveId: created.saveId, staffId: hiredScoutId,
})) as { ok: boolean; staff: StaffApi; balanceDelta: number };
check('i1_fire_ok',
  fire1.ok && fire1.staff.staff.length === 2 && !fire1.staff.staff.some((s) => s.id === hiredScoutId),
  `n=${fire1.staff.staff.length}`);
check('i1_fire_compensation',
  fire1.balanceDelta < 0 && fire1.staff.balance === balBeforeFire + fire1.balanceDelta,
  `delta=${fire1.balanceDelta}`);

let fireForeign = false;
try {
  await engineDispatch('POST', '/staff/fire', { saveId: created.saveId, staffId: anotherHead!.id });
} catch (e) {
  fireForeign = (e as { code?: string }).code === 'STAFF_NOT_EMPLOYED';
}
check('i1_fire_guard_foreign', fireForeign);

// сброс индивидуальной программы
const reset = (await engineDispatch('POST', '/training/player', {
  saveId: created.saveId, playerId: target.id, focus: null, intensity: null,
})) as { ok: boolean; individual: unknown };
check('i1_reset_individual', reset.ok && reset.individual === null);
const dump2 = engine.requireStore().toJSON() as unknown as Dump;
const ptRows = (dump2.playerTrainings ?? []) as { playerId: string }[];
eq('i1_reset_deleted_row', ptRows.filter((r) => r.playerId === target.id).length, 0);

// живость рынка: 6 недель — размер стабилен, состав меняется
const marketIds0 = new Set(((await engineDispatch('GET', '/staff', { saveId: created.saveId })) as StaffApi).market.map((m) => m.id));
for (let w = 0; w < 6; w++) {
  await engineDispatch('POST', '/simulate', { saveId: created.saveId });
}
const staffAfter6 = (await engineDispatch('GET', '/staff', { saveId: created.saveId })) as StaffApi;
check('i1_market_size_stable',
  staffAfter6.market.length >= 12 && staffAfter6.market.length <= 17,
  `n=${staffAfter6.market.length}`);
const marketIds6 = new Set(staffAfter6.market.map((m) => m.id));
const changed = [...marketIds6].some((id) => !marketIds0.has(id));
check('i1_market_alive', changed, 'рынок персонала статичен');

// длинный прогон до конца сезона: контракты/пенсии/продления ИИ
const stateNow = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as {
  snapshot: { save: { season: number; week: number; totalWeeks: number } };
};
let weeksLeft = stateNow.snapshot.save.totalWeeks - stateNow.snapshot.save.week + 1;
let guardWeeks = 0;
while (weeksLeft > 0 && guardWeeks < 60) {
  const res = (await engineDispatch('POST', '/simulate', { saveId: created.saveId })) as {
    result: { seasonEnded: unknown; sacked: boolean };
  };
  guardWeeks += 1;
  if (res.result.seasonEnded !== null && res.result.seasonEnded !== undefined) break;
  weeksLeft -= 1;
}
const staffSeason2 = (await engineDispatch('GET', '/staff', { saveId: created.saveId })) as StaffApi;
check('i1_season_transition_survived',
  staffSeason2.season === 2 && staffSeason2.market.length >= 12 && staffSeason2.staff.length >= 1,
  `season=${staffSeason2.season} market=${staffSeason2.market.length} staff=${staffSeason2.staff.length}`);
check('i1_user_staff_contracts_valid',
  staffSeason2.staff.every((s) => s.yearsLeft >= 0 && s.contractUntil >= staffSeason2.season),
  'контракт в прошлом');
const allStaffCount = ((engine.requireStore().toJSON() as unknown as Dump).staff ?? []).length;
check('i1_ai_staff_renewed', allStaffCount > staffSeason2.market.length, `total staff=${allStaffCount}`);

await engine.removeSlot(created.slot);
console.log(`\nИтого: PASS=${pass} FAIL=${fail}`);
if (fail > 0) {
  console.log(`Провалены: ${failures.join(', ')}`);
  process.exit(1);
}

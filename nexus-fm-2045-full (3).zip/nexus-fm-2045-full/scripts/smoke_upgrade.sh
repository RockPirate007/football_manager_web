#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Smoke-тест Фазы 2 (Task 10-a-2): мульти-карьеры, кубковая неделя, тренировки,
# награды, compat-роуты Фазы 1. Запуск: bash scripts/smoke_upgrade.sh
# Требует: работающий dev-сервер на :3000, jq.
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

BASE="http://localhost:3000/api/game"
PASS=0
FAIL=0

ok()  { PASS=$((PASS + 1)); echo "  ✔ $*"; }
bad() { FAIL=$((FAIL + 1)); echo "  ✘ $*"; }
section() { echo; echo "── $* ─────────────────────────────────"; }

#HTTP POST/GET/PATCH/DELETE helper: method url [json-body] → BODY (глобально), CODE
call() {
  local method="$1" url="$2" body="${3:-}"
  if [ -n "$body" ]; then
    BODY=$(curl -s -w $'\n%{http_code}' -X "$method" -H 'Content-Type: application/json' -d "$body" "$url")
  else
    BODY=$(curl -s -w $'\n%{http_code}' -X "$method" "$url")
  fi
  CODE=$(echo "$BODY" | tail -n1)
  BODY=$(echo "$BODY" | sed '$d')
}

check() { # check "описание" "jq-expr" "ожидание"
  local desc="$1" expr="$2" expected="$3"
  local actual
  actual=$(echo "$BODY" | jq -r "$expr" 2>/dev/null)
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"
  else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}

check_code() { # check_code "описание" "код"
  if [ "$CODE" = "$2" ]; then ok "$1 (HTTP $CODE)"
  else bad "$1: ожидался HTTP $2, получен $CODE"; fi
}

section "0. Очистка БД перед прогоном"

call GET "$BASE/saves"
if [ "$CODE" = "200" ]; then
  for sid in $(echo "$BODY" | jq -r '.saves[].id'); do
    call DELETE "$BASE/saves/$sid"
    if [ "$CODE" = "200" ]; then ok "удалён сейв $sid"; else bad "не удалось удалить сейв $sid (HTTP $CODE)"; fi
  done
  call GET "$BASE/saves"
  check "БД пуста" '.saves | length' '0'
else
  bad "GET /saves недоступен (HTTP $CODE) — dev-сервер запущен?"
fi

section "1. Создание двух карьер: Англия (клуб 0) и Испания (клуб 1)"

call POST "$BASE/saves" '{"leagueCode":"EPL","clubIndex":0,"managerName":"Алексей Воронин","careerName":"Сити — мой путь"}'
check_code "POST /saves Англия" 200
ENG=$(echo "$BODY" | jq -r '.saveId')
check "английская карьера создана (saveId)" '.saveId != null and .ok' 'true'
check "careerName сохранён" '.careerName' 'Сити — мой путь'
check "лига в ответе" '.league.code' 'EPL'
check "клуб в ответе" '.club.shortName' 'MCI'
check "карточка карьеры в ответе" '.save.clubName' 'Манчестер Сити'

call POST "$BASE/saves" '{"leagueCode":"LAL","clubIndex":1,"managerName":"Пабло Гарсия"}'
check_code "POST /saves Испания" 200
ESP=$(echo "$BODY" | jq -r '.saveId')
check "испанская карьера создана" '.saveId != null and .ok' 'true'
check "careerName автогенерация «Барселона · Сезон 1»" '.careerName' 'Барселона · Сезон 1'

# Негативные проверки валидации
call POST "$BASE/saves" '{"leagueCode":"XXX","clubIndex":0,"managerName":"Тест"}'
check_code "неизвестная лига → 400" 400
check "код INVALID_LEAGUE" '.error' 'INVALID_LEAGUE'
call POST "$BASE/saves" '{"leagueCode":"EPL","clubIndex":99,"managerName":"Тест"}'
check "clubIndex вне диапазона → INVALID_LEAGUE" '.error' 'INVALID_LEAGUE'

section "2. GET /saves — обе карьеры в списке"

call GET "$BASE/saves"
check_code "GET /saves" 200
check "в списке 2 карьеры" '.saves | length' '2'
check "обе с клубами (setup-сейвов нет)" '[.saves[].clubName] | length' '2'
ENG_IN_LIST=$(echo "$BODY" | jq -r '[.saves[].id] | index("'"$ENG"'") != null')
if [ "$ENG_IN_LIST" = "true" ]; then ok "английская карьера в списке"; else bad "английской карьеры нет в списке"; fi
ESP_IN_LIST=$(echo "$BODY" | jq -r '[.saves[].id] | index("'"$ESP"'") != null')
if [ "$ESP_IN_LIST" = "true" ]; then ok "испанская карьера в списке"; else bad "испанской карьеры нет в списке"; fi
check "метка недели англ. карьеры" '[.saves[] | select(.id=="'"$ENG"'") | .weekLabel][0]' 'Тур 1/38'
check "totalWeeks англ. карьеры (38+5)" '[.saves[] | select(.id=="'"$ENG"'") | .totalWeeks][0]' '43'

section "3. GET /state?saveId=англ — блоки league/cup/training"

call GET "$BASE/state?saveId=$ENG"
check_code "GET /state" 200
check "careerName в снапшоте" '.snapshot.save.careerName' 'Сити — мой путь'
check "лига в снапшоте" '.snapshot.save.league.code' 'EPL'
check "кубок Англии" '.snapshot.cup.cupName' 'Кубок Англии'
check "раундов кубка 5" '.snapshot.cup.rounds | length' '5'
check "клуб не в розыгрыше ещё" '.snapshot.cup.myStatus' 'not_started'
check "тренировка по умолчанию rest/normal" '.snapshot.training.focus + "/" + .snapshot.training.intensity' 'rest/normal'
check "weekInfo в снапшоте" '.snapshot.save.weekInfo.label' 'Тур 1/38'
check "лидеры: топ-10 бомбардиров (0 голов в начале)" '.snapshot.leaders.topScorers | length' '10'
check "состав игрока не пуст" '.snapshot.myPlayers | length > 0' 'true'

call GET "$BASE/state?saveId=no-such-save"
check_code "GET /state несуществующий saveId → 404" 404
check "код SAVE_NOT_FOUND" '.error' 'SAVE_NOT_FOUND'

section "4. POST /training (attack/hard) + GET /training"

call POST "$BASE/training" "{\"saveId\":\"$ENG\",\"focus\":\"attack\",\"intensity\":\"hard\"}"
check_code "POST /training" 200
check "новое состояние тренировки" '.training.focus + "/" + .training.intensity' 'attack/hard'

call GET "$BASE/training?saveId=$ENG"
check_code "GET /training" 200
check "фокус установлен" '.training.focus' 'attack'
check "интенсивность установлена" '.training.intensity' 'hard'
check "состав в ответе" '.squad | length > 0' 'true'
check "xp только по атрибутам фокуса (+ GK-атрибуты вратарей)" '([.squad[].trainingXp | keys[]] | length > 0) and ([.squad[].trainingXp | keys[]] | all(. == "finishing" or . == "dribbling" or . == "crossing" or . == "pace" or . == "reflexes" or . == "rushingOut" or . == "kicking"))' 'true'
check "подсказки эффектов (6 фокусов)" '.hints.focuses | length' '6'
check "подсказки интенсивностей (3)" '.hints.intensities | length' '3'

call POST "$BASE/training" "{\"saveId\":\"$ENG\",\"focus\":\"hacking\",\"intensity\":\"hard\"}"
check_code "неверный фокус → 400" 400
check "код INVALID_TRAINING" '.error' 'INVALID_TRAINING'

section "5. simulate ×9 → кубковая неделя 8 (EPL: CUP_WEEKS[0]=8)"

for i in 1 2 3 4 5 6 7; do
  call POST "$BASE/simulate" "{\"saveId\":\"$ENG\"}"
  if [ "$CODE" != "200" ]; then bad "тур $i: HTTP $CODE: $(echo "$BODY" | head -c 200)"; break; fi
  check "тур $i сыгран" '.result.weekType' 'league'
done

call POST "$BASE/simulate" "{\"saveId\":\"$ENG\"}"
check_code "неделя 8 (кубковая)" 200
check "тип недели — cup" '.result.weekType' 'cup'
check "метка недели — Кубок" '.result.weekLabel | startswith("Кубок")' 'true'
check "кубковые матчи недели сыграны (4 предварительных)" '.result.weekResults | length' '4'
check "жеребьёвка следующего раунда (1/8) есть" '.result.cupRound.round' '2'
check "пар в 1/8 — 8" '.result.cupRound.pairs | length' '8'

call GET "$BASE/state?saveId=$ENG"
check_code "GET /state после кубковой недели" 200
CUP_MATCH_ID=$(echo "$BODY" | jq -r '[.snapshot.seasonMatches[] | select(.competition == "cup" and .played)] | .[0].id')
check "кубковые матчи в календаре (competition=cup)" '[.snapshot.seasonMatches[] | select(.competition == "cup")] | length >= 12' 'true'
check "предварительный раунд разведён" '.snapshot.cup.rounds[0].drawn' 'true'
check "неделя 9 — лиговая" '.snapshot.save.weekInfo.type' 'league'

call GET "$BASE/match?saveId=$ENG&id=$CUP_MATCH_ID"
check_code "GET /match кубкового матча" 200
check "матч — кубковый (competition=cup)" '.match.competition' 'cup'
check "раунд матча = 1" '.match.cupRound' '1'
check "победитель определён" '.match.winnerTeamId != null' 'true'

# Изоляция карьер: матч испанской карьеры не доступен через англ. saveId
call GET "$BASE/state?saveId=$ESP"
ESP_MATCH_ID=$(echo "$BODY" | jq -r '.snapshot.seasonMatches[0].id')
call GET "$BASE/match?saveId=$ENG&id=$ESP_MATCH_ID"
check_code "чужой матч → 404 MATCH_NOT_FOUND" 404
check "код MATCH_NOT_FOUND" '.error' 'MATCH_NOT_FOUND'

section "6. GET /awards — сезон не закончен, список пуст"

call GET "$BASE/awards?saveId=$ENG"
check_code "GET /awards" 200
check "наград ещё нет" '.awards | length' '0'
check "live-бомбардиры есть" '.live.topScorers | length > 0' 'true'
check "live-ассистенты есть" '.live.topAssists | length > 0' 'true'

call GET "$BASE/awards?saveId=$ENG&season=abc"
check_code "некорректный season → 400" 400
check "код INVALID_PAYLOAD" '.error' 'INVALID_PAYLOAD'

section "7. DELETE /saves/[id] — испанская карьера удалена"

call DELETE "$BASE/saves/$ESP"
check_code "DELETE /saves испанской" 200
call GET "$BASE/saves"
check "осталась 1 карьера" '.saves | length' '1'
call GET "$BASE/state?saveId=$ESP"
check_code "удалённый сейв → 404" 404

section "8. PATCH /saves/[id] — переименование"

call PATCH "$BASE/saves/$ENG" '{"careerName":"Новый путь Сити"}'
check_code "PATCH /saves" 200
call PATCH "$BASE/saves/$ENG" '{"careerName":""}'
check_code "пустое имя → 400" 400
check "код INVALID_CAREER_NAME" '.error' 'INVALID_CAREER_NAME'
call GET "$BASE/saves"
check "новое название в списке" '[.saves[] | select(.id=="'"$ENG"'") | .careerName][0]' 'Новый путь Сити'

section "9. Compat Фазы 1: POST /new → POST /select → GET /state (легаси)"

call POST "$BASE/new" '{"managerName":"Легаси Менеджер"}'
check_code "POST /new" 200
LEGACY=$(echo "$BODY" | jq -r '.saveId')
check "16 клубов РПЛ в ответе" '.clubs | length' '16'
LEGACY_TEAM=$(echo "$BODY" | jq -r '.clubs[3].id')
call POST "$BASE/select" "{\"saveId\":\"$LEGACY\",\"teamId\":\"$LEGACY_TEAM\"}"
check_code "POST /select" 200

call GET "$BASE/state"
check_code "легаси GET /state (без saveId)" 200
check "легаси-фолбэк выбрал свежую карьеру" '.snapshot.save.id' "$LEGACY"
check "лига РПЛ" '.snapshot.save.league.nameRu' 'Российская Премьер-Лига'
check "кубок России" '.snapshot.cup.cupName' 'Кубок России'

call POST "$BASE/simulate"
check_code "легаси POST /simulate (без body)" 200
check "тур РПЛ сыгран" '.result.weekType' 'league'

call DELETE "$BASE/saves/$LEGACY"
check_code "cleanup: удаление легаси-карьеры" 200

section "Итог"
echo
echo "PASS: $PASS  FAIL: $FAIL"
if [ "$FAIL" -gt 0 ]; then
  echo "СМОУК-ТЕСТ ПРОВАЛЕН"
  exit 1
fi
echo "СМОУК-ТЕСТ ПРОЙДЕН ✔"

#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# QA-регресс Фазы 2 (Task 11): ПОЛНЫЙ СЕЗОН + сезонный переход + инварианты.
# Запуск: bash scripts/qa_season.sh
# Требует: dev-сервер на :3000, jq.
# Создаёт отдельную карьеру «QA-Сезон <метка>» и удаляет её в конце —
# существующие карьеры пользователя НЕ трогает.
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

BASE="http://localhost:3000/api/game"
TAG="QA-Сезон $(date +%H%M%S)"
LOG=$(mktemp /tmp/qa_season_XXXXXX.jsonl)
PASS=0
FAIL=0

ok()  { PASS=$((PASS + 1)); echo "  ✔ $*"; }
bad() { FAIL=$((FAIL + 1)); echo "  ✘ $*"; }
section() { echo; echo "── $* ─────────────────────────────────"; }

call() { # method url [body] → BODY, CODE
  local method="$1" url="$2" body="${3:-}"
  if [ -n "$body" ]; then
    BODY=$(curl -s -w $'\n%{http_code}' -X "$method" -H 'Content-Type: application/json' -d "$body" "$url")
  else
    BODY=$(curl -s -w $'\n%{http_code}' -X "$method" "$url")
  fi
  CODE=$(echo "$BODY" | tail -n1)
  BODY=$(echo "$BODY" | sed '$d')
}
check() { # desc jq-expr expected
  local actual
  actual=$(echo "$BODY" | jq -r "$2" 2>/dev/null)
  if [ "$actual" = "$3" ]; then ok "$1 ($actual)"
  else bad "$1: ожидалось '$3', получено '$actual'"; fi
}
check_code() {
  if [ "$CODE" = "$2" ]; then ok "$1 (HTTP $CODE)"; else bad "$1: ожидался HTTP $2, получен $CODE"; fi
}

section "1. Создание тестовой карьеры (RPL, 16 команд — самый быстрый сезон)"
call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":0,"managerName":"QA Регресс","careerName":"'"$TAG"'"}'
check_code "POST /saves" 200
SID=$(echo "$BODY" | jq -r '.saveId')
[ -n "$SID" ] && [ "$SID" != "null" ] && ok "saveId получен" || bad "saveId пуст"
call POST "$BASE/training" "{\"saveId\":\"$SID\",\"focus\":\"attack\",\"intensity\":\"normal\"}"
check_code "training attack/normal" 200

section "2. ПОЛНЫЙ СЕЗОН: 34 недели, лог каждой недели"
WEEKS_OK=0
declare -a CUP_W_N=(0 0 0 0)
for i in $(seq 1 34); do
  call POST "$BASE/simulate" "{\"saveId\":\"$SID\"}"
  if [ "$CODE" != "200" ]; then bad "неделя $i: HTTP $CODE"; break; fi
  WEEKS_OK=$((WEEKS_OK + 1))
  echo "$BODY" | jq -c '.result' >> "$LOG"
  W=$(echo "$BODY" | jq -r '.result.week')
  T=$(echo "$BODY" | jq -r '.result.weekType')
  L=$(echo "$BODY" | jq -r '.result.weekLabel')
  N=$(echo "$BODY" | jq -r '.result.weekResults | length')
  UM=$(echo "$BODY" | jq -r 'if .result.userMatch then "играл" else "отдых" end')
  echo "  неделя $W: $T · $L · матчей: $N · клуб игрока: $UM"
  # кубковые недели RPL: 8(1/8, 8 матчей), 16(1/4, 4), 24(1/2, 2), 34(финал, 1)
  case "$W" in
    8)  CUP_W_N[0]=$N ;;
    16) CUP_W_N[1]=$N ;;
    24) CUP_W_N[2]=$N ;;
    34) CUP_W_N[3]=$N ;;
  esac
done
[ "$WEEKS_OK" = "34" ] && ok "все 34 недели сыграны без 5xx/4xx" || bad "сыграно недель: $WEEKS_OK из 34"

section "3. Кубковые недели и структура раундов"
[ "${CUP_W_N[0]}" = "8" ] && ok "неделя 8 = 1/8 финала: 8 матчей" || bad "неделя 8: ${CUP_W_N[0]} матчей (ожидалось 8)"
[ "${CUP_W_N[1]}" = "4" ] && ok "неделя 16 = 1/4 финала: 4 матча" || bad "неделя 16: ${CUP_W_N[1]} (ожидалось 4)"
[ "${CUP_W_N[2]}" = "2" ] && ok "неделя 24 = 1/2 финала: 2 матча" || bad "неделя 24: ${CUP_W_N[2]} (ожидалось 2)"
[ "${CUP_W_N[3]}" = "1" ] && ok "неделя 34 = финал: 1 матч" || bad "неделя 34: ${CUP_W_N[3]} (ожидалось 1)"

PENS=$(jq -s '[.[] | select(.weekType == "cup") | .weekResults[] | select(.homePens != null)] | length' "$LOG")
[ "$PENS" -gt 0 ] && ok "кубковые ничьи решены пенальти ($PENS серий)" || echo "  ⚠ пенальти в этом прогоне не случилось (РНГ)"

FIN_NEUTRAL=$(jq -s '[.[] | select(.week == 34)][0].weekResults[0]' "$LOG" 2>/dev/null | jq -r '.' 2>/dev/null || echo "n/a")

section "4. Инварианты финальной таблицы (из seasonEnded недели 34)"
jq -s '[.[] | select(.week == 34)][0].seasonEnded.standings' "$LOG" > /tmp/qa_stand.json 2>/dev/null
SUM_P=$(jq '[.[].points] | add' /tmp/qa_stand.json)
SUM_3WD=$(jq '3 * ([.[].won] | add) + ([.[].drawn] | add)' /tmp/qa_stand.json)
[ "$SUM_P" = "$SUM_3WD" ] && ok "очки = 3W+D ($SUM_P)" || bad "очки $SUM_P ≠ 3W+D $SUM_3WD"
GF=$(jq '[.[].goalsFor] | add' /tmp/qa_stand.json)
GA=$(jq '[.[].goalsAgainst] | add' /tmp/qa_stand.json)
[ "$GF" = "$GA" ] && ok "забито = пропущено ($GF)" || bad "забито $GF ≠ пропущено $GA"
ALL30=$(jq '[.[] | select(.played != 30)] | length' /tmp/qa_stand.json)
[ "$ALL30" = "0" ] && ok "у всех played = 30" || bad "у $ALL30 команд played ≠ 30"
PLACES=$(jq -r '[.[].place] | sort | map(tostring) | join(",")' /tmp/qa_stand.json)
[ "$PLACES" = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16" ] && ok "места 1..16 без дублей" || bad "места: $PLACES"

section "5. Сезонный переход: сезон 2, неделя 1, кубок сброшен"
call GET "$BASE/state?saveId=$SID"
check "сезон стал 2" '.snapshot.save.season' '2'
check "неделя сброшена в 1" '.snapshot.save.week' '1'
check "кубок сброшен (not_started)" '.snapshot.cup.myStatus' 'not_started'
check "раунд 1 не разведён" '.snapshot.cup.rounds[0].drawn' 'false'
check "новый календарь: 8 матчей недели 1" '.snapshot.fixtures | length' '8'
check "таблица нового сезона пуста (0 игр)" '[.snapshot.standings[] | select(.played > 0)] | length' '0'

section "6. Награды сезона 1: ровно 8 типов"
call GET "$BASE/awards?saveId=$SID&season=1"
check "8 наград" '.awards | length' '8'
for T in champion cup_winner top_scorer top_assist mvp young golden_glove cup_scorer; do
  HAST=$(echo "$BODY" | jq -r --arg t "$T" '[.awards[] | select(.type == $t)] | length')
  [ "$HAST" = "1" ] && ok "награда $T" || bad "награда $T: $HAST записей (ожидалась 1)"
done
check "live-лидеры нового сезона есть" '.live.topScorers | length > 0' 'true'

section "7. Призовые и финансы"
call GET "$BASE/state?saveId=$SID"
PRIZE=$(jq -s '[.[] | select(.week == 34)][0].seasonEnded.prize' "$LOG")
[ "$PRIZE" -gt 0 ] && ok "призовые за место зачислены (€$PRIZE)" || bad "призовые = $PRIZE"

section "8. Уборка тестовой карьеры"
call DELETE "$BASE/saves/$SID"
check_code "DELETE /saves" 200
call GET "$BASE/state?saveId=$SID"
check_code "удалённый сейв → 404" 404
rm -f "$LOG" /tmp/qa_stand.json

section "Итог"
echo
echo "PASS: $PASS  FAIL: $FAIL"
if [ "$FAIL" -gt 0 ]; then echo "QA-СЕЗОННЫЙ РЕГРЕСС ПРОВАЛЕН"; exit 1; fi
echo "QA-СЕЗОННЫЙ РЕГРЕСС ПРОЙДЕН ✔"

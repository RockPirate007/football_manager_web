/**
 * Кубковый турнир: жеребьёвка («слабый дома»), пенальти, ИИ-матчи, призовые.
 * Чистый модуль (Prisma не трогает; io — в week.ts). §3.2 architecture-upgrade.md.
 */

import {
  CUP_AI_RANDOM_SHARE, CUP_AI_WIN_DIV, CUP_FINALIST_PRIZE, CUP_PRIZE_ROUND,
  CUP_WEAK_HOME_PROB, PEN_P_GOAL, PEN_P_SAVE, PEN_SUDDEN_DEATH_MAX,
  type AiStyleCode,
} from './constants';
import {
  PEN_GOAL_TEMPLATES, PEN_MISS_TEMPLATES, PEN_SAVE_TEMPLATES,
  SHOOTOUT_END_TEXT, SHOOTOUT_START_TEXT,
} from './data';
import { simulateAiMatch } from './match';
import type { PlayerLike } from './players';
import { clamp, pick, randInt, type RNG } from './rng';
import type { MatchEvent } from './types';

export interface CupTeamSeed {
  id: string;
  strength: number;
}

export interface CupPair {
  homeTeamId: string;
  awayTeamId: string;
  isNeutral: boolean;
}

/**
 * Жеребьёвка раунда: shuffle участников; в каждой паре слабый — дома с p=0.7,
 * иначе сильный — дома. Финал: isNeutral=true, «дом» — случайный (50/50).
 */
export function drawCupRound(rng: RNG, alive: CupTeamSeed[], isFinal: boolean): CupPair[] {
  if (alive.length < 2 || alive.length % 2 !== 0) {
    throw new Error(`drawCupRound: нужно чётное число участников ≥ 2, получено ${alive.length}`);
  }
  const byId = new Map(alive.map((t) => [t.id, t]));
  const order = [...alive];
  // Фишер–Йетс тем же rng
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  const pairs: CupPair[] = [];
  for (let i = 0; i < order.length; i += 2) {
    const a = byId.get(order[i].id) as CupTeamSeed;
    const b = byId.get(order[i + 1].id) as CupTeamSeed;
    let home: CupTeamSeed;
    let away: CupTeamSeed;
    if (isFinal) {
      home = rng() < 0.5 ? a : b;
      away = home === a ? b : a;
    } else {
      const weakHome = rng() < CUP_WEAK_HOME_PROB;
      if (weakHome) {
        home = a.strength <= b.strength ? a : b;
        away = home === a ? b : a;
      } else {
        home = a.strength >= b.strength ? a : b;
        away = home === a ? b : a;
      }
    }
    pairs.push({ homeTeamId: home.id, awayTeamId: away.id, isNeutral: isFinal });
  }
  return pairs;
}

/**
 * Участники предварительного раунда: 2×(N−16) команд (N=20 → 8 слабейших,
 * N=18 → 4, N=16 → [] — нет предварительного).
 * season=1 — слабейшие по Team.strength; season≥2 — худшие места финальной
 * таблицы ПРОШЛОГО сезона (competition='league').
 */
export function prelimParticipants(
  teams: CupTeamSeed[],
  prevStandings: { teamId: string; place: number }[] | null,
  teamCount: number,
): string[] {
  const count = 2 * (teamCount - 16);
  if (count <= 0) return [];
  if (prevStandings && prevStandings.length > 0) {
    const byPlace = [...prevStandings].sort((a, b) => b.place - a.place);
    return byPlace.slice(0, count).map((s) => s.teamId);
  }
  const weakest = [...teams].sort((a, b) => a.strength - b.strength);
  return weakest.slice(0, count).map((t) => t.id);
}

export interface AiCupSide {
  teamId: string;
  name: string;
  strength: number;
  players: PlayerLike[];
  /** Фаза 4 (евро): стиль тренера — проброс в simulateAiMatch (λ-дельты); отсутствует → balanced. */
  aiStyle?: AiStyleCode;
}

/**
 * ИИ-матч кубка: обычный движок (opts.neutral — финал); при ничьей — вероятностные пенальти:
 * P(win home) = clamp(0.5 + Δstr/80, 0.30, 0.70) + 15% чистой случайности.
 * Счёт серии: победитель randInt(3,5), проигравший randInt(1, winner−1).
 */
export function simulateAiCupMatch(
  rng: RNG,
  home: AiCupSide,
  away: AiCupSide,
  opts?: { neutral?: boolean },
): {
  homeGoals: number;
  awayGoals: number;
  events: MatchEvent[];
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string;
} {
  const base = simulateAiMatch(rng, home, away, opts);
  if (base.homeGoals !== base.awayGoals) {
    const winnerTeamId = base.homeGoals > base.awayGoals ? home.teamId : away.teamId;
    return {
      homeGoals: base.homeGoals,
      awayGoals: base.awayGoals,
      events: base.events,
      homePens: null,
      awayPens: null,
      winnerTeamId,
    };
  }

  // Пенальти вероятностно
  let homeWins: boolean;
  if (rng() < CUP_AI_RANDOM_SHARE) {
    homeWins = rng() < 0.5;
  } else {
    const p = clamp(0.5 + (home.strength - away.strength) / CUP_AI_WIN_DIV, 0.3, 0.7);
    homeWins = rng() < p;
  }
  const winnerPens = randInt(rng, 3, 5);
  const loserPens = Math.max(1, randInt(rng, 1, winnerPens - 1));
  const homePens = homeWins ? winnerPens : loserPens;
  const awayPens = homeWins ? loserPens : winnerPens;
  const winnerTeamId = homeWins ? home.teamId : away.teamId;
  const winnerName = homeWins ? home.name : away.name;

  const events: MatchEvent[] = [...base.events];
  events.push({ minute: 95, type: 'pen_goal', text: SHOOTOUT_START_TEXT });
  events.push({
    minute: 120,
    type: 'pen_goal',
    teamId: winnerTeamId,
    text: `Серия пенальти: ${home.name} ${homePens}:${awayPens} ${away.name} — победа ${winnerName}!`,
  });
  return { homeGoals: base.homeGoals, awayGoals: base.awayGoals, events, homePens, awayPens, winnerTeamId };
}

export interface ShootoutTaker {
  playerId: string;
  playerName: string;
  finishing: number;
}

export interface ShootoutGk {
  playerName: string;
  reflexes: number;
}

/**
 * Серия пенальти для матча клуба игрока — покиково, события в ленту.
 * pGoal = clamp(0.72 + 0.20×(finishing−75)/25, 0.62, 0.87);
 * pSave = clamp(0.18 + 0.20×(reflexes−75)/25, 0.10, 0.33) — вратарь ПРОТИВНИКА.
 * Один бросок rng: r < pGoal → гол; r < pGoal + pSave×(1−pGoal) → сэйв; иначе промах.
 * По 5 ударов с досрочным решением; после 5:5 — внезапная смерть
 * (максимум PEN_SUDDEN_DEATH_MAX пар, затем монетка). minute = 95 + номер удара.
 */
export function simulatePenaltyShootout(rng: RNG, args: {
  homeName: string;
  awayName: string;
  homeTeamId: string;
  awayTeamId: string;
  homeTakers: ShootoutTaker[];
  awayTakers: ShootoutTaker[];
  homeGk: ShootoutGk;
  awayGk: ShootoutGk;
  events: MatchEvent[]; // append
}): { homePens: number; awayPens: number; winnerIsHome: boolean } {
  const {
    homeName, awayName, homeTeamId, awayTeamId,
    homeTakers, awayTakers, homeGk, awayGk, events,
  } = args;

  events.push({ minute: 94, type: 'pen_goal', text: SHOOTOUT_START_TEXT });

  const home = { score: 0, taken: 0 };
  const away = { score: 0, taken: 0 };
  let kickIndex = 0;

  const pGoalOf = (finishing: number): number =>
    clamp(
      PEN_P_GOAL.base + (PEN_P_GOAL.slope * (finishing - PEN_P_GOAL.ref)) / PEN_P_GOAL.span,
      PEN_P_GOAL.min,
      PEN_P_GOAL.max,
    );
  const pSaveOf = (reflexes: number): number =>
    clamp(
      PEN_P_SAVE.base + (PEN_P_SAVE.slope * (reflexes - PEN_P_SAVE.ref)) / PEN_P_SAVE.span,
      PEN_P_SAVE.min,
      PEN_P_SAVE.max,
    );

  const attempt = (side: 'home' | 'away', taker: ShootoutTaker, oppGk: ShootoutGk): void => {
    const minute = 95 + kickIndex;
    kickIndex++;
    const pGoal = pGoalOf(taker.finishing);
    const pSave = pSaveOf(oppGk.reflexes);
    const r = rng();
    const teamId = side === 'home' ? homeTeamId : awayTeamId;
    if (r < pGoal) {
      if (side === 'home') home.score++;
      else away.score++;
      events.push({
        minute,
        type: 'pen_goal',
        teamId,
        playerId: taker.playerId,
        playerName: taker.playerName,
        text: pick(rng, PEN_GOAL_TEMPLATES).replace('{player}', taker.playerName),
      });
    } else if (r < pGoal + pSave * (1 - pGoal)) {
      events.push({
        minute,
        type: 'pen_save',
        teamId,
        playerId: taker.playerId,
        playerName: taker.playerName,
        gkName: oppGk.playerName,
        text: pick(rng, PEN_SAVE_TEMPLATES)
          .replace('{gk}', oppGk.playerName)
          .replace('{player}', taker.playerName),
      });
    } else {
      events.push({
        minute,
        type: 'pen_miss',
        teamId,
        playerId: taker.playerId,
        playerName: taker.playerName,
        text: pick(rng, PEN_MISS_TEMPLATES).replace('{player}', taker.playerName),
      });
    }
  };

  /** Решена ли серия в базовой части (обе стороны ещё ≤ 5 ударов). */
  const regularDecided = (): boolean => {
    if (home.taken === away.taken) return home.score !== away.score;
    const homeLeft = 5 - home.taken;
    const awayLeft = 5 - away.taken;
    if (home.score > away.score + awayLeft) return true;
    if (away.score > home.score + homeLeft) return true;
    return false;
  };

  const takerFor = (side: 'home' | 'away', i: number): ShootoutTaker | null => {
    const list = side === 'home' ? homeTakers : awayTakers;
    if (list.length === 0) return null;
    return list[i % list.length];
  };

  // Базовая часть: по 5 ударов, досрочное решение
  for (let i = 0; i < 5; i++) {
    const h = takerFor('home', i);
    if (h) {
      attempt('home', h, awayGk);
      home.taken++;
    }
    if (regularDecided()) break;
    const a = takerFor('away', i);
    if (a) {
      attempt('away', a, homeGk);
      away.taken++;
    }
    if (regularDecided()) break;
  }

  // Внезапная смерть: пары до решающей, максимум PEN_SUDDEN_DEATH_MAX пар
  let pair = 0;
  while (
    home.taken >= 5 && away.taken >= 5 &&
    home.taken === away.taken &&
    home.score === away.score &&
    pair < PEN_SUDDEN_DEATH_MAX
  ) {
    const h = takerFor('home', home.taken);
    const a = takerFor('away', away.taken);
    if (h) {
      attempt('home', h, awayGk);
      home.taken++;
    }
    if (a) {
      attempt('away', a, homeGk);
      away.taken++;
    }
    pair++;
  }

  let winnerIsHome: boolean;
  if (home.score === away.score) {
    winnerIsHome = rng() < 0.5; // монетка после PEN_SUDDEN_DEATH_MAX пар
  } else {
    winnerIsHome = home.score > away.score;
  }

  events.push({
    minute: 120,
    type: 'pen_goal',
    text: SHOOTOUT_END_TEXT
      .replace('{home}', homeName)
      .replace('{hp}', String(home.score))
      .replace('{ap}', String(away.score))
      .replace('{away}', awayName)
      .replace('{winner}', winnerIsHome ? homeName : awayName),
  });

  return { homePens: home.score, awayPens: away.score, winnerIsHome };
}

/** Призовые за выход/победу в раунде (N=16 — премии сдвигаются, БЕЗ предварительного). */
export function prizeForRound(teamCount: number, round: number): number {
  const idx = teamCount <= 16 ? round + 1 : round;
  const arr = CUP_PRIZE_ROUND;
  return arr[Math.min(Math.max(idx - 1, 0), arr.length - 1)];
}

/** Призовые финалиста (проигравшего в финале). */
export function finalistPrize(): number {
  return CUP_FINALIST_PRIZE;
}

/** Топ-N бьющих по finishing из СТАРТОВОГО состава (меньше N — все). */
export function shootoutTakers(
  lineup: (string | null)[],
  byId: Map<string, PlayerLike>,
  take = 5,
): ShootoutTaker[] {
  const starters = lineup
    .map((id) => (id ? byId.get(id) : undefined))
    .filter((p): p is PlayerLike => !!p && p.position !== 'GK');
  return [...starters]
    .sort((a, b) => b.finishing - a.finishing)
    .slice(0, take)
    .map((p) => ({ playerId: p.id, playerName: `${p.firstName} ${p.lastName}`, finishing: p.finishing }));
}

/** Стартовый вратарь команды (слот 0 всех формаций = GK). */
export function lineupGoalkeeper(lineup: (string | null)[], byId: Map<string, PlayerLike>): ShootoutGk | null {
  const gk = lineup[0] ? byId.get(lineup[0]) : undefined;
  if (!gk) return null;
  return { playerName: `${gk.firstName} ${gk.lastName}`, reflexes: gk.reflexes };
}

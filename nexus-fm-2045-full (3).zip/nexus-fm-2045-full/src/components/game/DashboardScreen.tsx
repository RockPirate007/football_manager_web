'use client';

import { useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Area, AreaChart, Bar, CartesianGrid, ComposedChart, Line, ReferenceLine, ResponsiveContainer,
  Tooltip as ChartTooltip, XAxis, YAxis,
} from 'recharts';
import {
  Activity, AlertTriangle, ArrowLeftRight, ArrowRight, Bandage, Bed, Building2, CalendarDays,
  ClipboardList, Dumbbell, Gauge, Globe, GraduationCap, HeartPulse, Landmark, ListChecks,
  Newspaper, PartyPopper, PlayCircle, PiggyBank, Scale, ShieldAlert, Sparkles, Target,
  TrendingUp, Trophy, UserRound, Users, Wallet, Zap,
} from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { FormDots } from '@/components/game/shared/FormDots';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { StatCard } from '@/components/game/shared/StatCard';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { WAGE_ALERT_RATIO, MATCH_PLAN_DEFAULT, MATCH_PLAN_LABELS } from '@/lib/game/constants';
import { formatMoney } from '@/lib/game/format';
import type { NewsType } from '@/lib/game/types';
import { useGameStore, type TabId } from '@/lib/store';
import { cn } from '@/lib/utils';

const NEWS_ICONS: Record<NewsType, typeof Newspaper> = {
  result: Trophy,
  transfer: ArrowLeftRight,
  injury: Bandage,
  market: ArrowLeftRight,
  finance: Wallet,
  info: Newspaper,
  cup: Trophy,
  training: Newspaper,
  board: Landmark,
  academy: GraduationCap,
  euro: Globe, // ── Фаза 4: Кубок Европы
  manager: UserRound, // ── D-6 «Тренер»: личная жизнь
};

function NextMatchTile() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const setTab = useGameStore((s) => s.setTab);
  const { save, nextMatch, nextMatchPreview } = snapshot;
  const myTeam = snapshot.myTeam;

  if (!nextMatch) {
    // Кубковая неделя без участия клуба игрока.
    if (save.weekInfo.type === 'cup') {
      return (
        <Alert className="border-[#EAB308]/40 bg-[#EAB308]/5">
          <Bed className="size-4 text-[#EAB308]" aria-hidden />
          <AlertTitle>{save.weekInfo.label} — команда отдыхает</AlertTitle>
          <AlertDescription>
            Ваш клуб не участвует в этом раунде. Симулируйте неделю во вкладке «Матч» —
            игроки восстановят силы.
          </AlertDescription>
        </Alert>
      );
    }
    return (
      <Alert className="border-primary/30 bg-primary/5">
        <PlayCircle className="size-4 text-primary" aria-hidden />
        <AlertTitle>{save.weekInfo.label} уже сыгран</AlertTitle>
        <AlertDescription>
          Симуляция этой недели завершена. Загляните во вкладки «Лига» и «Кубок»,
          чтобы увидеть результаты.
        </AlertDescription>
      </Alert>
    );
  }

  const isHome = nextMatch.homeTeamId === myTeam.id;
  const opponentBrief = nextMatchPreview?.opponent;
  const oppStrength = opponentBrief?.strength ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="rounded-lg border border-border/70 bg-card p-4 sm:p-6"
    >
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <Badge
          variant="outline"
          className={cn(
            'text-[11px]',
            nextMatch.competition === 'cup' &&
              'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]',
          )}
        >
          Сезон {save.season} · {save.weekInfo.label}
        </Badge>
        <Badge className={cn('text-[11px]', isHome ? 'bg-primary/15 text-primary' : 'bg-secondary text-muted-foreground')}>
          {isHome ? 'Дома' : 'В гостях'}
        </Badge>
      </div>

      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-4">
        <div className="flex flex-col items-center gap-2 text-center sm:flex-row sm:text-left">
          <TeamCrest
            shortName={isHome ? myTeam.shortName : nextMatch.awayShort}
            colorPrimary={isHome ? myTeam.colorPrimary : nextMatch.awayPrimary}
            colorSecondary={isHome ? myTeam.colorSecondary : nextMatch.awaySecondary}
            size="lg"
          />
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">
              {isHome ? myTeam.name : nextMatch.awayName}
            </div>
            <div className="text-xs text-muted-foreground tabular">
              Сила {isHome ? myTeam.strength : oppStrength}
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <span className="text-2xl font-bold text-muted-foreground">VS</span>
        </div>

        <div className="flex flex-col items-center gap-2 text-center sm:flex-row-reverse sm:text-right">
          <TeamCrest
            shortName={isHome ? nextMatch.homeShort : myTeam.shortName}
            colorPrimary={isHome ? nextMatch.homePrimary : myTeam.colorPrimary}
            colorSecondary={isHome ? nextMatch.homeSecondary : myTeam.colorSecondary}
            size="lg"
          />
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">
              {isHome ? nextMatch.homeName : myTeam.name}
            </div>
            <div className="text-xs text-muted-foreground tabular">
              Сила {isHome ? oppStrength : myTeam.strength}
            </div>
          </div>
        </div>
      </div>

      {nextMatchPreview ? (
        <div className="mt-4 grid grid-cols-3 gap-3">
          {(
            [
              ['Атака', nextMatchPreview.myLines.attack, nextMatchPreview.opponentLines.attack],
              ['Центр', nextMatchPreview.myLines.midfield, nextMatchPreview.opponentLines.midfield],
              ['Оборона', nextMatchPreview.myLines.defence, nextMatchPreview.opponentLines.defence],
            ] as const
          ).map(([label, mine, opp]) => {
            const total = mine + opp || 1;
            return (
              <div key={label}>
                <div className="mb-1 flex items-center justify-between text-[11px] text-muted-foreground">
                  <span className="tabular font-semibold text-foreground">{mine}</span>
                  <span>{label}</span>
                  <span className="tabular font-semibold text-foreground">{opp}</span>
                </div>
                <div className="flex h-1.5 overflow-hidden rounded-full bg-secondary">
                  <div className="bg-primary" style={{ width: `${(mine / total) * 100}%` }} />
                  <div className="bg-[#FACC15]" style={{ width: `${(opp / total) * 100}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      ) : null}

      <Button
        size="lg"
        className="mt-5 h-12 w-full text-base"
        onClick={() => setTab('match')}
      >
        <PlayCircle className="size-5" aria-hidden />
        Сыграть матч
      </Button>
    </motion.div>
  );
}

/** Главный экран обновления 2046: единый командный центр вместо набора разрозненных карточек. */
function CommandCenterHero() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { save, myTeam, myPlayers, standings, board, nextMatch, finances } = snapshot;

  const average = (selector: (player: (typeof myPlayers)[number]) => number) =>
    myPlayers.length
      ? Math.round(myPlayers.reduce((total, player) => total + selector(player), 0) / myPlayers.length)
      : 0;
  const readiness = average((player) => player.condition);
  const morale = average((player) => player.morale);
  const averageOvr = average((player) => player.ovr);
  const place = standings.find((row) => row.teamId === myTeam.id)?.place ?? standings.length;
  const injuries = myPlayers.filter((player) => player.injuryWeeks > 0).length;
  const opponent = nextMatch
    ? nextMatch.homeTeamId === myTeam.id
      ? nextMatch.awayName
      : nextMatch.homeName
    : 'Окно восстановления';
  const pressure = board.confidence >= 65 ? 'Стабильная позиция' : board.confidence >= 35 ? 'Нужно ускориться' : 'Кресло под угрозой';
  const pressureTone = board.confidence >= 65 ? 'text-[#22C55E]' : board.confidence >= 35 ? 'text-[#FACC15]' : 'text-[#EF4444]';

  return (
    <section className="hud-hero relative overflow-hidden rounded-2xl border border-primary/25 bg-card shadow-[0_18px_60px_rgba(0,0,0,0.28)]">
      <div className="hud-hero-grid absolute inset-0 opacity-60" aria-hidden />
      <div className="relative grid gap-7 p-5 sm:p-7 lg:grid-cols-[1.35fr_0.65fr]">
        <div className="min-w-0">
          <div className="mb-5 flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em]">
            <Badge className="border border-primary/30 bg-primary/10 text-primary">NEXUS FM // 2046</Badge>
            <span className="flex items-center gap-1.5 text-muted-foreground"><span className="live-dot" /> Командный центр</span>
          </div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-[0.16em] text-primary/80">Добро пожаловать, {save.managerName}</p>
          <h1 className="max-w-2xl text-2xl font-black tracking-tight sm:text-4xl">
            Следующий уровень начинается с <span className="neon-text text-primary">этой недели.</span>
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">
            {nextMatch ? `${save.weekInfo.label}. ${opponent} уже в фокусе штаба — настройте план и выходите за тремя очками.` : `${save.weekInfo.label}. Команда восстанавливается, а штаб готовит следующий рывок.`}
          </p>

          <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: 'Рейтинг клуба', value: myTeam.strength, suffix: '/100', icon: Gauge, tone: 'text-primary' },
              { label: 'Средний OVR', value: averageOvr, suffix: '', icon: Users, tone: 'text-[#A78BFA]' },
              { label: 'Место в лиге', value: place, suffix: `/${standings.length}`, icon: TrendingUp, tone: 'text-[#22C55E]' },
              { label: 'Доверие', value: board.confidence, suffix: '%', icon: Target, tone: pressureTone },
            ].map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.label} className="rounded-xl border border-border/60 bg-background/45 p-3 backdrop-blur-sm">
                  <div className="mb-2 flex items-center justify-between gap-1">
                    <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{stat.label}</span>
                    <Icon className={cn('size-3.5', stat.tone)} aria-hidden />
                  </div>
                  <p className={cn('tabular text-xl font-black', stat.tone)}>{stat.value}<span className="ml-0.5 text-xs font-semibold text-muted-foreground">{stat.suffix}</span></p>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex flex-col justify-between rounded-2xl border border-border/60 bg-background/40 p-4 backdrop-blur-sm sm:p-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Индекс недели</p>
              <p className={cn('mt-1 text-xs font-semibold', pressureTone)}>{pressure}</p>
            </div>
            <Activity className="size-5 text-primary" aria-hidden />
          </div>
          <div className="my-5 flex items-center gap-4">
            <div
              className="relative flex size-28 shrink-0 items-center justify-center rounded-full"
              style={{ background: `conic-gradient(#00D4FF ${readiness}%, rgba(30,42,58,0.75) 0)` }}
              aria-label={`Готовность команды ${readiness}%`}
            >
              <div className="flex size-[5.4rem] flex-col items-center justify-center rounded-full bg-card">
                <span className="tabular text-2xl font-black text-foreground">{readiness}%</span>
                <span className="text-[9px] uppercase tracking-wide text-muted-foreground">готовность</span>
              </div>
            </div>
            <div className="min-w-0 space-y-3">
              <div>
                <div className="mb-1 flex justify-between text-[10px] text-muted-foreground"><span>Мораль</span><span className="tabular font-bold text-foreground">{morale}%</span></div>
                <div className="h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-[#A78BFA]" style={{ width: `${morale}%` }} /></div>
              </div>
              <div>
                <div className="mb-1 flex justify-between text-[10px] text-muted-foreground"><span>Финансовый поток</span><span className={cn('tabular font-bold', finances.weeklyIncome - finances.weeklyWages >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]')}>{finances.weeklyIncome - finances.weeklyWages >= 0 ? '+' : ''}{formatMoney(finances.weeklyIncome - finances.weeklyWages)}</span></div>
                <div className="h-1.5 overflow-hidden rounded-full bg-secondary"><div className={cn('h-full rounded-full', finances.weeklyIncome - finances.weeklyWages >= 0 ? 'bg-[#22C55E]' : 'bg-[#EF4444]')} style={{ width: `${Math.min(100, Math.round((Math.abs(finances.weeklyIncome - finances.weeklyWages) / Math.max(1, finances.weeklyIncome)) * 100))}%` }} /></div>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between border-t border-border/50 pt-3 text-[11px]">
            <span className="text-muted-foreground">Состав под нагрузкой</span>
            <span className={cn('font-bold', injuries > 0 ? 'text-[#FACC15]' : 'text-[#22C55E]')}>{injuries > 0 ? `${injuries} травм` : 'Все готовы'}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function WeeklyBriefing() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const setTab = useGameStore((s) => s.setTab);
  const { nextMatch, nextMatchPreview, contractsExpiring, squadWarnings, board, save } = snapshot;
  const opponent = nextMatch
    ? nextMatch.homeTeamId === snapshot.myTeam.id ? nextMatch.awayName : nextMatch.homeName
    : null;
  const items = [
    {
      icon: nextMatch ? Target : CalendarDays,
      label: nextMatch ? 'Главная задача' : 'Ритм недели',
      title: nextMatch ? `Подготовиться к ${opponent}` : 'Восстановить состав',
      detail: nextMatchPreview ? `Преимущество в центре: ${nextMatchPreview.myLines.midfield} / ${nextMatchPreview.opponentLines.midfield}` : 'Следующий матч появится после симуляции недели',
      tab: 'match' as const,
      tone: 'text-primary',
    },
    {
      icon: contractsExpiring.length ? Zap : ShieldAlert,
      label: contractsExpiring.length ? 'Решение штаба' : 'Контроль состава',
      title: contractsExpiring.length ? `${contractsExpiring.length} контрактов требуют внимания` : 'Контракты под контролем',
      detail: contractsExpiring.length ? 'Продлите лидеров до выхода на рынок' : 'Критичных переговоров на этой неделе нет',
      tab: 'squad' as const,
      tone: contractsExpiring.length ? 'text-[#FACC15]' : 'text-[#22C55E]',
    },
    {
      icon: board.confidence < 40 ? AlertTriangle : Sparkles,
      label: 'Сигнал правления',
      title: board.confidence < 40 ? 'Нужна быстрая реакция' : 'Курс одобрен',
      detail: board.confidence < 40 ? 'Результат ближайшего матча критичен для позиции' : `Цель: ${board.targetLabel}`,
      tab: 'league' as const,
      tone: board.confidence < 40 ? 'text-[#EF4444]' : 'text-[#A78BFA]',
    },
  ];

  return (
    <section className="rounded-2xl border border-border/70 bg-card/80 p-4 sm:p-5">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.16em] text-primary"><Zap className="size-3.5" aria-hidden /> Оперативная сводка</p>
          <h2 className="mt-1 text-lg font-bold">Приоритеты недели <span className="text-muted-foreground">· С{save.season} / Н{save.week}</span></h2>
        </div>
        <p className="text-[11px] text-muted-foreground">Ассистент обновляет рекомендации после каждого матча</p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <button key={item.label} type="button" onClick={() => setTab(item.tab)} className="group flex min-h-[132px] flex-col rounded-xl border border-border/60 bg-secondary/25 p-3.5 text-left transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:bg-primary/5">
              <div className="flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">{item.label}</span><Icon className={cn('size-4', item.tone)} aria-hidden /></div>
              <p className="mt-3 text-sm font-bold leading-snug group-hover:text-primary">{item.title}</p>
              <p className="mt-auto pt-2 text-[11px] leading-relaxed text-muted-foreground">{item.detail}</p>
            </button>
          );
        })}
      </div>
      {squadWarnings.length > 0 ? <p className="mt-3 flex items-center gap-2 border-t border-border/50 pt-3 text-[11px] text-muted-foreground"><ShieldAlert className="size-3.5 shrink-0 text-primary" aria-hidden /> {squadWarnings[0]}</p> : null}
    </section>
  );
}

/** Фаза 4: плитка «Кубок Европы» — раунд, соперник, статус (паттерн BoardPanel). */
function EuroTile() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const setTab = useGameStore((s) => s.setTab);
  const euroCache = useGameStore((s) => s.euroCache);
  const euroLoading = useGameStore((s) => s.euroLoading);
  const fetchEuro = useGameStore((s) => s.fetchEuro);
  const { save, standings, myTeam } = snapshot;
  const myPlace = standings.find((r) => r.teamId === myTeam.id)?.place ?? null;

  useEffect(() => {
    void fetchEuro();
  }, [fetchEuro]);

  const euro = euroCache;
  if (!euro) {
    return euroLoading ? (
      <div className="rounded-lg border border-border/70 bg-card p-4">
        <p className="mb-2 flex items-center gap-1.5 text-xs font-bold">
          <Globe className="size-4 text-[#D4AF37]" aria-hidden />
          Кубок Европы
        </p>
        <div className="h-4 w-3/4 animate-pulse rounded bg-secondary" />
      </div>
    ) : null;
  }

  const quota = euro.quotas.find((q) => q.code === save.league.code)?.quota ?? 2;
  const next = euro.nextEuroMatch;

  let line: React.ReactNode;
  if (euro.status === 'winner') {
    line = <span className="font-bold text-[#D4AF37]">Чемпион Европы! 🏆</span>;
  } else if (euro.status === 'alive' && next) {
    line = (
      <>
        <span className="font-bold text-primary">{next.label}</span>
        <span className="text-muted-foreground">
          {' · соперник: '}
          <span className="font-semibold text-foreground">{next.opponent.name}</span>
          {next.opponent.isGuest ? ` (гость из ${next.opponent.leagueName})` : ''} ·{' '}
          {next.isHome ? 'дома' : 'в гостях'} · неделя <span className="tabular">{next.week}</span>
        </span>
      </>
    );
  } else if (euro.status === 'alive' || euro.status === 'qualified') {
    line = <span className="text-primary">Вы в игре · ждём жеребьёвку 1/8 финала</span>;
  } else if (euro.status === 'eliminated') {
    const label = euro.myEliminatedRound
      ? euro.rounds.find((r) => r.round === euro.myEliminatedRound)?.label
      : null;
    line = <span className="font-semibold text-[#EF4444]">Вылет в {label ?? 'раунде'}</span>;
  } else {
    line = (
      <span className="text-muted-foreground">
        Квота лиги: <span className="font-bold text-foreground">{quota} места</span> — зона топ-{quota}{' '}
        таблицы
        {myPlace !== null ? (
          <>
            {' · сейчас '}
            <span
              className={cn(
                'tabular font-bold',
                myPlace <= quota ? 'text-[#22C55E]' : 'text-[#FACC15]',
              )}
            >
              {myPlace}-е
            </span>
          </>
        ) : null}
      </span>
    );
  }

  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      onClick={() => setTab('euro')}
      className="flex w-full items-center gap-3 rounded-lg border border-[#D4AF37]/30 bg-card p-4 text-left transition-colors hover:border-[#D4AF37]/60"
      aria-label="Кубок Европы — перейти к турниру"
    >
      <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-[#D4AF37]/10">
        <Globe className="size-5 text-[#D4AF37]" aria-hidden />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-bold">Кубок Европы</p>
        <p className="mt-0.5 text-[11px] leading-relaxed">{line}</p>
      </div>
      <ArrowRight className="size-4 shrink-0 text-muted-foreground" aria-hidden />
    </motion.button>
  );
}

/** Фаза 4: индикатор нестандартного плана на матч (§7.5) — только при не-дефолте. */
function MatchPlanIndicator() {
  const matchPlanCache = useGameStore((s) => s.matchPlanCache);
  const fetchMatchPlan = useGameStore((s) => s.fetchMatchPlan);
  const setTab = useGameStore((s) => s.setTab);

  useEffect(() => {
    void fetchMatchPlan();
  }, [fetchMatchPlan]);

  if (!matchPlanCache) return null;
  const isDefault =
    matchPlanCache.leadMode === MATCH_PLAN_DEFAULT.leadMode
    && matchPlanCache.chaseMode === MATCH_PLAN_DEFAULT.chaseMode
    && matchPlanCache.fatigueSubs === MATCH_PLAN_DEFAULT.fatigueSubs;
  if (isDefault) return null;

  return (
    <button
      type="button"
      onClick={() => setTab('match')}
      className="flex min-h-11 w-full items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 px-3 py-2 text-left text-xs transition-colors hover:border-primary/40"
      aria-label="План на матч задан — перейти к настройке"
    >
      <ListChecks className="size-4 shrink-0 text-primary" aria-hidden />
      <span className="min-w-0 flex-1 truncate">
        План на матч:{' '}
        <span className="font-semibold">
          {MATCH_PLAN_LABELS.lead[matchPlanCache.leadMode]} · {MATCH_PLAN_LABELS.chase[matchPlanCache.chaseMode]}
        </span>
        {!matchPlanCache.fatigueSubs ? ' · без авто-замен' : ''}
      </span>
      <ArrowRight className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
    </button>
  );
}

function MiniTable() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const setTab = useGameStore((s) => s.setTab);
  const { standings, myTeam } = snapshot;

  const rows = useMemo(() => {
    const top = standings.slice(0, 6);
    const mine = standings.find((r) => r.teamId === myTeam.id);
    if (mine && mine.place > 6) return [...top, mine];
    return top;
  }, [standings, myTeam.id]);

  return (
    <div className="rounded-lg border border-border/70 bg-card p-4">
      <SectionHeader
        title="Таблица"
        subtitle={`Сезон ${snapshot.save.season}`}
        action={
          <Button variant="ghost" size="sm" onClick={() => setTab('league')} className="min-h-9">
            Полная
            <ArrowRight className="size-3.5" aria-hidden />
          </Button>
        }
      />
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="h-8 w-8 text-center text-[11px]">#</TableHead>
            <TableHead className="h-8 text-[11px]">Клуб</TableHead>
            <TableHead className="h-8 w-10 text-center text-[11px]">И</TableHead>
            <TableHead className="h-8 w-10 text-center text-[11px]">О</TableHead>
            <TableHead className="h-8 text-right text-[11px]">Форма</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((r, i) => {
            const showSeparator = i === 6;
            return (
              <TableRow
                key={r.teamId}
                className={cn(
                  'zebra h-9 border-border/40',
                  r.isUser && 'bg-primary/10 hover:bg-primary/10',
                  showSeparator && 'border-t-2 border-border',
                )}
              >
                <TableCell className="py-1 text-center text-xs tabular">{r.place}</TableCell>
                <TableCell className="py-1">
                  <div className="flex items-center gap-1.5">
                    <TeamCrest
                      shortName={r.shortName}
                      colorPrimary={r.colorPrimary}
                      colorSecondary={r.colorSecondary}
                      size="sm"
                      title={r.name}
                    />
                    <span className={cn('truncate text-xs', r.isUser && 'font-bold text-primary')}>
                      {r.name}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="py-1 text-center text-xs tabular text-muted-foreground">
                  {r.played}
                </TableCell>
                <TableCell className="py-1 text-center text-xs font-semibold tabular">
                  {r.points}
                </TableCell>
                <TableCell className="py-1 text-right">
                  <FormDots form={r.form} />
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

function NewsFeed() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const news = snapshot.news.slice(0, 8);

  return (
    <div className="flex h-full flex-col rounded-lg border border-border/70 bg-card p-4">
      <SectionHeader title="Новости клуба" subtitle="Последние события" />
      <ScrollArea className="h-72 pr-3">
        <ul className="space-y-2">
          {news.length === 0 ? (
            <li className="py-8 text-center text-xs text-muted-foreground">Пока тихо…</li>
          ) : (
            news.map((n) => {
              const Icon = NEWS_ICONS[n.type] ?? Newspaper;
              return (
                <li key={n.id} className="flex gap-2.5 rounded-md bg-secondary/40 p-2.5">
                  <div className="mt-0.5 rounded bg-secondary p-1.5">
                    <Icon className="size-3.5 text-muted-foreground" aria-hidden />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs leading-relaxed">{n.message}</p>
                    <p className="mt-1 text-[10px] text-muted-foreground">
                      Сезон {n.season} · тур {n.week}
                    </p>
                  </div>
                </li>
              );
            })
          )}
        </ul>
      </ScrollArea>
    </div>
  );
}

/** Цвет полосы доверия правления: ≥55 — газонный, 30–54 — жёлтый, <30 — красный. */
function confidenceBarClass(confidence: number): string {
  if (confidence >= 55) return 'bg-primary';
  if (confidence >= 30) return 'bg-[#EAB308]';
  return 'bg-[#EF4444]';
}

/**
 * Модуль 5: подпись статуса финцели правления для чипа на панели «Правление»
 * (no_debt — баланс ≥ 0; wage_control — зарплаты ≤ 65% дохода).
 */
function financeTargetOnTrackLabel(
  code: 'no_debt' | 'wage_control',
  balance: number,
  wageRatio: number,
): string {
  if (code === 'no_debt') return balance >= 0 ? ' — выполняется' : ' — баланс в минусе';
  return wageRatio <= 0.65 ? ' — выполняется' : ' — ведомость раздута';
}

/** Цвет бейджа статуса должности (7 статусов BOARD_JOB_STATUSES). */
function jobStatusBadgeClass(jobStatus: string): string {
  if (jobStatus === 'untouchable' || jobStatus === 'very_secure' || jobStatus === 'secure') {
    return 'border border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]';
  }
  if (jobStatus === 'stable') return 'bg-secondary text-foreground';
  if (jobStatus === 'pressured') return 'border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]';
  return 'border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]'; // hot_seat / on_edge
}

/** Панель «Правление»: цель сезона, доверие, статус должности, предупреждения (§7.2). */
function BoardPanel() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const setTab = useGameStore((s) => s.setTab);
  const setSquadExpiringOnly = useGameStore((s) => s.setSquadExpiringOnly);
  const boardCache = useGameStore((s) => s.boardCache);
  const fetchBoard = useGameStore((s) => s.fetchBoard);

  const { board, standings, myTeam, save, finances, contractsExpiring } = snapshot;
  const myPlace = standings.find((r) => r.teamId === myTeam.id)?.place ?? null;

  // Новости правления (последние 10 с сервера, показываем 2) — кеш инвалидируется каждую неделю.
  useEffect(() => {
    void fetchBoard();
  }, [fetchBoard]);

  const boardNews = boardCache?.news.slice(0, 2) ?? [];

  const goExpiring = () => {
    setSquadExpiringOnly(true);
    setTab('squad');
  };

  return (
    <div className="rounded-lg border border-border/70 bg-card p-4">
      <SectionHeader
        title="Правление"
        subtitle="Цель сезона и доверие к тренеру"
        action={
          <Badge className={cn('text-[11px]', jobStatusBadgeClass(board.jobStatus))}>
            {board.jobStatusLabel}
          </Badge>
        }
      />

      <div className="space-y-3">
        {/* Цель сезона */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-[11px] text-muted-foreground">Цель сезона</p>
            <p className="text-sm font-semibold leading-snug">{board.targetLabel}</p>
          </div>
          {myPlace !== null ? (
            <div className="shrink-0 text-right">
              <p className="text-[11px] text-muted-foreground">Место</p>
              <p
                className={cn(
                  'tabular text-sm font-bold',
                  myPlace <= board.targetPlace
                    ? 'text-[#22C55E]'
                    : myPlace <= board.targetPlace + 3
                      ? 'text-[#EAB308]'
                      : 'text-[#EF4444]',
                )}
              >
                {myPlace}-е из {standings.length}
              </p>
            </div>
          ) : null}
        </div>

        {/* Доверие правления */}
        <div>
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Доверие правления</span>
            <span className="tabular font-semibold">{board.confidence}/100</span>
          </div>
          <div
            className="h-2 w-full overflow-hidden rounded-full bg-secondary"
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={board.confidence}
            aria-label="Доверие правления"
          >
            <div
              className={cn('h-full rounded-full transition-all', confidenceBarClass(board.confidence))}
              style={{ width: `${board.confidence}%` }}
            />
          </div>
        </div>

        {/* Модуль 5: график доверия сезона (история недель, Recharts) */}
        {board.history.length >= 2 ? (
          <div>
            <div className="mb-1 flex items-center justify-between text-[11px]">
              <span className="text-muted-foreground">Доверие по неделям</span>
              <span className="text-[10px] text-muted-foreground">
                жёлтая — предупреждение (30), красная — ультиматум (20)
              </span>
            </div>
            <div className="h-[84px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={board.history} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                  <defs>
                    <linearGradient id="boardConfFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#22C55E" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#22C55E" stopOpacity={0.03} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="week"
                    tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }}
                    stroke="hsl(var(--border))"
                    interval="preserveStartEnd"
                    minTickGap={14}
                  />
                  <ReferenceLine y={30} stroke="#EAB308" strokeDasharray="3 3" strokeWidth={1} />
                  <ReferenceLine y={20} stroke="#EF4444" strokeDasharray="3 3" strokeWidth={1} />
                  <Area
                    type="monotone"
                    dataKey="confidence"
                    stroke="#22C55E"
                    strokeWidth={1.8}
                    fill="url(#boardConfFill)"
                    isAnimationActive={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        ) : null}

        {/* Модуль 5: бюджеты правления (трансферы / зарплаты) */}
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded bg-secondary/50 p-2">
            <div className="text-[10px] text-muted-foreground">Трансферный бюджет</div>
            <div className="tabular text-xs font-bold text-primary">
              {formatMoney(board.transferBudget)}
            </div>
          </div>
          <div className="rounded bg-secondary/50 p-2">
            <div className="flex items-center justify-between gap-1 text-[10px] text-muted-foreground">
              <span>Зарплатный бюджет</span>
              <span className="tabular">
                {Math.min(999, Math.round((finances.weeklyWages / Math.max(1, board.wageBudget)) * 100))}%
              </span>
            </div>
            <div
              className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-border"
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.min(100, Math.round((finances.weeklyWages / Math.max(1, board.wageBudget)) * 100))}
              aria-label="Использование зарплатного бюджета"
            >
              <div
                className={cn(
                  'h-full rounded-full',
                  finances.weeklyWages > board.wageBudget * WAGE_ALERT_RATIO
                    ? 'bg-[#EAB308]'
                    : 'bg-[#22C55E]',
                )}
                style={{
                  width: `${Math.min(100, (finances.weeklyWages / Math.max(1, board.wageBudget)) * 100)}%`,
                }}
              />
            </div>
            <div className="mt-0.5 tabular text-[10px] text-muted-foreground">
              {formatMoney(finances.weeklyWages)} / {formatMoney(board.wageBudget)} в нед
            </div>
          </div>
        </div>

        {/* Модуль 5: финансовая цель сезона */}
        {board.financeTarget ? (
          <p className="flex items-center gap-1.5 rounded bg-primary/10 px-2 py-1.5 text-[11px] text-primary">
            <Scale className="size-3.5 shrink-0" aria-hidden />
            Финцель правления: {board.financeTarget.label}
            {financeTargetOnTrackLabel(board.financeTarget.code, save.balance, finances.wageRatio)}
          </p>
        ) : null}

        {/* Медовый месяц */}
        {board.honeymoonWeeksLeft > 0 ? (
          <p className="flex items-center gap-1.5 rounded bg-primary/10 px-2 py-1.5 text-[11px] text-primary">
            <PartyPopper className="size-3.5 shrink-0" aria-hidden />
            Медовый месяц: ещё {board.honeymoonWeeksLeft}{' '}
            {board.honeymoonWeeksLeft === 1 ? 'неделя' : board.honeymoonWeeksLeft < 5 ? 'недели' : 'недель'} —
            правление снисходительно к ошибкам
          </p>
        ) : null}

        {/* Предупреждение / ультиматум */}
        {board.warnLevel !== 'none' ? (
          <p
            className={cn(
              'flex items-center gap-1.5 rounded border px-2 py-1.5 text-[11px] leading-relaxed',
              board.warnLevel === 'ultimatum'
                ? 'border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]'
                : 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]',
            )}
          >
            <AlertTriangle className="size-3.5 shrink-0" aria-hidden />
            {board.warnLevel === 'ultimatum'
              ? 'Ультиматум правления: несколько недель на исправление ситуации, иначе — отставка!'
              : 'Правление недовольно результатами — исправьте положение в таблице'}
          </p>
        ) : null}

        {/* Истекающие контракты */}
        <button
          type="button"
          onClick={goExpiring}
          disabled={contractsExpiring.length === 0}
          className={cn(
            'flex w-full min-h-11 items-center justify-between gap-2 rounded border px-2.5 text-left text-xs transition-colors',
            contractsExpiring.length > 0
              ? 'border-border/60 bg-secondary/40 hover:border-primary/40 hover:bg-primary/5'
              : 'border-border/40 bg-secondary/20 cursor-default',
          )}
          aria-label={
            contractsExpiring.length > 0
              ? `Истекают контракты: ${contractsExpiring.length} — перейти к составу с фильтром`
              : 'Все контракты в порядке'
          }
        >
          <span className="flex items-center gap-1.5 text-muted-foreground">
            <Landmark className="size-3.5 shrink-0" aria-hidden />
            Истекают контракты
          </span>
          <span className="flex items-center gap-1.5">
            <span
              className={cn(
                'tabular font-bold',
                contractsExpiring.length > 0 ? 'text-[#EAB308]' : 'text-[#22C55E]',
              )}
            >
              {contractsExpiring.length > 0 ? contractsExpiring.length : 'все в порядке'}
            </span>
            {contractsExpiring.length > 0 ? (
              <ArrowRight className="size-3.5 text-muted-foreground" aria-hidden />
            ) : null}
          </span>
        </button>

        {/* Последние новости правления */}
        {boardNews.length > 0 ? (
          <ul className="space-y-1.5 border-t border-border/50 pt-2">
            {boardNews.map((n) => (
              <li key={n.id} className="flex gap-2 text-[11px] leading-relaxed text-muted-foreground">
                <span className="shrink-0 tabular">С{save.season}·{n.week}</span>
                <span className="min-w-0">{n.message}</span>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}

function TeamState() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const players = snapshot.myPlayers;
  const avg = (fn: (p: (typeof players)[number]) => number) =>
    players.length ? Math.round(players.reduce((s, p) => s + fn(p), 0) / players.length) : 0;
  const avgMorale = avg((p) => p.morale);
  const avgCondition = avg((p) => p.condition);
  const injuries = players.filter((p) => p.injuryWeeks > 0).length;

  return (
    <div className="rounded-lg border border-border/70 bg-card p-4">
      <SectionHeader title="Состояние команды" subtitle={`${players.length} игроков`} />
      <div className="space-y-3">
        <div>
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Средняя мораль</span>
            <span className="tabular font-semibold">{avgMorale}</span>
          </div>
          <Progress value={avgMorale} className="h-2" />
        </div>
        <div>
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Средняя готовность</span>
            <span className="tabular font-semibold">{avgCondition}%</span>
          </div>
          <Progress
            value={avgCondition}
            className="h-2"
            aria-label="Средняя готовность состава"
          />
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Травмы</span>
          {injuries > 0 ? (
            <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]">
              <Bandage className="size-3" aria-hidden />
              {injuries}
            </Badge>
          ) : (
            <Badge className="border border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]">
              Все здоровы
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}

/** Панель быстрых действий — FM-паттерн «quick links» с тревог-бейджами. */
function QuickActions() {
  const setTab = useGameStore((s) => s.setTab);
  const snapshot = useGameStore((s) => s.snapshot)!;
  const expiring = snapshot.contractsExpiring.length;

  const actions: { id: TabId; label: string; icon: typeof ClipboardList; badge?: number }[] = [
    { id: 'tactics', label: 'Тактика', icon: ClipboardList },
    { id: 'training', label: 'Тренировки', icon: Dumbbell },
    { id: 'transfers', label: 'Трансферы', icon: ArrowLeftRight, badge: expiring },
    { id: 'academy', label: 'Академия', icon: GraduationCap },
    { id: 'territory', label: 'Территория', icon: Building2 },
    { id: 'finances', label: 'Финансы', icon: Wallet },
    { id: 'media', label: 'Медиа', icon: Newspaper },
  ];

  return (
    <div
      className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 sm:mx-0 sm:grid sm:grid-cols-7 sm:overflow-visible sm:px-0"
      role="toolbar"
      aria-label="Быстрые действия по разделам"
    >
      {actions.map((a) => (
        <button
          key={a.id}
          type="button"
          onClick={() => setTab(a.id)}
          className={cn(
            'relative flex min-h-11 shrink-0 flex-row items-center gap-1.5 rounded-full border px-3.5 text-xs font-medium transition-colors',
            'border-border/70 bg-card text-muted-foreground hover:border-primary/40 hover:bg-primary/5 hover:text-foreground',
            'sm:min-h-[64px] sm:flex-col sm:justify-center sm:gap-1.5 sm:rounded-lg sm:p-2 sm:text-[11px]',
          )}
          aria-label={`Перейти: ${a.label}${a.badge ? ` — контракты: ${a.badge}` : ''}`}
        >
          <a.icon className="size-4 shrink-0" aria-hidden />
          <span className="whitespace-nowrap">{a.label}</span>
          {a.badge && a.badge > 0 ? (
            <span className="absolute -right-1 -top-1 rounded-full bg-[#EAB308]/15 px-1.5 py-0.5 text-[9px] font-bold leading-none text-[#EAB308] tabular">
              {a.badge}
            </span>
          ) : null}
        </button>
      ))}
    </div>
  );
}

/** Модуль 6: график формы — последние 10 матчей клуба (голы за/против + очки). */
function TeamFormChart() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const myTeamId = snapshot.myTeam.id;

  const data = useMemo(() => {
    // Сезонные матчи клуба игрока (лига+кубок+евро): seasonMatches, а не fixtures
    // (fixtures — только текущая неделя).
    const played = snapshot.seasonMatches
      .filter((m) => m.played && (m.homeTeamId === myTeamId || m.awayTeamId === myTeamId))
      .sort((a, b) => a.week - b.week)
      .slice(-10);
    return played.map((m) => {
      const isHome = m.homeTeamId === myTeamId;
      const gf = isHome ? m.homeGoals ?? 0 : m.awayGoals ?? 0;
      const ga = isHome ? m.awayGoals ?? 0 : m.homeGoals ?? 0;
      const pts = gf > ga ? 3 : gf === ga ? 1 : 0;
      return { week: m.week, gf, ga, pts };
    });
  }, [snapshot.seasonMatches, myTeamId]);

  if (data.length < 2) {
    return null;
  }

  const lastPts = data.slice(-5).reduce((s, d) => s + d.pts, 0);

  return (
    <div className="rounded-lg border border-border/70 bg-card p-4 md:col-span-2 xl:col-span-1">
      <SectionHeader
        title="Форма команды"
        subtitle={`Последние ${data.length} матчей · ${lastPts} из 15 очков`}
      />
      <div className="h-[150px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 6, right: 4, bottom: 0, left: -22 }}>
            <CartesianGrid strokeDasharray="2 4" stroke="hsl(var(--border))" vertical={false} />
            <XAxis
              dataKey="week"
              tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }}
              stroke="hsl(var(--border))"
            />
            <YAxis
              tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }}
              stroke="hsl(var(--border))"
              allowDecimals={false}
            />
            <ChartTooltip
              cursor={{ fill: 'rgba(0,212,255,0.06)' }}
              contentStyle={{
                background: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: 8,
                fontSize: 11,
              }}
              formatter={(value: number | string, name: string) => [value, name]}
              labelFormatter={(label) => `Неделя ${label}`}
            />
            <Bar dataKey="gf" name="Забито" stackId="g" fill="#22C55E" radius={[0, 0, 0, 0]} maxBarSize={14} />
            <Bar dataKey="ga" name="Пропущено" stackId="g" fill="#EF4444" radius={[3, 3, 0, 0]} maxBarSize={14} />
            <Line
              type="monotone"
              dataKey="pts"
              name="Очки"
              stroke="#00D4FF"
              strokeWidth={2}
              dot={{ r: 2, fill: '#00D4FF' }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function DashboardScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { save, finances, squadWarnings, standings, myTeam } = snapshot;
  const myPlace = standings.find((r) => r.teamId === myTeam.id)?.place ?? 16;

  return (
    <div className="space-y-4">
      <CommandCenterHero />
      <WeeklyBriefing />
      <NextMatchTile />
      <EuroTile />
      <MatchPlanIndicator />
      <QuickActions />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        <MiniTable />
        <TeamFormChart />
        <NewsFeed />
        <TeamState />
        <BoardPanel />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 md:col-span-2 xl:col-span-1">
          <StatCard
            icon={PiggyBank}
            value={formatMoney(save.balance)}
            label="Баланс клуба"
            tone={save.balance < 0 ? 'danger' : 'default'}
          />
          <StatCard
            icon={ArrowLeftRight}
            value={formatMoney(save.transferBudget)}
            label="Бюджет трансферов"
            tone="success"
          />
          <StatCard
            icon={Wallet}
            value={`${formatMoney(finances.weeklyWages)}/нед`}
            label="Зарплатная ведомость"
            tone={finances.wageRatio > WAGE_ALERT_RATIO ? 'warning' : 'default'}
          />
        </div>

        <div className="flex flex-col gap-4 md:col-span-2 xl:col-span-3">
          <Alert className="border-primary/30 bg-primary/5">
            <HeartPulse className="size-4 text-primary" aria-hidden />
            <AlertTitle>Совет ассистента</AlertTitle>
            <AlertDescription className="flex flex-wrap items-center gap-x-3 gap-y-1">
              {squadWarnings.map((w, i) => (
                <span key={i} className="flex items-center gap-1.5 text-xs">
                  <ShieldAlert className="size-3 text-primary/70" aria-hidden />
                  {w}
                </span>
              ))}
              <span className="text-xs text-muted-foreground">
                Место в лиге: <span className="tabular font-semibold text-foreground">{myPlace}</span> ·
                доход за тур ≈ <span className="tabular">{formatMoney(finances.weeklyIncome)}</span>
              </span>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </div>
  );
}

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolvePlayingSave } from '@/lib/game/api-helpers';
import { LISTING_TTL } from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { canSellPlayer, type PlayerLike } from '@/lib/game/players';
import { buildSnapshot } from '@/lib/game/snapshot';
import { sellPriceBounds } from '@/lib/game/transfers';

const bodySchema = z.object({
  saveId: z.string().min(1).optional(),
  playerId: z.string().min(1),
  price: z.number().int().positive(),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/market/sell — выставить своего игрока на продажу.
 * Body: { saveId, playerId, price }. Без saveId (легаси-клиент Фазы 1) —
 * последний открытый активный сейв.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('PRICE_OUT_OF_BAND', 409);
    const { playerId, price } = parsed.data;

    const save = await resolvePlayingSave(parsed.data.saveId ?? null);

    const player = await db.player.findUnique({ where: { id: playerId } });
    if (!player || player.saveId !== save.id || player.teamId !== save.teamId) {
      return fail('NOT_YOUR_PLAYER', 400);
    }
    if (player.injuryWeeks > 0) return fail('PLAYER_INJURED', 409);

    // Фикс QA-8: валидация цены ДО проверки «уже выставлен» —
    // иначе ALREADY_LISTED маскировал реальную причину (цену вне диапазона).
    const bounds = sellPriceBounds(player.value);
    if (price < bounds.min || price > bounds.max) return fail('PRICE_OUT_OF_BAND', 409);

    const existing = await db.transferListing.findFirst({
      where: { playerId, status: 'active' },
    });
    if (existing) return fail('ALREADY_LISTED', 409);

    const squad = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId },
    });
    if (!canSellPlayer(squad as unknown as PlayerLike[], playerId)) {
      return fail('SQUAD_MIN_VIOLATION', 409);
    }

    const name = `${player.firstName} ${player.lastName}`;

    // playerId уникален в TransferListing: если лот уже был (продан/истёк) —
    // переиспользуем строку, иначе создаём новую.
    const priorRow = await db.transferListing.findFirst({ where: { playerId } });
    const listingOp = priorRow
      ? db.transferListing.update({
          where: { id: priorRow.id },
          data: { price, source: 'user', status: 'active', expiresAt: LISTING_TTL },
        })
      : db.transferListing.create({
          data: {
            id: crypto.randomUUID(),
            saveId: save.id,
            playerId,
            price,
            askFactor: 1.0,
            source: 'user',
            status: 'active',
            expiresAt: LISTING_TTL,
          },
        });
    await db.$transaction([
      listingOp,
      db.newsItem.create({
        data: {
          id: crypto.randomUUID(),
          saveId: save.id,
          season: save.season,
          week: save.week,
          type: 'transfer',
          message: `${name} выставлен на трансферный рынок за €${price.toLocaleString('ru-RU')}.`,
        },
      }),
    ]);

    const snapshot = await buildSnapshot(save.id);
    return NextResponse.json({ ok: true, snapshot });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/market/sell]', error);
    return fail('UNKNOWN', 500);
  }
}

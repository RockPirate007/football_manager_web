import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { matchPlanOf, normalizeErrorCode, resolvePlayingSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { parseMatchPlan } from '@/lib/game/types';
import type { MatchPlanDTO, MatchPlanResponse, SetMatchPlanResponse } from '@/lib/game/types';

const bodySchema = z.object({
  saveId: z.string().min(1).optional(),
  leadMode: z.enum(['park', 'hold']).optional(),
  chaseMode: z.enum(['allout', 'steady']).optional(),
  fatigueSubs: z.boolean().optional(),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/matchplan?saveId= — текущий план на матч клуба игрока
 * (Фаза 4, §6.1 architecture-phase4.md): Team.matchPlan → MatchPlanDTO;
 * null/битый JSON → дефолт («как тренеры ИИ»). finished-сейвы — 404.
 */
export async function GET(request: Request) {
  try {
    const save = await resolvePlayingSave(saveIdFromQuery(request));
    const plan = await matchPlanOf(save);
    const response: MatchPlanResponse = { ok: true, plan };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/matchplan]', error);
    return fail('UNKNOWN', 500);
  }
}

/**
 * POST /api/game/matchplan — сохранение плана на матч клуба игрока.
 * Body: { saveId?, leadMode?, chaseMode?, fatigueSubs? } — частичное
 * обновление (отсутствующие поля берутся из текущего плана); невалидные
 * значения → 400 INVALID_MATCH_PLAN. План пишется ТОЛЬКО клубу игрока
 * (ИИ движок подставляет дефолт).
 */
export async function POST(request: Request) {
  try {
    // Битый JSON / пустое тело → 400 (а не «частичное обновление без полей»)
    const json: unknown = await request.json().catch(() => null);
    if (json === null || typeof json !== 'object') return fail('INVALID_MATCH_PLAN', 400);
    const parsed = bodySchema.safeParse(json);
    if (!parsed.success) return fail('INVALID_MATCH_PLAN', 400);

    const save = await resolvePlayingSave(parsed.data.saveId ?? null);
    const team = await db.team.findUnique({
      where: { id: save.teamId },
      select: { id: true, matchPlan: true },
    });
    if (!team) return fail('SAVE_NOT_FOUND', 404);

    // Частичное обновление поверх текущего плана
    const current = parseMatchPlan(team.matchPlan);
    const plan: MatchPlanDTO = {
      leadMode: parsed.data.leadMode ?? current.leadMode,
      chaseMode: parsed.data.chaseMode ?? current.chaseMode,
      fatigueSubs: parsed.data.fatigueSubs ?? current.fatigueSubs,
    };

    await db.team.update({
      where: { id: team.id },
      data: { matchPlan: JSON.stringify(plan) },
    });

    const response: SetMatchPlanResponse = { ok: true, plan };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/matchplan]', error);
    return fail('UNKNOWN', 500);
  }
}

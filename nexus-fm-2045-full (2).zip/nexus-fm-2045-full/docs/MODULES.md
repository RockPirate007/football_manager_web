# MODULES.md — справочник модулей ядра (`src/lib/game/`)

> **Формат**: для каждого модуля — назначение, ключевые экспорты, зависимости (импорт из соседних модулей ядра; `@/lib/db` = Prisma-клиент).
> **Правила ядра**: чистые функции над POJO (`PlayerLike`), RNG — только явно параметром (детерминизм: одинаковый сид → одинаковый матч); доступ к Prisma имеют только `week.ts`, `snapshot.ts`, `api-helpers.ts` (и сами API-роуты). Хранение производного состояния запрещено («одна правда в одном месте»).
> **Объём**: 31 файл — 28 модулей ядра + 3 клиентских/UI-хелпера (`api.ts`, `format.ts`, `lineup.ts`).

## Соответствие фазам

| Фаза | Добавленные модули |
|---|---|
| 1 — MVP (движок) | poisson, rng, strength, match, standings, data, players, generate, progression, finances, transfers, week, snapshot, constants, types, error, format |
| 2 — мир и структуры | leagues, calendar, cup, training, awards, api-helpers, api |
| 3 — «AAA» | contracts, board, academy, history |
| 4 — Match AI + Кубок Европы | coach, euro |
| UI-хелпер | lineup |

## Движок матча (Фаза 1)

Математическое ядро: от состава и тактики к счёту и ленте событий. Полный движок считается для матчей клуба игрока (события, статистика, рейтинги), упрощённый — для ИИ-матчей (только голы).

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `poisson.ts` | Сэмплер распределения Пуассона (алгоритм Кнута) | `samplePoisson` | constants |
| `rng.ts` | Детерминированный RNG mulberry32 + утилиты; сид матча выводится из saveId/season/week/matchId | `mulberry32`, `hashString`, `matchSeed`, `gauss`, `clamp`, `randInt`, `pick`, `pickWeighted`, `shuffled` | — |
| `strength.ts` | Силы линий команды из состава + тактические модификаторы (ментальность/темп/прессинг/линия/стиль). Изоморфный — используется движком и экраном «Тактика» | `computeLines`, `applyModifiers`, `playerContribution`, `positionFitOf` | constants, players |
| `match.ts` | Сегментный движок симуляции (перестроен в Фазе 4): 3 сегмента [1–45][46–70][71–93] с пересчётом λ и тактики, время-взвешенные красные, «сушка»/«погоня», решения тренеров на контрольных точках 46'/70', замены до SUB_MAX с событиями `type:'sub'`, виртуальная усталость стартёров; упрощённый движок — для ИИ-матчей (~930 строк) | `simulateMatch`, `simulateAiMatch`, `MatchResult`, `MatchTeamInput`, `SubRecord` | constants, poisson, rng, strength, players, coach, types |
| `standings.ts` | Таблица лиги «на лету» из сыгранных матчей (очки, GF/GA, форма, зоны) | `computeStandings`, `StandingTeamInput`, `StandingMatchInput` | types |
| `data.ts` | Статические текстовые шаблоны событий матча (`{player}` — подстановка) | `GOAL_TEMPLATES`, `CHANCE_TEMPLATES`, `YELLOW/RED/INJURY_TEMPLATES`, `PEN_*_TEMPLATES` | — |

## Игроки и прогрессия (Фаза 1)

Домен игрока: генерация, экономика атрибутов, развитие и старение.

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `players.ts` | Генерация игрока, расчёт OVR/стоимости/зарплаты, автосостав, валидация состава, номера, уникальность имён. Центральный домен ядра | `generatePlayer`, `computeOvr`, `computeValue`, `computeSalary`, `refreshEconomy`, `autoLineup`, `isLineupValid`, `canSellPlayer`, `playerCreateData`, `PlayerLike` | constants, contracts, leagues, rng, types |
| `generate.ts` | Генерация мира по LeagueDef: команды из данных лиг, составы 20–22 игрока, календарь-карусель с маппингом тура → сквозная неделя; Фаза 4: назначение стилей/имён ИИ-тренеров и `generateEuroGuests` — 13–14 гостевых клубов еврокубка с полными составами (isEuroGuest) | `generateLeague`, `generateSquad`, `generateCalendar`, `generateEuroGuests`, `assignAiStyle`, `poolContextOf`, `WorldGen` | calendar, leagues, players, rng, types |
| `progression.ts` | Пост-матчевые апдейты (мораль/форма/статистика/травмы/рейтинг матча 4.5–10; Фаза 4: `applyMatchEffects` с учётом сыгранных минут/замен + еженедельное восстановление `applyWeeklyRecovery`) и межсезонье (старение, развитие, пенсии) | `computeMatchRating`, `applyMatchEffects`, `applyWeeklyRecovery`, `applyPostMatch`, `applySeasonProgression`, `retires` | constants, players, rng, types |

## Экономика и трансферы (Фаза 1)

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `finances.ts` | Финансы клуба игрока: недельная ведомость, посещаемость/билеты, спонсор, алерт зарплат (>70% дохода) | `computeWeekFinance`, `weeklyWages`, `weeklyIncomeEstimate`, `sponsorIncome`, `attendanceRate`, `isWageAlert` | constants, players, types |
| `transfers.ts` | Трансферы: генерация рынка (50–70 лотов), формула стоимости, границы цены продажи, интерес ИИ, выбор покупок ИИ | `generateMarketListing`, `marketTopUpCount`, `sellPriceBounds`, `sellOfferProbability`, `pickAiPurchase` | constants, players, rng, leagues, types |

## Данные мира (Фаза 2)

Единственный источник «реального» мира и производных от него структур времени.

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `leagues.ts` | Данные 6 реальных лиг: 112 клубов (названия/города/цвета/силы/стадионы) + пулы имён 6 стран + микс легионеров | `LEAGUES`, `NAME_POOLS`, `NAT_TO_POOL`, `leagueByCode`, `leagueAvgStrength`, `LeagueDef` | types |
| `calendar.ts` | Календарь сезона: сквозные недели, типы недель (лига/кубок), CUP_WEEKS; кеш планов по leagueCode | `buildSeasonPlan`, `weekSlotAt`, `leagueWeekOf`, `weekLabelOf`, `cupRoundsOf`, `cupWeeksOf`, `CUP_WEEKS` | leagues, types |

## Оркестрация и снапшот (серверные, Фазы 1–3)

Единственные модули ядра с доступом к базе: чистая логика соединяется с Prisma здесь.

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `week.ts` | Оркестратор недели: матч (лига/кубок/евро), тренировки, финансы, рынок, новости, правление, Босман, академия + сезонный переход (награды → снапшот истории → вердикт правления → контракты/подписания ИИ → старение/пенсии → новый календарь). Фаза 4: евронедели (жеребьёвка/матчи/призы), congestion-недели (2 матча, drain ×2 + recovery ×1), квалификация и ростер Кубка Европы, блок 6-FA (старение свободных агентов). Самый «толстый» модуль (~2850 строк) | `simulateWeek` | @/lib/db + почти все модули ядра |
| `snapshot.ts` | Сборка снапшота состояния (GET /state, ответы buy/sell): weekInfo, таблица, кубок, тренировки, лидеры, правление, истекающие контракты, DTO-преобразования | `buildSnapshot`, `toPlayerDTO`, `toTeamDTO`, `toTeamBrief`, `boardDtoOf`, `contractsExpiringOf` | @/lib/db, @prisma/client, calendar, awards, board, error, finances, leagues, players, strength, standings, training, types |
| `api-helpers.ts` | Серверные хелперы роутов: доступ к сейву по saveId, легаси-фолбэк Фазы 1, карточки карьер, нормализация кодов ошибок | `requireSave`, `resolveSave`, `resolvePlayingSave`, `legacyActiveSave`, `buildSaveCards`, `buildSaveCard`, `normalizeErrorCode` | @/lib/db, calendar, error, leagues, standings, types |

## Механики Фазы 2

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `cup.ts` | Кубковый турнир: жеребьёвка («слабый дома», p=0.7), пенальти до внезапной смерти, ИИ-матчи, призовые по раундам | `drawCupRound`, `prelimParticipants`, `simulateAiCupMatch`, `simulatePenaltyShootout`, `shootoutTakers`, `prizeForRound` | constants, match, players, rng, types |
| `training.ts` | Недельные тренировки: фокус × интенсивность, xp-накопление (g = TRAIN_BASE × I × возраст × запас потенциала), потолок potential, состояние/травмы; выбор ИИ тем же кодом | `applyWeeklyTraining`, `aiTrainingChoice`, `FOCUS_ATTRS`, `attrsForPlayer`, `ageCurveOf`, `coerceTrainingFocus/Intensity` | constants, players, rng, types |
| `awards.ts` | Награды сезона: 8 типов (6 индивидуальных + 2 командных), MVP-формула, бонусы лауреатам, live-лидеры текущего сезона | `computeSeasonAwards`, `applyAwardBonuses`, `liveLeaders`, `liveCupScorers`, `mvpScore`, `AWARD_CEREMONY_ORDER` | constants, players, rng, types |

## Механики Фазы 3 «AAA»

Все четыре — чистые функции (без Prisma); запись в БД выполняет `week.ts` и роуты.

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `contracts.ts` | Контракты: сроки (1–4 г., абсолютная шкала contractUntil), зарплатный спрос по роли, решения ИИ (продления/подписания с guard состава ≥15), Босман-вероятности, жадное пополнение составов ИИ | `contractYearsRoll`, `contractUntilFromYears`, `yearsLeftOf`, `contractRoleOf`, `renewDemand`, `renewalOutcome`, `bosmanProbability`, `aiContractDecisions`, `aiReplenishmentPicks` | constants, players, rng |
| `board.ts` | Цели правления (champion/ucl/uel/upper/safe/survive), board confidence 0–100, 7 статусов должности, медовый месяц, еженедельный апдейт и вердикт сезона (мет/овер/промах/увольнение) | `boardTargetFor`, `nextSeasonTarget`, `weeklyBoardUpdate`, `evaluateSeasonTarget`, `jobStatusOf`, `boardWarnLevel`, `strengthRankOf` | constants, rng |
| `academy.ts` | Молодёжная академия: набор в неделю 4 (2–6 игроков 16–17 лет, OVR 34–52, контракт 3 года), тиры по силе клуба, «жемчужины» (POT 85–93) и «золотой набор» | `runIntakeForClub`, `academyTierOf`, `starsOf`, `starsLabelOf`, `weakestGroupOf`, `intakeNews` | constants, leagues, rng, types |
| `history.ts` | История игрока по сезонам: строки снапшота (avgRating ×10, Int без float-дрейфа) и карьерные итоги | `buildSeasonRecords`, `careerTotalsOf`, `SeasonRecordRow`, `FREE_AGENT_TEAM_NAME` | players |

## Механики Фазы 4 «Match AI + Кубок Европы»

Оба новых модуля — чистые функции (без Prisma); запись в БД выполняет `week.ts` и роуты `/matchplan`, `/euro`. Гостевые клубы еврокубка (`isEuroGuest`) изолированы от лиги/рынка/нацкубка 7 фильтрами (таблица, рынок, лидеры, кубок, Босман, академия, контракты).

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `coach.ts` | Решения ИИ-тренера по ходу матча: FSM «счёт × фаза» (9 состояний) задаёт пакет допустимых действий, Utility-скоры с шумом ±10 выбирают замену (усталость/погоня/оборона); замены по усталости (≥60'), для погони, вынужденные при травмах; смена схемы при панике (3-4-3) через remap-слотов; ленивая миграция легаси-стилей; смена стилей в сезонном переходе (p=0.25, топ-6 — 0.10) | `coachDecide`, `remapForFormation`, `guessAiStyle`, `aiStyleChangesFor`, `aiDefaultPlan`, `CoachSideState`, `CoachDecision`, `SubPlan`; реэкспорт `AI_STYLES`/`AI_STYLE_CODES`/`AI_STYLE_ASSIGN` | constants, generate, players, rng, types |
| `euro.ts` | Кубок Европы: евронедели по размеру лиги (мидвики, без удлинения сезона), квалификация 16 участников по квотам лиг (EPL/LAL/SEA/BUN=3 + FL1/RPL=2, своя лига — топ таблицы, остальные — реальные клубы по силе с шумом), ростер с 13–14 гостями (составы ≥18), жеребьёвка нокаута (посев по силе, запрет пар одной лиги в 1/8, «слабый дома» p=0.7), призовые (участие €2M, чемпион суммарно €13M), ИИ-матчи и пенальти, сериализация состояния в GameSave | `euroParticipants`, `resolveEuroRoster`, `drawEuroRound`, `euroPrizeFor`, `simulateEuroAiMatch`, `euroCtxOf`, `euroRoundOf`, `euroWeeksOf`, `euroRoundAt`, `parseEuroTeamIds`/`serializeEuroTeamIds` | calendar, constants, cup, generate, leagues, rng, types |

Существенные изменения существующих модулей в Фазе 4: `match.ts` (сегментный движок, ~930 строк), `progression.ts` (`applyMatchEffects`/`applyWeeklyRecovery`), `week.ts` (евронедели/конгестион/блок 6-FA), `generate.ts` (`generateEuroGuests`, `assignAiStyle`), `awards.ts` (`liveEuroScorers`), `constants.ts` (блоки `SEGMENT_*`, `SUB_*`, `UTILITY_*`, `AI_STYLE_*`, `EURO_*`, ЖК 1.9, красные 0.55/1.30/0.70/1.15, дренаж 30/60).

## Общие и клиентские модули

| Модуль | Назначение | Ключевые экспорты | Зависимости |
|---|---|---|---|
| `constants.ts` | **Все константы баланса** — единственное место «магических чисел»: мир, экономика, λ матча, тактика, формации (13 схем), кубок, тренировки, награды, контракты, Босман, академия, правление + Фаза 4: сегментный движок, замены, Utility, стили ИИ, Кубок Европы + `coerce*`-валидаторы | `BASE_GOALS`, `HOME_ADVANTAGE`, `FORMATIONS`, `TRAIN_*`, `CUP_*`, `CONTRACT_*`, `BOSMAN_*`, `ACADEMY_*`, `BOARD_*`, `SEGMENT_*`, `SUB_*`, `UTILITY_*`, `AI_STYLE_*`, `EURO_*`, `coerceFormation`… | types |
| `types.ts` | Все типы/DTO игры (изоморфный — сервер и клиент): снапшот, игроки, матчи, таблица, кубок, контракты, правление, академия + парсеры JSON-полей Prisma | `GameSnapshot`, `PlayerDTO`, `TeamDTO`, `WeekResultPayload`, `MatchEvent`, `StandingRow`, `BoardDTO`, `parseLineup`, `parseEvents`, `parseStats`, `parseTrainingXp` | constants |
| `error.ts` | Ошибка игрового API с кодом и HTTP-статусом + человекочитаемые сообщения | `ApiGameError`, `ERROR_MESSAGES` | — |
| `format.ts` | UI-форматирование (изоморфно): компактные € (`€1.2M`), цвета OVR/атрибутов/зон таблицы | `formatMoney`, `formatMoneyExact`, `strengthLabel`, `ovrColor`, `attrColor`, `zoneClass` | — |
| `lineup.ts` | Хелпер состава для UI: эффективный состав (сохранённый менеджером или автосостав) | `effectiveLineup`, `EffectiveLineup` | players, types |
| `api.ts` | Типизированные fetch-обёртки игрового API (клиентская часть): все 25 эндпоинт-методов, единая обработка ошибок сервера | `api` (getLeagues, createSave, getSaves, getState, simulate, buy, sell, setTactic, getTraining, getAwards, getContracts, renewContract, getBoard, getAcademy, getPlayerDialog, getMatchPlan/setMatchPlan, getEuro…), `ApiClientError` | error, types |

---

## Карта зависимостей (кратко)

- `rng` и `data` — «листья» (ни от кого не зависят);
- `constants` ← почти все; `types` ← почти все (изоморфный слой DTO);
- `players` — центральный домен (движок, экономика, генерация, UI-валидация);
- `match` ← `coach` (на контрольных точках 46'/70' движок спрашивает решения тренера); `euro` → переиспользует пенальти и ИИ-стороны `cup` + генерацию гостей `generate`;
- `week.ts` — вершина: единственное место, где чистые модули соединяются с Prisma (в Фазе 4 — ещё и оркестрация евронеделей/конгестиона);
- цепочка клиента: компоненты → `store.ts` → `api.ts` → REST-роуты → `api-helpers` → `week`/`snapshot` → чистое ядро.

## Типовой сценарий: одна кнопка «Продолжить»

1. `POST /api/game/simulate` (`saveId`) → роут → `week.ts::simulateWeek`.
2. Неделя: `calendar` (тип недели) → `match`/`cup`/`euro` (матчи; евронеделя: жеребьёвка → матч клуба игрока с полным движком/ИИ-матчи → призы; congestion — 2 матча) → `progression` (пост-матч: мораль, форма, рейтинг, восстановление) → `training` (все клубы) → `finances` (клуб игрока) → `transfers` (регенерация рынка, ИИ-покупки) → `board` (доверие, предупреждения) → Босман (`contracts`) → академия (неделя 4, `academy`).
3. Конец сезона: `awards` → `history` (снапшот ~450 строк) → `board` (вердикт) → `contracts` (исполнения/продления/подписания ИИ) → `progression` (старение/пенсии, включая свободных агентов — блок 6-FA) → `coach.aiStyleChangesFor` (смена стилей p=0.25) → `euro.resolveEuroRoster` + `generate.generateEuroGuests` (квалификация и гости нового сезона) → `generate`/`calendar` (новый мир-календарь).
4. Ответ `WeekResultPayload` → `snapshot.buildSnapshot` → клиент обновляет стор и экраны.

## Типовые задачи: где что менять

| Задача | Куда смотреть |
|---|---|
| Изменить баланс матча (голов больше/меньше, преимущество хозяев) | `constants.ts`: `BASE_GOALS`, `HOME_ADVANTAGE`, `LAMBDA_MIN/MAX` (после правки `HOME_ADVANTAGE` прогоните `scripts/calibrate_home.py`) |
| Перекроить экономику (стоимость, зарплаты, призовые) | `constants.ts`: `VALUE_*`, `SALARY_*`, `PRIZE_MONEY_BY_SIZE`, `SPONSOR_*`; логика — `players.ts`, `finances.ts` |
| Настроить тренировки (скорость роста, травмы) | `constants.ts`: `TRAIN_*`; логика — `training.ts` |
| Изменить кубок (частота туров, призы, пенальти) | `constants.ts`: `CUP_*`, `PEN_*`, `CUP_WEEKS` в `calendar.ts`; логика — `cup.ts` |
| Настроить сегментный движок (доли голов, красные, «сушка»/«погоня») | `constants.ts`: `SEGMENT_*`, `RED_LAMBDA_*`, `PARKING_BUS_MOD`/`CHASE_MOD`; калибровка — `scripts/calibrate_segments.ts` |
| Стиль ИИ-тренеров / агрессивность замен | `constants.ts`: `AI_STYLE_*`, `UTILITY_*`, `SUB_*`; логика — `coach.ts` |
| Кубок Европы (квоты, недели, призы, гости) | `constants.ts`: `EURO_*`; логика — `euro.ts`; оркестрация — `week.ts` |
| Перекроить контракты/Босмана/академию/правление | `constants.ts`: `CONTRACT_*`, `BOSMAN_*`, `ACADEMY_*`, `BOARD_*`; логика — `contracts.ts` / `academy.ts` / `board.ts` |
| Добавить лигу или клуб | `leagues.ts` (данные + пул имён) и `calendar.ts` подхватит размер автоматически |
| Поменять формации | `constants.ts`: `FORMATIONS` (13 схем со слотами) |
| Добавить новый экран/механику | новый чистый модуль в `src/lib/game/` (паттерн: RNG параметром, без Prisma) + вызов из `week.ts` + DTO в `types.ts` + константы в `constants.ts` |

## Чего в ядре осознанно нет

(фиксация объёма Фазы 3, §0 `docs/architecture-phase3.md`; замены добавлены в Фазе 4): MOTM в отчёте матча; релиз-клаузул; многораундовых переговоров «с настроением агента»; зарплатного бюджета как отдельной сущности; режима «Безработица» с офферами клубов после увольнения (sack завершает карьеру экраном «Карьера завершена»); 9-й награды «Лучший рейтинг лиги» (наград осталось 8); группового этапа еврокубка (Фаза 4 — только нокаут).

См. также: `README.md` (запуск и структура), `docs/architecture*.md` (ТЗ фаз, формулы), `worklog.md` (история разработки).

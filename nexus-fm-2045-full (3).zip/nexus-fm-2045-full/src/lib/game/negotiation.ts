/**
 * Модуль 3 «Контрактные переговоры при подписании»: зарплатный спрос нового
 * контракта (signing demand) и оценка предложения клуба (accepted / counter /
 * rejected с причиной). Чистые функции; RNG — только в evaluateSigningOffer
 * («настроение агента» — жёсткий/уступчивый порог недели, детерминированный
 * броском вызывающего).
 *
 * Формула спроса (фамильная с renewDemand §6.1, но без истории клуба):
 *   base = computeSalary(value) × roleMult(роль в составе ПОКУПАТЕЛЯ)
 *   × (age ≥ 35 ? 0.75 : age ≥ 32 ? 0.90 : 1) × (morale < 40 ? 1.15 : 1)
 *   × ((pot − ovr) ≥ 8 && age ≤ 23 ? 1.20 : 1)
 * Роль в составе покупателя оценивается по OVR игрока против среднего OVR
 * топ-11 покупателя (клиент может передать средний OVR своего состава).
 */

import {
  CONTRACT_AGE_MULT_32, CONTRACT_AGE_MULT_35, CONTRACT_LOW_MORALE,
  CONTRACT_LOW_MORALE_MULT, CONTRACT_MAX_YEARS, CONTRACT_ROLE_MULT,
  CONTRACT_TALENT_AGE, CONTRACT_TALENT_GAP, CONTRACT_TALENT_MULT,
  SALARY_MIN, SALARY_ROUND,
} from './constants';
import type { ContractRole } from './contracts';
import { computeSalary, type PlayerLike } from './players';
import { clamp, type RNG } from './rng';

export interface SigningDemand {
  /** Требуемая зарплата €/нед. */
  salary: number;
  /** Желаемый срок (лет) по возрасту. */
  years: number;
  /** Премия за гол € (0 для GK/DEF — их интересуют сухие). */
  goalBonus: number;
  /** Премия за сухой матч €. */
  cleanSheetBonus: number;
}

/** Оценка роли игрока в составе покупателя по среднему OVR топ-11 хозяев. */
export function roleForBuyer(playerOvr: number, buyerTop11Avg: number): ContractRole {
  const diff = playerOvr - buyerTop11Avg;
  if (diff >= 4) return 'star';
  if (diff >= -2) return 'starter';
  if (diff >= -7) return 'rotation';
  return 'depth';
}

/** Желаемый срок по возрасту: молодой — длинный, ветеран — короткий. */
export function desiredYearsOf(age: number): number {
  if (age <= 23) return 4;
  if (age <= 29) return 3;
  if (age <= 32) return 2;
  return 1;
}

/**
 * Полный спрос подписания: зарплата + срок + бонусы. Бонусы от стоимости:
 * атакующим — за голы, GK/оборонительным — за сухие матчи (≈ 0.15% стоимости
 * за гол, 0.05% за сухой матч; округление к €100).
 */
export function signingDemandOf(args: {
  player: PlayerLike;
  buyerTop11Avg: number;
}): SigningDemand {
  const { player, buyerTop11Avg } = args;
  const role = roleForBuyer(player.ovr, buyerTop11Avg);
  const roleMult = CONTRACT_ROLE_MULT[role];
  const nominal = computeSalary(player.value);
  let x = Math.max(nominal * roleMult, nominal * 1.05); // «новый клуб — новая цена»
  if (player.age >= 35) x *= CONTRACT_AGE_MULT_35;
  else if (player.age >= 32) x *= CONTRACT_AGE_MULT_32;
  if (player.morale < CONTRACT_LOW_MORALE) x *= CONTRACT_LOW_MORALE_MULT;
  if (player.potential - player.ovr >= CONTRACT_TALENT_GAP && player.age <= CONTRACT_TALENT_AGE) {
    x *= CONTRACT_TALENT_MULT;
  }
  const salary = Math.max(SALARY_MIN, Math.round(x / SALARY_ROUND) * SALARY_ROUND);

  const isAttacker = ['AM', 'ST'].includes(player.position) || player.position.startsWith('AM');
  const isDefender = player.position === 'GK' || ['DL', 'DC', 'DR', 'DML', 'DMC', 'DMR'].includes(player.position);
  const goalBonus = isAttacker
    ? Math.round((player.value * 0.0015) / 100) * 100
    : Math.round((player.value * 0.0004) / 100) * 100;
  const cleanSheetBonus = isDefender
    ? Math.round((player.value * 0.0006) / 100) * 100
    : 0;

  return { salary, years: desiredYearsOf(player.age), goalBonus, cleanSheetBonus };
}

export type SigningDecision =
  | { kind: 'accepted' }
  | { kind: 'counter'; demand: SigningDemand; message: string }
  | { kind: 'rejected'; reason: 'salary' | 'bonus' | 'years'; message: string };

export interface SigningOfferInput {
  salary: number;
  years: number;
  goalBonus: number;
  cleanSheetBonus: number;
}

/**
 * Оценка предложения: агент принимает при зарплате ≥ ~0.95 × demand (порог
 * плавает с «настроением» rng: жёсткий агент требует ровно спрос, мягкий
 * согласится на 0.90), бонусы ≥ 0.75 × demand и отклонении срока не более
 * чем на год. Близкое предложение → counter с точным спросом; дальнее →
 * отказ с причиной (клиент показывает, что именно не устроило).
 */
export function evaluateSigningOffer(args: {
  player: PlayerLike;
  demand: SigningDemand;
  offer: SigningOfferInput;
  rng: RNG;
}): SigningDecision {
  const { player, demand, offer, rng } = args;
  const name = `${player.firstName} ${player.lastName}`;

  const mood = rng(); // 0 — жёсткий агент, 1 — уступчивый
  const salaryFloor = demand.salary * (1.0 - mood * 0.08); // 0.92..1.0 × demand
  const bonusFloor = (demand.goalBonus + demand.cleanSheetBonus) * 0.75;

  const yearsOk = Math.abs(offer.years - demand.years) <= 1
    && offer.years >= 1
    && offer.years <= CONTRACT_MAX_YEARS;
  const salaryOk = offer.salary >= salaryFloor;
  const bonusOk = offer.goalBonus + offer.cleanSheetBonus >= bonusFloor - 1;

  if (salaryOk && bonusOk && yearsOk) return { kind: 'accepted' };

  // Отказ или торг — что «больнее»: сортируем по относительному отставанию
  const salaryGap = offer.salary / Math.max(demand.salary, 1);
  const bonusGap = (offer.goalBonus + offer.cleanSheetBonus + 1)
    / Math.max(demand.goalBonus + demand.cleanSheetBonus, 1);
  if (!salaryOk && salaryGap < 0.8) {
    return {
      kind: 'rejected', reason: 'salary',
      message: `${name} не устраивает зарплата: агент требует заметно больше.`,
    };
  }
  if (!yearsOk && !salaryOk) {
    return {
      kind: 'rejected', reason: 'years',
      message: `${name} хочет другой срок контракта и большую зарплату.`,
    };
  }
  if (!bonusOk && bonusGap < 0.5) {
    return {
      kind: 'rejected', reason: 'bonus',
      message: `${name} рассчитывает на более весомые бонусные выплаты.`,
    };
  }
  // Близко — контрпредложение ровно в спрос
  const wanted = clamp(demand.years, 1, CONTRACT_MAX_YEARS);
  return {
    kind: 'counter',
    demand: { ...demand, years: wanted },
    message: `${name} готов обсудить условия, но требует €${demand.salary.toLocaleString('ru-RU')}/нед и ${wanted} ${pluralYears(wanted)}.`,
  };
}

/** Дефолт-контракт «без переговоров» (легаси-клиент Фазы 1): подпись по спросу. */
export function defaultSigningOf(demand: SigningDemand): SigningOfferInput {
  return {
    salary: demand.salary,
    years: demand.years,
    goalBonus: demand.goalBonus,
    cleanSheetBonus: demand.cleanSheetBonus,
  };
}

function pluralYears(n: number): string {
  return n === 1 ? 'год' : n >= 2 && n <= 4 ? 'года' : 'лет';
}

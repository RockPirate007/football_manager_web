/**
 * ENGINE 2.0 — калибровочные константы событийного матчевого движка.
 * Все значения прошли калибровку scripts/engine2_calibrate.ts:
 * цель — средние тотал голов ≈ 2.5–2.9, победы хозяев 42–48%,
 * удары 8–16 на команду, владение 25–75%.
 */

// ── Темп матча (действий за минуту владения) ─────────────────────────────
export const APM_BASE = 1.15; // среднее число действий/мин владеющей командой
export const APM_TEMPO: Record<string, number> = { low: 0.88, medium: 1.0, high: 1.24 };
export const APM_ZONE_FACTOR = 0.75; // затухание числа действий при прогрессе (ATT жарче)

// ── Выносливость ─────────────────────────────────────────────────────────
/** Дрейн энергии за минуту: базовый множитель (темп × прессинг × стамина). */
export const DRAIN_PER_MIN = 0.7;
export const DRAIN_TEMPO: Record<string, number> = { low: 0.86, medium: 1.0, high: 1.18 };
export const DRAIN_PRESSING: Record<string, number> = { low: 0.93, medium: 1.0, high: 1.12 };
/** Стамина 100 → ×0.72 дрейна; стамина 30 → ×1.22. */
export const DRAIN_STAMINA_SLOPE = -0.0022;
export const DRAIN_STAMINA_BASE = 0.94;
/** Мин-эффективность уставшего игрока (атрибуты × mult). */
export const EFF_MULT_FLOOR = 0.52;
export const EFF_MULT_SPAN = 0.48; // mult = FLOOR + SPAN × (energy/100)
/** Дополнительный дрейн при спринте (участие в дуэли/рывке). */
export const DRAIN_SPRINT = 0.55;

// ── Мораль в матче ───────────────────────────────────────────────────────
export const MORALE_GOAL_SCORED = 9;
export const MORALE_GOAL_CONCEDED = -10;
export const MORALE_RED = -9;
export const MORALE_BIG_MISS = -3;
export const MORALE_SAVE = 2;
export const MORALE_HALFTIME_LOSING_TALK = 4;
/** Лидерство гасит качели морали: swing × (1 − avgLead × DAMP). */
export const MORALE_LEAD_DAMP = 0.0022;
/** Мораль → множитель атрибутов: 0.93..1.07. */
export const MORALE_MULT_FLOOR = 0.93;
export const MORALE_MULT_SPAN = 0.14;

// ── Дуэли ────────────────────────────────────────────────────────────────
/** Логистическая крутизна: p = k·exp(Δ/s) / (1 + k·exp(Δ/s)). */
export const DUEL_SLOPE = 9.0;
/** Базовые шансы атакующего по типу действия (odds-множитель k). */
export const DUEL_BIAS = {
  safePass: 1.45,
  progPass: 1.0,
  throughBall: 0.72,
  longBall: 0.9,
  dribble: 0.95,
  cross: 0.85,
  clearance: 2.2,
} as const;

// ── Удары и xG-контексты ─────────────────────────────────────────────────
export const SHOT_XG = {
  boxCentre: 0.24, // удар после прострела/паса в штрафную
  boxFlank: 0.14, // удар с фланга штрафной / после навеса
  boxSelf: 0.2, // обыграл и бьёт из штрафной
  header: 0.12, // головой после навеса
  cornerHeader: 0.1, // головой с углового
  longShot: 0.04, // из-за штрафной (ATT_C)
  cutInside: 0.07, // сместился с фланга и пробил
  freeKick: 0.05, // прямой штрафной
  penalty: 0.76,
} as const;

/** Доля ударов: в створ / заблокирован. Остаток — мимо. */
export const SHOT_ON_TARGET = 0.34;
export const SHOT_BLOCKED = 0.21;
/** Вероятность углового после сейва/блока. */
export const CORNER_AFTER_SAVE = 0.5;
export const CORNER_AFTER_BLOCK = 0.5;

// ── Фолы и карточки ──────────────────────────────────────────────────────
/** Шанс фола при проигранном подкате/опеке. */
export const FOUL_ON_LOSS = 0.28;
/** Агрессия 50 → +0.0; каждый пункт агрессии добавляет slope. */
export const FOUL_AGGR_SLOPE = 0.0028;
/** Прессинг high — больше фолов. */
export const FOUL_PRESSING_HIGH = 0.05;
/** Шанс жёлтой при фоле. */
export const YELLOW_ON_FOUL = 0.5;
export const YELLOW_AGGR_SLOPE = 0.0022;
/** Прямая красная при грубом фоле. */
export const STRAIGHT_RED_ON_FOUL = 0.005;
/** Фол в своей штрафной → пенальти. */
export const PEN_ON_BOX_FOUL = 0.5;
/** Фол-сдерживание при перехваченном пасе (реальный фол, свободный удар). */
export const PASS_FOUL_CHANCE = 0.22;
/** Жёлтая при фоле-сдерживании. */
export const PASS_FOUL_YELLOW = 0.24;
/** Травма на дуэли: база × (injuryProneness/50). */
export const INJURY_ON_DUEL = 0.003;
/** Травма без контакта (усталостная) за минуту. */
export const INJURY_PER_MIN = 0.00008;

// ── Офсайды ──────────────────────────────────────────────────────────────
/** Шанс офсайда на вертикальном пасе против линии защиты. */
export const OFFSIDE_BY_DEFLINE: Record<string, number> = { low: 0.09, medium: 0.14, high: 0.2 };
/** Решения нападающего снижают шанс офсайда. */
export const OFFSIDE_DECISIONS_SLOPE = 0.0025;

// ── Замены ───────────────────────────────────────────────────────────────
/** Порог энергии для авто-замены по усталости (от 58-й минуты). */
export const SUB_ENERGY_THRESHOLD = 58;
export const SUB_FIRST_WINDOW = 58;
/** Минимальный интервал между усталостными заменами команды. */
export const SUB_COOLDOWN = 5;
/** Энергия свежего игрока, вошедшего на замену. */
export const SUB_IN_ENERGY = 93;

// ── Владение и моментум ──────────────────────────────────────────────────
/** Окно сглаживания владения (действий). */
export const MOMENTUM_WINDOW = 24;
/** Порог доминирования для события momentum. */
export const MOMENTUM_DOMINANCE = 0.7;
export const MOMENTUM_COOLDOWN = 12;
/** Минут тишины до «фонового» события-заполнителя. */
export const FILLER_AFTER_QUIET = 7;
export const FILLER_CHANCE = 0.5;
export const FILLER_MAX = 7;

// ── Дистрибуция вратаря ──────────────────────────────────────────────────
/** Доля длинных вводов у стиля long (остальные стили меньше). */
export const GK_LONG_STYLE_BONUS: Record<string, number> = {
  long: 0.42,
  counter: 0.22,
  passing: -0.18,
  balanced: 0,
  wing: -0.05,
  vertical: 0.1,
} as const;

/** Зажим вероятности дуэли: даже фаворит ошибается, аутсайдер находит шанс. */
export const DUEL_P_MIN = 0.08;
export const DUEL_P_MAX = 0.88;

/**
 * QA Фаза 3 (Task P3-5) — целевые репро-проверки для scripts/qa3_targeted.sh.
 * Запуск: bun scripts/qa3_repro.ts <команда> <saveId> [аргументы]
 * Пишет ТОЛЬКО в собственные тест-сейвы P3-QA3… (команды подготовки сценариев).
 */
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient({ log: [] });

/** Состав клуба игрока: id age ovr contractUntil preContract value. */
async function squad(saveId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true, season: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  const rows = await db.player.findMany({
    where: { saveId, teamId: save.teamId },
    select: { id: true, age: true, ovr: true, contractUntil: true, preContractTeamId: true, value: true },
    orderBy: { ovr: 'desc' },
  });
  console.log(`season=${save.season}`);
  console.log(`squad_size=${rows.length}`);
  for (const p of rows) {
    console.log(`p ${p.id} ${p.age} ${p.ovr} cu=${p.contractUntil} pre=${p.preContractTeamId ? 1 : 0} v=${p.value}`);
  }
}

/** Принудительно истечь: contractUntil = текущий сезон. */
async function forceexpire(saveId: string, playerId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { season: true } });
  if (!save) { console.log('save=missing'); return; }
  await db.player.update({ where: { id: playerId }, data: { contractUntil: save.season } });
  console.log(`forced=${playerId} cu=${save.season}`);
}

/** Принудительно состарить игрока (для сценария пенсии истекающего). */
async function ageup(saveId: string, playerId: string, ageStr: string) {
  await db.player.update({ where: { id: playerId }, data: { age: Number(ageStr) } });
  console.log(`aged=${playerId} age=${ageStr}`);
}

/** Состояние игрока после перехода: teamId/age/contractUntil + все его лоты. */
async function playerstate(saveId: string, playerId: string) {
  const p = await db.player.findFirst({
    where: { id: playerId, saveId },
    select: { id: true, teamId: true, age: true, contractUntil: true, ovr: true, value: true },
  });
  if (!p) { console.log('player=deleted'); return; }
  console.log(`player=exists team=${p.teamId ?? 'null'} age=${p.age} cu=${p.contractUntil} ovr=${p.ovr} v=${p.value}`);
  const listings = await db.transferListing.findMany({
    where: { playerId }, select: { source: true, status: true, price: true, expiresAt: true },
  });
  console.log(`listings=${listings.length}`);
  for (const l of listings) console.log(`l ${l.source} ${l.status} price=${l.price} ttl=${l.expiresAt}`);
}

/** Состав клуба игрока + валидность сохранённого состава (stale-слоты). */
async function squadcheck(saveId: string) {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, select: { teamId: true } });
  if (!save?.teamId) { console.log('save=missing'); return; }
  const team = await db.team.findUnique({ where: { id: save.teamId }, select: { lineup: true, bench: true } });
  if (!team) { console.log('save=missing'); return; }
  const ids = await db.player.findMany({ where: { saveId, teamId: save.teamId }, select: { id: true } });
  const idSet = new Set(ids.map((p) => p.id));
  const lineup = (JSON.parse(team.lineup ?? '[]') as (string | null)[]).filter((x): x is string => !!x);
  const bench = (JSON.parse(team.bench ?? '[]') as (string | null)[]).filter((x): x is string => !!x);
  const stale = [...lineup, ...bench].filter((id) => !idSet.has(id)).length;
  console.log(`squad_size=${ids.length}`);
  console.log(`lineup_size=${lineup.length}`);
  console.log(`stale_lineup_refs=${stale}`);
}

const [cmd, saveId, ...rest] = process.argv.slice(2);
if (!cmd || !saveId) {
  console.error('usage: qa3_repro.ts <squad|forceexpire|ageup|playerstate|squadcheck> <saveId> [args]');
  process.exit(1);
}
switch (cmd) {
  case 'squad': await squad(saveId); break;
  case 'forceexpire': await forceexpire(saveId, rest[0] ?? ''); break;
  case 'ageup': await ageup(saveId, rest[0] ?? '', rest[1] ?? '36'); break;
  case 'playerstate': await playerstate(saveId, rest[0] ?? ''); break;
  case 'squadcheck': await squadcheck(saveId); break;
  default: console.error(`unknown cmd ${cmd}`); process.exit(1);
}
await db.$disconnect();

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolveSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { starsOf } from '@/lib/game/academy';
import { yearsLeftOf } from '@/lib/game/contracts';
import { ApiGameError } from '@/lib/game/error';
import type { AcademyPlayerDTO, AcademyResponse, Position } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/academy?saveId= — воспитанники академии клуба игрока
 * (Фаза 3, §6.1), сортировка по потенциалу. Отчёты о наборах — новости
 * недели 4 (тип 'academy'); экран показывает воспитанников постоянно.
 */
export async function GET(request: Request) {
  try {
    const save = await resolveSave(saveIdFromQuery(request));
    if (!save.teamId) return fail('SAVE_NOT_FOUND', 404);

    const rows = await db.player.findMany({
      where: { saveId: save.id, teamId: save.teamId, isAcademy: true },
      orderBy: [{ potential: 'desc' }, { ovr: 'desc' }],
    });

    const graduates: AcademyPlayerDTO[] = rows.map((p) => ({
      id: p.id,
      name: `${p.firstName} ${p.lastName}`,
      position: p.position as Position,
      age: p.age,
      ovr: p.ovr,
      potential: p.potential,
      stars: starsOf(p.potential),
      contractUntil: p.contractUntil,
      yearsLeft: yearsLeftOf(p.contractUntil, save.season),
      value: p.value,
      salary: p.salary,
    }));

    const response: AcademyResponse = { ok: true, graduates };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/academy]', error);
    return fail('UNKNOWN', 500);
  }
}

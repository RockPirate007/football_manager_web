import { NextResponse } from 'next/server';
import { z } from 'zod';
import { normalizeErrorCode, resolvePlayingSave } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { simulateWeek } from '@/lib/game/week';

const bodySchema = z.object({
  saveId: z.string().min(1),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * POST /api/game/simulate — симуляция недели (лига ИЛИ кубок).
 * Body: { saveId }. Без body (легаси-клиент Фазы 1) — последний открытый
 * активный сейв; тело с невалидным saveId → 400 INVALID_PAYLOAD.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    let saveId: string | null = null;
    if (json !== null && typeof json === 'object') {
      const parsed = bodySchema.safeParse(json);
      if (!parsed.success) return fail('INVALID_PAYLOAD', 400);
      saveId = parsed.data.saveId;
    }

    const save = await resolvePlayingSave(saveId);
    const result = await simulateWeek(save.id);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/simulate]', error);
    return fail('UNKNOWN', 500);
  }
}

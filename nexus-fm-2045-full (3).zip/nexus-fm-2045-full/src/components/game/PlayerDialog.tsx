'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  ArrowDown, ArrowUp, Award, Bandage, Eye, EyeOff, FileSignature, Handshake, Loader2,
  ShoppingBag, Sparkles, TrendingUp,
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AttributeBar } from '@/components/game/shared/AttributeBar';
import { AttrRadarChart } from '@/components/game/shared/AttrRadarChart';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { PositionBadge } from '@/components/game/shared/PositionBadge';
import {
  CONTRACT_ACCEPT_RATIO, CONTRACT_OFFER_MAX_RATIO, CONTRACT_OFFER_MIN_RATIO,
  CONTRACT_RENEWABLE_YEARS_LEFT, CONTRACT_ROUNDS_MAX, FORMATIONS, SALARY_ROUND,
} from '@/lib/game/constants';
import { formatMoney, formatMoneyExact } from '@/lib/game/format';
import { potentialLabelOf } from '@/lib/game/development';
import { effectiveLineup } from '@/lib/game/lineup';
import { slotScore } from '@/lib/game/players';
import { maxRenewYears, yearsLeftOf } from '@/lib/game/contracts';
import { ATTR_LABELS } from '@/lib/game/types';
import type { AttrKey, NegotiationDTO, PlayerDTO, TacticPayload } from '@/lib/game/types';
import { sellOfferProbability, sellPriceBounds } from '@/lib/game/transfers';
import { signingDemandOf } from '@/lib/game/negotiation';
import { KNOWLEDGE_PARTIAL, KNOWLEDGE_TIER_LABELS, knowledgeTierOf } from '@/lib/game/scouting';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const FIELD_ATTRS: AttrKey[] = [
  'finishing', 'passing', 'dribbling', 'crossing', 'tackling', 'marking',
  'positioning', 'heading', 'pace', 'stamina', 'strength', 'aggression',
];
const GK_ATTRS: AttrKey[] = ['reflexes', 'rushingOut', 'kicking'];

function moraleTone(morale: number): { label: string; className: string } {
  if (morale >= 70) return { label: `↑ ${morale}`, className: 'text-[#22C55E]' };
  if (morale >= 40) return { label: `— ${morale}`, className: 'text-muted-foreground' };
  return { label: `↓ ${morale}`, className: 'text-[#EF4444]' };
}

/** «1 год / 2 года / 5 лет». */
function pluralYears(n: number): string {
  if (n === 1) return '1 год';
  if (n >= 2 && n <= 4) return `${n} года`;
  return `${n} лет`;
}

/** Цвет среднего рейтинга: ≥7.2 — зелёный, ≥6.8 — обычный, ниже — приглушённый. */
function avgRatingClass(rating: number): string {
  if (rating >= 7.2) return 'text-[#22C55E]';
  if (rating >= 6.8) return 'text-foreground';
  return 'text-muted-foreground';
}

/** Границы слайдера зарплаты: 80–130% спроса с округлением к SALARY_ROUND (как в API). */
function salaryBounds(demand: number): { min: number; max: number } {
  return {
    min: Math.floor((CONTRACT_OFFER_MIN_RATIO * demand) / SALARY_ROUND) * SALARY_ROUND,
    max: Math.ceil((CONTRACT_OFFER_MAX_RATIO * demand) / SALARY_ROUND) * SALARY_ROUND,
  };
}

// ── История игрока (Фаза 3, §7.3) ─────────────────────────────────────────

/** Вкладка «История»: сезоны, карьерные итоги, награды. Грузится лениво при первом открытии. */
function HistoryTab({ playerId }: { playerId: string }) {
  const dialog = useGameStore((s) => s.playerDialogCache.get(playerId) ?? null);
  const loadingId = useGameStore((s) => s.playerDialogLoadingId);
  const fetchPlayerDialog = useGameStore((s) => s.fetchPlayerDialog);

  useEffect(() => {
    void fetchPlayerDialog(playerId);
  }, [playerId, fetchPlayerDialog]);

  if (!dialog && loadingId === playerId) {
    return (
      <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Загружаем историю игрока…
      </div>
    );
  }

  if (!dialog) {
    return (
      <p className="py-8 text-center text-xs text-muted-foreground">
        История недоступна — попробуйте открыть диалог ещё раз.
      </p>
    );
  }

  const { history, totals, awards } = dialog;

  if (history.length === 0 && awards.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 px-4 py-8 text-center">
        <Sparkles className="size-6 text-muted-foreground" aria-hidden />
        <p className="text-sm font-semibold">Первый сезон в лиге</p>
        <p className="max-w-xs text-xs text-muted-foreground">
          История появится после завершения сезона: матчи, голы, ассисты и средний рейтинг
          по каждому году карьеры.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Таблица сезонов */}
      <div className="scroll-thin overflow-x-auto rounded-lg border border-border/60 bg-secondary/20">
        <Table className="min-w-[560px]">
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="h-9 text-center text-[11px]">Сезон</TableHead>
              <TableHead className="h-9 text-[11px]">Клуб</TableHead>
              <TableHead className="h-9 w-14 text-center text-[11px]">Возраст</TableHead>
              <TableHead className="h-9 w-14 text-center text-[11px]">Матчи</TableHead>
              <TableHead className="h-9 w-12 text-center text-[11px]" title="Лига (кубок / Кубок Европы)">Голы</TableHead>
              <TableHead className="h-9 w-14 text-center text-[11px]" title="Лига (кубок / Кубок Европы)">Ассисты</TableHead>
              <TableHead className="h-9 w-14 text-center text-[11px]">Рейтинг</TableHead>
              <TableHead className="h-9 w-14 text-center text-[11px]">Ж/К</TableHead>
              <TableHead className="h-9 w-12 text-center text-[11px]">Сухие</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="zebra">
            {history.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="py-6 text-center text-xs text-muted-foreground">
                  Сезоны ещё не завершены
                </TableCell>
              </TableRow>
            ) : (
              history.map((h) => (
                <TableRow key={`${h.season}-${h.teamName}`} className="border-border/40">
                  <TableCell className="py-2 text-center text-xs font-semibold tabular">
                    {h.season}
                  </TableCell>
                  <TableCell className="max-w-40 truncate py-2 text-xs">
                    <span title={h.teamName}>{h.teamName}</span>
                  </TableCell>
                  <TableCell className="py-2 text-center text-xs tabular text-muted-foreground">
                    {h.age}
                  </TableCell>
                  <TableCell className="py-2 text-center text-xs tabular font-semibold">
                    {h.apps}
                  </TableCell>
                  <TableCell className="py-2 text-center text-xs tabular">
                    {h.goals}
                    {h.cupGoals > 0 || h.euroGoals > 0 ? (
                      <span
                        className="text-muted-foreground"
                        title={`Голы: кубок — ${h.cupGoals}, Кубок Европы — ${h.euroGoals}`}
                      >
                        {' '}({h.cupGoals}/{h.euroGoals})
                      </span>
                    ) : null}
                  </TableCell>
                  <TableCell className="py-2 text-center text-xs tabular">
                    {h.assists}
                    {h.cupAssists > 0 || h.euroAssists > 0 ? (
                      <span
                        className="text-muted-foreground"
                        title={`Ассисты: кубок — ${h.cupAssists}, Кубок Европы — ${h.euroAssists}`}
                      >
                        {' '}({h.cupAssists}/{h.euroAssists})
                      </span>
                    ) : null}
                  </TableCell>
                  <TableCell
                    className={cn(
                      'py-2 text-center text-xs tabular font-semibold',
                      h.avgRating === null ? 'text-muted-foreground/60' : avgRatingClass(h.avgRating),
                    )}
                    title={h.avgRating === null ? 'Не играл в этом сезоне' : 'Средний рейтинг сезона'}
                  >
                    {h.avgRating === null ? '—' : h.avgRating.toFixed(1)}
                  </TableCell>
                  <TableCell className="py-2 text-center text-xs tabular text-muted-foreground">
                    {h.yellowCards > 0 || h.redCards > 0
                      ? `${h.yellowCards}/${h.redCards}`
                      : '—'}
                  </TableCell>
                  <TableCell className="py-2 text-center text-xs tabular text-muted-foreground">
                    {h.cleanSheets > 0 ? h.cleanSheets : '—'}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Карьерные итоги */}
      <div className="rounded-lg border border-border/60 bg-secondary/30 p-3">
        <p className="mb-2 text-xs font-semibold text-muted-foreground">Итоги карьеры</p>
        <p className="text-xs leading-relaxed">
          <span className="font-semibold tabular">{totals.seasons}</span>{' '}
          {totals.seasons === 1 ? 'сезон' : totals.seasons < 5 ? 'сезона' : 'сезонов'} ·{' '}
          <span className="font-semibold tabular">{totals.apps}</span> матчей ·{' '}
          <span className="font-semibold tabular">{totals.goals}</span>{' '}
          {totals.goals === 1 ? 'гол' : totals.goals < 5 ? 'гола' : 'голов'} ·{' '}
          <span className="font-semibold tabular">{totals.assists}</span>{' '}
          {totals.assists === 1 ? 'ассист' : totals.assists < 5 ? 'ассиста' : 'ассистов'} ·
          средний рейтинг{' '}
          <span className={cn('font-semibold tabular', totals.avgRating !== null && avgRatingClass(totals.avgRating))}>
            {totals.avgRating === null ? '—' : totals.avgRating.toFixed(2)}
          </span>
        </p>
      </div>

      {/* Награды игрока */}
      {awards.length > 0 ? (
        <div className="space-y-2">
          <p className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
            <Award className="size-3.5 text-[#EAB308]" aria-hidden />
            Награды игрока
          </p>
          <ul className="space-y-1.5">
            {awards.map((a) => (
              <li
                key={a.id}
                className="flex items-center gap-2 rounded-lg border border-[#EAB308]/25 bg-[#EAB308]/5 p-2"
              >
                <Award className="size-4 shrink-0 text-[#EAB308]" aria-hidden />
                <span className="min-w-0 flex-1 truncate text-xs font-semibold">
                  {a.typeName}
                </span>
                <span className="shrink-0 text-[10px] text-muted-foreground">
                  сезон <span className="tabular">{a.season}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="text-[11px] text-muted-foreground">
        Хороший сезон — рейтинг 7.2+. Кубковые голы и ассисты показаны с плюсом рядом с лиговыми.
      </p>
    </div>
  );
}

// ── Переговоры о продлении (Фаза 3, §7.1) ─────────────────────────────────

/** Переговорная секция: ожидания игрока, срок, зарплата, раунды 1..3. */
function RenewSection({
  player,
  onClose,
  onAccepted,
}: {
  player: PlayerDTO;
  onClose: () => void;
  onAccepted: () => void;
}) {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const contractsCache = useGameStore((s) => s.contractsCache);
  const contractsLoading = useGameStore((s) => s.contractsLoading);
  const fetchContracts = useGameStore((s) => s.fetchContracts);
  const renewContract = useGameStore((s) => s.renewContract);
  const loading = useGameStore((s) => s.loading);

  const [yearsOverride, setYearsOverride] = useState<number | null>(null);
  const [salaryOverride, setSalaryOverride] = useState<number | null>(null);
  const [rounds, setRounds] = useState(0);
  const [counterDemand, setCounterDemand] = useState<number | null>(null);

  useEffect(() => {
    if (!contractsCache) void fetchContracts();
  }, [contractsCache, fetchContracts]);

  const info = useMemo(
    () =>
      contractsCache?.contracts.find((c) => c.playerId === player.id) ??
      snapshot.contractsExpiring.find((c) => c.playerId === player.id) ??
      null,
    [contractsCache, snapshot.contractsExpiring, player.id],
  );

  const demand = info?.demand ?? null;
  const maxYears = info?.maxRenewYears ?? maxRenewYears(player.age);

  if (contractsLoading && !contractsCache && !info) {
    return (
      <div className="flex items-center justify-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-6 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Запрашиваем ожидания игрока…
      </div>
    );
  }

  // Список ещё не загружен (и в снапшоте игрока нет среди истекающих) — держим загрузку,
  // чтобы не мигать заглушкой до прихода кеша.
  if (!info && !contractsCache) {
    return (
      <div className="flex items-center justify-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-6 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Готовим данные контракта…
      </div>
    );
  }

  if (demand === null) {
    return (
      <div className="space-y-3 rounded-lg border border-border/60 bg-secondary/30 p-3">
        <p className="text-xs leading-relaxed text-muted-foreground">
          Контракт этого игрока пока нельзя продлить: возможно, он уже подписал предконтракт
          с другим клубом или срок контракта больше двух лет.
        </p>
        <Button variant="outline" className="min-h-11 w-full" onClick={onClose}>
          Понятно
        </Button>
      </div>
    );
  }

  // Дефолты выводим прямо в рендере (без эффекта): 3 года (или максимум для ветерана 30+),
  // зарплата = спрос, округлённый к SALARY_ROUND и зажатый в границы 80–130%.
  const bounds = salaryBounds(demand);
  const defaultYears = Math.max(1, Math.min(3, maxYears));
  const years = Math.min(yearsOverride ?? defaultYears, maxYears);
  const defaultSalary = Math.round(demand / SALARY_ROUND) * SALARY_ROUND;
  const clampedSalary = Math.min(
    Math.max(salaryOverride ?? defaultSalary, bounds.min),
    bounds.max,
  );
  const roundsLeft = CONTRACT_ROUNDS_MAX - rounds;
  const negotiationsOver = roundsLeft <= 0;
  const acceptThreshold = CONTRACT_ACCEPT_RATIO * demand;
  const chance =
    clampedSalary >= acceptThreshold ? 'высокий'
      : clampedSalary >= demand * 0.9 ? 'средний'
        : 'низкий';

  const handleOffer = async () => {
    const res = await renewContract(player.id, years, clampedSalary);
    if (!res) return;
    if (res.outcome === 'accepted') {
      onAccepted();
      return;
    }
    setCounterDemand(res.demand);
    setRounds((r) => r + 1);
  };

  return (
    <div className="space-y-3 rounded-lg border border-border/60 bg-secondary/30 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-xs font-semibold">
          <Handshake className="size-4 text-primary" aria-hidden />
          Продление контракта
        </p>
        <Badge variant="outline" className="tabular text-[10px]">
          Раунд {Math.min(rounds + 1, CONTRACT_ROUNDS_MAX)}/{CONTRACT_ROUNDS_MAX}
        </Badge>
      </div>

      {/* Ожидания игрока */}
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Игрок хочет</span>
        <span className="tabular font-bold text-[#EAB308]">
          ~{formatMoneyExact(demand)}/нед
        </span>
      </div>

      {/* Контрпредложение */}
      {counterDemand !== null ? (
        <p className="rounded border border-[#EAB308]/40 bg-[#EAB308]/10 px-2.5 py-2 text-[11px] leading-relaxed text-[#EAB308]">
          Игрок настаивает на ~{formatMoneyExact(counterDemand)}/нед — предложите больше
          или вернитесь к переговорам позже.
        </p>
      ) : null}

      {/* Срок */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Срок продления</span>
          <span className="tabular font-semibold">
            до сезона {snapshot.save.season + years} ({pluralYears(years)})
          </span>
        </div>
        <div className="flex gap-1.5">
          {Array.from({ length: maxYears }, (_, i) => i + 1).map((y) => (
            <Button
              key={y}
              type="button"
              variant={y === years ? 'default' : 'outline'}
              size="sm"
              className="min-h-10 flex-1 tabular"
              onClick={() => {
                setYearsOverride(y);
              }}
              aria-pressed={y === years}
            >
              {y} {y === 1 ? 'год' : 'года'}
            </Button>
          ))}
        </div>
      </div>

      {/* Зарплата */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Зарплата в неделю</span>
          <span className="tabular font-bold text-foreground">
            {formatMoneyExact(clampedSalary)}
          </span>
        </div>
        <Slider
          value={[clampedSalary]}
          min={bounds.min}
          max={bounds.max}
          step={SALARY_ROUND}
          onValueChange={(v) => {
            setSalaryOverride(v[0] ?? bounds.min);
          }}
          aria-label="Предлагаемая зарплата в неделю"
        />
        <div className="flex items-center justify-between text-[10px] text-muted-foreground tabular">
          <span>−20% {formatMoney(bounds.min)}</span>
          <span>{Math.round((clampedSalary / demand) * 100)}% от запроса</span>
          <span>+30% {formatMoney(bounds.max)}</span>
        </div>
        <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <TrendingUp
            className={cn(
              'size-3.5',
              chance === 'высокий' ? 'text-[#22C55E]' : chance === 'средний' ? 'text-[#FACC15]' : 'text-[#EF4444]',
            )}
            aria-hidden
          />
          {chance === 'высокий'
            ? 'высокие шансы на согласие'
            : chance === 'средний'
              ? 'игрок может запросить больше'
              : 'низкие шансы — игрок откажется'}
        </p>
      </div>

      {negotiationsOver ? (
        <p className="rounded border border-[#EF4444]/40 bg-[#EF4444]/10 px-2.5 py-2 text-[11px] leading-relaxed text-[#EF4444]">
          Переговоры прерваны: игрок больше не готов обсуждать продление. Вернитесь
          к диалогу через несколько недель.
        </p>
      ) : null}

      <div className="flex gap-2">
        <Button variant="outline" className="min-h-11 flex-1" onClick={onClose}>
          Отмена
        </Button>
        <Button
          className="min-h-11 flex-1"
          onClick={() => void handleOffer()}
          disabled={loading || negotiationsOver}
          title={
            negotiationsOver
              ? 'Переговоры прерваны после трёх раундов'
              : 'Отправить предложение игроку'
          }
        >
          {loading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
          Предложить
        </Button>
      </div>
    </div>
  );
}

// ── Модуль 3: переговоры о подписании с рынка ──────────────────────────────

/** Зарплатный спрос-прикидка по видимым (туманным) данным игрока. */
function signingEstimateOf(player: PlayerDTO, myPlayers: PlayerDTO[]): { salary: number; years: number; goalBonus: number; cleanSheetBonus: number } {
  const top11 = [...myPlayers].sort((a, b) => b.ovr - a.ovr).slice(0, 11);
  const avg = top11.length > 0 ? top11.reduce((s, p) => s + p.ovr, 0) / top11.length : 50;
  const demand = signingDemandOf({ player: player as never, buyerTop11Avg: avg });
  return demand;
}

/**
 * Переговорная секция при покупке с рынка (Модуль 3): предложение контракта
 * (зарплата/срок/бонусы) → решение агента (принято / контр / отказ).
 * Спрос-прикидка тем точнее, чем выше знание скаутов о игроке.
 */
function SigningSection({
  player,
  price,
  onBought,
}: {
  player: PlayerDTO;
  price: number;
  onBought: () => void;
}) {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const loading = useGameStore((s) => s.loading);
  const buyPlayerNegotiated = useGameStore((s) => s.buyPlayerNegotiated);

  const demand = useMemo(
    () => signingEstimateOf(player, snapshot.myPlayers),
    [player, snapshot.myPlayers],
  );
  const know = player.scoutKnowledge;
  const knowLow = know < 40; // спрос скрыт — можно «стрелять наугад»

  const isGk = player.position === 'GK';
  const isDefender = isGk || ['DL', 'DC', 'DR', 'DML', 'DMC', 'DMR'].includes(player.position);
  const isAttacker = ['AM', 'ST'].includes(player.position) || player.position.startsWith('AM');

  const [salaryOv, setSalaryOv] = useState<number | null>(null);
  const [yearsOv, setYearsOv] = useState<number | null>(null);
  const [goalBonusOv, setGoalBonusOv] = useState<number | null>(null);
  const [csBonusOv, setCsBonusOv] = useState<number | null>(null);
  const [negotiation, setNegotiation] = useState<NegotiationDTO | null>(null);

  const bounds = salaryBounds(demand.salary);
  const salary = Math.min(Math.max(salaryOv ?? demand.salary, bounds.min), bounds.max);
  const years = Math.min(Math.max(yearsOv ?? demand.years, 1), 4);
  const goalBonus = Math.max(0, goalBonusOv ?? demand.goalBonus);
  const cleanSheetBonus = Math.max(0, csBonusOv ?? demand.cleanSheetBonus);

  const agentDemand = negotiation?.kind === 'counter' ? negotiation.demand : null;
  const rejected = negotiation?.kind === 'rejected' ? negotiation : null;

  const handleOffer = async (override?: { salary: number; years: number; goalBonus: number; cleanSheetBonus: number }) => {
    const offer = override ?? { salary, years, goalBonus, cleanSheetBonus };
    const res = await buyPlayerNegotiated(player.id, offer);
    if (!res) return;
    if (res.kind === 'accepted') {
      onBought();
      return;
    }
    setNegotiation(res);
    if (res.kind === 'counter' && res.demand) {
      // подставляем требования агента — решение за игроком (согласиться/торговаться)
      setSalaryOv(res.demand.salary);
      setYearsOv(res.demand.years);
      setGoalBonusOv(res.demand.goalBonus);
      setCsBonusOv(res.demand.cleanSheetBonus);
    }
  };

  return (
    <div className="space-y-3 rounded-lg border border-border/60 bg-secondary/30 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-xs font-semibold">
          <Handshake className="size-4 text-primary" aria-hidden />
          Подписание контракта
        </p>
        <span className="tabular text-[10px] text-muted-foreground">
          трансфер €{formatMoney(price)}
        </span>
      </div>

      {/* Спрос агента */}
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Агент намекает на</span>
        {knowLow ? (
          <span className="font-semibold text-muted-foreground">
            ? — игрок не проскаутлен
          </span>
        ) : (
          <span className="tabular font-bold text-[#EAB308]">
            ~{formatMoneyExact(demand.salary)}/нед
          </span>
        )}
      </div>

      {/* Контрпредложение */}
      {agentDemand !== null ? (
        <div className="space-y-2 rounded border border-[#EAB308]/40 bg-[#EAB308]/10 px-2.5 py-2">
          <p className="text-[11px] leading-relaxed text-[#EAB308]">
            {negotiation?.message}
          </p>
          <Button
            size="sm"
            className="min-h-9 w-full"
            disabled={loading}
            onClick={() => void handleOffer(agentDemand)}
          >
            Принять условия агента
          </Button>
        </div>
      ) : null}

      {/* Отказ */}
      {rejected !== null ? (
        <p className="rounded border border-[#EF4444]/40 bg-[#EF4444]/10 px-2.5 py-2 text-[11px] leading-relaxed text-[#EF4444]">
          {rejected.message} Условия можно изменить и предложить снова.
        </p>
      ) : null}

      {/* Срок */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Срок контракта</span>
          <span className="tabular font-semibold">
            до сезона {snapshot.save.season + years} ({pluralYearsLocal(years)})
          </span>
        </div>
        <div className="flex gap-1.5">
          {[1, 2, 3, 4].map((y) => (
            <Button
              key={y}
              type="button"
              variant={y === years ? 'default' : 'outline'}
              size="sm"
              className="min-h-10 flex-1 tabular"
              onClick={() => setYearsOv(y)}
              aria-pressed={y === years}
            >
              {y} {y === 1 ? 'год' : 'года'}
            </Button>
          ))}
        </div>
      </div>

      {/* Зарплата */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Зарплата в неделю</span>
          <span className="tabular font-bold text-foreground">{formatMoneyExact(salary)}</span>
        </div>
        <Slider
          value={[salary]}
          min={bounds.min}
          max={bounds.max}
          step={SALARY_ROUND}
          onValueChange={(v) => setSalaryOv(v[0] ?? bounds.min)}
          aria-label="Предлагаемая зарплата в неделю"
        />
        <div className="flex items-center justify-between text-[10px] text-muted-foreground tabular">
          <span>{formatMoney(bounds.min)}</span>
          <span>{Math.round((salary / demand.salary) * 100)}% от прикидки</span>
          <span>{formatMoney(bounds.max)}</span>
        </div>
      </div>

      {/* Бонусы */}
      <div className="space-y-1.5">
        <p className="text-[11px] font-semibold text-muted-foreground">Бонусы контракта</p>
        {isAttacker || !isDefender ? (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">За гол</span>
              <span className="tabular font-semibold">€{goalBonus.toLocaleString('ru-RU')}</span>
            </div>
            <Slider
              value={[goalBonus]}
              min={0}
              max={Math.max(1000, demand.goalBonus * 3)}
              step={100}
              onValueChange={(v) => setGoalBonusOv(v[0] ?? 0)}
              aria-label="Бонус за гол"
            />
          </div>
        ) : null}
        {isDefender ? (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">За сухой матч</span>
              <span className="tabular font-semibold">€{cleanSheetBonus.toLocaleString('ru-RU')}</span>
            </div>
            <Slider
              value={[cleanSheetBonus]}
              min={0}
              max={Math.max(1000, demand.cleanSheetBonus * 3)}
              step={100}
              onValueChange={(v) => setCsBonusOv(v[0] ?? 0)}
              aria-label="Бонус за сухой матч"
            />
          </div>
        ) : null}
      </div>

      <Button
        className="min-h-11 w-full"
        onClick={() => void handleOffer()}
        disabled={loading || price > snapshot.save.transferBudget}
        title={price > snapshot.save.transferBudget ? 'Не хватает трансферного бюджета' : undefined}
      >
        {loading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <ShoppingBag className="size-4" aria-hidden />}
        Предложить контракт и купить
      </Button>
    </div>
  );
}

function pluralYearsLocal(n: number): string {
  return n === 1 ? 'год' : n >= 2 && n <= 4 ? 'года' : 'лет';
}

/** Карточка игрока: атрибуты, экономика, статистика, история, действия. */
export function PlayerDialog({
  player,
  open,
  onOpenChange,
  mode,
  price,
  onBought,
  defaultSellMode = false,
}: {
  player: PlayerDTO | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'squad' | 'market';
  price?: number;
  onBought?: () => void;
  defaultSellMode?: boolean;
}) {
  const snapshot = useGameStore((s) => s.snapshot);
  const saveTactics = useGameStore((s) => s.saveTactics);
  const listPlayer = useGameStore((s) => s.listPlayer);
  const loading = useGameStore((s) => s.loading);
  // Модуль 3: скаутинг — слежение за чужими игроками
  const scoutCache = useGameStore((s) => s.scoutCache);
  const scoutWatch = useGameStore((s) => s.scoutWatch);
  const scoutUnwatch = useGameStore((s) => s.scoutUnwatch);

  const [sellMode, setSellMode] = useState(defaultSellMode && player?.askingPrice === null);
  const [sellPrice, setSellPrice] = useState(player ? sellPriceBounds(player.value).min : 0);
  const [renewMode, setRenewMode] = useState(false);
  const [tab, setTab] = useState<'overview' | 'history'>('overview');

  // Туман войны (Модуль 3): в market-режиме знания могут быть < 40
  const knowledge = mode === 'market' ? (player?.scoutKnowledge ?? 0) : 100;
  const attrsUnknown = knowledge < KNOWLEDGE_PARTIAL;
  const watched = mode === 'market'
    ? (scoutCache?.reports.find((r) => r.playerId === player?.id)?.watched ?? false)
    : false;

  const handleWatchToggle = () => {
    if (!player) return;
    if (watched) void scoutUnwatch(player.id);
    else void scoutWatch(player.id);
  };

  const handleOpenChange = (o: boolean) => {
    if (!o) {
      setSellMode(false);
      setRenewMode(false);
      setTab('overview');
    }
    onOpenChange(o);
  };

  const inLineup = useMemo(() => {
    if (!player || !snapshot) return false;
    return effectiveLineup(snapshot.myTeam, snapshot.myPlayers).lineup.includes(player.id);
  }, [player, snapshot]);

  if (!player || !snapshot) return null;

  const isGk = player.position === 'GK';
  const attrs: AttrKey[] = isGk ? [...GK_ATTRS, ...FIELD_ATTRS] : [...FIELD_ATTRS, ...GK_ATTRS];
  const morale = moraleTone(player.morale);
  const bounds = sellPriceBounds(player.value);
  const sellChance = Math.round(sellOfferProbability(sellPrice, player.value) * 100);

  // Контракт (Фаза 3): абсолютная шкала сезонов, текущий сезон входит в срок.
  const season = snapshot.save.season;
  const yearsLeft = yearsLeftOf(player.contractUntil, season);
  const renewable =
    mode === 'squad' &&
    yearsLeft <= CONTRACT_RENEWABLE_YEARS_LEFT &&
    !player.preContract &&
    snapshot.save.status === 'active';

  /** Переключить «в старт» / «в запас» и сохранить тактику. */
  const toggleStarter = async () => {
    if (!player) return;
    const { myTeam, myPlayers } = snapshot;
    const eff = effectiveLineup(myTeam, myPlayers);
    const lineup = [...eff.lineup];
    let bench = [...eff.bench];
    const byId = new Map(myPlayers.map((p) => [p.id, p]));
    const slots = FORMATIONS[myTeam.formation].slots;
    const idx = lineup.indexOf(player.id);

    if (idx >= 0) {
      // В запас: заменить лучшим кандидатом со скамейки/из резерва
      const slotPos = slots[idx].position;
      const reserve = myPlayers
        .filter((p) => p.id !== player.id && p.injuryWeeks === 0 && !lineup.includes(p.id))
        .sort((a, b) => slotScore(b, slotPos) - slotScore(a, slotPos));
      const replacement = reserve.find((p) => bench.includes(p.id)) ?? reserve[0];
      if (!replacement) {
        toast.error('Некем заменить игрока — в составе нет свободных игроков');
        return;
      }
      lineup[idx] = replacement.id;
      bench = [player.id, ...bench.filter((id) => id !== replacement.id)].slice(0, 7);
    } else {
      // В старт: лучший слот для игрока, заменяем текущего обитателя
      let bestSlot = 0;
      let bestScore = -1;
      slots.forEach((slot, i) => {
        const score = slotScore(player, slot.position);
        if (score > bestScore) {
          bestScore = score;
          bestSlot = i;
        }
      });
      const occupantId = lineup[bestSlot];
      const occupant = occupantId ? byId.get(occupantId) : undefined;
      if (occupant) {
        bench = [occupant.id, ...bench.filter((id) => id !== player.id)].slice(0, 7);
      }
      lineup[bestSlot] = player.id;
    }

    if (lineup.some((id) => !id)) {
      toast.error('Не удалось собрать полный состав');
      return;
    }

    const payload: TacticPayload = {
      formation: myTeam.formation,
      mentality: myTeam.mentality,
      tempo: myTeam.tempo,
      pressing: myTeam.pressing,
      defLine: myTeam.defLine,
      playStyle: myTeam.playStyle,
      lineup: lineup as string[],
      bench,
    };
    const ok = await saveTactics(payload);
    if (ok) onOpenChange(false);
  };

  const handleSell = async () => {
    if (!player) return;
    const ok = await listPlayer(player.id, sellPrice);
    if (ok) {
      onOpenChange(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="scroll-thin max-h-[88vh] max-w-lg overflow-y-auto sm:max-w-xl">
          <div className="visual-panel rounded-xl border border-primary/20 bg-card p-4" style={{ backgroundImage: "url('/visuals/stadium-night.svg')" }}>
            <div className="flex items-center gap-3">
              <OvrBadge ovr={player.ovr} size="lg" />
              <div className="min-w-0 flex-1">
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Player dossier // live profile</p>
                <p className="mt-1 truncate text-lg font-black">{player.firstName} {player.lastName}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">{player.position} · {player.age} лет · {player.nationality}</p>
              </div>
              {mode === 'squad' || knowledge >= 70 ? <div className="hidden text-right sm:block"><p className="text-[10px] uppercase tracking-wide text-muted-foreground">Потенциал</p><p className="tabular text-lg font-black text-[#EAB308]">{player.potential}</p></div> : null}
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              {[
                ['Готовность', `${player.condition}%`],
                ['Мораль', `${player.morale}%`],
                ['Рейтинг', player.avgRating === null ? '—' : player.avgRating.toFixed(1)],
              ].map(([label, value]) => <div key={label} className="rounded-lg border border-border/60 bg-background/55 px-2 py-2"><p className="tabular text-sm font-bold">{value}</p><p className="mt-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">{label}</p></div>)}
            </div>
          </div>
          <DialogHeader>
            <DialogTitle className="flex flex-wrap items-center gap-2.5 pr-6">
              <OvrBadge ovr={player.ovr} size="lg" />
              <span className="min-w-0">
                {player.firstName} {player.lastName}
              </span>
              <PositionBadge position={player.position} />
              <Badge variant="outline" className="tabular">
                {player.age} лет
              </Badge>
              <Badge variant="secondary">[{player.nationality}]</Badge>
            </DialogTitle>
            <DialogDescription className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
              <span className="flex items-center gap-1">
                <Sparkles className="size-3 text-[#EAB308]" aria-hidden />
                Потенциал:{' '}
                <span className="font-semibold text-[#EAB308]">
                  {mode === 'market' && knowledge < 70 && player.potentialRange[0] !== player.potentialRange[1]
                    ? `${potentialLabelOf(player.potentialRange[0])} — ${potentialLabelOf(player.potentialRange[1])}`
                    : potentialLabelOf(player.potential)}
                </span>
              </span>
              {mode === 'market' ? (
                <Badge
                  variant="outline"
                  className={cn(
                    'text-[10px]',
                    knowledge >= 70
                      ? 'border-[#22C55E]/40 text-[#22C55E]'
                      : 'border-border/60 text-muted-foreground',
                  )}
                  title={
                    `Досье скаутов: ${KNOWLEDGE_TIER_LABELS[knowledgeTierOf(knowledge)]} — ` +
                    (knowledge >= 70
                      ? 'точные атрибуты и потенциал'
                      : knowledge >= 40
                        ? 'атрибуты-оценки (±6), потенциал вилкой'
                        : 'видна только примерная сила (±8)')
                  }
                >
                  <Eye className="size-3" aria-hidden />
                  {KNOWLEDGE_TIER_LABELS[knowledgeTierOf(knowledge)]}
                </Badge>
              ) : null}
              <span className="flex items-center gap-1">
                № <span className="tabular font-semibold">{player.shirtNumber}</span>
              </span>
              {mode === 'squad' ? (
                <Badge
                  className={cn(
                    'text-[10px]',
                    inLineup ? 'bg-primary/15 text-primary' : 'bg-secondary text-muted-foreground',
                  )}
                >
                  {inLineup ? 'Стартовый состав' : 'Не в старте'}
                </Badge>
              ) : null}
              {player.injuryWeeks > 0 ? (
                <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]">
                  <Bandage className="size-3" aria-hidden />
                  Травма: {player.injuryWeeks} тур(а)
                </Badge>
              ) : null}
              {player.preContract ? (
                <Badge
                  className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]"
                  title="Предконтракт с другим клубом — уйдёт по Босману в конце сезона"
                >
                  Уходит по Босману
                </Badge>
              ) : null}
            </DialogDescription>
          </DialogHeader>

          <Tabs value={tab} onValueChange={(v) => setTab(v as 'overview' | 'history')}>
            <TabsList className="w-full sm:w-auto">
              <TabsTrigger value="overview" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
                Обзор
              </TabsTrigger>
              <TabsTrigger value="history" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
                История
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-3">
              <div className="space-y-4">
                {/* Состояние */}
                <div className="grid grid-cols-1 gap-3 rounded-lg border border-border/60 bg-secondary/30 p-3 sm:grid-cols-2">
                  <div>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Готовность</span>
                      <span className="tabular font-semibold">{player.condition}%</span>
                    </div>
                    <Progress value={player.condition} className="h-1.5" />
                  </div>
                  <div>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Мораль</span>
                      <span className={cn('tabular font-semibold', morale.className)}>{morale.label}</span>
                    </div>
                    <Progress value={player.morale} className="h-1.5" />
                  </div>
                </div>

                {/* Атрибуты */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground">
                    {attrsUnknown
                      ? 'Атрибуты скрыты — назначьте скаутинг, чтобы изучить игрока'
                      : isGk
                        ? 'Вратарские и полевые атрибуты'
                        : 'Атрибуты'}
                  </p>

                  {/* Модуль 6: профиль-радар (FM «Playing Styles»): 6 осей — средние групп) */}
                  {!attrsUnknown ? (
                    <div className="rounded-lg border border-border/60 bg-secondary/20 p-2">
                      <p className="pb-1 text-center text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/80">
                        Профиль игрока · радар
                      </p>
                      <AttrRadarChart attrs={player} position={player.position} />
                    </div>
                  ) : null}

                  <div className="grid grid-cols-1 gap-x-6 gap-y-1.5 sm:grid-cols-2">
                    {attrs.map((key) => (
                      <AttributeBar
                        key={key}
                        label={ATTR_LABELS[key]}
                        value={attrsUnknown ? 0 : player[key]}
                        unknown={attrsUnknown}
                        className={cn(isGk && GK_ATTRS.includes(key) && 'sm:col-span-2')}
                      />
                    ))}
                  </div>
                  {mode === 'market' && knowledge >= 40 && knowledge < 70 ? (
                    <p className="text-[10px] text-muted-foreground">
                      Значения — оценки скаутов (могут отличаться на ±6).
                    </p>
                  ) : null}
                </div>

                {/* Экономика */}
                <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
                  <div className="rounded bg-secondary/50 p-2">
                    <div className="text-muted-foreground">Стоимость</div>
                    <div className="tabular font-bold text-[#EAB308]">{formatMoney(player.value)}</div>
                  </div>
                  <div className="rounded bg-secondary/50 p-2">
                    <div className="text-muted-foreground">Зарплата</div>
                    <div className="tabular font-semibold">{formatMoney(player.salary)}/нед</div>
                  </div>
                  {mode === 'market' ? (
                    <>
                      <div className="rounded bg-primary/10 p-2">
                        <div className="text-muted-foreground">Цена лота</div>
                        <div className="tabular font-bold text-primary">
                          {price !== undefined ? formatMoney(price) : '—'}
                        </div>
                      </div>
                      <div className="rounded bg-secondary/50 p-2">
                        <div className="text-muted-foreground">Возраст</div>
                        <div className="tabular font-semibold">{player.age}</div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="rounded bg-secondary/50 p-2">
                        <div className="text-muted-foreground">На продаже</div>
                        <div className="tabular font-semibold">
                          {player.askingPrice !== null ? formatMoney(player.askingPrice) : 'нет'}
                        </div>
                      </div>
                      <div className="rounded bg-secondary/50 p-2">
                        <div className="text-muted-foreground">Контракт</div>
                        <div className="tabular font-semibold">
                          до сезона {player.contractUntil}
                          <span className="block text-[10px] font-normal text-muted-foreground">
                            {yearsLeft > 1
                              ? `осталось ${pluralYears(yearsLeft)} с текущим`
                              : 'истекает по окончании сезона'}
                          </span>
                        </div>
                      </div>
                    </>
                  )}
                </div>

                {/* Бейджи истечения / предконтракта */}
                {mode === 'squad' && (yearsLeft <= 2 || player.preContract) ? (
                  <div className="flex flex-wrap gap-2">
                    {player.preContract ? (
                      <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]">
                        Предконтракт подписан — продление невозможно
                      </Badge>
                    ) : yearsLeft <= 1 ? (
                      <Badge className="border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
                        Контракт истекает — игрок может уйти свободным агентом
                      </Badge>
                    ) : (
                      <Badge className="border border-border/60 bg-secondary/50 text-muted-foreground">
                        Последние два года контракта — окно продления открыто
                      </Badge>
                    )}
                  </div>
                ) : null}

                {/* Статистика сезона */}
                <div className="rounded-lg border border-border/60 bg-secondary/30 p-3">
                  <p className="mb-2 text-xs font-semibold text-muted-foreground">
                    Сезон {snapshot.save.season}
                  </p>
                  <div className="grid grid-cols-6 gap-1 text-center">
                    {(
                      [
                        ['Матчи', player.apps],
                        ['Голы', player.goals],
                        ['Ассисты', player.assists],
                        ['Рейтинг', player.avgRating === null ? null : player.avgRating.toFixed(1)],
                        ['ЖК', player.yellowCards],
                        ['КК', player.redCards],
                      ] as const
                    ).map(([label, value]) => (
                      <div key={label} className="rounded bg-card/70 p-1.5">
                        <div
                          className={cn(
                            'tabular text-sm font-bold',
                            label === 'Рейтинг' && value !== null && avgRatingClass(Number(value)),
                          )}
                        >
                          {value ?? '—'}
                        </div>
                        <div className="text-[10px] text-muted-foreground">{label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Действия */}
                {mode === 'squad' ? (
                  renewMode ? (
                    <RenewSection
                      player={player}
                      onClose={() => setRenewMode(false)}
                      onAccepted={() => onOpenChange(false)}
                    />
                  ) : sellMode ? (
                    <div className="space-y-3 rounded-lg border border-border/60 bg-secondary/30 p-3">
                      <p className="text-xs font-semibold">Выставить на продажу</p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Цена: <span className="tabular font-bold text-[#EAB308]">{formatMoneyExact(sellPrice)}</span></span>
                        <span>Рыночная: {formatMoney(player.value)}</span>
                      </div>
                      <Slider
                        value={[sellPrice]}
                        min={bounds.min}
                        max={bounds.max}
                        step={Math.max(10000, Math.round((bounds.max - bounds.min) / 100 / 10000) * 10000)}
                        onValueChange={(v) => setSellPrice(v[0] ?? bounds.min)}
                        aria-label="Цена продажи"
                      />
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">
                          Шанс продажи за тур:{' '}
                          <span className="tabular font-semibold text-foreground">{sellChance}%</span>
                        </span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <TrendingUp
                            className={cn(
                              'size-3.5',
                              sellChance >= 70 ? 'text-[#22C55E]' : sellChance >= 40 ? 'text-[#FACC15]' : 'text-[#EF4444]',
                            )}
                            aria-hidden
                          />
                          {sellChance >= 70 ? 'высокий интерес' : sellChance >= 40 ? 'средний интерес' : 'низкий интерес'}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="min-h-11 flex-1"
                          onClick={() => setSellMode(false)}
                        >
                          Отмена
                        </Button>
                        <Button className="min-h-11 flex-1" onClick={() => void handleSell()} disabled={loading}>
                          {loading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
                          Выставить
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex flex-col gap-2 sm:flex-row">
                        <Button
                          variant={inLineup ? 'secondary' : 'default'}
                          className="min-h-11 flex-1"
                          onClick={() => void toggleStarter()}
                          disabled={loading || player.injuryWeeks > 0}
                          title={player.injuryWeeks > 0 ? 'Травмированный игрок не может играть' : undefined}
                        >
                          {loading ? (
                            <Loader2 className="size-4 animate-spin" aria-hidden />
                          ) : inLineup ? (
                            <ArrowDown className="size-4" aria-hidden />
                          ) : (
                            <ArrowUp className="size-4" aria-hidden />
                          )}
                          {inLineup ? 'В запас' : 'В старт'}
                        </Button>
                        <Button
                          variant="outline"
                          className="min-h-11 flex-1"
                          onClick={() => {
                            setSellPrice(bounds.min);
                            setSellMode(true);
                          }}
                          disabled={player.injuryWeeks > 0 || player.askingPrice !== null}
                          title={
                            player.askingPrice !== null
                              ? 'Игрок уже на рынке'
                              : player.injuryWeeks > 0
                                ? 'Травмированного игрока нельзя продать'
                                : undefined
                          }
                        >
                          <ShoppingBag className="size-4" aria-hidden />
                          {player.askingPrice !== null ? 'Уже на продаже' : 'Выставить на продажу'}
                        </Button>
                      </div>
                      {renewable ? (
                        <Button
                          variant="outline"
                          className="min-h-11 w-full"
                          onClick={() => setRenewMode(true)}
                          title="Переговоры о продлении контракта (до 3 раундов)"
                        >
                          <FileSignature className="size-4" aria-hidden />
                          Продлить контракт
                        </Button>
                      ) : null}
                    </div>
                  )
                ) : (
                  <div className="space-y-2">
                    {/* Модуль 3: слежение скаутов */}
                    <Button
                      variant={watched ? 'secondary' : 'outline'}
                      className="min-h-11 w-full"
                      onClick={handleWatchToggle}
                      title={
                        watched
                          ? 'Снять наблюдение — знания начнут забываться'
                          : 'Назначить наблюдение: атрибуты и потенциал откроются через недели'
                      }
                    >
                      {watched ? (
                        <>
                          <EyeOff className="size-4" aria-hidden />
                          Снять наблюдение
                        </>
                      ) : (
                        <>
                          <Eye className="size-4" aria-hidden />
                          Следить за игроком
                        </>
                      )}
                    </Button>
                    {/* Модуль 3: переговоры о подписании */}
                    {price !== undefined ? (
                      <SigningSection
                        player={player}
                        price={price}
                        onBought={() => {
                          onOpenChange(false);
                          onBought?.();
                        }}
                      />
                    ) : null}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="history" className="mt-3">
              <HistoryTab playerId={player.id} />
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
}

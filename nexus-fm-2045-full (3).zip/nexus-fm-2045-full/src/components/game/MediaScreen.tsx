'use client';

import { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Bandage, ChevronLeft, ChevronRight, CircleAlert, Loader2, Newspaper, Quote, Shield,
  TriangleAlert, Trophy,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import type { NewspaperClippingDTO, PressMomentDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/**
 * Экран «Медиа» (D-7, спека §5.6): стилизованная газетная полоса —
 * ЕДИНСТВЕННЫЙ светлый экран приложения. «Бумага» кремовая #F5F0E6, текст
 * тёмный #1A1A14, заголовки serif (Georgia/'Times New Roman'), двойные
 * линии-разделители; «фото»-карточки моментов и блок MOTM — в стиле тёмной
 * темы (#151D18 / #2A382F / #D4AF37 / #F0F6FC). Архив: листание
 * «Ранее ←» / «→ Свежее» (offset ±1) + горизонтальная лента страницы.
 * Русский; тачи ≥ 44px; без синих/эмодзи.
 */

/** Размер страницы архива (вырезок на один GET /media). */
const MEDIA_PAGE_SIZE = 10;

/** Газетная гарнитура (§5.6): Georgia/'Times New Roman', serif. */
const SERIF = "Georgia, 'Times New Roman', serif";

/** Контекст-бейдж (§5.2): подпись + бордовый акцент кремовой полосы. */
const CONTEXT_META: Record<string, { label: string; dark?: boolean }> = {
  cup_final_heartbreak: { label: 'Финал кубка' },
  hat_trick: { label: 'Хет-трик' },
  sensation: { label: 'Сенсация' },
  big_win: { label: 'Крупная победа' },
  thrashing: { label: 'Разгром' },
  clean_sheet_win: { label: 'Сухая победа' },
  derby: { label: 'Дерби' },
  draw: { label: 'Ничья' },
  narrow_loss: { label: 'Поражение' },
  plain_win: { label: 'Победа' },
  special_son: { label: 'Спецвыпуск', dark: true },
};

function contextMetaOf(context: string): { label: string; dark?: boolean } {
  return CONTEXT_META[context] ?? { label: 'Выпуск' };
}

/** Иконки «фото»-карточек моментов (§5.6): Trophy/CircleAlert/Bandage/TriangleAlert. */
const MOMENT_ICONS: Record<PressMomentDTO['kind'], typeof Trophy> = {
  goal: Trophy,
  red: TriangleAlert,
  pens: Shield,
  injury: Bandage,
  yellow: CircleAlert,
};

const MOMENT_LABELS: Record<PressMomentDTO['kind'], string> = {
  goal: 'Гол',
  red: 'Красная',
  pens: 'Пенальти',
  injury: 'Травма',
  yellow: 'Жёлтая',
};

/** «Фото»-карточка момента: тёмная карточка в стиле приложения (§5.6). */
function MomentCard({ moment }: { moment: PressMomentDTO }) {
  const Icon = MOMENT_ICONS[moment.kind] ?? Trophy;
  return (
    <div className="break-inside-avoid rounded-md border border-[#2A382F] bg-[#151D18] p-3 shadow-sm">
      <div className="flex items-center gap-2">
        <Icon className="size-4 shrink-0 text-[#D4AF37]" aria-hidden />
        <span className="font-serif text-lg font-bold tabular text-[#D4AF37]">
          {moment.minute}'
        </span>
        <span className="rounded-sm border border-[#2A382F] px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[#9DB5A6]">
          {MOMENT_LABELS[moment.kind]}
        </span>
      </div>
      <p className="mt-2 text-xs leading-relaxed text-[#F0F6FC]">{moment.text}</p>
    </div>
  );
}

/** Газетная полоса — один выпуск (§5.6). */
function NewspaperPage({ clipping, index, total }: {
  clipping: NewspaperClippingDTO;
  index: number;
  total: number;
}) {
  const meta = contextMetaOf(clipping.context);
  const isAcademy = clipping.competition === 'academy';
  const scoreLine = isAcademy
    ? 'Молодёжная академия'
    : `${clipping.homeGoals}:${clipping.awayGoals}`
      + (clipping.homePens !== null && clipping.awayPens !== null
        ? ` (пен. ${clipping.homePens}:${clipping.awayPens})`
        : '');

  return (
    <motion.article
      key={clipping.id}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.28, ease: 'easeOut' }}
      className="relative overflow-hidden rounded-lg border border-[#D8D0BC] bg-[#F5F0E6] px-4 py-5 text-[#1A1A14] shadow-lg sm:px-7 sm:py-7"
      style={{ fontFamily: SERIF }}
      aria-label={`Газетный выпуск: ${clipping.headline}`}
    >
      {/* Лёгкая «неровность бумаги» — виньетка по краям */}
      <div
        className="pointer-events-none absolute inset-0 rounded-lg"
        style={{ boxShadow: 'inset 0 0 44px rgba(120, 104, 70, 0.16)' }}
        aria-hidden
      />

      {/* ── Шапка номера (§5.6): издание · выпуск · сезон ── */}
      <header className="relative text-center">
        <p className="text-[10px] font-semibold uppercase tracking-[0.35em] text-[#7B2D26]">
          Спортивный выпуск
        </p>
        <h2 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
          Спортивный Вестник
        </h2>
        <p className="mt-1 text-[11px] italic text-[#4A453A]">
          Сезон {clipping.season} · неделя {clipping.week} · выпуск {index + 1} из {total}
        </p>
        {/* Газетный двойной бордер */}
        <div className="mt-3 border-t-2 border-[#1A1A14]" aria-hidden />
        <div className="mt-[3px] border-t border-[#1A1A14]" aria-hidden />
      </header>

      {/* ── Счёт в шапке полосы (§5.6) ── */}
      <div className="relative mt-4 text-center">
        <p className="text-sm font-semibold uppercase tracking-wide text-[#4A453A]">
          {isAcademy ? clipping.homeName : `${clipping.homeName} — ${clipping.awayName}`}
        </p>
        <p className="mt-0.5 text-3xl font-bold tabular sm:text-4xl">{scoreLine}</p>
      </div>

      {/* ── Контекст-бейдж ── */}
      <div className="relative mt-3 flex justify-center">
        <span
          className={cn(
            'inline-flex items-center gap-1.5 rounded-sm border px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.18em]',
            meta.dark
              ? 'border-[#D4AF37]/60 bg-[#D4AF37]/15 text-[#7B5B1E]'
              : 'border-[#7B2D26]/40 bg-[#7B2D26]/10 text-[#7B2D26]',
          )}
        >
          {meta.label}
        </span>
      </div>

      {/* ── Крупный заголовок (§5.6: кегль 28–36, serif bold) ── */}
      <h3 className="relative mt-4 text-center text-[28px] font-bold leading-[1.15] tracking-tight sm:text-[34px]">
        {clipping.headline}
      </h3>

      {/* ── Подзаголовок italic serif (§5.6) ── */}
      <p className="relative mt-2 text-center text-sm italic leading-relaxed text-[#4A453A]">
        {clipping.subheadline}
      </p>

      {/* Двойная линия-разделитель */}
      <div className="relative mt-4 border-t-2 border-[#1A1A14]" aria-hidden />
      <div className="mt-[3px] border-t border-[#1A1A14]" aria-hidden />

      {/* ── Тело: 2 колонки (desktop, CSS columns; мобайл — 1) ── */}
      <div className="relative mt-4 gap-6 md:columns-2">
        {/* Первая колонка: выдержка с оценками (§5.6) */}
        <section className="break-inside-avoid">
          <p className="flex items-start gap-2 text-[15px] leading-[1.65] text-[#26221A]">
            <Quote className="mt-1 size-4 shrink-0 rotate-180 text-[#7B2D26]" aria-hidden />
            <span>{clipping.excerpt}</span>
          </p>

          {/* Блок MOTM (§5.6: имя, позиция, оценка крупно serif) */}
          {clipping.motm !== null ? (
            <div className="mt-4 border border-[#C9C0A8] bg-[#EFE8D8] p-3.5">
              <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#7B2D26]">
                Игрок матча
              </p>
              <div className="mt-1.5 flex items-baseline justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-xl font-bold leading-tight">{clipping.motm.name}</p>
                  <p className="mt-0.5 text-xs text-[#4A453A]">{clipping.motm.position}</p>
                </div>
                <p className="shrink-0 text-4xl font-bold tabular text-[#7B5B1E]">
                  {clipping.motm.rating.toFixed(1)}
                </p>
              </div>
            </div>
          ) : null}
        </section>

        {/* Вторая колонка: «фото»-карточки моментов (§5.6) */}
        {clipping.moments.length > 0 ? (
          <section className="mt-4 space-y-3 break-inside-avoid md:mt-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#4A453A]">
              Кадры матча
            </p>
            {clipping.moments.map((m, i) => (
              <MomentCard key={`${m.minute}-${i}`} moment={m} />
            ))}
          </section>
        ) : null}
      </div>

      {/* Подвал номера */}
      <footer className="relative mt-5 border-t border-[#1A1A14]/60 pt-2 text-center text-[10px] italic text-[#4A453A]">
        Спортивный Вестник · пресс-служба клуба · оценка редакции может расходиться с вашей
      </footer>
    </motion.article>
  );
}

/** Пункт горизонтальной ленты архива: дата + заголовок + контекст-бейдж. */
function ArchiveItem({
  clipping,
  active,
  onSelect,
}: {
  clipping: NewspaperClippingDTO;
  active: boolean;
  onSelect: () => void;
}) {
  const meta = contextMetaOf(clipping.context);
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        'flex min-h-[76px] w-56 shrink-0 flex-col items-start gap-1.5 rounded-lg border p-3 text-left transition-colors',
        active
          ? 'border-[#D4AF37] bg-[#D4AF37]/10'
          : 'border-border/60 bg-secondary/40 hover:border-[#D4AF37]/40',
      )}
      aria-current={active ? 'true' : undefined}
    >
      <span className="flex w-full items-center justify-between gap-2">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground tabular">
          Сезон {clipping.season} · нед. {clipping.week}
        </span>
        <span
          className={cn(
            'shrink-0 rounded-sm border px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide',
            meta.dark
              ? 'border-[#D4AF37]/40 text-[#D4AF37]'
              : 'border-border text-muted-foreground',
          )}
        >
          {meta.label}
        </span>
      </span>
      <span className="line-clamp-3 text-xs font-medium leading-snug">
        {clipping.headline}
      </span>
    </button>
  );
}

/** Экран «Медиа» (§5.6): полоса последнего выпуска + архив (листание). */
export function MediaScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const mediaCache = useGameStore((s) => s.mediaCache);
  const mediaLoading = useGameStore((s) => s.mediaLoading);
  const mediaPageIndex = useGameStore((s) => s.mediaPageIndex);
  const fetchMedia = useGameStore((s) => s.fetchMedia);
  const setMediaPageIndex = useGameStore((s) => s.setMediaPageIndex);

  // Ленивая загрузка страницы архива (как loadManager; после playWeek кеш сброшен)
  useEffect(() => {
    if (mediaCache === null) void fetchMedia(0);
  }, [mediaCache, fetchMedia]);

  const clippings = mediaCache?.clippings ?? [];
  const total = mediaCache?.total ?? 0;
  const offset = mediaCache?.offset ?? 0;
  const safeIndex = clippings.length > 0 ? Math.min(mediaPageIndex, clippings.length - 1) : 0;
  const current = clippings[safeIndex] ?? null;
  /** Индекс текущего выпуска во всём архиве (0 = самый свежий). */
  const globalIndex = offset + safeIndex;

  /** Листание на один выпуск по всему архиву (§5.6: offset ±1). */
  const go = (target: number): void => {
    if (target < 0 || target >= total || target === globalIndex) return;
    if (target >= offset && target < offset + clippings.length) {
      setMediaPageIndex(target - offset);
      return;
    }
    if (target > globalIndex) {
      // «Ранее» — следующая страница архива начинается с этого выпуска
      void fetchMedia(target);
    } else {
      // «Свежее» — предыдущая страница: выпуск последним в ней
      const newOffset = Math.max(0, target - (MEDIA_PAGE_SIZE - 1));
      void fetchMedia(newOffset).then(() => setMediaPageIndex(target - newOffset));
    }
  };

  const hasOlder = globalIndex + 1 < total;
  const hasNewer = globalIndex > 0;

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Медиа"
        subtitle={`${snapshot.myTeam.name} · Спортивный Вестник — послематчевые выпуски`}
        action={
          <Badge variant="outline" className="gap-1 text-[11px] tabular">
            <Newspaper className="size-3.5" aria-hidden />
            {total > 0 ? `${total} из 60` : 'архив пуст'}
          </Badge>
        }
      />

      {/* Полоса / загрузка / заглушка */}
      {mediaLoading && mediaCache === null ? (
        <div className="flex min-h-[320px] items-center justify-center rounded-lg border border-border/60 bg-secondary/30">
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" aria-hidden />
            Открываем типографию…
          </p>
        </div>
      ) : current !== null ? (
        <AnimatePresence mode="wait">
          <NewspaperPage key={current.id} clipping={current} index={globalIndex} total={total} />
        </AnimatePresence>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="flex min-h-[320px] flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border/70 bg-secondary/30 p-6 text-center"
        >
          <Newspaper className="size-10 text-muted-foreground/70" aria-hidden />
          <p className="text-sm font-semibold">Выпусков ещё нет — сыграйте первый матч</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            После каждого матча клуба (лига, кубок, Кубок Европы) «Спортивный Вестник»
            выходит с послематчевым выпуском: заголовок, игрок матча и кадры игры.
          </p>
        </motion.div>
      )}

      {/* Листание архива (§5.6): «Ранее ←» / «→ Свежее», счётчик «{n} из {total}» */}
      {total > 0 ? (
        <div className="flex items-center justify-between gap-2 rounded-lg border border-border/60 bg-secondary/30 p-2">
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="min-h-11 flex-1 font-semibold sm:max-w-44"
            disabled={!hasOlder || mediaLoading}
            onClick={() => go(globalIndex + 1)}
          >
            <ChevronLeft className="size-4" aria-hidden />
            Ранее
          </Button>
          <p className="px-2 text-center text-xs font-semibold tabular text-muted-foreground">
            {globalIndex + 1} из {total}
          </p>
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="min-h-11 flex-1 font-semibold sm:max-w-44"
            disabled={!hasNewer || mediaLoading}
            onClick={() => go(globalIndex - 1)}
          >
            Свежее
            <ChevronRight className="size-4" aria-hidden />
          </Button>
        </div>
      ) : null}

      {/* Горизонтальная лента страницы архива (свежие выпуска) */}
      {clippings.length > 1 ? (
        <section>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Архив выпусков
          </p>
          <div
            className="flex gap-2 overflow-x-auto pb-2"
            role="list"
            aria-label="Лента последних газетных выпусков"
          >
            {clippings.map((c, i) => (
              <ArchiveItem
                key={c.id}
                clipping={c}
                active={i === safeIndex}
                onSelect={() => setMediaPageIndex(i)}
              />
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground">
            Показаны выпуски {offset + 1}–{offset + clippings.length} из {total}. Листайте
            кнопками выше — архив хранит последние 60 выпусков.
          </p>
        </section>
      ) : null}
    </div>
  );
}

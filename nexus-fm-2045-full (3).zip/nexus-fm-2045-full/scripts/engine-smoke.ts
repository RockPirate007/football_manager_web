/**
 * D-3b engine-smoke — регрессия движка по §8.1 спеки (этап D-3: S0–S3 + S10).
 * Запуск: `bun scripts/engine-smoke.ts` (StorageAdapter = MemoryStorage в bun).
 * Секции:
 *  S0  — адаптер SaveStore: where {not}/{in}/relation-фильтры, orderBy/take/skip,
 *        select, include {player}/{team}, $transaction, P2002/P2025, canonical
 *        roundtrip, Prisma-семантика undefined в update;
 *  S1  — создание карьер × 6 лиг (112 клубов) + константы + db-прокси активной
 *        карьеры + уборка слотов;
 *  S2  — неделя 1 (EPL): матчи созданы/сыграны, счёт валиден, события матча
 *        (трансляция), статы, финансы, рынок 50–70, новости;
 *  S3  — недели 2–4: трансферы/тренировки/контракты/академия не падают,
 *        диффы-записи пишутся; сейв/лоад байт-в-байт ПОСЛЕ simulate
 *        (canonical-правило: конверт слота меняется только через touchSlot);
 *        детерминизм: один сид + замороженные часы + патч crypto.randomUUID →
 *        два одинаковых слота, 5 недель → байт-в-байт одинаковые файлы;
 *  S10 — полный сезон EPL (43 недели): финальная таблица, чемпион, 8 наград,
 *        записи истории, старение игроков, евро-недели/гости (изоляция),
 *        новый календарь сезона 2, время прогона < 2000 мс/неделя;
 *  S11 — D-5 «Территория»: каталог цен/дней §3.1, стартовые уровни по stature
 *        (топ/середняк/аутсайдер + ИИ), BuildingsDTO, POST /buildings (ошибки
 *        404/402/409, списание баланса, FinanceRecord construction), таймер
 *        (2 недели → level+1 + новость), содержание/мерч/VIP в финансах,
 *        юнит-проверки множителей (xp/травмы/восстановление/билеты/академия);
 *  S12 — D-6 «Тренер»: каталог 7 активов §4.2 + продажа 70%/−ceil(p/2),
 *        парсер/канонический JSON, юниты эффектов престижа, старт-профиль
 *        (зарплаты по stature 120К/45К/12К, кошелёк 50К, престиж 400×10),
 *        GET /manager DTO, POST /manager/asset (buy/sell/409/402/404, новости),
 *        coach_wages в финансах, кошелёк в минусе (−10/нед + новость),
 *        VIP-достройка +20·L, сезонные дельты престижа (точная формула),
 *        семья: женитьба p=0.04 (реплика сида) → ребёнок (ровно 40 недель) →
 *        сын в академии (ускоренный переход) + buildSonAcademyPlayer (юнит);
 *  S13 — D-7 «Газеты»: классификатор 11 контекстов §5.2 (синтетика), шаблоны
 *        ≤70 с worst-case подстановками, buildClipping (детерминизм сида
 *        press:, MOTM/выдержка/моменты), спецвыпуск «сын в академии» (юнит +
 *        интеграция перехода S12), лиговая неделя → вырезка, конгестия
 *        кубок+евро → 2 вырезки, архив ≤ 60 (62 синтетических + неделя),
 *        GET /media (пагинация/DTO/сорт/ошибки), канонический roundtrip.
 * Печать: PASS/FAIL по пунктам; итог PASS=N FAIL=M; exit code 0/1.
 */

import { buildSeasonPlan, weekSlotAt } from '@/lib/game/calendar';
import {
  ACADEMY_INTAKE_WEEK, CONTRACT_AI_SQUAD_FLOOR, EURO_GUEST_MIN_SQUAD, EURO_ROUNDS,
  MARKET_SIZE_MAX, MARKET_SIZE_MIN, SAVES_MAX, START_BALANCE_BASE,
  START_BALANCE_PER_STRENGTH,
} from '@/lib/game/constants';
import { LEAGUES, NAME_POOLS, leagueByCode } from '@/lib/game/leagues';
import { computeStandings, type StandingMatchInput, type StandingTeamInput } from '@/lib/game/standings';
import type {
  AcademyResponse, ManagerResponse, MatchEvent, MatchEventType, MediaResponse, Position,
  WeekResultPayload,
} from '@/lib/game/types';
import { runIntakeForClub } from '@/lib/game/academy';
import { attendanceRate, computeWeekFinance } from '@/lib/game/finances';
import { simulateMatch, type MatchTeamInput } from '@/lib/game/match';
import { autoLineup, generatePlayer, type PlayerLike } from '@/lib/game/players';
import { applyMatchEffects, applyWeeklyRecovery } from '@/lib/game/progression';
import { hashString, mulberry32, pick } from '@/lib/game/rng';
import { parseTrainingXp } from '@/lib/game/types';
import { applyWeeklyTraining } from '@/lib/game/training';
import { ApiGameError } from '@/lib/game/error';
import { poolContextOf } from '@/lib/game/generate';
import {
  BUILDINGS, BUILDING_IDS, absoluteDayOf, parseBuildings, serializeBuildings,
  startLevelsByStrength, upkeepWeeklyOfBuilding, upkeepWeeklyTotal,
} from '@/engine/buildings';
import {
  ASSETS, FEMALE_NAME_POOLS, MANAGER_AGE_START, MANAGER_CHILD_AFTER_WEEKS,
  MANAGER_MARRIAGE_P, MANAGER_PRESTIGE_START, MANAGER_SALARY_BY_TIER,
  MANAGER_WALLET_START, absoluteWeekOf, boardWarnBelowOf, buildSonAcademyPlayer,
  clampPrestige, contractsPrestigeMult, managerMarketPrice, parseManager,
  prestigeLabelOf, serializeManager, sellPrestigeOf, sellPriceOf,
  type ManagerFamilyState, type ManagerState,
} from '@/engine/manager';
import {
  PRESS_ARCHIVE_LIMIT, PRESS_HEADLINES, PRESS_NEWSPAPER_NAME, PRESS_PHRASES,
  buildClipping, buildSonClipping, classifyPressContext, computePressRatings,
  fillHeadlineTemplate, parseMoments, parseMotm, pickMoments, userGoalsByPlayer,
  type PressContext, type PressMatchContextInput, type PressMatchInput,
} from '@/engine/press';
import type { GameSaveRecord } from '@/engine/models';
import { engineDispatch } from '@/engine/router';
import {
  createSaveStore, createSaveStoreFromDump, db, EngineRecordNotFoundError, EngineUniqueError,
} from '@/engine/db';
import { getEngine } from '@/engine/index';
import { createStorage, MemoryStorage } from '@/engine/storage';

// Патч crypto.randomUUID — единственный недетерминизм simulateWeek (id новостей/
// лотов/финансов). Включается ДО первой симуляции (S2): весь прогон смоука
// детерминирован, включая S10 (иначе увольнение — лотерея рыночных id).
let uuidCounter = 0;
const uuidFactory = ((): string => {
  uuidCounter += 1;
  return `00000000-0000-4000-8000-${String(uuidCounter).padStart(12, '0')}`;
}) as typeof crypto.randomUUID;
crypto.randomUUID = uuidFactory;

let pass = 0;
let fail = 0;
const failures: string[] = [];

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    pass += 1;
    console.log(`PASS ${name}`);
  } else {
    fail += 1;
    const suffix = detail !== undefined ? ` :: ${detail}` : '';
    console.log(`FAIL ${name}${suffix}`);
    failures.push(name);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  const show = (v: unknown): string => {
    if (typeof v === 'string') return JSON.stringify(v);
    return String(v);
  };
  check(name, actual === expected, `actual=${show(actual)} expected=${show(expected)}`);
}

const NOW = new Date('2025-01-01T12:00:00.000Z');
const EVENT_TYPES = new Set<MatchEventType>([
  'kickoff', 'goal', 'yellow', 'red', 'injury', 'chance', 'halftime', 'fulltime',
  'pen_goal', 'pen_miss', 'pen_save', 'sub',
  // Engine 2.0: детальные события ленты/радара
  'shot_on', 'shot_off', 'save', 'corner', 'offside', 'duel', 'momentum',
]);

const engine = getEngine();
const storage = await createStorage();

// ── S0: адаптер SaveStore ──────────────────────────────────────────────────

console.log('== S0: адаптер (where/orderBy/include/transaction/unique/canonical) ==');

eq('s0_storage_memory_in_bun', storage instanceof MemoryStorage, true);

const store0 = createSaveStore({ clock: () => NOW });
await store0.$transaction([
  store0.gameSave.create({ data: { id: 's0save', managerName: 'Тест', leagueCode: 'EPL', teamId: 'tLeague' } }),
  store0.team.create({ data: { id: 'tLeague', saveId: 's0save', name: 'Лига', strength: 70 } }),
  store0.team.create({ data: { id: 'tGuest', saveId: 's0save', name: 'Гость', strength: 70, isEuroGuest: true } }),
  store0.player.create({ data: { id: 'pHome', saveId: 's0save', teamId: 'tLeague', firstName: 'А', lastName: 'Б', position: 'ST' } }),
  store0.player.create({ data: { id: 'pGuest', saveId: 's0save', teamId: 'tGuest', firstName: 'В', lastName: 'Г', position: 'MC' } }),
  store0.player.create({ data: { id: 'pFree', saveId: 's0save', teamId: null, firstName: 'Д', lastName: 'Е', position: 'GK' } }),
  store0.match.create({ data: { id: 'm1', saveId: 's0save', season: 1, week: 1, homeTeamId: 'tLeague', awayTeamId: 'tGuest' } }),
  store0.match.create({ data: { id: 'm2', saveId: 's0save', season: 1, week: 1, homeTeamId: 'tGuest', awayTeamId: 'tLeague' } }),
  store0.match.create({ data: { id: 'm3', saveId: 's0save', season: 1, week: 2, homeTeamId: 'tLeague', awayTeamId: 'tGuest' } }),
  store0.transferListing.create({ data: { id: 'l1', saveId: 's0save', playerId: 'pFree', price: 100_000 } }),
]);

const s0NotIn = await store0.player.findMany({
  where: { saveId: 's0save', teamId: { not: null }, id: { in: ['pHome', 'pGuest', 'pFree'] } },
});
eq('s0_where_not_in', s0NotIn.map((p) => p.id).sort().join(','), 'pGuest,pHome');

// Relation-фильтр (расширение D-3b): snapshot.ts `team: { isEuroGuest: false }`
const s0LeaguePlayers = await store0.player.findMany({
  where: { saveId: 's0save', teamId: { not: null }, team: { isEuroGuest: false } },
});
eq('s0_relation_where_league_only', s0LeaguePlayers.map((p) => p.id).join(','), 'pHome');

const s0FreeByRelation = await store0.player.findMany({
  where: { saveId: 's0save', team: null },
});
eq('s0_relation_where_team_null', s0FreeByRelation.map((p) => p.id).join(','), 'pFree');

const s0Sorted = await store0.match.findMany({
  where: { saveId: 's0save' },
  orderBy: [{ week: 'asc' }, { id: 'desc' }],
  skip: 1,
  take: 2,
});
eq('s0_orderby_take_skip', s0Sorted.map((m) => m.id).join(','), 'm1,m3');

const s0Selected = await store0.match.findMany({
  where: { saveId: 's0save' },
  select: { id: true, week: true },
});
check(
  's0_select_keys',
  s0Selected.length > 0 && s0Selected.every((m) => Object.keys(m).join(',') === 'id,week'),
  `keys=${s0Selected[0] ? Object.keys(s0Selected[0]).join(',') : 'empty'}`,
);

const s0Listing = await store0.transferListing.findMany({
  where: { saveId: 's0save' },
  include: { player: true },
});
eq('s0_include_player', s0Listing[0]?.player?.id, 'pFree');

const s0SaveRow = await store0.gameSave.findUnique({ where: { id: 's0save' }, include: { team: true } });
eq('s0_include_team', s0SaveRow?.team?.id, 'tLeague');

await store0.$transaction([
  store0.team.update({ where: { id: 'tLeague' }, data: { strength: 75 } }),
  store0.match.update({ where: { id: 'm1' }, data: { stats: '{"x":1}' } }),
]);
eq('s0_transaction_applied', (await store0.team.findUnique({ where: { id: 'tLeague' } }))?.strength, 75);

// Prisma-семантика undefined: поле не трогается (week.ts playedMatchOps: stats)
await store0.match.update({ where: { id: 'm1' }, data: { homeGoals: 2, stats: undefined } });
const s0M1 = await store0.match.findUnique({ where: { id: 'm1' } });
check('s0_update_undefined_keeps', s0M1?.stats === '{"x":1}' && s0M1?.homeGoals === 2, `stats=${s0M1?.stats}`);

let s0P2002 = false;
let s0P2002Target = '';
try {
  await store0.match.create({
    data: { id: 'mDup', saveId: 's0save', season: 1, week: 1, homeTeamId: 'tLeague', awayTeamId: 'tOther' },
  });
} catch (error) {
  s0P2002 = error instanceof EngineUniqueError;
  s0P2002Target = (error as EngineUniqueError).meta.target.join(',');
}
check('s0_p2002_match_composite', s0P2002 && s0P2002Target === 'saveId,season,week,homeTeamId,competition', `target=${s0P2002Target}`);

let s0P2025 = false;
try {
  await store0.player.update({ where: { id: 'missing' }, data: { goals: 1 } });
} catch (error) {
  s0P2025 = error instanceof EngineRecordNotFoundError;
}
eq('s0_p2025_update_missing', s0P2025, true);

const s0Dump1 = JSON.stringify(store0.toJSON());
const s0Reloaded = createSaveStoreFromDump(store0.toJSON(), { clock: () => NOW });
eq('s0_canonical_roundtrip', JSON.stringify(s0Reloaded.toJSON()), s0Dump1);

// db-прокси без активной карьеры — контролируемый отказ
let s0ProxyThrew = false;
try {
  await db.team.findMany();
} catch {
  s0ProxyThrew = true;
}
eq('s0_db_proxy_requires_active', s0ProxyThrew, true);

// ── S1: карьера × 6 лиг + константы ────────────────────────────────────────

console.log('\n== S1: createCareer × 6 лиг (112 клубов) + константы ==');

eq('s1_leagues_count', LEAGUES.length, 6);
eq('s1_clubs_total', LEAGUES.reduce((s, l) => s + l.teamCount, 0), 112);
eq('s1_saves_max', SAVES_MAX, 8);
eq('s1_market_bounds', `${MARKET_SIZE_MIN}-${MARKET_SIZE_MAX}`, '50-70');

const createdSlots: number[] = [];
for (const def of LEAGUES) {
  const res = await engine.createCareer({
    leagueCode: def.code,
    clubIndex: 0,
    managerName: 'Смоук Менеджер',
    seed: 3000 + def.teamCount,
    now: NOW,
  });
  createdSlots.push(res.slot);
  const store = engine.requireStore();
  const teams = await store.team.findMany({ where: { saveId: res.saveId } });
  const players = await store.player.findMany({ where: { saveId: res.saveId } });
  const matches = await store.match.findMany({ where: { saveId: res.saveId } });
  const saveRow = await store.gameSave.findUnique({ where: { id: res.saveId } });
  const N = def.teamCount;

  check(
    `s1_career_${def.code}_structure`,
    teams.length === N
      && players.length >= N * 20 && players.length <= N * 22
      && matches.length === N * (N - 1),
    `teams=${teams.length} players=${players.length} matches=${matches.length} (N=${N})`,
  );
  const userTeam = teams.find((t) => t.id === saveRow?.teamId);
  const lineup: unknown = userTeam ? JSON.parse(userTeam.lineup ?? '[]') : [];
  const bench: unknown = userTeam ? JSON.parse(userTeam.bench ?? '[]') : [];
  check(
    `s1_career_${def.code}_state`,
    saveRow?.week === 1 && saveRow?.season === 1 && saveRow?.status === 'active'
      && Array.isArray(lineup) && lineup.length === 11
      && Array.isArray(bench) && bench.length <= 7,
    `week=${saveRow?.week} status=${saveRow?.status} lineup=${Array.isArray(lineup) ? lineup.length : 'x'}`,
  );
}

// db-прокси резолвится в активную карьеру (последний createCareer)
const s1ProxyTeams = await db.team.findMany({ where: { saveId: engine.saveId ?? '' } });
eq('s1_db_proxy_resolves_active', s1ProxyTeams.length, LEAGUES[LEAGUES.length - 1].teamCount);

// Уборка: слоты освобождаются, список пустеет (границы 8 слотов — в selftest D-3a)
for (const slot of createdSlots) await engine.removeSlot(slot);
eq('s1_slots_cleanup', (await engine.listSlots()).length, 0);
eq('s1_store_unloaded', engine.store === null, true);

// ── S2: неделя 1 (EPL) ─────────────────────────────────────────────────────

console.log('\n== S2: прогон недели 1 (EPL, 20 клубов) ==');

const EPL = leagueByCode('EPL');
if (!EPL) throw new Error('engine-smoke: EPL не найдена в LEAGUES');
const eplPlan = buildSeasonPlan('EPL');

// D-3c: seed 7 вместо 42 — при 42 (как и на сервере; паритет движка подтверждён
// scripts/d33-parity2.ts на 45 недель) правление увольняет менеджера
// в середине сезона (цель champion, темп ниже цели + зарплаты > 70% дохода);
// инвариантам S10 нужен полный сезон; 7 даёт запас (conf >= 54).
const career = await engine.createCareer({
  leagueCode: 'EPL',
  clubIndex: 0,
  managerName: 'Смоук Менеджер',
  seed: 7,
  now: NOW,
});
const eplSlot = career.slot;
const eplSaveId = career.saveId;
const startBalance =
  START_BALANCE_BASE + Math.max(0, EPL.clubs[0].str - 55) * START_BALANCE_PER_STRENGTH;

eq('s2_slot_activated', engine.slot === eplSlot && engine.saveId === eplSaveId && engine.store !== null, true);

const week1 = await engine.simulateActiveWeek();

eq('s2_week1_type', `${week1.weekType}|${week1.season}|${week1.week}`, `league|1|1`);
eq('s2_week1_label', week1.weekLabel, `Тур 1/${eplPlan.leagueWeeks}`);
eq('s2_user_matches_count', week1.userMatches.length, 1);
const um1 = week1.userMatches[0];
eq('s2_user_match_competition', um1?.competition, 'league');
check(
  's2_score_valid',
  [um1?.homeGoals, um1?.awayGoals].every((g) => typeof g === 'number' && Number.isInteger(g) && g >= 0 && g <= 12),
  `score=${um1?.homeGoals}:${um1?.awayGoals}`,
);
const goalEvents1 = (um1?.events ?? []).filter((e) => e.type === 'goal');
eq('s2_goal_events_match_score', goalEvents1.length, (um1?.homeGoals ?? 0) + (um1?.awayGoals ?? 0));
check(
  's2_events_wellformed',
  (um1?.events ?? []).length > 0 && (um1?.events ?? []).every(
    (e) => e.minute >= 0 && e.minute <= 96 && EVENT_TYPES.has(e.type) && typeof e.text === 'string' && e.text.length > 0,
  ),
  `events=${(um1?.events ?? []).length}`,
);
check(
  's2_stats_present',
  um1?.stats != null && um1.stats.possessionHome > 0 && um1.stats.possessionHome < 100,
  `possession=${um1?.stats?.possessionHome}`,
);
eq('s2_week_results_count', week1.weekResults.length, EPL.teamCount / 2);
check(
  's2_week_results_valid',
  week1.weekResults.every((r) => r.homeGoals >= 0 && r.awayGoals >= 0),
  '',
);

const storeE = engine.requireStore();
const playedWeek1 = await storeE.match.findMany({
  where: { saveId: eplSaveId, season: 1, week: 1, status: 'played' },
});
eq('s2_db_rows_played', playedWeek1.length, EPL.teamCount / 2);
const saveRow1 = await storeE.gameSave.findUnique({ where: { id: eplSaveId } });
eq('s2_week_advanced', `${saveRow1?.season}:${saveRow1?.week}`, '1:2');

const financeWeek1 = await storeE.financeRecord.findMany({
  where: { saveId: eplSaveId, season: 1, week: 1 },
});
const financeCats = new Set(financeWeek1.map((r) => r.category));
check(
  's2_finance_wages_sponsor',
  financeWeek1.length >= 2 && financeCats.has('wages') && financeCats.has('sponsor'),
  `cats=${[...financeCats].join(',')}`,
);
check('s2_balance_changed', saveRow1?.balance !== startBalance, `balance=${saveRow1?.balance} start=${startBalance}`);

const marketActive1 = await storeE.transferListing.findMany({
  where: { saveId: eplSaveId, status: 'active' },
});
check(
  's2_market_topup_50_70',
  marketActive1.length >= MARKET_SIZE_MIN && marketActive1.length <= MARKET_SIZE_MAX,
  `active=${marketActive1.length}`,
);

const newsRows1 = await storeE.newsItem.findMany({ where: { saveId: eplSaveId } });
check(
  's2_news_grew',
  newsRows1.length >= 2 && newsRows1.some((n) => n.message.includes('Тур 1')),
  `news=${newsRows1.length}`,
);

// ── S3: недели 2–4 + сейв/лоад байт-в-байт + детерминизм ────────────────────

console.log('\n== S3: недели 2-4 + roundtrip байт-в-байт + детерминизм ==');

for (let w = 2; w <= 4; w++) {
  await engine.simulateActiveWeek();
  const saveRow = await engine.requireStore().gameSave.findUnique({ where: { id: eplSaveId } });
  eq(`s3_week_${w}_ok`, `${saveRow?.season}:${saveRow?.week}`, `1:${w + 1}`);

  // canonical-правило: save → load → save даёт байт-в-байт тот же файл
  // (конверт слота не меняется — touchSlot не вызывался, дамп каноничен)
  await engine.saveSlot();
  const bytes1 = await storage.read(eplSlot);
  await engine.loadSlot(eplSlot);
  await engine.saveSlot();
  const bytes2 = await storage.read(eplSlot);
  check(
    `s3_roundtrip_week_${w}`,
    typeof bytes1 === 'string' && typeof bytes2 === 'string' && bytes1 === bytes2,
    `bytes1=${typeof bytes1 === 'string' ? bytes1.length : 'null'} bytes2=${typeof bytes2 === 'string' ? bytes2.length : 'null'}`,
  );
}

const dumpBeforeLoad = JSON.stringify(engine.requireStore().toJSON());
await engine.loadSlot(eplSlot);
eq('s3_canonical_dump_stable', JSON.stringify(engine.requireStore().toJSON()), dumpBeforeLoad);

const store3 = engine.requireStore();
const players3 = await store3.player.findMany({ where: { saveId: eplSaveId } });
check('s3_training_xp_written', players3.filter((p) => p.trainingXp !== null).length >= 10, `xp=${players3.filter((p) => p.trainingXp !== null).length}`);
const squadContracts = players3.filter((p) => p.teamId !== null);
eq('s3_contracts_valid', squadContracts.every((p) => p.contractUntil >= 1), true);
check('s3_apps_accumulated', players3.filter((p) => p.apps > 0).length >= 200, `apps>0=${players3.filter((p) => p.apps > 0).length}`);

const marketActive3 = await store3.transferListing.findMany({
  where: { saveId: eplSaveId, status: 'active' },
});
check(
  's3_market_range',
  marketActive3.length >= MARKET_SIZE_MIN && marketActive3.length <= MARKET_SIZE_MAX + 15,
  `active=${marketActive3.length}`,
);

// Неделя 4 — набор академии (ACADEMY_INTAKE_WEEK): воспитанники созданы
const academyPlayers = players3.filter((p) => p.isAcademy);
check('s3_academy_intake', academyPlayers.length >= EPL.teamCount * 2, `academy=${academyPlayers.length}`);
const academyNews = await store3.newsItem.findMany({
  where: { saveId: eplSaveId, season: 1, week: ACADEMY_INTAKE_WEEK, type: 'academy' },
});
eq('s3_academy_news', academyNews.length > 0, true);

// Детерминизм: один сид + замороженные часы + патч crypto.randomUUID
// (имя менеджера одинаковое: managerName и welcome-новость входят в файл слота)
const detSeed = 777;
const detA = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: 5, managerName: 'Дет', seed: detSeed, now: NOW,
});
const detB = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: 5, managerName: 'Дет', seed: detSeed, now: NOW,
});
eq('s3_same_seed_same_creation_file', await storage.read(detA.slot), await storage.read(detB.slot));

// Счётчик патча (уже включён до S2) — сброс перед каждым дет-прогоном

const detClock = (): Date => NOW;
const runFiveWeeks = async (slot: number): Promise<string> => {
  uuidCounter = 0;
  await engine.loadSlot(slot, { clock: detClock });
  for (let i = 0; i < 5; i++) await engine.simulateActiveWeek();
  await engine.saveSlot();
  const raw = await storage.read(slot);
  if (raw === null) throw new Error(`engine-smoke: слот ${slot} пуст после прогона`);
  return raw;
};

const detFileA = await runFiveWeeks(detA.slot);
const detFileB = await runFiveWeeks(detB.slot);
check('s3_determinism_5weeks_bytes', detFileA === detFileB, `a=${detFileA.length} b=${detFileB.length}`);

const detSaveB = (await engine.requireStore().gameSave.findFirst());
eq('s3_determinism_week_progress', `${detSaveB?.season}:${detSaveB?.week}`, '1:6');

eq('s3_slots_list', (await engine.listSlots()).length, 3); // EPL + Дет А + Дет Б

// ── S10: полный сезон EPL (43 недели) ─────────────────────────────────────

console.log('\n== S10: полный сезон EPL (43 недели) + переход ==');

await engine.loadSlot(eplSlot);
const storeS10 = engine.requireStore();
const userTeamId = (await storeS10.gameSave.findFirst())?.teamId ?? null;
if (!userTeamId) throw new Error('engine-smoke: teamId карьеры EPL не найден');

const agesBeforeFinal: Map<string, number> = new Map();
let weeksRun = 0;
let lastPayload: WeekResultPayload | null = null;
let sacked = false;
const t0 = Date.now();

while (weeksRun < 60) {
  const saveRow = await storeS10.gameSave.findFirst();
  if (!saveRow || saveRow.season >= 2 || saveRow.week > eplPlan.totalWeeks) break;
  if (saveRow.week === eplPlan.totalWeeks) {
    const squad = await storeS10.player.findMany({ where: { saveId: eplSaveId, teamId: userTeamId } });
    for (const p of squad) agesBeforeFinal.set(p.id, p.age);
  }
  const payload = await engine.simulateActiveWeek();
  lastPayload = payload;
  weeksRun += 1;
  const row = await storeS10.gameSave.findFirst();
  if (row && row.status !== 'active') {
    sacked = true;
    break;
  }
}
const elapsedMs = Date.now() - t0;

const finalSave = await storeS10.gameSave.findFirst();
eq('s10_season_transition', `${finalSave?.season}:${finalSave?.week}:${finalSave?.status}`, '2:1:active');
eq('s10_not_sacked', sacked, false);
eq('s10_weeks_run', weeksRun, eplPlan.totalWeeks - 4); // старт с недели 5
const avgMs = weeksRun > 0 ? Math.round(elapsedMs / weeksRun) : -1;
check('s10_time_budget', avgMs >= 0 && avgMs < 2000, `avg=${avgMs} мс/неделя, всего=${elapsedMs} мс`);
console.log(`     время сезона: ${elapsedMs} мс (${avgMs} мс/неделя, ${weeksRun} недель)`);

check(
  's10_season_ended_payload',
  lastPayload?.seasonEnded != null
    && lastPayload.seasonEnded.standings.length === EPL.teamCount
    && lastPayload.seasonEnded.place >= 1 && lastPayload.seasonEnded.place <= EPL.teamCount,
  `place=${lastPayload?.seasonEnded?.place ?? 'null'}`,
);

const playedLeagueS1 = await storeS10.match.findMany({
  where: { saveId: eplSaveId, season: 1, status: 'played', competition: 'league' },
});
eq('s10_league_matches_complete', playedLeagueS1.length, EPL.teamCount * (EPL.teamCount - 1));

// Финальная таблица (пересчёт из сыгранных матчей) и чемпион
const teamsS10 = await storeS10.team.findMany({ where: { saveId: eplSaveId, isEuroGuest: false } });
const standingTeams: StandingTeamInput[] = teamsS10.map((t) => ({
  id: t.id, name: t.name, shortName: t.shortName,
  colorPrimary: t.colorPrimary, colorSecondary: t.colorSecondary, isUser: t.isUserTeam,
}));
const standingMatches: StandingMatchInput[] = playedLeagueS1
  .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
  .map((m) => ({
    homeTeamId: m.homeTeamId, awayTeamId: m.awayTeamId,
    homeGoals: m.homeGoals as number, awayGoals: m.awayGoals as number, week: m.week,
  }));
const finalTable = computeStandings(standingTeams, standingMatches);
const championRow = finalTable[0];

const awardsS1 = await storeS10.seasonAward.findMany({ where: { saveId: eplSaveId, season: 1 } });
const awardTypes = new Set(awardsS1.map((a) => a.type));
const championAward = awardsS1.find((a) => a.type === 'champion');
check(
  's10_champion_determined',
  championAward != null && championAward.teamId === championRow?.teamId,
  `award=${championAward?.teamId ?? 'null'} table=${championRow?.teamId ?? 'null'}`,
);

const cupFinals = await storeS10.match.findMany({
  where: { saveId: eplSaveId, season: 1, competition: 'cup', cupRound: eplPlan.cupRounds },
});
const cupWinnerAward = awardsS1.find((a) => a.type === 'cup_winner');
check(
  's10_cup_final_played',
  cupFinals.length > 0 && cupFinals.every((m) => m.status === 'played' && m.winnerTeamId !== null)
    && cupWinnerAward != null && cupWinnerAward.teamId === cupFinals[0]?.winnerTeamId,
  `finals=${cupFinals.length} winner=${cupFinals[0]?.winnerTeamId ?? 'null'}`,
);

eq('s10_awards_8', awardsS1.length, 8);
check(
  's10_awards_types',
  awardTypes.size === 8
    && ['champion', 'cup_winner', 'top_scorer', 'mvp'].every((t) => awardTypes.has(t)),
  `types=${[...awardTypes].sort().join(',')}`,
);

const seasonRecords = await storeS10.playerSeasonRecord.findMany({
  where: { saveId: eplSaveId, season: 1 },
});
const seasonRecordsFa = seasonRecords.filter((r) => r.teamId === null).length;
check(
  's10_season_records',
  // [D-3c] записи = составы лиги (~500) + гости еврокубка (~300) + свободные агенты
  // (buildSeasonRecords: squadPlayers+guestSides+freeAgents) — окно research §3 400-900
  // занижено (замер был без учёта гостей/FA); корректный коридор 600-1400 + FA ≥ 100
  seasonRecords.length >= 600 && seasonRecords.length <= 1400 && seasonRecordsFa >= 100,
  `records=${seasonRecords.length} fa=${seasonRecordsFa}`,
);

// Старение: выжившие игроки клуба — возраст +1 (снапшот ДО финальной недели)
const squadAfter = await storeS10.player.findMany({ where: { saveId: eplSaveId, teamId: userTeamId } });
const agedOk = squadAfter.filter((p) => {
  const before = agesBeforeFinal.get(p.id);
  return before !== undefined && p.age === before + 1;
});
const knownAfter = squadAfter.filter((p) => agesBeforeFinal.has(p.id));
check(
  's10_players_aged',
  knownAfter.length >= 15 && agedOk.length === knownAfter.length,
  `aged=${agedOk.length}/${knownAfter.length} squad=${squadAfter.length}`,
);

const newCalendar = await storeS10.match.findMany({
  where: { saveId: eplSaveId, season: 2, competition: 'league' },
});
eq('s10_new_calendar', newCalendar.length, EPL.teamCount * (EPL.teamCount - 1));
eq('s10_new_calendar_scheduled', newCalendar.every((m) => m.status === 'scheduled'), true);

check(
  's10_board_next_season',
  finalSave?.boardTarget != null && finalSave.boardConfidence >= 0 && finalSave.boardConfidence <= 100,
  `target=${finalSave?.boardTarget} conf=${finalSave?.boardConfidence}`,
);

const marketS10 = await storeS10.transferListing.findMany({
  where: { saveId: eplSaveId, status: 'active' },
});
const marketNonFree = marketS10.filter((l) => l.source !== 'free').length;
const marketFree = marketS10.length - marketNonFree;
check(
  's10_market_regenerated',
  // [D-3c] рефреш сезона гасит ТОЛЬКО не-free лоты (ловушка §10.3 Фазы 3 —
  // free-лоты истёкших контрактов НЕ гасим) — окно рынка применяется к не-free,
  // free-лоты накапливаются отдельно (санити ≤ 120)
  marketNonFree >= MARKET_SIZE_MIN && marketNonFree <= MARKET_SIZE_MAX + 15 && marketFree <= 120,
  `nonFree=${marketNonFree} free=${marketFree}`,
);

const euroMatchesS1 = await storeS10.match.findMany({
  where: { saveId: eplSaveId, season: 1, competition: 'euro' },
});
check('s10_euro_weeks_played', euroMatchesS1.length >= 2 * EURO_ROUNDS, `euroMatches=${euroMatchesS1.length}`);

const euroParticipants = finalSave?.euroParticipants ? JSON.parse(finalSave.euroParticipants) : [];
eq('s10_euro_participants_16', Array.isArray(euroParticipants) ? euroParticipants.length : -1, 16);
eq('s10_euro_next_season', finalSave?.euroSeason, 2);

const guestTeams = await storeS10.team.findMany({ where: { saveId: eplSaveId, isEuroGuest: true } });
// [D-3c] resolveEuroRoster РЕЮЗИТ старых гостей (по leagueCode:name) и НЕ удаляет
// заменённых — гости накапливаются в БД (сервер-паритет). Корректные инварианты:
// (1) все 16 участников сезона 2 существуют; (2) гости среди участников = 16 − свои;
// (3) гостей в БД ≥ гостей среди участников (накопление допустимо)
{
  const guestIds = new Set(guestTeams.map((g) => g.id));
  const teamIdsS10 = new Set(teamsS10.map((t) => t.id));
  const participantsOk = Array.isArray(euroParticipants)
    && euroParticipants.length === 16
    && euroParticipants.every((id: string) => teamIdsS10.has(id) || guestIds.has(id));
  const ownInEuro = Array.isArray(euroParticipants)
    ? euroParticipants.filter((id: string) => teamIdsS10.has(id)).length : -1;
  const guestsInEuro = Array.isArray(euroParticipants)
    ? euroParticipants.filter((id: string) => guestIds.has(id)).length : -1;
  check(
    's10_guest_teams_created',
    participantsOk && ownInEuro + guestsInEuro === 16 && guestTeams.length >= guestsInEuro,
    `guestsDB=${guestTeams.length} ownInEuro=${ownInEuro} guestsInEuro=${guestsInEuro}`,
  );
}

// Изоляция гостей: снапшот — только лиговые команды/таблица/лидеры
const snapshot = await engine.snapshotActive();
eq('s10_snapshot_teams_league_only', snapshot.teams.length, EPL.teamCount);
eq('s10_snapshot_standings_20', snapshot.standings.length, EPL.teamCount);
const leagueTeamIds = new Set(teamsS10.map((t) => t.id));
check(
  's10_snapshot_leaders_no_guests',
  snapshot.leaders.topScorers.every((l) => leagueTeamIds.has(l.teamId))
    && snapshot.leaders.topAssists.every((l) => leagueTeamIds.has(l.teamId)),
  '',
);

const prizeRecords = await storeS10.financeRecord.findMany({
  where: { saveId: eplSaveId, season: 1, category: 'prize' },
});
check('s10_prize_paid', prizeRecords.length >= 1 && prizeRecords.every((r) => r.amount > 0), `prizes=${prizeRecords.length}`);

// Инвариант составов после межсезонья (AI-клубы ≥ 15, гости ≥ 18, клуб игрока ≥ 14)
const playersByTeamS10 = new Map<string, number>();
for (const p of await storeS10.player.findMany({ where: { saveId: eplSaveId, teamId: { not: null } } })) {
  playersByTeamS10.set(p.teamId as string, (playersByTeamS10.get(p.teamId as string) ?? 0) + 1);
}
const allTeamsS10 = await storeS10.team.findMany({ where: { saveId: eplSaveId } });
const floorsOk = allTeamsS10.every((t) => {
  const size = playersByTeamS10.get(t.id) ?? 0;
  if (t.isUserTeam) return size >= 14;
  return t.isEuroGuest ? size >= EURO_GUEST_MIN_SQUAD : size >= CONTRACT_AI_SQUAD_FLOOR;
});
check(
  's10_squad_floors',
  floorsOk,
  `min=${Math.min(...allTeamsS10.map((t) => playersByTeamS10.get(t.id) ?? 0))}`,
);

// ── S11: D-5 «Территория» (§3.1–3.6) ──────────────────────────────────────

console.log('\n== S11: здания — каталог/стартовые уровни/стройка/таймер/финансы/эффекты ==');

// Канон каталога §3.1 (цены L1..L5 и дни постройки — таблица спеки дословно)
// Модуль 5: + 9-е здание «Скаут-центр» (синергия с туманом войны М3)
const SPEC_PRICES: Record<string, number[]> = {
  training: [2_000_000, 3_500_000, 6_100_000, 10_600_000, 18_500_000],
  medical: [3_000_000, 5_000_000, 8_500_000, 14_300_000, 24_000_000],
  fitness: [1_500_000, 2_600_000, 4_600_000, 8_000_000, 14_000_000],
  academy: [2_500_000, 4_400_000, 7_700_000, 13_400_000, 23_500_000],
  hotel: [2_000_000, 3_500_000, 6_100_000, 10_600_000, 18_500_000],
  parking: [800_000, 1_400_000, 2_500_000, 4_300_000, 7_500_000],
  fanshop: [1_000_000, 1_800_000, 3_100_000, 5_400_000, 9_500_000],
  vip: [3_000_000, 5_200_000, 9_100_000, 15_900_000, 27_800_000],
  scoutcenter: [1_800_000, 3_100_000, 5_400_000, 9_500_000, 16_600_000],
};
const SPEC_DAYS: Record<string, number[]> = {
  training: [14, 21, 28, 35, 42], medical: [21, 28, 35, 42, 49],
  fitness: [14, 21, 28, 35, 42], academy: [21, 28, 35, 42, 49],
  hotel: [14, 21, 28, 35, 42], parking: [10, 15, 20, 25, 30],
  fanshop: [10, 15, 20, 25, 30], vip: [21, 28, 35, 42, 49],
  scoutcenter: [14, 21, 28, 35, 42],
};
check(
  's11_catalog_prices',
  BUILDINGS.length === 9
    && BUILDINGS.every((b) => b.prices.length === 5 && b.prices.every((p, i) => p === SPEC_PRICES[b.id][i])),
  JSON.stringify(BUILDINGS.map((b) => b.prices.join(','))),
);
check(
  's11_catalog_days',
  BUILDINGS.every((b) => b.days.length === 5 && b.days.every((d, i) => d === SPEC_DAYS[b.id][i])),
  JSON.stringify(BUILDINGS.map((b) => b.days.join(','))),
);

// Содержание 0.25% × price(L) — контрольный пример спеки: training L5 = 46 250
const s11ParseNull = parseBuildings(null);
const s11ParseBroken = parseBuildings('{oops');
const s11ParseRound = serializeBuildings(parseBuildings('{"training":{"level":3,"upgradeEndsAtDay":137}}'));
check(
  's11_parse_tolerance',
  BUILDING_IDS.every((id) => s11ParseNull[id].level === 0 && s11ParseNull[id].upgradeEndsAtDay === null)
    && BUILDING_IDS.every((id) => s11ParseBroken[id].level === 0)
    && JSON.parse(s11ParseRound).training.level === 3
    && JSON.parse(s11ParseRound).training.upgradeEndsAtDay === 137
    && Object.keys(JSON.parse(s11ParseRound)).join(',') === BUILDING_IDS.join(',')
    && upkeepWeeklyOfBuilding('training', 5) === 46_250
    && upkeepWeeklyTotal(s11ParseNull) === 0,
  `trainingL5upkeep=${upkeepWeeklyOfBuilding('training', 5)}`,
);

// Стартовые уровни по stature (§3.2): топ ≥84 / середняк 74–83 / аутсайдер <74
// Модуль 5: scoutcenter — как fitness/academy/parking (топ 2 · середняк 1 · аутсайдер 0)
const TOP_LEVELS: Record<string, number> = { training: 2, medical: 2, fitness: 2, academy: 2, hotel: 1, parking: 2, fanshop: 2, vip: 2, scoutcenter: 2 };
const MID_LEVELS: Record<string, number> = { training: 1, medical: 1, fitness: 1, academy: 1, hotel: 0, parking: 1, fanshop: 1, vip: 1, scoutcenter: 1 };
const LOW_LEVELS: Record<string, number> = { training: 1, medical: 1, fitness: 0, academy: 0, hotel: 0, parking: 0, fanshop: 0, vip: 0, scoutcenter: 0 };
const levelsOf = (raw: string | null): Record<string, number> => {
  const st = parseBuildings(raw);
  const out: Record<string, number> = {};
  for (const id of BUILDING_IDS) out[id] = st[id].level;
  return out;
};
const sameMap = (a: Record<string, number>, b: Record<string, number>): boolean =>
  Object.keys(b).every((k) => a[k] === b[k]);

const topClubIdx = EPL.clubs.findIndex((c) => c.str >= 84);
const midClubIdx = EPL.clubs.findIndex((c) => c.str >= 74 && c.str < 84);
const lowClubIdx = EPL.clubs.findIndex((c) => c.str < 74);
check('s11_tiers_present', topClubIdx >= 0 && midClubIdx >= 0 && lowClubIdx >= 0, `top=${topClubIdx} mid=${midClubIdx} low=${lowClubIdx}`);

const careerTop = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: topClubIdx, managerName: 'Топ Клуб', seed: 4111, now: NOW,
});
const storeTop = engine.requireStore();
const topRow = await storeTop.gameSave.findUnique({ where: { id: careerTop.saveId } });
const topTeam = await storeTop.team.findUnique({ where: { id: topRow?.teamId ?? '' } });
check(
  's11_start_levels_top',
  topTeam !== null && sameMap(levelsOf(topTeam.buildings), TOP_LEVELS),
  `levels=${JSON.stringify(levelsOf(topTeam?.buildings ?? null))}`,
);

// ИИ-клубы — те же стартовые уровни по своей силе (симметрия §3.2)
const topTeamsAll = await storeTop.team.findMany({ where: { saveId: careerTop.saveId, isEuroGuest: false } });
const aiLevelsOk = topTeamsAll.every((t) => {
  const st = parseBuildings(t.buildings);
  const expected = startLevelsByStrength(t.strength);
  return BUILDING_IDS.every((id) => st[id].level === expected[id].level && st[id].upgradeEndsAtDay === null);
});
check('s11_ai_teams_start_levels', topTeamsAll.length === EPL.teamCount && aiLevelsOk, `teams=${topTeamsAll.length}`);

// BuildingsDTO в снапшоте (§3.6 + М5): 9 карточек, всё посчитано
const snapTop = await engine.snapshotActive();
const dtoOk = snapTop.myTeam.buildings.length === 9
  && snapTop.myTeam.buildings.every((c) => c.id === BUILDINGS[BUILDINGS.findIndex((b) => b.id === c.id)]?.id)
  && snapTop.myTeam.buildings.every((c) => {
    const spec = BUILDINGS.find((b) => b.id === c.id)!;
    const next = c.level < 5 ? c.level + 1 : null;
    return c.name === spec.name
      && c.priceNext === (next !== null ? spec.prices[next - 1] : null)
      && c.daysNext === (next !== null ? spec.days[next - 1] : null)
      && c.upkeepWeekly === (c.level > 0 ? Math.round(spec.prices[c.level - 1] * 0.0025) : 0);
  });
check(
  's11_snapshot_buildings_dto',
  dtoOk && snapTop.myTeam.buildings.map((c) => c.id).join(',') === BUILDING_IDS.join(','),
  `cards=${snapTop.myTeam.buildings.map((c) => `${c.id}:${c.level}`).join(' ')}`,
);

// Ошибки POST /buildings: неизвестное здание → 404
let s11Unknown: string | null = null;
try {
  await engineDispatch('POST', '/buildings', { saveId: careerTop.saveId, buildingId: 'stadium' });
} catch (e) {
  s11Unknown = e instanceof ApiGameError ? e.code : `unexpected:${String(e)}`;
}
eq('s11_buy_unknown_404', s11Unknown, 'BUILDING_NOT_FOUND');

// Недостаточно баланса → 402 (оплата с balance, НЕ с бюджета; деньги не списываются)
const careerMid = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: midClubIdx, managerName: 'Мид Клуб', seed: 4222, now: NOW,
});
const storeMid = engine.requireStore();
const midRow = await storeMid.gameSave.findUnique({ where: { id: careerMid.saveId } });
const midTeam = await storeMid.team.findUnique({ where: { id: midRow?.teamId ?? '' } });
check(
  's11_start_levels_mid',
  midTeam !== null && sameMap(levelsOf(midTeam.buildings), MID_LEVELS),
  `levels=${JSON.stringify(levelsOf(midTeam?.buildings ?? null))}`,
);
await storeMid.gameSave.update({ where: { id: careerMid.saveId }, data: { balance: 1_000_000 } });
let s11Funds: string | null = null;
try {
  // medical L1→L2 = 5 000 000 > 1 000 000 (баланс НЕ бюджет трансферов)
  await engineDispatch('POST', '/buildings', { saveId: careerMid.saveId, buildingId: 'medical' });
} catch (e) {
  s11Funds = e instanceof ApiGameError ? e.code : `unexpected:${String(e)}`;
}
const midAfter = await storeMid.gameSave.findUnique({ where: { id: careerMid.saveId } });
const midConstructions = await storeMid.financeRecord.findMany({
  where: { saveId: careerMid.saveId, category: 'construction' },
});
check(
  's11_buy_insufficient_402',
  s11Funds === 'INSUFFICIENT_FUNDS' && midAfter?.balance === 1_000_000 && midConstructions.length === 0,
  `code=${s11Funds} balance=${midAfter?.balance}`,
);

// Карьера аутсайдера: happy path покупки + таймер (parking L1 = 10 дней = 2 недели)
const careerLow = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: lowClubIdx, managerName: 'Лоу Клуб', seed: 4333, now: NOW,
});
const storeLow = engine.requireStore();
const lowRow = await storeLow.gameSave.findUnique({ where: { id: careerLow.saveId } });
const lowTeamId = lowRow?.teamId ?? '';
const lowTeam = await storeLow.team.findUnique({ where: { id: lowTeamId } });
check(
  's11_start_levels_low',
  lowTeam !== null && sameMap(levelsOf(lowTeam.buildings), LOW_LEVELS),
  `levels=${JSON.stringify(levelsOf(lowTeam?.buildings ?? null))}`,
);
const lowBalanceBefore = lowRow?.balance ?? 0;

const buyRes = (await engineDispatch('POST', '/buildings', {
  saveId: careerLow.saveId, buildingId: 'parking',
})) as { ok: boolean; snapshot: { myTeam: { buildings: { id: string; level: number; upgradeEndsAtDay: number | null; priceNext: number | null; daysNext: number | null }[] }; save: { balance: number } } };
const parkingCard = buyRes.snapshot.myTeam.buildings.find((b) => b.id === 'parking');
const lowSaveAfterBuy = await storeLow.gameSave.findUnique({ where: { id: careerLow.saveId } });
check(
  's11_buy_ok_timer_balance',
  buyRes.ok === true
    && lowSaveAfterBuy?.balance === lowBalanceBefore - 800_000
    && parkingCard?.level === 0
    && parkingCard?.upgradeEndsAtDay === 10
    && parkingCard?.priceNext === 800_000
    && parkingCard?.daysNext === 10
    && absoluteDayOf(1, 1, eplPlan.totalWeeks) === 0,
  `balance=${lowSaveAfterBuy?.balance} (было ${lowBalanceBefore}) ends=${parkingCard?.upgradeEndsAtDay}`,
);

const lowConstructions = await storeLow.financeRecord.findMany({
  where: { saveId: careerLow.saveId, category: 'construction' },
});
check(
  's11_construction_finance_record',
  lowConstructions.length === 1
    && lowConstructions[0].kind === 'expense'
    && lowConstructions[0].amount === 800_000
    && lowConstructions[0].description === 'Стройка: Парковка стадиона ур. 1',
  `desc=${lowConstructions[0]?.description}`,
);

// Одна активная стройка на клуб → 409 (деньги не списываются повторно)
let s11InProgress: string | null = null;
try {
  await engineDispatch('POST', '/buildings', { saveId: careerLow.saveId, buildingId: 'fanshop' });
} catch (e) {
  s11InProgress = e instanceof ApiGameError ? e.code : `unexpected:${String(e)}`;
}
const lowSaveAfterSecond = await storeLow.gameSave.findUnique({ where: { id: careerLow.saveId } });
eq('s11_in_progress_blocks', s11InProgress, 'BUILDING_IN_PROGRESS');
check(
  's11_in_progress_no_double_charge',
  lowSaveAfterSecond?.balance === lowBalanceBefore - 800_000,
  `balance=${lowSaveAfterSecond?.balance}`,
);

// Таймер: неделя 1 (+7 дней < 10) — стройка не завершена
await engine.simulateActiveWeek();
const lowTeamW1 = await storeLow.team.findUnique({ where: { id: lowTeamId } });
const parkingW1 = parseBuildings(lowTeamW1?.buildings ?? null).parking;
check(
  's11_timer_week1_pending',
  parkingW1.level === 0 && parkingW1.upgradeEndsAtDay === 10,
  `level=${parkingW1.level} ends=${parkingW1.upgradeEndsAtDay}`,
);

// Неделя 2 (+14 ≥ 10) — уровень 1, таймер null, новость «Открыт …» (§3.3)
await engine.simulateActiveWeek();
const lowTeamW2 = await storeLow.team.findUnique({ where: { id: lowTeamId } });
const parkingW2 = parseBuildings(lowTeamW2?.buildings ?? null).parking;
const openNews = await storeLow.newsItem.findMany({
  where: { saveId: careerLow.saveId, season: 1, week: 2, type: 'info' },
});
check(
  's11_timer_completion_news',
  parkingW2.level === 1 && parkingW2.upgradeEndsAtDay === null
    && openNews.some((n) => n.message === 'Открыт Парковка стадиона — уровень 1!'),
  `level=${parkingW2.level} news=${openNews.map((n) => n.message).join(' | ')}`,
);

// Содержание после достройки: 0.25% × (training L1 2M + medical L1 3M + parking L1 0.8M) = 14 500
const lowFinW2 = await storeLow.financeRecord.findMany({
  where: { saveId: careerLow.saveId, season: 1, week: 2 },
});
const upkeepRecW2 = lowFinW2.find((r) => r.category === 'building');
const merchRecW2 = lowFinW2.find((r) => r.category === 'merch');
check(
  's11_upkeep_after_completion',
  upkeepRecW2 !== undefined && upkeepRecW2.kind === 'expense' && upkeepRecW2.amount === 14_500
    && upkeepRecW2.description === 'Содержание инфраструктуры' && merchRecW2 === undefined,
  `upkeep=${upkeepRecW2?.amount} merch=${merchRecW2?.amount ?? 'нет'}`,
);

// MAX_LEVEL → 409 (тренировочный комплекс выставлен на L5 напрямую)
const lowStateMax = parseBuildings(lowTeamW2?.buildings ?? null);
lowStateMax.training.level = 5;
await storeLow.team.update({
  where: { id: lowTeamId },
  data: { buildings: serializeBuildings(lowStateMax) },
});
let s11Max: string | null = null;
try {
  await engineDispatch('POST', '/buildings', { saveId: careerLow.saveId, buildingId: 'training' });
} catch (e) {
  s11Max = e instanceof ApiGameError ? e.code : `unexpected:${String(e)}`;
}
eq('s11_buy_max_level_409', s11Max, 'BUILDING_MAX_LEVEL');

// Финансы топ-клуба (стартовые уровни 2/2/2/2/1/2/2/2): merch 60К/нед,
// содержание 64 750/нед (§3.2 пример), VIP 320К за домашний матч
{
  await engine.loadSlot(careerTop.slot);
  const storeT = engine.requireStore();
  const topId = careerTop.saveId;
  let vipSeen = false;
  for (let w = 1; w <= 6 && !vipSeen; w++) {
    await engine.simulateActiveWeek();
    const recs = await storeT.financeRecord.findMany({ where: { saveId: topId, season: 1, week: w } });
    const merch = recs.filter((r) => r.category === 'merch');
    const upkeep = recs.filter((r) => r.category === 'building');
    const vip = recs.filter((r) => r.category === 'vip');
    if (w === 1) {
      check(
        's11_weekly_merch_upkeep_top',
        merch.length === 1 && merch[0].amount === 60_000 && merch[0].kind === 'income'
          // Модуль 5: + скаут-центр L2 топ-клуба → содержание 7 750 (64 750 + 7 750)
          && upkeep.length === 1 && upkeep[0].amount === 72_500 && upkeep[0].kind === 'expense',
        `merch=${merch[0]?.amount} upkeep=${upkeep[0]?.amount}`,
      );
    }
    if (vip.length > 0) {
      vipSeen = vip.every((r) => r.amount === 320_000 && r.kind === 'income');
    }
  }
  check('s11_vip_home_income_top', vipSeen, 'VIP-запись 320 000 за домашний матч не найдена');
}

// ── Юнит-проверки эффектов (§3.5): множители чистых функций ──

// training: xpMult ×1.2 — прирост опыта больше при том же броске rng
{
  const mk = (): PlayerLike => ({
    id: 'xpT', teamId: 't', firstName: 'И', lastName: 'Т', nationality: 'RU', position: 'ST',
    shirtNumber: 9, age: 20, potential: 90, ovr: 60, finishing: 60, passing: 60, dribbling: 60,
    crossing: 60, tackling: 50, marking: 50, positioning: 55, heading: 55, pace: 70, stamina: 70,
    strength: 65, aggression: 50, reflexes: 50, rushingOut: 50, kicking: 50, morale: 60,
    vision: 60, decisions: 60, leadership: 50, acceleration: 68, jumping: 55, handling: 50,
    condition: 100, injuryWeeks: 0, value: 0, salary: 0, goals: 0, assists: 0, apps: 0,
    yellowCards: 0, redCards: 0, trainingXp: null, cleanSheets: 0, cupGoals: 0, cupAssists: 0,
    contractUntil: 3, preContractTeamId: null, ratingSum: 0, ratingApps: 0, isAcademy: false,
    euroGoals: 0, euroAssists: 0,
  });
  const a = mk();
  const b = mk();
  applyWeeklyTraining(mulberry32(42), 'physical', 'normal', [a]);
  applyWeeklyTraining(mulberry32(42), 'physical', 'normal', [b], { xpMult: 1.2 });
  const sum = (p: PlayerLike): number =>
    Object.values(parseTrainingXp(p.trainingXp)).reduce((s, v) => s + v, 0);
  check(
    's11_train_xp_mult',
    sum(b) > sum(a) && Math.abs(sum(b) - sum(a) * 1.2) < 0.01,
    `base=${sum(a).toFixed(3)} mult=${sum(b).toFixed(3)}`,
  );
}

// medical: injuryDurMult — выбранные недели травмы × mult (round, min 1)
{
  const mk = (id: string): PlayerLike => ({
    id, teamId: 't', firstName: 'И', lastName: 'Б', nationality: 'RU', position: 'ST',
    shirtNumber: 9, age: 24, potential: 80, ovr: 60, finishing: 60, passing: 60, dribbling: 60,
    crossing: 60, tackling: 50, marking: 50, positioning: 55, heading: 55, pace: 70, stamina: 70,
    strength: 65, aggression: 50, reflexes: 50, rushingOut: 50, kicking: 50, morale: 60,
    vision: 60, decisions: 60, leadership: 50, acceleration: 68, jumping: 55, handling: 50,
    condition: 100, injuryWeeks: 0, value: 0, salary: 0, goals: 0, assists: 0, apps: 0,
    yellowCards: 0, redCards: 0, trainingXp: null, cleanSheets: 0, cupGoals: 0, cupAssists: 0,
    contractUntil: 3, preContractTeamId: null, ratingSum: 0, ratingApps: 0, isAcademy: false,
    euroGoals: 0, euroAssists: 0,
  });
  const p5 = mk('dur5');
  applyMatchEffects(
    { players: [p5], starterIds: new Set(['dur5']), benchIds: new Set(), events: [], outcome: 'D', tempo: 'medium', pressing: 'medium' },
    new Map([['dur5', 5]]),
    () => 0.5,
    { injuryDurMult: 0.5 },
  );
  const p2 = mk('dur2');
  applyMatchEffects(
    { players: [p2], starterIds: new Set(['dur2']), benchIds: new Set(), events: [], outcome: 'D', tempo: 'medium', pressing: 'medium' },
    new Map([['dur2', 2]]),
    () => 0.5,
    { injuryDurMult: 0.4 },
  );
  const pPlain = mk('plain');
  applyMatchEffects(
    { players: [pPlain], starterIds: new Set(['plain']), benchIds: new Set(), events: [], outcome: 'D', tempo: 'medium', pressing: 'medium' },
    new Map([['plain', 5]]),
    () => 0.5,
  );
  check(
    's11_injury_dur_mult',
    p5.injuryWeeks === 3 && p2.injuryWeeks === 1 && pPlain.injuryWeeks === 5,
    `5×0.5=${p5.injuryWeeks} 2×0.4=${p2.injuryWeeks} без=${pPlain.injuryWeeks}`,
  );
}

// fitness/hotel: applyWeeklyRecovery +8 + bonus (clamp 30..100)
{
  const mk = (condition: number): PlayerLike => ({
    id: 'rec', teamId: 't', firstName: 'И', lastName: 'В', nationality: 'RU', position: 'GK',
    shirtNumber: 1, age: 28, potential: 70, ovr: 60, finishing: 50, passing: 50, dribbling: 50,
    crossing: 50, tackling: 50, marking: 50, positioning: 50, heading: 50, pace: 50, stamina: 50,
    strength: 50, aggression: 50, reflexes: 60, rushingOut: 60, kicking: 60, morale: 60,
    vision: 50, decisions: 55, leadership: 60, acceleration: 50, jumping: 55, handling: 60,
    condition, injuryWeeks: 0, value: 0, salary: 0, goals: 0, assists: 0, apps: 0,
    yellowCards: 0, redCards: 0, trainingXp: null, cleanSheets: 0, cupGoals: 0, cupAssists: 0,
    contractUntil: 3, preContractTeamId: null, ratingSum: 0, ratingApps: 0, isAcademy: false,
    euroGoals: 0, euroAssists: 0,
  });
  const base = mk(50);
  applyWeeklyRecovery([base]);
  const withBonus = mk(50);
  applyWeeklyRecovery([withBonus], { bonus: 2.4 });
  const clamped = mk(99);
  applyWeeklyRecovery([clamped], { bonus: 2 });
  check(
    's11_recovery_bonus',
    base.condition === 58 && Math.abs(withBonus.condition - 60.4) < 1e-9 && clamped.condition === 100,
    `base=${base.condition} bonus=${withBonus.condition} clamp=${clamped.condition}`,
  );
}

// parking/vip: computeWeekFinance — билеты × mult, VIP-доплата (категория vip)
{
  const args: {
    players: PlayerLike[];
    place: number;
    teamCount: number;
    isHomeMatch: boolean;
    stadiumCapacity: number;
  } = {
    players: [],
    place: 1,
    teamCount: 20,
    isHomeMatch: true,
    stadiumCapacity: 60_000,
  };
  const base = 60_000 * attendanceRate(1, 20, mulberry32(7)) * 30;
  const f1 = computeWeekFinance({ ...args, rng: mulberry32(7) });
  const f2 = computeWeekFinance({ ...args, rng: mulberry32(7), ticketMult: 1.075 });
  const f3 = computeWeekFinance({ ...args, rng: mulberry32(7), vipPerMatch: 800_000 });
  const vipRec = f3.records.find((r) => r.category === 'vip');
  check(
    's11_finance_ticket_vip',
    f1.tickets === Math.round(base)
      && f2.tickets === Math.round(base * 1.075)
      && vipRec !== undefined && vipRec.amount === 800_000 && vipRec.kind === 'income'
      && f3.net === f3.sponsor + f3.tickets + 800_000 - f3.wages,
    `t1=${f1.tickets} t2=${f2.tickets} vip=${vipRec?.amount ?? 'нет'}`,
  );
}

// academy: sizeBonus (+2 игрока) и potBonus (+4 к границам, кап 93)
{
  const pool = poolContextOf(EPL);
  const rngSquad = mulberry32(99);
  const squad = Array.from({ length: 3 }, () => generatePlayer(rngSquad, 55, 'MC', {
    fixedAge: 25, contractUntil: 3, pool,
  }));
  const run = (opts: { sizeBonus?: number; potBonus?: number }) => runIntakeForClub({
    rng: mulberry32(555), season: 1, team: { id: 't', strength: 60 }, squad, pool, ...opts,
  });
  const base = run({});
  const withSize = run({ sizeBonus: 2 });
  const withPot = run({ potBonus: 4 });
  const potOk = withPot.players.length === base.players.length
    && withPot.players.every((p, i) => p.potential >= base.players[i].potential)
    && withPot.players.reduce((s, p) => s + p.potential, 0) > base.players.reduce((s, p) => s + p.potential, 0);
  check(
    's11_academy_size_pot_bonus',
    withSize.players.length === base.players.length + 2 && potOk,
    `size=${base.players.length}+2=${withSize.players.length} potSum=${base.players.reduce((s, p) => s + p.potential, 0)}→${withPot.players.reduce((s, p) => s + p.potential, 0)}`,
  );
}

// medical (матч): medRiskMult 0 — травм нет ни в одном из 300 сидов; без множителя — есть
{
  await engine.loadSlot(careerMid.slot);
  const storeM = engine.requireStore();
  const midRowB = await storeM.gameSave.findUnique({ where: { id: careerMid.saveId } });
  const teamsM = await storeM.team.findMany({ where: { saveId: careerMid.saveId, isEuroGuest: false } });
  const homeT = teamsM.find((t) => t.id === midRowB?.teamId);
  const awayT = teamsM.find((t) => t.id !== homeT?.id);
  if (!homeT || !awayT) throw new Error('engine-smoke S11: команды mid-карьеры не найдены');
  const squadOf = async (teamId: string): Promise<PlayerLike[]> =>
    (await storeM.player.findMany({ where: { saveId: careerMid.saveId, teamId } })) as unknown as PlayerLike[];
  const squadH = await squadOf(homeT.id);
  const squadA = await squadOf(awayT.id);
  const inputOf = (team: typeof homeT, squad: PlayerLike[], medRiskMult?: number): MatchTeamInput => {
    const auto = autoLineup(squad, '4-4-2');
    return {
      teamId: team.id,
      players: squad,
      formation: '4-4-2',
      mentality: 'balanced',
      tempo: 'medium',
      pressing: 'medium',
      defLine: 'medium',
      playStyle: 'balanced',
      lineup: auto.lineup,
      name: team.name,
      bench: auto.bench,
      ...(medRiskMult !== undefined ? { medRiskMult } : {}),
    };
  };
  let withMult = 0;
  let baseline = 0;
  for (let s = 0; s < 300; s++) {
    const r1 = simulateMatch(mulberry32(1000 + s), inputOf(homeT, squadH, 0), inputOf(awayT, squadA));
    withMult += r1.injuries.filter((i) => i.teamId === homeT.id).length;
    const r2 = simulateMatch(mulberry32(1000 + s), inputOf(homeT, squadH), inputOf(awayT, squadA));
    baseline += r2.injuries.filter((i) => i.teamId === homeT.id).length;
  }
  check(
    's11_med_risk_mult_match',
    withMult === 0 && baseline > 0,
    `medRiskMult=0: травм ${withMult}; без множителя: ${baseline} (ожидание ~12 на 300)`,
  );
}

// ── S12: D-6 «Тренер» — кошелёк/активы/престиж/семья (§4.1–4.7) ────────────

console.log('\n== S12: D-6 «Тренер» — личная жизнь менеджера ==');

// Каталог 7 активов §4.2 дословно + правила продажи (70 % / −ceil(престиж/2))
{
  const SPEC: Record<string, [string, string, number, number, number]> = {
    re_flat: ['Недвижимость', 'Квартира в городе', 250_000, 30, 1_000],
    re_house: ['Недвижимость', 'Загородный дом', 1_500_000, 80, 4_000],
    re_villa: ['Недвижимость', 'Вилла на побережье', 6_000_000, 180, 12_000],
    car_compact: ['Авто', 'Компакт-класс', 40_000, 10, 200],
    car_sport: ['Авто', 'Спорткар', 200_000, 40, 1_000],
    car_lux: ['Авто', 'Представительский седан', 500_000, 80, 2_500],
    yacht: ['Яхта', 'Яхта', 3_000_000, 150, 8_000],
  };
  const CAT: Record<string, 'realty' | 'auto' | 'yacht'> = {
    Недвижимость: 'realty', Авто: 'auto', Яхта: 'yacht',
  };
  check(
    's12_catalog_assets',
    ASSETS.length === 7 && ASSETS.every((a) => {
      const s = SPEC[a.id];
      return s !== undefined && a.category === CAT[s[0]] && a.name === s[1]
        && a.price === s[2] && a.prestige === s[3] && a.upkeep === s[4];
    }),
    JSON.stringify(ASSETS.map((a) => `${a.id}:${a.price}/${a.prestige}/${a.upkeep}`)),
  );
  check(
    's12_sell_rules',
    ASSETS.every((a) => sellPriceOf(a) === Math.round(a.price * 0.7)
      && sellPrestigeOf(a) === Math.ceil(a.prestige / 2))
      && sellPriceOf(ASSETS[0]) === 175_000 && sellPrestigeOf(ASSETS[2]) === 90,
    `flat=${sellPriceOf(ASSETS[0])} villaPrestige=${sellPrestigeOf(ASSETS[2])}`,
  );
}

// Парсер (толерантность) + канонический roundtrip (ключи §4.1)
{
  const nullParsed = parseManager(null, 70);
  const broken = parseManager('{"oops', 70);
  const fallback = parseManager('{"age":50}', 70);
  const full: ManagerState = {
    age: 47, wallet: 123_456, salary: 45_000, prestige: 555,
    assets: ['re_flat', 'yacht'],
    family: {
      marriedAtWeek: 30, spouseName: 'Елена',
      child: { bornAtWeek: 70, name: 'Артём', gender: 'м', age: 3, joinedAcademyPlayerId: null },
    },
  };
  const round = parseManager(serializeManager(full), 70);
  const canonicalKeys = Object.keys(JSON.parse(serializeManager(full))).join(',');
  check(
    's12_parse_serialize',
    nullParsed === null && broken === null
      && fallback !== null && fallback.age === 50 && fallback.wallet === MANAGER_WALLET_START
      && fallback.prestige === MANAGER_PRESTIGE_START && fallback.salary === MANAGER_SALARY_BY_TIER.low
      && fallback.assets.length === 0 && fallback.family.child === null
      && canonicalKeys === 'age,wallet,salary,prestige,assets,family'
      && round !== null && round.age === 47 && round.wallet === 123_456 && round.prestige === 555
      && round.assets.join(',') === 're_flat,yacht'
      && round.family.marriedAtWeek === 30 && round.family.child?.name === 'Артём'
      && round.family.child?.age === 3 && round.family.child?.joinedAcademyPlayerId === null,
    `keys=${canonicalKeys}`,
  );
}

// Юниты эффектов престижа (§4.3 — чистые функции, пороги 400/600/700/750)
{
  check(
    's12_prestige_effects',
    contractsPrestigeMult(399) === 1.05 && contractsPrestigeMult(400) === 1
      && contractsPrestigeMult(599) === 1 && contractsPrestigeMult(600) === 0.95
      && managerMarketPrice(750, 1_000_000, 60) === 950_000
      && managerMarketPrice(749, 1_000_000, 60) === 1_000_000
      && managerMarketPrice(599, 1_000_000, 85) === 1_100_000
      && managerMarketPrice(599, 1_000_000, 79) === 1_000_000
      && managerMarketPrice(600, 1_000_000, 85) === 1_000_000
      && managerMarketPrice(780, 1_234_000, 60) === 1_172_000 // floor до €1 000
      && boardWarnBelowOf(699) === 30 && boardWarnBelowOf(700) === 25
      && prestigeLabelOf(399) === 'Скромный авторитет'
      && prestigeLabelOf(400) === 'Уважаемый тренер'
      && prestigeLabelOf(600) === 'Звёздный тренер'
      && clampPrestige(-5) === 0 && clampPrestige(1200) === 1000
      && absoluteWeekOf(2, 5, 43) === 48,
    'пороги контрактов/рынка/правления/подписей',
  );
}

// Карьера M (середняк EPL): зарплата по stature через GET /manager (§4.1)
const MGR_NAME = 'Игорь Северов';
const careerM = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: midClubIdx, managerName: MGR_NAME, seed: 6444, now: NOW,
});
{
  const mgrTop = await engineDispatch('GET', '/manager', { saveId: careerTop.saveId }) as ManagerResponse;
  const mgrLow = await engineDispatch('GET', '/manager', { saveId: careerLow.saveId }) as ManagerResponse;
  check(
    's12_salary_by_tier',
    mgrTop.ok === true && mgrTop.manager.salary === MANAGER_SALARY_BY_TIER.top
      && mgrLow.ok === true && mgrLow.manager.salary === MANAGER_SALARY_BY_TIER.low,
    `top=${mgrTop.manager.salary} low=${mgrLow.manager.salary}`,
  );
}
// Слот M — активный до конца секции (топ/лоу выше переключали слоты)
await engine.loadSlot(careerM.slot);
const storeM = engine.requireStore();

const rowM0 = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
const teamMId = rowM0?.teamId ?? '';
const teamMRow = await storeM.team.findUnique({ where: { id: teamMId } });
const mgrM0 = parseManager(rowM0?.manager ?? null, teamMRow?.strength ?? 60);
check(
  's12_start_profile',
  mgrM0 !== null
    && mgrM0.age === MANAGER_AGE_START && mgrM0.wallet === MANAGER_WALLET_START
    && mgrM0.salary === MANAGER_SALARY_BY_TIER.mid && mgrM0.prestige === MANAGER_PRESTIGE_START
    && mgrM0.assets.length === 0
    && mgrM0.family.marriedAtWeek === null && mgrM0.family.spouseName === null
    && mgrM0.family.child === null
    && teamMRow !== null && teamMRow.strength >= 74 && teamMRow.strength < 84,
  `salary=${mgrM0?.salary} prestige×10=${mgrM0?.prestige}`,
);

// GET /manager DTO (§4.6): престиж /10 c 1 знаком, каталог+владение, эффекты
{
  const dto0 = await engineDispatch('GET', '/manager', { saveId: careerM.saveId }) as ManagerResponse;
  const assets0 = dto0.manager.assets;
  check(
    's12_start_dto',
    dto0.ok === true && dto0.manager.name === MGR_NAME && dto0.manager.clubName === teamMRow?.name
      && dto0.manager.season === 1 && dto0.manager.age === 45
      && dto0.manager.wallet === 50_000 && dto0.manager.salary === 45_000
      && dto0.manager.prestige === 40 && dto0.manager.prestigeLabel === 'Уважаемый тренер'
      && dto0.manager.family === null && dto0.manager.netWeekly === 45_000
      && dto0.manager.effects.contractsDemandMult === 1
      && dto0.manager.effects.marketDiscount === false
      && dto0.manager.effects.marketStarPremium === true
      && dto0.manager.effects.boardWarnBelow === 30
      && assets0.length === 7
      && assets0.every((a) => a.owned === false && a.sellPrice === Math.round(a.price * 0.7))
      && (assets0.find((a) => a.id === 'yacht')?.prestige ?? 0) === 150,
    `prestige=${dto0.manager.prestige} assets=${assets0.length}`,
  );
}

// ── Хелперы S12: точечные патчи сейва/менеджера и реплика еженедельных дельт ──

type SavePatch = Partial<Pick<
  GameSaveRecord,
  'week' | 'season' | 'balance' | 'boardConfidence' | 'cupRound' | 'cupAliveTeamIds' | 'manager'
>>;
const patchSaveM = (data: SavePatch): Promise<unknown> =>
  storeM.gameSave.update({ where: { id: careerM.saveId }, data });
const readManagerM = async (): Promise<ManagerState | null> =>
  parseManager(
    (await storeM.gameSave.findUnique({ where: { id: careerM.saveId } }))?.manager ?? null,
    teamMRow?.strength ?? 60,
  );
const emptyFamily = (): ManagerFamilyState => ({ marriedAtWeek: null, spouseName: null, child: null });
const patchManagerM = async (patch: {
  wallet?: number; prestige?: number; assets?: ManagerState['assets']; family?: ManagerFamilyState;
}): Promise<void> => {
  const cur = await readManagerM();
  if (!cur) throw new Error('S12: ManagerState отсутствует');
  await patchSaveM({
    manager: serializeManager({
      ...cur,
      ...(patch.wallet !== undefined ? { wallet: patch.wallet } : {}),
      ...(patch.prestige !== undefined ? { prestige: patch.prestige } : {}),
      ...(patch.assets !== undefined ? { assets: patch.assets } : {}),
      ...(patch.family !== undefined ? { family: patch.family } : {}),
    }),
  });
};

/**
 * Реплика еженедельной матчевой дельты престижа (§4.3): победа недели +1,
 * разгром (≥ 3) −2 — по сыгранным матчам клуба игрока на этой неделе.
 */
const userMatchPrestigeDelta = async (season: number, week: number): Promise<number> => {
  const rows = await storeM.match.findMany({
    where: { saveId: careerM.saveId, season, week, status: 'played' },
  });
  const mine = rows.filter((m) => m.homeTeamId === teamMId || m.awayTeamId === teamMId);
  if (mine.length === 0) return 0;
  let wonAny = false;
  let heavy = false;
  for (const m of mine) {
    const isHome = m.homeTeamId === teamMId;
    const my = isHome ? m.homeGoals : m.awayGoals;
    const opp = isHome ? m.awayGoals : m.homeGoals;
    if (my === null || opp === null) continue;
    const won = m.winnerTeamId !== null ? m.winnerTeamId === teamMId : my > opp;
    if (won) wonAny = true;
    if (!won && opp - my >= 3) heavy = true;
  }
  return (wonAny ? 1 : 0) + (heavy ? -2 : 0);
};

const expectCode = async (name: string, code: string, run: () => Promise<unknown>): Promise<void> => {
  let got: string | null = null;
  try {
    await run();
  } catch (e) {
    got = e instanceof ApiGameError ? e.code : `unexpected:${String(e)}`;
  }
  eq(name, got, code);
};

// ── Зарплата в финансах: 3 недели coach_wages + накопление кошелька (§4.1) ──
for (let w = 1; w <= 3; w++) await engine.simulateActiveWeek();
{
  const wages3 = await storeM.financeRecord.findMany({
    where: { saveId: careerM.saveId, category: 'coach_wages' },
  });
  check(
    's12_coach_wages_finance',
    wages3.length === 3
      && wages3.every((r) => r.kind === 'expense' && r.amount === 45_000 && r.description === 'Зарплата тренера')
      && wages3.map((r) => r.week).sort((a, b) => a - b).join(',') === '1,2,3',
    `recs=${wages3.map((r) => `${r.week}:${r.amount}`).join(' ')}`,
  );
  const mgrM3 = await readManagerM();
  eq('s12_wallet_accumulation', mgrM3?.wallet, 185_000);
}

// ── POST /manager/asset: покупка/продажа/ошибки (§4.2/§4.6) ──
{
  // База престижа — фактическая (недели 1–3 уже дали еженедельные дельты §4.3)
  const basePrestige = (await readManagerM())?.prestige ?? 0;
  const buyCar = await engineDispatch('POST', '/manager/asset', {
    saveId: careerM.saveId, assetId: 'car_compact', action: 'buy',
  }) as ManagerResponse;
  const newsBuy = await storeM.newsItem.findMany({
    where: { saveId: careerM.saveId, type: 'manager' },
  });
  check(
    's12_buy_asset',
    buyCar.ok === true && buyCar.manager.wallet === 145_000
      && buyCar.manager.prestige === Math.round(basePrestige + 10) / 10
      && (buyCar.manager.assets.find((a) => a.id === 'car_compact')?.owned ?? false)
      && (await readManagerM())?.wallet === 145_000
      && (await readManagerM())?.prestige === basePrestige + 10
      && newsBuy.some((n) => n.message === `${MGR_NAME} приобрёл Компакт-класс`),
    `wallet=${buyCar.manager.wallet} prestige=${buyCar.manager.prestige}`,
  );

  await expectCode('s12_buy_twice_409', 'ASSET_ALREADY_OWNED', () => engineDispatch('POST', '/manager/asset', {
    saveId: careerM.saveId, assetId: 'car_compact', action: 'buy',
  }));

  let code402: string | null = null;
  try {
    await engineDispatch('POST', '/manager/asset', {
      saveId: careerM.saveId, assetId: 're_villa', action: 'buy',
    });
  } catch (e) {
    code402 = e instanceof ApiGameError ? e.code : `unexpected:${String(e)}`;
  }
  const after402 = await readManagerM();
  check(
    's12_buy_insufficient_402',
    code402 === 'INSUFFICIENT_WALLET' && after402?.wallet === 145_000
      && after402?.prestige === basePrestige + 10 && after402?.assets.length === 1,
    `code=${code402} wallet=${after402?.wallet} prestige=${after402?.prestige}`,
  );
}

// Неделя 4: кошелёк += зарплата − содержание актива (200), netWeekly в DTO
{
  const beforeWeek = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
  const w4 = beforeWeek?.week ?? 4;
  await engine.simulateActiveWeek();
  const mgrM4 = await readManagerM();
  const dtoCar = await engineDispatch('GET', '/manager', { saveId: careerM.saveId }) as ManagerResponse;
  const wages4 = await storeM.financeRecord.findMany({
    where: { saveId: careerM.saveId, season: 1, week: w4, category: 'coach_wages' },
  });
  check(
    's12_upkeep_week',
    mgrM4?.wallet === 189_800 && dtoCar.manager.netWeekly === 44_800 && wages4.length === 1,
    `wallet=${mgrM4?.wallet} netWeekly=${dtoCar.manager.netWeekly}`,
  );
}

// Продажа: +70 % цены, престиж −ceil(начислено/2), новость «Продано: …»
{
  // База — фактический престиж ПОСЛЕ недели 4 (матчевые дельты уже в счёте)
  const preSellPrestige = (await readManagerM())?.prestige ?? 0;
  const sellCar = await engineDispatch('POST', '/manager/asset', {
    saveId: careerM.saveId, assetId: 'car_compact', action: 'sell',
  }) as ManagerResponse;
  const mgrSell = await readManagerM();
  const newsSell = await storeM.newsItem.findMany({
    where: { saveId: careerM.saveId, type: 'manager' },
  });
  check(
    's12_sell_asset',
    sellCar.ok === true && sellCar.manager.wallet === 217_800
      && sellCar.manager.prestige === Math.round(preSellPrestige - 5) / 10
      && (sellCar.manager.assets.find((a) => a.id === 'car_compact')?.owned ?? true) === false
      && mgrSell?.prestige === preSellPrestige - 5
      && newsSell.some((n) => n.message === 'Продано: Компакт-класс'),
    `wallet=${sellCar.manager.wallet} prestige=${sellCar.manager.prestige}`,
  );

  await expectCode('s12_sell_not_owned_409', 'ASSET_NOT_OWNED', () => engineDispatch('POST', '/manager/asset', {
    saveId: careerM.saveId, assetId: 'car_compact', action: 'sell',
  }));
  await expectCode('s12_unknown_asset_404', 'ASSET_NOT_FOUND', () => engineDispatch('POST', '/manager/asset', {
    saveId: careerM.saveId, assetId: 'jet', action: 'buy',
  }));

  // Повторная покупка проданного — полная цена, престиж начисляется заново
  const rebuy = await engineDispatch('POST', '/manager/asset', {
    saveId: careerM.saveId, assetId: 'car_compact', action: 'buy',
  }) as ManagerResponse;
  check(
    's12_rebuy_full_price',
    rebuy.ok === true && rebuy.manager.wallet === 177_800
      && rebuy.manager.prestige === Math.round(preSellPrestige + 5) / 10
      && (rebuy.manager.assets.find((a) => a.id === 'car_compact')?.owned ?? false),
    `wallet=${rebuy.manager.wallet} prestige=${rebuy.manager.prestige}`,
  );
}

// Кошелёк в минусе: −10 престижа в неделю + новость-предупреждение (§4.1)
{
  const rowNeg = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
  const negSeason = rowNeg?.season ?? 1;
  const negWeek = rowNeg?.week ?? 5;
  await patchManagerM({ wallet: -100_000, prestige: 400, assets: [], family: emptyFamily() });
  await patchSaveM({ boardConfidence: 50 });
  await engine.simulateActiveWeek();
  const mgrNeg = await readManagerM();
  const negNews = await storeM.newsItem.findMany({
    where: { saveId: careerM.saveId, type: 'manager' },
  });
  const deltaNeg = await userMatchPrestigeDelta(negSeason, negWeek);
  check(
    's12_wallet_negative',
    mgrNeg?.wallet === -55_000 && mgrNeg?.prestige === 400 + deltaNeg - 10
      && negNews.some((n) => n.message.startsWith('Личные финансы: кошелёк тренера в минусе')),
    `wallet=${mgrNeg?.wallet} prestige=${mgrNeg?.prestige}/${400 + deltaNeg - 10}`,
  );
}

// VIP-достройка: +20·L престижа (§4.3; таймер L2→L3 → +60 в шкале ×10)
{
  const rowVip = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
  const vipSeason = rowVip?.season ?? 1;
  const vipWeek = rowVip?.week ?? 6;
  const bState = parseBuildings(teamMRow?.buildings ?? null);
  bState.vip.level = 2;
  bState.vip.upgradeEndsAtDay = absoluteDayOf(vipSeason, vipWeek, eplPlan.totalWeeks) + 3;
  await storeM.team.update({ where: { id: teamMId }, data: { buildings: serializeBuildings(bState) } });
  await patchManagerM({ wallet: 100_000, prestige: 400, assets: [], family: emptyFamily() });
  await patchSaveM({ boardConfidence: 50 });
  await engine.simulateActiveWeek();
  const mgrVip = await readManagerM();
  const vipNews = await storeM.newsItem.findMany({
    where: { saveId: careerM.saveId, season: vipSeason, week: vipWeek, type: 'info' },
  });
  const deltaVip = await userMatchPrestigeDelta(vipSeason, vipWeek);
  check(
    's12_vip_prestige',
    mgrVip?.prestige === 400 + deltaVip + 60
      && vipNews.some((n) => n.message === 'Открыт VIP-ложи — уровень 3!'),
    `prestige=${mgrVip?.prestige}/${400 + deltaVip + 60}`,
  );
}

// ── Сезонный переход: точная формула дельт (§4.3) + возраст/кошелёк ──
{
  // Когерентный финал кубка (2 участника) + нейтральное правление (50 — без
  // дельты престижа ±2/−3 после апдейта) — ожидание вычисляется по факту
  const other = (await storeM.team.findMany({
    where: { saveId: careerM.saveId, isEuroGuest: false },
  })).find((t) => t.id !== teamMId);
  if (!other) throw new Error('S12: нет соперника для финала кубка');
  await patchSaveM({
    week: eplPlan.totalWeeks,
    cupRound: eplPlan.cupRounds,
    cupAliveTeamIds: JSON.stringify([teamMId, other.id]),
    boardConfidence: 50,
  });
  await patchManagerM({ prestige: 450, wallet: 100_000, assets: [], family: emptyFamily() });
  await engine.simulateActiveWeek(); // финальная неделя сезона 1 + переход

  const teamsAll = await storeM.team.findMany({
    where: { saveId: careerM.saveId, isEuroGuest: false },
  });
  const playedLeague1 = await storeM.match.findMany({
    where: { saveId: careerM.saveId, season: 1, competition: 'league', status: 'played' },
  });
  const standingTeamsM: StandingTeamInput[] = teamsAll.map((t) => ({
    id: t.id, name: t.name, shortName: t.shortName,
    colorPrimary: t.colorPrimary, colorSecondary: t.colorSecondary, isUser: t.isUserTeam,
  }));
  const playedInputs: StandingMatchInput[] = playedLeague1
    .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
    .map((m) => ({
      homeTeamId: m.homeTeamId, awayTeamId: m.awayTeamId,
      homeGoals: m.homeGoals as number, awayGoals: m.awayGoals as number, week: m.week,
    }));
  const userPlace = computeStandings(standingTeamsM, playedInputs).find((s) => s.teamId === teamMId)?.place ?? -1;
  const finalMatch = (await storeM.match.findMany({
    where: { saveId: careerM.saveId, season: 1, week: eplPlan.totalWeeks, competition: 'cup' },
  })).find((m) => m.homeTeamId === teamMId || m.awayTeamId === teamMId);
  const cupWon = finalMatch !== undefined && finalMatch.winnerTeamId === teamMId;
  // Евро сезона 1 не инициализировано (недели 1/8 пропущены) → исход null
  const euroPlayed1 = await storeM.match.findMany({
    where: { saveId: careerM.saveId, season: 1, competition: 'euro', status: 'played' },
  });
  const delta43 = await userMatchPrestigeDelta(1, eplPlan.totalWeeks);
  const expectedSeasonal = 450 + delta43 + (userPlace === 1 ? 80 : 0) + (cupWon ? 50 : 0);
  const mgrSeason = await readManagerM();
  const rowSeason = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
  check(
    's12_seasonal_deltas',
    mgrSeason?.prestige === expectedSeasonal && mgrSeason?.age === 46
      && rowSeason?.season === 2 && rowSeason?.week === 1
      && mgrSeason?.wallet === 145_000
      && euroPlayed1.length === 0
      && finalMatch !== undefined && finalMatch.status === 'played',
    `prestige=${mgrSeason?.prestige}/${expectedSeasonal} place=${userPlace} cupWon=${cupWon} age=${mgrSeason?.age}`,
  );
}

// ── Семья (§4.4): женитьба (сид p=0.04) → ребёнок (ровно 40 недель) ──
const poolM = poolContextOf(EPL);
const leagueAt = (absWeek: number): boolean =>
  weekSlotAt(eplPlan, ((absWeek - 1) % eplPlan.totalWeeks) + 1).type === 'league';

/**
 * Довести карьеру до абсолютной недели target (≥ текущей): прыжок внутри
 * сезона (только лиговые недели — кубковые прыжки ломают жеребьёвку) или
 * сезонный переход через когерентный финал (кубок: 2 участника, board 80 —
 * без отставки). Сама неделя target НЕ симулируется — это делает вызывающий.
 */
const advanceToAbsWeek = async (target: number, boardConf: number): Promise<void> => {
  for (let guard = 0; guard < 12; guard++) {
    const row = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
    const season = row?.season ?? 1;
    const curAbs = (season - 1) * eplPlan.totalWeeks + (row?.week ?? 1);
    if (curAbs > target) throw new Error(`advanceToAbsWeek: цель ${target} в прошлом (сейчас ${curAbs})`);
    const targetSeason = Math.floor((target - 1) / eplPlan.totalWeeks) + 1;
    if (season === targetSeason) {
      await patchSaveM({ week: ((target - 1) % eplPlan.totalWeeks) + 1, boardConfidence: boardConf });
      return;
    }
    const other = (await storeM.team.findMany({
      where: { saveId: careerM.saveId, isEuroGuest: false },
    })).find((t) => t.id !== teamMId);
    await patchSaveM({
      week: eplPlan.totalWeeks,
      cupRound: eplPlan.cupRounds,
      cupAliveTeamIds: JSON.stringify([teamMId, other?.id ?? teamMId]),
      boardConfidence: 80,
    });
    await engine.simulateActiveWeek();
  }
  throw new Error('advanceToAbsWeek: превышен лимит сезонов');
};

// Скан сидов женитьбы (сезон 2+, лиговая неделя; неделя ребёнка — тоже лиговая)
let marriageX: number | null = null;
for (let w = 44; w <= 44 + eplPlan.totalWeeks * 8; w++) {
  if (!leagueAt(w) || !leagueAt(w + MANAGER_CHILD_AFTER_WEEKS)) continue;
  const r = mulberry32(hashString(`${careerM.saveId}:family:marriage:${w}`));
  if (r() < MANAGER_MARRIAGE_P) {
    marriageX = w;
    break;
  }
}

if (marriageX === null) {
  check('s12_marriage_seeded', false, 'ни один сид p=0.04 не сработал за 8 сезонов (~3e-7)');
  check('s12_child_born', false, 'пропущено: женитьба не найдена');
  check('s12_son_in_academy', false, 'пропущено: женитьба не найдена');
} else {
  // Женитьба: престиж ≥ 50.0 (патч 600) + сид-реплика супруги
  await advanceToAbsWeek(marriageX, 50);
  await patchManagerM({ prestige: 600, wallet: 100_000, assets: [], family: emptyFamily() });
  const mRng = mulberry32(hashString(`${careerM.saveId}:family:marriage:${marriageX}`));
  const hit = mRng() < MANAGER_MARRIAGE_P;
  const expectedSpouse = pick(mRng, FEMALE_NAME_POOLS[poolM.base]);
  const seasonM = Math.floor((marriageX - 1) / eplPlan.totalWeeks) + 1;
  const weekM = ((marriageX - 1) % eplPlan.totalWeeks) + 1;
  await engine.simulateActiveWeek();
  {
    const mgrMar = await readManagerM();
    const marNews = await storeM.newsItem.findMany({
      where: { saveId: careerM.saveId, type: 'manager' },
    });
    const deltaMar = await userMatchPrestigeDelta(seasonM, weekM);
    check(
      's12_marriage_seeded',
      hit === true
        && mgrMar?.family.marriedAtWeek === marriageX
        && mgrMar?.family.spouseName === expectedSpouse
        && mgrMar?.prestige === 600 + deltaMar + 20
        && marNews.some((n) => n.message === `${MGR_NAME} женился на ${expectedSpouse}!`),
      `X=${marriageX} spouse=${mgrMar?.family.spouseName}/${expectedSpouse} prestige=${mgrMar?.prestige}/${600 + deltaMar + 20}`,
    );
  }

  // Ребёнок ровно через 40 недель: имя/пол — реплика сида, престиж +30
  const childAbs = marriageX + MANAGER_CHILD_AFTER_WEEKS;
  await advanceToAbsWeek(childAbs, 50);
  await patchManagerM({ prestige: 500, wallet: 100_000, assets: [] });
  const cRng = mulberry32(hashString(`${careerM.saveId}:family:child:${childAbs}`));
  const expectedGender = cRng() < 0.5 ? 'м' as const : 'д' as const;
  const expectedChildName = expectedGender === 'м'
    ? pick(cRng, NAME_POOLS[poolM.base].first)
    : pick(cRng, FEMALE_NAME_POOLS[poolM.base]);
  const seasonC = Math.floor((childAbs - 1) / eplPlan.totalWeeks) + 1;
  const weekC = ((childAbs - 1) % eplPlan.totalWeeks) + 1;
  await engine.simulateActiveWeek();
  {
    const mgrChild = await readManagerM();
    const child = mgrChild?.family.child ?? null;
    const childNews = await storeM.newsItem.findMany({
      where: { saveId: careerM.saveId, type: 'manager' },
    });
    const dtoChild = await engineDispatch('GET', '/manager', { saveId: careerM.saveId }) as ManagerResponse;
    const deltaChild = await userMatchPrestigeDelta(seasonC, weekC);
    check(
      's12_child_born',
      child !== null && child.bornAtWeek === childAbs && child.name === expectedChildName
        && child.gender === expectedGender && child.age === 0 && child.joinedAcademyPlayerId === null
        && mgrChild?.prestige === 500 + deltaChild + 30
        && childNews.some((n) => n.message === (expectedGender === 'м'
          ? `У ${MGR_NAME} родился сын — ${expectedChildName}!`
          : `У ${MGR_NAME} родилась дочь — ${expectedChildName}!`))
        && dtoChild.manager.family?.child?.seasonsToAcademy === 14,
      `child=${child?.name}/${child?.gender} prestige=${mgrChild?.prestige}/${500 + deltaChild + 30}`,
    );
  }

  // «Сын в академии» (§4.4): возраст 13 → 14 в ближайшем переходе
  const famBefore = (await readManagerM())?.family ?? emptyFamily();
  await patchManagerM({
    family: {
      ...famBefore,
      child: famBefore.child !== null ? { ...famBefore.child, age: 13 } : null,
    },
  });
  const rowSon = await storeM.gameSave.findUnique({ where: { id: careerM.saveId } });
  const seasonBeforeSon = rowSon?.season ?? 2;
  const otherSon = (await storeM.team.findMany({
    where: { saveId: careerM.saveId, isEuroGuest: false },
  })).find((t) => t.id !== teamMId);
  await patchSaveM({
    week: eplPlan.totalWeeks,
    cupRound: eplPlan.cupRounds,
    cupAliveTeamIds: JSON.stringify([teamMId, otherSon?.id ?? teamMId]),
    boardConfidence: 80,
  });
  await engine.simulateActiveWeek();
  {
    const mgrSon = await readManagerM();
    const sonId = mgrSon?.family.child?.joinedAcademyPlayerId ?? null;
    const sonRow = sonId !== null
      ? await storeM.player.findUnique({ where: { id: sonId } })
      : null;
    const sonNews = await storeM.newsItem.findMany({
      where: { saveId: careerM.saveId, type: 'manager' },
    });
    const dtoSon = await engineDispatch('GET', '/manager', { saveId: careerM.saveId }) as ManagerResponse;
    const academy = await engineDispatch('GET', '/academy', { saveId: careerM.saveId }) as AcademyResponse;
    check(
      's12_son_in_academy',
      sonRow !== null && sonId !== null
        && mgrSon?.family.child?.age === 14
        && sonRow.firstName === expectedChildName && sonRow.lastName === 'Северов'
        && sonRow.teamId === teamMId && sonRow.age === 14 && sonRow.isAcademy === true
        && sonRow.ovr >= 40 && sonRow.ovr <= 50
        && sonRow.potential >= 70 && sonRow.potential <= 93
        && sonRow.contractUntil === seasonBeforeSon + 3
        && sonNews.some((n) => n.message === `Сын тренера в академии: ${expectedChildName} Северов — ${sonRow.position}, 14 лет, OVR ${sonRow.ovr}, потолок ${sonRow.potential}.`)
        && dtoSon.manager.family?.child?.joinedAcademyPlayerId === sonId
        && dtoSon.manager.family?.child?.seasonsToAcademy === null
        && academy.graduates.some((g) => g.id === sonId),
      `son=${sonRow?.firstName} ${sonRow?.lastName} ovr=${sonRow?.ovr} pot=${sonRow?.potential}`,
    );
  }
}

// buildSonAcademyPlayer (юнит §4.4): имя/возраст/OVR 40–50/POT обе ветки
{
  const sonPositions = new Set(['GK', 'DL', 'DC', 'DR', 'ML', 'MC', 'MR', 'AML', 'AMC', 'AMR', 'ST']);
  let gem = false;
  let solid = false;
  let okAll = true;
  let lastPot = 0;
  for (let s = 0; s < 40; s++) {
    const son = buildSonAcademyPlayer({
      rng: mulberry32(7000 + s),
      managerName: MGR_NAME,
      child: { name: 'Артём', gender: 'м' },
      season: 4,
      pool: poolM,
      idFactory: () => `sonU${s}`,
    });
    const ok = son.firstName === 'Артём' && son.lastName === 'Северов' && son.age === 14
      && son.isAcademy === true && son.contractUntil === 7
      && sonPositions.has(son.position)
      && son.ovr >= 40 && son.ovr <= 50;
    if (!ok) okAll = false;
    if (son.potential >= 85 && son.potential <= 93) gem = true;
    else if (son.potential >= 70 && son.potential <= 84) solid = true;
    else okAll = false;
    lastPot = son.potential;
  }
  check('s12_son_unit', okAll && gem && solid, `gem=${gem} solid=${solid} lastPot=${lastPot}`);
}

// ── S13: D-7 «Газеты» — классификатор/шаблоны/MOTM/архив/getMedia (§5.1–5.6) ─

console.log('\n== S13: D-7 «Медиа» — газетные вырезки ==');

// Юнит: классификатор — 11 контекстов по сконструированным результатам (§5.2)
{
  const ev = (minute: number, type: MatchEventType, teamId: string, playerId?: string): MatchEvent => ({
    minute,
    type,
    teamId,
    ...(playerId !== undefined ? { playerId } : {}),
    text: 'x',
  });
  const hatTrickEvents = [
    ev(10, 'goal', 'U', 'p1'), ev(30, 'goal', 'U', 'p1'), ev(70, 'goal', 'U', 'p1'),
  ];
  const base = (over: Partial<PressMatchContextInput>): PressMatchContextInput => ({
    competition: 'league',
    isCupFinal: false,
    outcome: 'W',
    userGoals: 1,
    oppGoals: 0,
    events: [],
    userTeamId: 'U',
    strengthGap: 0,
    userPlace: null,
    oppPlace: null,
    userCity: null,
    oppCity: null,
    ...over,
  });
  check(
    's13_classifier_contexts',
    classifyPressContext(base({ competition: 'cup', isCupFinal: true, outcome: 'L', userGoals: 1, oppGoals: 2 })) === 'cup_final_heartbreak'
      && classifyPressContext(base({ outcome: 'W', userGoals: 3, oppGoals: 0, events: hatTrickEvents })) === 'hat_trick'
      && classifyPressContext(base({ outcome: 'W', userGoals: 1, oppGoals: 0, strengthGap: 8 })) === 'sensation'
      && classifyPressContext(base({ outcome: 'W', userGoals: 1, oppGoals: 0, strengthGap: 0, userPlace: 10, oppPlace: 5 })) === 'sensation'
      && classifyPressContext(base({ outcome: 'W', userGoals: 4, oppGoals: 1 })) === 'big_win'
      && classifyPressContext(base({ outcome: 'L', userGoals: 0, oppGoals: 3 })) === 'thrashing'
      && classifyPressContext(base({ outcome: 'W', userGoals: 2, oppGoals: 0 })) === 'clean_sheet_win'
      && classifyPressContext(base({ outcome: 'L', userGoals: 1, oppGoals: 2, userCity: 'Москва', oppCity: 'Москва' })) === 'derby'
      && classifyPressContext(base({ outcome: 'D', userGoals: 1, oppGoals: 1 })) === 'draw'
      && classifyPressContext(base({ outcome: 'L', userGoals: 1, oppGoals: 2 })) === 'narrow_loss'
      && classifyPressContext(base({ outcome: 'W', userGoals: 2, oppGoals: 1 })) === 'plain_win'
      // поражение по пенальти при ничейном счёте — «минимальное поражение» (разница 0–2)
      && classifyPressContext(base({ competition: 'cup', outcome: 'L', userGoals: 1, oppGoals: 1 })) === 'narrow_loss',
    '11 контекстов §5.2 + пенальти-поражение',
  );
}

// Юнит: шаблоны — подстановки worst-case ≤70 знаков; без остатков плейсхолдеров
{
  const worst = { user: 'Манчестер Юнайтед', opp: 'Манчестер Юнайтед', score: '10:10', player: 'Константин Константинов', city: 'Санкт-Петербург' };
  const contexts = Object.keys(PRESS_HEADLINES) as PressContext[];
  let allLen = true;
  let lastBad = '';
  for (const c of contexts) {
    for (const t of PRESS_HEADLINES[c]) {
      const filled = fillHeadlineTemplate(t, worst);
      if (filled.length > 70 || /\{[a-z]+\}/.test(filled)) {
        allLen = false;
        lastBad = `${c}: ${filled.length}`;
      }
    }
  }
  check(
    's13_headline_templates',
    allLen
      && contexts.length === 11
      && PRESS_HEADLINES.big_win.length === 3 && PRESS_HEADLINES.sensation.length === 3
      && PRESS_HEADLINES.draw.length === 2
      && PRESS_HEADLINES.big_win.includes('Разнос: {user} громит {opp} — {score}')
      && PRESS_HEADLINES.big_win.includes('Яркий вечер на трибунах: {score} в пользу {user}')
      && PRESS_HEADLINES.cup_final_heartbreak[0] === 'Серебро с горечью: финал кубка упущен — {score}'
      && PRESS_HEADLINES.special_son[1] === '{player} продолжает династию: путь в академии начат'
      && PRESS_PHRASES.big_win === 'Команда в ударе — болельщики требуют продолжения банкета.'
      && PRESS_NEWSPAPER_NAME === 'Спортивный Вестник'
      && PRESS_ARCHIVE_LIMIT === 60,
    lastBad,
  );
}

// Юнит: buildClipping — детерминизм, MOTM по сиду press:, выдержка, моменты
{
  const pool = poolContextOf(EPL);
  const rngSquad = mulberry32(1313);
  const positions: Position[] = ['GK', 'DC', 'DC', 'DL', 'DR', 'MC', 'MC', 'ML', 'AMC', 'ST', 'ST'];
  const squad = positions.map((position) => generatePlayer(rngSquad, 70, position, {
    fixedAge: 26, contractUntil: 3, pool,
  }));
  const events: MatchEvent[] = [
    { minute: 1, type: 'kickoff', teamId: 'U', text: 'Стартовый свисток.' },
    { minute: 12, type: 'goal', teamId: 'U', playerId: squad[9].id, playerName: 'A', assistId: squad[7].id, assistName: 'B', text: 'Гол! A открывает счёт после передачи B.' },
    { minute: 34, type: 'yellow', teamId: 'O', playerId: 'opp1', text: 'Жёлтая карточка гостям.' },
    { minute: 41, type: 'red', teamId: 'O', playerId: 'opp2', text: 'Красная! Гости остались вдесятером.' },
    { minute: 55, type: 'injury', teamId: 'U', playerId: squad[2].id, text: 'Травма защитника.' },
    { minute: 61, type: 'goal', teamId: 'U', playerId: squad[9].id, playerName: 'A', text: 'Дубль A!' },
    { minute: 95, type: 'pen_save', teamId: 'O', playerId: 'opp3', gkName: 'GK', text: 'Вратарь тащит пенальти!' },
  ];
  const input = (matchId: string): PressMatchInput => ({
    saveId: 'sv13', season: 1, week: 5, matchId,
    competition: 'league',
    isCupFinal: false,
    roundLabel: null,
    weekLabel: 'Тур 5/38',
    userTeam: { id: 'U', name: 'Зенит', city: 'Санкт-Петербург', strength: 70 },
    oppTeam: { id: 'O', name: 'Динамо', city: 'Москва', strength: 66 },
    userPlace: 4,
    oppPlace: 9,
    userHome: true,
    homeName: 'Зенит',
    awayName: 'Динамо',
    homeGoals: 2,
    awayGoals: 0,
    homePens: null,
    awayPens: null,
    winnerTeamId: null,
    userPlayers: squad,
    starterIds: new Set(squad.slice(0, 11).map((p) => p.id)),
    subInIds: new Set<string>(),
    events,
  });
  const a = buildClipping(input('m13'));
  const b = buildClipping(input('m13'));
  const motm = parseMotm(a.motm);
  const moments = parseMoments(a.moments);
  const rated = computePressRatings({
    saveId: 'sv13', matchId: 'm13', userTeamId: 'U', outcome: 'W', goalsConceded: 0,
    players: squad, starterIds: new Set(squad.slice(0, 11).map((p) => p.id)),
    subInIds: new Set<string>(), events,
  });
  const maxRated = rated.reduce((m, r) => (r.rating > m.rating ? r : m));
  const heroName = `${squad[9].firstName} ${squad[9].lastName}`;
  check(
    's13_build_clipping_unit',
    JSON.stringify(a) === JSON.stringify(b) // детерминизм от сида press:
      && a.context === 'clean_sheet_win' && a.competition === 'league'
      && a.homeGoals === 2 && a.awayGoals === 0 && a.homeName === 'Зенит' && a.awayName === 'Динамо'
      && a.headline.length <= 70 && !a.headline.includes('{')
      && (a.headline.startsWith('На ноль: Зенит') || a.headline.startsWith('Сухая победа'))
      && a.subheadline === 'Чемпионат, Тур 5/38. Зенит — 4-е место в таблице.'
      && a.subheadline.length <= 120
      && motm !== null && motm.playerId === maxRated.playerId
      && motm.rating >= 45 && motm.rating <= 100 && motm.rating === maxRated.rating
      && rated.every((r) => r.rating >= 45 && r.rating <= 100)
      && a.excerpt.startsWith('Лучшие у Зенит: ')
      && a.excerpt.includes(heroName)
      && a.excerpt.endsWith(PRESS_PHRASES.clean_sheet_win)
      && moments.length === 3
      && moments[0].minute === 12 && moments[0].kind === 'goal'
      && moments[1].minute === 41 && moments[1].kind === 'red'
      && moments[2].minute === 61 && moments[2].kind === 'goal'
      && moments.every((m) => m.text.length > 0)
      && userGoalsByPlayer(events, 'U').get(squad[9].id) === 2,
    `context=${a.context} motm=${motm?.name}(${motm?.rating}) moments=${moments.map((m) => `${m.minute}'${m.kind}`).join(',')}`,
  );

  // Чувствительность к матчу: другой matchId → другой сид шаблона допустим,
  // но рейтинг каждого игрока НЕ зависит от чужих сидов (тот же игрок — то же число)
  const c = buildClipping(input('m13-other'));
  const ratedC = computePressRatings({
    saveId: 'sv13', matchId: 'm13-other', userTeamId: 'U', outcome: 'W', goalsConceded: 0,
    players: squad, starterIds: new Set(squad.slice(0, 11).map((p) => p.id)),
    subInIds: new Set<string>(), events,
  });
  check(
    's13_press_seed_per_player',
    ratedC.every((r, i) => r.playerId === rated[i].playerId)
      && c.headline.length <= 70 && c.context === a.context
      && (c.headline === a.headline || c.headline !== a.headline) // шаблон зависит от сида матча
      && parseMoments(c.moments).length === 3,
    `headlines differ=${c.headline !== a.headline}`,
  );
}

// Юнит: pickMoments — приоритеты (goal > red > pens > injury > yellow), маркеры серии
{
  const events: MatchEvent[] = [
    { minute: 94, type: 'pen_goal', text: 'Серия пенальти!' }, // маркер — не карточка
    { minute: 5, type: 'yellow', teamId: 'U', playerId: 'p1', text: 'ЖК' },
    { minute: 96, type: 'pen_save', teamId: 'U', playerId: 'p1', text: 'Сэйв' },
    { minute: 120, type: 'pen_goal', teamId: 'U', text: 'Серия пенальти: 4:3 — победа!' },
    { minute: 90, type: 'injury', teamId: 'U', playerId: 'p2', text: 'Травма' },
    { minute: 70, type: 'goal', teamId: 'U', playerId: 'p3', text: 'Гол' },
    { minute: 80, type: 'goal', teamId: 'O', playerId: 'p4', text: 'Гол гостей' },
    { minute: 85, type: 'chance', teamId: 'U', playerId: 'p5', text: 'Момент' },
    { minute: 86, type: 'sub', teamId: 'U', playerId: 'p6', text: 'Замена' },
    { minute: 2, type: 'kickoff', text: 'Свисток' },
  ];
  const moments = pickMoments(events);
  check(
    's13_moments_priority',
    moments.length === 3
      && moments[0].minute === 70 && moments[0].kind === 'goal'
      && moments[1].minute === 80 && moments[1].kind === 'goal'
      && moments[2].minute === 96 && moments[2].kind === 'pens'
      && !moments.some((m) => m.minute === 94)
      && parseMoments('oops') !== undefined && parseMoments('oops').length === 0
      && parseMotm('oops') === null,
    `moments=${moments.map((m) => `${m.minute}'${m.kind}`).join(',')}`,
  );
}

// Юнит: buildSonClipping — спецвыпуск академии (§5.2-11)
{
  const sonClip = buildSonClipping({
    saveId: 'sv13', season: 2, week: 43,
    userTeamName: 'Спартак',
    son: { playerId: 'son1', name: 'Артём Северов', position: 'MC' },
  });
  check(
    's13_son_clipping_unit',
    sonClip.context === 'special_son' && sonClip.competition === 'academy'
      && sonClip.matchId === null && sonClip.motm === null && sonClip.moments === '[]'
      && sonClip.subheadline === 'Молодёжная академия, сезон 2'
      && sonClip.homeName === 'Спартак' && sonClip.homeGoals === 0 && sonClip.awayGoals === 0
      && (sonClip.headline === 'Сын тренера — в академии Спартак!'
        || sonClip.headline === 'Артём Северов продолжает династию: путь в академии начат')
      && sonClip.excerpt === PRESS_PHRASES.special_son,
    sonClip.headline,
  );
}

// Интеграция S12→S13: спецвыпуск «сын в академии» создан переходом (careerM)
{
  const sonClippings = await storeM.newspaperClipping.findMany({
    where: { saveId: careerM.saveId, context: 'special_son' },
  });
  check(
    's13_son_clipping_integration',
    sonClippings.length === 1
      && sonClippings[0].matchId === null
      && sonClippings[0].competition === 'academy'
      && sonClippings[0].subheadline === `Молодёжная академия, сезон ${sonClippings[0].season}`
      && sonClippings[0].moments === '[]' && sonClippings[0].motm === null
      && sonClippings[0].headline.length <= 70,
    `n=${sonClippings.length} season=${sonClippings[0]?.season}`,
  );
}

// Интеграция: карьера P — лига (неделя 1) → вырезка с корректным контекстом
const PRESS_MGR = 'Пресс Редактор';
const careerP = await engine.createCareer({
  leagueCode: 'EPL', clubIndex: midClubIdx, managerName: PRESS_MGR, seed: 7555, now: NOW,
});
await engine.loadSlot(careerP.slot);
const storeP = engine.requireStore();
const rowP = await storeP.gameSave.findUnique({ where: { id: careerP.saveId } });
const teamPId = rowP?.teamId ?? '';
const teamsP = await storeP.team.findMany({ where: { saveId: careerP.saveId, isEuroGuest: false } });
const teamP = teamsP.find((t) => t.id === teamPId);
const patchSaveP = (data: Record<string, unknown>): Promise<unknown> =>
  storeP.gameSave.update({ where: { id: careerP.saveId }, data });
{
  const week1 = await engine.simulateActiveWeek();
  const clips1 = await storeP.newspaperClipping.findMany({ where: { saveId: careerP.saveId } });
  const userMatch1 = week1.userMatches[0];
  const clip1 = clips1[0];
  const matchRow1 = userMatch1
    ? await storeP.match.findUnique({ where: { id: userMatch1.matchId } })
    : null;
  const validContexts = new Set([
    'big_win', 'sensation', 'clean_sheet_win', 'derby', 'draw', 'narrow_loss', 'plain_win',
    'hat_trick', 'thrashing',
  ]);
  const motm1 = clip1 ? parseMotm(clip1.motm) : null;
  check(
    's13_league_week_clipping',
    week1.userMatches.length === 1
      && clips1.length === 1
      && clip1 !== undefined
      && clip1.competition === 'league'
      && clip1.season === 1 && clip1.week === 1
      && clip1.matchId === userMatch1?.matchId
      && matchRow1 !== null && clip1.homeGoals === matchRow1.homeGoals
      && clip1.awayGoals === matchRow1.awayGoals
      && clip1.homeName === (teamsP.find((t) => t.id === matchRow1?.homeTeamId)?.name ?? '')
      && validContexts.has(clip1.context)
      && clip1.headline.length <= 70 && !clip1.headline.includes('{')
      && clip1.subheadline.startsWith('Чемпионат, Тур 1/38. ')
      && clip1.subheadline.includes('-е место в таблице.')
      && motm1 !== null && motm1.rating >= 45 && motm1.rating <= 100
      && clip1.excerpt.startsWith(`Лучшие у ${teamP?.name}: `)
      && parseMoments(clip1.moments).length >= 1
      && parseMoments(clip1.moments).length <= 3,
    `context=${clip1?.context} sub="${clip1?.subheadline}" motm=${motm1?.rating}`,
  );
}

// Интеграция: конгестия — кубок + евро на одной неделе → 2 вырезки (§5.1)
{
  // 4 участника кубка и 4 евро: после раунда останется по 2 — следующая
  // жеребьёвка валидна (1 победитель ломал бы drawRound)
  const others = teamsP.filter((t) => t.id !== teamPId);
  const cupIds = [teamPId, others[0].id, others[1].id, others[2].id];
  const euroIds = [teamPId, others[3].id, others[4].id, others[5].id];
  await patchSaveP({
    week: 16, // EPL: кубковая неделя 2 (1/8 финала) И евронеделя 1/8
    cupRound: 2,
    cupAliveTeamIds: JSON.stringify(cupIds),
    euroSeason: 1,
    euroRound: 1,
    euroAliveTeamIds: JSON.stringify(euroIds),
    euroParticipants: JSON.stringify(euroIds),
  });
  const week16 = await engine.simulateActiveWeek();
  const clips16 = await storeP.newspaperClipping.findMany({
    where: { saveId: careerP.saveId, week: 16 },
  });
  const cupClip = clips16.find((c) => c.competition === 'cup');
  const euroClip = clips16.find((c) => c.competition === 'euro');
  check(
    's13_congestion_cup_euro',
    week16.userMatches.length === 2
      && clips16.length === 2
      && cupClip !== undefined && euroClip !== undefined
      && cupClip.matchId === week16.userMatches.find((m) => m.competition === 'cup')?.matchId
      && euroClip.matchId === week16.userMatches.find((m) => m.competition === 'euro')?.matchId
      && cupClip.subheadline === 'Кубок, 1/8 финала.'
      && euroClip.subheadline === 'Кубок Европы, 1/8 финала.'
      && [cupClip, euroClip].every((c) => c.headline.length <= 70)
      && [cupClip, euroClip].every((c) => parseMotm(c.motm) !== null)
      && (cupClip.homePens === null || (cupClip.homePens >= 1 && cupClip.awayPens !== null)),
    `userMatches=${week16.userMatches.map((m) => m.competition).join('+')} clips=${clips16.map((c) => c.competition).join('+')}`,
  );
}

// Интеграция: архив ≤ 60 — 62 синтетических + неделя с матчем → 60 (§5.4/S13)
{
  const synthIds: string[] = [];
  for (let i = 0; i < 62; i++) {
    const id = `clip-synth-${i}`;
    synthIds.push(id);
    await storeP.newspaperClipping.create({
      data: {
        id,
        saveId: careerP.saveId,
        season: 1,
        week: i + 1,
        matchId: `synth-match-${i}`,
        competition: 'league',
        context: 'plain_win',
        headline: `Синтетический выпуск № ${i + 1}`,
        subheadline: 'Чемпионат, синтетика.',
        homeName: 'A',
        awayName: 'B',
        homeGoals: 1,
        awayGoals: 0,
        homePens: null,
        awayPens: null,
        motm: null,
        excerpt: 'Синтетика.',
        moments: '[]',
        createdAt: new Date(NOW.getTime() + (i + 1) * 60_000),
      },
    });
  }
  // неделя 17 — лиговая: 1 новый выпуск; 62 synth + 3 real (недели 1 и 16×2)
  // + 1 новый = 66 → старейшие 6 удалены → ровно 60
  await patchSaveP({ week: 17 });
  const week17 = await engine.simulateActiveWeek();
  const after = await storeP.newspaperClipping.findMany({ where: { saveId: careerP.saveId } });
  const afterIds = new Set(after.map((c) => c.id));
  const newClip = after.find((c) => c.week === 17 && c.competition === 'league');
  check(
    's13_archive_cap_60',
    week17.userMatches.length === 1
      && after.length === 60
      && newClip !== undefined && afterIds.has(newClip.id)
      // старейшие синтетические (недели 1–4) удалены; свежие остаются
      && !afterIds.has(synthIds[0]) && !afterIds.has(synthIds[1])
      && !afterIds.has(synthIds[2]) && !afterIds.has(synthIds[3])
      && afterIds.has(synthIds[5]) && afterIds.has(synthIds[61]),
    `total=${after.length} (62 synth + 3 real + 1 new − 6 oldest → 60)`,
  );
}

// GET /media (§5.6): пагинация offset/limit, DTO-форма, сорт desc, ошибки
{
  const all = await storeP.newspaperClipping.findMany({
    where: { saveId: careerP.saveId },
    orderBy: [{ season: 'desc' }, { week: 'desc' }, { createdAt: 'desc' }],
  });
  const page1 = await engineDispatch('GET', '/media', {
    saveId: careerP.saveId, offset: 0, limit: 3,
  }) as MediaResponse;
  const page3 = await engineDispatch('GET', '/media', {
    saveId: careerP.saveId, offset: 59, limit: 5,
  }) as MediaResponse;
  const beyond = await engineDispatch('GET', '/media', {
    saveId: careerP.saveId, offset: 100, limit: 5,
  }) as MediaResponse;
  const defaultLimit = await engineDispatch('GET', '/media', {
    saveId: careerP.saveId,
  }) as MediaResponse;
  let invalidPayload = false;
  try {
    await engineDispatch('GET', '/media', { saveId: careerP.saveId, offset: -1, limit: 1 });
  } catch (e) {
    invalidPayload = e instanceof ApiGameError && e.code === 'INVALID_PAYLOAD';
  }
  const d0 = page1.clippings[0];
  const dtoOk = d0 !== undefined
    && typeof d0.id === 'string' && typeof d0.createdAt === 'string' && !Number.isNaN(Date.parse(d0.createdAt))
    && Array.isArray(d0.moments) && (d0.motm === null || typeof d0.motm.rating === 'number')
    && (d0.motm === null || (d0.motm.rating * 10) % 1 === 0)
    && page1.clippings.every((c) => c.headline.length <= 70);
  check(
    's13_get_media_pagination',
    page1.ok === true && page1.total === 60 && page1.clippings.length === 3
      && page1.clippings[0].id === all[0].id && page1.clippings[2].id === all[2].id
      && (page1.clippings[0].season > page1.clippings[2].season
        || page1.clippings[0].week >= page1.clippings[2].week)
      && page3.clippings.length === 1 && page3.clippings[0].id === all[59].id
      && beyond.clippings.length === 0 && beyond.total === 60
      && defaultLimit.clippings.length === 1
      && invalidPayload
      && dtoOk,
    `page1=${page1.clippings.length}/${page1.total} page3=${page3.clippings.length} invalid=${invalidPayload}`,
  );
}

// Канонический roundtrip дампа с вырезками (§2.1/D-7: таблица newspaperClippings)
{
  const dump1 = storeP.toJSON();
  const dumpJson1 = JSON.stringify(dump1);
  const revived = createSaveStoreFromDump(JSON.parse(dumpJson1), { clock: () => NOW });
  const dumpJson2 = JSON.stringify(revived.toJSON());
  const clipRow = dump1.newspaperClippings[0] as unknown as Record<string, unknown>;
  const clipFull = await storeP.newspaperClipping.findUnique({ where: { id: clipRow.id as string } });
  check(
    's13_canonical_roundtrip',
    dumpJson1 === dumpJson2
      && Array.isArray(dump1.newspaperClippings) && dump1.newspaperClippings.length === 60
      && Object.keys(clipRow).join(',') === 'id,saveId,season,week,matchId,competition,context,headline,subheadline,homeName,awayName,homeGoals,awayGoals,homePens,awayPens,motm,excerpt,moments,createdAt'
      && clipFull !== null && typeof clipFull.motm === 'string' && typeof clipFull.moments === 'string'
      && (clipFull.motm === null || parseMotm(clipFull.motm) !== null)
      && parseMoments(clipFull.moments).length <= 3,
    `n=${dump1.newspaperClippings.length} keys=${Object.keys(clipRow).length}`,
  );
}

// Пустой архив: карьера без сыгранных матчей → total=0 (§5.6 заглушка)
{
  const emptyMedia = await engineDispatch('GET', '/media', {
    saveId: careerTop.saveId,
  }) as MediaResponse;
  check(
    's13_media_empty',
    emptyMedia.ok === true && emptyMedia.total === 0 && emptyMedia.clippings.length === 0,
    `total=${emptyMedia.total}`,
  );
}

// ── Итог ───────────────────────────────────────────────────────────────────

console.log(`\nИтого: PASS=${pass} FAIL=${fail}`);
if (failures.length > 0) {
  console.log(`Провалены: ${failures.join(', ')}`);
}
process.exit(fail > 0 ? 1 : 0);

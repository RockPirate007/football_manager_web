import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolveSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { careerTotalsOf, type SeasonRecordRow } from '@/lib/game/history';
import { toPlayerDTO } from '@/lib/game/snapshot';
import { AWARD_TYPE_LABELS } from '@/lib/game/types';
import type { PlayerDialogDTO, PlayerDialogResponse, PlayerHistoryDTO, SeasonAwardDTO } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/player?saveId=&id= — диалог игрока (Фаза 3, §6.1): карточка +
 * история по сезонам (PlayerSeasonRecord) + карьерные итоги + награды.
 * Игрок может быть ЧУЖИМ или рыночным (скаутинг по истории). Лениво
 * подгружается при открытии диалога — не раздувать /state историей.
 */
export async function GET(request: Request) {
  try {
    const save = await resolveSave(saveIdFromQuery(request));
    if (!save.teamId) return fail('SAVE_NOT_FOUND', 404);

    const { searchParams } = new URL(request.url);
    const playerId = searchParams.get('id')?.trim();
    if (!playerId) return fail('INVALID_PAYLOAD', 400);

    const playerRow = await db.player.findFirst({
      where: { id: playerId, saveId: save.id },
    });
    if (!playerRow) return fail('PLAYER_NOT_FOUND', 404);

    // Запрошенная цена, если игрок выставлен на рынок
    const listing = await db.transferListing.findFirst({
      where: { playerId: playerRow.id, status: 'active' },
      select: { price: true },
    });

    // История по сезонам (по возрастанию)
    const recordRows = await db.playerSeasonRecord.findMany({
      where: { playerId: playerRow.id, saveId: save.id },
      orderBy: [{ season: 'asc' }],
    });
    const history: PlayerHistoryDTO[] = recordRows.map((r) => ({
      season: r.season,
      teamName: r.teamName,
      age: r.age,
      position: r.position,
      apps: r.apps,
      goals: r.goals,
      assists: r.assists,
      cupGoals: r.cupGoals,
      cupAssists: r.cupAssists,
      // ── Фаза 4: евросезон в карточке игрока ──
      euroGoals: r.euroGoals,
      euroAssists: r.euroAssists,
      cleanSheets: r.cleanSheets,
      yellowCards: r.yellowCards,
      redCards: r.redCards,
      avgRating: r.avgRating > 0 ? r.avgRating / 10 : null,
    }));

    // Карьерные итоги из строк истории
    const rows: SeasonRecordRow[] = recordRows.map((r) => ({
      playerId: r.playerId,
      teamId: r.teamId,
      teamName: r.teamName,
      age: r.age,
      position: r.position,
      apps: r.apps,
      goals: r.goals,
      assists: r.assists,
      cupGoals: r.cupGoals,
      cupAssists: r.cupAssists,
      euroGoals: r.euroGoals, // Фаза 4 (§5.6-3)
      euroAssists: r.euroAssists,
      cleanSheets: r.cleanSheets,
      yellowCards: r.yellowCards,
      redCards: r.redCards,
      avgRating: r.avgRating,
    }));
    const totals = careerTotalsOf(rows);

    // Награды игрока за все сезоны
    const awardRows = await db.seasonAward.findMany({
      where: { playerId: playerRow.id, saveId: save.id },
      orderBy: [{ season: 'asc' }, { createdAt: 'asc' }],
    });
    const teams = await db.team.findMany({
      where: { saveId: save.id },
      select: { id: true, name: true },
    });
    const teamName = new Map(teams.map((t) => [t.id, t.name]));
    const playerName = `${playerRow.firstName} ${playerRow.lastName}`;
    const awards: SeasonAwardDTO[] = awardRows.map((r) => ({
      id: r.id,
      season: r.season,
      type: r.type,
      typeName: AWARD_TYPE_LABELS[r.type] ?? r.type,
      playerId: r.playerId,
      playerName,
      teamId: r.teamId,
      teamName: teamName.get(r.teamId) ?? '',
      value: r.value,
      label: r.label,
    }));

    const dialog: PlayerDialogDTO = {
      player: toPlayerDTO(playerRow, listing ? listing.price : null),
      history,
      totals,
      awards,
    };
    const response: PlayerDialogResponse = { ok: true, dialog };
    return NextResponse.json(response);
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/player]', error);
    return fail('UNKNOWN', 500);
  }
}

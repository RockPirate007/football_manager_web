import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { toTeamBrief } from '@/lib/game/snapshot';
import { parseEvents, parseStats } from '@/lib/game/types';
import type { MatchDetailsDTO } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/match?saveId=&id= — детали матча (лента событий) для экранов
 * Лига/Кубок. При явном saveId матч обязан принадлежать этой карьере
 * (изоляция карьер), иначе 404 MATCH_NOT_FOUND.
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id') ?? '';
    if (!id) return fail('MATCH_NOT_FOUND', 404);

    const match = await db.match.findUnique({ where: { id } });
    if (!match) return fail('MATCH_NOT_FOUND', 404);

    const saveId = saveIdFromQuery(request);
    if (saveId && match.saveId !== saveId) return fail('MATCH_NOT_FOUND', 404);

    const home = await db.team.findUnique({ where: { id: match.homeTeamId } });
    const away = await db.team.findUnique({ where: { id: match.awayTeamId } });
    if (!home || !away) return fail('MATCH_NOT_FOUND', 404);

    const dto: MatchDetailsDTO = {
      id: match.id,
      week: match.week,
      season: match.season,
      competition: match.competition === 'cup' ? 'cup' : 'league',
      cupRound: match.cupRound,
      home: toTeamBrief(home),
      away: toTeamBrief(away),
      homeGoals: match.homeGoals ?? 0,
      awayGoals: match.awayGoals ?? 0,
      homePens: match.homePens,
      awayPens: match.awayPens,
      winnerTeamId: match.winnerTeamId,
      isNeutral: match.isNeutral,
      played: match.status === 'played',
      events: parseEvents(match.events),
      stats: parseStats(match.stats),
    };

    return NextResponse.json({ ok: true, match: dto });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/match]', error);
    return fail('UNKNOWN', 500);
  }
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { liveCupScorers, liveEuroScorers, liveLeaders, type LeaderTeamInfo } from '@/lib/game/awards';
import { normalizeErrorCode, resolvePlayingSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import type { PlayerLike } from '@/lib/game/players';
import { AWARD_TYPE_LABELS } from '@/lib/game/types';
import type { PlayerLeaderDTO, SeasonAwardDTO } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/**
 * GET /api/game/awards?saveId=&season= — зал славы по сезонам + live-лидеры
 * текущего сезона. season необязателен: без него — все сезоны карьеры. §5.5.
 */
export async function GET(request: Request) {
  try {
    const saveId = saveIdFromQuery(request);
    if (!saveId) return fail('INVALID_PAYLOAD', 400);
    const save = await resolvePlayingSave(saveId);

    const { searchParams } = new URL(request.url);
    const seasonParam = searchParams.get('season');
    let season: number | null = null;
    if (seasonParam !== null && seasonParam.trim() !== '') {
      const n = Number(seasonParam);
      if (!Number.isInteger(n) || n < 1) return fail('INVALID_PAYLOAD', 400);
      season = n;
    }

    const rows = await db.seasonAward.findMany({
      where: { saveId: save.id, ...(season !== null ? { season } : {}) },
      orderBy: [{ season: 'asc' }, { createdAt: 'asc' }],
    });

    const teams = await db.team.findMany({ where: { saveId: save.id } });
    const teamName = new Map(teams.map((t) => [t.id, t.name]));

    // Игроки-лауреаты могли завершить карьеру (FK SeasonAward.playerId → SetNull)
    const playerIds = [...new Set(rows.map((r) => r.playerId).filter((x): x is string => !!x))];
    const players = playerIds.length > 0
      ? await db.player.findMany({ where: { id: { in: playerIds } } })
      : [];
    const playerName = new Map(players.map((p) => [p.id, `${p.firstName} ${p.lastName}`]));

    const awards: SeasonAwardDTO[] = rows.map((r) => ({
      id: r.id,
      season: r.season,
      type: r.type,
      typeName: AWARD_TYPE_LABELS[r.type] ?? r.type,
      playerId: r.playerId,
      playerName: r.playerId ? (playerName.get(r.playerId) ?? null) : null,
      teamId: r.teamId,
      teamName: teamName.get(r.teamId) ?? '',
      value: r.value,
      label: r.label,
    }));

    // Live-лидеры текущего сезона (топ-5, на лету).
    // Фаза 4 (§5.5 ТЗ, QA P4-5): лиговые лидеры — ТОЛЬКО не-гости
    // (team.isEuroGuest=false, как в snapshot.ts); topEuroScorers — все,
    // включая гостей (бомбардиры Кубка Европы для экрана «Европа»).
    const allPlayers = await db.player.findMany({
      where: { saveId: save.id, teamId: { not: null } },
    });
    const guestTeamIds = new Set(teams.filter((t) => t.isEuroGuest).map((t) => t.id));
    const leaguePlayersLike = allPlayers
      .filter((p) => !guestTeamIds.has(p.teamId ?? '')) as unknown as PlayerLike[];
    const allPlayersLike = allPlayers as unknown as PlayerLike[];
    const leaderTeams = new Map<string, LeaderTeamInfo>(
      teams.map((t) => [
        t.id,
        {
          name: t.name,
          shortName: t.shortName,
          c1: t.colorPrimary,
          c2: t.colorSecondary,
          isUser: t.isUserTeam,
        },
      ]),
    );
    const leaders = liveLeaders({ players: leaguePlayersLike, teams: leaderTeams, take: 5 });
    const topCupScorers: PlayerLeaderDTO[] = liveCupScorers({
      players: leaguePlayersLike,
      teams: leaderTeams,
      take: 5,
    });
    const topEuroScorers: PlayerLeaderDTO[] = liveEuroScorers({
      players: allPlayersLike,
      teams: leaderTeams,
      take: 10,
    });

    return NextResponse.json({
      ok: true,
      awards,
      live: { ...leaders, topCupScorers, topEuroScorers },
    });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/awards]', error);
    return fail('UNKNOWN', 500);
  }
}

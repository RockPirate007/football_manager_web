/**
 * Движок симуляции матча (Фаза 4 — сегментный): 3 сегмента [1–45][46–70][71–93],
 * время-взвешенные λ-факторы (красные / «сушка» / «погоня» / дефицит), решения
 * тренеров на контрольных точках 46'/70' (coach.ts — FSM × Utility), замены
 * (до SUB_MAX) с событиями type:'sub' и виртуальная усталость стартёров
 * (PER_SEGMENT_COND_DRAIN за сегмент). Полный движок — для матчей с участием
 * клуба игрока; упрощённый (односэмпльный Пуассон) — для ИИ.
 * Раздел 4.8 docs/architecture.md + §4.2 docs/architecture-phase4.md.
 *
 * ДЕТЕРМИНИЗМ (порядок rng-бросков, зафиксирован):
 *   карточки home → карточки away → травмы home → травмы away →
 *   вынужденные замены home (по минутам) → away →
 *   [сегмент: Пуассон home → голы home → Пуассон away → голы away →
 *   моменты home → моменты away] → КТ46 (coachDecide home → away;
 *   исполнение home → away) → [сегмент 2 …] → КТ70 … → [сегмент 3 …] →
 *   статистика (sot home → sot away → fouls home → fouls away).
 */

import {
  AI_STYLES, BASE_GOALS, CHASE_MOD, COND_EFF_FLOOR, FORMATIONS, HOME_ADVANTAGE, INJURY_PROB,
  LAMBDA_MAX, LAMBDA_MIN, MENTALITY_ORDER, PARKING_BUS_MOD, PER_SEGMENT_COND_DRAIN,
  RED_CARD_PROB, RED_LAMBDA_OPP, RED_LAMBDA_OPP_LATE, RED_LAMBDA_SELF,
  RED_LAMBDA_SELF_LATE, SEGMENT_BOUNDS, SEGMENT_SHARES, SEGMENTS_COUNT,
  SHORT_HANDED_LAMBDA_MOD, SUB_IN_CONDITION_CAP, SUB_MAX, TEMPO_CHANCE_MOD,
  YELLOW_CAP, YELLOW_LAMBDA_AGGR_DIV, YELLOW_LAMBDA_BASE, YELLOW_PRESSING_BONUS,
  type AiStyleCode, type AiStyleDef,
} from './constants';
import {
  CHANCE_TEMPLATES, FORMATION_SHIFT_TEMPLATES, FULLTIME_TEXT, GOAL_TEMPLATES,
  HALFTIME_TEXT, INJURY_TEMPLATES, KICKOFF_TEXT, RED_TEMPLATES,
  SECOND_YELLOW_TEMPLATES, SUB_FORCED_INDEX, SUB_TEMPLATES, YELLOW_TEMPLATES,
} from './data';
import { aiDefaultPlan, coachDecide, remapForFormation, type CoachSideState } from './coach';
import { positionGroupOf, slotScore, type LineupPlayer, type PlayerLike } from './players';
import { samplePoisson } from './poisson';
import { clamp, gauss, pick, pickWeighted, randInt, type RNG } from './rng';
import { applyModifiers, type TeamTacticState } from './strength';
import type {
  DefLineLevel, FormationId, MatchEvent, MatchEventType, MatchPlanDTO, MatchStats,
  Mentality, PositionGroup, TempoLevel,
} from './types';

export interface MatchTeamInput extends TeamTacticState {
  name: string;
  /** Фаза 4: id запасных (не в XI). Отсутствует → пул выводится из players (не в XI, здоровые). */
  bench?: string[];
  /** Фаза 4: стиль и план тренера. Отсутствует → balanced + дефолтный AI-план (паритет решений). */
  coach?: { style: AiStyleCode; plan: MatchPlanDTO };
  /**
   * D-5 «Территория» (§3.5): множитель риска травм в матче (medical L клуба
   * игрока, 1 − 0.04·L). Отсутствует → 1 (обратная совместимость, по образцу
   * bench/coach) — ИИ-клубы играют без множителя.
   */
  medRiskMult?: number;
}

export interface MatchInjury {
  teamId: string;
  playerId: string;
  weeks: number;
}

/** Замена матча (Фаза 4): кто сошёл / кто вышел / минута / причина. */
export interface SubRecord {
  outId: string;
  inId: string;
  minute: number;
  reason: 'injury' | 'fatigue' | 'chase' | 'defensive';
}

export interface MatchResult {
  homeGoals: number;
  awayGoals: number;
  events: MatchEvent[];
  stats: MatchStats;
  homeStarters: (string | null)[];
  awayStarters: (string | null)[];
  /** Фаза 4: замены команд (для пост-матча: минуты выходов/сходов). */
  homeSubs: SubRecord[];
  awaySubs: SubRecord[];
  injuries: MatchInjury[];
}

const TYPE_ORDER: Record<MatchEventType, number> = {
  kickoff: 0,
  goal: 1,
  chance: 1,
  yellow: 1,
  red: 1,
  injury: 1,
  sub: 1,
  pen_goal: 1,
  pen_miss: 1,
  pen_save: 1,
  shot_on: 1,
  shot_off: 1,
  save: 1,
  corner: 1,
  offside: 1,
  duel: 1,
  momentum: 1,
  halftime: 2,
  fulltime: 3,
};

// ── Сегменты ─────────────────────────────────────────────────────────────

const SEG_END: readonly number[] = SEGMENT_BOUNDS; // [45, 70, 93]
const SEG_START: readonly number[] = [1, SEGMENT_BOUNDS[0] + 1, SEGMENT_BOUNDS[1] + 1]; // [1, 46, 71]

function segIndexOf(minute: number): number {
  for (let k = 0; k < SEGMENTS_COUNT; k++) {
    if (minute <= SEG_END[k]) return k;
  }
  return SEGMENTS_COUNT - 1;
}

/**
 * Время-взвешенный множитель сегмента (§4.2): событие на минуте m снижает λ
 * сегмента k пропорционально доле сегмента ПОСЛЕ события: factor = 1 − w + w×mul.
 */
function segFactor(eventMinute: number, k: number, mul: number): number {
  const s = SEG_START[k];
  const e = SEG_END[k];
  if (eventMinute >= e) return 1; // событие позже сегмента — не влияет
  const w = clamp((e - Math.max(eventMinute, s)) / (e - s + 1), 0, 1);
  return 1 - w + w * mul;
}

/** λ-множители красной по минуте: ≤45' (0.55/1.30), 46–70' (0.70/1.15), 71+ — без эффекта. */
function redMulOf(minute: number): { self: number; opp: number } {
  if (minute <= SEG_END[0]) return { self: RED_LAMBDA_SELF, opp: RED_LAMBDA_OPP };
  if (minute <= SEG_END[1]) return { self: RED_LAMBDA_SELF_LATE, opp: RED_LAMBDA_OPP_LATE };
  return { self: 1, opp: 1 };
}

/** Минута гола по сегментным долям (упрощённый движок ИИ; полный берёт минуту сегмента). */
function segmentGoalMinute(rng: RNG): number {
  const roll = rng();
  if (roll < SEGMENT_SHARES[0]) return randInt(rng, 1, SEG_END[0]);
  if (roll < SEGMENT_SHARES[0] + SEGMENT_SHARES[1]) return randInt(rng, SEG_START[1], SEG_END[1]);
  return randInt(rng, SEG_START[2], SEG_END[2]);
}

// ── Вспомогательные ──────────────────────────────────────────────────────

function fullName(p: PlayerLike): string {
  return `${p.firstName} ${p.lastName}`;
}

function pluralTours(n: number): string {
  if (n % 10 === 1 && n % 100 !== 11) return 'тур';
  if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14)) return 'тура';
  return 'туров';
}

/** Шаблоны тактических замен («вынужденная» — только для травм). */
const TACTICAL_SUB_TEMPLATES: string[] = SUB_TEMPLATES.filter(
  (_, i) => i !== SUB_FORCED_INDEX,
);

/** Замена в λ-линейке состава: segFrom — первый сегмент, где замена влияет на λ. */
interface SubMutation {
  minute: number;
  slot: number;
  outId: string;
  inId: string;
  /** Сегмент, с которого замена влияет на λ (КТ — текущий; вынужденная — следующий). */
  segFrom: number;
}

interface TeamRuntime {
  input: MatchTeamInput;
  style: AiStyleDef;
  plan: MatchPlanDTO;
  byId: Map<string, PlayerLike>;
  originalLineup: (string | null)[];
  starters: PlayerLike[];
  benchPool: PlayerLike[];
  mentality: Mentality;
  tempo: TempoLevel;
  formation: FormationId;
  yellowCount: Map<string, number>;
  sentOff: Map<string, number>; // playerId → минута удаления
  injuredAt: Map<string, number>; // playerId → минута травмы
  subOutAt: Map<string, number>; // playerId → минута схода (замена)
  subInAt: Map<string, number>; // playerId → минута входа
  subInSeg: Map<string, number>; // playerId → сегмент входа
  subsUsed: number;
  shortHanded: number[]; // минуты незаменённых травм (дефицит λ×0.93)
  events: MatchEvent[];
  subs: SubRecord[];
  /** λ-состав текущего сегмента (XI + замены, влияющие на λ с этого сегмента). */
  lamLineup: (string | null)[];
  /** Все замены (вынужденные + КТ) — для восстановления поля на минуту m. */
  mutations: SubMutation[];
  /** Жёлтые, породившие красную, — не отбрасываются как «призрачные». */
  protectedYellows: Set<MatchEvent>;
}

function buildRuntime(input: MatchTeamInput): TeamRuntime {
  const byId = new Map(input.players.map((p) => [p.id, p]));
  const originalLineup = [...input.lineup];
  const starters = input.lineup
    .map((id) => (id ? byId.get(id) : undefined))
    .filter((p): p is PlayerLike => !!p);
  const starterIds = new Set(starters.map((p) => p.id));
  const benchIds =
    input.bench ?? input.players.filter((p) => !starterIds.has(p.id)).map((p) => p.id);
  const benchPool = benchIds
    .map((id) => byId.get(id))
    .filter((p): p is PlayerLike => !!p && p.injuryWeeks === 0);
  const style = input.coach ? AI_STYLES[input.coach.style] : AI_STYLES.balanced;
  const plan = input.coach?.plan ?? aiDefaultPlan();
  return {
    input,
    style,
    plan,
    byId,
    originalLineup,
    starters,
    benchPool,
    mentality: input.mentality,
    tempo: input.tempo,
    formation: input.formation,
    yellowCount: new Map(),
    sentOff: new Map(),
    injuredAt: new Map(),
    subOutAt: new Map(),
    subInAt: new Map(),
    subInSeg: new Map(),
    subsUsed: 0,
    shortHanded: [],
    events: [],
    subs: [],
    lamLineup: [...originalLineup],
    mutations: [],
    protectedYellows: new Set(),
  };
}

/** На поле ли игрок на минуте m (удаление / травма / замена). */
function isOnField(t: TeamRuntime, p: PlayerLike, minute: number): boolean {
  const red = t.sentOff.get(p.id);
  if (red !== undefined && red <= minute) return false;
  const injury = t.injuredAt.get(p.id);
  if (injury !== undefined && injury <= minute) return false;
  const out = t.subOutAt.get(p.id);
  if (out !== undefined && out <= minute) return false;
  return true;
}

/** Действующие лица на минуте m: стартёры (минус ушедшие) + вышедшие на замену. */
function fieldPlayersAt(t: TeamRuntime, minute: number): PlayerLike[] {
  const out: PlayerLike[] = [];
  for (const p of t.starters) {
    if (isOnField(t, p, minute)) out.push(p);
  }
  for (const [id, m] of t.subInAt) {
    if (m > minute) continue;
    const p = t.byId.get(id);
    // вышедшие не карточатся (карточки генерируются заранее только стартёрам)
    if (p) out.push(p);
  }
  return out;
}

/** Состав «на поле» на минуту m: стартовая XI + все замены с minute ≤ m (хронологически). */
function fieldLineupAt(t: TeamRuntime, minute: number): (string | null)[] {
  const lineup = [...t.originalLineup];
  const muts = [...t.mutations].sort((a, b) => a.minute - b.minute);
  for (const m of muts) {
    if (m.minute <= minute && lineup[m.slot] === m.outId) lineup[m.slot] = m.inId;
  }
  return lineup;
}

/** Виртуальная готовность на сегмент k (для КТ и λ-состояния сегмента). */
function effCondOfAt(t: TeamRuntime, playerId: string, k: number): number {
  const p = t.byId.get(playerId);
  if (!p) return 100;
  const drain = PER_SEGMENT_COND_DRAIN + t.style.condDrainPerSegment;
  const inSeg = t.subInSeg.get(playerId);
  if (inSeg !== undefined) {
    return Math.max(
      COND_EFF_FLOOR,
      Math.min(p.condition, SUB_IN_CONDITION_CAP) - drain * Math.max(0, k - inSeg),
    );
  }
  return Math.max(COND_EFF_FLOOR, p.condition - drain * k);
}

/** Виртуальное тактическое состояние сегмента k: клоны игроков с effCond, текущая тактика. */
function segmentStateOf(t: TeamRuntime, k: number): TeamTacticState {
  const players: PlayerLike[] = [];
  const lineup: (string | null)[] = [...t.lamLineup];
  for (let i = 0; i < lineup.length; i++) {
    const id = lineup[i];
    if (!id) continue;
    const p = t.byId.get(id);
    if (!p) {
      lineup[i] = null;
      continue;
    }
    players.push({ ...p, condition: effCondOfAt(t, id, k) });
  }
  return {
    teamId: t.input.teamId,
    players,
    formation: t.formation,
    mentality: t.mentality,
    tempo: t.tempo,
    pressing: t.input.pressing,
    defLine: t.input.defLine,
    playStyle: t.input.playStyle,
    lineup,
  };
}

function avgAggression(starters: PlayerLike[]): number {
  if (starters.length === 0) return 50;
  return starters.reduce((s, p) => s + p.aggression, 0) / starters.length;
}

function scorerWeight(p: PlayerLike): number {
  const group: PositionGroup = positionGroupOf(p.position);
  const bonus = group === 'ST' ? 20 : group === 'AM' ? 10 : group === 'MID' ? 0 : -30;
  return Math.max(1, p.finishing + bonus);
}

// ── Карточки и травмы (шаг 1 — на весь матч вперёд) ──────────────────────

function processCards(rng: RNG, t: TeamRuntime, oppPressingHigh: boolean): void {
  const lambda =
    YELLOW_LAMBDA_BASE +
    avgAggression(t.starters) / YELLOW_LAMBDA_AGGR_DIV +
    (t.input.pressing === 'high' ? YELLOW_PRESSING_BONUS : 0) +
    t.style.yellowLambdaBonus +
    (oppPressingHigh ? t.style.yellowVsPressingHigh : 0);
  const yellowCount = Math.min(samplePoisson(rng, lambda), YELLOW_CAP);

  for (let i = 0; i < yellowCount; i++) {
    const pool = t.starters.filter((p) => !t.sentOff.has(p.id));
    if (pool.length === 0) break;
    const author = pickWeighted(
      rng,
      pool.map((p) => ({ item: p, weight: Math.max(1, p.aggression) })),
    );
    const minute = randInt(rng, 10, 88);
    const prev = t.yellowCount.get(author.id) ?? 0;
    t.yellowCount.set(author.id, prev + 1);
    const yellowEvent: MatchEvent = {
      minute,
      type: 'yellow',
      teamId: t.input.teamId,
      playerId: author.id,
      playerName: fullName(author),
      text: pick(rng, YELLOW_TEMPLATES).replace('{player}', fullName(author)),
    };
    t.events.push(yellowEvent);
    if (prev + 1 >= 2) {
      t.protectedYellows.add(yellowEvent); // породила красную — не фильтровать
      t.sentOff.set(author.id, minute);
      t.events.push({
        minute,
        type: 'red',
        teamId: t.input.teamId,
        playerId: author.id,
        playerName: fullName(author),
        text: pick(rng, SECOND_YELLOW_TEMPLATES).replace('{player}', fullName(author)),
      });
    }
  }

  // Прямая красная
  if (rng() < RED_CARD_PROB) {
    const pool = t.starters.filter((p) => !t.sentOff.has(p.id));
    if (pool.length > 0) {
      const author = pickWeighted(
        rng,
        pool.map((p) => ({ item: p, weight: Math.max(1, p.aggression) })),
      );
      const minute = randInt(rng, 20, 80);
      if ((t.yellowCount.get(author.id) ?? 0) >= 1) {
        // вторая жёлтая: сначала фиксируется жёлтая на той же минуте
        t.yellowCount.set(author.id, (t.yellowCount.get(author.id) ?? 0) + 1);
        const yellowEvent: MatchEvent = {
          minute,
          type: 'yellow',
          teamId: t.input.teamId,
          playerId: author.id,
          playerName: fullName(author),
          text: pick(rng, YELLOW_TEMPLATES).replace('{player}', fullName(author)),
        };
        t.events.push(yellowEvent);
        t.protectedYellows.add(yellowEvent);
      }
      t.sentOff.set(author.id, minute);
      t.events.push({
        minute,
        type: 'red',
        teamId: t.input.teamId,
        playerId: author.id,
        playerName: fullName(author),
        text: pick(rng, RED_TEMPLATES).replace('{player}', fullName(author)),
      });
    }
  }
}

function processInjuries(rng: RNG, t: TeamRuntime, injuries: MatchInjury[]): void {
  const avgCond =
    t.starters.length > 0
      ? t.starters.reduce((s, p) => s + p.condition, 0) / t.starters.length
      : 100;
  const mult = avgCond < 65 ? t.style.injuryProbMult : 1;
  // D-5: медицинский центр клуба игрока снижает риск (§3.5)
  const medRiskMult = t.input.medRiskMult ?? 1;
  if (rng() >= INJURY_PROB * mult * medRiskMult) return;
  const pool = t.starters.filter((p) => !t.sentOff.has(p.id));
  if (pool.length === 0) return;
  const victim = pickWeighted(
    rng,
    pool.map((p) => ({ item: p, weight: 1 / (p.stamina + 10) })),
  );
  const minute = randInt(rng, 5, 85);
  const weeks = randInt(rng, 1, 5);
  t.injuredAt.set(victim.id, minute);
  injuries.push({ teamId: t.input.teamId, playerId: victim.id, weeks });
  t.events.push({
    minute,
    type: 'injury',
    teamId: t.input.teamId,
    playerId: victim.id,
    playerName: fullName(victim),
    text: `${pick(rng, INJURY_TEMPLATES).replace('{player}', fullName(victim))} Выбыл на ${weeks} ${pluralTours(weeks)}.`,
  });
}

// ── Замены ───────────────────────────────────────────────────────────────

/** Записать замену: карты сходов/выходов, событие 'sub', мутация λ-линейки. */
function applySub(
  rng: RNG,
  t: TeamRuntime,
  minute: number,
  outId: string,
  inId: string,
  slot: number,
  reason: SubRecord['reason'],
  segFrom: number,
  applyToLambdaNow: boolean,
): void {
  t.subOutAt.set(outId, minute);
  t.subInAt.set(inId, minute);
  t.subInSeg.set(inId, segIndexOf(minute));
  t.subsUsed += 1;
  t.subs.push({ outId, inId, minute, reason });
  t.mutations.push({ minute, slot, outId, inId, segFrom });
  if (applyToLambdaNow) t.lamLineup[slot] = inId;
  const outP = t.byId.get(outId);
  const inP = t.byId.get(inId);
  const text =
    reason === 'injury'
      ? SUB_TEMPLATES[SUB_FORCED_INDEX]
      : pick(rng, TACTICAL_SUB_TEMPLATES);
  t.events.push({
    minute,
    type: 'sub',
    teamId: t.input.teamId,
    playerId: inId,
    playerName: inP ? fullName(inP) : inId,
    subOutId: outId,
    subOutName: outP ? fullName(outP) : outId,
    text: text
      .replace('{player}', inP ? fullName(inP) : inId)
      .replace('{out}', outP ? fullName(outP) : outId),
  });
}

/** Вынужденные замены травмированных (шаг 2): лучший под слот из запаса, иначе дефицит. */
function forcedInjurySubs(rng: RNG, t: TeamRuntime): void {
  const sorted = [...t.injuredAt.entries()].sort((a, b) => a[1] - b[1]);
  for (const [victimId, minute] of sorted) {
    if (t.subsUsed >= SUB_MAX || t.benchPool.length === 0) {
      t.shortHanded.push(minute);
      continue;
    }
    const slot = t.originalLineup.indexOf(victimId);
    if (slot < 0) {
      t.shortHanded.push(minute);
      continue;
    }
    const used = new Set(t.subInAt.keys());
    const candidates = t.benchPool.filter((p) => !used.has(p.id));
    if (candidates.length === 0) {
      t.shortHanded.push(minute);
      continue;
    }
    const inP = pickWeighted(
      rng,
      candidates.map((p) => ({
        item: p,
        weight: Math.max(1, slotScore(p, FORMATIONS[t.input.formation].slots[slot].position)),
      })),
    );
    // λ — со следующего сегмента (сегмент входа уже «сыгран» жертвой)
    applySub(rng, t, minute, victimId, inP.id, slot, 'injury', Math.min(segIndexOf(minute) + 1, SEGMENTS_COUNT), false);
  }
}

/** Применить к λ-линейке вынужденные замены, вступающие в силу с сегмента k. */
function applyDueForced(t: TeamRuntime, k: number): void {
  for (const m of t.mutations) {
    if (m.segFrom === k && t.lamLineup[m.slot] === m.outId) {
      t.lamLineup[m.slot] = m.inId;
    }
  }
}

// ── Контрольные точки (шаг 3а) ───────────────────────────────────────────

interface ModeState {
  active: boolean;
  minute: number;
}

/** Ушедшие с поля к моменту КТ + «скрытые» будущие события (анти-«призраки»). */
function offPitchAt(t: TeamRuntime, cp: number): Set<string> {
  const out = new Set<string>([...t.sentOff.keys(), ...t.injuredAt.keys()]);
  for (const e of t.events) {
    if (e.type === 'yellow' && e.playerId && e.minute > cp) out.add(e.playerId);
  }
  return out;
}

function coachSideOf(
  t: TeamRuntime,
  k: number,
  cp: number,
  scored: number,
  conceded: number,
): CoachSideState {
  const byId: Map<string, LineupPlayer> = t.byId;
  return {
    teamId: t.input.teamId,
    style: t.style,
    plan: t.plan,
    mentality: t.mentality,
    tempo: t.tempo,
    formation: t.formation,
    onField: fieldLineupAt(t, cp),
    bench: t.benchPool,
    byId,
    offPitch: offPitchAt(t, cp),
    subsUsed: t.subsUsed,
    scored,
    conceded,
    effCondOf: (playerId: string) => effCondOfAt(t, playerId, k),
  };
}

/** Исполнить решение тренера: менталитет/темп, замены, 3-4-3, режимы λ. */
function applyDecision(
  rng: RNG,
  k: number,
  cp: number,
  t: TeamRuntime,
  oppRt: TeamRuntime,
  dec: ReturnType<typeof coachDecide>,
  park: ModeState,
  chase: ModeState,
): void {
  void oppRt;
  if (dec.mentalityShift !== 0) {
    const idx = MENTALITY_ORDER.indexOf(t.mentality);
    t.mentality = MENTALITY_ORDER[clamp(idx + dec.mentalityShift, 0, MENTALITY_ORDER.length - 1)];
  }
  if (dec.tempoLow) t.tempo = 'low';
  if (dec.tempoHigh) t.tempo = 'high';

  const field = fieldLineupAt(t, cp);
  for (const sub of dec.subs) {
    const slot = field.indexOf(sub.outId);
    if (slot < 0) continue;
    applySub(rng, t, cp, sub.outId, sub.inId, slot, sub.reason, k, true);
    field[slot] = sub.inId;
  }

  if (dec.formationSwitch) {
    t.formation = dec.formationSwitch;
    t.lamLineup = remapForFormation(fieldLineupAt(t, cp), t.input.players, dec.formationSwitch);
    t.events.push({
      minute: cp,
      type: 'chance',
      teamId: t.input.teamId,
      text: pick(rng, FORMATION_SHIFT_TEMPLATES).replace('{team}', t.input.name),
    });
  }

  if (dec.parkBus) {
    park.active = true;
    park.minute = t.style.parkBusMinute;
  }
  if (dec.chase) {
    chase.active = true;
    chase.minute = t.style.chaseMinute;
  }
}

// ── Голы и моменты сегмента (шаг 3в) ─────────────────────────────────────

function addSegmentGoals(
  rng: RNG,
  t: TeamRuntime,
  k: number,
  count: number,
  onGoal: () => void,
): void {
  for (let i = 0; i < count; i++) {
    const minute = randInt(rng, SEG_START[k], SEG_END[k]);
    const pool = fieldPlayersAt(t, minute);
    if (pool.length === 0) continue;
    const scorer = pickWeighted(
      rng,
      pool.map((p) => ({ item: p, weight: scorerWeight(p) })),
    );
    let assist: PlayerLike | null = null;
    if (rng() < 0.5) {
      const assistPool = pool.filter((p) => p.id !== scorer.id);
      if (assistPool.length > 0) {
        assist = pickWeighted(
          rng,
          assistPool.map((p) => ({ item: p, weight: Math.max(1, p.passing) })),
        );
      }
    }
    let text = pick(rng, GOAL_TEMPLATES).replace('{player}', fullName(scorer));
    if (assist) text += ` Пас — ${fullName(assist)}.`;
    t.events.push({
      minute,
      type: 'goal',
      teamId: t.input.teamId,
      playerId: scorer.id,
      playerName: fullName(scorer),
      assistId: assist?.id,
      assistName: assist ? fullName(assist) : undefined,
      text,
    });
    onGoal();
  }
}

function addSegmentChances(
  rng: RNG,
  t: TeamRuntime,
  k: number,
  lambdaSeg: number,
  goals: number,
): void {
  const shotsBase = clamp(Math.round(4 + lambdaSeg * 7), 3, 25);
  const count = Math.max(
    0,
    Math.round(
      (shotsBase - goals - 2) * 0.5 * TEMPO_CHANCE_MOD[t.tempo] * t.style.chanceCountMult,
    ),
  );
  for (let i = 0; i < count; i++) {
    const minute = randInt(rng, SEG_START[k], SEG_END[k]);
    const pool = fieldPlayersAt(t, minute);
    if (pool.length === 0) continue;
    const author = pickWeighted(
      rng,
      pool.map((p) => ({ item: p, weight: Math.max(1, p.finishing + 10) })),
    );
    t.events.push({
      minute,
      type: 'chance',
      teamId: t.input.teamId,
      playerId: author.id,
      playerName: fullName(author),
      text: pick(rng, CHANCE_TEMPLATES).replace('{player}', fullName(author)),
    });
  }
}

/** Отбросить «призрачные» жёлтые: автор уже сошёл (незамещённая травма) до минуты карточки. */
function dropGhostYellows(t: TeamRuntime): void {
  t.events = t.events.filter((e) => {
    if (e.type !== 'yellow' || !e.playerId || t.protectedYellows.has(e)) return true;
    const out = t.subOutAt.get(e.playerId);
    return !(out !== undefined && out <= e.minute);
  });
}

// ── Полный движок ────────────────────────────────────────────────────────

/**
 * Полный сегментный движок матча клуба игрока. opts.neutral — нейтральное поле
 * (финал кубка): домашнее преимущество ×1.0.
 */
export function simulateMatch(
  rng: RNG,
  home: MatchTeamInput,
  away: MatchTeamInput,
  opts?: { neutral?: boolean },
): MatchResult {
  const rtH = buildRuntime(home);
  const rtA = buildRuntime(away);
  const injuries: MatchInjury[] = [];

  // 1. Карточки и травмы — на весь матч вперёд (порядок RNG: home → away)
  processCards(rng, rtH, away.pressing === 'high');
  processCards(rng, rtA, home.pressing === 'high');
  processInjuries(rng, rtH, injuries);
  processInjuries(rng, rtA, injuries);

  // 2. Вынужденные замены при травмах (home по минутам, затем away)
  forcedInjurySubs(rng, rtH);
  forcedInjurySubs(rng, rtA);

  // 3. Цикл сегментов
  let scoreH = 0;
  let scoreA = 0;
  const parkH: ModeState = { active: false, minute: SEG_END[2] };
  const parkA: ModeState = { active: false, minute: SEG_END[2] };
  const chaseH: ModeState = { active: false, minute: SEG_END[2] };
  const chaseA: ModeState = { active: false, minute: SEG_END[2] };
  let lambdaSumH = 0;
  let lambdaSumA = 0;
  let possessionHome = 50;

  for (let k = 0; k < SEGMENTS_COUNT; k++) {
    // 3а. Контрольные точки перед сегментами 2 и 3 (home решает первым)
    if (k === 1 || k === 2) {
      const cp: 46 | 70 = k === 1 ? 46 : 70;
      applyDueForced(rtH, k);
      applyDueForced(rtA, k);
      const decH = coachDecide(rng, cp, coachSideOf(rtH, k, cp, scoreH, scoreA), away.defLine);
      const decA = coachDecide(rng, cp, coachSideOf(rtA, k, cp, scoreA, scoreH), home.defLine);
      applyDecision(rng, k, cp, rtH, rtA, decH, parkH, chaseH);
      applyDecision(rng, k, cp, rtA, rtH, decA, parkA, chaseA);
    }

    // 3б. λ сегмента: модификаторы на виртуальных состояниях + стиль-дельты
    const mods = applyModifiers(segmentStateOf(rtH, k), segmentStateOf(rtA, k), opts);
    if (k === 0) {
      possessionHome = clamp(
        Math.round(
          50 +
            1.2 *
              (mods.home.effMid * rtH.style.midDelta -
                mods.away.effMid * rtA.style.midDelta),
        ) +
          rtH.style.possessionBonus -
          rtA.style.possessionBonus,
        25,
        75,
      );
    }
    const atkH =
      mods.home.effAtk *
      rtH.style.atkDelta *
      (rtH.style.verticalVsHighLine && away.defLine === 'high' ? 1.05 : 1);
    const defH = mods.home.effDef * rtH.style.defDelta;
    const atkA =
      mods.away.effAtk *
      rtA.style.atkDelta *
      (rtA.style.verticalVsHighLine && home.defLine === 'high' ? 1.05 : 1);
    const defA = mods.away.effDef * rtA.style.defDelta;
    const lambdaFullH = clamp((BASE_GOALS * atkH) / defA, LAMBDA_MIN, LAMBDA_MAX);
    const lambdaFullA = clamp((BASE_GOALS * atkA) / defH, LAMBDA_MIN, LAMBDA_MAX);

    // время-взвешенные факторы сегмента
    let fH = SEGMENT_SHARES[k];
    let fA = SEGMENT_SHARES[k];
    for (const m of rtH.sentOff.values()) {
      const mul = redMulOf(m);
      fH *= segFactor(m, k, mul.self);
      fA *= segFactor(m, k, mul.opp);
    }
    for (const m of rtA.sentOff.values()) {
      const mul = redMulOf(m);
      fA *= segFactor(m, k, mul.self);
      fH *= segFactor(m, k, mul.opp);
    }
    for (const m of rtH.shortHanded) fH *= segFactor(m, k, SHORT_HANDED_LAMBDA_MOD);
    for (const m of rtA.shortHanded) fA *= segFactor(m, k, SHORT_HANDED_LAMBDA_MOD);
    if (parkH.active) {
      fH *= segFactor(parkH.minute, k, PARKING_BUS_MOD.self);
      fA *= segFactor(parkH.minute, k, PARKING_BUS_MOD.opp);
    }
    if (parkA.active) {
      fA *= segFactor(parkA.minute, k, PARKING_BUS_MOD.self);
      fH *= segFactor(parkA.minute, k, PARKING_BUS_MOD.opp);
    }
    if (chaseH.active) {
      fH *= segFactor(chaseH.minute, k, CHASE_MOD.self);
      fA *= segFactor(chaseH.minute, k, CHASE_MOD.opp);
    }
    if (chaseA.active) {
      fA *= segFactor(chaseA.minute, k, CHASE_MOD.self);
      fH *= segFactor(chaseA.minute, k, CHASE_MOD.opp);
    }

    const lambdaH = clamp(lambdaFullH * fH, 0, LAMBDA_MAX);
    const lambdaA = clamp(lambdaFullA * fA, 0, LAMBDA_MAX);
    lambdaSumH += lambdaH;
    lambdaSumA += lambdaA;

    // 3в. Голы сегмента (Пуассон home → away; детали home → away)
    const goalsH = samplePoisson(rng, lambdaH);
    const goalsA = samplePoisson(rng, lambdaA);
    addSegmentGoals(rng, rtH, k, goalsH, () => {
      scoreH += 1;
    });
    addSegmentGoals(rng, rtA, k, goalsA, () => {
      scoreA += 1;
    });
    addSegmentChances(rng, rtH, k, lambdaH, goalsH);
    addSegmentChances(rng, rtA, k, lambdaA, goalsA);
  }

  // 3г. Чистка «призрачных» жёлчных (автор сошёл раньше минуты карточки)
  dropGhostYellows(rtH);
  dropGhostYellows(rtA);

  // 3д. Статистика
  const shotsHome = clamp(Math.round(4 + lambdaSumH * 7) + rtH.style.shotsBonus, 3, 25);
  const shotsAway = clamp(Math.round(4 + lambdaSumA * 7) + rtA.style.shotsBonus, 3, 25);
  const sotHome = Math.max(
    scoreH,
    Math.round(shotsHome * (0.35 + rng() * 0.2 + rtH.style.sotShareDelta)),
  );
  const sotAway = Math.max(
    scoreA,
    Math.round(shotsAway * (0.35 + rng() * 0.2 + rtA.style.sotShareDelta)),
  );
  const yellowsHome = rtH.events.filter((e) => e.type === 'yellow').length;
  const yellowsAway = rtA.events.filter((e) => e.type === 'yellow').length;
  const redsHome = rtH.events.filter((e) => e.type === 'red').length;
  const redsAway = rtA.events.filter((e) => e.type === 'red').length;

  const stats: MatchStats = {
    possessionHome,
    shotsHome,
    shotsAway,
    sotHome,
    sotAway,
    cornersHome: Math.round(shotsHome * 0.45),
    cornersAway: Math.round(shotsAway * 0.45),
    foulsHome: Math.max(randInt(rng, 8, 16), yellowsHome * 4),
    foulsAway: Math.max(randInt(rng, 8, 16), yellowsAway * 4),
    yellowsHome,
    yellowsAway,
    redsHome,
    redsAway,
  };

  // 4. Рамки ленты + стабильная сортировка (minute, TYPE_ORDER)
  const events: MatchEvent[] = [
    { minute: 0, type: 'kickoff', text: KICKOFF_TEXT },
    ...rtH.events,
    ...rtA.events,
    { minute: SEG_END[0], type: 'halftime', text: HALFTIME_TEXT },
    { minute: SEG_END[2], type: 'fulltime', text: FULLTIME_TEXT },
  ];
  events.sort((a, b) => a.minute - b.minute || TYPE_ORDER[a.type] - TYPE_ORDER[b.type]);

  return {
    homeGoals: scoreH,
    awayGoals: scoreA,
    events,
    stats,
    homeStarters: [...home.lineup],
    awayStarters: [...away.lineup],
    homeSubs: rtH.subs,
    awaySubs: rtA.subs,
    injuries,
  };
}

// ── Упрощённый движок для ИИ-матчей ──────────────────────────────────────

export interface AiTeamInput {
  teamId: string;
  name: string;
  strength: number;
  players: PlayerLike[]; // авторы голов, взвешенно по OVR
  /** Фаза 4: стиль тренера (λ-дельты); отсутствует → balanced. */
  aiStyle?: AiStyleCode;
}

export interface AiMatchResult {
  homeGoals: number;
  awayGoals: number;
  events: MatchEvent[]; // только голы
}

/**
 * ИИ-матч: односэмпльный Пуассон (тактический ИИ и сегментация НЕ
 * распространяются — research §1.4), стиль-дельты λ, минуты голов по
 * сегментным долям. Карточки/травмы не моделируются (как раньше).
 */
export function simulateAiMatch(
  rng: RNG,
  home: AiTeamInput,
  away: AiTeamInput,
  opts?: { neutral?: boolean },
): AiMatchResult {
  const shHome = clamp(home.strength + gauss(rng, 0, 3), 30, 95) * (opts?.neutral ? 1 : HOME_ADVANTAGE);
  const shAway = clamp(away.strength + gauss(rng, 0, 3), 30, 95);
  const styleH = AI_STYLES[home.aiStyle ?? 'balanced'];
  const styleA = AI_STYLES[away.aiStyle ?? 'balanced'];
  const lambdaHome = clamp((BASE_GOALS * shHome * styleH.atkDelta) / (shAway * styleA.defDelta), LAMBDA_MIN, LAMBDA_MAX);
  const lambdaAway = clamp((BASE_GOALS * shAway * styleA.atkDelta) / (shHome * styleH.defDelta), LAMBDA_MIN, LAMBDA_MAX);
  const homeGoals = samplePoisson(rng, lambdaHome);
  const awayGoals = samplePoisson(rng, lambdaAway);

  const events: MatchEvent[] = [];
  const addGoals = (t: AiTeamInput, count: number) => {
    if (t.players.length === 0) return;
    for (let i = 0; i < count; i++) {
      const minute = segmentGoalMinute(rng);
      const author = pickWeighted(
        rng,
        t.players.map((p) => ({ item: p, weight: Math.max(1, p.ovr) })),
      );
      events.push({
        minute,
        type: 'goal',
        teamId: t.teamId,
        playerId: author.id,
        playerName: fullName(author),
        text: `${pick(rng, GOAL_TEMPLATES).replace('{player}', fullName(author))} (${t.name})`,
      });
    }
  };
  addGoals(home, homeGoals);
  addGoals(away, awayGoals);
  events.sort((a, b) => a.minute - b.minute);

  return { homeGoals, awayGoals, events };
}

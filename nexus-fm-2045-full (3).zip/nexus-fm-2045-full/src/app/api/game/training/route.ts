import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolvePlayingSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import {
  TRAIN_CONDITION_DELTA, TRAIN_INJURY_RISK, TRAIN_INTENSITY_FACTOR,
  TRAIN_REST_COND, TRAIN_REST_MORALE,
} from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import type { PlayerLike } from '@/lib/game/players';
import {
  FOCUS_ATTRS, TRAINING_FOCUS_LABELS, TRAINING_INTENSITY_LABELS,
  attrsForPlayer, coerceTrainingFocus, coerceTrainingIntensity,
} from '@/lib/game/training';
import { ATTR_LABELS, parseTrainingXp } from '@/lib/game/types';
import type {
  AttrKey, Position, TrainingFocus, TrainingHintsDTO, TrainingIntensity,
  TrainingPlayerDTO, TrainingStateDTO,
} from '@/lib/game/types';

const TRAINING_FOCUS_CODES: TrainingFocus[] = [
  'attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest',
];
const TRAINING_INTENSITY_CODES: TrainingIntensity[] = ['light', 'normal', 'hard'];

const bodySchema = z.object({
  saveId: z.string().min(1),
  focus: z.enum(['attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest']),
  intensity: z.enum(['light', 'normal', 'hard']),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/** Подсказки эффектов: подписи фокусов/интенсивностей + числовые эффекты. */
function trainingHints(): TrainingHintsDTO {
  return {
    focuses: TRAINING_FOCUS_CODES.map((code) => ({
      code,
      label: TRAINING_FOCUS_LABELS[code],
      attrLabels: FOCUS_ATTRS[code].map((attr) => ATTR_LABELS[attr]),
    })),
    intensities: TRAINING_INTENSITY_CODES.map((code) => ({
      code,
      label: TRAINING_INTENSITY_LABELS[code],
      growthFactor: TRAIN_INTENSITY_FACTOR[code],
      conditionDelta: TRAIN_CONDITION_DELTA[code],
      injuryRiskPct: Math.round(TRAIN_INJURY_RISK[code] * 1000) / 10,
    })),
    restConditionBonus: TRAIN_REST_COND,
    restMoraleBonus: TRAIN_REST_MORALE,
  };
}

/** GET /api/game/training?saveId= — состояние тренировки клуба игрока + состав. §4.7. */
export async function GET(request: Request) {
  try {
    const saveId = saveIdFromQuery(request);
    if (!saveId) return fail('INVALID_PAYLOAD', 400);
    const save = await resolvePlayingSave(saveId);

    const team = await db.team.findUnique({ where: { id: save.teamId } });
    if (!team) return fail('SAVE_NOT_FOUND', 404);

    const squad = await db.player.findMany({
      where: { saveId: save.id, teamId: team.id },
      orderBy: [{ ovr: 'desc' }, { shirtNumber: 'asc' }],
    });

    const training: TrainingStateDTO = {
      focus: coerceTrainingFocus(team.trainingFocus),
      intensity: coerceTrainingIntensity(team.trainingIntensity),
    };

    // xp — только по атрибутам ТЕКУЩЕГО фокуса (+ GK-атрибуты для вратарей)
    const squadDto: TrainingPlayerDTO[] = squad.map((p) => {
      const xp = parseTrainingXp(p.trainingXp);
      const attrs = attrsForPlayer(p as unknown as PlayerLike, training.focus);
      const filtered: Partial<Record<AttrKey, number>> = {};
      for (const attr of attrs) {
        filtered[attr] = xp[attr] ?? 0;
      }
      return {
        id: p.id,
        firstName: p.firstName,
        lastName: p.lastName,
        position: p.position as Position,
        age: p.age,
        ovr: p.ovr,
        potential: p.potential,
        morale: p.morale,
        condition: p.condition,
        injuryWeeks: p.injuryWeeks,
        trainingXp: filtered,
        individual: null, // Модуль 4: серверное зеркало — только командная программа
      };
    });

    return NextResponse.json({
      ok: true,
      training,
      squad: squadDto,
      hints: trainingHints(),
    });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/training GET]', error);
    return fail('UNKNOWN', 500);
  }
}

/**
 * POST /api/game/training — установить фокус и интенсивность тренировки.
 * Настройки сработают в ближайший simulateWeek. §4.7.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('INVALID_TRAINING', 400);

    const save = await resolvePlayingSave(parsed.data.saveId);
    const { focus, intensity } = parsed.data;

    await db.team.update({
      where: { id: save.teamId },
      data: { trainingFocus: focus, trainingIntensity: intensity },
    });

    return NextResponse.json({ ok: true, training: { focus, intensity } });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/training POST]', error);
    return fail('UNKNOWN', 500);
  }
}

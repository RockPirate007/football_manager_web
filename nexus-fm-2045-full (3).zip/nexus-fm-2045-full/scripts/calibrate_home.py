#!/usr/bin/env python3
"""Калибровка HOME_ADVANTAGE (фикс QA-5).

Механика обоих движков (полного и ИИ) при равных командах:
  λ_home = BASE_GOALS × HA          (эффект: atk/def/mid × HA, затем деление)
  λ_away = BASE_GOALS / HA
  → отношение λ = HA²

Цель по исследованию (Task 2-a): домашние победы 46–49%, ничьи ~26%.
Скрипт перебирает HA и считает точные вероятности исходов матча
через свёртку двух распределений Пуассона (k ≤ 20).
"""
from math import exp, factorial

BASE_GOALS = 1.35


def poisson_pmf(lmb: float, k: int) -> float:
    return exp(-lmb) * lmb**k / factorial(k)


def match_outcomes(lh: float, la: float) -> tuple[float, float, float]:
    """Возвращает (P_win_home, P_draw, P_win_away) для X~Pois(lh), Y~Pois(la)."""
    KMAX = 20
    ph = [poisson_pmf(lh, k) for k in range(KMAX + 1)]
    pa = [poisson_pmf(la, k) for k in range(KMAX + 1)]
    win = sum(ph[k] * sum(pa[:k]) for k in range(KMAX + 1))
    draw = sum(ph[k] * pa[k] for k in range(KMAX + 1))
    return win, draw, 1.0 - win - draw


print(f"{'HA':>5} {'λh':>6} {'λa':>6} {'P(home)':>8} {'P(draw)':>8} {'P(away)':>8}")
print("-" * 48)

best = None
for i in range(0, 31):  # HA от 1.00 до 1.30, шаг 0.01
    ha = 1.00 + i * 0.01
    lh = BASE_GOALS * ha
    la = BASE_GOALS / ha
    w, d, l = match_outcomes(lh, la)
    mark = ""
    if 0.455 <= w <= 0.475:
        mark = "  ← цель ~46–47%"
        if best is None:
            best = ha
    print(f"{ha:>5.2f} {lh:>6.3f} {la:>6.3f} {w:>8.1%} {d:>8.1%} {l:>8.1%}{mark}")

print()
if best:
    lh = BASE_GOALS * best
    la = BASE_GOALS / best
    w, d, l = match_outcomes(lh, la)
    print(f"РЕКОМЕНДАЦИЯ: HOME_ADVANTAGE = {best}")
    print(f"  Итог: дома {w:.1%}, ничьи {d:.1%}, в гостях {l:.1%}")
    print(f"  Отношение λ = {best**2:.3f}")
else:
    print("Целевой диапазон не достигнут — расширить перебор")

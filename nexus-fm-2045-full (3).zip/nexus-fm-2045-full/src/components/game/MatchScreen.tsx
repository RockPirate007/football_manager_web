'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Bed, ChevronDown, ChevronRight, Clock, FastForward, Globe, ListChecks, Loader2, Maximize2, Play,
  Ticket, Trophy, Type, Wallet,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { MatchRadar } from '@/components/game/MatchRadar';
import { MatchTimeline } from '@/components/game/MatchTimeline';
import { CoachStyleBadge } from '@/components/game/shared/CoachStyleBadge';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { PositionBadge } from '@/components/game/shared/PositionBadge';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import {
  EURO_ROUND_LABELS, EURO_WEEKS, FORMATIONS, MATCH_PLAN_DEFAULT, MATCH_PLAN_LABELS,
} from '@/lib/game/constants';
import { formatMoney } from '@/lib/game/format';
import { effectiveLineup } from '@/lib/game/lineup';
import { MENTALITY_LABELS } from '@/lib/game/types';
import type {
  MatchEvent, MatchPlanDTO, Position, TeamBriefDTO, UserMatchResultDTO, WeekFinancesDTO,
} from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Базовая скорость: 300 мс за игровую минуту. */
const BASE_TICK_MS = 300;

/** Метка еврораунда по номеру недели (EURO_WEEKS лиги размера N) или null. */
function euroRoundLabelOf(week: number, teamCount: number): string | null {
  const weeks = EURO_WEEKS[teamCount];
  if (!weeks) return null;
  const idx = weeks.indexOf(week);
  return idx >= 0 ? EURO_ROUND_LABELS[idx] : null;
}

/** Подпись соревнования матча двойной недели: «Кубок · 1/4 финала» / «Кубок Европы · 1/4 финала» / «Тур 10/30». */
function matchCompetitionLabel(
  m: UserMatchResultDTO,
  ctx: { weekLabel: string; week: number; teamCount: number },
): string {
  if (m.competition === 'euro') {
    const round = euroRoundLabelOf(ctx.week, ctx.teamCount);
    return round ? `Кубок Европы · ${round}` : 'Кубок Европы';
  }
  const parts = ctx.weekLabel.split(' · ');
  if (m.competition === 'cup') {
    return parts.length >= 2 ? `${parts[0]} · ${parts[1]}` : 'Кубок';
  }
  return parts[0] ?? 'Лига';
}

function LineupColumn({
  title,
  crest,
  entries,
}: {
  title: string;
  crest: React.ReactNode;
  entries: { ovr: number; name: string; position: Position; rating: number | null }[];
}) {
  return (
    <div className="min-w-0 flex-1 rounded-lg border border-border/60 bg-secondary/30 p-3">
      <div className="mb-2 flex items-center gap-2">
        {crest}
        <span className="truncate text-xs font-semibold">{title}</span>
      </div>
      <ul className="space-y-1">
        {entries.map((p, i) => (
          <li key={i} className="flex items-center gap-2 rounded bg-card/60 px-2 py-1.5">
            <OvrBadge ovr={p.ovr} size="sm" />
            <span className="min-w-0 flex-1 truncate text-xs">{p.name}</span>
            {p.rating !== null ? (
              <span
                className={cn(
                  'tabular text-[10px] font-semibold',
                  p.rating >= 7.2 ? 'text-[#22C55E]' : 'text-muted-foreground',
                )}
                title="Средний рейтинг текущего сезона"
              >
                {p.rating.toFixed(1)}
              </span>
            ) : null}
            <PositionBadge position={p.position} />
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Сегмент-переключатель на 2 опции (план на матч: lead/chase режимы). */
function PlanSegment<T extends string>({
  options,
  value,
  onChange,
  ariaLabel,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  ariaLabel: string;
}) {
  return (
    <div
      className="grid grid-cols-2 gap-1 rounded-lg border border-border/60 bg-secondary/30 p-1"
      role="group"
      aria-label={ariaLabel}
    >
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          role="radio"
          aria-checked={value === opt.value}
          onClick={() => onChange(opt.value)}
          className={cn(
            'min-h-11 rounded-md px-2 text-xs font-medium transition-colors',
            value === opt.value
              ? 'bg-primary/15 text-primary'
              : 'text-muted-foreground hover:text-foreground',
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

/** Карточка «План на матч» (§7.2 ТЗ Фазы 4): свёрнута по умолчанию, сохранение через POST /matchplan.
 *  Локальный draft применяется поверх кеша (кеш приходит из fetchMatchPlan) —
 *  синхронизация без useEffect-setState. */
function MatchPlanCard() {
  const matchPlanCache = useGameStore((s) => s.matchPlanCache);
  const matchPlanSaving = useGameStore((s) => s.matchPlanSaving);
  const fetchMatchPlan = useGameStore((s) => s.fetchMatchPlan);
  const saveMatchPlan = useGameStore((s) => s.saveMatchPlan);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<MatchPlanDTO | null>(null);

  useEffect(() => {
    void fetchMatchPlan();
  }, [fetchMatchPlan]);

  const plan: MatchPlanDTO = draft ?? matchPlanCache ?? { ...MATCH_PLAN_DEFAULT };
  const reference: MatchPlanDTO = matchPlanCache ?? { ...MATCH_PLAN_DEFAULT };
  const dirty =
    draft !== null
    && (draft.leadMode !== reference.leadMode
      || draft.chaseMode !== reference.chaseMode
      || draft.fatigueSubs !== reference.fatigueSubs);
  const update = (patch: Partial<MatchPlanDTO>) => setDraft({ ...plan, ...patch });

  return (
    <Card className="border-border/70">
      <Collapsible open={open} onOpenChange={setOpen}>
        <CardHeader className="pb-2">
          <CollapsibleTrigger asChild>
            <button
              type="button"
              className="flex min-h-11 w-full items-center gap-2 text-left"
              aria-expanded={open}
            >
              <ListChecks className="size-4 text-primary" aria-hidden />
              <CardTitle className="text-sm">План на матч</CardTitle>
              <Badge variant="outline" className="hidden text-[10px] text-muted-foreground sm:inline-flex">
                {MATCH_PLAN_LABELS.lead[plan.leadMode]} · {MATCH_PLAN_LABELS.chase[plan.chaseMode]}
              </Badge>
              <ChevronDown
                className={cn('ml-auto size-4 shrink-0 text-muted-foreground transition-transform', open && 'rotate-180')}
                aria-hidden
              />
            </button>
          </CollapsibleTrigger>
        </CardHeader>
        <CollapsibleContent>
          <CardContent className="space-y-4 pt-1">
            <div>
              <p className="mb-1.5 text-xs font-semibold text-muted-foreground">Ведём к 70-й минуте</p>
              <PlanSegment
                ariaLabel="Режим при лидировании к 70-й минуте"
                options={[
                  { value: 'park' as const, label: MATCH_PLAN_LABELS.lead.park },
                  { value: 'hold' as const, label: MATCH_PLAN_LABELS.lead.hold },
                ]}
                value={plan.leadMode}
                onChange={(leadMode) => update({ leadMode })}
              />
            </div>
            <div>
              <p className="mb-1.5 text-xs font-semibold text-muted-foreground">Отстаём к 70-й минуте</p>
              <PlanSegment
                ariaLabel="Режим при отставании к 70-й минуте"
                options={[
                  { value: 'allout' as const, label: MATCH_PLAN_LABELS.chase.allout },
                  { value: 'steady' as const, label: MATCH_PLAN_LABELS.chase.steady },
                ]}
                value={plan.chaseMode}
                onChange={(chaseMode) => update({ chaseMode })}
              />
            </div>
            <div className="flex min-h-11 items-center justify-between gap-3 rounded-lg border border-border/60 bg-secondary/30 px-3">
              <div className="min-w-0">
                <p className="text-xs font-semibold">Авто-замены уставших</p>
                <p className="text-[10px] text-muted-foreground">
                  Ассистент меняет игроков с низкой готовностью
                </p>
              </div>
              <Switch
                checked={plan.fatigueSubs}
                onCheckedChange={(fatigueSubs) => update({ fatigueSubs })}
                aria-label="Автоматические замены уставших игроков"
              />
            </div>
            <p className="text-[11px] leading-relaxed text-muted-foreground">
              По умолчанию — как тренеры ИИ. Замены выполняет ассистент по плану; состав и скамейка —
              из вкладки «Тактика».
            </p>
            <Button
              className="h-11 w-full"
              onClick={() => void saveMatchPlan(plan)}
              disabled={matchPlanSaving || !dirty}
            >
              {matchPlanSaving ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : null}
              Сохранить план
            </Button>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

function Prematch() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const playWeek = useGameStore((s) => s.playWeek);
  const loading = useGameStore((s) => s.loading);
  const euroCache = useGameStore((s) => s.euroCache);
  const fetchEuro = useGameStore((s) => s.fetchEuro);
  const { nextMatch, nextMatchPreview, myTeam, myPlayers, save } = snapshot;

  // Фаза 4: кеш /euro — соперник/раунд для превью евроматча и плашек отдыха.
  useEffect(() => {
    void fetchEuro();
  }, [fetchEuro]);

  const myXI = useMemo(() => {
    const { lineup } = effectiveLineup(myTeam, myPlayers);
    const byId = new Map(myPlayers.map((p) => [p.id, p]));
    const slots = FORMATIONS[myTeam.formation].slots;
    return lineup
      .map((id, i) => {
        const p = id ? byId.get(id) : undefined;
        if (!p || !slots[i]) return null;
        return {
          ovr: p.ovr,
          name: `${p.firstName} ${p.lastName}`,
          position: slots[i].position,
          rating: p.avgRating,
        };
      })
      .filter(
        (x): x is { ovr: number; name: string; position: Position; rating: number | null } => !!x,
      );
  }, [myTeam, myPlayers]);

  // Матчи клуба игрока на этой неделе (двойная неделя: кубок/лига → евро).
  const userFixtures = useMemo(
    () => snapshot.fixtures.filter((f) => f.isUserMatch && !f.played),
    [snapshot.fixtures],
  );
  const euroFixture = userFixtures.find((f) => f.competition === 'euro') ?? null;
  const euroOpponent = euroCache?.nextEuroMatch?.opponent ?? null;

  // Кубковая/еврокубковая неделя без участия клуба игрока — отдых + симуляция недели.
  if (!nextMatch) {
    const euroWeek = snapshot.fixtures.some((f) => f.competition === 'euro');
    const euroRoundLabel =
      euroCache?.rounds.find((r) => r.week === save.week)?.label
      ?? euroRoundLabelOf(save.week, save.league.teamCount);
    if (save.weekInfo.type === 'cup') {
      return (
        <div className="space-y-4">
          <Card className="border-[#EAB308]/40 bg-[#EAB308]/5">
            <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
              <span className="flex size-14 items-center justify-center rounded-full bg-[#EAB308]/10">
                <Bed className="size-7 text-[#EAB308]" aria-hidden />
              </span>
              <p className="text-sm font-semibold">
                {save.weekInfo.label} — ваша команда отдыхает
              </p>
              <p className="max-w-sm text-xs text-muted-foreground">
                {snapshot.cup.myStatus === 'eliminated'
                  ? `Клуб выбыл из ${save.league.cupName} — остальные раунды играются без вас. Симулируйте неделю.`
                  : 'Ваш клуб не участвует в этом раунде. Симулируйте неделю — команда восстановит силы (+10 состояния).'}
              </p>
              {euroWeek ? (
                <p className="flex max-w-sm items-center justify-center gap-1.5 rounded border border-[#D4AF37]/40 bg-[#D4AF37]/5 px-3 py-1.5 text-xs text-[#D4AF37]">
                  <Globe className="size-3.5 shrink-0" aria-hidden />
                  Кубок Европы{euroRoundLabel ? ` · ${euroRoundLabel}` : ''} — клуб{' '}
                  {euroCache?.status === 'eliminated' ? 'выбыл' : 'не участвует'}. Симулируйте неделю.
                </p>
              ) : null}
              <Button
                size="lg"
                className="h-12 w-full max-w-xs text-base"
                onClick={() => void playWeek()}
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="size-5 animate-spin" aria-hidden />
                ) : (
                  <FastForward className="size-5" aria-hidden />
                )}
                Симулировать неделю
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    return (
      <Card className="border-border/70">
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          <Clock className="size-8 text-muted-foreground" aria-hidden />
          <p className="text-sm font-semibold">Матч этой недели уже сыгран</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            {save.weekInfo.label}. Результаты смотрите во вкладке «Лига», «Кубок» и «Европа».
          </p>
        </CardContent>
      </Card>
    );
  }

  const isHome = nextMatch.homeTeamId === myTeam.id;
  const isCup = nextMatch.competition === 'cup';
  const isEuro = nextMatch.competition === 'euro';
  const opponent = nextMatchPreview?.opponent;
  const myLines = nextMatchPreview?.myLines;
  const oppLines = nextMatchPreview?.opponentLines;

  return (
    <div className="space-y-4">
      {/* Превью матча 1 (кубок/лига — или единственный евроматч) */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="visual-panel rounded-2xl border border-[#7bd7ff]/25 bg-card p-4 shadow-[0_18px_50px_rgba(0,0,0,.22)] sm:p-6"
        style={{ backgroundImage: "url('/visuals/matchday-pitch.svg')" }}
      >
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <Badge
            variant="outline"
            className={cn(
              'text-[11px]',
              isCup && 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]',
              isEuro && 'border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#D4AF37]',
            )}
          >
            {userFixtures.length > 1 ? 'Матч 1 из 2 · ' : ''}
            {save.weekInfo.label}
          </Badge>
          <div className="flex items-center gap-2">
            {nextMatch.isNeutral ? (
              <Badge variant="outline" className="text-[11px] text-muted-foreground">
                Нейтральное поле
              </Badge>
            ) : null}
            <Badge className={cn('text-[11px]', isHome ? 'bg-primary/15 text-primary' : 'bg-secondary text-muted-foreground')}>
              {isHome ? 'Играем дома' : 'Играем в гостях'}
            </Badge>
          </div>
        </div>
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <div className="flex flex-col items-center gap-1.5 text-center">
            <TeamCrest
              shortName={nextMatch.homeShort}
              colorPrimary={nextMatch.homePrimary}
              colorSecondary={nextMatch.homeSecondary}
              size="lg"
            />
            <span className="truncate text-xs font-semibold">{nextMatch.homeName}</span>
          </div>
          <span className="text-xl font-bold text-muted-foreground">VS</span>
          <div className="flex flex-col items-center gap-1.5 text-center">
            <TeamCrest
              shortName={nextMatch.awayShort}
              colorPrimary={nextMatch.awayPrimary}
              colorSecondary={nextMatch.awaySecondary}
              size="lg"
            />
            <span className="truncate text-xs font-semibold">{nextMatch.awayName}</span>
          </div>
        </div>
        {opponent ? (
          <div className="mt-3 flex flex-col items-center gap-1.5">
            <p className="text-center text-xs text-muted-foreground">
              Соперник: формация {opponent.formation} · менталитет «
              {MENTALITY_LABELS[opponent.mentality].toLowerCase()}» · сила {opponent.strength}
            </p>
            {/* Фаза 4: бейдж стиля ИИ-тренера соперника (клуб игрока — без бейджа) */}
            <CoachStyleBadge style={opponent.coachStyle} />
          </div>
        ) : null}
      </motion.div>

      {/* Превью матча 2 — еврокубок двойной недели */}
      {euroFixture && euroFixture !== nextMatch ? (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08 }}
          className="rounded-lg border border-[#D4AF37]/30 bg-card p-4 sm:p-6"
        >
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <Badge variant="outline" className="border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[11px] text-[#D4AF37]">
              <Globe className="size-3" aria-hidden />
              Матч 2 из 2 · Кубок Европы
              {euroCache?.nextEuroMatch ? ` · ${euroCache.nextEuroMatch.label}` : ''}
            </Badge>
            {euroFixture.isNeutral ? (
              <Badge variant="outline" className="text-[11px] text-muted-foreground">
                Нейтральное поле
              </Badge>
            ) : null}
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 text-center">
            <TeamCrest
              shortName={euroFixture.homeShort}
              colorPrimary={euroFixture.homePrimary}
              colorSecondary={euroFixture.homeSecondary}
              size="md"
              title={euroFixture.homeName}
            />
            <span className="text-sm font-semibold">{euroFixture.homeName}</span>
            <span className="text-sm font-bold text-muted-foreground">VS</span>
            <TeamCrest
              shortName={euroFixture.awayShort}
              colorPrimary={euroFixture.awayPrimary}
              colorSecondary={euroFixture.awaySecondary}
              size="md"
              title={euroFixture.awayName}
            />
            <span className="text-sm font-semibold">{euroFixture.awayName}</span>
          </div>
          {euroOpponent ? (
            <div className="mt-3 flex flex-col items-center gap-1.5">
              <p className="text-xs text-muted-foreground">
                {euroOpponent.isGuest ? `Гость из ${euroOpponent.leagueName}` : 'Представитель вашей лиги'}
                {' · сила '}
                <span className="tabular font-semibold text-foreground">{euroOpponent.strength}</span>
                {euroCache?.nextEuroMatch ? (
                  <>
                    {' · '}
                    {euroCache.nextEuroMatch.isHome ? 'дома' : 'в гостях'}
                    {' · '}
                    неделя <span className="tabular">{euroCache.nextEuroMatch.week}</span>
                  </>
                ) : null}
              </p>
              <CoachStyleBadge style={euroOpponent.coachStyle} />
            </div>
          ) : null}
        </motion.div>
      ) : null}

      {myLines && oppLines ? (
        <Card className="border-border/70">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Сравнение линий</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {(
              [
                ['Атака', myLines.attack, oppLines.attack],
                ['Центр поля', myLines.midfield, oppLines.midfield],
                ['Оборона', myLines.defence, oppLines.defence],
              ] as const
            ).map(([label, mine, opp]) => {
              const total = mine + opp || 1;
              return (
                <div key={label}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="tabular font-bold text-primary">{mine}</span>
                    <span className="text-muted-foreground">{label}</span>
                    <span className="tabular font-bold text-[#FACC15]">{opp}</span>
                  </div>
                  <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
                    <div className="bg-primary transition-all" style={{ width: `${(mine / total) * 100}%` }} />
                    <div className="bg-[#FACC15] transition-all" style={{ width: `${(opp / total) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      ) : null}

      {/* Фаза 4: план на матч (только клуб игрока) */}
      <MatchPlanCard />

      <div className="flex flex-col gap-3 sm:flex-row">
        <LineupColumn
          title={`Стартовый состав · ${myTeam.formation}`}
          crest={
            <TeamCrest
              shortName={myTeam.shortName}
              colorPrimary={myTeam.colorPrimary}
              colorSecondary={myTeam.colorSecondary}
              size="sm"
            />
          }
          entries={myXI}
        />
        {opponent ? (
          <OpponentCard opponent={opponent} />
        ) : null}
      </div>

      <Button size="lg" className="h-12 w-full text-base" onClick={() => void playWeek()} disabled={loading}>
        {loading ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <Play className="size-5" aria-hidden />}
        {userFixtures.length > 1
          ? 'Сыграть оба матча'
          : isCup
            ? 'Начать кубковый матч'
            : isEuro
              ? 'Начать еврокубковый матч'
              : 'Начать матч'}
      </Button>
    </div>
  );
}

function OpponentCard({ opponent }: { opponent: TeamBriefDTO }) {
  return (
    <div className="min-w-0 flex-1 rounded-lg border border-border/60 bg-secondary/30 p-3">
      <div className="mb-2 flex items-center gap-2">
        <TeamCrest
          shortName={opponent.shortName}
          colorPrimary={opponent.colorPrimary}
          colorSecondary={opponent.colorSecondary}
          size="sm"
        />
        <span className="truncate text-xs font-semibold">{opponent.name}</span>
      </div>
      <ul className="space-y-1 text-xs text-muted-foreground">
        <li className="flex items-center justify-between rounded bg-card/60 px-2 py-1.5">
          <span>Формация</span>
          <span className="font-semibold text-foreground tabular">{opponent.formation}</span>
        </li>
        <li className="flex items-center justify-between rounded bg-card/60 px-2 py-1.5">
          <span>Менталитет</span>
          <span className="font-semibold text-foreground">{MENTALITY_LABELS[opponent.mentality]}</span>
        </li>
        <li className="flex items-center justify-between rounded bg-card/60 px-2 py-1.5">
          <span>Сила клуба</span>
          <span className="font-semibold text-foreground tabular">{opponent.strength}</span>
        </li>
        <li className="flex items-center justify-between rounded bg-card/60 px-2 py-1.5">
          <span>Город</span>
          <span className="font-semibold text-foreground">{opponent.city ?? '—'}</span>
        </li>
      </ul>
    </div>
  );
}

function scoreOf(events: MatchEvent[], upTo: number, teamId: string): number {
  return events.filter((e) => e.type === 'goal' && e.minute <= upTo && e.teamId === teamId).length;
}

function penScoreOf(events: MatchEvent[], upTo: number, teamId: string): number {
  return events.filter((e) => e.type === 'pen_goal' && e.minute <= upTo && e.teamId === teamId).length;
}

function Live() {
  const lastMatch = useGameStore((s) => s.lastMatch)!;
  const liveMinute = useGameStore((s) => s.liveMinute);
  const liveSpeed = useGameStore((s) => s.liveSpeed);
  const liveMatchIndex = useGameStore((s) => s.liveMatchIndex);
  const radarNames = useGameStore((s) => s.radarNames);
  const toggleRadarNames = useGameStore((s) => s.toggleRadarNames);
  const snapshot = useGameStore((s) => s.snapshot);
  const setLiveMinute = useGameStore((s) => s.setLiveMinute);
  const setLiveSpeed = useGameStore((s) => s.setLiveSpeed);
  const setLiveMatchIndex = useGameStore((s) => s.setLiveMatchIndex);
  const setMatchView = useGameStore((s) => s.setMatchView);
  const [radarFull, setRadarFull] = useState(false);

  // Фаза 4: двойная неделя — лента конкретного матча очереди (0..1).
  const userMatches = lastMatch.userMatches;
  const index = Math.min(liveMatchIndex, Math.max(0, userMatches.length - 1));
  const match = userMatches[index] ?? null;

  const maxMinute = useMemo(
    () => (match ? Math.max(90, ...match.events.map((e) => e.minute)) : 90),
    [match],
  );

  useEffect(() => {
    if (!match) return;
    if (liveMinute >= maxMinute) {
      const t = setTimeout(() => {
        // Матчей в очереди больше — лента матча 2 с минуты 0; иначе — к итогам.
        if (index + 1 < userMatches.length) setLiveMatchIndex(index + 1);
        else setMatchView('result');
      }, 700);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setLiveMinute(liveMinute + 1), BASE_TICK_MS / liveSpeed);
    return () => clearTimeout(t);
  }, [liveMinute, liveSpeed, maxMinute, match, index, userMatches.length, setLiveMinute, setLiveMatchIndex, setMatchView]);

  if (!match) {
    return <WeekWithoutMatch />;
  }

  const { home, away, events } = match;
  const hasPens = events.some((e) => e.type.startsWith('pen_'));
  const visible = events.filter((e) => e.minute <= liveMinute);
  const homeGoals = scoreOf(events, liveMinute, home.id);
  const awayGoals = scoreOf(events, liveMinute, away.id);
  const homePens = penScoreOf(events, liveMinute, home.id);
  const awayPens = penScoreOf(events, liveMinute, away.id);
  const pensStarted = visible.some((e) => e.type.startsWith('pen_'));
  const progress = Math.min(100, (liveMinute / maxMinute) * 100);
  const teamCount = snapshot?.save.league.teamCount ?? 16;
  const compLabel = matchCompetitionLabel(match, {
    weekLabel: lastMatch.weekLabel,
    week: lastMatch.week,
    teamCount,
  });
  const onNext = () => {
    if (index + 1 < userMatches.length) setLiveMatchIndex(index + 1);
    else setMatchView('result');
  };

  return (
    <div className="space-y-4">
      {/* Заголовок двойной недели: «Матч 1 из 2 · Кубок · 1/4 финала» */}
      {userMatches.length > 1 ? (
        <div className="flex items-center justify-center gap-2">
          <Badge variant="outline" className="border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[11px] text-[#D4AF37]">
            Матч {index + 1} из {userMatches.length} · {compLabel}
          </Badge>
        </div>
      ) : null}

      {/* Счёт */}
      <div className="rounded-lg border border-border/70 bg-card p-4 sm:p-5">
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
          <div className="flex min-w-0 flex-col items-center gap-1 text-center">
            <TeamCrest
              shortName={home.shortName}
              colorPrimary={home.colorPrimary}
              colorSecondary={home.colorSecondary}
              size="md"
              title={home.name}
            />
            <span className="w-full truncate text-xs font-semibold">{home.shortName}</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-3xl font-bold tabular sm:text-4xl">
              {homeGoals}<span className="mx-1.5 text-muted-foreground">:</span>{awayGoals}
            </span>
            {pensStarted ? (
              <span className="mt-1 rounded bg-[#EAB308]/15 px-2 py-0.5 text-xs font-bold tabular text-[#EAB308]">
                пен. {homePens}:{awayPens}
              </span>
            ) : (
              <span className="mt-1 rounded bg-primary/15 px-2 py-0.5 text-xs font-bold tabular text-primary">
                {liveMinute}&apos;
              </span>
            )}
          </div>
          <div className="flex min-w-0 flex-col items-center gap-1 text-center">
            <TeamCrest
              shortName={away.shortName}
              colorPrimary={away.colorPrimary}
              colorSecondary={away.colorSecondary}
              size="md"
              title={away.name}
            />
            <span className="w-full truncate text-xs font-semibold">{away.shortName}</span>
          </div>
        </div>
        <Progress value={progress} className="mt-4 h-1.5" aria-label="Прогресс матча" />
        <div className="mt-1.5 flex items-center justify-between text-[10px] text-muted-foreground tabular">
          <span>0&apos;</span>
          <span>{hasPens ? 'серия пенальти' : 'перерыв 45\''}</span>
          <span>{maxMinute}&apos;</span>
        </div>
      </div>

      {/* Управление скоростью + настройки радара */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-muted-foreground">Скорость:</span>
        {([1, 2, 4] as const).map((s) => (
          <Button
            key={s}
            size="sm"
            variant={liveSpeed === s ? 'secondary' : 'outline'}
            className={cn('min-h-9', liveSpeed === s && 'bg-primary/15 text-primary')}
            onClick={() => setLiveSpeed(s)}
            aria-pressed={liveSpeed === s}
          >
            ×{s}
          </Button>
        ))}
        <Button
          size="sm"
          variant="outline"
          className={cn('min-h-9 gap-1.5', radarNames && 'border-primary/50 text-primary')}
          onClick={toggleRadarNames}
          aria-pressed={radarNames}
          title="Показывать фамилии под фишками 2D-радара"
        >
          <Type className="size-3.5" aria-hidden />
          <span className="hidden sm:inline">Имена</span>
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="ml-auto min-h-9 gap-1.5"
          onClick={() => setRadarFull(true)}
          aria-label="Развернуть 2D-радар на весь экран"
          title="Полноэкранный радар"
        >
          <Maximize2 className="size-3.5" aria-hidden />
          <span className="hidden sm:inline">Радар</span>
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="min-h-9"
          onClick={onNext}
        >
          <FastForward className="size-3.5" aria-hidden />
          {index + 1 < userMatches.length ? 'К матчу 2' : 'К итогу'}
        </Button>
      </div>

      {/* Модуль 6: 2D-радар + лента — две колонки на десктопе */}
      <div className="grid gap-4 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        <div className="min-w-0">
          <MatchRadar match={match} liveMinute={liveMinute} showNames={radarNames} />
        </div>
        <div className="min-w-0 rounded-lg border border-border/70 bg-card p-2">
          <MatchTimeline
            events={visible}
            homeTeamId={home.id}
            homeShort={home.shortName}
            awayShort={away.shortName}
            className="h-[40vh] min-h-56 lg:h-full lg:max-h-[560px]"
          />
        </div>
      </div>

      {/* Полноэкранный радар (Модуль 6) */}
      <Dialog open={radarFull} onOpenChange={setRadarFull}>
        <DialogContent className="max-w-3xl p-3 sm:p-4">
          <DialogHeader className="pb-1">
            <DialogTitle className="flex items-center gap-2 text-sm">
              <span
                className="size-2.5 rounded-full"
                style={{ backgroundColor: home.colorPrimary }}
                aria-hidden
              />
              {home.shortName} {homeGoals}:{awayGoals} {away.shortName}
              <span className="text-muted-foreground">· {liveMinute}&apos;</span>
              <span
                className="size-2.5 rounded-full"
                style={{ backgroundColor: away.colorSecondary }}
                aria-hidden
              />
            </DialogTitle>
            <DialogDescription className="sr-only">
              Полноэкранный 2D-радар матча: позиции игроков, мяч и маркеры событий.
            </DialogDescription>
          </DialogHeader>
          <MatchRadar match={match} liveMinute={liveMinute} showNames={radarNames} />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatRow({
  label,
  home,
  away,
  suffix = '',
}: {
  label: string;
  home: number;
  away: number;
  suffix?: string;
}) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <span className="w-8 text-right text-xs font-semibold tabular">{home}{suffix}</span>
      <span className="flex-1 text-center text-[11px] text-muted-foreground">{label}</span>
      <span className="w-8 text-xs font-semibold tabular">{away}{suffix}</span>
    </div>
  );
}

/** Итоговый экран для недели БЕЗ матча клуба игрока (кубковый/еврокубковый отдых). */
function WeekWithoutMatch() {
  const lastMatch = useGameStore((s) => s.lastMatch)!;
  const snapshot = useGameStore((s) => s.snapshot)!;
  const setMatchView = useGameStore((s) => s.setMatchView);
  const setTab = useGameStore((s) => s.setTab);
  const seasonSummarySeen = useGameStore((s) => s.seasonSummarySeen);
  const teamById = useMemo(
    () => new Map(snapshot.teams.map((t) => [t.id, t])),
    [snapshot.teams],
  );
  const { weekLabel, weekResults, finances, seasonEnded } = lastMatch;

  const onContinue = () => {
    if (seasonEnded && !seasonSummarySeen) {
      setMatchView('ceremony');
      return;
    }
    setMatchView('prematch');
    setTab('dashboard');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="rounded-lg border border-border/70 bg-card p-4 text-center sm:p-6">
        <p className="text-sm font-bold text-muted-foreground">Неделя без матча</p>
        <p className="mt-1 text-lg font-bold">{weekLabel}</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Ваша команда отдыхала: состояние +10, мораль +2.
        </p>
        {seasonEnded ? (
          <Badge className="mt-4 border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
            Сезон {lastMatch.season} завершён: {seasonEnded.place} место · призовые{' '}
            {formatMoney(seasonEnded.prize)}
          </Badge>
        ) : null}
      </div>

      <Card className="border-border/70">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Результаты недели</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {weekResults.length === 0 ? (
            <p className="py-4 text-center text-xs text-muted-foreground">
              На этой неделе матчей не было.
            </p>
          ) : (
            weekResults.map((m, i) => {
              const home = teamById.get(m.homeId);
              const away = teamById.get(m.awayId);
              return (
                <div
                  key={i}
                  className="flex items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-2 text-xs"
                >
                  <span className="min-w-0 flex-1 truncate text-right">{home?.name ?? '—'}</span>
                  <span className="shrink-0 font-bold tabular">
                    {m.homeGoals}:{m.awayGoals}
                    {m.homePens !== null && m.awayPens !== null ? (
                      <span className="ml-1 text-[#EAB308]">({m.homePens}:{m.awayPens} пен.)</span>
                    ) : null}
                  </span>
                  <span className="min-w-0 flex-1 truncate">{away?.name ?? '—'}</span>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      <FinancesGrid finances={finances} />

      <Button size="lg" className="h-12 w-full text-base" onClick={onContinue}>
        {seasonEnded ? (
          <>
            Церемония наград
            <Trophy className="size-5" aria-hidden />
          </>
        ) : (
          <>
            Продолжить
            <ChevronRight className="size-5" aria-hidden />
          </>
        )}
      </Button>
    </motion.div>
  );
}

function FinancesGrid({ finances }: { finances: WeekFinancesDTO }) {
  const hasCupPrize = finances.cupPrize > 0;
  const hasEuroPrize = finances.euroPrize > 0;
  return (
    <Card className="border-border/70">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">Финансы недели</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
        <div className="rounded bg-secondary/50 p-2">
          <div className="mb-0.5 flex items-center gap-1 text-muted-foreground">
            <Wallet className="size-3" aria-hidden />
            Зарплаты
          </div>
          <div className="tabular font-semibold text-[#EF4444]">−{formatMoney(finances.wages)}</div>
        </div>
        <div className="rounded bg-secondary/50 p-2">
          <div className="mb-0.5 flex items-center gap-1 text-muted-foreground">
            <Ticket className="size-3" aria-hidden />
            Билеты
          </div>
          <div className="tabular font-semibold text-[#22C55E]">
            {finances.tickets > 0 ? '+' : ''}
            {formatMoney(finances.tickets)}
          </div>
        </div>
        <div className="rounded bg-secondary/50 p-2">
          <div className="mb-0.5 flex items-center gap-1 text-muted-foreground">
            <Ticket className="size-3" aria-hidden />
            Спонсор
          </div>
          <div className="tabular font-semibold text-[#22C55E]">+{formatMoney(finances.sponsor)}</div>
        </div>
        {hasCupPrize ? (
          <div className="rounded bg-secondary/50 p-2">
            <div className="mb-0.5 flex items-center gap-1 text-muted-foreground">
              <Trophy className="size-3" aria-hidden />
              Кубковые
            </div>
            <div className="tabular font-semibold text-[#EAB308]">
              +{formatMoney(finances.cupPrize)}
            </div>
          </div>
        ) : null}
        {hasEuroPrize ? (
          <div className="rounded bg-secondary/50 p-2">
            <div className="mb-0.5 flex items-center gap-1 text-muted-foreground">
              <Globe className="size-3" aria-hidden />
              Еврокубок
            </div>
            <div className="tabular font-semibold text-[#D4AF37]">
              +{formatMoney(finances.euroPrize)}
            </div>
          </div>
        ) : null}
        {!hasCupPrize && !hasEuroPrize ? (
          <div className="rounded bg-secondary/50 p-2">
            <div className="mb-0.5 text-muted-foreground">Итого за неделю</div>
            <div className={cn('tabular font-bold', finances.net >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]')}>
              {finances.net >= 0 ? '+' : '−'}
              {formatMoney(Math.abs(finances.net))}
            </div>
          </div>
        ) : (
          <div className="col-span-2 rounded bg-secondary/50 p-2 sm:col-span-4">
            <div className="mb-0.5 text-muted-foreground">Итого за неделю</div>
            <div className={cn('tabular font-bold', finances.net >= 0 ? 'text-[#22C55E]' : 'text-[#EF4444]')}>
              {finances.net >= 0 ? '+' : '−'}
              {formatMoney(Math.abs(finances.net))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/** Сводная карточка матча двойной недели (счёт + кнопка «Трансляция»). */
function DoubleMatchRow({
  m,
  index,
  myTeamId,
  teamCount,
  weekLabel,
  week,
}: {
  m: UserMatchResultDTO;
  index: number;
  myTeamId: string;
  teamCount: number;
  weekLabel: string;
  week: number;
}) {
  const setMatchView = useGameStore((s) => s.setMatchView);
  const setLiveMatchIndex = useGameStore((s) => s.setLiveMatchIndex);
  const isHome = m.home.id === myTeamId;
  const my = isHome ? m.homeGoals : m.awayGoals;
  const opp = isHome ? m.awayGoals : m.homeGoals;
  const decidedByPens = m.homePens !== null && m.awayPens !== null && m.winnerTeamId !== null;
  const won = decidedByPens ? m.winnerTeamId === myTeamId : my > opp;
  const outcomeWord = decidedByPens
    ? m.winnerTeamId === myTeamId
      ? 'Победа по пенальти'
      : 'Поражение по пенальти'
    : my > opp
      ? 'Победа'
      : my === opp
        ? 'Ничья'
        : 'Поражение';
  const outcomeTone = won
    ? 'text-[#22C55E]'
    : !decidedByPens && my === opp
      ? 'text-[#FACC15]'
      : 'text-[#EF4444]';

  return (
    <div className="rounded-lg border border-border/60 bg-secondary/30 p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <Badge variant="outline" className="shrink-0 text-[10px] text-muted-foreground">
          Матч {index + 1} · {matchCompetitionLabel(m, { weekLabel, week, teamCount })}
        </Badge>
        <span className={cn('text-[11px] font-bold', outcomeTone)}>{outcomeWord}</span>
      </div>
      <div className="flex items-center gap-2">
        <TeamCrest
          shortName={m.home.shortName}
          colorPrimary={m.home.colorPrimary}
          colorSecondary={m.home.colorSecondary}
          size="sm"
          title={m.home.name}
        />
        <span className="min-w-0 flex-1 truncate text-xs">{m.home.name}</span>
        <span className="shrink-0 text-sm font-bold tabular">
          {m.homeGoals}:{m.awayGoals}
          {decidedByPens ? (
            <span className="ml-1 text-[11px] text-[#EAB308]">({m.homePens}:{m.awayPens} пен.)</span>
          ) : null}
        </span>
        <span className="min-w-0 flex-1 truncate text-right text-xs">{m.away.name}</span>
        <TeamCrest
          shortName={m.away.shortName}
          colorPrimary={m.away.colorPrimary}
          colorSecondary={m.away.colorSecondary}
          size="sm"
          title={m.away.name}
        />
      </div>
      <Button
        variant="outline"
        size="sm"
        className="mt-2 h-9 w-full text-xs"
        onClick={() => {
          setLiveMatchIndex(index);
          setMatchView('live');
        }}
      >
        <Play className="size-3.5" aria-hidden />
        Трансляция
      </Button>
    </div>
  );
}

function Result() {
  const lastMatch = useGameStore((s) => s.lastMatch)!;
  const setMatchView = useGameStore((s) => s.setMatchView);
  const setTab = useGameStore((s) => s.setTab);
  const seasonSummarySeen = useGameStore((s) => s.seasonSummarySeen);
  const snapshot = useGameStore((s) => s.snapshot)!;

  const { userMatches, finances, seasonEnded, weekLabel } = lastMatch;

  // Кубковая/еврокубковая неделя без участия клуба игрока.
  if (userMatches.length === 0) {
    return <WeekWithoutMatch />;
  }

  // Фаза 4: двойная неделя — сводка двух матчей + итоги последнего.
  const isDouble = userMatches.length > 1;
  const userMatch = userMatches[userMatches.length - 1];
  const { home, away, homeGoals, awayGoals, homePens, awayPens, winnerTeamId, events, stats } = userMatch;
  const isHome = home.id === snapshot.myTeam.id;
  const my = isHome ? homeGoals : awayGoals;
  const opp = isHome ? awayGoals : homeGoals;
  const decidedByPens = homePens !== null && awayPens !== null && winnerTeamId !== null;
  const outcome = decidedByPens
    ? winnerTeamId === snapshot.myTeam.id
      ? 'Победа по пенальти!'
      : 'Поражение по пенальти'
    : my > opp
      ? 'Победа!'
      : my === opp
        ? 'Ничья'
        : 'Поражение';
  const outcomeTone = decidedByPens
    ? winnerTeamId === snapshot.myTeam.id
      ? 'text-[#22C55E]'
      : 'text-[#EF4444]'
    : my > opp
      ? 'text-[#22C55E]'
      : my === opp
        ? 'text-[#FACC15]'
        : 'text-[#EF4444]';

  const possession = stats ? Math.round(stats.possessionHome) : 50;

  const onContinue = () => {
    if (seasonEnded && !seasonSummarySeen) {
      setMatchView('ceremony');
      return;
    }
    setMatchView('prematch');
    setTab('dashboard');
  };

  const teamCount = snapshot.save.league.teamCount;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Итоговый счёт */}
      <div className="rounded-lg border border-border/70 bg-card p-4 text-center sm:p-6">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          {weekLabel}
        </p>
        <p className={cn('mt-1 text-sm font-bold uppercase tracking-wide', outcomeTone)}>{outcome}</p>
        <div className="mt-2 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <div className="flex min-w-0 flex-col items-center gap-1">
            <TeamCrest
              shortName={home.shortName}
              colorPrimary={home.colorPrimary}
              colorSecondary={home.colorSecondary}
              size="lg"
              title={home.name}
            />
            <span className="w-full truncate text-xs font-semibold">{home.name}</span>
          </div>
          <span className="text-center">
            <span className="text-4xl font-bold tabular sm:text-5xl">
              {homeGoals}<span className="mx-2 text-muted-foreground">:</span>{awayGoals}
            </span>
            {decidedByPens ? (
              <span className="mt-1 block text-sm font-bold tabular text-[#EAB308]">
                {homePens}:{awayPens} по пен.
              </span>
            ) : null}
          </span>
          <div className="flex min-w-0 flex-col items-center gap-1">
            <TeamCrest
              shortName={away.shortName}
              colorPrimary={away.colorPrimary}
              colorSecondary={away.colorSecondary}
              size="lg"
              title={away.name}
            />
            <span className="w-full truncate text-xs font-semibold">{away.name}</span>
          </div>
        </div>
        {seasonEnded ? (
          <Badge className="mt-4 border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]">
            Сезон {lastMatch.season} завершён: {seasonEnded.place} место · призовые{' '}
            {formatMoney(seasonEnded.prize)}
          </Badge>
        ) : null}
      </div>

      {/* Фаза 4: сводная карточка двойной недели (каждый матч + «Трансляция») */}
      {isDouble ? (
        <Card className="border-border/70">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Матчи недели</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {userMatches.map((m, i) => (
              <DoubleMatchRow
                key={m.matchId}
                m={m}
                index={i}
                myTeamId={snapshot.myTeam.id}
                teamCount={teamCount}
                weekLabel={lastMatch.weekLabel}
                week={lastMatch.week}
              />
            ))}
          </CardContent>
        </Card>
      ) : null}

      {/* Статистика */}
      {stats ? (
        <Card className="border-border/70">
          <CardHeader className="pb-1">
            <CardTitle className="text-sm">Статистика матча</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-3">
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="tabular font-semibold">{possession}%</span>
                <span className="text-muted-foreground">Владение</span>
                <span className="tabular font-semibold">{100 - possession}%</span>
              </div>
              <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
                <div className="bg-primary" style={{ width: `${possession}%` }} />
                <div className="bg-[#FACC15]" style={{ width: `${100 - possession}%` }} />
              </div>
            </div>
            <StatRow label="Удары" home={stats.shotsHome} away={stats.shotsAway} />
            <StatRow label="В створ" home={stats.sotHome} away={stats.sotAway} />
            <StatRow label="Угловые" home={stats.cornersHome} away={stats.cornersAway} />
            <StatRow label="Фолы" home={stats.foulsHome} away={stats.foulsAway} />
            <StatRow label="Жёлтые" home={stats.yellowsHome} away={stats.yellowsAway} />
            <StatRow label="Красные" home={stats.redsHome} away={stats.redsAway} />
          </CardContent>
        </Card>
      ) : null}

      {/* Лента целиком */}
      <div className="rounded-lg border border-border/70 bg-card p-2">
        <p className="px-2 pb-1 pt-1 text-xs font-semibold text-muted-foreground">
          Хронология матча{isDouble ? ' · последний матч недели' : ''}
        </p>
        <MatchTimeline
          events={events}
          homeTeamId={home.id}
          homeShort={home.shortName}
          awayShort={away.shortName}
          className="h-64"
        />
      </div>

      <FinancesGrid finances={finances} />

      <Button size="lg" className="h-12 w-full text-base" onClick={onContinue}>
        {seasonEnded ? (
          <>
            Церемония наград
            <Trophy className="size-5" aria-hidden />
          </>
        ) : (
          <>
            Продолжить
            <ChevronRight className="size-5" aria-hidden />
          </>
        )}
      </Button>
    </motion.div>
  );
}

/** Экран матча: пре-матч → трансляция (с пенальти) → итог → церемония.
 *  Церемонию (matchView === 'ceremony') рендерит GameShell на верхнем уровне:
 *  дублирующий рендер здесь убран — двойной оверлей и два aria-modal в дереве
 *  доступности, а position:fixed внутри анимированного motion.div нестабилен
 *  из-за transform предка. */
export function MatchScreen() {
  const matchView = useGameStore((s) => s.matchView);

  if (matchView === 'live') return <Live />;
  if (matchView === 'result') return <Result />;
  return <Prematch />;
}

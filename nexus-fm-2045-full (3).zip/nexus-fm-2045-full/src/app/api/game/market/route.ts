import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { normalizeErrorCode, resolvePlayingSave, saveIdFromQuery } from '@/lib/game/api-helpers';
import { ApiGameError } from '@/lib/game/error';
import { broadGroupOf } from '@/lib/game/players';
import { toPlayerDTO } from '@/lib/game/snapshot';
import type { MarketListingDTO, MarketPositionFilter, MarketSort } from '@/lib/game/types';

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

const POSITIONS: MarketPositionFilter[] = ['ALL', 'GK', 'DEF', 'MID', 'FWD'];
const SORTS: MarketSort[] = ['ovr', 'price', 'age'];

/**
 * GET /api/game/market?saveId=&position=&maxPrice=&minOvr=&sort= —
 * трансферный рынок с фильтрами. Без saveId (легаси-клиент Фазы 1) —
 * последний открытый активный сейв.
 */
export async function GET(request: Request) {
  try {
    const saveId = saveIdFromQuery(request);
    const save = await resolvePlayingSave(saveId);

    const { searchParams } = new URL(request.url);
    const positionParam = searchParams.get('position') ?? 'ALL';
    const maxPriceParam = Number(searchParams.get('maxPrice') ?? '');
    const minOvrParam = Number(searchParams.get('minOvr') ?? '');
    const sortParam = searchParams.get('sort') ?? 'ovr';

    const position: MarketPositionFilter = POSITIONS.includes(positionParam as MarketPositionFilter)
      ? (positionParam as MarketPositionFilter)
      : 'ALL';
    const maxPrice = Number.isFinite(maxPriceParam) && maxPriceParam > 0 ? maxPriceParam : null;
    const minOvr = Number.isFinite(minOvrParam) && minOvrParam > 0 ? minOvrParam : null;
    const sort: MarketSort = SORTS.includes(sortParam as MarketSort) ? (sortParam as MarketSort) : 'ovr';

    const listings = await db.transferListing.findMany({
      where: { saveId: save.id, status: 'active' },
      include: { player: true },
    });

    let dtos: MarketListingDTO[] = listings.map((l) => ({
      listingId: l.id,
      price: l.price,
      source: l.source as MarketListingDTO['source'], // market | user | free (Фаза 3)
      expiresAt: l.expiresAt,
      player: toPlayerDTO(l.player),
    }));

    if (position !== 'ALL') {
      dtos = dtos.filter((l) => broadGroupOf(l.player.position) === position);
    }
    if (maxPrice !== null) {
      dtos = dtos.filter((l) => l.price <= maxPrice);
    }
    if (minOvr !== null) {
      dtos = dtos.filter((l) => l.player.ovr >= minOvr);
    }

    dtos.sort((a, b) => {
      if (sort === 'price') return a.price - b.price;
      if (sort === 'age') return a.player.age - b.player.age;
      return b.player.ovr - a.player.ovr;
    });

    return NextResponse.json({ ok: true, listings: dtos });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/market]', error);
    return fail('UNKNOWN', 500);
  }
}

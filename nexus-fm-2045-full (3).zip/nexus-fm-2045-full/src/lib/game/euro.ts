/**
 * Кубок Европы (Фаза 4, §4.5 architecture-phase4.md): евронедели, квалификация
 * 16 участников (квоты лиг: EPL/LAL/SEA/BUN по 3 + FL1/RPL по 2; своя лига —
 * топ по таблице/силе, остальные — реальные клубы из leagues.ts по силе с
 * шумом gauss(0, EURO_QUAL_NOISE)), жеребьёвка нокаут-раундов 1/8→финал
 * (посев по силе, «сильные в разные пары», ЗАПРЕТ пар одной лиги в 1/8,
 * «слабый дома» p=EURO_WEAK_HOME_PROB), призовые (чемпиону суммарно €13M),
 * сериализация состояния GameSave и ИИ-матчи евро.
 *
 * Чистый модуль: Prisma не трогает (создание гостей/матчей — week.ts);
 * rng ТОЛЬКО параметром. Сиды (см. ТЗ §4.5):
 *   квалификация  — `${saveId}:euroqual:${season}` (переход) / `:euroqual:${season}:lazy` (сезон 1)
 *   жеребьёвка    — `${saveId}:eurodraw:${season}:${round}`
 *   генерация гостей — `${saveId}:euroguests:${season}`
 */

import type { SeasonPlan } from './calendar';
import { cupWeeksOf } from './calendar';
import {
  EURO_PRIZE_CHAMPION, EURO_PRIZE_FINALIST, EURO_PRIZE_ROUND, EURO_QUAL_NOISE,
  EURO_ROUNDS, EURO_ROUND_LABELS, EURO_WEAK_HOME_PROB, EURO_QUOTAS, EURO_WEEKS,
} from './constants';
import { generateEuroGuests, type EuroGuestTeamGen } from './generate';
import { LEAGUES } from './leagues';
import { gauss, type RNG } from './rng';
import { simulateAiCupMatch, type AiCupSide, type CupPair } from './cup';
import { parseTeamIdList, type LeagueCode } from './types';

// ── Календарь евро ────────────────────────────────────────────────────────

/** Евронедели лиги размера N (кубковые недели БЕЗ предварительного раунда; fallback — последние 4 кубковые). */
export function euroWeeksOf(teamCount: number): number[] {
  return EURO_WEEKS[teamCount] ?? cupWeeksOf(teamCount).slice(-EURO_ROUNDS);
}

/** Номер еврораунда (1..4) на сквозной неделе плана; null — неделя не евровая. */
export function euroRoundAt(plan: SeasonPlan, week: number): number | null {
  const idx = euroWeeksOf(plan.teamCount).indexOf(week);
  return idx >= 0 ? idx + 1 : null;
}

/** Подпись раунда евро («1/8 финала» … «Финал»); вне 1..4 — запасная строка. */
export function euroRoundLabel(round: number): string {
  const r = Math.min(Math.max(round, 1), EURO_ROUNDS);
  return EURO_ROUND_LABELS[r - 1] ?? `Раунд ${round}`;
}

// ── Квалификация ──────────────────────────────────────────────────────────

/** Семя гостевого клуба: реальный клуб ДРУГОЙ лиги (leagues.ts, clubIndex — индекс в def.clubs). */
export interface EuroGuestSeed {
  leagueCode: LeagueCode;
  clubIndex: number;
  /** Сила ClubSeed (для посева/слияния участников). */
  strength: number;
}

export interface EuroQualification {
  /** Квота своей лиги (2–3): id Team сейва В ПОРЯДКЕ отбора (место/сила). */
  ownTeamIds: string[];
  /** Гости из других лиг (13–14) В ПОРЯДКЕ посева (сила + шум gauss). */
  guestSeeds: EuroGuestSeed[];
}

/**
 * Квалификация Кубка Европы (§4.5 ТЗ):
 *  1) своя лига — топ-q по place финальной таблицы (place=null → сезон 1, по силе);
 *  2) каждая другая лига — клубы ClubSeed по str + gauss(rng, 0, EURO_QUAL_NOISE) → топ-q_L;
 *     (клубы своей лиги из LEAGUES не участвуют — их квота закрыта своими Team сейва).
 * rng: seed `${saveId}:euroqual:${season}` (переход) / `:euroqual:${season}:lazy` (сезон 1).
 * Отступление от буквы ТЗ: guests НЕ имеют id до записи в БД, поэтому функция
 * возвращает ownTeamIds + guestSeeds; полные 16 id собирает resolveEuroRoster.
 */
export function euroParticipants(args: {
  ownLeague: LeagueCode;
  /** Лиговые Team сейва (свои клубы); place = финальная таблица прошлого сезона (null = сезон 1). */
  leagueTeams: { id: string; strength: number; place: number | null }[];
  rng: RNG;
}): EuroQualification {
  const ownQuota = EURO_QUOTAS[args.ownLeague] ?? 3;
  const own = [...args.leagueTeams]
    .sort((a, b) => (a.place ?? 10_000) - (b.place ?? 10_000) || b.strength - a.strength)
    .slice(0, ownQuota);
  const ownTeamIds = own.map((t) => t.id);

  // Гости: другие лиги в порядке LEAGUES, шум на каждый клуб (детерминизм порядка бросков)
  const guests: { seed: EuroGuestSeed; noisy: number }[] = [];
  for (const def of LEAGUES) {
    if (def.code === args.ownLeague) continue;
    const quota = EURO_QUOTAS[def.code] ?? 2;
    const scored = def.clubs.map((club, clubIndex) => ({
      seed: { leagueCode: def.code, clubIndex, strength: club.str },
      noisy: club.str + gauss(args.rng, 0, EURO_QUAL_NOISE),
    }));
    scored.sort((a, b) => b.noisy - a.noisy);
    guests.push(...scored.slice(0, quota));
  }
  guests.sort((a, b) => b.noisy - a.noisy);

  return { ownTeamIds, guestSeeds: guests.map((g) => g.seed) };
}

/**
 * Полный ростер сезона (композит для week.ts): квалификация + сопоставление
 * гостей с УЖЕ существующими Team-строками (isEuroGuest, совпадение
 * leagueCode + имя клуба) + генерация отсутствующих. Возвращает 16 id
 * В ПОРЯДКЕ ПОСЕВА (сила desc: свои Team.strength, гости — сила семени) и
 * готовые createMany-данные новых гостей (обычно 0–2 клуба за переход).
 */
export function resolveEuroRoster(args: {
  ownLeague: LeagueCode;
  leagueTeams: { id: string; strength: number; place: number | null }[];
  /** Существующие гости сейва (isEuroGuest=true): id/leagueCode/name. */
  existingGuests: { id: string; leagueCode: string; name: string }[];
  /** Квалификация: seed `${saveId}:euroqual:${season}` / `…:lazy`. */
  rng: RNG;
  /** Генерация составов новых гостей: seed `${saveId}:euroguests:${season}`. */
  guestRng: RNG;
  /** saveId — подставляется в createMany-данные новых гостей. */
  saveId: string;
  idFactory?: () => string;
}): {
  teamIds: string[];
  ownTeamIds: string[];
  guestSeeds: EuroGuestSeed[];
  newGuests: EuroGuestTeamGen[];
} {
  const qual = euroParticipants({
    ownLeague: args.ownLeague,
    leagueTeams: args.leagueTeams,
    rng: args.rng,
  });

  const seedKey = (seed: EuroGuestSeed): string => {
    const def = LEAGUES.find((l) => l.code === seed.leagueCode);
    const club = def?.clubs[seed.clubIndex];
    return `${seed.leagueCode}:${club?.name ?? seed.clubIndex}`;
  };
  const existingByKey = new Map(
    args.existingGuests.map((g) => [`${g.leagueCode}:${g.name}`, g.id]),
  );

  const missingSeeds = qual.guestSeeds.filter((s) => !existingByKey.has(seedKey(s)));
  const newGuests = generateEuroGuests(args.guestRng, args.saveId, missingSeeds, args.idFactory);
  const newIdBySeed = new Map<string, string>();
  missingSeeds.forEach((seed, i) => newIdBySeed.set(seedKey(seed), newGuests[i].team.id));

  // Слияние в порядке посева: сила desc (свои — Team.strength, гости — сила семени)
  const entries: { id: string; strength: number }[] = [
    ...qual.ownTeamIds.map((id) => ({
      id,
      strength: args.leagueTeams.find((t) => t.id === id)?.strength ?? 60,
    })),
    ...qual.guestSeeds.map((seed) => ({
      id: existingByKey.get(seedKey(seed)) ?? newIdBySeed.get(seedKey(seed)) ?? '',
      strength: seed.strength,
    })),
  ].filter((e) => e.id !== '');
  entries.sort((a, b) => b.strength - a.strength);

  return {
    teamIds: entries.map((e) => e.id),
    ownTeamIds: qual.ownTeamIds,
    guestSeeds: qual.guestSeeds,
    newGuests,
  };
}

// ── Жеребьёвка раунда ─────────────────────────────────────────────────────

/**
 * Жеребьёвка еврораунда (§4.5): посев по силе + gauss(0, 3), жадно
 * «сильнейший непарный → слабейший непарный ИЗ ДРУГОЙ ЛИГИ» (только 1/8;
 * раунды 2+ — без ограничения лиг) + РЕМОНТ: жадность может оставить пару
 * одной лиги (например, два средних клуба лиги) — перекрёстная перезапайка
 * с парой из чужих лиг (корректность: ≤3 клуба лиги из 16 → донор всегда
 * есть; ремонт не создаёт новых плохих пар — каждое исправление уменьшает
 * их число, цикл завершается). «Слабый дома» p=EURO_WEAK_HOME_PROB,
 * финал (round=4) — isNeutral=true, «дом» монеткой.
 * Отступление от буквы ТЗ: вместо параметра isFinal передаётся round
 * (isFinal = round === EURO_ROUNDS выводится) — нужен номер раунда для
 * запрета пар одной лиги только в 1/8; ремонт — дополнение к ТЗ
 * (буквальный инвариант ТЗ «пары одной лиги в 1/8 невозможны» наивной
 * жадностью НЕ достигается — подтверждено перебором 500 сидов).
 * Детерминизм: 16 gauss (в порядке alive) → жадные пары (без rng) →
 * ремонт (без rng) → «слабый дома»/монетка по одной паре.
 */
export function drawEuroRound(
  rng: RNG,
  alive: { id: string; strength: number; leagueCode: string }[],
  round: number,
): CupPair[] {
  if (alive.length < 2 || alive.length % 2 !== 0) {
    throw new Error(`drawEuroRound: нужно чётное число участников ≥ 2, получено ${alive.length}`);
  }
  const isFinal = round >= EURO_ROUNDS;
  const seeded = alive
    .map((t) => ({ ...t, seed: t.strength + gauss(rng, 0, 3) }))
    .sort((a, b) => b.seed - a.seed);

  // 1) Жадная жеребьёвка: сильнейший непарный → слабейший ИЗ ДРУГОЙ ЛИГИ (1/8)
  const unpaired = [...seeded];
  const rawPairs: [typeof seeded[number], typeof seeded[number]][] = [];
  while (unpaired.length > 0) {
    const top = unpaired.shift() as (typeof seeded)[number];
    let idx = unpaired.length - 1;
    if (round === 1) {
      // слабейший непарный из другой лиги — последний подходящий в порядке убывания посева
      const found = [...unpaired].reverse().findIndex((t) => t.leagueCode !== top.leagueCode);
      if (found >= 0) idx = unpaired.length - 1 - found;
    }
    const opp = unpaired.splice(idx, 1)[0] ?? top;
    rawPairs.push([top, opp]);
  }

  // 2) Ремонт (1/8): пара одной лиги (X,X) → перекрёст с парой без клуба лиги X
  if (round === 1) {
    for (let guard = 0; guard < alive.length; guard++) {
      const badIdx = rawPairs.findIndex(([a, b]) => a.leagueCode === b.leagueCode);
      if (badIdx < 0) break;
      const [a, b] = rawPairs[badIdx];
      const donorIdx = rawPairs.findIndex(
        ([c, d], i) => i !== badIdx && c.leagueCode !== a.leagueCode && d.leagueCode !== a.leagueCode,
      );
      if (donorIdx < 0) break; // недостижимо при ≤3 клубах лиги из 16 (≥6 пар без неё)
      const [c, d] = rawPairs[donorIdx];
      rawPairs[badIdx] = [a, c];
      rawPairs[donorIdx] = [b, d];
    }
  }

  // 3) Дом/гости: «слабый дома» p=EURO_WEAK_HOME_PROB; финал — монетка
  const pairs: CupPair[] = rawPairs.map(([a, b]) => {
    let home: (typeof seeded)[number];
    let away: (typeof seeded)[number];
    if (isFinal) {
      home = rng() < 0.5 ? a : b;
      away = home === a ? b : a;
    } else {
      const weakHome = rng() < EURO_WEAK_HOME_PROB;
      const weak = a.strength <= b.strength ? a : b;
      const strong = weak === a ? b : a;
      home = weakHome ? weak : strong;
      away = home === weak ? strong : weak;
    }
    return { homeTeamId: home.id, awayTeamId: away.id, isNeutral: isFinal };
  });
  return pairs;
}

// ── Призовые ──────────────────────────────────────────────────────────────

/**
 * Призовые клуба игрока за еврораунд (§4.5): участие €2M кредитуется отдельно
 * (EURO_PRIZE_PARTICIPATION в week 1/8 — константа constants.ts); победа в
 * раунде 1..3 — EURO_PRIZE_ROUND[r−1]; финал: чемпион €5M / финалист €3.5M.
 * Итого чемпиону за сезон: 2+1+2+3+5 = €13M.
 */
export function euroPrizeFor(args: { round: number; won: boolean; isFinal: boolean }): number {
  if (args.isFinal || args.round >= EURO_ROUNDS) {
    return args.won ? EURO_PRIZE_CHAMPION : EURO_PRIZE_FINALIST;
  }
  if (!args.won) return 0;
  const idx = Math.min(Math.max(args.round, 1), EURO_ROUNDS - 1) - 1;
  return EURO_PRIZE_ROUND[idx];
}

// ── Состояние GameSave (сериализация) ─────────────────────────────────────

/** Разбор JSON string[] из GameSave.euroAliveTeamIds / euroParticipants. */
export function parseEuroTeamIds(raw: string | null | undefined): string[] {
  return parseTeamIdList(raw);
}

/** Сериализация id участников/живых для полей GameSave. */
export function serializeEuroTeamIds(ids: string[]): string {
  return JSON.stringify(ids);
}

/** Состояние евро из полей GameSave (структурный вход — без Prisma-типов). */
export interface EuroCtx {
  /** euroSeason !== null — турнир хотя бы раз инициализирован. */
  initialized: boolean;
  /** Сезон, на который рассчитано состояние; null = не инициализировано. */
  season: number | null;
  /** Последний ИГРАВШИЙСЯ раунд (0..4). */
  round: number;
  /** Живые участники следующего раунда (после финала/сброса — пусто). */
  aliveTeamIds: string[];
  /** 16 участников сезона. */
  participantIds: string[];
}

export function euroCtxOf(save: {
  euroSeason: number | null;
  euroRound: number;
  euroAliveTeamIds: string | null;
  euroParticipants: string | null;
}): EuroCtx {
  return {
    initialized: save.euroSeason !== null,
    season: save.euroSeason,
    round: save.euroRound,
    aliveTeamIds: parseEuroTeamIds(save.euroAliveTeamIds),
    participantIds: parseEuroTeamIds(save.euroParticipants),
  };
}

/**
 * Еврораунд ТЕКУЩЕЙ недели с учётом ленивой инициализации: null, если евро
 * не инициализировано на этот сезон (euroSeason !== season) ИЛИ неделя не
 * евровая. Гейт week.ts: при null===euroSeason инициализация только на r=1.
 */
export function euroRoundOf(
  save: { euroSeason: number | null },
  season: number,
  plan: SeasonPlan,
  week: number,
): number | null {
  if (save.euroSeason !== season) return null;
  return euroRoundAt(plan, week);
}

// ── ИИ-матчи евро ─────────────────────────────────────────────────────────

/** Евро-сторона ИИ-матча: как кубковая + стиль тренера (λ-дельты). */
export type EuroAiSide = AiCupSide;

/**
 * ИИ-евроматч (пары без клуба игрока, §5.2 Б.2.f): simulateAiCupMatch
 * (движок simulateAiMatch с aiStyle-дельтами гостей + пенальти при ничьей).
 * Возвращает победителя (winnerTeamId) для продвижения по сетке.
 */
export function simulateEuroAiMatch(
  rng: RNG,
  home: EuroAiSide,
  away: EuroAiSide,
  opts?: { neutral?: boolean },
): ReturnType<typeof simulateAiCupMatch> {
  return simulateAiCupMatch(
    rng,
    { ...home, aiStyle: home.aiStyle ?? 'balanced' },
    { ...away, aiStyle: away.aiStyle ?? 'balanced' },
    opts,
  );
}
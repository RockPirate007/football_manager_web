'use client';

import { Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { MatchTimeline } from '@/components/game/MatchTimeline';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import type { MatchDetailsDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Диалог деталей матча (лига и кубок): счёт, пенальти, лента событий. */
export function MatchDetailsDialog({
  matchId,
  match,
  loading,
  onClose,
}: {
  matchId: string | null;
  match: MatchDetailsDTO | null;
  loading: boolean;
  onClose: () => void;
}) {
  const snapshot = useGameStore((s) => s.snapshot);
  const open = matchId !== null;

  const cupLabel = (round: number | null): string | null => {
    if (round === null) return null;
    const r = snapshot?.cup.rounds.find((x) => x.round === round);
    return r ? r.label : null;
  };

  /** Фаза 4: метка еврораунда (1..4) для заголовка деталей евроматча. */
  const euroLabel = (round: number | null): string | null => {
    if (round === null) return null;
    const labels = ['1/8 финала', '1/4 финала', '1/2 финала', 'Финал'];
    return labels[Math.min(Math.max(round, 1), 4) - 1] ?? null;
  };

  const headerLabel = match
    ? match.competition === 'euro'
      ? `Кубок Европы · ${euroLabel(match.cupRound) ?? 'раунд ' + (match.cupRound ?? '?')}`
      : match.competition === 'cup'
        ? `Кубок · ${cupLabel(match.cupRound) ?? 'раунд ' + (match.cupRound ?? '?')}`
        : `Тур ${match.week}`
    : '';

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="scroll-thin max-h-[85vh] max-w-lg overflow-y-auto">
        {loading || !match ? (
          <>
            <DialogHeader>
              <DialogTitle className="text-center text-base">Матч</DialogTitle>
              <DialogDescription className="text-center">Загружаем данные матча…</DialogDescription>
            </DialogHeader>
            <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
              <Loader2 className="size-5 animate-spin" aria-hidden />
              Загружаем матч…
            </div>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="text-center text-base">
                {headerLabel} · сезон {match.season}
              </DialogTitle>
              {match.isNeutral ? (
                <div className="flex justify-center">
                  <Badge variant="outline" className="text-[10px]">
                    Нейтральное поле
                  </Badge>
                </div>
              ) : null}
              <DialogDescription asChild>
                <div className="mt-2 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
                  <div className="flex min-w-0 flex-col items-center gap-1 text-center">
                    <TeamCrest
                      shortName={match.home.shortName}
                      colorPrimary={match.home.colorPrimary}
                      colorSecondary={match.home.colorSecondary}
                      size="md"
                    />
                    <span className="w-full truncate text-xs font-semibold">{match.home.name}</span>
                  </div>
                  <span className="text-center">
                    <span className="text-2xl font-bold tabular">
                      {match.homeGoals} : {match.awayGoals}
                    </span>
                    {match.homePens !== null && match.awayPens !== null ? (
                      <span
                        className={cn(
                          'mt-0.5 block text-[11px] font-semibold tabular text-[#EAB308]',
                        )}
                      >
                        пен. {match.homePens}:{match.awayPens}
                      </span>
                    ) : null}
                  </span>
                  <div className="flex min-w-0 flex-col items-center gap-1 text-center">
                    <TeamCrest
                      shortName={match.away.shortName}
                      colorPrimary={match.away.colorPrimary}
                      colorSecondary={match.away.colorSecondary}
                      size="md"
                    />
                    <span className="w-full truncate text-xs font-semibold">{match.away.name}</span>
                  </div>
                </div>
              </DialogDescription>
            </DialogHeader>
            {match.events.length > 0 ? (
              <MatchTimeline
                events={match.events}
                homeTeamId={match.home.id}
                homeShort={match.home.shortName}
                awayShort={match.away.shortName}
                className="max-h-80"
                autoScroll={false}
              />
            ) : (
              <p className="py-4 text-center text-xs text-muted-foreground">
                Лента событий этого матча не сохранилась.
              </p>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

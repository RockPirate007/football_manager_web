# Техническое задание Фазы 3 «AAA» — «Футбольный Менеджер»

> **Task ID:** P3-2 · **Автор:** Агент-Архитектор (Лагерь 1 — Research & Design) · **Стадия:** Фаза 3 — AAA-механики
> **Основа:** docs/research-aaa.md (P3-1 — главный вход: ВСЕ формулы и таблицы параметров взяты оттуда), docs/architecture-upgrade.md (Фаза 2 — образец формата), текущий код (проверен построчно: prisma/schema.prisma, все модули src/lib/game/*, все 15 эндпоинт-методов API, store.ts, api.ts, page.tsx, компоненты GameShell/DashboardScreen/SquadScreen/PlayerDialog/SeasonCeremony/CareersScreen).
> **Статус:** проект готов к реализации без дополнительных решений. Все поля, формулы, сигнатуры, контракты API, порядок пайплайна и разбиение по блокам зафиксированы.

---

## 0. Цель, объём, что НЕ входит

| Решение | Значение |
|---|---|
| Что строим | Контракты игроков (1–4 года, истечение, продления, Босман-лайт) · молодёжная академия (набор в неделю 4) · цели правления и риск увольнения (boardConfidence, 7 статусов, sack) · история игрока по сезонам (рейтинг матча + PlayerSeasonRecord) |
| Схема | **Строго аддитивный дифф** — существующие сейвы Фазы 2 переживают `prisma db push` без сброса (см. §1.4, §10.1). Новая модель PlayerSeasonRecord |
| Время | Единицы времени НЕ меняются: неделя = слот, сезон 34/39/43 недели. Академия — неделя 4; Босман — с 60% сезона; правление — еженедельно |
| Репрезентация контракта | `Player.contractUntil` — **абсолютный номер сезона**, до которого действует контракт (включительно). Декремент НЕ нужен (в отличие от research-aaa §1.2 «contractYears» — решение Архитектора: абсолютная шкала идемпотентна и переживает любые переходы) |
| Правление | Существует ТОЛЬКО у клуба игрока (поля на GameSave, не на Team). ИИ-клубы НЕ симулируют правление |
| История | Снапшот ВСЕХ игроков сейва (~450 строк/сезон) строго между наградами и сбросом статов; рейтинг матча — всем клубам единым кодом в applyPostMatch |
| Увольнение | Mid-season (confidence < 12 четыре недели подряд) или в переходе сезона (промах ≥ 4 мест И confidence < 30, ИЛИ confidence < 15). После увольнения — **экран «Карьера завершена»**, GameSave.status = 'finished' (сейв остаётся в списке карьер, доступен для просмотра/удаления) |
| Новые модули | `contracts.ts`, `board.ts`, `academy.ts`, `history.ts` — чистые функции над PlayerLike/POJO (как training.ts/awards.ts); запись в БД — только в week.ts и API-роутах |

**Что НЕ входит в Фазу 3 (осознанно исключено, объём фиксирован):**
- Режим «Безработица» с 3 офферами клубов (research §3.2) — sack завершает карьеру экраном «Карьера завершена» (решение постановки задачи P3-2).
- 9-я награда «Лучший рейтинг лиги» (research §4.4, опция P2) — наград остаётся 8.
- «Игрок матча» (MOTM) в отчёте о матче — нет per-match хранения рейтингов.
- Релиз-клаузулы (research §1.3.5, опция P2).
- Авто-выставление ИИ слабейших 30+ на продажу перед набором академии (research §2.4) — состав защищён капом SQUAD_MAX в размере набора.
- Скаутинг, переговоры в несколько раундов с «настроением» агента, week-to-week контракты, зарплатный бюджет как отдельная сущность.

---

## 1. Дифф Prisma-схемы (точный)

Файл: `prisma/schema.prisma`. Все изменения аддитивны — `db push` НЕ требует сброса дев-БД и НЕ ломает существующие сейвы (см. §1.4).

### 1.1. Player — 5 новых полей

```prisma
model Player {
  // ...все существующие поля без изменений (строки 80–131)...

  // ── Фаза 3: контракты ──
  contractUntil     Int     @default(3)  // последний сезон действия контракта ВКЛЮЧИТЕЛЬНО; 3 = безопасный дефолт для легаси-строк (см. §1.4)
  preContractTeamId String?              // Босман: клуб предконтракта (null = нет). Скаляр БЕЗ FK — сознательно (паттерн Match.winnerTeamId), каскад удаления идёт через saveId

  // ── Фаза 3: история/рейтинг ──
  ratingSum Int @default(0) // сумма рейтингов матчей ×10 (68 = 6.8) — Int, без float-дрейфа SQLite
  ratingApps Int @default(0) // число матчей с рейтингом (= старты; замен в движке нет)

  // ── Фаза 3: академия ──
  isAcademy Boolean @default(false) // воспитанник академии (пришёл из набора)

  // ── Фаза 3: связь истории ──
  seasonRecords PlayerSeasonRecord[]

  save    GameSave         @relation("SavePlayers", fields: [saveId], references: [id], onDelete: Cascade)
  team    Team?            @relation("TeamPlayers", fields: [teamId], references: [id])
  listing TransferListing?
  awards  SeasonAward[]    @relation("AwardPlayer")
}
```

Семантика `contractUntil`:
- Игрок в клубе, пока `contractUntil >= save.season` (текущий сезон ещё покрыт).
- `yearsLeft = contractUntil − season + 1`; «истекает в конце сезона» ⇔ `contractUntil === season`.
- Формулы присвоения по местам вызова (единообразно «контракт до конца сезона X»):
  - генерация мира (сезон 1, срок y лет): `contractUntil = y` (= `season + y − 1`);
  - набор академии (неделя 4 сезона S, 3 года): `contractUntil = S + 2`;
  - покупка на рынке (сезон S, срок y лет): `contractUntil = S + y − 1`;
  - продление игроком/ИИ в течение сезона S на k лет («продлить на k лет» = с следующего сезона): `contractUntil = S + k`;
  - ИИ-продление в сезонном переходе (конец S, срок k с сезона S+1): `contractUntil = S + k`.
- У игроков рынка (teamId = null) поле не используется; заполняется при покупке.

### 1.2. GameSave — 7 новых полей

```prisma
model GameSave {
  // ...все существующие поля без изменений (строки 14–39)...

  // ── Фаза 3: правление ──
  boardTarget        String?  // код цели: champion|ucl|uel|upper|safe|survive (board.ts); null → ленивая инициализация (легаси-сейвы, §4.1 шаг 0)
  boardTargetPlace   Int?     // целевое МЕСТО в лиге (расчёты темпа/вердикта)
  boardConfidence    Int      @default(55) // 0..100
  boardWarnings      Int      @default(0) // 0 — ничего; 1 — отправлено предупреждение (<30); 2 — отправлен ультиматум (<20); сброс каждый сезон
  boardLowStreak     Int      @default(0) // число недель подряд с confidence < BOARD_SACK_CONF_WEEKLY (mid-season sack)
  honeymoonUntilWeek Int?     // неделя СЕЗОНА, до которой действует иммунитет медового месяца (8 при старте сезона; недели 1..totalWeeks)
  finishReason       String?  // 'sacked' — уволен правлением; null для активных

  // статус: "active" | "finished" (Фаза 3) | "setup" (легаси). Комментарий в схеме обновить.

  awards         SeasonAward[]
  seasonRecords  PlayerSeasonRecord[] // ── НОВАЯ связь (Фаза 3)
}
```

**Почему нет поля jobStatus:** статус должности — чистая функция от boardConfidence (7 градаций, §2.4), вычисляется на лету (board.ts::jobStatusOf + DTO). Хранение производного состояния запрещено проектным принципом «одна правда в одном месте».

### 1.3. НОВАЯ модель PlayerSeasonRecord

```prisma
/// Снапшот сезона игрока. Создаётся в сезонном переходе для ВСЕХ игроков сейва
/// (строго между наградами и сбросом статистики — §4.2 шаг 3). ~450 строк/сезон.
model PlayerSeasonRecord {
  id          String   @id @default(cuid())
  saveId      String
  season      Int
  playerId    String
  teamId      String?  // null = был свободным агентом в тот сезон
  teamName    String   // снапшот названия клуба (клуб может исчезнуть — имя остаётся); для свободных агентов — «Свободный агент»
  age         Int      // возраст В ТОТ сезон (до летнего старения)
  position    String
  apps        Int      // старты (лига + кубок; движок не различает соревнования в Player.apps)
  goals       Int      // все соревнования (кубковые — подмножество cupGoals)
  assists     Int
  cupGoals    Int
  cupAssists  Int
  cleanSheets Int
  yellowCards Int
  redCards    Int
  avgRating   Int      // ×10 (68 = 6.8); 0 = не играл (ratingApps = 0)
  createdAt   DateTime @default(now())

  save   GameSave @relation(fields: [saveId], references: [id], onDelete: Cascade)
  player Player   @relation(fields: [playerId], references: [id], onDelete: Cascade)

  @@index([saveId, season]) // экран истории / срезы сезона
  @@index([playerId])       // история конкретного игрока (GET /player)
}
```

Обоснование `onDelete: Cascade` на player: пенсионеры УДАЛЯЮТСЯ (строки Player) в переходе (week.ts, строки 300–304) — их история недостижима для UI (диалог игрока существует только для живых игроков), поэтому записи удаляются вместе с игроком, orphan-строк не остаётся. Снимок наград (SeasonAward) живёт дольше за счёт `SetNull` + label-строки — там осознанное другое решение Фазы 2. Каскад по saveId — стандарт проекта.

### 1.4. Совместимость с существующими сейвами (db push)

Все новые поля либо nullable, либо с дефолтом — SQLite `ALTER TABLE ADD COLUMN ... DEFAULT` выполняется без потери данных:

| Поле | Дефолт для легаси-строк | Опасность | Защита |
|---|---|---|---|
| Player.contractUntil = 3 | «контракт до конца сезона 3» | сейв уже в сезоне ≥ 4 → mass-expiry при первом переходе | ленивая миграция в simulateWeek шаг 0: `contractUntil < season → season + randInt(1,2)` (§4.1) |
| Player.ratingSum/ratingApps = 0, isAcademy = false, preContractTeamId = null | нейтрально | нет | — |
| GameSave.boardTarget = null | правление не инициализировано | нет данных для панели | ленивая инициализация в simulateWeek шаг 0 (§4.1) |
| GameSave.boardConfidence = 55 | стартовое значение | нет | — |
| PlayerSeasonRecord | таблица новая, пустая | нет | — |

Проверка приёмки: создать сейв Фазы 2 → применить дифф (`bunx prisma db push`) → `GET /state` отвечает 200, `POST /simulate` отрабатывает неделю, досыпая миграции.

---

## 2. Константы (constants.ts)

Новые блоки в конец `src/lib/game/constants.ts` (после «Зоны таблицы лиги», строка 487). Все значения — из research-aaa.md §5.1–5.4. Повторное использование существующих: `SALARY_MIN`, `SALARY_ROUND`, `SQUAD_MAX`, `WAGE_ALERT_RATIO`, `START_BALANCE_BASE`, `START_BALANCE_PER_STRENGTH`.

### 2.1. Контракты: CONTRACT_*

```ts
// ── Контракты (Фаза 3) ────────────────────────────────────────────────────

export const CONTRACT_MIN_YEARS = 1;
export const CONTRACT_MAX_YEARS = 4;
export const CONTRACT_VETERAN_MAX_YEARS = 2; // игроку 30+ не дают больше 2 лет
export const CONTRACT_RENEWABLE_YEARS_LEFT = 2; // продлевать можно при yearsLeft ≤ 2

/** Распределение сроков при генерации по возрасту (research §1.2). Индекс = годы−1. */
export const CONTRACT_YEARS_DISTRIBUTION: readonly {
  maxAge: number;
  weights: readonly [number, number, number, number];
}[] = [
  { maxAge: 21, weights: [0.10, 0.25, 0.35, 0.30] }, // таланты: ожидание 2.85
  { maxAge: 28, weights: [0.15, 0.30, 0.30, 0.25] }, // ядро: 2.65
  { maxAge: 31, weights: [0.25, 0.35, 0.30, 0.10] }, // ветераны: 2.25
  { maxAge: 99, weights: [0.45, 0.35, 0.15, 0.05] }, // последний контракт: 1.80
];

/** Множители роли по рангу OVR в составе (research §1.2). */
export const CONTRACT_ROLE_MULT = { star: 1.30, starter: 1.15, rotation: 1.00, depth: 0.85 } as const;
export const CONTRACT_RANK_STAR = 3;    // топ-3 по OVR → «звезда»
export const CONTRACT_RANK_STARTER = 11; // топ-11 → «основа»
export const CONTRACT_RANK_ROTATION = 18; // топ-18 → «ротация»; глубже — «резерв»

/** Модификаторы зарплатного спроса (перемножаются). */
export const CONTRACT_SALARY_FLOOR_RATIO = 1.15; // demand = max(salary×1.15, ...)
export const CONTRACT_AGE_MULT_32 = 0.90;
export const CONTRACT_AGE_MULT_35 = 0.75;
export const CONTRACT_LOW_MORALE = 40;        // morale < 40 → ×1.15
export const CONTRACT_LOW_MORALE_MULT = 1.15;
export const CONTRACT_LOW_APPS_RATIO = 0.5;   // apps < 50% матчей команды → ×1.10
export const CONTRACT_LOW_APPS_MULT = 1.10;
export const CONTRACT_TALENT_GAP = 8;         // (pot−ovr) ≥ 8 и age ≤ 23 → ×1.20
export const CONTRACT_TALENT_AGE = 23;
export const CONTRACT_TALENT_MULT = 1.20;

/** Принятие предложения: offer ≥ 0.92 × demand (ниже — контрпредложение ровно в demand). */
export const CONTRACT_ACCEPT_RATIO = 0.92;
export const CONTRACT_OFFER_MIN_RATIO = 0.8;  // границы слайдера UI / валидации API
export const CONTRACT_OFFER_MAX_RATIO = 1.3;
export const CONTRACT_ROUNDS_MAX = 3;         // раунды переговоров — правило UI-диалога

/** Истечение контракта → рынок свободных агентов. */
export const CONTRACT_FREE_PRICE_RATIO = 0.25; // цена лота = 0.25 × value
export const CONTRACT_FREE_TTL = 8;            // недель жизни лота (вместо 6)
export const CONTRACT_FREE_SALARY_MULT = 1.2;  // зарплата free-агента ×1.2 (компенсация агенту)
export const CONTRACT_DRAIN_AGE = 32;          // дренаж рынка: тихое завершение карьеры
export const CONTRACT_DRAIN_OVR = 55;          // свободные агенты age ≥ 32 И ovr < 55 без лота

/** ИИ-продления: матрица «хочет продлить» (ранг по OVR в составе × возраст). */
export const CONTRACT_AI_WANT: readonly { maxRank: number; maxAge: number; p: number }[] = [
  { maxRank: 11, maxAge: 31, p: 0.90 },
  { maxRank: 11, maxAge: 34, p: 0.65 },
  { maxRank: 16, maxAge: 29, p: 0.50 },
  { maxRank: 16, maxAge: 32, p: 0.30 },
];
export const CONTRACT_AI_WANT_DEFAULT = 0.10;   // глубина состава
export const CONTRACT_AI_UNHAPPY_MULT = 0.5;    // morale < 40 → want × 0.5 (ИИ-«босман»)
export const CONTRACT_AI_SQUAD_FLOOR = 15;      // guard: состав не ниже 15 после истечений
export const CONTRACT_AI_WAGE_RATIO = 0.7;      // guard: зарплаты ≤ 70% оценочного дохода

/** Срок контракта от ИИ: 2 + (≤23 → +2 · ≤27 → +1 · иначе +0). */
export function contractAiYears(age: number): number {
  return 2 + (age <= 23 ? 2 : age <= 27 ? 1 : 0);
}
```

### 2.2. Босман: BOSMAN_*

```ts
// ── Босман-лайт (Фаза 3) ───────────────────────────────────────────────────

export const BOSMAN_SEASON_START = 0.6;   // броски с 60% сезона: week ≥ ceil(0.6 × totalWeeks)
export const BOSMAN_INTERVAL = 4;         // раз в 4 недели (week % 4 === 0)
export const BOSMAN_BASE_P = 0.10;
export const BOSMAN_LOW_MORALE_ADD = 0.30;   // morale < 40
export const BOSMAN_LOW_WAGE_ADD = 0.25;     // salary < 0.7 × computeSalary(value)
export const BOSMAN_LOW_WAGE_RATIO = 0.7;
export const BOSMAN_LOW_APPS_ADD = 0.20;     // apps < 40% матчей команды
export const BOSMAN_LOW_APPS_RATIO = 0.4;
export const BOSMAN_P_CAP = 0.75;
export const BOSMAN_RANK_SPAN = 3;           // клуб предконтракта: ранг силы ± 3 (не клуб игрока)
```

### 2.3. Академия: ACADEMY_*

```ts
// ── Академия (Фаза 3) ──────────────────────────────────────────────────────

export const ACADEMY_INTAKE_WEEK = 4;        // неделя набора (всегда лиговая: CUP_WEEKS не пересекают 4)
export const ACADEMY_SIZE_MIN = 2;           // randInt(2, 4) + tierBonus, кап по SQUAD_MAX
export const ACADEMY_SIZE_MAX = 4;
export const ACADEMY_TIER_STR = { top: 84, mid: 74 } as const; // сила ≥ 84 — топ; 74–83 — середина; < 74 — низ
export const ACADEMY_SIZE_TIER_BONUS = { top: 2, mid: 1, low: 0 } as const; // итог 2–6, среднее ≈ 3.5

export const ACADEMY_AGE_16_P = 0.8;         // 16 лет — 80%, 17 — 20%
export const ACADEMY_AGE_MIN = 16;
export const ACADEMY_AGE_MAX = 17;
export const ACADEMY_OVR_MIN = 34;           // randInt(34, 46) + tierBonus → итог 34–52
export const ACADEMY_OVR_MAX = 46;
export const ACADEMY_OVR_TIER_BONUS = { top: 6, mid: 3, low: 0 } as const;

export const ACADEMY_POT_RANGE = {
  top: [62, 88], mid: [56, 80], low: [50, 72],
} as const;
export const ACADEMY_GEM_P = { top: 0.08, mid: 0.03, low: 0.012 } as const; // «жемчужина»
export const ACADEMY_GEM_POT = [85, 93] as const;
export const ACADEMY_GOLDEN_P = 0.015;       // «золотой набор» за сезон на клуб
export const ACADEMY_GOLDEN_BONUS = 6;       // весь набор +6 к потолку, ≥ 1 жемчужина
export const ACADEMY_CONTRACT_YEARS = 3;     // молодёжный договор

export const ACADEMY_GK_P = 0.5;             // 1 GK с p = 0.5 (только при < 2 GK моложе 33)
export const ACADEMY_GK_YOUNG_MAX = 2;
export const ACADEMY_GK_MAX_AGE = 33;
export const ACADEMY_WEAK_GROUP_P = 0.6;     // 60% — позиция слабейшей группы состава, 40% — шум

/** Звёзды потенциала для UI (research §2.2): pot ≥ 85 → 5★ … < 62 → 1★. */
export const ACADEMY_STARS: readonly { min: number; stars: number }[] = [
  { min: 85, stars: 5 }, { min: 78, stars: 4 }, { min: 70, stars: 3 },
  { min: 62, stars: 2 }, { min: 0, stars: 1 },
];
```

### 2.4. Правление: BOARD_*

```ts
// ── Правление (Фаза 3) ─────────────────────────────────────────────────────

export type BoardTargetCode = 'champion' | 'ucl' | 'uel' | 'upper' | 'safe' | 'survive';

export const BOARD_CONF_START = 55;
export const BOARD_CONF_MIN = 0;
export const BOARD_CONF_MAX = 100;

/** Матчевые дельты (лига И кубок — кубковый матч даёт обе: матчевую + надбавку). */
export const BOARD_DELTA_WIN = 2;
export const BOARD_DELTA_WIN_UPSET = 3;      // победа над соперником сильнее на ≥ 4
export const BOARD_DELTA_DRAW_UP = 1;        // ничья с сильнее на ≥ 4
export const BOARD_DELTA_DRAW_EVEN = 0;
export const BOARD_DELTA_DRAW_DOWN = -1;     // ничья со слабее на ≥ 4
export const BOARD_DELTA_LOSS = -2;
export const BOARD_DELTA_LOSS_DOWN = -3;     // поражение от слабее на ≥ 4
export const BOARD_STRENGTH_GAP = 4;         // порог «заметно сильнее/слабее»

/** Кубковые надбавки (поверх матчевых дельт). */
export const BOARD_DELTA_CUP_ROUND = 4;      // проход раунда
export const BOARD_DELTA_CUP_FINAL = 8;      // выигрыш финала
export const BOARD_DELTA_CUP_UPSET_LOSS = -3; // вылет от заметно слабого

/** Обзор темпа к цели раз в 4 недели. */
export const BOARD_PACE_INTERVAL = 4;
export const BOARD_PACE_AHEAD = 5;           // место ≤ target−3
export const BOARD_PACE_ON_TARGET = 2;       // место ≤ target
export const BOARD_PACE_NEAR = 0;            // место ≤ target+3
export const BOARD_PACE_BEHIND = -5;         // хуже
export const BOARD_PACE_REL_ZONE = -7;       // в зоне вылета при цели ≠ survive

/** Финансы/гармония (еженедельно). */
export const BOARD_DELTA_NEG_BALANCE = -3;   // баланс < 0
export const BOARD_DELTA_WAGES = -1;         // зарплаты > 70% дохода (WAGE_ALERT_RATIO)
export const BOARD_DELTA_HARMONY = -1;       // средняя мораль состава < 45
export const BOARD_HARMONY_MORALE = 45;

/** Медовый месяц. */
export const BOARD_HONEYMOON_WEEKS = 8;      // недели 1–8 каждого сезона
export const BOARD_HONEYMOON_FLOOR = 35;     // confidence не ниже 35

/** 7 статусов должности (отображение, вычисляется из confidence). */
export const BOARD_JOB_STATUSES: readonly { min: number; code: string; label: string }[] = [
  { min: 85, code: 'untouchable', label: 'Неприкасаем' },
  { min: 70, code: 'very_secure', label: 'Очень надёжно' },
  { min: 55, code: 'secure', label: 'Надёжно' },
  { min: 40, code: 'stable', label: 'Стабильно' },
  { min: 30, code: 'pressured', label: 'Под давлением' },
  { min: 20, code: 'hot_seat', label: 'Горячее кресло' },
  { min: 0, code: 'on_edge', label: 'На волоске' },
];

/** Пороги увольнения. */
export const BOARD_WARN_BELOW = 30;          // первое предупреждение за сезон
export const BOARD_ULTIMATUM_BELOW = 20;     // ультиматум «6 недель на исправление»
export const BOARD_SACK_CONF_WEEKLY = 12;    // mid-season: ниже 4 недели подряд (после honeymoon)
export const BOARD_SACK_STREAK = 4;
export const BOARD_SACK_MISS_PLACES = 4;     // переход: промах ≥ 4 мест ниже target
export const BOARD_SACK_CONF = 30;           // …И confidence < 30 на конец сезона
export const BOARD_SACK_CONF_HARD = 15;      // …ИЛИ confidence < 15 (при любом месте)

/** Перевыполнение. */
export const BOARD_OVER_PLACES = 3;          // место ≥ 3 позиций выше цели
export const BOARD_OVER_CONF = 70;           // старт следующего сезона
export const BOARD_OVER_BONUS = 2_000_000;   // разовая премия (категория prize)

/** Потолок амбиций: минимальный ранг цели по силе клуба (правление не ждёт чуда). */
export const BOARD_AMBITION_MIN_RANK = { top: 1, mid: 4, low: 7 } as const; // сила ≥ 84 / 74–83 / < 74

export const BOARD_TARGET_LABELS: Record<BoardTargetCode, string> = {
  champion: 'Выиграть чемпионат',
  ucl: 'Попасть в Лигу чемпионов (топ-3)',
  uel: 'Попасть в еврокубки (топ-6)',
  upper: 'Финишировать в верхней половине',
  safe: 'Уверенно сохранить прописку',
  survive: 'Бороться за выживание',
};
```

### 2.5. Рейтинг матча: RATING_*

```ts
// ── Рейтинг матча (Фаза 3, FM-шкала) ──────────────────────────────────────

export const RATING_BASE = 6.5;              // средняя по лиге ≈ 6.75
export const RATING_WIN = 0.3;
export const RATING_DRAW = 0;
export const RATING_LOSS = -0.3;
export const RATING_GOAL = 0.7;              // за гол
export const RATING_ASSIST = 0.35;           // за ассист
export const RATING_YELLOW = -0.1;
export const RATING_RED = -0.6;
export const RATING_GK_CLEAN = 0.4;          // вратарю за сухой матч
export const RATING_GK_CONCEDED = -0.12;     // за каждый пропущенный
export const RATING_GK_CONCEDED_CAP = -0.6;  // кап штрафа
export const RATING_NOISE = 0.2;             // шум ±0.2 («невидимый вклад»)
export const RATING_MIN = 4.5;
export const RATING_MAX = 10.0;
```

Бенчмарки для подсказок UI: средняя лиги ≈ 6.75 · хороший сезон ≥ 7.2 · звёздный ≥ 7.6 (research §4.2).

---

## 3. Новые модули (src/lib/game/)

Все четыре модуля — чистые функции над POJO/PlayerLike (паттерн training.ts/awards.ts): без Prisma, без fetch; RNG — только явно в параметрах; мутации игроков — на месте (дифф-механизм week.ts запишет). Запись в БД — исключительная зона week.ts и API-роутов.

### 3.1. contracts.ts (~210 строк, новый)

```ts
/** Контракты: сроки, зарплатный спрос, решения ИИ, Босман. Чистые функции (§3 architecture-phase3.md). */

import { CONTRACT_*, BOSMAN_*, SALARY_MIN, SALARY_ROUND } from './constants';
import { computeSalary, type PlayerLike } from './players';
import { clamp, pickWeighted, randInt, type RNG } from './rng';

/** Срок контракта при генерации/покупке по возрастной таблице CONTRACT_YEARS_DISTRIBUTION. */
export function contractYearsRoll(rng: RNG, age: number): number;

/** Последний сезон действия: контракт начинается С сезона season. */
export function contractUntilFromYears(season: number, years: number): number; // season + years − 1, years clamp 1..4

/** Осталось лет (включая текущий сезон); 0 = истёк. */
export function yearsLeftOf(contractUntil: number, season: number): number; // max(0, contractUntil − season + 1)

export type ContractRole = 'star' | 'starter' | 'rotation' | 'depth';

/** Роль по рангу OVR в составе: rank ≤ 3 star · ≤ 11 starter · ≤ 18 rotation · глубже depth. */
export function contractRoleOf(player: PlayerLike, squad: PlayerLike[]): ContractRole;

/**
 * Зарплатный спрос при продлении (единая формула для клуба игрока и ИИ):
 *   base = max(player.salary × CONTRACT_SALARY_FLOOR_RATIO, computeSalary(value) × roleMult)
 *   × (age ≥ 35 ? 0.75 : age ≥ 32 ? 0.90 : 1)
 *   × (morale < 40 ? 1.15 : 1) × (apps < 0.5 × teamApps ? 1.10 : 1)
 *   × ((pot − ovr) ≥ 8 && age ≤ 23 ? 1.20 : 1)
 *   → max(SALARY_MIN, round(x / SALARY_ROUND) × SALARY_ROUND)
 */
export function renewDemand(args: { player: PlayerLike; squad: PlayerLike[]; teamApps: number }): number;

/** Максимум лет продления: 30+ → CONTRACT_VETERAN_MAX_YEARS, иначе CONTRACT_MAX_YEARS. */
export function maxRenewYears(age: number): number;

/** Результат предложения: 'accepted' при offer ≥ CONTRACT_ACCEPT_RATIO × demand, иначе 'counter'. */
export function renewalOutcome(offer: number, demand: number): 'accepted' | 'counter';

/** Вероятность Босман-ухода: 0.10 + 0.30(morale<40) + 0.25(зарплата<0.7 номинала) + 0.20(apps<40%), кап 0.75. */
export function bosmanProbability(args: { player: PlayerLike; teamApps: number }): number;

/** Риск для бейджа UI: p < 0.2 'low' · p < 0.45 'medium' · иначе 'high'. */
export function bosmanRiskOf(p: number): 'low' | 'medium' | 'high';

export interface AiContractDecisions {
  renewed: { player: PlayerLike; years: number; salary: number }[]; // мутации уже применены к PlayerLike
  expired: PlayerLike[]; // истекающие (contractUntil === season), которых клуб НЕ продлил
}

/**
 * ИИ-продления для ОДНОГО клуба в сезонном переходе:
 *  1. кандидаты = contractUntil === season;
 *  2. p = want-матрица CONTRACT_AI_WANT (ранг по OVR × возраст) × (morale < 40 ? 0.5 : 1);
 *  3. guard бюджета: пропускаем продление, если суммарные зарплаты после него
 *     превысят CONTRACT_AI_WAGE_RATIO × income (проверять по нарастающей, начиная с лучших);
 *  4. guard состава: если после всех истечений в клубе < CONTRACT_AI_SQUAD_FLOOR игроков —
 *     лучший истекающий продлевается принудительно (p = 1);
 *  5. продление: contractUntil = season + contractAiYears(age), salary = renewDemand (ИИ не торгуется).
 * Клуб игрока НЕ обрабатывается этой функцией (продления — только вручную через API).
 */
export function aiContractDecisions(args: {
  rng: RNG;
  squad: PlayerLike[];   // весь состав клуба
  season: number;
  income: number;        // оценочный недельный доход (weeklyIncomeEstimate)
}): AiContractDecisions;
```

### 3.2. board.ts (~270 строк, новый)

```ts
/** Цели правления, board confidence, статусы должности, вердикт сезона. Чистые функции. */

/** Ранг клуба по силе в лиге (1 = сильнейший). */
export function strengthRankOf(teams: { id: string; strength: number }[], userTeamId: string): number;

/** Матрица целей: r=1 → champion(место 1) · 2–3 → ucl(3) · 4–6 → uel(6) · 7..⌈N/2⌉ → upper(⌈N/2⌉) · ≤ N−3 → safe(N−4) · последние 3 → survive(N−3). */
export function boardTargetFor(rank: number, teamCount: number): {
  code: BoardTargetCode;
  place: number;
  label: string;
};

/**
 * Цель следующего сезона: базовый ранг = место прошлого сезона (сезон 1 — ранг силы),
 * перевыполнение ужесточает на 1; клампы:
 *   r_min = BOARD_AMBITION_MIN_RANK по силе клуба (сила ≥ 84 → 1 · 74–83 → 4 · < 74 → 7),
 *   r_max = ранг силы + 3 («правление не ждёт чуда» в обе стороны).
 */
export function nextSeasonTarget(args: {
  teamCount: number;
  teams: { id: string; strength: number }[];
  userTeamId: string;
  prevPlace: number | null;       // null для сезона 1
  harderByOverperformance: boolean;
}): { code: BoardTargetCode; place: number; label: string };

/** Статус должности из confidence (7 градаций BOARD_JOB_STATUSES). */
export function jobStatusOf(confidence: number): { code: string; label: string };

export interface BoardWeeklyInput {
  confidence: number;
  week: number;
  totalWeeks: number;
  honeymoonUntilWeek: number;
  place: number;                  // текущее место в ЛИГОВОЙ таблице
  targetPlace: number;
  targetCode: BoardTargetCode;
  teamCount: number;
  /** Матч клуба игрока этой недели (лига ИЛИ кубок); null = кубковая неделя без участия. */
  match: {
    outcome: 'W' | 'D' | 'L';
    myStrength: number;
    oppStrength: number;
    competition: 'league' | 'cup';
    roundPassed: boolean;         // кубок: клуб прошёл раунд
    wonFinal: boolean;            // кубок: выигран финал
    upsetCupLoss: boolean;        // кубок: вылет от соперника слабее на ≥ BOARD_STRENGTH_GAP
  } | null;
  balance: number;                // баланс после недели (в минусе → −3)
  wageRatio: number;              // зарплаты / доход (> 0.7 → −1)
  avgMorale: number;              // средняя мораль состава (< 45 → −1)
}

/**
 * Еженедельный пересчёт confidence:
 *  - матчевая дельта (W +2/+3 · D +1/0/−1 · L −2/−3 по разнице сил);
 *  - кубковые надбавки (раунд +4, финал +8, обидный вылет −3) — поверх матчевых;
 *  - темп к цели при week % BOARD_PACE_INTERVAL === 0 (±5 / −7 в зоне вылета);
 *  - финансы и гармония;
 *  - honeymoon: если week ≤ honeymoonUntilWeek → confidence ≥ BOARD_HONEYMOON_FLOOR;
 *  - clamp BOARD_CONF_MIN..MAX.
 * Возвращает notes — причины дельты для новости «Правление: …».
 */
export function weeklyBoardUpdate(args: BoardWeeklyInput): { confidence: number; delta: number; notes: string[] };

export interface BoardVerdict {
  sacked: boolean;
  verdict: 'met' | 'missed' | 'over';
  confidenceNext: number;
  bonus: number;                          // BOARD_OVER_BONUS при перевыполнении, иначе 0
  news: string[];                         // тексты новостей (вердикт, премия, отставка)
  nextTarget: { code: BoardTargetCode; place: number; label: string };
}

/**
 * Вердикт цели в сезонном переходе:
 *  miss = place − targetPlace;
 *  over = miss ≤ −BOARD_OVER_PLACES; met = miss ≤ 0;
 *  sacked = (miss ≥ BOARD_SACK_MISS_PLACES && confidence < BOARD_SACK_CONF)
 *           || confidence < BOARD_SACK_CONF_HARD;
 *  confidenceNext: over → 70 · met → max(confidence, 60) · missed → без изменений;
 *  бонус €2M (категория prize) при over; nextTarget через nextSeasonTarget(harderByOverperformance).
 */
export function evaluateSeasonTarget(args: {
  place: number;
  confidence: number;           // ПОСЛЕ недельного апдейта финальной недели
  teamCount: number;
  teams: { id: string; strength: number }[];
  userTeamId: string;
  prevPlace: number | null;
}): BoardVerdict;

/** Уровень тревоги для UI: 'none' | 'warning' (< 30) | 'ultimatum' (< 20). */
export function boardWarnLevel(confidence: number): 'none' | 'warning' | 'ultimatum';
```

### 3.3. academy.ts (~230 строк, новый)

```ts
/** Молодёжная академия: набор в неделю 4, качество по тиру клуба. Чистые функции. */

export type AcademyTier = 'top' | 'mid' | 'low';
export function academyTierOf(strength: number): AcademyTier; // ≥ 84 top · 74–83 mid · < 74 low

/** Звёзды потенциала 1..5 (ACADEMY_STARS). */
export function starsOf(potential: number): number;

export interface IntakeResult {
  players: PlayerLike[];        // готовые к playerCreateData; isAcademy = true, contractUntil = season + 2
  golden: boolean;              // «золотой набор»
  gemCount: number;             // число «жемчужин» (pot ≥ 85)
  skippedNoSpace: boolean;      // true = состав полон, набор сокращён до 0
}

/**
 * Набор ОДНОГО клуба (вызывается для всех клубов сейва одним проходом):
 *  - размер = randInt(ACADEMY_SIZE_MIN, MAX) + tierBonus, кап max(0, SQUAD_MAX − squad);
 *  - возраст: 16 лет с p = 0.8, иначе 17;
 *  - позиции: 1 GK с p = ACADEMY_GK_P (только если в составе < ACADEMY_GK_YOUNG_MAX GK моложе
 *    ACADEMY_GK_MAX_AGE); прочие — слабейшая широкая группа состава (broadGroupOf) с
 *    p = ACADEMY_WEAK_GROUP_P, иначе случайная полевая позиция (шум);
 *  - каждый игрок: generatePlayer(rng, randInt(34,46) + ovrTierBonus, позиция, { fixedAge,
 *    potential, contractUntil, pool }) — новый API players.ts (§3.5);
 *  - потенциал: randInt по диапазону тира ACADEMY_POT_RANGE; отдельный бросок «жемчужины»
 *    ACADEMY_GEM_P → randInt(ACADEMY_GEM_POT); «золотой набор» (p = ACADEMY_GOLDEN_P за клуб)
 *    → весь набор + ACADEMY_GOLDEN_BONUS к потолку (кап 99) и ≥ 1 жемчужина;
 *  - ensureUniqueNames по составу (pool лиги).
 */
export function runIntakeForClub(args: {
  rng: RNG;
  season: number;
  team: { id: string; strength: number };
  squad: PlayerLike[];
  pool: NamePoolContext;
}): IntakeResult;

/** Тексты новостей отчёта о наборе для клуба игрока: список игроков со звёздами,
 *  «Наибольшие надежды — {лучший}», спец-новость при золотом наборе, «нет мест» при skippedNoSpace. */
export function intakeNews(args: { teamName: string; result: IntakeResult }): string[];
```

### 3.4. history.ts (~130 строк, новый)

```ts
/** История игрока по сезонам: строки снапшота и карьерные итоги. Чистые функции. */

export interface SeasonRecordRow {
  playerId: string;
  teamId: string | null;
  teamName: string;
  age: number;
  position: string;
  apps: number; goals: number; assists: number;
  cupGoals: number; cupAssists: number; cleanSheets: number;
  yellowCards: number; redCards: number;
  avgRating: number; // ×10; 0 = не играл
}

/**
 * Снапшот ВСЕХ игроков сейва для PlayerSeasonRecord (createMany).
 * squadPlayers — из ctxs (команды), freeAgents — рыночные (teamId = null, teamName «Свободный агент»).
 * avgRating = ratingApps > 0 ? round(ratingSum / ratingApps) : 0   // уже ×10.
 */
export function buildSeasonRecords(args: {
  season: number;
  squadPlayers: PlayerLike[];
  freeAgents: PlayerLike[];
  teamNameById: Map<string, string>;
}): SeasonRecordRow[];

/** Карьерные итоги: суммы по сезонам + средний рейтинг (round до 0.1) + число сезонов. */
export function careerTotalsOf(rows: SeasonRecordRow[]): {
  apps: number; goals: number; assists: number; cleanSheets: number;
  yellowCards: number; redCards: number;
  avgRating: number | null; // 6.8 (не ×10) или null при 0 матчей
  seasons: number;
};
```

### 3.5. Точечные правки существующих чистых модулей

**players.ts** (строки 165–242):
- `PlayerLike` (интерфейс, строка 17) += `contractUntil: number; ratingSum: number; ratingApps: number; isAcademy: boolean; preContractTeamId: string | null;`
- `GeneratePlayerOptions` (строка 165) += `fixedAge?: number; potentialOverride?: number; contractUntil?: number;`
- `generatePlayer` (строка 189): использовать `fixedAge` (если задан — вместо sampleAge), после расчёта потенциала применить `potentialOverride` (clamp по ovr..99), проставить `contractUntil ?? contractUntilFromYears(1, contractYearsRoll(rng, age))`, `ratingSum: 0, ratingApps: 0, isAcademy: false, preContractTeamId: null`.
- `playerCreateData` (строка 408) += все 5 новых полей.

**transfers.ts** (строка 88–89): фильтр `pickAiPurchase` — `.filter((l) => l.source === 'market' || l.source === 'free')` (ИИ покупает и свободных агентов — дренаж рынка фри-агентов, research §1.3.1). Сигнатура не меняется (source уже в типе параметра).

**error.ts** — новые коды (§6.4).

---

## 4. Интеграция в week.ts (точный порядок)

week.ts остаётся единственным модулем игровой логики с доступом к Prisma. Все новые блоки работают через существующие механизмы: `extraOps` (переход), `pendingNews`, дифф `playerDiff`/`DYNAMIC_FIELDS` (строки 46–71), одна транзакция `db.$transaction(ops)` (строка 1401).

### 4.1. Недельный пайплайн simulateWeek — полный порядок Фазы 3

| # | Блок | Якорь в текущем коде | Изменение |
|---|---|---|---|
| 0 | Загрузка save/teams/playerRows/матчей | 414–436 | **+ ленивая миграция контрактов**: `p.teamId ≠ null && p.contractUntil < season → p.contractUntil = season + randInt(migRng, 1, 2)` (rng = `mulberry32(hashString(saveId + ':contractmig:' + season))`; срабатывает один раз, дифф запишет). **+ ленивая инициализация правления**: `save.boardTarget === null` → `nextSeasonTarget` по рангу силы, `boardConfidence = 55`, `honeymoonUntilWeek = min(week + 8, totalWeeks)` (записать в финальный GameSave.update) |
| 1 | Контексты команд + составы | 451–482 | без изменений |
| 2 | Лиговая (521–685) / кубковая (687–1063) неделя | 521 / 687 | симуляция без изменений; **applyPostMatch — новые аргументы** `goalsConceded` + `ratingRng` (оба вызова: строка 650 — лига, переменная `conceded` уже вычислена в 624–643; строка 964 — кубок, `opp`) → начисление рейтинга стартёрам (§5) |
| 3 | Тренировки всех клубов | 1065–1107 | без изменений |
| 4 | Декремент давних травм | 1109–1113 | без изменений |
| 5 | Финансы клуба игрока | 1115–1127 | без изменений (newBalance доступен дальше) |
| 6 | **ПРАВЛЕНИЕ (новое)** | после 1127, до рынка 1129 | `weeklyBoardUpdate(...)` по §3.2 (вход: исход матча клуба игрока из ветки 2 — завести локальный `boardMatchInput` в обеих ветках; место из standings; `balance = newBalance`; `wageRatio = finance.wages / max(1, weeklyIncomeEstimate(place, stadiumCapacity, N))`; `avgMorale` — среднее по userCtx.players). Новость типа `board` раз в 4 недели (вместе с обзором темпа — «Правление: темп к цели …») и при значимых сдвигах (абсолютная дельта ≥ 5). Предупреждение: `confidence < 30 && boardWarnings === 0` → новость + boardWarnings = 1. Ультиматум: `confidence < 20 && boardWarnings === 1` → новость + boardWarnings = 2. **Mid-season sack**: `week > honeymoonUntilWeek && confidence < BOARD_SACK_CONF_WEEKLY` → `boardLowStreak + 1` (иначе сброс в 0); `boardLowStreak ≥ BOARD_SACK_STREAK` → `sackedMidSeason = true` (новость «Вы уволены», статус в шаге 11) |
| 7 | Рынок | 1129–1215 | истечения лотов / офферы / покупки ИИ / догенерация — без изменений; ИИ-покупки теперь видят `source='free'` (§3.5) |
| 8 | **БОСМАН (новое)** | после 1215 | Условие: `week ≥ ceil(BOSMAN_SEASON_START × totalWeeks) && week % BOSMAN_INTERVAL === 0`. Для игроков клуба игрока с `contractUntil === season && preContractTeamId === null`: p = `bosmanProbability({player, teamApps})`; rng = `mulberry32(hashString(saveId + ':bosman:' + season + ':' + week))`. Сработало → выбор клуба предконтракта: ИИ-клубы с рангом силы в пределах ± BOSMAN_RANK_SPAN от ранга клуба игрока (не сам клуб игрока) → `p.preContractTeamId = клуб`; новость типа `transfer`: «{Имя} подписал предконтракт с {Клуб} — уйдёт бесплатно по окончании сезона». Исполнение — в переходе (§4.2 шаг 5a) |
| 9 | **АКАДЕМИЯ (новое)** | после 8 | Условие: `week === ACADEMY_INTAKE_WEEK`. Один проход по всем ctxs: `runIntakeForClub` (rng = `mulberry32(hashString(saveId + ':academy:' + season))`); каждому новичку `shirtNumber = freeShirtNumbers(ctx.players, [])`, `teamId = ctx.team.id`; `ctx.players.push(...)`; op `db.player.create(playerCreateData)` собирается в массив `academyCreates` (аналог scheduledCreates), сливается в ops перед транзакцией. Новости — только клубу игрока (`intakeNews`). Новички НЕ тренируются и НЕ играют на этой неделе (блоки 2–3 уже отработали) — это корректно |
| 10 | Сезонный переход | 1217–1234 | см. §4.2 |
| 11 | Запись транзакции | 1255–1401 | **DYNAMIC_FIELDS (46–53) += `'contractUntil', 'ratingSum', 'ratingApps'`** (рейтинг копится еженедельно — дифф обязателен); в `playerDiff` — спец-кейс `preContractTeamId` (строка, как trainingXp в 66–69); `academyCreates` в ops; GameSave.update (1385–1397) += `boardConfidence, boardWarnings, boardLowStreak` (+ при переходе: `boardTarget, boardTargetPlace, honeymoonUntilWeek: 8, boardWarnings: 0, boardLowStreak: 0`); **`status: sacked ? 'finished' : 'active'`, при sacked — `finishReason: 'sacked'`** |
| 12 | Ответ | 1412–1446 | `WeekResultPayload` += `board: { confidence, delta, jobStatusLabel }` (null при неинициализированном правлении), `sacked: boolean`; `seasonEnded` += `boardVerdict` (§6.2) |

### 4.2. Сезонный переход buildSeasonTransition — полный порядок Фазы 3

Текущий код: строки 209–396. Новый порядок (нумерация сквозная, «─ БЕЗ ИЗМЕНЕНИЙ» = код не трогать):

1. **Призовые по месту** (237–240) — БЕЗ ИЗМЕНЕНИЙ.
2. **Награды** (242–279) — БЕЗ ИЗМЕНЕНИЙ (вычисляются до старения, по статистике завершившегося сезона).
3. **СНАПШОТ ИСТОРИИ (новое, КРИТИЧНЫЙ порядок)**: `buildSeasonRecords({ season, squadPlayers: все игроки из ctxs, freeAgents, teamNameById })` → `extraOps.push(db.playerSeasonRecord.createMany({ data: rows }))`. `freeAgents` — доп. запрос в simulateWeek ПЕРЕД вызовом перехода (функция перехода синхронная): `week >= plan.totalWeeks ? await db.player.findMany({ where: { saveId, teamId: null } }) : []`, передать аргументом. Строго ДО старения (возраст «в тот сезон») и ДО `applySeasonProgression` (иначе все записи — нули).
4. **ВЕРДИКТ ПРАВЛЕНИЯ (новое)**: `evaluateSeasonTarget({ place: userPlace, confidence: boardConfidence после недельного апдейта, ... })`. Действия: при over — `extraOps.push(financeRecord.create({ kind: 'income', category: 'prize', amount: BOARD_OVER_BONUS, description: 'Премия правления за перевыполнение цели' }))` и `prize += BOARD_OVER_BONUS` (в newBalance); новости вердикта — `pendingNews`/`newsOp` типа `board`; запомнить `sacked = verdict.sacked` и nextTarget для шага 12.
5. **КОНТРАКТЫ (новое)**, rng = `mulberry32(hashString(saveId + ':contracts:' + season))`:
   - **5a. Босман-исполнения**: игроки (любого клуба) с `preContractTeamId ≠ null` → `extraOps.push(db.player.update({ where: { id }, data: { teamId: preContractTeamId, preContractTeamId: null, contractUntil: season + contractAiYears(age), salary: renewDemand(...), shirtNumber: freeShirtNumbers(клуб-приёмник, []) } }))`; для клуба игрока — новость типа `transfer` «{Имя} покинул клуб по предконтракту».
   - **5b. ИИ-продления**: для каждого ИИ-клуба `aiContractDecisions({ rng, squad: ctx.players, season, income: weeklyIncomeEstimate(strengthRankPlace(t), t.stadiumCapacity, N) })` — продления мутируют `contractUntil`/`salary` на месте (дифф шага 11 запишет); места приёма босмана и продления НЕ создают listing.
   - **5c. Истечения (все клубы, ВКЛЮЧАЯ клуб игрока)**: игроки с `contractUntil ≤ season`, не продленные в 5b и без preContract → `db.player.update({ data: { teamId: null, salary: roundTo100(max(SALARY_MIN, computeSalary(value) × CONTRACT_FREE_SALARY_MULT)) } })` + `db.transferListing.create({ source: 'free', price: max(10_000, round(value × CONTRACT_FREE_PRICE_RATIO)), askFactor: 1.0, expiresAt: CONTRACT_FREE_TTL, status: 'active' })`. Guard: если у игрока уже есть активный листинг (продан в эту же транзакцию) — листинг не создавать. Для клуба игрока — новость «{Имя} покинул клуб по окончании контракта» (списком, одной новостью).
   - **5d. Дренаж рынка**: свободные агенты (teamId = null) с `age ≥ CONTRACT_DRAIN_AGE && ovr < CONTRACT_DRAIN_OVR` и без активного лота → `deleteMany(listing) + delete(player)` (тихо, без новостей; история уходит каскадом).
6. **Старение / развитие / пенсии** (281–304): `p.age += 1`, `applySeasonProgression` — БЕЗ ИЗМЕНЕНИЙ формул, **УДАЛИТЬ блок генерации клонов-пенсионеров (строки 287–297: `const replacement = generatePlayer(rng, Math.max(40, ctx.team.strength - 5), r.position, { minAge: 17, maxAge: 19, pool })` и весь цикл `for (const r of retired)`)** — академия (шаг 9 недельного пайплайна) + покупки ИИ с рынка — единственные каналы молодёжи. Удаление ушедших (300–304: deleteMany листинга → delete игрока) — ОСТАВИТЬ (чистит и случайно созданные в 5c листинги пенсионеров: истёкший 36-летний получит листинг в 5c и будет удалён в 6 — create-then-delete в одной транзакции безопасен).
7. **Бонусы лауреатам** (306–313) — БЕЗ ИЗМЕНЕНИЙ.
8. **Новый календарь** (315–332) — БЕЗ ИЗМЕНЕНИЙ.
9. **Регенерация рынка** (334–357): `db.transferListing.updateMany({ where: { saveId, status: 'active', **source: { not: 'free' }** }, data: { status: 'expired' } })` — **ИЗМЕНИТЬ фильтр**: free-листинги шага 5c НЕ гасятся регенерацией (иначе «истёкшие контракты» исчезают с рынка в момент создания — ловушка §10.3). Догенерация marketTopUpCount — без изменений (считает только `source === 'market'`).
10. **Призовые finance record** (359–373) — БЕЗ ИЗМЕНЕНИЙ (премия правления уже добавлена в 4).
11. **Новости итогов** (375–391) — БЕЗ ИЗМЕНЕНИЙ; добавляются новости правления/контрактов (шаги 4–5).
12. **GameSave.update** (в simulateWeek, 1385–1397): += `boardTarget/boardTargetPlace` (nextTarget), `boardConfidence: verdict.confidenceNext`, `boardWarnings: 0`, `boardLowStreak: 0`, `honeymoonUntilWeek: BOARD_HONEYMOON_WEEKS`, `status: sacked ? 'finished' : 'active'`, `finishReason: sacked ? 'sacked' : undefined`.

`SeasonTransitionResult` (строка 199) += `sacked: boolean; boardVerdict: { code: 'met' | 'missed' | 'over' | 'sacked'; label: string; bonus: number } | null`.

### 4.3. Правки progression.ts

**applyPostMatch** (строка 35) — новый контракт (рейтинг, §5):

```ts
export interface PostMatchTeam {
  // ...существующие поля (15–24)...
  goalsConceded: number | null; // НОВОЕ: пропущено этой командой (null = нет данных)
}

export function applyPostMatch(
  team: PostMatchTeam,
  injuries: Map<string, number>,
  ratingRng: RNG, // НОВОЕ: шум рейтинга
): void;
```

Внутри стартёра (после `p.apps += 1`, строка 63): вычислить рейтинг (§5), `p.ratingSum += ratingX10; p.ratingApps += 1;` — только стартёрам (запасные рейтинг не получают — замен в движке нет).

**applySeasonProgression** (строка 151): в блок сброса (158–167) добавить `p.ratingSum = 0; p.ratingApps = 0;` (сезонная статистика, сбрасывается вместе с goals/apps).

**retires / developPlayer** — без изменений.

### 4.4. Сводка «что удаляется»

| Что | Где | Почему |
|---|---|---|
| Генерация клона-пенсионера (7 строк: цикл `for (const r of retired) { replacement = generatePlayer(...strength−5, 17–19...) }`) | week.ts 287–297 | академия заменяет канал молодёжи; клон давал ИИ мгновенного 17-летнего OVR ≈ strength−5 → составы не старели (research §2.2) |

Больше ничего не удаляется. Match.winnerTeamId-паттерн, пенальти, тренировки, финансы, кубок, награды — нетронуты.

---

## 5. Рейтинг матча — точная формула и место расчёта

**Где:** `progression.ts::computeMatchRating` (новая экспортная чистая функция рядом с applyPostMatch); вызывается ТОЛЬКО из `applyPostMatch`, который вызывается из week.ts для ВСЕХ клубов в обеих ветках (лига — строка 650, кубок — строка 964). **match.ts НЕ меняется** — все данные (outcome, события, пропущенные) уже есть на входе applyPostMatch. Данные ИИ-матчей достаточны: simulateAiMatch (match.ts:387) генерирует голевые события; карточек/ассистов в ИИ-матчах нет — формула это переживает (нулевые слагаемые).

**Формула (только стартёрам):**

```ts
export function computeMatchRating(args: {
  player: PlayerLike;
  outcome: 'W' | 'D' | 'L';
  goals: number; assists: number; yellows: number; reds: number; // из statFromEvents
  goalsConceded: number | null; // этой команды
  rng: RNG;
}): number /* ×10, int */ {
  let r = RATING_BASE
    + (outcome === 'W' ? RATING_WIN : outcome === 'D' ? RATING_DRAW : RATING_LOSS)
    + goals * RATING_GOAL
    + assists * RATING_ASSIST
    + yellows * RATING_YELLOW
    + reds * RATING_RED;
  if (player.position === 'GK' && args.goalsConceded !== null) {
    r += goalsConceded === 0
      ? RATING_GK_CLEAN
      : Math.max(RATING_GK_CONCEDED_CAP, goalsConceded * RATING_GK_CONCEDED);
  }
  r += (rng() * 2 - 1) * RATING_NOISE;           // шум ±0.2
  r = clamp(r, RATING_MIN, RATING_MAX);           // 4.5..10.0
  return Math.round(r * 10);                      // ×10 → Int (округление до 0.1)
}
```

**Хранение:** `p.ratingSum += ratingX10; p.ratingApps += 1;` (стартёры). Средний = `ratingApps > 0 ? ratingSum / ratingApps / 10 : null` (в DTO — с округлением до 0.1). Сброс — в applySeasonProgression (§4.3).

**RNG-дисциплина:** `ratingRng = mulberry32(hashString(saveId + ':rating:' + season + ':' + week + ':' + teamId))` — отдельный на команду, детерминированно.

**Калибровка (для QA):** стартёр-победитель без гола ≈ 6.8; забивший ≈ 7.5; GK с сухой в победе ≈ 7.2; проигравший с красной ≈ 5.6; средняя лиги ≈ 6.7–6.8 за 10+ недель; максимум 10 достижим (пента + победа). Известная особенность движка: авторы голов ИИ-матчей выбираются из всего состава (не только стартёров) — у «забившего запасного» растут goals без ratingApps; не баг, поведение не меняется.

---

## 6. API-контракты

Стиль — в точности как Фаза 2: `{ ok: true, ... }` / `{ ok: false, error }`, zod-валидация тела, `resolveSave`/`resolvePlayingSave` из api-helpers.ts, `normalizeErrorCode` в catch. Легаси-фолбэк без saveId сохраняется для GET-роутов.

### 6.1. Новые эндпоинты (5 роутов)

**GET /api/game/contracts?saveId=** → `ContractsResponse`

```ts
export interface ContractInfoDTO {
  playerId: string; name: string; position: Position;
  age: number; ovr: number; value: number; salary: number;
  contractUntil: number; yearsLeft: number;
  renewable: boolean;      // yearsLeft ≤ CONTRACT_RENEWABLE_YEARS_LEFT && preContractTeamId === null
  demand: number | null;   // зарплатный спрос (заполняется для renewable)
  maxRenewYears: number;   // maxRenewYears(age)
  preContract: boolean;    // Босман: уйдёт в конце сезона
  bosmanRisk: 'low' | 'medium' | 'high';
}
export interface ContractsResponse { ok: true; season: number; contracts: ContractInfoDTO[] }
```

Логика: состав клуба игрока, отсортирован по yearsLeft asc, затем по OVR desc. `teamApps` для demand/риска Босмана — «число матчей команды» = `Math.ceil(sum(apps 11 игроков с наибольшими apps) / 11)` (стартовое ядро; запасные не искажают знаменатель).

**POST /api/game/contracts/renew** — тело `{ saveId: string; playerId: string; years: number; salary: number }` (zod: saveId/playerId — uuid-строки, years int 1..4, salary int ≥ 0):

```ts
export interface RenewResponse {
  ok: true;
  outcome: 'accepted' | 'counter';
  demand: number;              // всегда возвращаем спрос (для контрпредложения UI)
  snapshot?: GameSnapshot;     // только при accepted (состояние изменилось)
}
```

Логика: `resolvePlayingSave` → игрок `findFirst({ id, saveId, teamId: save.teamId })`, иначе 404 `NOT_YOUR_PLAYER`. Проверки: `preContractTeamId ≠ null` → 409 `CONTRACT_PRECONTRACT`; `yearsLeft > CONTRACT_RENEWABLE_YEARS_LEFT` → 400 `CONTRACT_NOT_RENEWABLE`; `years > maxRenewYears(age)` или `years < 1` → 400 `INVALID_CONTRACT`; `salary` вне `[floor(0.8 × demand / 100) × 100, ceil(1.3 × demand / 100) × 100]` → 400 `INVALID_CONTRACT`. Расчёт `demand = renewDemand(...)` (состав — клуб игрока). `renewalOutcome(salary, demand)`: accepted → `db.player.update({ data: { contractUntil: save.season + years, salary } })` + вернуть свежий `buildSnapshot`; counter → ничего не менять, вернуть demand. Сервер stateless: «3 раунда / повтор через 4 недели» — правило UI-диалога (§7.1), формула demand детерминирована — повтор ничего не даёт.

**GET /api/game/board?saveId=** → `BoardResponse`

```ts
export interface BoardResponse {
  ok: true;
  board: BoardDTO;               // тот же DTO, что в state (§6.2)
  news: NewsDTO[];               // последние 10 новостей типа 'board'
}
```

**GET /api/game/academy?saveId=** → `AcademyResponse` (решение по открытому вопросу задачи: отдельный эндпоинт, а не state — состав воспитанников не нужен каждому запросу снапшота)

```ts
export interface AcademyPlayerDTO {
  id: string; name: string; position: Position;
  age: number; ovr: number; potential: number;
  stars: number;                 // 1..5 (starsOf)
  contractUntil: number; yearsLeft: number;
  value: number; salary: number;
}
export interface AcademyResponse { ok: true; graduates: AcademyPlayerDTO[] }
```

Логика: `db.player.findMany({ where: { saveId, teamId: save.teamId, isAcademy: true } })`, сортировка по potential desc. Отчёт о наборе — новости недели 4 (intakeNews), экран показывает воспитанников постоянно.

**GET /api/game/player?saveId=&id=** → `PlayerDialogResponse` (решение по открытому вопросу: query-параметр `id` в едином стиле с `/match`, БЕЗ динамического сегмента; лениво подгружается при открытии диалога игрока — не раздувать /state историей ~450 строк)

```ts
export interface PlayerHistoryDTO {
  season: number; teamName: string; age: number; position: string;
  apps: number; goals: number; assists: number;
  cupGoals: number; cupAssists: number; cleanSheets: number;
  yellowCards: number; redCards: number;
  avgRating: number | null;      // 6.8 (не ×10); null = 0 матчей
}
export interface CareerTotalsDTO {
  apps: number; goals: number; assists: number; cleanSheets: number;
  yellowCards: number; redCards: number; avgRating: number | null; seasons: number;
}
export interface PlayerDialogDTO {
  player: PlayerDTO;
  history: PlayerHistoryDTO[];   // по возрастанию сезона
  totals: CareerTotalsDTO;
  awards: SeasonAwardDTO[];      // награды игрока за все сезоны
}
export interface PlayerDialogResponse { ok: true; dialog: PlayerDialogDTO }
```

Логика: игрок `findFirst({ id, saveId })` → 404 `PLAYER_NOT_FOUND` (игрок может быть ЧУЖИМ или рыночным — разрешено: «скаутинг» по истории игрока рынка). История: `db.playerSeasonRecord.findMany({ where: { playerId, saveId }, orderBy: season asc })`; награды: `db.seasonAward.findMany({ where: { playerId, saveId } })` ( typeName уже считается как в /awards).

### 6.2. Изменения DTO (types.ts — зона Блока A, интерфейсы замораживаются до Блока B)

```ts
// PlayerDTO (строка 135) += аддитивно:
  contractUntil: number;
  avgRating: number | null;    // текущий сезон; null = не играл
  preContract: boolean;        // уходит по Босману

// GameSnapshot (строка 473) += аддитивно:
  board: BoardDTO;                       // НОВОЕ
  contractsExpiring: ContractExpiringDTO[]; // НОВОЕ (yearsLeft ≤ 1)

export interface BoardDTO {
  target: BoardTargetCode;
  targetLabel: string;         // BOARD_TARGET_LABELS
  targetPlace: number;
  confidence: number;          // 0..100
  jobStatus: string;           // код
  jobStatusLabel: string;      // «Под давлением» и т.д.
  honeymoonWeeksLeft: number;  // max(0, honeymoonUntilWeek − week)
  warnLevel: 'none' | 'warning' | 'ultimatum';
}

export interface ContractExpiringDTO {
  playerId: string; name: string; position: Position;
  age: number; ovr: number; value: number; salary: number;
  contractUntil: number; yearsLeft: number;
  demand: number; maxRenewYears: number;
  preContract: boolean;
}

// WeekResultPayload (строка 547) += аддитивно:
  board: { confidence: number; delta: number; jobStatusLabel: string } | null;
  sacked: boolean;
// WeekResultPayload.seasonEnded += аддитивно:
  boardVerdict: { code: 'met' | 'missed' | 'over' | 'sacked'; label: string; bonus: number } | null;

// MarketListingDTO.source (строка 518): 'market' | 'user' | 'free'
// NewsType (строка 325) += 'board' | 'academy'   (иконки — Блок B)
```

### 6.3. Таблица изменений существующих роутов

| Роут | Изменение |
|---|---|
| `GET /api/game/state` (state/route.ts) | `buildSnapshot` допускает `status === 'finished'` (сейчас 404 на не-active — строка 21 роута и строка 234 snapshot.ts: условие `save.status !== 'active'` → `save.status !== 'active' && save.status !== 'finished'`); снапшот += board/contractsExpiring; toPlayerDTO += 3 поля |
| `POST /api/game/simulate` | тело без изменений; payload += board/sacked/boardVerdict; вся логика — week.ts §4 |
| `GET /api/game/market` | без изменений кода (free-лоты приходят из общего запроса активных листингов); DTO source расширен |
| `POST /api/game/market/buy` | при покупке: `contractUntil = contractUntilFromYears(save.season, contractYearsRoll(rng, age))`, rng = `mulberry32(hashString(saveId + ':contractbuy:' + playerId))` — добавить в player.update; аналогичное присвоение в week.ts для ИИ-покупок (ops `aiPurchases`, строки 1342–1346) |
| `POST /api/game/saves` (saves/route.ts) | generatePlayer уже проставляет contractUntil (§3.5); GameSave.create data += `boardTarget/boardTargetPlace` (nextSeasonTarget по рангу силы), `boardConfidence: BOARD_CONF_START`, `honeymoonUntilWeek: BOARD_HONEYMOON_WEEKS`; welcome-новость += строка «Правление: {цель сезона}» |
| `GET /api/game/saves`, `PATCH/DELETE /saves/[id]` | без изменений (status 'finished' уже течёт через SaveCardDTO.status) |
| `POST /api/game/tactic`, `/training`, `/market/sell`, `/match`, `/new`, `/select`, `/leagues`, `/awards` | без изменений (resolvePlayingSave сам блокирует finished-сейвы — 404) |

### 6.4. Новые коды ошибок (error.ts)

```ts
// ── Фаза 3 ──
INVALID_CONTRACT: 'Неверные параметры продления контракта',           // 400
CONTRACT_NOT_RENEWABLE: 'Контракт можно продлить, когда осталось не более 2 лет', // 400
CONTRACT_PRECONTRACT: 'Игрок подписал предконтракт с другим клубом',  // 409
PLAYER_NOT_FOUND: 'Игрок не найден',                                  // 404
```

---

## 7. UI-план (Блок B)

Палитра проекта (без изменений, БЕЗ синих/индиго): фон `#0D1210`, поверхности `#151D18`/`#1C2620`, границы `#2A382F`, акцент `#2E9E5B` (primary), текст `#F0F0E0`, золото — устоявшийся в проекте `#EAB308` (SeasonCeremony/PlayerDialog; заявленный `#D4AF37` визуально идентичен на тёмном фоне — НЕ вводить два золотых), красный `#F87171`, зелёный успех `#4ADE80`. Все тексты на русском. Тач-таргеты ≥ 44px (кнопки `min-h-11` — как в PlayerDialog, табы моб. `min-h-[56px]` — как в GameShell).

### 7.1. Контракты — секции, БЕЗ новой вкладки (10 вкладок + 1 «Академия» = 11, контракты не тянут отдельный экран)

- **SquadScreen**: колонка/бейдж «Контракт до {season}» (или «истекает» — жёлтый `#EAB308`, «предконтракт» — красный `#F87171` с подписью «уходит»); новый `sortKey = 'contract'` (по yearsLeft asc) в существующий Select сортировки (строка 120); фильтр-чип «Истекают N» при `contractsExpiring.length > 0`.
- **PlayerDialog** (замена строки 293–297 «Контракт: бессрочный»): плашка «До конца сезона {contractUntil} · {yearsLeft} г.» + бейджи истечения/предконтракта. Кнопка «Продлить контракт» (видна при `yearsLeft ≤ 2 && !preContract`, mode = 'squad') раскрывает переговорную секцию: ожидания (demand, «игрок хочет ~{demand}/нед»), выбор срока (Select 1..maxRenewYears лет), слайдер зарплаты 80–130% demand (step SALARY_ROUND), кнопка «Предложить» → `store.renewContract`. Outcome: accepted → toast «Контракт продлён до {season}», диалог закрыть; counter → показать контрпредложение «Игрок настаивает на {demand}/нед», счётчик раундов 1..CONTRACT_ROUNDS_MAX, после 3 — кнопка блокируется с подписью «Переговоры прерваны». Данные demand — из `snapshot.contractsExpiring` / `store.contractsCache`.
- **DashboardScreen**: компактная строка в карточке «Правление» (§7.2): «Истекают контракты: N» (клик → таб squad с фильтром).

### 7.2. Панель «Правление» на дашборде

Новая карточка после блока «Состояние команды» (TeamState, строка 288 DashboardScreen), до ленты новостей: заголовок «Правление» + цель сезона (`board.targetLabel`, например «Попасть в Лигу чемпионов (топ-3)») · Progress-бар confidence (0–100; цвет: ≥ 55 — primary, 30–54 — `#EAB308`, < 30 — `#F87171`) · статус должности (`jobStatusLabel`, бейдж) · подпись «Медовый месяц: N недель» при `honeymoonWeeksLeft > 0` · warnLevel warning/ultimatum — красная строка-предупреждение · строка «Истекают контракты: N» (см. §7.1). Мобайл: карточка одноколоночная, full-width.

### 7.3. Вкладка «История» в PlayerDialog

Диалог получает внутренние табы: «Обзор» (всё текущее содержимое) / «История» (только для mode 'squad' и 'market' — единообразно; доступна всегда, для новичка — empty state «Первый сезон в лиге»). Переключение впервые → `store.fetchPlayerDialog(playerId)` (GET /player, кеш `Map<playerId, PlayerDialogDTO>` в сторе, инвалидируется при смене activeSaveId). Таблица (горизонтальный скролл на мобайл, `text-xs`, `tabular-nums`): Сезон | Клуб | Возраст | Матчи | Голы | Ассисты | Рейтинг | Ж/К | Сухие. Итоговая строка (totals): «Карьера: {seasons} сезонов · {apps} матчей · {goals} голов · {assists} ассистов · средний рейтинг {avgRating ?? '—'}». Блок «Награды»: бейджи `typeName` по сезонам. Подсказка-легенда: «Хороший сезон — рейтинг 7.2+».

### 7.4. Экран «Академия» (новая вкладка)

`GameShell` TABS (строка 28) += `{ id: 'academy', label: 'Академия', icon: GraduationCap }` после «Тренировки»; `ScreenSwitch` += case; TabId += 'academy'. MOBILE_TABS НЕ меняется (5+«Ещё…» — академия попадает в MoreSheet автоматически; обновить aria-label «Ещё…»). Экран: заголовок «Академия» + подпись «Набор воспитанников — 4-я неделя каждого сезона»; список карточек `graduates` (AcademyScreen): имя, PositionBadge, возраст, OvrBadge, потенциал звёздами (`★` × stars, цвет `#EAB308`), «Контракт до {season}», стоимость. Тап по карточке → PlayerDialog (mode 'squad'). Empty state: «Воспитанники появятся после первого набора — неделя 4». Отчёт о наборе — новости недели 4 (тип 'academy', иконка GraduationCap в NEWS_ICONS). Кеш `academyCache` в сторе (инвалидировать при season change / playWeek).

### 7.5. Экран «Карьера завершена» (увольнение) + SeasonCeremony

- **Новый компонент CareerOverScreen**: полноэкранный оверлей (`fixed inset-0 z-50`, паттерн SeasonCeremony): иконка LogOut/Briefcase в красном круге, заголовок «Карьера завершена», текст «Правление отправило вас в отставку. Сезон {N}, {place}-е место, доверие {confidence}/100.» (для mid-season — «…после {N} недель сезона»), кнопки «К списку карьер» (`exitToCareers`, min-h-11) и «Удалить карьеру» (variant outline, с подтверждением — reuse паттерн удаления из CareersScreen). Рендер: `GameShell` рендерит CareerOverScreen поверх контента при `snapshot.save.status === 'finished'` (страховка: все серверные действия для finished уже 404).
- **Mid-season sack**: `playWeek` получил `res.result.sacked === true` → после закрытия экрана результата недели пользователь видит CareerOverScreen (hydrate уже вернул status finished).
- **Transition sack**: SeasonCeremony при `ended.boardVerdict.code === 'sacked'` — вариант заголовка «Сезон {N} завершён — вы уволены», вердикт-строка (§7.6), кнопка «Закрыть карьеру» → `exitToCareers` (CareerOverScreen как страховка не нужен поверх — но статус рендерится по правилу выше, кнопка церемонии вызывает exitToCareers напрямую).
- **CareersScreen**: у карточек с `status === 'finished'` — бейдж «Уволен» (красная рамка `#F87171`/40), кнопка «Продолжить» скрыта (открывается только просмотр поверх GameShell → CareerOverScreen).

### 7.6. SeasonCeremony — вердикт правления

После блока «Призовая тройка» — строка вердикта: met → «Цель сезона выполнена: {targetLabel}» (primary); over → «Цель перевыполнена! Премия правления €2 000 000» (золото `#EAB308`); missed → «Цель сезона провалена» (muted); sacked → «Вы уволены» (красный). Обычная кнопка «Начать сезон {N+1}» остаётся (для не-sacked).

### 7.7. Мелкие правки

- `NEWS_ICONS` (DashboardScreen строка 25, MatchScreen аналогично) += `board: Landmark/Building`, `academy: GraduationCap`.
- Хедер GameShell: при `warnLevel ≠ 'none'` — маленький индикатор рядом с бейджем недели (красная точка + title).
- MatchScreen/TransfersScreen: колонка «Рейтинг» (avgRating, «—» если null) — по возможности без перестройки сетки; минимум — рейтинг в PlayerDialog.

---

## 8. Порядок реализации — Блок A (backend) и Блок B (frontend)

Блоки идут СТРОГО последовательно: A завершён и снят `tsc --noEmit` + смоук по API → B начинает. Интерфейс (types.ts из A) заморожен до конца B. **Пересечение файлов между блоками запрещено.**

### Блок A — backend (один агент)

| Шаг | Файл | ~строк | Содержание |
|---|---|---|---|
| A1 | `prisma/schema.prisma` | +55 | §1; затем `bunx prisma db push` + **перезапуск dev-сервера** (§10.1!) |
| A2 | `src/lib/game/constants.ts` | +130 | все блоки §2 (включая `contractAiYears`, `BoardTargetCode`, `BOARD_JOB_STATUSES`, `BOARD_TARGET_LABELS`) |
| A3 | `src/lib/game/types.ts` | +190 | все DTO/типы §6.2 (зона заморозки для B) |
| A4 | `src/lib/game/players.ts` | +30 | PlayerLike +5 полей, GeneratePlayerOptions +3 опций, generatePlayer, playerCreateData |
| A5 | `src/lib/game/progression.ts` | +70 | PostMatchTeam.goalsConceded, applyPostMatch(rng), computeMatchRating (§5), сброс ratingSum/ratingApps |
| A6 | `src/lib/game/contracts.ts` | ~210 | новый модуль §3.1 |
| A7 | `src/lib/game/board.ts` | ~270 | новый модуль §3.2 |
| A8 | `src/lib/game/academy.ts` | ~230 | новый модуль §3.3 |
| A9 | `src/lib/game/history.ts` | ~130 | новый модуль §3.4 |
| A10 | `src/lib/game/transfers.ts` | +8 | pickAiPurchase видит 'free' |
| A11 | `src/lib/game/week.ts` | +280 / −7 | пайплайн §4.1 + переход §4.2 + удаление клонов |
| A12 | `src/lib/game/snapshot.ts` | +110 | board/contractsExpiring/toPlayerDTO/status 'finished' |
| A13 | `src/lib/game/error.ts` | +10 | коды §6.4 |
| A14 | роуты: `contracts/route.ts` (~80), `contracts/renew/route.ts` (~130), `board/route.ts` (~55), `academy/route.ts` (~70), `player/route.ts` (~100) | ~435 | §6.1 |
| A15 | правки роутов: saves POST, state, buy (+week.ts aiPurchases) | ~120 | §6.3 |

Итого Блок A ≈ **2000–2100 строк**. Приёмка A: `tsc --noEmit` 0 ошибок, `bun run lint` 0, смоук-сценарий curl (создать сейв → 4 недели (академия) → досимулировать до конца сезона через POST /simulate циклом → проверить снапшот/контракты/вердикт/finished) — инварианты §9 №1–№14, 16–18, 20–22.

### Блок B — frontend (один агент)

| Шаг | Файл | ~строк | Содержание |
|---|---|---|---|
| B1 | `src/lib/game/api.ts` | +70 | getContracts/renewContract/getBoard/getAcademy/getPlayerDialog |
| B2 | `src/lib/store.ts` | +130 | TabId 'academy'; contractsCache/academyCache/playerDialogCache + fetch-экшены; renewContract; sacked-обработка в playWeek; инвалидации кешей при season change |
| B3 | `src/components/game/GameShell.tsx` | +20 | вкладка «Академия», рендер CareerOverScreen при status finished, индикатор warnLevel |
| B4 | `src/components/game/DashboardScreen.tsx` | +120 | панель «Правление» §7.2 + NEWS_ICONS |
| B5 | `src/components/game/SquadScreen.tsx` | +70 | бейджи контрактов, sortKey 'contract', фильтр «Истекают» |
| B6 | `src/components/game/PlayerDialog.tsx` | +230 | табы Обзор/История, контрактная плашка, переговоры продления §7.1/§7.3 |
| B7 | `src/components/game/AcademyScreen.tsx` | ~220 | новый экран §7.4 |
| B8 | `src/components/game/CareerOverScreen.tsx` | ~150 | новый экран §7.5 |
| B9 | `src/components/game/SeasonCeremony.tsx` | +70 | вердикт правления + sacked-вариант §7.6 |
| B10 | `src/components/game/CareersScreen.tsx` | +20 | бейдж «Уволен», скрытие «Продолжить» |
| B11 | `src/components/game/MatchScreen.tsx` / `TransfersScreen.tsx` | +30 | колонка «Рейтинг» (минимум — PlayerDialog) |

Итого Блок B ≈ **1050–1150 строк**. Приёмка B: браузерный прогон (agent-browser): панель правления, продление контракта, история игрока, академия, полный сезон с церемонией + вердикт, сценарий увольнения, мобайл 375px, консоль пуста.

Файлы, которые НЕ трогает никто: match.ts, cup.ts, standings.ts, training.ts, awards.ts, finances.ts, calendar.ts, generate.ts, leagues.ts, data.ts, poisson.ts, rng.ts, lineup.ts, strength.ts, format.ts, api-helpers.ts (кроме чтения), db.ts, page.tsx, NewCareerFlow, LeagueScreen, CupScreen, TacticsScreen, TrainingScreen, FinancesScreen, AwardsScreen, ClubCard, PitchField, PlayerChip, MatchTimeline, shared/*.

---

## 9. Критерии приёмки QA (22 проверяемых инварианта)

1. **Схема аддитивна**: сейв Фазы 2, созданный до диффа, после `bunx prisma db push` открывается (GET /state 200) и переживает POST /simulate (миграция contractUntil < season → season+1..2 board-инициализация сработали).
2. **Генерация мира**: у каждого игрока каждого клуба `contractUntil ∈ [1, 4]` в сезоне 1; на большой выборке распределение сроков соответствует таблице §2.1 (мода 2–3 года).
3. **Истечение → рынок**: игрок с `contractUntil === S` (без продления и предконтракта) после перехода конца сезона S имеет `teamId = null` и активный лот `source = 'free'`, `price = max(10 000, round(0.25 × value))`, `expiresAt = 8`.
4. **Free-листинги переживают регенерацию рынка**: после сезонного перехода все лоты `source = 'free'` остались `status = 'active'` (регенерация гасит только `source ≠ 'free'`).
5. **Снапшот до сброса**: сумма `goals` по записям PlayerSeasonRecord сезона S равна сумме `Player.goals` по сейву ДО перехода; после перехода у всех игроков `goals = apps = assists = ... = ratingSum = ratingApps = 0`.
6. **avgRating записи**: `avgRating = round(ratingSum / ratingApps)` (×10) на момент снапшота; `ratingApps = 0 → avgRating = 0`.
7. **Клоны-пенсионеры не генерируются**: в сезонном переходе не появляется НИ ОДНОГО нового игрока 17–19 лет с `ovr ≥ strength клуба − 8` (проверка по БД до/после перехода); новые 16–17-летние появляются только на неделе 4 (академия, `isAcademy = true`, `ovr ≤ 52`).
8. **Академия — неделя 4**: после симуляции недели 4 каждого клуба `+2..6` игроков (или меньше при составе 25) возраста 16/17 с `ovr ∈ [34, 52]`, `contractUntil = S + 2`, `isAcademy = true`.
9. **Тиры академии**: у топ-клуба (сила ≥ 84) средний потенциал набора значимо выше, чем у клубов < 74 (стат-проверка 100 бросков: pot max топа ≥ 88).
10. **Жемчужина**: pot ≥ 85 у 16–17-летних встречается с частотой ≈ 0.08/0.03/0.012 по тиру (допуск ×0.5 на 1000 бросков); «золотой набор» даёт всему набору pot + 6 и ≥ 1 жемчужину.
11. **Confidence реагирует**: после победы confidence вырос на ≥ 2 (или на 3 при сопернике сильнее на ≥ 4); после поражения упал на 2/3; всегда в [0, 100].
12. **Honeymoon**: в неделях 1–8 сезона confidence ≥ 35 при любых результатах (серия из 6 поражений подряд).
13. **Предупреждение единственно**: при падении ниже 30 за сезон создаётся ровно ОДНА новость типа 'board' предупреждения (boardWarnings = 1); ниже 20 — один ультиматум.
14. **Mid-season sack**: confidence < 12 в течение 4 недель подряд (после honeymoon) → `status = 'finished'`, `finishReason = 'sacked'`, WeekResultPayload.sacked = true; при восстановлении выше 12 streak сбрасывается.
15. **Sack в переходе**: (place − target ≥ 4 И confidence < 30) ИЛИ confidence < 15 → 'finished'; ни одно из условий не выполнено → 'active'.
16. **Перевыполнение**: place ≤ target − 3 → в новом сезоне confidence = 70, finance record €2M (prize), цель следующего сезона на ступень амбициознее, но не ниже потолка амбиции по силе клуба.
17. **Рейтинг — только стартёры**: после матча `ratingApps` вырос ровно у 11 стартёров (валидный состав), у запасных не изменился; ratingSum ∈ [45×11, 100×11] на команду.
18. **Средняя лиги**: после ≥ 10 недель средний avgRating по всем игрокам с ratingApps > 0 ∈ [6.4, 7.1].
19. **Босман**: игрок клуба игрока с `contractUntil = S`, morale < 40 на 60%+ сезона с p ≥ 0.4 покидает клуб в переходе → в составе ИИ-клуба (preContractTeamId исполнен), клуб игрока не получил €; новость о предконтракте была в ленте.
20. **ИИ-продления**: после перехода каждый ИИ-клуб имеет ≥ 15 игроков (guard сработал при массовых истечениях); суммарные зарплаты любого ИИ-клуба ≤ 70% его оценочного дохода.
21. **Продление игроком**: POST /contracts/renew с offer = 0.92 × demand → accepted, `contractUntil = season + years`, salary = offer; с offer < 0.92 × demand → counter с demand, контракт не изменился; years > maxRenewYears(30+) → 400.
22. **Покупка free-агента**: после buy у игрока `contractUntil = season + годы − 1`, лот `sold`; GET /state для finished-сейва → 200 со status 'finished', POST /simulate → 404.

Дополнительно (сквозные): lint 0, `tsc --noEmit` 0 (src/), dev.log без ошибок компиляции, консоль браузера пуста.

---

## 10. Риски и ловушки

1. **Stale Prisma-клиент после db push — РЕАЛЬНЫЙ кейс проекта** (worklog, Task 10-a-2: `PrismaClientValidationError «Unknown argument lastOpenedAt»` — dev-сервер, запущенный до пуша, держал старый клиент и старый Turbopack-кэш). После `bunx prisma db push` ОБЯЗАТЕЛЬНО перезапустить dev-сервер тем же механизмом (bun run dev в фоне, порт 3000) и проверить dev.log. Это первый шаг Блока A.
2. **Порядок сезонного перехода**: снапшот PlayerSeasonRecord — строго МЕЖДУ наградами (шаг 2) и `applySeasonProgression` (шаг 6), иначе записи — нули; вердикт правления — до контрактов (порядок новостей: «цель выполнена/провалена» — первая в новом сезоне); ИИ-продления — до истечений (иначе guard состава считает уже ушедших); create-then-delete (истёкший пенсионер: листинг в 5c → удаление в 6) безопасен внутри одной транзакции, порядок ops не менять.
3. **Регенерация рынка гасит free-листинги**: текущий `updateMany({ where: { status: 'active' } })` (week.ts 335–337) без фильтра source мгновенно «истекает» только что созданные free-лоты. Обязательно `source: { not: 'free' }` (§4.2 шаг 9). Проверяется инвариантом №4.
4. **FK-каскады**: PlayerSeasonRecord.player — Cascade: пенсионеры уносят свою историю (осознанно, §1.3); при удалении сейва каскад от saveId сработает раньше — порядок delete в DELETE /saves/[id] не менять. `preContractTeamId` — скаляр без FK (клуб-приёмник может быть удалён только вместе с сейвом — риска нет).
5. **Unique-индекс TransferListing.playerId**: у игрока не может быть двух активных лотов. При истечении контракта (5c) проверять отсутствие активного листинга (игрок мог быть продан в эту же неделю). При удалении игрока — существующий `deleteMany` перед `delete` (week.ts 301–303) обязателен.
6. **Производительность снапшота**: ~450 строк одним `createMany` (НЕ создавать по одной); транзакция перехода вырастает до ~1500 ops — Prisma батчит сам, SQLite переносит; измерить время перехода (ожидание < 1 c).
7. **Легаси-сейвы**: contractUntil = 3 опасен для сейвов в сезоне ≥ 4 — ленивая миграция (§4.1 шаг 0) обязательна; boardTarget = null — ленивая инициализация. Оба — идемпотентные, срабатывают один раз.
8. **ratingSum ×10 Int**: не хранить float; средний рейтинг всегда `ratingSum / ratingApps / 10` с округлением до 0.1 на выводе. В PlayerSeasonRecord.avgRating — тоже ×10.
9. **Детерминизм**: все новые rng — `mulberry32(hashString(saveId + ':' + домен + ':' + season [:week [:teamId]]))` — по образцу существующих (finance/market/training). Никаких Math.random.
10. **Дифф-механизм**: DYNAMIC_FIELDS обязан пополниться `contractUntil/ratingSum/ratingApps` (рейтинг копится еженедельно — без диффа изменения потеряются); `preContractTeamId` — строковое поле, спец-кейс по образцу trainingXp (week.ts 66–69). Новые игроки (академия/рынок) НЕ в playerRows — только create-ops, дифф их не трогает.
11. **Состав ИИ после удаления клонов**: пенсионный слив (~1–2/сезон/клуб) + истечения могут опустить клуб ниже SQUAD_MIN 13 в неудачном сезоне; guard продлений держит 15, набор академии ≈ 3.5/сезон. Мониторить инвариант №20 на 5+ сезонах; при деградации — точечная правка (не в объёме Фазы 3): принудительный добор ИИ с рынка.
12. **UI-ловушки**: строка PlayerDialog «Контракт: бессрочный» (строка ~295) — заменить обязательно, иначе механика невидима (research §1.3.4: «рейтинг контрактов в UI решает всё»); 11-я вкладка — проверить мобильный MoreSheet (список extra растёт) и aria-label; CareerOverScreen перекрывает GameShell (z-50) — не блокировать выход к карьерам.
13. **Босман — только последний год**: броски лишь для `contractUntil === season` (не по yearsLeft ≤ 1 в целом); предконтрактный игрок (`preContractTeamId ≠ null`) не продлевается — 409 CONTRACT_PRECONTRACT; исполнение — только в переходе.
14. **finished-сейвы и легаси-фолбэк**: `legacyActiveSave` фильтрует status 'active' — finished-сейвы не перехватывают запросы без saveId; GET /saves показывает их с плашкой; любые play-действия — 404 через resolvePlayingSave.

---

## Приложение: соответствие исследованию

Все числовые значения выверены по research-aaa.md: контракты — §1.2/§5.1; академия — §2.2/§5.2; правление — §3.2/§5.3; история/рейтинг — §4.2/§5.4; интеграционные заметки §5.5 (порядок перехода, API-минимум, QA-инварианты) — §4/§6/§9 этого ТЗ. Отклонения от исследования (зафиксированы осознанно): `contractUntil` вместо `contractYears` (идемпотентность); sack → экран завершения карьеры вместо «Безработицы» с 3 офферами (объём задачи P3-2); ИИ-«босман» — модификатор want ×0.5 вместо отдельных переходов (упрощение); авто-листинг ИИ перед набором — исключён (кап состава решает).

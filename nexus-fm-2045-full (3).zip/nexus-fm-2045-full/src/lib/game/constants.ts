/**
 * Все константы баланса игры. Единственное место «волшебных чисел».
 * Соответствует разделам 4.1–4.7 docs/architecture.md.
 */

import type {
  AttrKey, DefLineLevel, FinanceCategory, FinanceTargetCode, FormationClass, FormationId,
  LeagueCode, Mentality, PlayStyle, Position, PositionGroup, PressingLevel,
  TempoLevel, WidthLevel,
} from './types';

// Типы, используемые в константах (board/budget/finances) — реэкспорт,
// чтобы модули Модуля 5 импортировали их из одного места (паттерн до выноса
// типов в types.ts сохранён: board.ts ждёт FinanceTargetCode отсюда).
export type { FinanceCategory, FinanceTargetCode, LeagueCode } from './types';

// ── Мир ──────────────────────────────────────────────────────────────────

export const SQUAD_MIN = 13; // минимальный размер состава (≥2 GK, ≥4 DEF, ≥4 MID, ≥3 FWD)
export const SQUAD_MAX = 25; // максимальный размер состава
export const LINEUP_SIZE = 11;
export const BENCH_MAX = 7;
export const SAVES_MAX = 8; // лимит карьер (Фаза 2)

export const SQUAD_MIN_BY_GROUP = { GK: 2, DEF: 4, MID: 4, FWD: 3 } as const;

// ── Экономика (€) ────────────────────────────────────────────────────────

export const START_BALANCE_BASE = 20_000_000; // стартовый баланс клуба игрока
export const START_BALANCE_PER_STRENGTH = 4_000_000; // + за каждую единицу силы выше 55
export const TICKET_PRICE = 30; // € за билет
export const SPONSOR_BASE = 300_000; // €/неделю
export const SPONSOR_PER_PLACE = 25_000; // + (N - место) * это
/** Призовые за место в лиге — по размеру лиги (индекс = место−1). */
export const PRIZE_MONEY_BY_SIZE: Record<number, readonly number[]> = {
  16: [15e6, 10e6, 7e6, 5e6, 3e6, 3e6, 3e6, 3e6, 2e6, 2e6, 2e6, 2e6, 1e6, 1e6, 1e6, 0.5e6],
  18: [15e6, 10e6, 7e6, 5e6, 3.5e6, 3e6, 3e6, 2.5e6, 2.5e6, 2e6, 2e6, 1.8e6, 1.6e6, 1.4e6, 1.2e6, 1e6, 0.8e6, 0.6e6],
  20: [15e6, 10e6, 7e6, 5e6, 4e6, 3.5e6, 3e6, 3e6, 2.8e6, 2.6e6, 2.4e6, 2.2e6, 2e6, 1.8e6, 1.6e6, 1.4e6, 1.2e6, 1e6, 0.8e6, 0.6e6],
};
export const TRANSFER_BUDGET_RATIO = 0.4; // легаси-миграция: transferBudget = floor(balance * 0.4), но >= 0
export const WAGE_ALERT_RATIO = 0.7; // алерт: зарплаты > 70% недельного дохода

// ── Модуль 5: Финансы 2.0 (ТВ-деньги, бюджеты, стадион, финцель) ─────────

/** ТВ-отчисления лиги, €/неделю (база; ×1.3 топ-кварталь · ×1.0 середина · ×0.85 низ). */
export const TV_MONEY_BY_LEAGUE: Record<LeagueCode, number> = {
  EPL: 1_100_000, // Англия — богатейший контракт
  LAL: 900_000, // Испания
  BUN: 850_000, // Германия
  SEA: 750_000, // Италия
  FL1: 650_000, // Франция
  RPL: 300_000, // Россия — входная лига
};
/** ТВ-бонус за класс места: топ-кварталь / середина / низ таблицы. */
export const TV_PLACE_MULT = { top: 1.3, mid: 1.0, low: 0.85 } as const;

/** Сезонный пересбор бюджетов: грант = TV×недель×доля + призовые×0.5 + перенос остатка×0.5. */
export const BUDGET_TV_SHARE = 0.30; // доля ТВ-потока сезона в трансферном гранте
export const BUDGET_PRIZE_SHARE = 0.5; // доля призовых за место — в трансферный грант
export const BUDGET_CARRYOVER_SHARE = 0.5; // перенос неиспользованного бюджета
export const BUDGET_CONFIDENCE_BONUS = 0.15; // confidence ≥ 70 → +15% к гранту
export const BUDGET_WAGE_RATIO = 0.65; // зарплатный бюджет = 65% «устойчивого дохода» лиги
export const WAGE_BUDGET_HEADROOM = 1.12; // зазор роста к текущей ведомости (правление даёт расти)
export const SALE_TO_BUDGET_RATIO = 0.8; // 80% продажи — в трансферный бюджет
export const WAGE_BUDGET_SLACK = 1.05; // гвард подписания: ведомость ≤ бюджет×1.05

/** Финансовая цель сезона правления (label + начисление в board.ts). */
export const FINANCE_TARGET_LABELS: Record<FinanceTargetCode, string> = {
  no_debt: 'Завершить сезон без долга',
  wage_control: 'Держать зарплаты в рамках',
};

/** Русские подписи статей бюджета (Модуль 5: отчёт по категориям). */
export const FINANCE_CATEGORY_LABELS: Record<FinanceCategory, string> = {
  sponsor: 'Спонсорские отчисления',
  tickets: 'Билеты',
  prize: 'Призовые лиги',
  cup_prize: 'Призовые кубка',
  euro_prize: 'Призовые Кубка Европы',
  transfer_in: 'Продажи игроков',
  transfer_out: 'Покупки игроков',
  wages: 'Зарплаты игроков',
  building: 'Содержание инфраструктуры',
  construction: 'Стройка',
  merch: 'Фан-шоп',
  vip: 'VIP-ложи',
  coach_wages: 'Зарплата тренера',
  staff_wages: 'Зарплаты штата',
  tv: 'Телевещание',
};
/** Порог баланса для назначения цели no_debt, €. */
export const FINANCE_TARGET_DEBT_BALANCE = 5_000_000;
/** Порог wageRatio для назначения цели wage_control. */
export const FINANCE_TARGET_WAGE_RATIO = 0.65;
/** Бонус confidence при выполнении финцели (вердикт сезона). */
export const BOARD_FINANCE_TARGET_BONUS = 5;
/** Еженедельный темп-бонус «финцель выполняется» (в pace-интервал, вместе с обзором темпа). */
export const BOARD_DELTA_FINANCE_TARGET = 1;

/** Стадион: каталог расширений (§ «Инфраструктура 2.0»). */
export const STADIUM_MAX_CAPACITY = 90_000;
export const STADIUM_BASE_SEAT_PRICE = 900; // €/место при пустом стадионе
export const STADIUM_SIZE_GROWTH = 100_000; // цена места растёт с вместимостью: 1 + cap/100k
export const STADIUM_DAYS_PER = { 3000: 56, 5000: 70, 8000: 84 } as const; // дней стройки
/** Кап валюты для стройки стадиона: цена округляется до €1 000. */
export const STADIUM_PRICE_ROUND = 1_000;

// ── Матч ─────────────────────────────────────────────────────────────────

export const BASE_GOALS = 1.35; // базовое λ (среднее голов команды)
export const HOME_ADVANTAGE = 1.15; // множитель домашней команды (фикс QA-5: калибровка 46% побед хозяев, scripts/calibrate_home.py)
export const LAMBDA_MIN = 0.2;
export const LAMBDA_MAX = 5.0;
export const MAX_GOALS = 8; // кап сэмпла Пуассона
export const EMPTY_SLOT_STRENGTH = 40; // сила пустого слота (сильный штраф)
export const RED_CARD_PROB = 0.030; // на команду за матч (Фаза 4: было 0.025)
export const INJURY_PROB = 0.04; // на команду за матч
export const RED_LAMBDA_SELF = 0.55; // множитель λ команды после красной (красная ≤ 45'; Фаза 4: было 0.85)
export const RED_LAMBDA_OPP = 1.30; // множитель λ соперника после красной (≤ 45'; Фаза 4: было 1.10)
export const RED_LAMBDA_SELF_LATE = 0.70; // красная в 46'–70' (Фаза 4: было 0.93)
export const RED_LAMBDA_OPP_LATE = 1.15; // Фаза 4: было 1.05

export const YELLOW_LAMBDA_BASE = 1.9; // Фаза 4: было 1.2 (итог ≈3.81 ЖК/матч; факт 4.42)
export const YELLOW_LAMBDA_AGGR_DIV = 200;
export const YELLOW_CAP = 5;
export const YELLOW_PRESSING_BONUS = 0.4;

// ── Веса линий ───────────────────────────────────────────────────────────

export const LINE_WEIGHT = { attack: 0.35, midfield: 0.30, defence: 0.35 } as const; // teamStrength для UI
export const EFF_ATK = { attack: 0.75, midfield: 0.25 } as const; // effectiveAttack
export const EFF_DEF = { defence: 0.70, midfield: 0.30 } as const; // effectiveDefence
export const LINE_REF = { attack: 2.6, midfield: 4.8, defence: 5.6 } as const; // эталон весов 4-4-2

/** Вклад слота (по его позиции) в линии. */
export const SLOT_LINE_WEIGHT: Record<PositionGroup, { defence: number; midfield: number; attack: number }> = {
  GK: { defence: 1.0, midfield: 0, attack: 0 },
  DEF: { defence: 1.0, midfield: 0.15, attack: 0 },
  DM: { defence: 0.55, midfield: 1.0, attack: 0 },
  MID: { defence: 0.15, midfield: 1.0, attack: 0.15 },
  AM: { defence: 0, midfield: 0.65, attack: 0.75 },
  ST: { defence: 0, midfield: 0.10, attack: 1.0 },
};

// ── Трансферы ────────────────────────────────────────────────────────────

export const MARKET_SIZE_MIN = 50; // активных лотов рынка после рефреша
export const MARKET_SIZE_MAX = 70;
export const SELL_PRICE_MIN_RATIO = 0.75; // границы цены продажи своих
export const SELL_PRICE_MAX_RATIO = 2.5;
export const VALUE_BASE = 50_000; // value = 50K × 1.11^OVR × ...
export const VALUE_GROWTH = 1.11;
export const SALARY_RATIO = 0.0002; // salary = value × 0.0002 / неделю (min €500)
export const SALARY_MIN = 500;
export const SALARY_ROUND = 100;
export const LISTING_TTL = 6; // туров жизни лота по умолчанию

// ── Пост-матч ────────────────────────────────────────────────────────────

export const MORALE_WIN = 15;
export const MORALE_DRAW = 2;
export const MORALE_LOSS = -15;
export const MORALE_BENCH_RATIO = 0.5;
export const MORALE_MIN = 5;
export const MORALE_MAX = 100;
export const CONDITION_DRAIN_BASE = 22; // −(22 − stamina/12) стартёрам
export const CONDITION_DRAIN_MIN = 8;
export const CONDITION_BENCH_GAIN = 10;
export const CONDITION_WEEKLY_RECOVERY = 8;
export const CONDITION_MIN = 30;
export const CONDITION_MAX = 100;
export const TEMPO_DRAIN = 2; // low → −2 к drain, high → +2
export const PRESSING_DRAIN = 3; // pressing high → +3 к drain

// ── OVR: веса атрибутов по позициям (таблица 4.4 architecture.md) ─────────
// Примечание: в таблице архитектурного документа сумма весов некоторых
// позиций отличается от 100 (погрешность таблицы). OVR вычисляется как
// взвешенное среднее (деление на фактическую сумму весов), что сохраняет
// шкалу 1..100 и относительную важность атрибутов ровно по таблице.

const W_GK: Partial<Record<AttrKey, number>> = {
  reflexes: 30, rushingOut: 15, kicking: 10, handling: 15, passing: 5,
  positioning: 15, pace: 5, stamina: 5, strength: 10, decisions: 5,
};
const W_DC: Partial<Record<AttrKey, number>> = {
  passing: 5, tackling: 20, marking: 20, positioning: 15,
  heading: 15, pace: 8, stamina: 5, strength: 12,
  jumping: 8, decisions: 4, acceleration: 4, vision: 2,
};
const W_DLDR: Partial<Record<AttrKey, number>> = {
  finishing: 2, passing: 10, dribbling: 10, crossing: 14,
  tackling: 14, marking: 12, positioning: 8, pace: 18, stamina: 14,
  acceleration: 8, jumping: 4, vision: 3, decisions: 3,
};
const W_DM: Partial<Record<AttrKey, number>> = {
  finishing: 3, passing: 20, dribbling: 8, tackling: 15,
  marking: 10, positioning: 10, heading: 5, pace: 8, stamina: 14, strength: 10,
  vision: 8, decisions: 6, acceleration: 3,
};
const W_MID: Partial<Record<AttrKey, number>> = {
  finishing: 5, passing: 24, dribbling: 14, crossing: 12,
  tackling: 10, positioning: 8, pace: 10, stamina: 14,
  vision: 10, decisions: 6, acceleration: 4, leadership: 2,
};
const W_AM: Partial<Record<AttrKey, number>> = {
  finishing: 15, passing: 18, dribbling: 18, crossing: 12,
  positioning: 4, pace: 20, stamina: 8, strength: 4,
  vision: 8, decisions: 6, acceleration: 8,
};
const W_ST: Partial<Record<AttrKey, number>> = {
  finishing: 30, dribbling: 14, positioning: 10,
  heading: 14, pace: 18, strength: 14,
  vision: 4, decisions: 6, acceleration: 8, jumping: 6,
};

function expand(
  base: Partial<Record<AttrKey, number>>,
  positions: Position[],
): Record<Position, Partial<Record<AttrKey, number>>> {
  const out = {} as Record<Position, Partial<Record<AttrKey, number>>>;
  for (const p of positions) out[p] = base;
  return out;
}

export const OVR_WEIGHTS: Record<Position, Partial<Record<AttrKey, number>>> = {
  ...expand(W_GK, ['GK']),
  ...expand(W_DC, ['DC']),
  ...expand(W_DLDR, ['DL', 'DR']),
  ...expand(W_DM, ['DML', 'DMC', 'DMR']),
  ...expand(W_MID, ['ML', 'MC', 'MR']),
  ...expand(W_AM, ['AML', 'AMC', 'AMR']),
  ...expand(W_ST, ['ST']),
};

/** Атрибут «ключевой» для позиции, если его вес ≥ 10 (используется в генерации и развитии). */
export const KEY_ATTR_THRESHOLD = 10;

// ── Соответствие позиций (positionFit, таблица 4.5) ───────────────────────

export const POSITION_FIT: Record<PositionGroup, Record<PositionGroup, number>> = {
  GK: { GK: 1.0, DEF: 0.2, DM: 0.2, MID: 0.2, AM: 0.2, ST: 0.2 },
  DEF: { GK: 0.2, DEF: 1.0, DM: 0.9, MID: 0.8, AM: 0.6, ST: 0.5 },
  DM: { GK: 0.2, DEF: 0.9, DM: 1.0, MID: 0.85, AM: 0.7, ST: 0.6 },
  MID: { GK: 0.2, DEF: 0.75, DM: 0.85, MID: 1.0, AM: 0.85, ST: 0.75 },
  AM: { GK: 0.2, DEF: 0.6, DM: 0.7, MID: 0.85, AM: 1.0, ST: 0.9 },
  ST: { GK: 0.2, DEF: 0.5, DM: 0.6, MID: 0.75, AM: 0.9, ST: 1.0 },
};

// ── Модификаторы тактики (4.7) ───────────────────────────────────────────

export const MENTALITY_MODS: Record<
  Mentality,
  { attack: number; defence: number; midfield: number }
> = {
  defensive: { attack: 0.92, defence: 1.08, midfield: 0.98 },
  cautious: { attack: 0.96, defence: 1.04, midfield: 1.0 },
  balanced: { attack: 1.0, defence: 1.0, midfield: 1.0 },
  attacking: { attack: 1.08, defence: 0.92, midfield: 1.02 },
  allout: { attack: 1.16, defence: 0.84, midfield: 1.04 },
};

export const MENTALITY_ORDER: Mentality[] = ['defensive', 'cautious', 'balanced', 'attacking', 'allout'];
export const TEMPO_ORDER: TempoLevel[] = ['low', 'medium', 'high'];
export const PRESSING_ORDER: PressingLevel[] = ['low', 'medium', 'high'];
export const DEF_LINE_ORDER: DefLineLevel[] = ['low', 'medium', 'high'];

/** Множитель на количество «опасных моментов» от темпа. */
export const TEMPO_CHANCE_MOD: Record<TempoLevel, number> = { low: 0.8, medium: 1.0, high: 1.2 };

/** Прессинг: low → своя оборона ×1.02; high → атака соперника ×0.96. */
export const PRESSING_DEF_MOD: Record<PressingLevel, number> = { low: 1.02, medium: 1.0, high: 1.0 };
export const PRESSING_OPP_ATTACK_MOD: Record<PressingLevel, number> = { low: 1.0, medium: 1.0, high: 0.96 };

/** Линия обороны: low → оборона ×1.03 / атака ×0.97; high → наоборот. */
export const DEF_LINE_MOD: Record<DefLineLevel, { attack: number; defence: number }> = {
  low: { attack: 0.97, defence: 1.03 },
  medium: { attack: 1.0, defence: 1.0 },
  high: { attack: 1.03, defence: 0.97 },
};

/** Матрица стилей: множитель на МОЮ атаку при паре (мой стиль, стиль соперника). */
export const STYLE_MATRIX: Record<PlayStyle, Record<PlayStyle, number>> = {
  balanced: { balanced: 1.0, wing: 1.0, passing: 1.0, long: 1.0, counter: 1.0 },
  wing: { balanced: 1.0, wing: 1.0, passing: 1.05, long: 0.95, counter: 1.0 },
  passing: { balanced: 1.0, wing: 0.95, passing: 1.0, long: 1.05, counter: 1.0 },
  long: { balanced: 1.0, wing: 1.05, passing: 0.95, long: 1.0, counter: 1.0 },
  counter: { balanced: 1.0, wing: 1.06, passing: 1.06, long: 0.97, counter: 1.0 },
};

/** Контратаки: своя оборона ×1.03 против менталитета attacking/allout. */
export const COUNTER_DEF_BONUS = 1.03;

// ── Классы формаций и их противодействия (4.7) ────────────────────────────

export const FORMATION_CLASS: Record<FormationId, FormationClass> = {
  '4-4-2': 'balanced',
  '4-3-3': 'flank_attack',
  '4-2-3-1': 'center_attack',
  '4-5-1': 'defensive',
  '3-5-2': 'flank_mid',
  '5-3-2': 'dense',
  '4-1-4-1': 'defensive',
  '3-4-3': 'flank_attack',
};

/**
 * Правила классов формаций. Каждый элемент — условие (мой класс, класс соперника)
 * и множители к МОИМ силам. При нескольких попаданиях перемножаются.
 */
export const FORMATION_CLASS_RULES: {
  mine: FormationClass;
  opp: FormationClass;
  atk?: number;
  def?: number;
}[] = [
  { mine: 'dense', opp: 'flank_attack', def: 1.07 },
  { mine: 'dense', opp: 'center_attack', def: 1.07 },
  { mine: 'flank_attack', opp: 'dense', atk: 1.07 },
  { mine: 'flank_mid', opp: 'dense', atk: 1.06 },
  { mine: 'dense', opp: 'balanced', def: 1.04 },
  { mine: 'center_attack', opp: 'defensive', atk: 1.05 },
  { mine: 'defensive', opp: 'flank_attack', def: 1.05 },
];

// ── Формации: слоты с координатами на вертикальном поле ───────────────────
// x: 0..100 (слева → направо), y: 0..100 (свои ворота ↓ → ворота соперника ↑)

export interface FormationSlot {
  position: Position;
  x: number;
  y: number;
}

export interface FormationDef {
  slots: FormationSlot[]; // ровно 11
  hint: string; // сильные стороны для подсказки в UI
}

export const FORMATIONS: Record<FormationId, FormationDef> = {
  '4-4-2': {
    hint: 'Классика: сбалансированные линии',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DL', x: 14, y: 24 },
      { position: 'DC', x: 38, y: 21 },
      { position: 'DC', x: 62, y: 21 },
      { position: 'DR', x: 86, y: 24 },
      { position: 'ML', x: 14, y: 50 },
      { position: 'MC', x: 38, y: 53 },
      { position: 'MC', x: 62, y: 53 },
      { position: 'MR', x: 86, y: 50 },
      { position: 'ST', x: 38, y: 80 },
      { position: 'ST', x: 62, y: 80 },
    ],
  },
  '4-3-3': {
    hint: 'Мощные фланги в атаке',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DL', x: 14, y: 24 },
      { position: 'DC', x: 38, y: 21 },
      { position: 'DC', x: 62, y: 21 },
      { position: 'DR', x: 86, y: 24 },
      { position: 'MC', x: 26, y: 48 },
      { position: 'MC', x: 50, y: 52 },
      { position: 'MC', x: 74, y: 48 },
      { position: 'AML', x: 15, y: 73 },
      { position: 'ST', x: 50, y: 83 },
      { position: 'AMR', x: 85, y: 73 },
    ],
  },
  '4-2-3-1': {
    hint: 'Контроль центра, один наконечник',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DL', x: 14, y: 24 },
      { position: 'DC', x: 38, y: 21 },
      { position: 'DC', x: 62, y: 21 },
      { position: 'DR', x: 86, y: 24 },
      { position: 'DMC', x: 38, y: 40 },
      { position: 'DMC', x: 62, y: 40 },
      { position: 'AML', x: 15, y: 63 },
      { position: 'AMC', x: 50, y: 60 },
      { position: 'AMR', x: 85, y: 63 },
      { position: 'ST', x: 50, y: 83 },
    ],
  },
  '4-5-1': {
    hint: 'Глубокая оборона, плотный центр',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DL', x: 14, y: 24 },
      { position: 'DC', x: 38, y: 21 },
      { position: 'DC', x: 62, y: 21 },
      { position: 'DR', x: 86, y: 24 },
      { position: 'ML', x: 12, y: 52 },
      { position: 'MC', x: 32, y: 49 },
      { position: 'MC', x: 50, y: 47 },
      { position: 'MC', x: 68, y: 49 },
      { position: 'MR', x: 88, y: 52 },
      { position: 'ST', x: 50, y: 79 },
    ],
  },
  '3-5-2': {
    hint: 'Численный перевес в центре',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DC', x: 30, y: 21 },
      { position: 'DC', x: 50, y: 19 },
      { position: 'DC', x: 70, y: 21 },
      { position: 'DML', x: 10, y: 47 },
      { position: 'MC', x: 34, y: 50 },
      { position: 'MC', x: 50, y: 53 },
      { position: 'MC', x: 66, y: 50 },
      { position: 'DMR', x: 90, y: 47 },
      { position: 'ST', x: 38, y: 80 },
      { position: 'ST', x: 62, y: 80 },
    ],
  },
  '5-3-2': {
    hint: 'Плотная оборона, игра на контратаках',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DL', x: 10, y: 26 },
      { position: 'DC', x: 30, y: 21 },
      { position: 'DC', x: 50, y: 19 },
      { position: 'DC', x: 70, y: 21 },
      { position: 'DR', x: 90, y: 26 },
      { position: 'MC', x: 30, y: 50 },
      { position: 'MC', x: 50, y: 53 },
      { position: 'MC', x: 70, y: 50 },
      { position: 'ST', x: 38, y: 80 },
      { position: 'ST', x: 62, y: 80 },
    ],
  },
  '4-1-4-1': {
    hint: 'Опорник + широкая середина',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DL', x: 14, y: 24 },
      { position: 'DC', x: 38, y: 21 },
      { position: 'DC', x: 62, y: 21 },
      { position: 'DR', x: 86, y: 24 },
      { position: 'DMC', x: 50, y: 36 },
      { position: 'ML', x: 14, y: 54 },
      { position: 'MC', x: 38, y: 52 },
      { position: 'MC', x: 62, y: 52 },
      { position: 'MR', x: 86, y: 54 },
      { position: 'ST', x: 50, y: 82 },
    ],
  },
  '3-4-3': {
    hint: 'Максимум атакующих игроков',
    slots: [
      { position: 'GK', x: 50, y: 6 },
      { position: 'DC', x: 30, y: 21 },
      { position: 'DC', x: 50, y: 19 },
      { position: 'DC', x: 70, y: 21 },
      { position: 'ML', x: 12, y: 50 },
      { position: 'MC', x: 38, y: 50 },
      { position: 'MC', x: 62, y: 50 },
      { position: 'MR', x: 88, y: 50 },
      { position: 'AML', x: 18, y: 74 },
      { position: 'ST', x: 50, y: 83 },
      { position: 'AMR', x: 82, y: 74 },
    ],
  },
};

export const FORMATION_IDS: FormationId[] = [
  '4-4-2', '4-3-3', '4-2-3-1', '4-5-1', '3-5-2', '5-3-2', '4-1-4-1', '3-4-3',
];

// ── Безопасное приведение строк БД к enum-типам ──────────────────────────

export function coerceFormation(v: string): FormationId {
  return (FORMATION_IDS as string[]).includes(v) ? (v as FormationId) : '4-4-2';
}

export function coerceMentality(v: string): Mentality {
  return (MENTALITY_ORDER as string[]).includes(v) ? (v as Mentality) : 'balanced';
}

export function coerceTempo(v: string): TempoLevel {
  return (TEMPO_ORDER as string[]).includes(v) ? (v as TempoLevel) : 'medium';
}

export function coercePressing(v: string): PressingLevel {
  return (PRESSING_ORDER as string[]).includes(v) ? (v as PressingLevel) : 'medium';
}

export function coerceDefLine(v: string): DefLineLevel {
  return (DEF_LINE_ORDER as string[]).includes(v) ? (v as DefLineLevel) : 'medium';
}

export function coercePlayStyle(v: string): PlayStyle {
  const all: PlayStyle[] = ['balanced', 'wing', 'passing', 'long', 'counter'];
  return (all as string[]).includes(v) ? (v as PlayStyle) : 'balanced';
}

/** Engine 2.0: ширина игры (Team.width — узкий коридор / норма / фланги). */
export function coerceWidth(v: string): WidthLevel {
  const all: WidthLevel[] = ['narrow', 'normal', 'wide'];
  return (all as string[]).includes(v) ? (v as WidthLevel) : 'normal';
}

// ── Генерация мира ───────────────────────────────────────────────────────

export const ATTR_MIN = 20;
export const ATTR_MAX = 95;
export const ROLE_MOD_KEY = 1.10;
export const ROLE_MOD_MINOR = 0.85;
export const GK_FIELD_ATTR_MOD = 0.6;
export const FIELD_GK_ATTR_MOD = 0.4;

export const AI_BUY_CHANCE = 0.15; // вероятность покупки ИИ за неделю (легаси-режим одного лота)

// ── Модуль 3: трансферный рынок и ИИ клубов ─────────────────────────────────

export const AI_MAX_BUYS_PER_WEEK = 3; // умные покупки ИИ за неделю (по одной на клуб)
/** Порог усиления: лот должен поднимать средний OVR стартовой группы ИИ. */
export const AI_UPGRADE_MIN_GAIN = -2;
/** Максимальный price/value, который ИИ считает разумным («не переплачивать»). */
export const AI_PRICE_VALUE_MAX = 1.35;
/** Минимальная глубина состава группы, ниже которой срочность растёт. */
export const AI_GROUP_DEPTH_MIN = 3;

/** Входящие офферы: раз в N недель бросок, начиная с недели сезона. */
export const INCOMING_OFFER_INTERVAL = 3;
export const INCOMING_OFFER_START_WEEK = 5;
export const INCOMING_OFFER_CHANCE = 0.45;
/** Живёт N недель (потом expired в недельном цикле). */
export const INCOMING_OFFER_TTL = 2;
/** Оффер на игрока последнего года контракта — дисконт (уйдёт бесплатно). */
export const INCOMING_OFFER_BOSMAN_FACTOR = [0.6, 0.85] as const;
/** Премия за star-игрока / топ-форма сезона. */
export const INCOMING_OFFER_STAR_FACTOR = [1.05, 1.25] as const;
/** Отвергнутый оффер на star-игрока с моралью < 45 → morale −N (недоволен). */
export const INCOMING_OFFER_REJECT_MORALE_HIT = 4;
/** Мораль игрока, ниже которой отклонение оффера его злит. */
export const INCOMING_OFFER_UNHAPPY_MORALE = 45;

/** Скаутинг: слоты и рост знания (детерминированные формулы — scouting.ts). */
export const SCOUT_BUY_KNOWLEDGE = 30; // стартовое знание при покупке/подписании игрока

// ── Модуль 4: персонал и рынок труда тренеров ──────────────────────────────

/** Слоты ролей в штате клуба (максимум одновременно). */
export const STAFF_ROLE_MAX: Record<string, number> = {
  head_coach: 1,
  assistant: 1,
  fitness: 1,
  physio: 1,
  scout: 3,
};

/** Целевой размер пула свободных кандидатов рынка персонала. */
export const STAFF_MARKET_TARGET = 17;
/** Компоненты стартового рынка при создании мира (сумма = STAFF_MARKET_TARGET). */
export const STAFF_MARKET_ROLES: { role: string; count: number }[] = [
  { role: 'head_coach', count: 3 },
  { role: 'assistant', count: 3 },
  { role: 'fitness', count: 3 },
  { role: 'physio', count: 3 },
  { role: 'scout', count: 5 },
];

/** Подписной бонус при найме: недель × зарплату (списание с баланса сразу). */
export const STAFF_HIRE_BONUS_WEEKS = 4;
/** Компенсация при увольнении: зарплата × оставшиеся недели сезона (минимум 4). */
export const STAFF_FIRE_MIN_WEEKS = 4;
/** Продление: зарплата = staffSalaryOf(rating) × N (инфляция продления). */
export const STAFF_RENEW_MULT = 1.05;
/** Продление: минимальный срок, максимум. */
export const STAFF_YEARS_MIN = 1;
export const STAFF_YEARS_MAX = 3;

/** Возраст выхода на пенсию персонала (сезонный переход). */
export const STAFF_RETIRE_AGE = 66;
/** ИИ продлевает истёкший контракт с этим шансом (рейтинг ≥ 50). */
export const STAFF_AI_RENEW_CHANCE = 0.85;
export const STAFF_AI_RENEW_MIN_RATING = 50;

/** Еженедельная живость рынка: шанс уйти у кандидата + пополнение до target. */
export const STAFF_MARKET_CHURN = 0.18;

// ── Эффекты персонала (формулы staff.ts; рейтинг 20..96) ──────────────────

/** XP-множитель тренировок от главного тренера: 1 + (rating − 60)/250, clamp. */
export const STAFF_COACH_XP_SPAN: [number, number] = [0.85, 1.2];
/** Ассистент: доп. XP молодым (≤23): 1 + (rating − 60)/400, clamp. */
export const STAFF_YOUTH_XP_SPAN: [number, number] = [0.9, 1.15];
export const STAFF_YOUTH_XP_MAX_AGE = 23;
/** Физио: множитель риска травм 1 + (55 − rating)/300, clamp. */
export const STAFF_INJURY_SPAN: [number, number] = [0.8, 1.25];
/** Физио 'treatment': доп. шанс ускорить лечение на 1 неделю. */
export const STAFF_HEAL_MAX = 0.25;
/** Фитнес-тренер: прибавка к еженедельному восстановлению, clamp. */
export const STAFF_RECOVERY_SPAN: [number, number] = [-1, 3];
/** Скаут 'talent': множитель роста знания о молодых (≤21). */
export const STAFF_TALENT_SCOUT_MULT = 1.25;
export const STAFF_TALENT_SCOUT_MAX_AGE = 21;
/** Специализация коуча: множитель XP категории атрибутов. */
export const STAFF_SPECIALTY_CAT_MULT = 1.12;

// ── Кубок (Фаза 2) ─────────────────────────────────────────────────────────

export const CUP_PRIZE_ROUND = [150_000, 300_000, 600_000, 1_200_000, 3_500_000] as const;
export const CUP_FINALIST_PRIZE = 1_750_000;
export const CUP_WEAK_HOME_PROB = 0.7; // «слабый дома» при жеребьёвке
export const CUP_AI_WIN_DIV = 80; // P = clamp(0.5 + Δstr/80, 0.30, 0.70)
export const CUP_AI_RANDOM_SHARE = 0.15; // доля чистой случайности в пенальти ИИ
export const CUP_MORALE_WIN = 5;
export const CUP_MORALE_OUT = -5;
export const CUP_REST_COND = 10;
export const CUP_REST_MORALE = 2;

export const PEN_P_GOAL = { base: 0.72, slope: 0.20, min: 0.62, max: 0.87, ref: 75, span: 25 } as const;
export const PEN_P_SAVE = { base: 0.18, slope: 0.20, min: 0.10, max: 0.33, ref: 75, span: 25 } as const;
export const PEN_SUDDEN_DEATH_MAX = 10; // пар внезапной смерти, затем монетка

// ── Тренировки (Фаза 2) ───────────────────────────────────────────────────

export const TRAIN_BASE = 0.07; // g = TRAIN_BASE × I × A × H × U (Модуль 2: FM-темп роста)
export const TRAIN_INTENSITY_FACTOR: Record<'light' | 'normal' | 'hard', number> = {
  light: 0.6, normal: 1.0, hard: 1.5,
};
export const TRAIN_CONDITION_DELTA: Record<'light' | 'normal' | 'hard', number> = {
  light: 5, normal: 0, hard: -8,
}; // после матча (clamp 30..100)
export const TRAIN_INJURY_RISK: Record<'light' | 'normal' | 'hard', number> = {
  light: 0.005, normal: 0.01, hard: 0.03,
}; // на игрока/неделю
export const TRAIN_INJURY_COND_MULT = 2; // множитель риска при condition < 60
export const TRAIN_INJURY_WEEKS = [1, 4] as const; // randInt
export const TRAIN_XP_CAP = 0.95; // заморозка xp у потолка
export const TRAIN_REST_COND = 10;
export const TRAIN_REST_MORALE = 3;
export const TRAIN_NOTES_MAX = 3; // максимум новостей «прогресс» за неделю

// ── Награды (Фаза 2) ──────────────────────────────────────────────────────

export const AWARD_MVP_W = { goal: 4, assist: 2.5, app: 0.5, ovr: 2, ovrBase: 70 } as const;
export const AWARD_MORALE = 10; // бонус морали лауреатам клуба игрока
export const AWARD_VALUE_MULT = 1.05; // бонус стоимости лауреатам клуба игрока

// ── Зоны таблицы лиги (UI, по размеру N) ──────────────────────────────────

export interface LeagueZones {
  ucl: [number, number];
  uel: [number, number];
  rel: [number, number];
}

/** ucl=[1,3], uel=[4,6], rel=[N−2, N]. */
export function zonesFor(N: number): LeagueZones {
  return { ucl: [1, 3], uel: [4, 6], rel: [Math.max(1, N - 2), N] };
}

// ── Контракты (Фаза 3) ────────────────────────────────────────────────────

export const CONTRACT_MIN_YEARS = 1;
export const CONTRACT_MAX_YEARS = 4;
export const CONTRACT_VETERAN_MAX_YEARS = 2; // игроку 30+ не дают больше 2 лет
export const CONTRACT_RENEWABLE_YEARS_LEFT = 2; // продлевать можно при yearsLeft ≤ 2

/** Распределение сроков при генерации по возрасту (research-aaa §1.2). Индекс = годы−1. */
export const CONTRACT_YEARS_DISTRIBUTION: readonly {
  maxAge: number;
  weights: readonly [number, number, number, number];
}[] = [
  { maxAge: 21, weights: [0.10, 0.25, 0.35, 0.30] }, // таланты: ожидание 2.85
  { maxAge: 28, weights: [0.15, 0.30, 0.30, 0.25] }, // ядро: 2.65
  { maxAge: 31, weights: [0.25, 0.35, 0.30, 0.10] }, // ветераны: 2.25
  { maxAge: 99, weights: [0.45, 0.35, 0.15, 0.05] }, // последний контракт: 1.80
];

/** Множители роли по рангу OVR в составе (research-aaa §1.2). */
export const CONTRACT_ROLE_MULT = { star: 1.30, starter: 1.15, rotation: 1.00, depth: 0.85 } as const;
export const CONTRACT_RANK_STAR = 3; // топ-3 по OVR → «звезда»
export const CONTRACT_RANK_STARTER = 11; // топ-11 → «основа»
export const CONTRACT_RANK_ROTATION = 18; // топ-18 → «ротация»; глубже — «резерв»

/** Модификаторы зарплатного спроса (перемножаются). */
export const CONTRACT_SALARY_FLOOR_RATIO = 1.15; // demand = max(salary×1.15, ...)
export const CONTRACT_AGE_MULT_32 = 0.90;
export const CONTRACT_AGE_MULT_35 = 0.75;
export const CONTRACT_LOW_MORALE = 40; // morale < 40 → ×1.15
export const CONTRACT_LOW_MORALE_MULT = 1.15;
export const CONTRACT_LOW_APPS_RATIO = 0.5; // apps < 50% матчей команды → ×1.10
export const CONTRACT_LOW_APPS_MULT = 1.10;
export const CONTRACT_TALENT_GAP = 8; // (pot−ovr) ≥ 8 и age ≤ 23 → ×1.20
export const CONTRACT_TALENT_AGE = 23;
export const CONTRACT_TALENT_MULT = 1.20;

/** Принятие предложения: offer ≥ 0.92 × demand (ниже — контрпредложение ровно в demand). */
export const CONTRACT_ACCEPT_RATIO = 0.92;
export const CONTRACT_OFFER_MIN_RATIO = 0.8; // границы слайдера UI / валидации API
export const CONTRACT_OFFER_MAX_RATIO = 1.3;
export const CONTRACT_ROUNDS_MAX = 3; // раунды переговоров — правило UI-диалога

/** Истечение контракта → рынок свободных агентов. */
export const CONTRACT_FREE_PRICE_RATIO = 0.25; // цена лота = 0.25 × value
export const CONTRACT_FREE_TTL = 8; // недель жизни лота (вместо 6)
export const CONTRACT_FREE_SALARY_MULT = 1.2; // зарплата free-агента ×1.2 (компенсация агенту)
export const CONTRACT_DRAIN_AGE = 30; // дренаж рынка: тихое завершение карьеры (Фаза 4: было 32)
export const CONTRACT_DRAIN_OVR = 60; // свободные агенты age ≥ 30 И ovr < 60 без лота (Фаза 4: было 55)

/** ИИ-продления: матрица «хочет продлить» (ранг по OVR в составе × возраст). */
export const CONTRACT_AI_WANT: readonly { maxRank: number; maxAge: number; p: number }[] = [
  { maxRank: 11, maxAge: 31, p: 0.90 },
  { maxRank: 11, maxAge: 34, p: 0.65 },
  { maxRank: 16, maxAge: 29, p: 0.50 },
  { maxRank: 16, maxAge: 32, p: 0.30 },
];
export const CONTRACT_AI_WANT_DEFAULT = 0.10; // глубина состава
export const CONTRACT_AI_UNHAPPY_MULT = 0.5; // morale < 40 → want × 0.5 (ИИ-«босман»)
export const CONTRACT_AI_SQUAD_FLOOR = 15; // guard: состав не ниже 15 после истечений
export const AI_SIGN_MAX_PER_SEASON = 8; // фикс QA №20: максимум свободных агентов, которых ИИ-клуб подпишет за один переход
export const CONTRACT_AI_WAGE_RATIO = 0.7; // guard: зарплаты ≤ 70% оценочного дохода

/** Срок контракта от ИИ: 2 + (≤23 → +2 · ≤27 → +1 · иначе +0). */
export function contractAiYears(age: number): number {
  return 2 + (age <= 23 ? 2 : age <= 27 ? 1 : 0);
}

// ── Босман-лайт (Фаза 3) ───────────────────────────────────────────────────

export const BOSMAN_SEASON_START = 0.6; // броски с 60% сезона: week ≥ ceil(0.6 × totalWeeks)
export const BOSMAN_INTERVAL = 4; // раз в 4 недели (week % 4 === 0)
export const BOSMAN_BASE_P = 0.10;
export const BOSMAN_LOW_MORALE_ADD = 0.30; // morale < 40
export const BOSMAN_LOW_WAGE_ADD = 0.25; // salary < 0.7 × computeSalary(value)
export const BOSMAN_LOW_WAGE_RATIO = 0.7;
export const BOSMAN_LOW_APPS_ADD = 0.20; // apps < 40% матчей команды
export const BOSMAN_LOW_APPS_RATIO = 0.4;
export const BOSMAN_P_CAP = 0.75;
export const BOSMAN_RANK_SPAN = 3; // клуб предконтракта: ранг силы ± 3 (не клуб игрока)

// ── Академия (Фаза 3) ──────────────────────────────────────────────────────

export const ACADEMY_INTAKE_WEEK = 4; // неделя набора (всегда лиговая: CUP_WEEKS не пересекают 4)
export const ACADEMY_SIZE_MIN = 2; // randInt(2, 4) + tierBonus, кап по SQUAD_MAX
export const ACADEMY_SIZE_MAX = 4;
export const ACADEMY_TIER_STR = { top: 84, mid: 74 } as const; // сила ≥ 84 — топ; 74–83 — середина; < 74 — низ
export const ACADEMY_SIZE_TIER_BONUS = { top: 2, mid: 1, low: 0 } as const; // итог 2–6, среднее ≈ 3.5

export const ACADEMY_AGE_16_P = 0.8; // 16 лет — 80%, 17 — 20%
export const ACADEMY_AGE_MIN = 16;
export const ACADEMY_AGE_MAX = 17;
export const ACADEMY_OVR_MIN = 34; // randInt(34, 46) + tierBonus → итог 34–52
export const ACADEMY_OVR_MAX = 46;
export const ACADEMY_OVR_TIER_BONUS = { top: 6, mid: 3, low: 0 } as const;

export const ACADEMY_POT_RANGE = {
  top: [62, 88], mid: [56, 80], low: [50, 72],
} as const;
export const ACADEMY_GEM_P = { top: 0.08, mid: 0.03, low: 0.012 } as const; // «жемчужина»
export const ACADEMY_GEM_POT = [85, 93] as const;
export const ACADEMY_GOLDEN_P = 0.015; // «золотой набор» за сезон на клуб
export const ACADEMY_GOLDEN_BONUS = 6; // весь набор +6 к потолку, ≥ 1 жемчужина
export const ACADEMY_CONTRACT_YEARS = 3; // молодёжный договор

export const ACADEMY_GK_P = 0.5; // 1 GK с p = 0.5 (только при < 2 GK моложе 33)
export const ACADEMY_GK_YOUNG_MAX = 2;
export const ACADEMY_GK_MAX_AGE = 33;
export const ACADEMY_WEAK_GROUP_P = 0.6; // 60% — позиция слабейшей группы состава, 40% — шум

/** Звёзды потенциала для UI (research-aaa §2.2): pot ≥ 85 → 5★ … < 62 → 1★. */
export const ACADEMY_STARS: readonly { min: number; stars: number }[] = [
  { min: 85, stars: 5 }, { min: 78, stars: 4 }, { min: 70, stars: 3 },
  { min: 62, stars: 2 }, { min: 0, stars: 1 },
];

// ── Правление (Фаза 3) ─────────────────────────────────────────────────────

export type BoardTargetCode = 'champion' | 'ucl' | 'uel' | 'upper' | 'safe' | 'survive';

export const BOARD_CONF_START = 55;
export const BOARD_CONF_MIN = 0;
export const BOARD_CONF_MAX = 100;

/** Матчевые дельты (лига И кубок — кубковый матч даёт обе: матчевую + надбавку). */
export const BOARD_DELTA_WIN = 2;
export const BOARD_DELTA_WIN_UPSET = 3; // победа над соперником сильнее на ≥ 4
export const BOARD_DELTA_DRAW_UP = 1; // ничья с сильнее на ≥ 4
export const BOARD_DELTA_DRAW_EVEN = 0;
export const BOARD_DELTA_DRAW_DOWN = -1; // ничья со слабее на ≥ 4
export const BOARD_DELTA_LOSS = -2;
export const BOARD_DELTA_LOSS_DOWN = -3; // поражение от слабее на ≥ 4
export const BOARD_STRENGTH_GAP = 4; // порог «заметно сильнее/слабее»

/** Кубковые надбавки (поверх матчевых дельт). */
export const BOARD_DELTA_CUP_ROUND = 4; // проход раунда
export const BOARD_DELTA_CUP_FINAL = 8; // выигрыш финала
export const BOARD_DELTA_CUP_UPSET_LOSS = -3; // вылет от заметно слабого

/** Обзор темпа к цели раз в 4 недели. */
export const BOARD_PACE_INTERVAL = 4;
export const BOARD_PACE_AHEAD = 5; // место ≤ target−3
export const BOARD_PACE_ON_TARGET = 2; // место ≤ target
export const BOARD_PACE_NEAR = 0; // место ≤ target+3
export const BOARD_PACE_BEHIND = -5; // хуже
export const BOARD_PACE_REL_ZONE = -7; // в зоне вылета при цели ≠ survive

/** Финансы/гармония (еженедельно). */
export const BOARD_DELTA_NEG_BALANCE = -3; // баланс < 0
export const BOARD_DELTA_WAGES = -1; // зарплаты > 70% дохода (WAGE_ALERT_RATIO)
export const BOARD_DELTA_HARMONY = -1; // средняя мораль состава < 45
export const BOARD_HARMONY_MORALE = 45;

/** Медовый месяц. */
export const BOARD_HONEYMOON_WEEKS = 8; // недели 1–8 каждого сезона
export const BOARD_HONEYMOON_FLOOR = 35; // confidence не ниже 35

/** 7 статусов должности (отображение, вычисляется из confidence). */
export const BOARD_JOB_STATUSES: readonly { min: number; code: string; label: string }[] = [
  { min: 85, code: 'untouchable', label: 'Неприкасаем' },
  { min: 70, code: 'very_secure', label: 'Очень надёжно' },
  { min: 55, code: 'secure', label: 'Надёжно' },
  { min: 40, code: 'stable', label: 'Стабильно' },
  { min: 30, code: 'pressured', label: 'Под давлением' },
  { min: 20, code: 'hot_seat', label: 'Горячее кресло' },
  { min: 0, code: 'on_edge', label: 'На волоске' },
];

/** Пороги увольнения. */
export const BOARD_WARN_BELOW = 30; // первое предупреждение за сезон
export const BOARD_ULTIMATUM_BELOW = 20; // ультиматум «6 недель на исправление»
export const BOARD_SACK_CONF_WEEKLY = 12; // mid-season: ниже 4 недели подряд (после honeymoon)
export const BOARD_SACK_STREAK = 4;
export const BOARD_SACK_MISS_PLACES = 4; // переход: промах ≥ 4 мест ниже target
export const BOARD_SACK_CONF = 30; // …И confidence < 30 на конец сезона
export const BOARD_SACK_CONF_HARD = 15; // …ИЛИ confidence < 15 (при любом месте)

/** Перевыполнение. */
export const BOARD_OVER_PLACES = 3; // место ≥ 3 позиций выше цели
export const BOARD_OVER_CONF = 70; // старт следующего сезона
export const BOARD_OVER_BONUS = 2_000_000; // разовая премия (категория prize)

/** Потолок амбиций: минимальный ранг цели по силе клуба (правление не ждёт чуда). */
export const BOARD_AMBITION_MIN_RANK = { top: 1, mid: 4, low: 7 } as const; // сила ≥ 84 / 74–83 / < 74

export const BOARD_TARGET_LABELS: Record<BoardTargetCode, string> = {
  champion: 'Выиграть чемпионат',
  ucl: 'Попасть в Лигу чемпионов (топ-3)',
  uel: 'Попасть в еврокубки (топ-6)',
  upper: 'Финишировать в верхней половине',
  safe: 'Уверенно сохранить прописку',
  survive: 'Бороться за выживание',
};

// ── Рейтинг матча (Фаза 3, FM-шкала) ──────────────────────────────────────

export const RATING_BASE = 6.5; // средняя по лиге ≈ 6.75
export const RATING_WIN = 0.3;
export const RATING_DRAW = 0;
export const RATING_LOSS = -0.3;
export const RATING_GOAL = 0.7; // за гол
export const RATING_ASSIST = 0.35; // за ассист
export const RATING_YELLOW = -0.1;
export const RATING_RED = -0.6;
export const RATING_GK_CLEAN = 0.4; // вратарю за сухой матч
export const RATING_GK_CONCEDED = -0.12; // за каждый пропущенный
export const RATING_GK_CONCEDED_CAP = -0.6; // кап штрафа
export const RATING_NOISE = 0.2; // шум ±0.2 («невидимый вклад»)
export const RATING_MIN = 4.5;
export const RATING_MAX = 10.0;

// ── Фаза 4: сегментный движок матча (research §1.3, §5.1) ──────────────────

export const SEGMENT_BOUNDS = [45, 70, 93] as const; // границы минут: [1..45][46..70][71..93]
export const SEGMENT_SHARES = [0.42, 0.28, 0.30] as const; // доли голов (сумма строго 1.00)
export const SEGMENTS_COUNT = 3;
export const PER_SEGMENT_COND_DRAIN = 6; // виртуальная усталость стартёра за сегмент (внутри матча)
export const COND_EFF_FLOOR = 40; // floor виртуального condition при расчёте линий сегмента
export const SUB_MAX = 5; // замен на команду за матч
export const SUB_IN_CONDITION_CAP = 92; // вышедший играет с effCond = min(condition, 92)
export const SUB_FATIGUE_MINUTE = 60; // усталостные замены только на контрольной точке ≥ 60' (т.е. на 70')
export const SHORT_HANDED_LAMBDA_MOD = 0.93; // травма без замены (слоты исчерпаны) — к оставшемуся времени

/** λ-множители режимов (research §1.3, §5.1). */
export const PARKING_BUS_MOD = { self: 0.88, opp: 0.85 } as const; // «сушка» при победе late
export const CHASE_MOD = { self: 1.15, opp: 1.08 } as const; // «погоня» при отставании ≥1 к 70'

/** Utility-пороги решений тренера (research §1.2, §5.1). */
export const UTILITY_SUB_FATIGUE = 55;
export const UTILITY_SUB_CHASE = 40;
export const UTILITY_SUB_DEFENSIVE = 40;
export const UTILITY_MENTALITY = 25;
export const UTILITY_NOTHING = 30; // консерватизм: скор действия «ничего»
export const UTILITY_NOISE = 10; // шум ±10 на каждый скор

// ── Фаза 4: стили ИИ-тренеров (research §2.2, §2.6) ─────────────────────────

export type AiStyleCode = 'gegenpress' | 'tikitaka' | 'bus' | 'vertical' | 'balanced';

export interface AiStyleDef {
  code: AiStyleCode;
  label: string; // русский для UI
  hint: string; // строка-подсказка для превью
  /** Тактические поля, КОТОРЫЕ СТИЛЬ НАЗНАЧАЕТ Team при генерации/смене (не суммируются с MODS!). */
  tactic: {
    formation: FormationId; mentality: Mentality; tempo: TempoLevel;
    pressing: PressingLevel; defLine: DefLineLevel; playStyle: PlayStyle;
  };
  /** Уникальные дельты (применяются только в match.ts поверх applyModifiers). */
  yellowLambdaBonus: number; // к λ ЖК команды (gegenpress +0.4)
  yellowVsPressingHigh: number; // доп. к λ ЖК, если соперник pressing=high (vertical +0.2)
  condDrainPerSegment: number; // PER_SEGMENT_COND_DRAIN + это (gegenpress +3)
  injuryProbMult: number; // множитель INJURY_PROB (gegenpress 1.2 при avgCond<65, иначе 1.0)
  atkDelta: number; // множитель effAtk (bus 0.95)
  defDelta: number; // множитель effDef (bus 1.05)
  midDelta: number; // множитель effMid — только possession (tikitaka 1.05)
  verticalVsHighLine: boolean; // vertical: atk ×1.05 при opp.defLine === 'high'
  possessionBonus: number; // п.п. к possession (tikitaka +5)
  shotsBonus: number; // к ударам в статистике (tikitaka +1)
  sotShareDelta: number; // п.п. к доле ударов в створ (tikitaka −3)
  chanceCountMult: number; // множитель числа «опасных моментов» (vertical 1.2)
  /** Параметры Match-AI. */
  parkBusMinute: number; // порог активации «сушки» (bus 55, остальные 70)
  parkAtDraw: boolean; // bus паркует и при ничьей
  chaseMinute: number; // порог активации «погони» (65/75/80/70/70)
  mentalityDownDrawDelta: number; // сдвиг скорa mentality_down при ничьей late (bus +15, gegenpress −10)
}

export const AI_STYLES: Record<AiStyleCode, AiStyleDef> = {
  gegenpress: {
    code: 'gegenpress', label: 'Гегенпрессинг', hint: 'Высокая линия и прессинг: ждите темпа и карточек',
    tactic: { formation: '4-3-3', mentality: 'attacking', tempo: 'high', pressing: 'high', defLine: 'high', playStyle: 'passing' },
    yellowLambdaBonus: 0.4, yellowVsPressingHigh: 0, condDrainPerSegment: 3, injuryProbMult: 1.2,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.0, verticalVsHighLine: false,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.0,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 65, mentalityDownDrawDelta: -10,
  },
  tikitaka: {
    code: 'tikitaka', label: 'Тики-така', hint: 'Владение и позиционные атаки: много ударов низкой остроты',
    tactic: { formation: '4-2-3-1', mentality: 'attacking', tempo: 'medium', pressing: 'high', defLine: 'high', playStyle: 'passing' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.05, verticalVsHighLine: false,
    possessionBonus: 5, shotsBonus: 1, sotShareDelta: -0.03, chanceCountMult: 1.0,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 75, mentalityDownDrawDelta: 0,
  },
  bus: {
    code: 'bus', label: 'Автобус', hint: 'Низкий блок и катеначчо: игра на контратаках и сушке счёта',
    tactic: { formation: '5-3-2', mentality: 'defensive', tempo: 'low', pressing: 'low', defLine: 'low', playStyle: 'counter' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 0.95, defDelta: 1.05, midDelta: 1.0, verticalVsHighLine: false,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.0,
    parkBusMinute: 55, parkAtDraw: true, chaseMinute: 80, mentalityDownDrawDelta: 15,
  },
  vertical: {
    code: 'vertical', label: 'Вертикальный', hint: 'Прямые быстрые атаки: опасен против высокой линии обороны',
    tactic: { formation: '4-2-3-1', mentality: 'balanced', tempo: 'high', pressing: 'medium', defLine: 'medium', playStyle: 'counter' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0.2, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.0, verticalVsHighLine: true,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.2,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 70, mentalityDownDrawDelta: 0,
  },
  balanced: {
    code: 'balanced', label: 'Сбалансированный', hint: 'Универсальная игра без яркого почерка',
    tactic: { formation: '4-4-2', mentality: 'balanced', tempo: 'medium', pressing: 'medium', defLine: 'medium', playStyle: 'balanced' },
    yellowLambdaBonus: 0, yellowVsPressingHigh: 0, condDrainPerSegment: 0, injuryProbMult: 1.0,
    atkDelta: 1.0, defDelta: 1.0, midDelta: 1.0, verticalVsHighLine: false,
    possessionBonus: 0, shotsBonus: 0, sotShareDelta: 0, chanceCountMult: 1.0,
    parkBusMinute: 70, parkAtDraw: false, chaseMinute: 70, mentalityDownDrawDelta: 0,
  },
};

export const AI_STYLE_CODES: AiStyleCode[] = ['gegenpress', 'tikitaka', 'bus', 'vertical', 'balanced'];

export function coerceAiStyle(v: string): AiStyleCode {
  return (AI_STYLE_CODES as string[]).includes(v) ? (v as AiStyleCode) : 'balanced';
}

/** Назначение стиля при генерации/смене (research §2.6-2: сила + «национальный колорит»). */
export const AI_STYLE_ASSIGN: Record<'top' | 'mid' | 'low', readonly { style: AiStyleCode; p: number }[]> = {
  // сила ≥ 84: 40% узнаваемых (gegenpress/tikitaka)
  top: [
    { style: 'gegenpress', p: 0.20 }, { style: 'tikitaka', p: 0.20 },
    { style: 'vertical', p: 0.15 }, { style: 'bus', p: 0.10 }, { style: 'balanced', p: 0.35 },
  ],
  // 74–83: 25% узнаваемых
  mid: [
    { style: 'gegenpress', p: 0.10 }, { style: 'tikitaka', p: 0.10 },
    { style: 'vertical', p: 0.20 }, { style: 'bus', p: 0.25 }, { style: 'balanced', p: 0.35 },
  ],
  // < 74: 60% bus/vertical/balanced
  low: [
    { style: 'gegenpress', p: 0.05 }, { style: 'tikitaka', p: 0.05 },
    { style: 'vertical', p: 0.25 }, { style: 'bus', p: 0.30 }, { style: 'balanced', p: 0.35 },
  ],
};
export const AI_STYLE_LEAGUE_BIAS: Record<string, AiStyleCode> = { RPL: 'vertical', FL1: 'vertical' };
export const AI_STYLE_LEAGUE_BIAS_P = 0.25; // p=0.25 → сразу vertical для RPL/FL1

/** Смена стиля в сезонном переходе (research §2.4). */
export const AI_STYLE_CHANGE_P = 0.25; // обычные клубы
export const AI_STYLE_CHANGE_TOP_P = 0.10; // топ-6 по силе («гранды идеологичны»)
export const AI_STYLE_TOP_RANK = 6;
export const AI_COACH_RENAME_P = 0.15; // новое имя тренера при смене стиля

// ── Фаза 4: Кубок Европы (research §3.2–3.5, §5.3) ──────────────────────────

export const EURO_SIZE = 16;
export const EURO_ROUNDS = 4;
export const EURO_ROUND_LABELS = ['1/8 финала', '1/4 финала', '1/2 финала', 'Финал'] as const;
export const EURO_QUOTAS: Record<string, number> = { EPL: 3, LAL: 3, SEA: 3, BUN: 3, FL1: 2, RPL: 2 }; // сумма = 16
export const EURO_TOURNAMENT_NAME = 'Кубок Европы';

/** Евронедели = кубковые недели БЕЗ предварительного раунда (N=18/20) / все (N=16). */
export const EURO_WEEKS: Record<number, number[]> = {
  16: [8, 16, 24, 34], // RPL
  18: [15, 24, 32, 39], // BUN/FL1 (кубковая неделя 7 — предварительный раунд, евро нет)
  20: [16, 26, 35, 43], // EPL/LAL/SEA (кубковая неделя 8 — предварительный раунд, евро нет)
};

export const EURO_PRIZE_PARTICIPATION = 2_000_000; // за квалификацию (кредитуется в неделю 1/8)
export const EURO_PRIZE_ROUND = [1_000_000, 2_000_000, 3_000_000] as const; // победа в 1/8 / 1/4 / 1/2
export const EURO_PRIZE_FINALIST = 3_500_000; // проигравший финал
export const EURO_PRIZE_CHAMPION = 5_000_000; // чемпион (итого чемпиону: 2+1+2+3+5 = €13M)
export const EURO_QUAL_NOISE = 3; // gauss(0, 3) при отборе участников других лиг
export const EURO_ROTATE_COND = 65; // порог ротации autoLineup ИИ в евронедели (вместо 55)
export const EURO_GUEST_MIN_SQUAD = 18; // инвариант состава гостей после регена
export const EURO_WEAK_HOME_PROB = 0.7; // «слабый дома» при жеребьёвке евро (как в кубке)

/** Правление: евродельты (research §3.5; победа +2/+3 = BOARD_DELTA_WIN/UPSET, раунд +4 = BOARD_DELTA_CUP_ROUND, финал +8 = BOARD_DELTA_CUP_FINAL). */
export const BOARD_DELTA_EURO_UPSET_LOSS = -4; // вылет от заметно слабого (кубок: −3, Европа обиднее)

// ── Фаза 4: план на матч клуба игрока (research §1.6, паритет с ИИ) ─────────

export type MatchPlanLeadMode = 'park' | 'hold'; // ведём к 70': сушить / играть как есть
export type MatchPlanChaseMode = 'allout' | 'steady'; // отстаём к 70': максимальная атака / без изменений

export const MATCH_PLAN_DEFAULT = { leadMode: 'park', chaseMode: 'allout', fatigueSubs: true } as const;
// Дефолт = поведение ИИ: движок ИИ-решений включается и для клуба игрока (паритет).
export const MATCH_PLAN_LABELS = {
  lead: { park: 'Сушить счёт', hold: 'Играть как есть' },
  chase: { allout: 'Максимальная атака', steady: 'Без паники' },
} as const;

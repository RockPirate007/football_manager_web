'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Globe, Goal, ListOrdered, Loader2, Trophy } from 'lucide-react';
import { api } from '@/lib/game/api';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CoachStyleBadge } from '@/components/game/shared/CoachStyleBadge';
import { MatchDetailsDialog } from '@/components/game/shared/MatchDetailsDialog';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import type {
  EuroMatchDTO, EuroRoundDTO, EuroSnapshotDTO, EuroTeamDTO, MatchDetailsDTO,
} from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Строка команды в карточке европары: герб, имя, флаг лиги, «гость». */
function EuroTeamRow({
  team,
  score,
  isWinner,
  played,
}: {
  team: EuroTeamDTO;
  score: number | null;
  isWinner: boolean;
  played: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <TeamCrest
        shortName={team.shortName}
        colorPrimary={team.colorPrimary}
        colorSecondary={team.colorSecondary}
        size="sm"
        title={team.name}
      />
      <span
        className={cn(
          'min-w-0 flex-1 truncate text-xs',
          isWinner ? 'font-bold text-foreground' : played ? 'text-muted-foreground' : 'text-foreground',
        )}
      >
        {team.shortName}
      </span>
      <span
        className="shrink-0 text-[10px] leading-none"
        title={`${team.leagueName}${team.isGuest ? ' · гость' : ''}`}
        aria-hidden
      >
        {team.leagueFlag}
      </span>
      {team.isGuest ? (
        <span className="shrink-0 rounded bg-secondary px-1 py-0.5 text-[9px] font-medium text-muted-foreground">
          гость
        </span>
      ) : null}
      <span className="w-6 shrink-0 text-center text-xs font-bold tabular">
        {played ? score : '—'}
      </span>
    </div>
  );
}

/** Карточка одной европары (аналог CupMatchCard с флагами лиг и пенальти). */
function EuroMatchCard({ m, myTeamId }: { m: EuroMatchDTO; myTeamId: string }) {
  const notDrawn = !m.home || !m.away;

  if (notDrawn) {
    return (
      <div className="flex w-full items-center justify-between gap-2 rounded-lg border border-dashed border-border/60 bg-secondary/20 px-3 py-2.5 text-xs text-muted-foreground">
        <span className="flex size-6 items-center justify-center rounded-full border border-border/60">?</span>
        <span>Жеребьёвка</span>
        <span className="flex size-6 items-center justify-center rounded-full border border-border/60">?</span>
      </div>
    );
  }

  const home = m.home!;
  const away = m.away!;
  const homeWin = m.winnerTeamId === home.id;
  const awayWin = m.winnerTeamId === away.id;

  return (
    <div
      className={cn(
        'w-full rounded-lg border border-border/60 bg-card px-3 py-2.5',
        m.isUserMatch && 'border-primary/60 ring-1 ring-primary/30',
      )}
    >
      <EuroTeamRow team={home} score={m.homeGoals} isWinner={homeWin} played={m.played} />
      <div className="mt-1.5">
        <EuroTeamRow team={away} score={m.awayGoals} isWinner={awayWin} played={m.played} />
      </div>
      {m.homePens !== null && m.awayPens !== null ? (
        <Badge className="mt-1.5 w-full justify-center border border-[#EAB308]/40 bg-[#EAB308]/10 text-[10px] font-semibold text-[#EAB308] tabular">
          пен. {m.homePens}:{m.awayPens}
        </Badge>
      ) : null}
      {m.isNeutral ? (
        <Badge variant="outline" className="mt-1.5 w-full justify-center text-[9px] text-muted-foreground">
          Нейтральное поле
        </Badge>
      ) : null}
    </div>
  );
}

/** Колонка раунда десктопной сетки (1/8 → Финал). */
function EuroBracketColumn({ round, myTeamId }: { round: EuroRoundDTO; myTeamId: string }) {
  return (
    <div className="flex w-52 shrink-0 flex-col">
      <div className="mb-2 text-center">
        <div className="text-xs font-bold">{round.label}</div>
        <div className="text-[10px] text-muted-foreground tabular">неделя {round.week}</div>
      </div>
      <div className="flex flex-1 flex-col justify-around gap-3">
        {round.drawn && round.matches.length > 0 ? (
          round.matches.map((m) => <EuroMatchCard key={m.id} m={m} myTeamId={myTeamId} />)
        ) : (
          <div className="rounded-lg border border-dashed border-border/60 bg-secondary/20 px-3 py-4 text-center text-[11px] text-muted-foreground">
            Жеребьёвка ещё не состоялась
          </div>
        )}
      </div>
    </div>
  );
}

/** Сетка: десктоп — колонки раундов, мобайл — вертикальный список. */
function EuroBracket({ euro, myTeamId }: { euro: EuroSnapshotDTO; myTeamId: string }) {
  const finalRound = euro.rounds[euro.rounds.length - 1];
  const winnerId = finalRound?.matches.find((m) => m.played && m.winnerTeamId)?.winnerTeamId ?? null;
  const winnerTeam =
    finalRound?.matches
      .flatMap((m) => [m.home, m.away])
      .find((t) => t && t.id === winnerId) ?? null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      {/* Десктоп: горизонтальная сетка */}
      <div className="scroll-thin hidden overflow-x-auto rounded-lg border border-border/70 bg-secondary/20 p-4 md:block">
        <div className="flex min-h-64 items-stretch gap-6">
          {euro.rounds.map((round) => (
            <EuroBracketColumn key={round.round} round={round} myTeamId={myTeamId} />
          ))}
          {winnerId && winnerTeam ? (
            <div className="flex w-52 shrink-0 flex-col">
              <div className="mb-2 text-center text-xs font-bold text-[#D4AF37]">Чемпион Европы</div>
              <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/10 p-4">
                <TeamCrest
                  shortName={winnerTeam.shortName}
                  colorPrimary={winnerTeam.colorPrimary}
                  colorSecondary={winnerTeam.colorSecondary}
                  size="lg"
                  title={winnerTeam.name}
                />
                <Trophy className="size-6 text-[#D4AF37]" aria-hidden />
                <div className="text-center text-xs font-bold">{winnerTeam.name}</div>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* Мобайл: вертикальный список раундов */}
      <div className="space-y-3 md:hidden">
        {euro.rounds.map((round) => (
          <Card key={round.round} className="border-border/70">
            <CardContent className="flex flex-col gap-3 p-4 pt-4">
              <div className="flex items-baseline justify-between">
                <div className="text-sm font-bold">{round.label}</div>
                <div className="text-[11px] text-muted-foreground tabular">неделя {round.week}</div>
              </div>
              {round.drawn && round.matches.length > 0 ? (
                round.matches.map((m) => <EuroMatchCard key={m.id} m={m} myTeamId={myTeamId} />)
              ) : (
                <p className="rounded-lg border border-dashed border-border/60 bg-secondary/20 px-3 py-3 text-center text-[11px] text-muted-foreground">
                  Жеребьёвка ещё не состоялась
                </p>
              )}
            </CardContent>
          </Card>
        ))}
        {winnerId && winnerTeam ? (
          <div className="flex items-center gap-3 rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/10 p-4">
            <Trophy className="size-6 shrink-0 text-[#D4AF37]" aria-hidden />
            <div className="min-w-0">
              <p className="text-sm font-bold text-[#D4AF37]">Чемпион Европы</p>
              <p className="truncate text-xs text-muted-foreground">{winnerTeam.name}</p>
            </div>
          </div>
        ) : null}
      </div>
    </motion.div>
  );
}

/** Строка статуса клуба игрока (§7.3 ТЗ). */
function EuroStatusBanner({ euro, myQuota }: { euro: EuroSnapshotDTO; myQuota: number }) {
  const next = euro.nextEuroMatch;

  if (euro.status === 'winner') {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/10 px-4 py-3">
        <Trophy className="size-5 shrink-0 text-[#D4AF37]" aria-hidden />
        <p className="text-sm font-bold text-[#D4AF37]">Чемпион Европы! 🏆</p>
      </div>
    );
  }
  if (euro.status === 'eliminated') {
    const label = euro.myEliminatedRound
      ? euro.rounds.find((r) => r.round === euro.myEliminatedRound)?.label
      : null;
    return (
      <div className="flex items-center gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 px-4 py-3">
        <Badge variant="outline" className="shrink-0 border-[#EF4444]/40 text-[#EF4444]">
          Выбыли
        </Badge>
        <p className="text-sm font-semibold text-[#EF4444]">
          {label ? `Ваш клуб выбыл в раунде «${label}»` : 'Ваш клуб выбыл из Кубка Европы'}
        </p>
      </div>
    );
  }
  if (euro.status === 'alive' && next) {
    return (
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-4 py-3">
        <Globe className="size-5 shrink-0 text-primary" aria-hidden />
        <p className="text-sm font-semibold text-primary">
          Кубок Европы · {next.label}
        </p>
        <p className="text-xs text-muted-foreground">
          Соперник: <span className="font-semibold text-foreground">{next.opponent.name}</span>
          {next.opponent.isGuest ? ` (гость из ${next.opponent.leagueName})` : ''} ·{' '}
          {next.isHome ? 'дома' : 'в гостях'} · неделя <span className="tabular">{next.week}</span>
        </p>
      </div>
    );
  }
  if (euro.status === 'alive' || euro.status === 'qualified') {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-4 py-3">
        <Globe className="size-5 shrink-0 text-primary" aria-hidden />
        <p className="text-sm font-semibold text-primary">
          Вы в игре · сетка появится после жеребьёвки 1/8 финала
        </p>
      </div>
    );
  }
  // not_started — квоты лиги
  return (
    <div className="flex items-center gap-2 rounded-lg border border-border/70 bg-secondary/30 px-4 py-3">
      <Globe className="size-5 shrink-0 text-muted-foreground" aria-hidden />
      <p className="text-sm text-muted-foreground">
        Турнир ещё не начался. Ваша лига даёт{' '}
        <span className="font-bold text-foreground">
          {myQuota} {myQuota === 1 ? 'место' : myQuota < 5 ? 'места' : 'мест'}
        </span>{' '}
        — зона топ-{myQuota} таблицы
      </p>
    </div>
  );
}

/** Квоты 6 лиг + призовые (до старта турнира — главный экран). */
function QuotasPanel({ euro, myLeagueCode }: { euro: EuroSnapshotDTO; myLeagueCode: string }) {
  return (
    <Card className="border-border/70">
      <CardContent className="space-y-3 p-4 pt-4">
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold text-muted-foreground">Квоты лиг (16 участников)</p>
          <Badge variant="outline" className="text-[10px] text-muted-foreground tabular">
            сезон стартует на кубковых неделях
          </Badge>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {euro.quotas.map((q) => (
            <div
              key={q.code}
              className={cn(
                'flex items-center justify-between gap-2 rounded border border-border/60 bg-secondary/30 px-2.5 py-2 text-xs',
                q.code === myLeagueCode && 'border-primary/40 bg-primary/5',
              )}
            >
              <span className="flex min-w-0 items-center gap-1.5">
                <span aria-hidden>{q.flag}</span>
                <span className="truncate">{q.code === myLeagueCode ? 'Ваша лига' : codeToName(q.code)}</span>
              </span>
              <span className="shrink-0 font-bold tabular text-foreground">{q.quota}</span>
            </div>
          ))}
        </div>
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Призовые: за участие €2M · победа в 1/8 — €1M · 1/4 — €2M · 1/2 — €3M · финалист — €3.5M ·
          чемпион — €5M.
        </p>
      </CardContent>
    </Card>
  );
}

/** Полное имя лиги по коду (квоты хранят код+флаг). */
function codeToName(code: string): string {
  switch (code) {
    case 'EPL': return 'АПЛ';
    case 'LAL': return 'Ла Лига';
    case 'SEA': return 'Серия А';
    case 'BUN': return 'Бундеслига';
    case 'FL1': return 'Лига 1';
    case 'RPL': return 'РПЛ';
    default: return code;
  }
}

/** Секция «Участники»: 16 карточек с лигами и стилями тренеров. */
function EuroParticipants({ euro, myTeamId }: { euro: EuroSnapshotDTO; myTeamId: string }) {
  if (euro.participants.length === 0) {
    return (
      <Card className="border-border/70">
        <CardContent className="py-8 text-center text-sm text-muted-foreground">
          Участники определятся после квалификации — топ-клубы шести лиг по таблицам.
        </CardContent>
      </Card>
    );
  }
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3"
    >
      {euro.participants.map((t, i) => (
        <div
          key={t.id}
          className={cn(
            'flex items-center gap-2.5 rounded-lg border border-border/60 bg-card px-3 py-2.5',
            t.id === myTeamId && 'border-primary/50 bg-primary/5',
          )}
        >
          <span className="w-5 shrink-0 text-center text-[11px] font-semibold tabular text-muted-foreground">
            {i + 1}
          </span>
          <TeamCrest
            shortName={t.shortName}
            colorPrimary={t.colorPrimary}
            colorSecondary={t.colorSecondary}
            size="sm"
            title={t.name}
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className={cn('truncate text-xs font-semibold', t.isUser && 'text-primary')}>
                {t.name}
              </span>
              {t.isGuest ? (
                <span className="shrink-0 rounded bg-secondary px-1 py-0.5 text-[9px] font-medium text-muted-foreground">
                  гость
                </span>
              ) : null}
            </div>
            <p className="truncate text-[10px] text-muted-foreground">
              <span aria-hidden>{t.leagueFlag}</span> {t.leagueName} · сила{' '}
              <span className="tabular">{t.strength}</span>
              {t.coachName ? ` · ${t.coachName}` : ''}
            </p>
            <CoachStyleBadge style={t.coachStyle} className="mt-1" />
          </div>
        </div>
      ))}
    </motion.div>
  );
}

/** Все сыгранные евроматчи сезона, клик — детали. */
function EuroResults() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const activeSaveId = useGameStore((s) => s.activeSaveId);
  const { seasonMatches, teams } = snapshot;
  const teamById = useMemo(() => new Map(teams.map((t) => [t.id, t])), [teams]);

  const [matchId, setMatchId] = useState<string | null>(null);
  const [matchData, setMatchData] = useState<MatchDetailsDTO | null>(null);
  const [matchLoading, setMatchLoading] = useState(false);

  const openMatch = (id: string) => {
    if (!activeSaveId) return;
    setMatchId(id);
    setMatchLoading(true);
    setMatchData(null);
    void api
      .getMatch(activeSaveId, id)
      .then((res) => setMatchData(res.match))
      .catch(() => setMatchData(null))
      .finally(() => setMatchLoading(false));
  };

  const closeMatch = () => {
    setMatchId(null);
    setMatchData(null);
    setMatchLoading(false);
  };

  const played = useMemo(
    () => seasonMatches.filter((m) => m.competition === 'euro' && m.played).sort((a, b) => b.week - a.week),
    [seasonMatches],
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
      {played.length === 0 ? (
        <Card className="border-border/70">
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            Еврокубковые матчи ещё не сыграли. Первый раунд — 1/8 финала на кубковой неделе.
          </CardContent>
        </Card>
      ) : (
        played.map((m) => {
          const home = teamById.get(m.homeTeamId);
          const away = teamById.get(m.awayTeamId);
          const isUser = m.homeTeamId === snapshot.myTeam.id || m.awayTeamId === snapshot.myTeam.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => openMatch(m.id)}
              className={cn(
                'flex w-full items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-2.5 text-left transition-colors hover:border-primary/50',
                isUser && 'border-primary/40 bg-primary/5',
              )}
            >
              <div className="flex min-w-0 flex-1 items-center justify-end gap-2 text-right">
                <span className={cn('hidden truncate text-xs sm:inline', isUser && 'font-bold text-primary')}>
                  {home?.name ?? '—'}
                </span>
                <TeamCrest
                  shortName={home?.shortName ?? '—'}
                  colorPrimary={home?.colorPrimary ?? '#0E7490'}
                  colorSecondary={home?.colorSecondary ?? '#F0F6FC'}
                  size="sm"
                />
              </div>
              <div className="w-16 shrink-0 text-center text-sm font-bold tabular">
                {m.homeGoals} : {m.awayGoals}
              </div>
              <div className="flex min-w-0 flex-1 items-center gap-2">
                <TeamCrest
                  shortName={away?.shortName ?? '—'}
                  colorPrimary={away?.colorPrimary ?? '#0E7490'}
                  colorSecondary={away?.colorSecondary ?? '#F0F6FC'}
                  size="sm"
                />
                <span className={cn('hidden truncate text-xs sm:inline', isUser && 'font-bold text-primary')}>
                  {away?.name ?? '—'}
                </span>
              </div>
            </button>
          );
        })
      )}
      <MatchDetailsDialog
        matchId={matchId}
        match={matchData}
        loading={matchLoading}
        onClose={closeMatch}
      />
    </motion.div>
  );
}

/** Топ-10 бомбардиров Кубка Европы (GET /awards live.topEuroScorers, вкл. гостей). */
function EuroScorers() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const awardsCache = useGameStore((s) => s.awardsCache);
  const awardsLoading = useGameStore((s) => s.awardsLoading);
  const fetchAwards = useGameStore((s) => s.fetchAwards);

  useEffect(() => {
    void fetchAwards();
  }, [fetchAwards]);

  const scorers = awardsCache?.live.topEuroScorers ?? [];

  if (awardsLoading && scorers.length === 0) {
    return (
      <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Загружаем бомбардиров Кубка Европы…
      </div>
    );
  }

  if (scorers.length === 0) {
    return (
      <Card className="border-border/70">
        <CardContent className="py-8 text-center text-sm text-muted-foreground">
          Голы в Кубке Европы ещё не забиты.
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="overflow-hidden rounded-lg border border-border/70 bg-card"
    >
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="h-10 w-10 text-center text-[11px]">#</TableHead>
            <TableHead className="h-10 text-[11px]">Игрок</TableHead>
            <TableHead className="h-10 text-[11px]">Клуб</TableHead>
            <TableHead className="h-10 w-12 text-center text-[11px]">Голы</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="zebra">
          {scorers.slice(0, 10).map((p, i) => (
            <TableRow
              key={p.playerId}
              className={cn('h-10 border-border/40', p.isUser && 'bg-primary/10 hover:bg-primary/10')}
            >
              <TableCell className="text-center text-xs font-semibold tabular">{i + 1}</TableCell>
              <TableCell className={cn('text-xs', p.isUser && 'font-bold text-primary')}>
                <span className="flex items-center gap-1.5">
                  <Goal className="size-3 text-muted-foreground" aria-hidden />
                  {p.name}
                </span>
              </TableCell>
              <TableCell>
                <span className="flex items-center gap-1.5">
                  <TeamCrest
                    shortName={p.teamShort}
                    colorPrimary={p.colorPrimary}
                    colorSecondary={p.colorSecondary}
                    size="sm"
                    title={p.teamName}
                  />
                  <span className="truncate text-xs text-muted-foreground">{p.teamName}</span>
                </span>
              </TableCell>
              <TableCell className="text-center text-xs font-bold tabular">{p.goals}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <p className="border-t border-border/50 px-4 py-2 text-[11px] text-muted-foreground">
        Голы Кубка Европы текущего сезона · {snapshot.save.season}
      </p>
    </motion.div>
  );
}

/** Экран «Европа»: статус, сетка 4 раундов, участники, бомбардиры (§7.3). */
export function EuroScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const euro = useGameStore((s) => s.euroCache);
  const euroLoading = useGameStore((s) => s.euroLoading);
  const fetchEuro = useGameStore((s) => s.fetchEuro);
  const { save, myTeam } = snapshot;

  useEffect(() => {
    void fetchEuro();
  }, [fetchEuro]);

  if (!euro) {
    return (
      <div className="space-y-4">
        <SectionHeader title="Кубок Европы" subtitle={`Сезон ${save.season} · 16 клубов · 6 лиг`} />
        {euroLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full rounded-lg" />
            <Skeleton className="h-64 w-full rounded-lg" />
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-16 rounded-lg" />
              ))}
            </div>
          </div>
        ) : (
          <Card className="border-border/70">
            <CardContent className="py-8 text-center text-sm text-muted-foreground">
              Не удалось загрузить турнир. Обновите вкладку.
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  const myQuota = euro.quotas.find((q) => q.code === save.league.code)?.quota ?? 2;
  const started = euro.participants.length > 0;

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Кубок Европы"
        subtitle={`Сезон ${save.season} · 16 клубов из 6 лиг · одна игра в раунде`}
      />
      <EuroStatusBanner euro={euro} myQuota={myQuota} />
      {!started ? <QuotasPanel euro={euro} myLeagueCode={save.league.code} /> : null}
      <Tabs defaultValue="bracket">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="bracket" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Trophy className="size-4" aria-hidden />
            Сетка
          </TabsTrigger>
          <TabsTrigger value="results" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <ListOrdered className="size-4" aria-hidden />
            Результаты
          </TabsTrigger>
          <TabsTrigger value="participants" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Globe className="size-4" aria-hidden />
            Участники
          </TabsTrigger>
          <TabsTrigger value="scorers" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Goal className="size-4" aria-hidden />
            Бомбардиры
          </TabsTrigger>
        </TabsList>
        <TabsContent value="bracket">
          <EuroBracket euro={euro} myTeamId={myTeam.id} />
        </TabsContent>
        <TabsContent value="results">
          <EuroResults />
        </TabsContent>
        <TabsContent value="participants">
          <EuroParticipants euro={euro} myTeamId={myTeam.id} />
        </TabsContent>
        <TabsContent value="scorers">
          <EuroScorers />
        </TabsContent>
      </Tabs>
      <p className="sr-only">
        Кубок Европы: {euro.rounds.map((r) => r.label).join(', ')}.
      </p>
    </div>
  );
}

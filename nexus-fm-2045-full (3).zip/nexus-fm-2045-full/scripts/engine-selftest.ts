/**
 * D-3a самотест ядра движка (запуск: `bun scripts/engine-selftest.ts`,
 * StorageAdapter = MemoryStorage). Проверки:
 *  (a) createCareer для всех 6 лиг — количество клубов/игроков/матчей
 *      календаря против констант generate/leagues (6 лиг / 112 клубов);
 *  (b) canonical save → load → save байт-в-байт (formatVersion, порядок
 *      ключей, ревайв Date);
 *  (c) детерминизм: два createCareer с одинаковым сидом → идентичные
 *      canonical-дампы (и файлы слотов);
 *  (d) слоты: 8 создаются, 9-й отказ (SAVE_LIMIT_REACHED), delete/rename,
 *      переиспользование освободившегося слота, сортировка списка;
 *  (e) P2002-эмуляция: дубликат Match-композита, Listing.playerId,
 *      GameSave.teamId (NULL-семантика SQLite), дубль id, P2025;
 *  (f) инвентарные паттерны адаптера: where {not}/{in}/равенство,
 *      мульти-orderBy, take/skip, select, include {player}/{team},
 *      createMany/updateMany/deleteMany/count/$transaction, @updatedAt.
 * Печать: PASS/FAIL по пунктам; итог PASS=N FAIL=M; exit code 0/1.
 */

import { cupRoundsOf } from '@/lib/game/calendar';
import { SAVES_MAX, START_BALANCE_BASE, START_BALANCE_PER_STRENGTH } from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { LEAGUES } from '@/lib/game/leagues';
import { createCareer } from '@/engine/career';
import {
  createSaveStore, EngineRecordNotFoundError, EngineUniqueError,
} from '@/engine/db';
import { createSlots, SLOT_FORMAT_VERSION } from '@/engine/save';
import { createStorage, MemoryStorage } from '@/engine/storage';

let pass = 0;
let fail = 0;
const failures: string[] = [];

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    pass += 1;
    console.log(`PASS ${name}`);
  } else {
    fail += 1;
    const suffix = detail !== undefined ? ` :: ${detail}` : '';
    console.log(`FAIL ${name}${suffix}`);
    failures.push(name);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  const show = (v: unknown): string => {
    if (typeof v === 'string') return JSON.stringify(v);
    return String(v);
  };
  check(name, actual === expected, `actual=${show(actual)} expected=${show(expected)}`);
}

function errorInfo(error: unknown): { code: string; target: string; cls: string } {
  const e = error as { code?: string; meta?: { target?: string[] }; name?: string };
  return {
    code: e?.code ?? '',
    target: (e?.meta?.target ?? []).join(','),
    cls: e?.name ?? '',
  };
}

const NOW = new Date('2025-01-01T12:00:00.000Z');

// ── (a) createCareer × 6 лиг ───────────────────────────────────────────────

console.log('== (a) createCareer: 6 лиг / 112 клубов / составы / календарь ==');

let totalClubs = 0;
let totalPlayers = 0;
for (const def of LEAGUES) {
  const res = await createCareer({
    leagueCode: def.code,
    clubIndex: 0,
    managerName: 'Тест Менеджер',
    seed: 1000 + def.teamCount,
    now: NOW,
  });
  const store = res.store;
  const saveRow = (await store.gameSave.findMany())[0];
  const teams = await store.team.findMany({ where: { saveId: res.saveId } });
  const players = await store.player.findMany({ where: { saveId: res.saveId } });
  const matches = await store.match.findMany({ where: { saveId: res.saveId } });
  const news = await store.newsItem.findMany({ where: { saveId: res.saveId } });

  eq(`a_teams_${def.code}`, teams.length, def.teamCount);
  check(
    `a_players_${def.code}`,
    players.length >= def.teamCount * 20 && players.length <= def.teamCount * 22,
    `players=${players.length} (ожидание ${def.teamCount * 20}..${def.teamCount * 22})`,
  );
  eq(`a_matches_${def.code}`, matches.length, def.teamCount * (def.teamCount - 1));
  eq(`a_news_${def.code}`, news.length, 1);
  check(`a_gameSave_row_${def.code}`, !!saveRow);
  eq(`a_status_${def.code}`, saveRow?.status, 'active');
  check(`a_teamId_set_${def.code}`, typeof saveRow?.teamId === 'string');
  eq(
    `a_balance_${def.code}`,
    saveRow?.balance,
    START_BALANCE_BASE + Math.max(0, def.clubs[0].str - 55) * START_BALANCE_PER_STRENGTH,
  );
  eq(`a_season_week_${def.code}`, `${saveRow?.season}:${saveRow?.week}`, '1:1');
  eq(`a_leagueCode_${def.code}`, saveRow?.leagueCode, def.code);

  const myTeam = teams.find((t) => t.id === saveRow?.teamId);
  const lineup: unknown = myTeam ? JSON.parse(myTeam.lineup ?? '[]') : [];
  const bench: unknown = myTeam ? JSON.parse(myTeam.bench ?? '[]') : [];
  eq(`a_lineup_11_${def.code}`, Array.isArray(lineup) ? lineup.length : -1, 11);
  check(
    `a_bench_${def.code}`,
    Array.isArray(bench) && bench.length <= 7,
    `bench=${Array.isArray(bench) ? bench.length : 'not-array'}`,
  );
  eq(`a_isUserTeam_${def.code}`, myTeam?.isUserTeam, true);

  const weeks = new Set(matches.map((m) => m.week));
  eq(`a_league_weeks_${def.code}`, weeks.size, def.leagueWeeks);
  check(
    `a_card_${def.code}`,
    !!res.save
      && res.save.clubName === def.clubs[0].name
      && res.save.place >= 1 && res.save.place <= def.teamCount
      && res.save.season === 1 && res.save.week === 1
      && res.save.totalWeeks === def.leagueWeeks + cupRoundsOf(def.teamCount)
      && Array.isArray(res.save.form) && res.save.form.length === 0,
    `club=${res.save?.clubName} place=${res.save?.place} totalWeeks=${res.save?.totalWeeks}`,
  );

  totalClubs += teams.length;
  totalPlayers += players.length;
}
eq('a_total_clubs', totalClubs, 112);
check('a_total_players_range', totalPlayers >= 112 * 20 && totalPlayers <= 112 * 22, `total=${totalPlayers}`);

// ── (b) canonical save → load → save байт-в-байт ───────────────────────────

console.log('\n== (b) canonical roundtrip байт-в-байт ==');

const storageB = new MemoryStorage();
const slotsB = createSlots(storageB);
const resB = await createCareer({
  leagueCode: 'EPL', clubIndex: 2, managerName: 'Roundtrip', seed: 777, now: NOW,
});
const handleB = await slotsB.create(resB.store, { now: NOW });
eq('b_slot_assigned', handleB.slot, 1);

const raw1 = await storageB.read(1);
check('b_raw_written', typeof raw1 === 'string' && raw1.length > 1000, `len=${raw1?.length}`);
const parsed1: Record<string, unknown> = raw1 ? JSON.parse(raw1) : {};
eq('b_envelope_keys', Object.keys(parsed1).join(','), 'formatVersion,createdAt,updatedAt,career');
eq('b_format_version', parsed1.formatVersion, SLOT_FORMAT_VERSION);
eq('b_created_at', parsed1.createdAt, NOW.toISOString());
eq(
  'b_career_keys',
  Object.keys((parsed1.career ?? {}) as Record<string, unknown>).join(','),
  'gameSave,teams,players,matches,transferListings,playerSeasonRecords,newsItems,financeRecords,seasonAwards,newspaperClippings',
);
const firstSave = ((parsed1.career as Record<string, unknown>).gameSave as Record<string, unknown>[])[0];
eq('b_record_first_key', firstSave ? Object.keys(firstSave)[0] : '', 'id');

const loadedB = await slotsB.load(1);
await slotsB.save(loadedB);
const raw2 = await storageB.read(1);
check('b_roundtrip_bytes', raw1 === raw2, `len1=${raw1?.length} len2=${raw2?.length}`);
check(
  'b_dump_equal',
  JSON.stringify(loadedB.store.toJSON()) === JSON.stringify(resB.store.toJSON()),
);
const revivedSave = await loadedB.store.gameSave.findFirst();
check(
  'b_date_revived',
  revivedSave?.createdAt instanceof Date && revivedSave.createdAt.toISOString() === NOW.toISOString(),
);
eq('b_load_envelope', loadedB.envelope.updatedAt, NOW.toISOString());

// ── (c) детерминизм от сида ────────────────────────────────────────────────

console.log('\n== (c) детерминизм: один сид → одинаковый дамп ==');

const det1 = await createCareer({ leagueCode: 'BUN', clubIndex: 1, managerName: 'Дет', seed: 12345, now: NOW });
const det2 = await createCareer({ leagueCode: 'BUN', clubIndex: 1, managerName: 'Дет', seed: 12345, now: NOW });
const det3 = await createCareer({ leagueCode: 'BUN', clubIndex: 1, managerName: 'Дет', seed: 999, now: NOW });
const dump1 = JSON.stringify(det1.store.toJSON());
const dump2 = JSON.stringify(det2.store.toJSON());
const dump3 = JSON.stringify(det3.store.toJSON());
check('c_same_seed_same_dump', dump1 === dump2);
check('c_diff_seed_diff_dump', dump1 !== dump3);
eq('c_same_saveId', det2.saveId, det1.saveId);
const storageC1 = new MemoryStorage();
const storageC2 = new MemoryStorage();
const slotsC1 = createSlots(storageC1);
const slotsC2 = createSlots(storageC2);
await slotsC1.create(det1.store, { now: NOW });
await slotsC2.create(det2.store, { now: NOW });
check('c_slot_file_deterministic', (await storageC1.read(1)) === (await storageC2.read(1)));

// ── (d) слоты: 8 создаются, 9-й отказ, delete/rename ───────────────────────

console.log('\n== (d) слоты: лимит 8, delete, rename, переиспользование ==');

const storageD = new MemoryStorage();
const slotsD = createSlots(storageD);
const assigned: number[] = [];
for (let i = 0; i < SAVES_MAX; i++) {
  const def = LEAGUES[i % LEAGUES.length];
  const at = new Date(NOW.getTime() + i * 60_000);
  const res = await createCareer({
    leagueCode: def.code,
    clubIndex: i % def.teamCount,
    managerName: `Менеджер ${i + 1}`,
    careerName: `Карьера ${i + 1}`,
    seed: 5000 + i,
    now: at,
  });
  const handle = await slotsD.create(res.store, { now: at });
  assigned.push(handle.slot);
}
eq('d_slots_sequence', assigned.join(','), '1,2,3,4,5,6,7,8');
eq('d_list_8', (await slotsD.list()).length, SAVES_MAX);

// Минимальное хранилище для проверки лимита (без генерации мира)
const tiny = createSaveStore();
await tiny.gameSave.create({ data: { id: 'tiny-save', managerName: 'М', leagueCode: 'RPL', teamId: 'tiny-team' } });
await tiny.team.create({ data: { id: 'tiny-team', saveId: 'tiny-save', name: 'Клуб Х', leagueCode: 'RPL' } });
await tiny.player.create({
  data: { id: 'tiny-p1', saveId: 'tiny-save', teamId: 'tiny-team', firstName: 'Иван', lastName: 'Иванов', position: 'GK', age: 20, potential: 60, ovr: 55 },
});
let limitError = '';
try {
  await slotsD.create(tiny);
} catch (error) {
  limitError = errorInfo(error).code;
}
eq('d_9th_slot_refused', limitError, 'SAVE_LIMIT_REACHED');
eq('d_free_slot_none', await slotsD.freeSlot(), null);

await slotsD.remove(3);
eq('d_list_7', (await slotsD.list()).length, SAVES_MAX - 1);
eq('d_free_slot_3', await slotsD.freeSlot(), 3);
check('d_removed_slot_unreadable', (await storageD.read(3)) === null);

const resReuse = await createCareer({
  leagueCode: 'RPL', clubIndex: 5, managerName: 'Повторно', seed: 6000, now: new Date(NOW.getTime() + 8 * 60_000),
});
const handleReuse = await slotsD.create(resReuse.store, { now: new Date(NOW.getTime() + 8 * 60_000) });
eq('d_slot_reused', handleReuse.slot, 3);

await slotsD.rename(1, 'Переименованная карьера');
const cardsD = await slotsD.list();
const cardD1 = cardsD.find((c) => c.slot === 1);
eq('d_rename_card', cardD1?.card.careerName, 'Переименованная карьера');
let renameError = '';
try {
  await slotsD.rename(1, '');
} catch (error) {
  renameError = errorInfo(error).code;
}
eq('d_rename_empty_refused', renameError, 'INVALID_CAREER_NAME');
renameError = '';
try {
  await slotsD.rename(1, 'x'.repeat(61));
} catch (error) {
  renameError = errorInfo(error).code;
}
eq('d_rename_long_refused', renameError, 'INVALID_CAREER_NAME');

// Сортировка списка: lastOpenedAt desc → последняя созданная карьера первая
eq('d_list_order_latest_first', cardsD[0]?.slot, 3);
const handleLoaded5 = await slotsD.load(5);
eq('d_load_slot', handleLoaded5.slot, 5);
eq('d_current_slot', slotsD.current()?.slot, 5);
await slotsD.remove(5);
check('d_current_cleared', slotsD.current() === null);
let loadMissing = '';
try {
  await slotsD.load(5);
} catch (error) {
  loadMissing = errorInfo(error).code;
}
eq('d_load_missing_404', loadMissing, 'SAVE_NOT_FOUND');

// ── (e) P2002-эмуляция unique-нарушений ───────────────────────────────────

console.log('\n== (e) P2002: дубликаты unique-индексов ==');

const resE = await createCareer({ leagueCode: 'RPL', clubIndex: 0, managerName: 'Уник', seed: 4242, now: NOW });
const storeE = resE.store;
const saveIdE = resE.saveId;
const matchE = (await storeE.match.findFirst({ where: { saveId: saveIdE } }));
check('e_fixture_present', !!matchE);

let caught = '';
let target = '';
try {
  await storeE.match.create({
    data: {
      id: 'dup-match', saveId: saveIdE, season: matchE?.season, week: matchE?.week,
      homeTeamId: matchE?.homeTeamId, awayTeamId: 'other-team',
    },
  });
} catch (error) {
  caught = errorInfo(error).cls;
  target = errorInfo(error).target;
}
eq('e_match_composite_p2002', caught, 'EngineUniqueError');
eq('e_match_composite_target', target, 'saveId,season,week,homeTeamId,competition');

// Та же неделя, но ДРУГОЙ домашний клуб — не дубликат (конджестшн-паттерн)
await storeE.match.create({
  data: { id: 'ok-match', saveId: saveIdE, season: matchE?.season, week: matchE?.week, homeTeamId: 'teamX', awayTeamId: 'teamY' },
});
check('e_match_other_home_ok', !!(await storeE.match.findUnique({ where: { id: 'ok-match' } })));

const playerA = (await storeE.player.findFirst({ where: { saveId: saveIdE } }));
const playerB = (await storeE.player.findMany({ where: { saveId: saveIdE, id: { not: playerA?.id ?? '' } } }))[0];
await storeE.transferListing.create({ data: { id: 'l1', saveId: saveIdE, playerId: playerA?.id ?? '', price: 1_000_000 } });
caught = '';
target = '';
try {
  await storeE.transferListing.create({ data: { id: 'l2', saveId: saveIdE, playerId: playerA?.id ?? '', price: 2_000_000 } });
} catch (error) {
  caught = errorInfo(error).cls;
  target = errorInfo(error).target;
}
eq('e_listing_playerid_p2002', caught, 'EngineUniqueError');
eq('e_listing_playerid_target', target, 'playerId');

await storeE.transferListing.create({ data: { id: 'l2', saveId: saveIdE, playerId: playerB?.id ?? '', price: 3_000_000 } });
caught = '';
try {
  await storeE.transferListing.update({ where: { id: 'l2' }, data: { playerId: playerA?.id ?? '' } });
} catch (error) {
  caught = errorInfo(error).cls;
}
eq('e_listing_update_p2002', caught, 'EngineUniqueError');

const saveRowE = (await storeE.gameSave.findFirst());
caught = '';
target = '';
try {
  await storeE.gameSave.create({ data: { id: 'save2', managerName: 'М2', leagueCode: 'RPL', teamId: saveRowE?.teamId } });
} catch (error) {
  caught = errorInfo(error).cls;
  target = errorInfo(error).target;
}
eq('e_gamesave_teamid_p2002', caught, 'EngineUniqueError');
eq('e_gamesave_teamid_target', target, 'teamId');

// NULL вне unique (семантика SQLite): несколько сейвов с teamId = null
await storeE.gameSave.create({ data: { id: 'save3', managerName: 'М3', leagueCode: 'RPL' } });
await storeE.gameSave.create({ data: { id: 'save4', managerName: 'М4', leagueCode: 'RPL', teamId: null } });
eq('e_gamesave_null_teamid_ok', await storeE.gameSave.count(), 3);
await storeE.gameSave.delete({ where: { id: 'save3' } });
await storeE.gameSave.delete({ where: { id: 'save4' } });
eq('e_gamesave_back_to_1', await storeE.gameSave.count(), 1);

const teamE0 = (await storeE.team.findFirst({ where: { saveId: saveIdE } }));
caught = '';
target = '';
try {
  await storeE.team.create({ data: { id: teamE0?.id ?? '', saveId: saveIdE, name: 'Дубль' } });
} catch (error) {
  caught = errorInfo(error).cls;
  target = errorInfo(error).target;
}
eq('e_duplicate_id_p2002', caught, 'EngineUniqueError');
eq('e_duplicate_id_target', target, 'id');

let p2025 = '';
try {
  await storeE.team.update({ where: { id: 'no-such-team' }, data: { name: 'X' } });
} catch (error) {
  p2025 = errorInfo(error).cls + ':' + errorInfo(error).code;
}
eq('e_p2025_update_missing', p2025, 'EngineRecordNotFoundError:P2025');

// ── (f) инвентарные паттерны адаптера ──────────────────────────────────────

console.log('\n== (f) адаптер: where/orderBy/take/skip/select/include/мутации ==');

const playersE = await storeE.player.findMany({ where: { saveId: saveIdE } });
const withTeam = await storeE.player.findMany({ where: { saveId: saveIdE, teamId: { not: null } } });
eq('f_where_not_null', withTeam.length, playersE.length);
eq('f_where_eq_null', (await storeE.player.findMany({ where: { saveId: saveIdE, teamId: null } })).length, 0);

const teamsE = await storeE.team.findMany({ where: { saveId: saveIdE } });
const inList = await storeE.team.findMany({ where: { saveId: saveIdE, id: { in: [teamsE[0]?.id ?? '', teamsE[3]?.id ?? ''] } } });
eq('f_where_in', inList.length, 2);
eq('f_where_in_miss', (await storeE.team.findMany({ where: { saveId: saveIdE, id: { in: ['nope'] } } })).length, 0);

const matchesE = await storeE.match.findMany({ where: { saveId: saveIdE } });
eq('f_where_not_value', (await storeE.match.findMany({ where: { saveId: saveIdE, status: { not: 'played' } } })).length, matchesE.length);
eq('f_where_eq_value', (await storeE.match.findMany({ where: { saveId: saveIdE, status: 'played' } })).length, 0);

const sortedMatches = await storeE.match.findMany({ where: { saveId: saveIdE }, orderBy: [{ week: 'asc' }, { id: 'asc' }] });
check(
  'f_orderby_weeks_asc',
  sortedMatches.every((m, i) => i === 0 || (sortedMatches[i - 1] as MatchLike).week <= (m as MatchLike).week),
);
const page = await storeE.match.findMany({ where: { saveId: saveIdE }, orderBy: [{ week: 'asc' }, { id: 'asc' }], take: 5, skip: 2 });
eq('f_take_skip_len', page.length, 5);
check(
  'f_take_skip_window',
  page.every((m, i) => m.id === sortedMatches[2 + i]?.id),
);
const selected = await storeE.match.findMany({ where: { saveId: saveIdE }, select: { id: true, week: true }, take: 1 });
eq('f_select_keys', selected[0] ? Object.keys(selected[0]).join(',') : '', 'id,week');

const listingsE = await storeE.transferListing.findMany({ where: { saveId: saveIdE }, include: { player: true } });
eq('f_include_count', listingsE.length, 2);
check('f_include_player_resolved', listingsE.every((l) => l.player?.id === l.playerId));
const saveWithTeam = await storeE.gameSave.findUnique({ where: { id: saveIdE }, include: { team: true } });
check('f_include_team_resolved', saveWithTeam?.team?.id === saveWithTeam?.teamId);

const createManyResult = await storeE.playerSeasonRecord.createMany({
  data: [
    seasonRecord('psr1', saveIdE, playerA?.id ?? '', playerA?.teamId ?? null),
    seasonRecord('psr2', saveIdE, playerB?.id ?? '', playerB?.teamId ?? null),
  ],
});
eq('f_createMany_count', createManyResult.count, 2);
eq('f_createMany_rows', await storeE.playerSeasonRecord.count({ where: { saveId: saveIdE } }), 2);

const updateManyResult = await storeE.transferListing.updateMany({ where: { saveId: saveIdE, status: 'active' }, data: { status: 'expired' } });
eq('f_updateMany_count', updateManyResult.count, 2);
eq('f_updateMany_state', await storeE.transferListing.count({ where: { saveId: saveIdE, status: 'expired' } }), 2);

const txResult = await storeE.$transaction([
  storeE.newsItem.create({ data: { id: 'n-tx', saveId: saveIdE, season: 1, week: 1, type: 'info', message: 'tx' } }),
  storeE.newsItem.count({ where: { saveId: saveIdE } }),
]);
check('f_transaction_array', Array.isArray(txResult) && txResult.length === 2);
eq('f_transaction_values', txResult[1], 2);

const deleteManyResult = await storeE.playerSeasonRecord.deleteMany({ where: { saveId: saveIdE } });
eq('f_deleteMany_count', deleteManyResult.count, 2);
eq('f_deleteMany_gone', await storeE.playerSeasonRecord.count({ where: { saveId: saveIdE } }), 0);

// @updatedAt: бампается при update, createdAt — нет
const storeF = createSaveStore();
const OLD = new Date('2020-01-01T00:00:00.000Z');
await storeF.gameSave.create({ data: { id: 'sf', managerName: 'М', leagueCode: 'EPL', createdAt: OLD, updatedAt: OLD } });
const updatedF = await storeF.gameSave.update({ where: { id: 'sf' }, data: { balance: 5 } });
eq('f_update_merge', updatedF.balance, 5);
check('f_updatedAt_bumped', updatedF.updatedAt.getTime() > OLD.getTime());
check('f_createdAt_stable', updatedF.createdAt.getTime() === OLD.getTime());

// createStorage: автовыбор в bun (без window) → MemoryStorage
const autoStorage = await createStorage();
check('f_createStorage_memory', autoStorage instanceof MemoryStorage);

// ── итог ───────────────────────────────────────────────────────────────────

console.log(`\nPASS=${pass} FAIL=${fail}`);
if (failures.length > 0) {
  console.log(`FAILED: ${failures.join(', ')}`);
}
process.exit(fail > 0 ? 1 : 0);

// ── локальные типы/хелперы ─────────────────────────────────────────────────

interface MatchLike { week: number }

function seasonRecord(id: string, saveId: string, playerId: string, teamId: string | null) {
  return {
    id, saveId, season: 1, playerId, teamId, teamName: 'Клуб', age: 20, position: 'ST',
    apps: 10, goals: 5, assists: 2, cupGoals: 1, cupAssists: 0, cleanSheets: 0,
    yellowCards: 1, redCards: 0, avgRating: 68,
  };
}

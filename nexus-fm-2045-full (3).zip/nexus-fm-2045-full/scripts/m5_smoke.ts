/**
 * Модуль 5 smoke: финансы / инфраструктура / правление.
 * Юниты чистых функций (stadium.ts / buildings.ts / budget.ts / board.ts) +
 * интеграция через router/db (POST /stadium, скаут-центр, бюджеты, финцель,
 * история доверия, отчёт по статьям, сезонный пересбор).
 * Запуск: `bun scripts/m5_smoke.ts`.
 */

import { mulberry32 } from '@/lib/game/rng';
import {
  BUILDINGS, BUILDING_IDS, BUILDING_MAX_LEVEL, parseBuildings, scoutSlotsBonus,
  scoutSpeedMult, serializeBuildings, startLevelsByStrength, upkeepWeeklyOfBuilding,
} from '@/engine/buildings';
import {
  migrateTransferBudget, migrateWageBudget, seasonTransferBudgetOf, transferBudgetAfterBuy,
  transferBudgetAfterSale, wageBudgetAllows,
} from '@/lib/game/budget';
import {
  appendBoardPoint, assignFinanceTargetOf, financeTargetOnTrack, parseBoardHistory,
  serializeBoardHistory,
} from '@/lib/game/board';
import {
  availableStadiumOptions, maxStadiumSeatsFor, stadiumDaysOf, stadiumFits, stadiumPriceOf,
} from '@/lib/game/stadium';
import { scoutSlotsOf } from '@/lib/game/scouting';
import { engineDispatch } from '@/engine/router';
import { getEngine } from '@/engine/index';

let pass = 0;
let fail = 0;
const failures: string[] = [];

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    pass += 1;
    console.log(`PASS ${name}`);
  } else {
    fail += 1;
    failures.push(name);
    const suffix = detail !== undefined ? ` :: ${detail}` : '';
    console.log(`FAIL ${name}${suffix}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  check(name, actual === expected, `actual=${String(actual)} expected=${String(expected)}`);
}

// патч uuid (как engine-smoke / m4)
let uuidCounter = 0;
crypto.randomUUID = ((): string => {
  uuidCounter += 1;
  return `00000000-0000-4000-8000-${String(uuidCounter).padStart(12, '0')}`;
}) as typeof crypto.randomUUID;

const NOW = new Date('2025-07-01T12:00:00Z');

// ── U1: стадион (stadium.ts) ───────────────────────────────────────────────

console.log('\n== U1: стадион ==');

eq('u1_price_base_3000', stadiumPriceOf(0, 3000), 2_700_000);
eq('u1_price_base_8000', stadiumPriceOf(0, 8000), 7_200_000);
eq('u1_price_grows_with_capacity', stadiumPriceOf(50_000, 5000), 6_750_000);
check('u1_price_monotonic', stadiumPriceOf(60_000, 5000) > stadiumPriceOf(50_000, 5000));
eq('u1_days_3000', stadiumDaysOf(3000), 56);
eq('u1_days_5000', stadiumDaysOf(5000), 70);
eq('u1_days_8000', stadiumDaysOf(8000), 84);
eq('u1_fits_ok', stadiumFits(40_000, 8000), true);
eq('u1_fits_over_limit', stadiumFits(84_000, 8000), false);
eq('u1_fits_edge', stadiumFits(82_000, 8000), true);
eq('u1_max_null_at_cap', maxStadiumSeatsFor(90_000), null);
eq('u1_max_big_at_mid', maxStadiumSeatsFor(40_000), 8000);
eq('u1_options_filtered', availableStadiumOptions(86_000).length, 1);
eq('u1_options_full', availableStadiumOptions(10_000).length, 3);
check('u1_options_have_price_days', availableStadiumOptions(10_000).every(
  (o) => o.price > 0 && o.days > 0,
));

// ── U2: скаут-центр (buildings.ts, 9-е здание) ─────────────────────────────

console.log('\n== U2: скаут-центр ==');

eq('u2_catalog_nine', BUILDINGS.length, 9);
eq('u2_ids_nine', BUILDING_IDS.length, 9);
check('u2_scoutcenter_in_catalog', BUILDING_IDS.includes('scoutcenter'));
eq('u2_scoutcenter_first_8_order_unchanged',
  BUILDING_IDS.slice(0, 8).join(','),
  'training,medical,fitness,academy,hotel,parking,fanshop,vip');
eq('u2_speed_mult_0', scoutSpeedMult(0), 1);
eq('u2_speed_mult_3', scoutSpeedMult(3), 1.18);
eq('u2_speed_mult_5', scoutSpeedMult(5), 1.3);
eq('u2_slots_bonus_l2', scoutSlotsBonus(2), 0);
eq('u2_slots_bonus_l3', scoutSlotsBonus(3), 1);
eq('u2_slots_bonus_l5', scoutSlotsBonus(5), 2);
eq('u2_upkeep_zero_l0', upkeepWeeklyOfBuilding('scoutcenter', 0), 0);
check('u2_upkeep_positive_l1', upkeepWeeklyOfBuilding('scoutcenter', 1) > 0);

// легаси-JSON без scoutcenter → L0 (толерантность)
const legacy = parseBuildings('{"training":{"level":2,"upgradeEndsAtDay":null}}');
eq('u2_legacy_scoutcenter_l0', legacy.scoutcenter.level, 0);
eq('u2_legacy_training_kept', legacy.training.level, 2);
// roundtrip сериализации: 9 ключей
const state = startLevelsByStrength(86);
const round = parseBuildings(serializeBuildings(state));
eq('u2_roundtrip_keys', Object.keys(round).length, 9);
eq('u2_roundtrip_level', round.scoutcenter.level, state.scoutcenter.level);
// стартовые уровни по силе
eq('u2_start_top', startLevelsByStrength(86).scoutcenter.level, 2);
eq('u2_start_mid', startLevelsByStrength(78).scoutcenter.level, 1);
eq('u2_start_low', startLevelsByStrength(60).scoutcenter.level, 0);
// слоты: база 2 + скауты + бонус центра
eq('u2_slots_base', scoutSlotsOf(0), 2);
eq('u2_slots_staff', scoutSlotsOf(2), 6);
eq('u2_slots_center', scoutSlotsOf(0, 2), 4);
eq('u2_slots_all', scoutSlotsOf(3, 2), 10);

// ── U3: бюджеты правления (budget.ts) ──────────────────────────────────────

console.log('\n== U3: бюджеты ==');

eq('u3_migrate_transfer_40pct', migrateTransferBudget(10_000_000, 0), 4_000_000);
eq('u3_migrate_transfer_kept', migrateTransferBudget(10_000_000, 5_000_000), 5_000_000);
eq('u3_migrate_transfer_floor', migrateTransferBudget(-5_000_000, 0), 0);
eq('u3_migrate_wage_headroom', migrateWageBudget(100_000, 0), 112_001); // ceil(100000 × 1.12 в float)
eq('u3_migrate_wage_kept', migrateWageBudget(100_000, 200_000), 200_000);
eq('u3_after_sale_80pct', transferBudgetAfterSale(5_000_000, 1_000_000), 5_800_000);
eq('u3_after_buy_floor0', transferBudgetAfterBuy(1_000_000, 5_000_000), 0);
eq('u3_after_buy_ok', transferBudgetAfterBuy(5_000_000, 2_000_000), 3_000_000);
eq('u3_wage_allows_ok', wageBudgetAllows({ squadWages: 90_000, signingSalary: 10_000, wageBudget: 100_000 }), true);
eq('u3_wage_allows_5pct_slack', wageBudgetAllows({ squadWages: 95_000, signingSalary: 10_000, wageBudget: 100_000 }), true);
eq('u3_wage_blocks_over', wageBudgetAllows({ squadWages: 95_000, signingSalary: 11_000, wageBudget: 100_000 }), false);
eq('u3_season_grant_rpl_low', seasonTransferBudgetOf({
  league: 'RPL', leagueWeeks: 34, place: 16, teamCount: 16,
  prize: 0, prevBudgetLeft: 0, confidence: 10,
}), 2_601_000); // 300k × 0.85 × 34 × 0.30
check('u3_season_grant_confidence_bonus', seasonTransferBudgetOf({
  league: 'EPL', leagueWeeks: 38, place: 1, teamCount: 20,
  prize: 15_000_000, prevBudgetLeft: 0, confidence: 80,
}) > seasonTransferBudgetOf({
  league: 'EPL', leagueWeeks: 38, place: 1, teamCount: 20,
  prize: 15_000_000, prevBudgetLeft: 0, confidence: 50,
}));

// ── U4: финцель + история доверия (board.ts) ───────────────────────────────

console.log('\n== U4: финцель и история ==');

eq('u4_ft_no_debt', assignFinanceTargetOf({ balance: 3_000_000, wageRatio: 0.4 }), 'no_debt');
eq('u4_ft_wage_control', assignFinanceTargetOf({ balance: 20_000_000, wageRatio: 0.8 }), 'wage_control');
eq('u4_ft_null', assignFinanceTargetOf({ balance: 20_000_000, wageRatio: 0.4 }), null);
eq('u4_ft_priority_debt', assignFinanceTargetOf({ balance: 0, wageRatio: 0.9 }), 'no_debt');
eq('u4_on_track_no_debt', financeTargetOnTrack('no_debt', 1, 0.9), true);
eq('u4_on_track_no_debt_fail', financeTargetOnTrack('no_debt', -1, 0.1), false);
eq('u4_on_track_wage', financeTargetOnTrack('wage_control', 0, 0.6), true);
eq('u4_on_track_wage_fail', financeTargetOnTrack('wage_control', 0, 0.8), false);

// история: парсинг битого/нулевого JSON, идемпотентность, смена сезона
eq('u4_parse_null_points', parseBoardHistory(null, 1).points.length, 0);
eq('u4_parse_garbage', parseBoardHistory('{oops', 2).season, 2);
let hist = parseBoardHistory(null, 1);
hist = appendBoardPoint(hist, 1, 1, 55);
hist = appendBoardPoint(hist, 1, 2, 60);
hist = appendBoardPoint(hist, 1, 2, 62); // дубль недели — замена
eq('u4_append_idempotent', hist.points.length, 2);
eq('u4_append_replaced', hist.points[1].c, 62);
const rt = parseBoardHistory(serializeBoardHistory(hist), 1);
eq('u4_serialize_roundtrip', JSON.stringify(rt), JSON.stringify(hist));
hist = appendBoardPoint(hist, 2, 1, 50); // новый сезон — история заново
check('u4_season_reset', hist.season === 2 && hist.points.length === 1);

// ── I1: интеграция — стадион (POST /stadium) ───────────────────────────────

console.log('\n== I1: стадион (интеграция) ==');

type StateApi = {
  snapshot: {
    save: { season: number; week: number; totalWeeks: number; balance: number; transferBudget: number };
    myTeam: {
      stadiumCapacity: number; stadiumPending: number; stadiumUpgradeEndsAtDay: number | null;
      buildings: { id: string; level: number; upgradeEndsAtDay: number | null; upkeepWeekly: number }[];
    };
    board: {
      confidence: number; history: { week: number; confidence: number }[];
      financeTarget: { code: string; label: string } | null;
      transferBudget: number; wageBudget: number;
    };
    finances: {
      weeklyIncome: number; wageRatio: number; seasonIncome: number; seasonExpense: number;
      byCategory: { category: string; label: string; income: number; expense: number }[];
      records: { id: string; kind: string; category: string; amount: number }[];
      transferBudget: number; wageBudget: number; wagesActual: number;
    };
  };
};

const engine = getEngine();
const created = await engine.createCareer({
  leagueCode: 'RPL',
  clubIndex: 2,
  managerName: 'М5 Смоук',
  seed: 5555,
  now: NOW,
});
check('i1_career_created', created.slot >= 1 && created.saveId.length > 0);

const state0 = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as StateApi;
const cap0 = state0.snapshot.myTeam.stadiumCapacity;
const balance0 = state0.snapshot.save.balance;
check('i1_buildings_nine_cards', state0.snapshot.myTeam.buildings.length === 9);
const scoutCenterCard = state0.snapshot.myTeam.buildings.find((b) => b.id === 'scoutcenter');
check('i1_scoutcenter_card_exists', scoutCenterCard !== undefined);
check('i1_no_stadium_build_initial',
  state0.snapshot.myTeam.stadiumPending === 0
  && state0.snapshot.myTeam.stadiumUpgradeEndsAtDay === null);
check('i1_budget_positive', state0.snapshot.save.transferBudget > 0, `b=${state0.snapshot.save.transferBudget}`);
check('i1_wage_budget_positive', state0.snapshot.board.wageBudget > 0);
check('i1_finance_summary_fields',
  state0.snapshot.finances.wagesActual === state0.snapshot.finances.wagesActual
  && typeof state0.snapshot.finances.byCategory.length === 'number');

// happy path: блок 3000 мест
const price3000 = stadiumPriceOf(cap0, 3000);
const st1 = (await engineDispatch('POST', '/stadium', {
  saveId: created.saveId, seats: 3000,
})) as {
  ok: boolean; capacityAfter: number; pending: number;
  upgradeEndsAtDay: number; balance: number; snapshot: unknown;
};
check('i1_stadium_started',
  st1.ok && st1.pending === 3000 && st1.capacityAfter === cap0 + 3000
  && st1.upgradeEndsAtDay > 0,
  `pending=${st1.pending} endDay=${st1.upgradeEndsAtDay}`);
check('i1_stadium_paid', st1.balance === balance0 - price3000, `b=${st1.balance} price=${price3000}`);

const state1 = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as StateApi;
check('i1_stadium_state_pending',
  state1.snapshot.myTeam.stadiumPending === 3000
  && state1.snapshot.myTeam.stadiumUpgradeEndsAtDay === st1.upgradeEndsAtDay);
check('i1_stadium_finance_record',
  state1.snapshot.finances.records.some(
    (r) => r.category === 'construction' && r.amount === price3000 && r.kind === 'expense',
  ));
check('i1_stadium_construction_category',
  state1.snapshot.finances.byCategory.some((r) => r.category === 'construction' && r.expense === price3000));

// гвард: уже строится
let inProgress = false;
try {
  await engineDispatch('POST', '/stadium', { saveId: created.saveId, seats: 5000 });
} catch (e) {
  inProgress = (e as { code?: string }).code === 'STADIUM_IN_PROGRESS';
}
check('i1_stadium_guard_in_progress', inProgress);

// гвард: мусорное значение мест
let badSeats = false;
try {
  await engineDispatch('POST', '/stadium', { saveId: created.saveId, seats: 7777 });
} catch (e) {
  badSeats = (e as { code?: string }).code === 'INVALID_STADIUM_SEATS';
}
check('i1_stadium_guard_bad_seats', badSeats);

// независимость: здание строится ВО ВРЕМЯ стройки стадиона (разные бригады)
const fanshopCard = state1.snapshot.myTeam.buildings.find((b) => b.id === 'fanshop');
check('i1_fanshop_exists', fanshopCard !== undefined);
let buildingOk = true;
try {
  await engineDispatch('POST', '/buildings', { saveId: created.saveId, buildingId: 'fanshop' });
} catch (e) {
  buildingOk = false;
}
check('i1_building_during_stadium_ok', buildingOk);

// ── I2: скаут-центр — скорость роста знания ────────────────────────────────

console.log('\n== I2: скаут-центр (туман войны) ==');

// Контрольная карьера Б — СЛАБЫЙ клуб (Рубин, str 73 → скаут-центр L0).
// ВАЖНО: saveId детерминирован от сида (career.ts: rngUuid(hash(seed:ids))) —
// поэтому сид Б ОТЛИЧАЕТСЯ от А, иначе карьера Б затрёт А тем же saveId.
// Штат любого клуба = главтренер + ассистент (скаутов нет → «глаз клуба» 45).
const createdB = await engine.createCareer({
  leagueCode: 'RPL',
  clubIndex: 7, // Рубин — аутсайдер: стартовый скаут-центр L0
  managerName: 'М5 Контроль',
  seed: 5556,
  now: NOW,
});
await engineDispatch('POST', '/simulate', { saveId: createdB.saveId });

type MarketApi = { listings: { listingId: string; player: { id: string; age: number } }[] };
const marketB = (await engineDispatch('GET', '/market', {
  saveId: createdB.saveId, position: 'ALL', sort: 'ovr',
})) as MarketApi;
check('i2_market_filled', marketB.listings.length > 0, `n=${marketB.listings.length}`);
const target = marketB.listings.find((l) => l.player.age >= 25) ?? marketB.listings[0];
check('i2_target_player_found', target !== undefined);

// карьера Б: смотрим игрока (центра нет) → рост 10 + 7.25 = 17
await engineDispatch('POST', '/scout/watch', { saveId: createdB.saveId, playerId: target.player.id });
await engineDispatch('POST', '/simulate', { saveId: createdB.saveId });
type ScoutApi = { reports: { playerId: string; knowledge: number }[] };
const scoutB = (await engineDispatch('GET', '/scout', { saveId: createdB.saveId })) as ScoutApi;
const kb = scoutB.reports.find((r) => r.playerId === target.player.id)?.knowledge ?? -1;
eq('i2_knowledge_no_center', kb, 17); // round(10 + 7.25)

// карьера А (ЦСКА, str 80 → стартовый скаут-центр L1): первая неделя — рынок
// наполняется, затем смотрим СВОЕГО игрока рынка (другой сид — другой мир)
await engineDispatch('POST', '/simulate', { saveId: created.saveId });
const stateA2 = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as StateApi;
const centerCardA = stateA2.snapshot.myTeam.buildings.find((b) => b.id === 'scoutcenter');
check('i2_center_card_l1', centerCardA !== undefined && centerCardA.level >= 1, `lvl=${centerCardA?.level}`);

const marketA = (await engineDispatch('GET', '/market', {
  saveId: created.saveId, position: 'ALL', sort: 'ovr',
})) as MarketApi;
check('i2_market_filled_a', marketA.listings.length > 0, `n=${marketA.listings.length}`);
const targetA = marketA.listings.find((l) => l.player.age >= 25) ?? marketA.listings[0];
check('i2_target_a_found', targetA !== undefined);
// рост с центром L1: 10 + 7.25 × 1.06 = 17.685 → 18
await engineDispatch('POST', '/scout/watch', { saveId: created.saveId, playerId: targetA.player.id });
await engineDispatch('POST', '/simulate', { saveId: created.saveId });
const scoutA = (await engineDispatch('GET', '/scout', { saveId: created.saveId })) as ScoutApi;
const ka = scoutA.reports.find((r) => r.playerId === targetA.player.id)?.knowledge ?? -1;
eq('i2_knowledge_with_center', ka, 18);
check('i2_center_speeds_scouting', ka > kb, `with=${ka} without=${kb}`);

// ── I3: финансы недели — ТВ/статьи/агрегаты ────────────────────────────────

console.log('\n== I3: финансы ==');

const stateF = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as StateApi;
const fin = stateF.snapshot.finances;
check('i3_by_category_nonempty', fin.byCategory.length > 0, `n=${fin.byCategory.length}`);
check('i3_tv_row', fin.byCategory.some((r) => r.category === 'tv' && r.income > 0));
check('i3_wages_row', fin.byCategory.some((r) => r.category === 'wages' && r.expense > 0));
check('i3_sponsor_row', fin.byCategory.some((r) => r.category === 'sponsor' && r.income > 0));
const incomeSum = fin.byCategory.reduce((s, r) => s + r.income, 0);
const expenseSum = fin.byCategory.reduce((s, r) => s + r.expense, 0);
eq('i3_income_agg_matches', incomeSum, fin.seasonIncome);
eq('i3_expense_agg_matches', expenseSum, fin.seasonExpense);
check('i3_income_includes_tv', fin.weeklyIncome > 0);
check('i3_budget_in_summary',
  fin.transferBudget === stateF.snapshot.save.transferBudget && fin.wageBudget > 0);
check('i3_wages_actual', fin.wagesActual > 0);
// записи в журнале: ТВ-категория присутствует
check('i3_records_tv', fin.records.some((r) => r.category === 'tv'));

// ── I4: правление — история доверия, финцель ───────────────────────────────

console.log('\n== I4: правление ==');

const board = stateF.snapshot.board;
check('i4_history_growing', board.history.length >= 2, `n=${board.history.length}`);
check('i4_history_sorted', board.history.every((p, i) => i === 0 || board.history[i - 1].week < p.week));
check('i4_confidence_range', board.confidence >= 0 && board.confidence <= 100);
const boardResp = (await engineDispatch('GET', '/board', { saveId: created.saveId })) as {
  ok: boolean; board: { history: { week: number }[]; financeTarget: unknown }; news: unknown[];
};
check('i4_board_endpoint_ok', boardResp.ok && boardResp.board.history.length >= 2);

// ── I5: завершение стройки стадиона + сезонный пересбор бюджетов ──────────

console.log('\n== I5: завершение стройки и сезон ==');

// блок 3000 мест = 56 дней = 8 недель от недели покупки (куплен до 1-й симуляции)
// уже сыграно 4 недели (I2): долистываем до конца сезона
let weeks = 0;
let season = stateF.snapshot.save.season;
let totalWeeks = stateF.snapshot.save.totalWeeks;
let curWeek = stateF.snapshot.save.week;
while (season === 1 && weeks < 45) {
  const res = (await engineDispatch('POST', '/simulate', { saveId: created.saveId })) as {
    result: { season: number | null; week: number | null };
  };
  weeks += 1;
  if (typeof res.result.season === 'number' && res.result.season > season) {
    season = res.result.season;
    break;
  }
  curWeek = typeof res.result.week === 'number' ? res.result.week : curWeek + 1;
}
eq('i5_season_rollover', season, 2);

const stateS2 = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as StateApi;
const t2 = stateS2.snapshot.myTeam;
check('i5_stadium_completed',
  t2.stadiumPending === 0 && t2.stadiumUpgradeEndsAtDay === null && t2.stadiumCapacity === cap0 + 3000,
  `cap=${t2.stadiumCapacity} expected=${cap0 + 3000} pending=${t2.stadiumPending}`);
check('i5_fanshop_completed',
  (t2.buildings.find((b) => b.id === 'fanshop')?.level ?? 0) > (fanshopCard?.level ?? 0),
  'фан-шоп не вырос');
check('i5_budget_regranted', stateS2.snapshot.save.transferBudget >= 500_000, `b=${stateS2.snapshot.save.transferBudget}`);
check('i5_wage_budget_rebuilt', stateS2.snapshot.board.wageBudget > 0);
check('i5_history_new_season', stateS2.snapshot.board.history.length >= 1
  && stateS2.snapshot.board.history.every((p) => p.week <= stateS2.snapshot.save.week + 1));

await engine.removeSlot(created.slot);
await engine.removeSlot(createdB.slot);

console.log(`\nИтого: PASS=${pass} FAIL=${fail}`);
if (fail > 0) {
  console.log(`Провалены: ${failures.join(', ')}`);
  process.exit(1);
}

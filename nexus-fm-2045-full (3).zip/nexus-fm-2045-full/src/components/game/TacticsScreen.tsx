'use client';

import { useMemo, useState } from 'react';
import { Activity, CircleDot, Loader2, MousePointerClick, Save, Shield, Sparkles, Wand2 } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { ChipLabel, PlayerChip } from '@/components/game/PlayerChip';
import { PitchField } from '@/components/game/PitchField';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import {
  DEF_LINE_LABELS, MENTALITY_LABELS, PLAY_STYLE_LABELS, PRESSING_LABELS, TEMPO_LABELS,
} from '@/lib/game/types';
import {
  BENCH_MAX, DEF_LINE_ORDER, FORMATIONS, FORMATION_IDS, MENTALITY_ORDER,
  PRESSING_ORDER, TEMPO_ORDER,
} from '@/lib/game/constants';
import { effectiveLineup } from '@/lib/game/lineup';
import { autoLineup, slotScore } from '@/lib/game/players';
import { computeLines } from '@/lib/game/strength';
import type {
  DefLineLevel, FormationId, Mentality, PlayStyle, PlayerDTO, Position,
  PressingLevel, TacticPayload, TempoLevel,
} from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

type Selection = { kind: 'slot' | 'bench'; index: number } | null;

interface LocalTactic {
  formation: FormationId;
  mentality: Mentality;
  tempo: TempoLevel;
  pressing: PressingLevel;
  defLine: DefLineLevel;
  playStyle: PlayStyle;
}

/** Пересборка состава под новую формацию (по позиционной близости). */
function remapLineup(
  oldLineup: (string | null)[],
  oldBench: string[],
  formation: FormationId,
  byId: Map<string, PlayerDTO>,
): { lineup: (string | null)[]; bench: string[] } {
  const slots = FORMATIONS[formation].slots;
  const candidateIds = [
    ...oldLineup.filter((x): x is string => !!x),
    ...oldBench,
  ];
  const used = new Set<string>();

  const pickBest = (slotPos: Position, pool: string[]): string | null => {
    let best: string | null = null;
    let bestScore = -1;
    for (const id of pool) {
      if (used.has(id)) continue;
      const p = byId.get(id);
      if (!p || p.injuryWeeks > 0) continue;
      const score = slotScore(p, slotPos);
      if (score > bestScore) {
        bestScore = score;
        best = id;
      }
    }
    return best;
  };

  const lineup: (string | null)[] = slots.map((slot) => {
    const id = pickBest(slot.position, candidateIds);
    if (id) used.add(id);
    return id;
  });
  for (let i = 0; i < lineup.length; i++) {
    if (lineup[i]) continue;
    const id = pickBest(slots[i].position, Array.from(byId.keys()));
    if (id) {
      used.add(id);
      lineup[i] = id;
    }
  }

  const rest = Array.from(byId.values())
    .filter((p) => !used.has(p.id) && p.injuryWeeks === 0);
  const gk = rest.filter((p) => p.position === 'GK').sort((a, b) => b.ovr - a.ovr)[0];
  const fieldRest = rest
    .filter((p) => p !== gk)
    .sort((a, b) => b.ovr * (b.condition / 100) - a.ovr * (a.condition / 100));
  const bench = [...(gk ? [gk.id] : []), ...fieldRest.map((p) => p.id)].slice(0, BENCH_MAX);

  return { lineup, bench };
}

function LabeledSlider({
  label,
  value,
  options,
  labels,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  labels: Record<string, string>;
  onChange: (v: string) => void;
}) {
  const index = Math.max(0, options.indexOf(value));
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold">{labels[value]}</span>
      </div>
      <Slider
        value={[index]}
        min={0}
        max={options.length - 1}
        step={1}
        onValueChange={(v) => onChange(options[v[0] ?? 0] ?? options[index])}
        aria-label={label}
      />
    </div>
  );
}

/** Экран «Тактика»: поле, формация, настройки, сила состава. */
export function TacticsScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const saveTactics = useGameStore((s) => s.saveTactics);
  const loading = useGameStore((s) => s.loading);
  const { myTeam, myPlayers } = snapshot;

  const byId = useMemo(() => new Map(myPlayers.map((p) => [p.id, p])), [myPlayers]);
  const eff = useMemo(() => effectiveLineup(myTeam, myPlayers), [myTeam, myPlayers]);

  const [tactic, setTactic] = useState<LocalTactic>({
    formation: myTeam.formation,
    mentality: myTeam.mentality,
    tempo: myTeam.tempo,
    pressing: myTeam.pressing,
    defLine: myTeam.defLine,
    playStyle: myTeam.playStyle,
  });
  const [lineup, setLineup] = useState<(string | null)[]>(eff.lineup);
  const [bench, setBench] = useState<string[]>(eff.bench);
  const [selection, setSelection] = useState<Selection>(null);
  const [dirty, setDirty] = useState(false);

  // Экран монтируется заново при каждом переключении вкладки (GameShell),
  // поэтому начальное состояние всегда синхронно со свежим снапшотом.

  const lines = useMemo(
    () =>
      computeLines({
        teamId: myTeam.id,
        players: myPlayers,
        formation: tactic.formation,
        mentality: tactic.mentality,
        tempo: tactic.tempo,
        pressing: tactic.pressing,
        defLine: tactic.defLine,
        playStyle: tactic.playStyle,
        lineup,
      }),
    [myTeam.id, myPlayers, tactic, lineup],
  );

  const canSave = lineup.every((id): id is string => !!id) && dirty;

  const mutate = (fn: () => void) => {
    fn();
    setDirty(true);
  };

  const handleSlotClick = (i: number) => {
    if (!selection) {
      if (lineup[i]) setSelection({ kind: 'slot', index: i });
      return;
    }
    if (selection.kind === 'slot') {
      if (selection.index === i) {
        setSelection(null);
        return;
      }
      mutate(() => {
        const next = [...lineup];
        [next[i], next[selection.index]] = [next[selection.index], next[i]];
        setLineup(next);
      });
      setSelection(null);
      return;
    }
    const benchId = bench[selection.index];
    setSelection(null);
    if (!benchId) return;
    mutate(() => {
      const next = [...lineup];
      const displaced = next[i];
      next[i] = benchId;
      const nextBench = bench.filter((_, bi) => bi !== selection.index);
      if (displaced) nextBench.push(displaced);
      setLineup(next);
      setBench(nextBench.slice(0, BENCH_MAX));
    });
  };

  const handleBenchClick = (i: number) => {
    if (!selection) {
      if (bench[i]) setSelection({ kind: 'bench', index: i });
      return;
    }
    if (selection.kind === 'bench') {
      if (selection.index === i) {
        setSelection(null);
        return;
      }
      mutate(() => {
        const nextBench = [...bench];
        [nextBench[i], nextBench[selection.index]] = [nextBench[selection.index], nextBench[i]];
        setBench(nextBench);
      });
      setSelection(null);
      return;
    }
    const slotId = lineup[selection.index];
    const benchId = bench[i];
    setSelection(null);
    if (!slotId || !benchId) return;
    mutate(() => {
      const next = [...lineup];
      next[selection.index] = benchId;
      const nextBench = [...bench];
      nextBench[i] = slotId;
      setLineup(next);
      setBench(nextBench);
    });
  };

  const changeFormation = (f: FormationId) => {
    if (f === tactic.formation) return;
    mutate(() => {
      const remapped = remapLineup(lineup, bench, f, byId);
      setTactic((t) => ({ ...t, formation: f }));
      setLineup(remapped.lineup);
      setBench(remapped.bench);
    });
    setSelection(null);
  };

  const handleAuto = () => {
    const auto = autoLineup(myPlayers, tactic.formation);
    mutate(() => {
      setLineup(auto.lineup);
      setBench(auto.bench);
    });
    setSelection(null);
    toast.success('Автосостав выставлен по лучшему вкладу в слоты');
  };

  const handleSave = async () => {
    if (!canSave) {
      if (!lineup.every(Boolean)) toast.error('Заполните все 11 слотов состава');
      return;
    }
    const payload: TacticPayload = {
      ...tactic,
      lineup: lineup as string[],
      bench,
    };
    const ok = await saveTactics(payload);
    if (ok) setDirty(false);
  };

  const benchSlots = Array.from({ length: BENCH_MAX }, (_, i) => bench[i] ?? null);

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Тактика"
        subtitle={`${myTeam.name} · сила состава ${lines.overall}`}
        action={
          dirty ? (
            <Badge className="border border-[#FACC15]/40 bg-[#FACC15]/10 text-[#FACC15]">
              есть изменения
            </Badge>
          ) : (
            <Badge variant="secondary" className="text-muted-foreground">
              сохранено
            </Badge>
          )
        }
      />

      <section className="visual-panel rounded-2xl border border-[#7bd7ff]/25 bg-card p-4 shadow-[0_18px_50px_rgba(0,0,0,.22)] sm:p-5" style={{ backgroundImage: "url('/visuals/matchday-pitch.svg')" }}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-[#7bd7ff]"><Sparkles className="size-3.5" aria-hidden /> Matchday tactics // live board</p>
            <h1 className="mt-1 text-xl font-black">План матча <span className="text-muted-foreground">· {tactic.formation}</span></h1>
            <p className="mt-1 text-xs text-muted-foreground">Расставьте игроков на поле и соберите профиль игры под соперника.</p>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              { label: 'Атака', value: lines.attack, icon: Activity },
              { label: 'Центр', value: lines.midfield, icon: CircleDot },
              { label: 'Оборона', value: lines.defence, icon: Shield },
            ].map(({ label, value, icon: Icon }) => (
              <div key={label} className="rounded-lg border border-border/60 bg-background/60 px-3 py-2"><Icon className="mx-auto mb-1 size-3.5 text-primary" aria-hidden /><div className="tabular text-sm font-bold">{value}</div><div className="text-[9px] uppercase tracking-wide text-muted-foreground">{label}</div></div>
            ))}
          </div>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,440px)_1fr]">
        {/* Поле + скамейка */}
        <div className="space-y-3">
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <MousePointerClick className="size-3.5 text-primary" aria-hidden />
            Клик по игроку, затем клик по другому слоту или скамейке — обмен местами
          </p>
          <PitchField
            formation={tactic.formation}
            lineup={lineup}
            byId={byId}
            selectedSlot={selection?.kind === 'slot' ? selection.index : null}
            onSlotClick={handleSlotClick}
          />

          {/* Скамейка */}
          <div className="rounded-lg border border-border/70 bg-card p-3">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-muted-foreground">
                Скамейка ({bench.length}/{BENCH_MAX})
              </span>
              {selection?.kind === 'bench' ? (
                <span className="text-[10px] text-primary">выбран игрок — кликните по слоту</span>
              ) : null}
            </div>
            <div className="flex flex-wrap gap-3">
              {benchSlots.map((id, i) => {
                const p = id ? byId.get(id) ?? null : null;
                return (
                  <div key={i} className="flex w-16 flex-col items-center">
                    <PlayerChip
                      player={p}
                      slotPosition={p?.position ?? 'MC'}
                      selected={selection?.kind === 'bench' && selection.index === i}
                      onClick={() => handleBenchClick(i)}
                    />
                    <ChipLabel player={p} slotPosition={p?.position ?? 'MC'} className="max-w-16" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Настройки */}
        <div className="space-y-4">
          <Card className="border-border/70">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Формация</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Select value={tactic.formation} onValueChange={(v) => changeFormation(v as FormationId)}>
                <SelectTrigger className="min-h-11 w-full" aria-label="Формация">
                  <SelectValue placeholder="Формация" />
                </SelectTrigger>
                <SelectContent>
                  {FORMATION_IDS.map((f) => (
                    <SelectItem key={f} value={f} className="min-h-10">
                      <span className="font-semibold">{f}</span>
                      <span className="ml-2 text-xs text-muted-foreground">
                        {FORMATIONS[f].hint}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">{FORMATIONS[tactic.formation].hint}</p>
            </CardContent>
          </Card>

          <Card className="border-border/70">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Настройки игры</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <LabeledSlider
                label="Менталитет"
                value={tactic.mentality}
                options={MENTALITY_ORDER}
                labels={MENTALITY_LABELS}
                onChange={(v) => mutate(() => setTactic((t) => ({ ...t, mentality: v as Mentality })))}
              />
              <LabeledSlider
                label="Темп"
                value={tactic.tempo}
                options={TEMPO_ORDER}
                labels={TEMPO_LABELS}
                onChange={(v) => mutate(() => setTactic((t) => ({ ...t, tempo: v as TempoLevel })))}
              />
              <LabeledSlider
                label="Прессинг"
                value={tactic.pressing}
                options={PRESSING_ORDER}
                labels={PRESSING_LABELS}
                onChange={(v) => mutate(() => setTactic((t) => ({ ...t, pressing: v as PressingLevel })))}
              />
              <LabeledSlider
                label="Линия обороны"
                value={tactic.defLine}
                options={DEF_LINE_ORDER}
                labels={DEF_LINE_LABELS}
                onChange={(v) => mutate(() => setTactic((t) => ({ ...t, defLine: v as DefLineLevel })))}
              />
              <div>
                <p className="mb-1.5 text-xs text-muted-foreground">Стиль игры</p>
                <ToggleGroup
                  type="single"
                  variant="outline"
                  value={tactic.playStyle}
                  onValueChange={(v) =>
                    v && mutate(() => setTactic((t) => ({ ...t, playStyle: v as PlayStyle })))
                  }
                  className="flex-wrap justify-start"
                >
                  {(Object.keys(PLAY_STYLE_LABELS) as PlayStyle[]).map((s) => (
                    <ToggleGroupItem key={s} value={s} className="min-h-9 px-3 text-xs">
                      {PLAY_STYLE_LABELS[s]}
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/70">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-1.5 text-sm">
                <CircleDot className="size-3.5 text-primary" aria-hidden />
                Сила состава
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(
                [
                  ['Атака', lines.attack],
                  ['Центр поля', lines.midfield],
                  ['Оборона', lines.defence],
                ] as const
              ).map(([label, value]) => (
                <div key={label}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="tabular font-semibold">{Math.round(value)}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
                    />
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between rounded-md bg-secondary/60 p-2.5">
                <span className="text-xs text-muted-foreground">Общая сила</span>
                <span className="text-lg font-bold tabular text-primary">{lines.overall}</span>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button variant="secondary" className="min-h-11 flex-1" onClick={handleAuto}>
              <Wand2 className="size-4" aria-hidden />
              Автосостав
            </Button>
            <Button
              className={cn('min-h-11 flex-1', !dirty && 'opacity-60')}
              onClick={() => void handleSave()}
              disabled={loading || !canSave}
              title={!canSave ? 'Нет изменений или состав неполный' : undefined}
            >
              {loading ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Save className="size-4" aria-hidden />
              )}
              Сохранить
              {dirty ? <span className="ml-0.5 size-1.5 rounded-full bg-[#FACC15]" aria-hidden /> : null}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

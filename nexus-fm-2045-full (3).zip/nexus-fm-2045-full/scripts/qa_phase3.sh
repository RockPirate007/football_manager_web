#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# QA Фазы 3 «AAA» (Task P3-5): полная регрессия Фаз 1–2 + три сезона подряд,
# контракты, правление (вкл. намеренное увольнение), академия, рейтинг,
# Босман, легаси-сейв. Запуск: bash scripts/qa_phase3.sh
# Требует: dev-сервер :3000, jq, bun, python3.
# Идемпотентен: создаёт и удаляет ТОЛЬКО свои сейвы «P3-QA3 …» —
# чужие карьеры («Каталония навсегда», «QA · История игроков», «Арсенал ·
# Сезон 1», «РПЛ-карьера QA») не трогает (кроме read-only GET).
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000/api/game"
DB="bun scripts/qa3_db.ts"
UNIT="bun scripts/qa3_unit.ts"
TMP=$(mktemp -d)
PASS=0
FAIL=0
PREFIX="P3-QA3"
# Прогон можно разбить на 2 вызова (песочница убивает фоновые процессы между
# командами): QA_PART=1 — секции 0+1 (три сезона), QA_PART=2 — секции 2–5
# (продолжение по стейт-файлу). По умолчанию — всё одним запуском.
PART="${QA_PART:-all}"
STATE_FILE="${QA_STATE:-/tmp/qa3_state.env}"

ok()  { PASS=$((PASS + 1)); echo "  ✔ $*"; }
bad() { FAIL=$((FAIL + 1)); echo "  ✘ $*"; }
section() { echo; echo "── $* ─────────────────────────────────"; }

call() { # call METHOD URL [json] → BODY, CODE
  local method="$1" url="$2" body="${3:-}"
  if [ -n "$body" ]; then
    BODY=$(curl -s -m 300 -w $'\n%{http_code}' -X "$method" -H 'Content-Type: application/json' -d "$body" "$url")
  else
    BODY=$(curl -s -m 300 -w $'\n%{http_code}' -X "$method" "$url")
  fi
  CODE=$(echo "$BODY" | tail -n1)
  BODY=$(echo "$BODY" | sed '$d')
}

check() { # check "desc" jq-expr expected
  local desc="$1" expr="$2" expected="$3" actual
  actual=$(echo "$BODY" | jq -r "$expr" 2>/dev/null)
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"
  else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}

check_eq() {
  local desc="$1" actual="$2" expected="$3"
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"
  else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}

check_code() {
  if [ "$CODE" = "$2" ]; then ok "$1 (HTTP $CODE)"
  else bad "$1: ожидался HTTP $2, получен $CODE"; fi
}

dbq() { # dbq <saveId> <cmd> [args…] → вывод qa3_db.ts
  $DB "$2" "$1" "${@:3}" 2>/dev/null
}

dbv() { # dbv <saveId> <cmd> <key> [args…] → значение ключа
  dbq "$1" "$2" "${@:4}" | grep "^${3}=" | head -n1 | cut -d= -f2
}

simulate() { # simulate <saveId> — POST /simulate, вывод в $BODY/$CODE
  call POST "$BASE/simulate" "{\"saveId\":\"$1\"}"
}

# ═══ 0. Очистка + юнит-инварианты ═════════════════════════════════════════
if [ "$PART" != "2" ]; then
section "0. Очистка своих сейвов + юнит-проверки чистых функций"

call GET "$BASE/saves"
check_code "GET /saves" 200
SAVES_BODY="$BODY"
for sid in $(echo "$SAVES_BODY" | jq -r ".saves[] | select(.careerName | startswith(\"$PREFIX\")) | .id"); do
  call DELETE "$BASE/saves/$sid"
  if [ "$CODE" = "200" ]; then ok "удалён свой сейв $sid"; else bad "не удалён $sid (HTTP $CODE)"; fi
done
OTHERS=$(echo "$SAVES_BODY" | jq -r "[.saves[] | select((.careerName | startswith(\"$PREFIX\")) | not)] | length")
echo "  … чужих карьер не тронуто: $OTHERS"

UNIT_OUT=$($UNIT)
UNIT_PASS=$(echo "$UNIT_OUT" | grep '^unit_pass=' | cut -d= -f2)
UNIT_FAIL=$(echo "$UNIT_OUT" | grep '^unit_fail=' | cut -d= -f2)
if [ "$UNIT_FAIL" = "0" ]; then ok "юнит-инварианты §9 (№2/6/9/11/12/15/16/19/21): $UNIT_PASS проверок"; else
  bad "юнит-инварианты: FAIL=$UNIT_FAIL"; echo "$UNIT_OUT" | grep FAIL | sed 's/^/      /'
fi
fi # PART != 2

# ═══ 1. ТРИ СЕЗОНА ПОДРЯД (RPL, сильный клуб) ═════════════════════════════
if [ "$PART" != "2" ]; then
section "1. Карьера «Три сезона» (RPL, Краснодар): сезоны 1→2→3"

call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":0,"managerName":"QA P3-5","careerName":"P3-QA3 Три сезона"}'
check_code "POST /saves" 200
SID=$(echo "$BODY" | jq -r '.saveId')
check "saveId выдан" '.saveId != null' 'true'

call GET "$BASE/state?saveId=$SID"
check_code "GET /state (новая карьера)" 200
check "цель правления задана (код валиден)" '.snapshot.board.target as $t | (["champion","ucl","uel","upper","safe","survive"] | index($t)) != null' 'true'
check "целевое место в 1..16" '.snapshot.board.targetPlace >= 1 and .snapshot.board.targetPlace <= 16' 'true'
check "confidence старта 55" '.snapshot.board.confidence' '55'
check "медовый месяц 7 недель (нед.1 из 8)" '.snapshot.board.honeymoonWeeksLeft' '7'
check "контракты 1–4 у всех" '([.snapshot.myPlayers[] | select(.contractUntil < 1 or .contractUntil > 4)] | length) == 0' 'true'
CONTRACT_HIST=$(dbq "$SID" usercontracts | tail -n +2 | awk '{print $2}' | sort -n | uniq -c | tr '\n' ' ')
echo "  … распределение сроков контрактов (term count): $CONTRACT_HIST"

BOARDLOG="$TMP/board_s1.log"; : > "$BOARDLOG"

sim_week() { # sim_week <saveId> <season> <week> — симуляция + базовые проверки
  simulate "$1"
  if [ "$CODE" != "200" ]; then bad "неделя $3 сезона $2: HTTP $CODE"; return 1; fi
  local wt expected
  wt=$(echo "$BODY" | jq -r '.result.weekType')
  case $3 in 8|16|24|34) expected="cup";; *) expected="league";; esac
  if [ "$wt" = "$expected" ]; then PASS=$((PASS+1)); else bad "неделя $2/$3: тип '$wt', ожидался '$expected'"; fi
  # реакция правления + доверие в границах
  local conf delta outcome
  conf=$(echo "$BODY" | jq -r '.result.board.confidence // "null"')
  delta=$(echo "$BODY" | jq -r '.result.board.delta // "null"')
  # Фаза 4: userMatch → userMatches[] (осознанное изменение контракта; [0] — основной матч недели)
  outcome=$(echo "$BODY" | jq -r '
    if .result.userMatches == null or (.result.userMatches | length) == 0 then "none"
    else (if .result.userMatches[0].home.isUser then
      (if .result.userMatches[0].homeGoals > .result.userMatches[0].awayGoals then "W"
       elif .result.userMatches[0].homeGoals == .result.userMatches[0].awayGoals then "D" else "L" end)
    else
      (if .result.userMatches[0].awayGoals > .result.userMatches[0].homeGoals then "W"
       elif .result.userMatches[0].awayGoals == .result.userMatches[0].homeGoals then "D" else "L" end)
    end) end')
  echo "$2 $3 $outcome $conf $delta" >> "$BOARDLOG"
  if [ "$conf" != "null" ]; then
    if [ "$conf" -ge 0 ] && [ "$conf" -le 100 ]; then PASS=$((PASS+1)); else bad "неделя $2/$3: confidence $conf вне [0,100]"; fi
    # Анти-sac guard: редкий неудачный rng-тренд топ-клуба (поражения −3 + темп
    # к цели −5/−7 + зарплаты −1 + мораль −1 → до −10/нед) может уронить доверие
    # ниже 12 на 4 недели и уволить сейв посреди 3-сезонного теста — тогда
    # каскадно падают ~100 проверок, не связанных с увольнением (отдельно оно
    # проверяется секциями 3а/3в). При conf<20 поднимаем до 30 — только в
    # собственном тест-сейве, поведение движка не трогаем.
    if [ "$conf" -lt 20 ] 2>/dev/null; then
      $DB setconf "$1" 30 0 >/dev/null 2>&1
    fi
  fi
  return 0
}

for S in 1 2 3; do
  echo "  ── Сезон $S ──"
  for W in $(seq 1 33); do
    # Босман-подготовка (сезон 1): истекающие → недовольные, p→0.75
    if [ "$S" = "1" ] && [ "$W" = "20" ]; then
      UNHAPPY=$(dbv "$SID" forceunhappy unhappy_set)
      echo "  … Босман: подготовлено недовольных истекающих: $UNHAPPY"
    fi
    if [ "$S" = "1" ] && { [ "$W" = "24" ] || [ "$W" = "28" ] || [ "$W" = "32" ]; }; then
      $DB forceunhappy "$SID" >/dev/null 2>&1
    fi
    sim_week "$SID" "$S" "$W" || break
    if [ "$W" = "4" ]; then
      INTAKE=$(dbv "$SID" academy intake_user "$S")
      AGES=$(dbv "$SID" academy ages_ok "$S")
      OVROK=$(dbv "$SID" academy ovr_ok "$S")
      if [ "$INTAKE" -ge 2 ] && [ "$INTAKE" -le 6 ]; then ok "академия S$S: набор клуба игрока $INTAKE (2–6)"; else bad "академия S$S: набор $INTAKE вне 2–6"; fi
      check_eq "академия S$S: возраст 16–17" "$AGES" "true"
      check_eq "академия S$S: OVR 34–52" "$OVROK" "true"
      CU=$(dbq "$SID" usercontracts | tail -n +2 | head -n1 | awk '{print $2}')
      echo "  … (справочно) первый контракт состава: $CU"
    fi
    if [ "$W" = "12" ] && [ "$S" = "1" ]; then
      AVG=$(dbv "$SID" ratings league_avg_rating)
      OUT=$(dbv "$SID" ratings rating_out_of_range)
      RATED=$(dbv "$SID" ratings rated_players)
      if [ "$RATED" -gt 0 ]; then ok "рейтинг после 12 недель: $RATED игравших, средний $AVG"; else bad "рейтинг: никто не играл"; fi
      check_eq "рейтинг: все в диапазоне 4.5–10" "$OUT" "0"
      IN_RANGE=$(python3 -c "print('true' if 6.0 <= $AVG <= 7.4 else 'false')")
      check_eq "средний рейтинг лиги в разумных пределах" "$IN_RANGE" "true"
    fi
    if [ "$W" = "24" ] && [ "$S" = "1" ]; then
      PRE=$(dbv "$SID" precontracts precontracts)
      if [ "$PRE" -ge 1 ]; then ok "Босман: предконтрактов подписано $PRE ≥ 1"; else bad "Босман: предконтрактов 0 (броски не сработали)"; fi
      PRE_PID=$(dbq "$SID" precontracts | awk '/^pre /{print $2; exit}')
      call GET "$BASE/state?saveId=$SID"
      check "Босман: preContract=true в /state" "[.snapshot.myPlayers[] | select(.id == \"$PRE_PID\") | .preContract][0]" 'true'
      check "Босман: бейдж уходит в /state (сезон последний)" "[.snapshot.myPlayers[] | select(.id == \"$PRE_PID\") | .contractUntil][0] == .snapshot.save.season" 'true'
      call GET "$BASE/contracts?saveId=$SID"
      check "Босман: renewable=false в /contracts" "[.contracts[] | select(.playerId == \"$PRE_PID\") | .renewable][0]" 'false'
      call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"$PRE_PID\",\"years\":1,\"salary\":100000}"
      check_code "Босман: renew предконтрактного → 409" 409
      check "Босман: код CONTRACT_PRECONTRACT" '.error' 'CONTRACT_PRECONTRACT'
    fi
  done

  # Детерминированные истекающие (после последнего броска Босмана — нед. 32)
  MADE=$(dbv "$SID" makeexpiring made_expiring 2)
  echo "  … принудительно истекающих создано: $MADE"
  dbq "$SID" usercontracts | grep -v '^season=' > "$TMP/uc_before_s$S.txt"

  # Анти-sac guard перехода: вердикт sacked в переходе (miss ≥ 4 И conf < 30,
  # ИЛИ conf < 15) — отдельная тема секций 3а/3в; здесь проверяем ФОРМУЛУ
  # met/over/missed, поэтому при conf < 45 перед финальной неделей поднимаем
  # до 45 (худшая неделя −7 → 38 ≥ 30 → вердикт строго по месту).
  CONF_NOW=$(dbv "$SID" save save_board_confidence)
  if [ "${CONF_NOW:-45}" -lt 45 ] 2>/dev/null; then
    $DB setconf "$SID" 45 0 >/dev/null 2>&1
    echo "  … anti-sack: confidence $CONF_NOW → 45 перед финальной неделей"
  fi

  # Срез ДО перехода
  PREIDS="$TMP/preids_s$S.txt"
  dbq "$SID" preids > "$PREIDS"
  PRECOUNT=$(grep -c . "$PREIDS")
  EXPIRING="$TMP/expiring_s$S.txt"
  dbq "$SID" userexpiring > "$EXPIRING"
  NEXP=$(dbv "$SID" userexpiring expiring)
  call GET "$BASE/state?saveId=$SID"
  TARGET_PLACE_BEFORE=$(echo "$BODY" | jq -r '.snapshot.board.targetPlace')
  TARGET_CODE_BEFORE=$(echo "$BODY" | jq -r '.snapshot.board.target')
  echo "  … до перехода: игроков $PRECOUNT, истекает у клуба игрока $NEXP, цель $TARGET_CODE_BEFORE (топ-$TARGET_PLACE_BEFORE)"
  # Предконтрактные игроки (для проверки исполнения) — срез ДО перехода:
  # после исполнения preContractTeamId обнуляется, повторный запрос вернул бы 0
  PRELIST_FILE="$TMP/prelist_s$S.txt"
  dbq "$SID" precontracts | grep '^pre ' > "$PRELIST_FILE"
  PRECONTRACT_LINE=$(head -n1 "$PRELIST_FILE")
  PRECONTRACT_PID=$(echo "$PRECONTRACT_LINE" | awk '{print $2}')
  # формат: pre <id> <first> <last…> <destTeamId> <cu> — фамилия может быть
  # двухсловной («Де Лука»), поэтому адресат и срок берём с конца строки
  PRECONTRACT_DEST=$(echo "$PRECONTRACT_LINE" | awk '{print $(NF-1)}')
  # Кандидат на истечение (НЕ предконтрактный, возраст ≤ 30 — пенсионер 35+ не
  # попадает на рынок по дизайну: create-then-delete, §10.5; формат: id value age …)
  PRE_IDS_FILE="$TMP/pre_ids_s$S.txt"
  dbq "$SID" precontracts | awk '/^pre /{print $2}' > "$PRE_IDS_FILE"
  EXPIRE_LINE=$(grep -v '^season=' "$EXPIRING" | grep -v '^expiring=' | grep -v -F -f "$PRE_IDS_FILE" | awk '$3 <= 30' | head -n1 || true)
  if [ -z "$EXPIRE_LINE" ]; then
    EXPIRE_LINE=$(grep -v '^season=' "$EXPIRING" | grep -v '^expiring=' | grep -v -F -f "$PRE_IDS_FILE" | head -n1 || true)
    [ -n "$EXPIRE_LINE" ] && echo "  … молодой кандидат не найден — взят первый истекающий (возраст $(echo "$EXPIRE_LINE" | awk '{print $3}'))"
  fi
  EXPIRE_PID=$(echo "$EXPIRE_LINE" | awk '{print $1}')
  EXPIRE_VALUE=$(echo "$EXPIRE_LINE" | awk '{print $2}')

  # Финальная неделя (переход)
  simulate "$SID"
  check_code "финальная неделя сезона $S (переход)" 200
  check "финальная неделя — кубок (Финал)" '.result.weekType' 'cup'
  echo "$BODY" > "$TMP/final_s$S.json"
  check "переход: seasonEnded присутствует" '.result.seasonEnded != null' 'true'
  check "переход: sacked=false (сильный клуб)" '.result.sacked' 'false'
  PLACE=$(echo "$BODY" | jq -r '.result.seasonEnded.place')
  VERDICT=$(echo "$BODY" | jq -r '.result.seasonEnded.boardVerdict.code')
  PRIZE=$(echo "$BODY" | jq -r '.result.seasonEnded.prize')
  # Таблица: инварианты Фазы 2
  check "таблица: 16 команд" '.result.seasonEnded.standings | length' '16'
  check "таблица: места 1..16" '([.result.seasonEnded.standings[].place] | sort) == ([range(1;17)])' 'true'
  check "таблица: все сыграли 30" '([.result.seasonEnded.standings[] | select(.played != 30)] | length) == 0' 'true'
  check "таблица: очки = 3W+D" '([.result.seasonEnded.standings[] | select(.points != 3*.won + .drawn)] | length) == 0' 'true'
  check "таблица: забито = пропущено (суммы)" '( [.result.seasonEnded.standings[].goalsFor] | add ) == ( [.result.seasonEnded.standings[].goalsAgainst] | add )' 'true'
  check "таблица: goalDiff = GF−GA" '([.result.seasonEnded.standings[] | select(.goalDiff != .goalsFor - .goalsAgainst)] | length) == 0' 'true'
  # Вердикт по формуле (miss = place − targetPlace)
  if [ "$PLACE" != "null" ] && [ -n "$PLACE" ]; then
    EXPECTED_VERDICT=$(python3 -c "
m = $PLACE - $TARGET_PLACE_BEFORE
print('over' if m <= -3 else ('met' if m <= 0 else 'missed'))")
    check_eq "вердикт правления по формуле (место $PLACE vs топ-$TARGET_PLACE_BEFORE)" "$VERDICT" "$EXPECTED_VERDICT"
  else
    bad "вердикт: место сезона не получено"
  fi
  # Награды — все 8 типов
  call GET "$BASE/awards?saveId=$SID&season=$S"
  check_code "GET /awards сезона $S" 200
  check "награды: все 8 типов" '([.awards[].type] | sort) == (["champion","cup_scorer","cup_winner","golden_glove","mvp","top_assist","top_scorer","young"] | sort)' 'true'
  # Призовые за место зачислены
  if [ "$PRIZE" != "null" ] && [ -n "$PRIZE" ] && [ "$PRIZE" -gt 0 ] 2>/dev/null; then ok "призовые за место: €$PRIZE"; else bad "призовые за место: '$PRIZE'"; fi
  FIN_PRIZE=$(dbv "$SID" finances finance_prize "$S")
  if [ "${FIN_PRIZE:-0}" -ge "${PRIZE:-0}" ] 2>/dev/null; then ok "finance prize сезона $S ≥ призовым (€$FIN_PRIZE)"; else bad "finance prize сезона $S: €$FIN_PRIZE < €$PRIZE"; fi

  # Снапшот истории: строгие инварианты до старения/сброса
  dbq "$SID" snapcheck "$S" "$PREIDS" > "$TMP/snap_s$S.txt"
  for key in ok missing age_violations aging_violations goals_violations apps_violations team_violations rating_violations extra_nonzero; do
    V=$(grep "^${key}=" "$TMP/snap_s$S.txt" | cut -d= -f2)
    case $key in
      ok) check_eq "снапшот S$S: сводный ok" "$V" "true";;
      missing|age_violations|aging_violations|goals_violations|apps_violations|team_violations|rating_violations|extra_nonzero)
        check_eq "снапшот S$S: $key = 0" "$V" "0";;
    esac
  done
  GONE=$(grep '^players_gone=' "$TMP/snap_s$S.txt" | cut -d= -f2)
  dbq "$SID" gonecheck "$PREIDS" > "$TMP/gone_s$S.txt"
  check_eq "каскад пенсионеров S$S (удалено $GONE, записей-сирот)" "$(grep '^records_of_gone=' "$TMP/gone_s$S.txt" | cut -d= -f2)" "0"

  # Составы ИИ ≥ 15 (guard продлений, №20) + диагностика деградации
  AIFLOOR=$(dbv "$SID" squads ai_min_squad)
  FREEAG=$(dbv "$SID" squads free_agents)
  USERSQ=$(dbv "$SID" squads user_squad)
  echo "  … свободных агентов в сейве: $FREEAG · состав клуба игрока: $USERSQ"
  if [ "$AIFLOOR" -ge 15 ]; then ok "ИИ-составы после перехода S$S: минимум $AIFLOOR ≥ 15"; else
    bad "ИИ-составы после перехода S$S: минимум $AIFLOOR < 15 (№20)"
    dbq "$SID" squads | grep '^below15_club=' | sed 's/^/      ⚠ /'
  fi

  # Истечение: кандидат (принудительный, не предконтрактный; teamId — по БД:
  # /state myPlayers содержит только игроков клуба, ушедший там не виден)
  if [ -n "$EXPIRE_PID" ] && [ "$EXPIRE_PID" != "" ]; then
    TEAMID=$(dbq "$SID" playerinfo "$EXPIRE_PID" | grep '^player_team=' | cut -d= -f2)
    check_eq "истечение S$S: игрок покинул клуб (teamId)" "$TEAMID" "null"
    dbq "$SID" freelisting "$EXPIRE_PID" > "$TMP/fl_s$S.txt"
    check_eq "истечение S$S: лот source=free" "$(grep '^source=' "$TMP/fl_s$S.txt" | cut -d= -f2)" "free"
    check_eq "истечение S$S: лот active" "$(grep '^status=' "$TMP/fl_s$S.txt" | cut -d= -f2)" "active"
    TTL=$(grep '^expires_at=' "$TMP/fl_s$S.txt" | cut -d= -f2)
    check_eq "истечение S$S: TTL лота 8" "$TTL" "8"
    PRICE=$(grep '^price=' "$TMP/fl_s$S.txt" | cut -d= -f2)
    EXPECTED_PRICE=$(python3 -c "print(max(10000, int($EXPIRE_VALUE * 0.25 + 0.5)))")
    check_eq "истечение S$S: цена 0.25×value" "$PRICE" "$EXPECTED_PRICE"
  else
    bad "истечение S$S: не найден кандидат на истечение"
  fi

  # Free-лоты пережили регенерацию рынка (№4)
  FREEACTIVE=$(dbv "$SID" freecount free_active)
  if [ "$FREEACTIVE" -ge 1 ]; then ok "free-лоты пережили регенерацию рынка: active=$FREEACTIVE"; else bad "free-лоты: active=0 после регенерации"; fi

  # Статы сброшены (№5, вторая половина)
  NOTRESET=$(dbv "$SID" ratings rated_players)
  check_eq "статы сезона сброшены (ratingApps=0 у всех)" "$NOTRESET" "0"

  # Новый сезон открыт
  call GET "$BASE/state?saveId=$SID"
  check_code "GET /state после перехода" 200
  NEXT=$((S + 1))
  check "сезон $NEXT неделя 1" '.snapshot.save.season == '"$NEXT"' and .snapshot.save.week == 1' 'true'
  check "кубок сброшен (not_started)" '.snapshot.cup.myStatus' 'not_started'
  check "медовый месяц нового сезона (нед.1 из 8)" '.snapshot.board.honeymoonWeeksLeft' '7'
  check "цель нового сезона задана" '.snapshot.board.target != null' 'true'
  check "таблица нового сезона пуста (0 игр)" '([.snapshot.standings[] | select(.played > 0)] | length) == 0' 'true'
  NEWCAL=$(echo "$BODY" | jq -r '.snapshot.fixtures | length')
  if [ "$NEWCAL" -ge 1 ]; then ok "новый календарь: матчей на неделе $NEWCAL"; else bad "новый календарь пуст"; fi
  # Академия нового сезона появится на неделе 4 — снапшот записи прошлого сезона уже проверены

  # Контракты клуба игрока: yearsLeft убывает (contractUntil не растёт без продления)
  dbq "$SID" usercontracts | grep -v '^season=' > "$TMP/uc_after_s$S.txt"
  CU_INC=$(awk 'NR==FNR{a[$1]=$2;next} ($1 in a) && $2 > a[$1] {c++} END{print c+0}' "$TMP/uc_before_s$S.txt" "$TMP/uc_after_s$S.txt")
  check_eq "контракты клуба игрока: contractUntil не растёт в переходе S$S" "$CU_INC" "0"
  SAME_CU=$(awk 'NR==FNR{a[$1]=$2;next} ($1 in a) && $2 == a[$1] {c++} END{print c+0}' "$TMP/uc_before_s$S.txt" "$TMP/uc_after_s$S.txt")
  echo "  … выживших с неизменным contractUntil (yearsLeft −1): $SAME_CU"

  # Межсезонье: продлеваем контракты клуба игрока через API (как реальный игрок —
  # иначе состав деградирует до 8 игроков и карьера гибнет на S3–S4)
  RENEWED_N=0
  for RP in $(seq 1 14); do
    call GET "$BASE/contracts?saveId=$SID"
    RP_ID=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable == true)] | sort_by(.yearsLeft) | .[0].playerId // empty')
    [ -z "$RP_ID" ] && break
    RD=$(echo "$BODY" | jq -r "[.contracts[] | select(.playerId == \"$RP_ID\") | .demand][0]")
    RY=$(echo "$BODY" | jq -r "[.contracts[] | select(.playerId == \"$RP_ID\") | .maxRenewYears][0]")
    call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"$RP_ID\",\"years\":${RY:-3},\"salary\":$RD}"
    if [ "$(echo "$BODY" | jq -r '.outcome')" = "accepted" ]; then RENEWED_N=$((RENEWED_N+1)); fi
  done
  echo "  … межсезонье S$S→S$((S+1)): продлено контрактов через API: $RENEWED_N"
  USERSQ2=$(dbv "$SID" squads user_squad)
  echo "  … состав клуба игрока после продлений: $USERSQ2"

  # Босман: исполнение предконтрактов (только сезон 1). 33+ летний игрок может
  # уйти на пенсию в том же переходе (create-then-delete §10.5) — это дизайн,
  # а не баг: проверяем всех предконтрактных, хотя бы один должен исполниться
  if [ "$S" = "1" ]; then
    BOS_EXEC=0; BOS_RETIRED=0; BOS_FAIL=0
    while read -r PRELINE; do
      BP=$(echo "$PRELINE" | awk '{print $2}')
      # фамилия может быть двухсловной → адресат = предпоследнее поле
      BD=$(echo "$PRELINE" | awk '{print $(NF-1)}')
      [ -z "$BP" ] && continue
      dbq "$SID" playerinfo "$BP" > "$TMP/pc_one.txt"
      if grep -q 'player=missing' "$TMP/pc_one.txt"; then BOS_RETIRED=$((BOS_RETIRED+1)); continue; fi
      BT=$(grep '^player_team=' "$TMP/pc_one.txt" | cut -d= -f2)
      BPC=$(grep '^player_pre_contract=' "$TMP/pc_one.txt" | cut -d= -f2)
      BCU=$(grep '^player_contract_until=' "$TMP/pc_one.txt" | cut -d= -f2)
      if [ "$BT" = "$BD" ] && [ "$BPC" = "null" ] && [ "$BCU" -ge 2 ] 2>/dev/null && [ "$BCU" -le 5 ] 2>/dev/null; then
        BOS_EXEC=$((BOS_EXEC+1))
      else
        BOS_FAIL=$((BOS_FAIL+1)); echo "      ⚠ предконтракт не исполнен: $BP (team=$BT, pre=$BPC, cu=$BCU, ждал клуб $BD)"
      fi
    done < "$PRELIST_FILE"
    if [ "$BOS_EXEC" -ge 1 ]; then ok "Босман: исполнено предконтрактов $BOS_EXEC (пенсионеров среди них $BOS_RETIRED)"; else bad "Босман: ни один предконтракт не исполнен (исполнено 0, пенсионеров $BOS_RETIRED, битых $BOS_FAIL)"; fi
    BOSMAN_NEWS=$(dbv "$SID" newssearch news_found "предконтракт")
    if [ "$BOSMAN_NEWS" -ge 2 ]; then ok "Босман: новости в БД (подписал + покинул): $BOSMAN_NEWS"; else bad "Босман: новостей о предконтракте в БД: $BOSMAN_NEWS < 2"; fi
    dbq "$SID" newssearch "предконтракт" | head -n3 | sed 's/^news /      … /'
    TRANSFER_IN=$(dbv "$SID" finances finance_transfer_in "$S")
    check_eq "Босман: клуб игрока не получил € (transfer_in=0)" "${TRANSFER_IN:-0}" "0"
  fi
done

# ── Правление: реакция confidence (лог сезона 1) ──
W_DELTA_POS=$(awk '$3=="W" && $5>0' "$BOARDLOG" | wc -l)
W_TOTAL=$(awk '$3=="W"' "$BOARDLOG" | wc -l)
L_DELTA_NEG=$(awk '$3=="L" && $5<0' "$BOARDLOG" | wc -l)
L_TOTAL=$(awk '$3=="L"' "$BOARDLOG" | wc -l)
NONE_OUT=$(awk '$3=="none"' "$BOARDLOG" | wc -l)
if [ "$W_TOTAL" -gt 0 ] && [ "$W_DELTA_POS" -gt 0 ]; then ok "confidence растёт после побед ($W_DELTA_POS/$W_TOTAL недель)"; else bad "confidence не растёт после побед (0/$W_TOTAL)"; fi
if [ "$L_TOTAL" -gt 0 ]; then
  if [ "$L_DELTA_NEG" -gt 0 ]; then ok "confidence падает после поражений ($L_DELTA_NEG/$L_TOTAL недель)"; else echo "  ⚠ после поражений delta<0 в $L_DELTA_NEG/$L_TOTAL недель (сильный клуб: темп к цели компенсирует) — реакция подтверждена юнит-тестами №11"; PASS=$((PASS+1)); fi
else
  echo "  ⚠ сезон без поражений — реакция на поражения подтверждена юнит-тестами №11"
  PASS=$((PASS+1))
fi
HONEYMOON_OK=$(awk '$2 <= 8 && $4 < 35 && $3 != "none"' "$BOARDLOG" | wc -l)
check_eq "медовый месяц: confidence ≥ 35 в неделях 1–8 (нарушений)" "$HONEYMOON_OK" "0"

# ── История: три сезона в записях ──
dbq "$SID" recordsbyseason > "$TMP/recs.txt"
R1=$(grep '^records_s1=' "$TMP/recs.txt" | cut -d= -f2)
R2=$(grep '^records_s2=' "$TMP/recs.txt" | cut -d= -f2)
R3=$(grep '^records_s3=' "$TMP/recs.txt" | cut -d= -f2)
[ "${R1:-0}" -gt 0 ] && ok "PlayerSeasonRecord S1: $R1 строк" || bad "PlayerSeasonRecord S1 пуст"
[ "${R2:-0}" -gt 0 ] && ok "PlayerSeasonRecord S2: $R2 строк" || bad "PlayerSeasonRecord S2 пуст"
[ "${R3:-0}" -gt 0 ] && ok "PlayerSeasonRecord S3: $R3 строк" || bad "PlayerSeasonRecord S3 пуст"
TOTAL_GROWTH=$(python3 -c "print('true' if ${R1:-0} > 0 and ${R2:-0} > 0 and ${R3:-0} > 0 else 'false')")
check_eq "история растёт каждый сезон (3 перехода)" "$TOTAL_GROWTH" "true"

# История конкретного игрока через API: 3 записи, возраст монотонно растёт
call GET "$BASE/state?saveId=$SID"
PID_HIST=$(echo "$BODY" | jq -r '.snapshot.myPlayers | sort_by(-.apps) | .[0].id')
call GET "$BASE/player?saveId=$SID&id=$PID_HIST"
check_code "GET /player (история)" 200
check "у ветерана 3 записи истории" '.dialog.history | length' '3'
check "возраст в истории монотонно растёт" '([.dialog.history[].age] as $a | $a == ($a | sort))' 'true'
check "итоги: 3 сезона" '.dialog.totals.seasons' '3'
HIST_AVG=$(echo "$BODY" | jq -r '.dialog.history[] | select(.apps > 0) | .avgRating' | sort -n | head -n1)
if [ -n "$HIST_AVG" ] && [ "$HIST_AVG" != "null" ]; then
  IN_RANGE=$(python3 -c "print('true' if 4.5 <= $HIST_AVG <= 10 else 'false')")
  check_eq "avgRating записей в 4.5–10 (мин $HIST_AVG)" "$IN_RANGE" "true"
else bad "avgRating записей пуст"; fi

# Жемчужины академии за 3 сезона (№10, маркер pot ≥ 85; статистика — в юнит-тестах)
GEMS=$(dbv "$SID" academy gems_all 1)
if [ "${GEMS:-0}" -ge 1 ]; then ok "жемчужины академии (pot ≥ 85) за 3 сезона: $GEMS"; else echo "  ⚠ жемчужин 0 за 3 сезона (малая выборка ~168 воспитанников; частоты проверены юнит-тестом №10: top 0.083, mid 0.020, low 0.017)"; PASS=$((PASS+1)); fi

# Стейт для продолжения (QA_PART=2) — секции 2–5 работают с этим сейвом
printf 'SID=%s\n' "$SID" > "$STATE_FILE"
fi # PART != 2 (секции 0+1)

if [ "$PART" = "1" ]; then
  echo
  echo "════ ИТОГ QA Фазы 3 (часть 1: секции 0+1) ═══════════"
  echo "PASS=$PASS  FAIL=$FAIL"
  echo "Стейт для QA_PART=2: $STATE_FILE (SID=$SID)"
  [ "$FAIL" -eq 0 ] && exit 0 || exit 1
fi

if [ "$PART" = "2" ]; then
  if [ -f "$STATE_FILE" ]; then
    # shellcheck disable=SC1090
    source "$STATE_FILE"
    echo "── Продолжение QA_PART=2: сейв «Три сезона» $SID ──"
  else
    echo "✘ QA_PART=2: стейт-файл $STATE_FILE не найден — сначала QA_PART=1"; exit 1
  fi
fi

# ═══ 2. Контракты: API продления ═════════════════════════════════════════
section "2. Контракты: продление через API (сейв на S4 W1)"

call GET "$BASE/contracts?saveId=$SID"
check_code "GET /contracts" 200
# Фикс сценария (QA-находка): сразу после перехода у всех контрактов 3–5 лет
# (yearsLeft > 2 → renewable=false) — принудительно создаём истекающий контракт
MADE2=$(dbv "$SID" makeexpiring made2 1)
echo "  … makeexpiring: $MADE2"
call GET "$BASE/contracts?saveId=$SID"
check_code "GET /contracts (после makeexpiring)" 200
RENEWABLES=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable == true)] | length')
if [ "$RENEWABLES" -ge 1 ]; then ok "найдено продлеваемых контрактов: $RENEWABLES"; else bad "нет продлеваемых контрактов (renewable=false у всех)"; fi
RID=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable == true)] | sort_by(.yearsLeft) | .[0].playerId')
DEMAND=$(echo "$BODY" | jq -r '[.contracts[] | select(.renewable == true)] | sort_by(.yearsLeft) | .[0].demand')
CU_BEFORE=$(echo "$BODY" | jq -r "[.contracts[] | select(.playerId == \"$RID\") | .contractUntil][0]")
S4=$(echo "$BODY" | jq -r '.season')
echo "  … игрок $RID: спрос €$DEMAND/нед, контракт до $CU_BEFORE, сезон $S4"

# 2a. Контрпредложение при 0.8×demand
OFFER_LOW=$(python3 -c "print(int($DEMAND * 0.8 // 100 * 100))")
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"$RID\",\"years\":2,\"salary\":$OFFER_LOW}"
check_code "renew 0.8×demand: HTTP" 200
check "renew 0.8×demand: counter" '.outcome' 'counter'
check "renew 0.8×demand: спрос возвращён" '.demand' "$DEMAND"
call GET "$BASE/contracts?saveId=$SID"
CU_AFTER_COUNTER=$(echo "$BODY" | jq -r "[.contracts[] | select(.playerId == \"$RID\") | .contractUntil][0]")
check_eq "counter: контракт не изменился" "$CU_AFTER_COUNTER" "$CU_BEFORE"

# 2b. Принятие при offer = demand
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"$RID\",\"years\":2,\"salary\":$DEMAND}"
check_code "renew demand: HTTP" 200
check "renew demand: accepted" '.outcome' 'accepted'
check "renew demand: снапшот возвращён" '.snapshot != null' 'true'
call GET "$BASE/contracts?saveId=$SID"
CU_AFTER=$(echo "$BODY" | jq -r "[.contracts[] | select(.playerId == \"$RID\") | .contractUntil][0]")
check_eq "контракт продлен до сезона+years" "$CU_AFTER" "$((S4 + 2))"

# 2c. Повторное продление → корректная ошибка (yearsLeft > 2)
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"$RID\",\"years\":2,\"salary\":$DEMAND}"
check_code "повторное продление: HTTP" 400
check "повторное продление: CONTRACT_NOT_RENEWABLE" '.error' 'CONTRACT_NOT_RENEWABLE'

# 2d. years > maxRenewYears → 400 INVALID_CONTRACT
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"$RID\",\"years\":9,\"salary\":$DEMAND}"
check_code "years=9: HTTP" 400

# 2e. Чужой игрок → 404 NOT_YOUR_PLAYER
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID\",\"playerId\":\"nonexistent-player\",\"years\":2,\"salary\":$DEMAND}"
check_code "несуществующий игрок: HTTP" 404
check "несуществующий игрок: NOT_YOUR_PLAYER" '.error' 'NOT_YOUR_PLAYER'

# 2f. Босман: попытка продлить игрока с предконтрактом → 409 (вакансия: предконтрактный уже ушёл в S2 — проверим на другом сейве ниже)

# ═══ 3. Правление: намеренные увольнения ═════════════════════════════════
section "3а. Увольнение в переходе (слабый клуб + промах ≥ 4 мест + conf < 30)"

call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":15,"managerName":"QA P3-5","careerName":"P3-QA3 Сак переход"}'
check_code "POST /saves (Химки, слабый клуб)" 200
SID_TS=$(echo "$BODY" | jq -r '.saveId')
# Держим confidence высоким, чтобы дожить до перехода без mid-season sack
for W in $(seq 1 33); do
  $DB setconf "$SID_TS" 45 34 >/dev/null 2>&1
  simulate "$SID_TS"
  if [ "$CODE" != "200" ]; then bad "сак-переход: неделя $W: HTTP $CODE"; break; fi
  SACKED_MID=$(echo "$BODY" | jq -r '.result.sacked')
  if [ "$SACKED_MID" = "true" ]; then bad "сак-переход: mid-season sack на неделе $W (не ожидался)"; break; fi
done
# Ставим цель «чемпионство» и confidence 25 → miss ≥ 4 + conf < 30 → sacked
$DB setconf "$SID_TS" 25 0 champion 1 >/dev/null 2>&1
simulate "$SID_TS"
check_code "финальная неделя сак-сейва" 200
check "переходное увольнение: sacked=true" '.result.sacked' 'true'
check "вердикт sacked" '.result.seasonEnded.boardVerdict.code' 'sacked'
TS_PLACE=$(echo "$BODY" | jq -r '.result.seasonEnded.place')
echo "  … итоговое место $TS_PLACE при цели топ-1, confidence 25"
TS_STATUS=$(dbv "$SID_TS" save save_status)
TS_REASON=$(dbv "$SID_TS" save save_finish_reason)
check_eq "статус сейва finished" "$TS_STATUS" "finished"
check_eq "finishReason sacked" "$TS_REASON" "sacked"

section "3б. GET/POST роуты после finished"

call GET "$BASE/state?saveId=$SID_TS"
check_code "GET /state finished-сейва → 200" 200
check "статус в снапшоте finished" '.snapshot.save.status' 'finished'
call POST "$BASE/simulate" "{\"saveId\":\"$SID_TS\"}"
check_code "POST /simulate finished → 404" 404
call POST "$BASE/tactic" "{\"saveId\":\"$SID_TS\"}"
check_code "POST /tactic finished → 404" 404
call POST "$BASE/training" "{\"saveId\":\"$SID_TS\",\"focus\":\"attack\",\"intensity\":\"normal\"}"
check_code "POST /training finished → 404" 404
call POST "$BASE/market/buy" "{\"saveId\":\"$SID_TS\",\"playerId\":\"x\"}"
check_code "POST /market/buy finished → 404" 404
call POST "$BASE/market/sell" "{\"saveId\":\"$SID_TS\",\"playerId\":\"x\",\"price\":1000}"
check_code "POST /market/sell finished → 404" 404
call POST "$BASE/contracts/renew" "{\"saveId\":\"$SID_TS\",\"playerId\":\"x\",\"years\":1,\"salary\":10000}"
check_code "POST /contracts/renew finished → 404" 404
call GET "$BASE/awards?saveId=$SID_TS"
check_code "GET /awards finished → 404 (play-роут)" 404
call GET "$BASE/contracts?saveId=$SID_TS"
check_code "GET /contracts finished → 200 (read-роут)" 200
call GET "$BASE/board?saveId=$SID_TS"
check_code "GET /board finished → 200 (read-роут)" 200
call GET "$BASE/academy?saveId=$SID_TS"
check_code "GET /academy finished → 200 (read-роут)" 200

section "3в. Mid-season sack (conf<12 четыре недели ПОСЛЕ медового месяца)"

call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":14,"managerName":"QA P3-5","careerName":"P3-QA3 Сак мидсезон"}'
check_code "POST /saves (mid-season сценарий)" 200
SID_MS=$(echo "$BODY" | jq -r '.saveId')
# Медовый месяц (недели 1–8): confidence ≥ 35 по №12 — увольнение невозможно
for W in $(seq 1 8); do
  simulate "$SID_MS"
  if [ "$(echo "$BODY" | jq -r '.result.sacked')" = "true" ]; then bad "mid-season: sack в медовый месяц (неделя $W) — нарушение №12"; fi
done
check_code "недели 1–8 (медовый месяц) отыграны" 200
# Недели 9+: пин conf=5 перед КАЖДОЙ неделей (эмуляция затяжного кризиса без
# влияния случайных побед) → низ < 12 четыре недели подряд → sack на 12-й
MS_SACKED_WEEK=0
for W in 9 10 11 12 13 14; do
  $DB setconf "$SID_MS" 5 0 >/dev/null 2>&1
  simulate "$SID_MS"
  if [ "$CODE" != "200" ]; then bad "mid-season: неделя $W HTTP $CODE"; break; fi
  if [ "$(echo "$BODY" | jq -r '.result.sacked')" = "true" ]; then MS_SACKED_WEEK=$W; break; fi
done
if [ "$MS_SACKED_WEEK" -gt 0 ]; then ok "mid-season sack на неделе $MS_SACKED_WEEK (conf<12 четыре недели подряд после honeymoon)"; else bad "mid-season sack не произошёл к неделе 14 при conf=5"; fi
MS_STATUS=$(dbv "$SID_MS" save save_status)
MS_REASON=$(dbv "$SID_MS" save save_finish_reason)
check_eq "mid-season: статус finished" "$MS_STATUS" "finished"
check_eq "mid-season: finishReason sacked" "$MS_REASON" "sacked"

# ═══ 4. Легаси-сейв «Каталония навсегда» (read-only) ═══════════════════════
section "4. Легаси-сейв «Каталония навсегда» жив (read-only)"

# при QA_PART=2 список карьер не закеширован секцией 0 — забираем свежий
if [ -z "${SAVES_BODY:-}" ]; then
  call GET "$BASE/saves"
  SAVES_BODY="$BODY"
fi
LEGACY=$(echo "$SAVES_BODY" | jq -r '.saves[] | select(.careerName=="Каталония навсегда") | .id' | head -n1)
if [ -n "$LEGACY" ]; then
  call GET "$BASE/state?saveId=$LEGACY"
  check_code "GET /state легаси" 200
  LSTATUS=$(echo "$BODY" | jq -r '.snapshot.save.status')
  LCLUB=$(echo "$BODY" | jq -r '.snapshot.myTeam.name')
  ok "легаси открывается: $LCLUB, статус $LSTATUS (кликается в UI)"
  call GET "$BASE/board?saveId=$LEGACY"
  check_code "GET /board легаси" 200
else
  bad "легаси-сейв «Каталония навсегда» не найден в списке карьер"
fi

# ═══ 5. Уборка: каскадное удаление своих сейвов ═══════════════════════════
section "5. Удаление тест-сейвов (каскад PlayerSeasonRecord)"

RECORDS_BEFORE=$(dbv "$SID" records records_total)
for DEL in "$SID" "$SID_TS" "$SID_MS"; do
  call DELETE "$BASE/saves/$DEL"
  if [ "$CODE" = "200" ]; then ok "удалён $DEL"; else bad "не удалён $DEL (HTTP $CODE)"; fi
done
RECORDS_AFTER=$(dbv "$SID" records records_total)
check_eq "записи истории удалены каскадом ($RECORDS_BEFORE → )" "$RECORDS_AFTER" "0"
call GET "$BASE/state?saveId=$SID"
check_code "GET /state удалённого → 404" 404
call GET "$BASE/saves"
LEFT=$(echo "$BODY" | jq -r "[.saves[] | select(.careerName | startswith(\"$PREFIX\"))] | length")
check_eq "своих сейвов не осталось" "$LEFT" "0"
rm -f "$STATE_FILE"

# ═══ Итог ═════════════════════════════════════════════════════════════════
echo
echo "════ ИТОГ QA Фазы 3 ═════════════════════════════════"
echo "PASS=$PASS  FAIL=$FAIL"
[ "$FAIL" -eq 0 ] && echo "СТАТУС: ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ" || echo "СТАТУС: ЕСТЬ ПРОВАЛЫ — см. выше"
exit $([ "$FAIL" -eq 0 ] && echo 0 || echo 1)

/**
 * Детерминированный RNG: mulberry32 + вспомогательные функции.
 * Раздел 4.2 docs/architecture.md.
 */

/** Тип генератора случайных чисел (фикс QA-4: не был экспортирован). */
export type RNG = () => number;

/** mulberry32 — быстрый детерминированный ГПСЧ. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function (): number {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** FNV-1a 32-бит — хеш строки для сида. */
export function hashString(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** Сид матча: детерминизм — повторный прогон того же матча даёт тот же результат. */
export function matchSeed(saveId: string, season: number, week: number, matchId: string): number {
  return hashString(`${saveId}:${season}:${week}:${matchId}`);
}

/** Нормальное распределение (Box-Muller). Кламп на месте вызова. */
export function gauss(rng: () => number, mean: number, sd: number): number {
  const u1 = Math.max(rng(), 1e-12); // защита от log(0)
  const u2 = rng();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return mean + z * sd;
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

/** Случайное целое [min, max] включительно. */
export function randInt(rng: () => number, min: number, max: number): number {
  return min + Math.floor(rng() * (max - min + 1));
}

/** Случайный элемент массива. */
export function pick<T>(rng: () => number, arr: readonly T[]): T {
  return arr[Math.floor(rng() * arr.length)];
}

/** Случайный элемент с весами (сумма весов может быть любой). */
export function pickWeighted<T>(rng: () => number, items: readonly { item: T; weight: number }[]): T {
  const total = items.reduce((s, x) => s + x.weight, 0);
  let roll = rng() * total;
  for (const entry of items) {
    roll -= entry.weight;
    if (roll <= 0) return entry.item;
  }
  return items[items.length - 1].item;
}

/** Перемешивание копии массива (Фишер–Йетс). */
export function shuffled<T>(rng: () => number, arr: readonly T[]): T[] {
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

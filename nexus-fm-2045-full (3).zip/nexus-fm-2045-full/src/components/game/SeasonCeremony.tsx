'use client';

import { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Award, ChevronRight, DoorOpen, Footprints, Globe, Goal, Hand, Landmark, Shield, Sparkles,
  Star, Trophy,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { formatMoney } from '@/lib/game/format';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Иконки 8 наград сезона. */
const AWARD_ICONS: Record<string, typeof Trophy> = {
  top_scorer: Footprints,
  top_assist: Goal,
  mvp: Star,
  young: Sparkles,
  golden_glove: Hand,
  cup_scorer: Goal,
  champion: Trophy,
  cup_winner: Shield,
};

const AWARD_ORDER: Record<string, number> = {
  champion: 0,
  cup_winner: 1,
  top_scorer: 2,
  top_assist: 3,
  mvp: 4,
  young: 5,
  golden_glove: 6,
  cup_scorer: 7,
};

/** Стиль блока вердикта правления по коду (§7.6). */
function verdictClass(code: 'met' | 'missed' | 'over' | 'sacked'): string {
  switch (code) {
    case 'met':
      return 'border-primary/40 bg-primary/10 text-primary';
    case 'over':
      return 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]';
    case 'sacked':
      return 'border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]';
    default:
      return 'border-border/60 bg-secondary/40 text-muted-foreground';
  }
}

/** Стиль строки итогов Кубка Европы по метке (§7.7 ТЗ Фазы 4). */
function euroClass(label: string): string {
  if (label.startsWith('Чемпион')) return 'border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#D4AF37]';
  if (label.startsWith('Финалист')) return 'border-[#D4AF37]/30 bg-[#D4AF37]/5 text-[#D4AF37]/80';
  if (label.startsWith('Вылет')) return 'border-border/60 bg-secondary/40 text-muted-foreground';
  return 'border-border/40 bg-secondary/20 text-muted-foreground/80';
}

/** Полноэкранная церемония наград по итогам сезона (§7.9) + вердикт правления (Фаза 3, §7.6). */
export function SeasonCeremony() {
  const lastMatch = useGameStore((s) => s.lastMatch);
  const dismiss = useGameStore((s) => s.dismissSeasonSummary);
  const setMatchView = useGameStore((s) => s.setMatchView);
  const setTab = useGameStore((s) => s.setTab);
  const exitToCareers = useGameStore((s) => s.exitToCareers);
  const snapshot = useGameStore((s) => s.snapshot);

  const ended = lastMatch?.seasonEnded ?? null;

  const awards = useMemo(() => {
    if (!ended) return [];
    return [...ended.awards].sort(
      (a, b) => (AWARD_ORDER[a.type] ?? 99) - (AWARD_ORDER[b.type] ?? 99),
    );
  }, [ended]);

  if (!ended) return null;

  const myRow = ended.standings.find((r) => r.isUser);
  const top3 = ended.standings.slice(0, 3);
  const season = lastMatch?.season ?? 0;
  const verdict = ended.boardVerdict;
  const sacked = verdict?.code === 'sacked';
  // После перехода снапшот уже содержит цель НОВОГО сезона (для не-уволенных).
  const newTarget = snapshot?.board.targetLabel ?? null;

  const finish = () => {
    dismiss();
    setMatchView('prematch');
    setTab('dashboard');
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-background/95 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Церемония наград по итогам сезона"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="mx-auto flex min-h-full w-full max-w-lg flex-col justify-center p-4"
      >
          <Card className="border-[#EAB308]/30">
            <CardHeader className="text-center">
              <motion.div
                initial={{ scale: 0, rotate: -12 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.15, type: 'spring', stiffness: 200, damping: 15 }}
                className="mx-auto mb-2 flex size-16 items-center justify-center rounded-full bg-[#EAB308]/15"
              >
                <Trophy className="size-8 text-[#EAB308]" aria-hidden />
              </motion.div>
              <CardTitle className="text-xl">
                {sacked ? `Сезон ${season} завершён — вы уволены` : `Сезон ${season} завершён!`}
              </CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Ваш клуб занял{' '}
                <span className="font-bold text-foreground">{ended.place}-е</span> место и получил
                призовые{' '}
                <span className="font-bold tabular text-[#EAB308]">{formatMoney(ended.prize)}</span>.
              </p>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Призовая тройка */}
              <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
                <p className="mb-2 text-xs font-semibold text-muted-foreground">Призовая тройка</p>
                <ul className="space-y-1.5">
                  {top3.map((r) => (
                    <li
                      key={r.teamId}
                      className={cn('flex items-center gap-2 text-xs', r.isUser && 'font-bold text-primary')}
                    >
                      <span className="w-5 text-center tabular">{r.place}</span>
                      <TeamCrest
                        shortName={r.shortName}
                        colorPrimary={r.colorPrimary}
                        colorSecondary={r.colorSecondary}
                        size="sm"
                      />
                      <span className="min-w-0 flex-1 truncate">{r.name}</span>
                      <span className="tabular text-muted-foreground">{r.points} очк.</span>
                    </li>
                  ))}
                  {myRow && myRow.place > 3 ? (
                    <li className="mt-1 flex items-center gap-2 border-t border-border/50 pt-1.5 text-xs font-bold text-primary">
                      <span className="w-5 text-center tabular">{myRow.place}</span>
                      <TeamCrest
                        shortName={myRow.shortName}
                        colorPrimary={myRow.colorPrimary}
                        colorSecondary={myRow.colorSecondary}
                        size="sm"
                      />
                      <span className="min-w-0 flex-1 truncate">{myRow.name}</span>
                      <span className="tabular text-muted-foreground">{myRow.points} очк.</span>
                    </li>
                  ) : null}
                </ul>
              </div>

              {/* Фаза 4: итоги Кубка Европы (§7.7) */}
              {ended.euro ? (
                <div className={cn('rounded-lg border p-3', euroClass(ended.euro.label))}>
                  <p className="flex items-center gap-1.5 text-xs font-semibold">
                    <Globe className="size-4 shrink-0" aria-hidden />
                    Кубок Европы · {ended.euro.label}
                  </p>
                  <p className="mt-1 text-[11px] leading-relaxed opacity-90">
                    Следующий сезон: квалификация{' '}
                    <span className="font-semibold">
                      {ended.euro.qualifiedNext ? 'обеспечена' : 'не обеспечена'}
                    </span>
                  </p>
                </div>
              ) : null}

              {/* Вердикт правления (Фаза 3, §7.6) */}
              {verdict ? (
                <div className={cn('rounded-lg border p-3', verdictClass(verdict.code))}>
                  <p className="flex items-center gap-1.5 text-xs font-semibold">
                    <Landmark className="size-4 shrink-0" aria-hidden />
                    {verdict.code === 'over'
                      ? `Цель перевыполнена! Премия правления ${formatMoney(verdict.bonus)}`
                      : verdict.code === 'met'
                        ? 'Цель сезона выполнена'
                        : verdict.code === 'missed'
                          ? 'Цель сезона провалена'
                          : 'Вы уволены'}
                  </p>
                  {verdict.code === 'sacked' ? (
                    <p className="mt-1 text-[11px] leading-relaxed opacity-90">
                      Доверие правления иссякло: карьера в этом клубе завершена. Нажмите
                      «Закрыть карьеру», чтобы подвести итоги.
                    </p>
                  ) : newTarget ? (
                    <p className="mt-1 text-[11px] leading-relaxed opacity-90">
                      Цель на сезон {season + 1}:{' '}
                      <span className="font-semibold">{newTarget}</span>
                    </p>
                  ) : null}
                </div>
              ) : null}

              {/* Лауреаты */}
              <div className="space-y-2">
                <p className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                  <Award className="size-3.5 text-[#EAB308]" aria-hidden />
                  Лауреаты сезона
                </p>
                {awards.length === 0 ? (
                  <p className="py-2 text-center text-xs text-muted-foreground">
                    Индивидуальных наград в этом сезоне нет.
                  </p>
                ) : (
                  awards.map((a, i) => {
                    const Icon = AWARD_ICONS[a.type] ?? Award;
                    return (
                      <motion.div
                        key={a.id}
                        initial={{ opacity: 0, x: -12 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.25 + i * 0.12, duration: 0.25 }}
                        className={cn(
                          'flex items-center gap-3 rounded-lg border border-border/60 bg-secondary/30 p-3',
                          a.teamId === myRow?.teamId && 'border-primary/40 bg-primary/5',
                        )}
                      >
                        <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[#EAB308]/10">
                          <Icon className="size-4 text-[#EAB308]" aria-hidden />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-xs font-bold">{a.typeName}</div>
                          <div className="truncate text-[11px] text-muted-foreground">{a.label}</div>
                        </div>
                        <Badge className="shrink-0 border border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308] tabular">
                          {a.value}
                        </Badge>
                      </motion.div>
                    );
                  })
                )}
              </div>

              {sacked ? (
                <Button
                  size="lg"
                  className="h-12 w-full text-base"
                  onClick={() => {
                    dismiss();
                    exitToCareers();
                  }}
                >
                  <DoorOpen className="size-5" aria-hidden />
                  Закрыть карьеру
                </Button>
              ) : (
                <Button size="lg" className="h-12 w-full text-base" onClick={finish}>
                  Начать сезон {season + 1}
                  <ChevronRight className="size-5" aria-hidden />
                </Button>
              )}
              <p className="text-center text-[11px] text-muted-foreground">
                {sacked
                  ? 'Итоги карьеры доступны в списке карьер — сейв помечен как завершённый.'
                  : 'Новый сезон уже сгенерирован: календарь и составы обновлены.'}
              </p>
            </CardContent>
          </Card>
        </motion.div>
    </div>
  );
}

/**
 * Оркестратор недели: симуляция матчей (лига ИЛИ кубок), еженедельные
 * тренировки, финансы, рынок, новости, сезонный переход с наградами.
 * Единственный модуль игровой логики с доступом к Prisma (вместе с API-роутами).
 * §3.4–3.5 architecture-upgrade.md (Фаза 2).
 */

import { db } from '@/lib/db';
import { Prisma, type Team as TeamModel } from '@prisma/client';
import {
  ACADEMY_INTAKE_WEEK, AI_BUY_CHANCE, BOSMAN_INTERVAL, BOSMAN_RANK_SPAN,
  BOSMAN_SEASON_START, BOARD_CONF_START, BOARD_HONEYMOON_WEEKS, BOARD_PACE_INTERVAL,
  BOARD_SACK_CONF_WEEKLY, BOARD_SACK_STREAK, BOARD_STRENGTH_GAP, BOARD_TARGET_LABELS,
  BOARD_ULTIMATUM_BELOW, BOARD_WARN_BELOW, CONDITION_MAX, CONDITION_MIN,
  CONTRACT_DRAIN_AGE, CONTRACT_DRAIN_OVR, CONTRACT_FREE_PRICE_RATIO,
  CONTRACT_FREE_SALARY_MULT, CONTRACT_FREE_TTL, CONTRACT_AI_SQUAD_FLOOR,
  AI_SIGN_MAX_PER_SEASON, AI_STYLES,
  CUP_MORALE_OUT, CUP_MORALE_WIN, CUP_REST_COND, CUP_REST_MORALE, MORALE_MAX,
  MORALE_MIN, PRIZE_MONEY_BY_SIZE, SALARY_MIN, SALARY_ROUND,
  START_BALANCE_BASE, START_BALANCE_PER_STRENGTH, TRANSFER_BUDGET_RATIO,
  FORMATIONS,
  coerceAiStyle, coerceDefLine, coerceFormation, coerceMentality, coercePlayStyle,
  coercePressing, coerceTempo, contractAiYears,
  EURO_GUEST_MIN_SQUAD, EURO_PRIZE_PARTICIPATION, EURO_ROTATE_COND, EURO_ROUNDS,
  EURO_TOURNAMENT_NAME,
  type BoardTargetCode,
} from './constants';
import { intakeNews, runIntakeForClub } from './academy';
import { applyAwardBonuses, computeSeasonAwards, type AwardDraft } from './awards';
import { aiDefaultPlan, aiStyleChangesFor, guessAiStyle } from './coach';
import {
  evaluateSeasonTarget, jobStatusOf, nextSeasonTarget, weeklyBoardUpdate,
  type BoardMatchInput, type BoardTargetInfo,
} from './board';
import {
  aiContractDecisions, aiReplenishmentPicks, bosmanProbability, contractUntilFromYears, contractYearsRoll,
  renewDemand, teamAppsOf,
} from './contracts';
import { buildSeasonPlan, cupRoundLabel, leagueWeekOf, weekSlotAt } from './calendar';
import {
  drawCupRound, finalistPrize, lineupGoalkeeper, prelimParticipants, prizeForRound,
  shootoutTakers, simulateAiCupMatch, simulatePenaltyShootout, type CupPair,
} from './cup';
import { ApiGameError } from './error';
import {
  drawEuroRound, euroPrizeFor, euroRoundAt, euroRoundLabel, euroWeeksOf,
  parseEuroTeamIds, resolveEuroRoster, serializeEuroTeamIds, simulateEuroAiMatch,
} from './euro';
import { computeWeekFinance, weeklyIncomeEstimate } from './finances';
import {
  generateCalendar, poolContextOf, type EuroGuestTeamGen, type NamePoolContext,
} from './generate';
import { buildSeasonRecords } from './history';
import { LEAGUES, leagueByCode, NAME_POOLS } from './leagues';
import { simulateAiMatch, simulateMatch, type MatchTeamInput, type SubRecord } from './match';
import {
  autoLineup, computeSalary, generatePlayer, isLineupValid, freeShirtNumber,
  playerCreateData, type PlayerLike,
} from './players';
import { applyMatchEffects, applySeasonProgression, applyWeeklyRecovery } from './progression';
import { gauss, hashString, mulberry32, clamp, pick, randInt, type RNG } from './rng';
import { computeStandings, type StandingMatchInput, type StandingTeamInput } from './standings';
import { generateMarketListing, marketTopUpCount, pickAiPurchase, sellOfferProbability } from './transfers';
import { aiTrainingChoice, applyWeeklyTraining, coerceTrainingFocus, coerceTrainingIntensity } from './training';
import { parseLineup, parseTeamIdList, parseMatchPlan, AWARD_TYPE_LABELS } from './types';
import type {
  CupMatchDTO, EuroMatchDTO, EuroTeamDTO, LeagueCode, MatchEvent, MatchStats, NewsDTO,
  NewsType, Position, RadarPlayerDTO, SeasonAwardDTO, StandingRow, TeamBriefDTO, UserMatchResultDTO,
  WeekResultPayload,
} from './types';

// ── Хелперы ──────────────────────────────────────────────────────────────

const DYNAMIC_FIELDS = [
  'morale', 'condition', 'injuryWeeks', 'goals', 'assists', 'apps',
  'yellowCards', 'redCards', 'age', 'potential', 'ovr', 'value', 'salary',
  'finishing', 'passing', 'dribbling', 'crossing', 'tackling', 'marking',
  'positioning', 'heading', 'pace', 'stamina', 'strength', 'aggression',
  'reflexes', 'rushingOut', 'kicking',
  'cleanSheets', 'cupGoals', 'cupAssists', 'euroGoals', 'euroAssists',
  // Фаза 3: контракт и рейтинг копятся еженедельно — дифф обязателен
  'contractUntil', 'ratingSum', 'ratingApps',
] as const;

type PrismaOps = Prisma.PrismaPromise<unknown>[];

function playerDiff(orig: PlayerLike, curr: PlayerLike): Record<string, number | string | null> | null {
  const data: Record<string, number | string | null> = {};
  let changed = false;
  for (const f of DYNAMIC_FIELDS) {
    if (orig[f] !== curr[f]) {
      data[f] = curr[f];
      changed = true;
    }
  }
  if (orig.trainingXp !== curr.trainingXp) {
    data.trainingXp = curr.trainingXp ?? '{}';
    changed = true;
  }
  // Фаза 3: Босман-предконтракт (string|null — спец-кейс по образцу trainingXp)
  if (orig.preContractTeamId !== curr.preContractTeamId) {
    data.preContractTeamId = curr.preContractTeamId;
    changed = true;
  }
  return changed ? data : null;
}

function toTeamBrief(team: TeamModel): TeamBriefDTO {
  return {
    id: team.id,
    name: team.name,
    shortName: team.shortName,
    city: team.city,
    colorPrimary: team.colorPrimary,
    colorSecondary: team.colorSecondary,
    strength: team.strength,
    isUser: team.isUserTeam,
    formation: coerceFormation(team.formation),
    mentality: coerceMentality(team.mentality),
  };
}

interface TeamCtx {
  team: TeamModel;
  players: PlayerLike[];
  lineup: (string | null)[];
  bench: string[];
  /** Фаза 4: клуб игрока (стиль движка = balanced, план из Team.matchPlan). */
  isUser: boolean;
}

function tacticInputOf(ctx: TeamCtx): MatchTeamInput {
  return {
    teamId: ctx.team.id,
    players: ctx.players,
    formation: coerceFormation(ctx.team.formation),
    mentality: coerceMentality(ctx.team.mentality),
    tempo: coerceTempo(ctx.team.tempo),
    pressing: coercePressing(ctx.team.pressing),
    defLine: coerceDefLine(ctx.team.defLine),
    playStyle: coercePlayStyle(ctx.team.playStyle),
    lineup: ctx.lineup,
    name: ctx.team.name,
    // ── Фаза 4 (§5.2 А) ──
    bench: ctx.bench,
    // Клуб игрока: balanced (его тактика уже в полях выше) + план из Team.matchPlan;
    // ИИ/гости: профиль стиля + дефолтный план (паритет решений движка)
    coach: ctx.isUser
      ? { style: 'balanced', plan: parseMatchPlan(ctx.team.matchPlan) }
      : { style: coerceAiStyle(ctx.team.aiStyle), plan: aiDefaultPlan() },
  };
}

/** Модуль 6 (зеркало engine/week.ts): стартовый XI для 2D-радара. */
function radarXiOf(ctx: TeamCtx): RadarPlayerDTO[] {
  const formation = coerceFormation(ctx.team.formation);
  const slots = FORMATIONS[formation].slots;
  const byId = new Map(ctx.players.map((p) => [p.id, p]));
  return ctx.lineup.map((pid, i) => {
    const slot = slots[i];
    const p = pid ? byId.get(pid) : undefined;
    return {
      slot: i,
      playerId: pid ?? null,
      name: p ? `${p.firstName} ${p.lastName}` : `Слот ${slot?.position ?? '?'}`,
      position: slot?.position ?? p?.position ?? 'MC',
      number: p?.shirtNumber ?? null,
    };
  });
}

interface PendingNews {
  id: string;
  type: NewsType;
  message: string;
}

/** Сыгранный матч недели (для записи в БД и DTO). */
interface PlayedMatch {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  week: number;
  isNeutral: boolean;
  competition: 'league' | 'cup' | 'euro';
  cupRound: number | null;
  homeGoals: number;
  awayGoals: number;
  homePens: number | null;
  awayPens: number | null;
  winnerTeamId: string | null;
  events: MatchEvent[];
  stats: MatchStats | null;
  isNew: boolean; // true → строку нужно СОЗДАТЬ (ленивая жеребьёвка)
}

/** Запланированный матч следующего раунда (кубок ИЛИ евро — жеребьёвка после раунда). */
interface ScheduledCupMatch {
  id: string;
  week: number;
  homeTeamId: string;
  awayTeamId: string;
  cupRound: number;
  isNeutral: boolean;
  /** Фаза 4: еврораунды расписываются так же, как кубковые (cupRound = номер еврораунда). */
  competition: 'cup' | 'euro';
}

function playedMatchOps(saveId: string, season: number, pm: PlayedMatch): PrismaOps {
  const common = {
    homeGoals: pm.homeGoals,
    awayGoals: pm.awayGoals,
    status: 'played',
    events: JSON.stringify(pm.events),
    competition: pm.competition,
    cupRound: pm.cupRound,
    homePens: pm.homePens,
    awayPens: pm.awayPens,
    winnerTeamId: pm.winnerTeamId,
    isNeutral: pm.isNeutral,
  };
  if (pm.isNew) {
    return [
      db.match.create({
        data: {
          id: pm.id,
          saveId,
          season,
          week: pm.week,
          homeTeamId: pm.homeTeamId,
          awayTeamId: pm.awayTeamId,
          stats: pm.stats ? JSON.stringify(pm.stats) : null,
          ...common,
        },
      }),
    ];
  }
  return [
    db.match.update({
      where: { id: pm.id },
      data: { ...common, stats: pm.stats ? JSON.stringify(pm.stats) : undefined },
    }),
  ];
}

/** «Сухой матч» стартовому вратарю (слот 0 = GK). */
function creditCleanSheet(ctx: TeamCtx, conceded: number): void {
  if (conceded !== 0) return;
  const gkId = ctx.lineup[0];
  if (!gkId) return;
  const gk = ctx.players.find((p) => p.id === gkId);
  if (gk && gk.position === 'GK') gk.cleanSheets += 1;
}

function freeShirtNumbers(squad: PlayerLike[], excluding: string[]): number {
  const used = new Set(
    squad.filter((p) => !excluding.includes(p.id)).map((p) => p.shirtNumber),
  );
  for (let n = 1; n <= 99; n++) if (!used.has(n)) return n;
  return 99;
}

interface SeasonTransitionResult {
  standings: StandingRow[];
  place: number;
  prize: number;
  /** Премия правления за перевыполнение (Фаза 3), € — добавляется к newBalance. */
  bonus: number;
  awards: SeasonAwardDTO[];
  sacked: boolean;
  boardVerdict: { code: 'met' | 'missed' | 'over' | 'sacked'; label: string; bonus: number } | null;
  /** Confidence на старт следующего сезона. */
  confidenceNext: number;
  nextTarget: BoardTargetInfo | null;
  /** Фаза 4: состояние евро следующего сезона (GameSave-поля перехода). */
  euroNextState: { season: number; participants: string; alive: string };
  /** Фаза 4: евро-итог для церемонии (§7.7): квалифицировался ли клуб. */
  euroNextDto: { qualifiedNext: boolean; label: string };
  extraOps: PrismaOps;
}

// ── Сезонный переход (§3.5) ───────────────────────────────────────────────

function buildSeasonTransition(args: {
  saveId: string;
  season: number;
  week: number;
  leagueCode: LeagueCode;
  ctxs: Map<string, TeamCtx>;
  standings: StandingRow[];
  cupWinnerTeamId: string | null;
  userTeamId: string;
  teamCount: number;
  pool: NamePoolContext;
  rng: RNG;
  idFactory: () => string;
  // ── Фаза 3 ──
  /** Игроки рынка (teamId=null) на момент перехода — для снапшота и дренажа. */
  freeAgents: PlayerLike[];
  /** Правление: цель и confidence завершившегося сезона (после недельного апдейта). */
  board: { targetCode: BoardTargetCode; targetPlace: number; confidence: number } | null;
  /** Игроки с активными лотами (guard 5d — не дренажировать). */
  activeListingPlayerIds: Set<string>;
  /** Проданные на этой неделе (guard 5c — free-лот не создаём). */
  soldThisWeekPlayerIds: Set<string>;
  // ── Фаза 4 ──
  /** Гости Кубка Европы (§5.5 — изолированы от ctxs): старение/реген/записи истории. */
  guestSides: { team: TeamModel; players: PlayerLike[] }[];
}): SeasonTransitionResult {
  const {
    saveId, season, week, leagueCode, ctxs, standings, cupWinnerTeamId,
    userTeamId, teamCount, pool, rng, idFactory, freeAgents, board,
    activeListingPlayerIds, soldThisWeekPlayerIds, guestSides,
  } = args;
  const extraOps: PrismaOps = [];
  const N = teamCount;
  const plan = buildSeasonPlan(leagueCode);

  // Место клуба по силе (1 = сильнейший) — для оценочного дохода ИИ-продлений
  const strengthRankById = new Map<string, number>();
  [...Array.from(ctxs.values())]
    .sort((a, b) => b.team.strength - a.team.strength)
    .forEach((c, i) => strengthRankById.set(c.team.id, i + 1));

  const teamNameById = new Map(Array.from(ctxs.values()).map((c) => [c.team.id, c.team.name]));
  // Фаза 4: имена гостей — для записей их PlayerSeasonRecord (§5.6-3)
  for (const g of guestSides) teamNameById.set(g.team.id, g.team.name);
  const playerNameById = new Map<string, string>();
  for (const ctx of ctxs.values()) {
    for (const p of ctx.players) playerNameById.set(p.id, `${p.firstName} ${p.lastName}`);
  }

  // 1. Финальная таблица — передана (все лиговые матчи сыграны)
  const userPlace = standings.find((s) => s.teamId === userTeamId)?.place ?? N;
  const prizeRow = PRIZE_MONEY_BY_SIZE[N] ?? PRIZE_MONEY_BY_SIZE[16];
  const prize = prizeRow[Math.min(Math.max(userPlace - 1, 0), prizeRow.length - 1)];

  // 2. Награды — ДО старения (возраст/статистика сезона)
  const allPlayers: PlayerLike[] = [];
  for (const ctx of ctxs.values()) allPlayers.push(...ctx.players);
  const drafts: AwardDraft[] = computeSeasonAwards({
    teams: Array.from(ctxs.values()).map((c) => ({ id: c.team.id, name: c.team.name })),
    players: allPlayers,
    standings,
    cupWinnerTeamId,
  });
  const awardIds = drafts.map(() => idFactory());
  const awardDtos: SeasonAwardDTO[] = drafts.map((d, i) => ({
    id: awardIds[i],
    season,
    type: d.type,
    typeName: AWARD_TYPE_LABELS[d.type] ?? d.type,
    playerId: d.playerId,
    playerName: d.playerId ? (playerNameById.get(d.playerId) ?? null) : null,
    teamId: d.teamId,
    teamName: teamNameById.get(d.teamId) ?? '',
    value: d.value,
    label: d.label,
  }));
  for (let i = 0; i < drafts.length; i++) {
    extraOps.push(
      db.seasonAward.create({
        data: {
          id: awardIds[i],
          saveId,
          season,
          type: drafts[i].type,
          playerId: drafts[i].playerId,
          teamId: drafts[i].teamId,
          value: drafts[i].value,
          label: drafts[i].label,
        },
      }),
    );
  }

  // 3. СНАПШОТ ИСТОРИИ (Фаза 3, КРИТИЧНЫЙ порядок): строго ДО старения
  // (возраст «в тот сезон») и ДО applySeasonProgression (иначе записи — нули)
  const squadPlayers: PlayerLike[] = [];
  for (const ctx of ctxs.values()) squadPlayers.push(...ctx.players);
  // [P4] §5.6-3: записи гостей — teamId/имя их клуба, евро-поля заполнены
  for (const g of guestSides) squadPlayers.push(...g.players);
  const recordRows = buildSeasonRecords({
    season,
    squadPlayers,
    freeAgents,
    teamNameById,
  });
  if (recordRows.length > 0) {
    extraOps.push(
      db.playerSeasonRecord.createMany({
        data: recordRows.map((r) => ({ ...r, saveId, season })),
      }),
    );
  }

  // 4. ВЕРДИКТ ПРАВЛЕНИЯ (Фаза 3): премия/увольнение/цель следующего сезона
  let sacked = false;
  let bonus = 0;
  let boardVerdictDto: SeasonTransitionResult['boardVerdict'] = null;
  let confidenceNext = board?.confidence ?? BOARD_CONF_START;
  let nextTarget: BoardTargetInfo | null = null;
  const verdictNews: string[] = [];
  if (board) {
    const verdict = evaluateSeasonTarget({
      place: userPlace,
      targetCode: board.targetCode,
      targetPlace: board.targetPlace,
      confidence: board.confidence,
      teamCount: N,
      teams: Array.from(ctxs.values()).map((c) => ({ id: c.team.id, strength: c.team.strength })),
      userTeamId,
      prevPlace: userPlace,
    });
    sacked = verdict.sacked;
    bonus = verdict.bonus;
    confidenceNext = verdict.confidenceNext;
    nextTarget = verdict.nextTarget;
    verdictNews.push(...verdict.news);
    if (verdict.bonus > 0) {
      extraOps.push(
        db.financeRecord.create({
          data: {
            id: idFactory(),
            saveId,
            season,
            week,
            kind: 'income',
            category: 'prize',
            amount: verdict.bonus,
            description: 'Премия правления за перевыполнение цели',
          },
        }),
      );
    }
    const code = verdict.sacked ? 'sacked' : verdict.verdict;
    boardVerdictDto = {
      code,
      label: code === 'sacked'
        ? 'Вы уволены'
        : code === 'over'
          ? 'Цель перевыполнена'
          : code === 'met'
            ? 'Цель выполнена'
            : 'Цель провалена',
      bonus: verdict.bonus,
    };
  }

  // 5. КОНТРАКТЫ (Фаза 3). Зарплаты, назначенные здесь, ПЕРЕЗАПИСЫВАЮТСЯ после
  // applySeasonProgression (шаг 6) через contractSalaries — дифф запишет итог.
  const contractRng = mulberry32(hashString(`${saveId}:contracts:${season}`));
  const contractSalaries = new Map<string, number>();

  // 5a. Босман-исполнения: игроки с предконтрактом переходят в клуб-приёмник
  const bosmanArrivals = new Map<string, PlayerLike[]>();
  for (const ctx of ctxs.values()) {
    const departures: PlayerLike[] = [];
    for (const p of ctx.players) {
      if (!p.preContractTeamId) continue;
      const destCtx = ctxs.get(p.preContractTeamId);
      const destTeamId = p.preContractTeamId;
      const destSquad = destCtx
        ? [...destCtx.players, ...(bosmanArrivals.get(destTeamId) ?? [])]
        : [p];
      const destTeamApps = teamAppsOf(destCtx ? destCtx.players : []);
      const salary = renewDemand({ player: p, squad: destSquad, teamApps: destTeamApps });
      const shirtNumber = destCtx ? freeShirtNumbers(destCtx.players, []) : 99;
      p.preContractTeamId = null;
      p.teamId = destTeamId;
      p.shirtNumber = shirtNumber;
      p.contractUntil = season + contractAiYears(p.age);
      contractSalaries.set(p.id, salary);
      departures.push(p);
      bosmanArrivals.set(destTeamId, [...(bosmanArrivals.get(destTeamId) ?? []), p]);
      // Уходящий больше не принадлежит клубу — чистим его лоты (unique playerId)
      extraOps.push(db.transferListing.deleteMany({ where: { playerId: p.id } }));
      extraOps.push(
        db.player.update({
          where: { id: p.id },
          data: { teamId: destTeamId, shirtNumber },
        }),
      );
      if (ctx.team.id === userTeamId) {
        extraOps.push(
          newsOp(
            saveId, season, week, idFactory, 'transfer',
            `${p.firstName} ${p.lastName} покинул клуб по предконтракту.`,
          ),
        );
      }
    }
    if (departures.length > 0) {
      const departureIds = new Set(departures.map((d) => d.id));
      ctx.players = ctx.players.filter((p) => !departureIds.has(p.id));
    }
  }
  // прибывшие вступают в составы приёмников (старение/статистика — как всем)
  for (const [teamId, arrivals] of bosmanArrivals) {
    const destCtx = ctxs.get(teamId);
    if (destCtx) destCtx.players.push(...arrivals);
  }

  // 5b. ИИ-продления (клуб игрока НЕ обрабатывается — продления только вручную)
  for (const ctx of ctxs.values()) {
    if (ctx.team.id === userTeamId) continue;
    const rankPlace = strengthRankById.get(ctx.team.id) ?? N;
    const income = weeklyIncomeEstimate(rankPlace, ctx.team.stadiumCapacity, N);
    const decisions = aiContractDecisions({
      rng: contractRng,
      squad: ctx.players,
      season,
      income,
    });
    for (const r of decisions.renewed) contractSalaries.set(r.player.id, r.salary);
  }

  // 5c. Истечения (все клубы, ВКЛЮЧАЯ клуб игрока) → свободные агенты + лоты
  const expiredFromUser: string[] = [];
  for (const ctx of ctxs.values()) {
    for (const p of ctx.players) {
      if (p.preContractTeamId) continue; // исполнен в 5a
      if (p.contractUntil > season) continue; // контракт ещё действует
      const newSalary = Math.max(
        SALARY_MIN,
        Math.round((computeSalary(p.value) * CONTRACT_FREE_SALARY_MULT) / SALARY_ROUND) * SALARY_ROUND,
      );
      p.teamId = null;
      contractSalaries.set(p.id, newSalary);
      extraOps.push(db.player.update({ where: { id: p.id }, data: { teamId: null } }));
      // Guard: продан на этой неделе — лот уже есть/ушёл, free-лот не создаём;
      // иначе чистим ЛЮБЫЕ старые лоты (expired/sold/active — unique playerId,
      // иначе P2002) и создаём канонический free-лот (регенерация его не гасит)
      if (!soldThisWeekPlayerIds.has(p.id)) {
        extraOps.push(db.transferListing.deleteMany({ where: { playerId: p.id } }));
        extraOps.push(
          db.transferListing.create({
            data: {
              id: idFactory(),
              saveId,
              playerId: p.id,
              price: Math.max(10_000, Math.round(p.value * CONTRACT_FREE_PRICE_RATIO)),
              askFactor: 1.0,
              source: 'free',
              status: 'active',
              expiresAt: CONTRACT_FREE_TTL,
            },
          }),
        );
      }
      if (ctx.team.id === userTeamId) expiredFromUser.push(`${p.firstName} ${p.lastName}`);
    }
  }
  if (expiredFromUser.length > 0) {
    extraOps.push(
      newsOp(
        saveId, season, week, idFactory, 'transfer',
        `${expiredFromUser.join(', ')} покинул клуб по окончании контракта.`,
      ),
    );
  }

  // 5d. Дренаж рынка: старые слабые свободные агенты без лота тихо завершают карьеру
  const drainedIds = new Set<string>(); // исключаются из пополнения 6b (для них уже queued delete)
  for (const p of freeAgents) {
    if (p.age < CONTRACT_DRAIN_AGE || p.ovr < CONTRACT_DRAIN_OVR) continue;
    if (activeListingPlayerIds.has(p.id)) continue; // есть активный лот
    if (soldThisWeekPlayerIds.has(p.id)) continue; // куплен ИИ на этой неделе
    drainedIds.add(p.id);
    extraOps.push(db.transferListing.deleteMany({ where: { playerId: p.id } }));
    extraOps.push(db.player.delete({ where: { id: p.id } }));
  }

  // 6-FA [P4-QA]: свободные агенты тоже живут межсезоньем — старение/развитие/
  // пенсии/сброс статов (тем же applySeasonProgression, что и лиговым составам).
  // Раньше агенты не старели вовсе (поведение Фаз 1–3) — строгая форма инварианта
  // №5 (снапшот возраста = возраст ДО старения для ВСЕХ игроков сейва) это вскрыла.
  // Снапшот истории уже создан выше — порядок «запись → старение» сохранён.
  const faSurvivors = freeAgents.filter((p) => !drainedIds.has(p.id));
  const faOriginals = new Map(faSurvivors.map((p) => [p.id, { ...p }]));
  for (const p of faSurvivors) p.age += 1; // старение
  const faResult = applySeasonProgression(rng, faSurvivors);
  for (const r of faResult.retired) {
    extraOps.push(db.transferListing.deleteMany({ where: { playerId: r.id } }));
    extraOps.push(db.player.delete({ where: { id: r.id } }));
  }
  for (const p of faSurvivors) {
    const faOrig = faOriginals.get(p.id);
    if (!faOrig) continue;
    const faDiff = playerDiff(faOrig, p);
    if (faDiff) extraOps.push(db.player.update({ where: { id: p.id }, data: faDiff }));
  }

  // 6. Старение и межсезонье (формулы без изменений). Генерация клонов-пенсионеров
  // УДАЛЕНА (Фаза 3): академия (неделя 4) и покупки ИИ — единственные каналы молодёжи.
  const retiredIds: string[] = [];
  for (const ctx of ctxs.values()) {
    for (const p of ctx.players) p.age += 1; // старение
    const { retired } = applySeasonProgression(rng, ctx.players);
    for (const r of retired) retiredIds.push(r.id);
  }

  // Удаление ушедших (фикс QA-2: сначала лоты, затем игрок; чистит и free-лоты
  // истёкших пенсионеров из 5c — create-then-delete в одной транзакции безопасен)
  for (const id of retiredIds) {
    extraOps.push(db.transferListing.deleteMany({ where: { playerId: id } }));
    extraOps.push(db.player.delete({ where: { id } }));
  }

  // 6-ГОСТИ [P4] (§5.6-6): старение/развитие/пенсии + реген; контракты/Босман/
  // дренаж их НЕ трогают (изоляция §5.5 — гости не в ctxs и не в freeAgents)
  const guestRegenRng = mulberry32(hashString(`${saveId}:guestregen:${season}`));
  const GUEST_REGEN_POSITIONS: Position[] = ['GK', 'DC', 'DL', 'DR', 'DMC', 'MC', 'ML', 'MR', 'AMC', 'ST'];
  for (const g of guestSides) {
    for (const p of g.players) p.age += 1; // старение (как лиговым)
    const { retired } = applySeasonProgression(guestRegenRng, g.players);
    for (const r of retired) {
      extraOps.push(db.transferListing.deleteMany({ where: { playerId: r.id } }));
      extraOps.push(db.player.delete({ where: { id: r.id } }));
    }
    // РЕГЕН: за каждого ушедшего — юниор той же позиции (18–23 года, сила клуба ±3,
    // пул лиги гостя, contractUntil=99); инвариент EURO_GUEST_MIN_SQUAD
    const guestDef = leagueByCode((g.team.leagueCode ?? leagueCode) as LeagueCode)
      ?? leagueByCode(leagueCode)
      ?? LEAGUES[0];
    const newbies: PlayerLike[] = [];
    const regenAt = (position: Position): void => {
      const newbie = generatePlayer(
        guestRegenRng,
        clamp(g.team.strength + Math.round(gauss(guestRegenRng, 0, 3)), 30, 95),
        position,
        { fixedAge: randInt(guestRegenRng, 18, 23), pool: poolContextOf(guestDef), contractUntil: 99, idFactory },
      );
      newbie.teamId = g.team.id;
      newbie.shirtNumber = freeShirtNumbers(g.players, []);
      g.players.push(newbie);
      newbies.push(newbie);
    };
    for (const r of retired) regenAt(r.position);
    while (g.players.length < EURO_GUEST_MIN_SQUAD) regenAt(pick(guestRegenRng, GUEST_REGEN_POSITIONS));
    for (const newbie of newbies) {
      extraOps.push(db.player.create({ data: playerCreateData(saveId, newbie) }));
    }
  }

  // Зарплаты контрактов (Босман/ИИ-продления/free-агенты) — ПОСЛЕ
  // applySeasonProgression, который сбрасывает salary к номиналу; итог запишет дифф
  for (const ctx of ctxs.values()) {
    for (const p of ctx.players) {
      const s = contractSalaries.get(p.id);
      if (s !== undefined) p.salary = s;
    }
  }

  // 6b. Пополнение составов ИИ свободными агентами (фикс QA №20 Фазы 3):
  // после истечений/пенсий клубы ниже CONTRACT_AI_SQUAD_FLOOR подписывают лучших
  // незанятых свободных агентов — с балансом позиционных групп (aiReplenishmentPicks).
  // Побочный эффект — осушение пула безработных (до фикса: 1265 агентов за 3 сезона).
  // Клуб игрока НЕ пополняется автоматически: состав — зона его решений (рынок/продления).
  const signPool = freeAgents.filter(
    (p) => p.teamId === null
      && !drainedIds.has(p.id)
      && !activeListingPlayerIds.has(p.id)
      && !soldThisWeekPlayerIds.has(p.id),
  );
  const needing = [...ctxs.values()]
    .filter((c) => c.team.id !== userTeamId)
    .map((c) => ({ ctx: c, size: c.players.filter((p) => p.teamId === c.team.id).length }))
    .filter((x) => x.size < CONTRACT_AI_SQUAD_FLOOR)
    .sort((a, b) => a.size - b.size); // слабейшие пополняются первыми
  for (const { ctx } of needing) {
    const squadNow = ctx.players.filter((p) => p.teamId === ctx.team.id);
    const picks = aiReplenishmentPicks({
      squad: squadNow,
      freeAgents: signPool,
      target: CONTRACT_AI_SQUAD_FLOOR,
      maxSignings: AI_SIGN_MAX_PER_SEASON,
    });
    for (const p of picks) {
      const idx = signPool.indexOf(p);
      if (idx >= 0) signPool.splice(idx, 1); // один агент — один клуб
      const shirtNumber = freeShirtNumbers(ctx.players, []);
      p.teamId = ctx.team.id;
      p.contractUntil = season + contractAiYears(p.age);
      p.shirtNumber = shirtNumber;
      p.salary = computeSalary(p.value);
      p.condition = CONDITION_MAX;
      p.goals = 0;
      p.assists = 0;
      p.apps = 0;
      p.yellowCards = 0;
      p.redCards = 0;
      p.cupGoals = 0;
      p.cupAssists = 0;
      p.cleanSheets = 0;
      p.ratingSum = 0;
      p.ratingApps = 0;
      ctx.players.push(p); // старение уже прошло — подписан «как есть» на новый сезон
      extraOps.push(db.transferListing.deleteMany({ where: { playerId: p.id } }));
      extraOps.push(
        db.player.update({
          where: { id: p.id },
          data: {
            teamId: ctx.team.id,
            contractUntil: p.contractUntil,
            shirtNumber,
            salary: p.salary,
            condition: CONDITION_MAX,
            goals: 0,
            assists: 0,
            apps: 0,
            yellowCards: 0,
            redCards: 0,
            cupGoals: 0,
            cupAssists: 0,
            cleanSheets: 0,
            ratingSum: 0,
            ratingApps: 0,
          },
        }),
      );
    }
  }

  // 7. [P4] СМЕНА СТИЛЕЙ ИИ-клубов (§5.6-7): p=0.25 (топ-6: 0.10); при смене —
  // тактические поля профиля AI_STYLES, p=0.15 новое имя тренера (клуб игрока/гости — не трогаем)
  const styleRng = mulberry32(hashString(`${saveId}:stylechg:${season}`));
  const styleChanges = aiStyleChangesFor(
    styleRng,
    leagueCode,
    Array.from(ctxs.values())
      .filter((c) => c.team.id !== userTeamId)
      .map((c) => ({ id: c.team.id, strength: c.team.strength, aiStyle: coerceAiStyle(c.team.aiStyle) })),
  );
  for (const change of styleChanges) {
    const ctx = ctxs.get(change.teamId);
    if (!ctx) continue;
    const tactic = AI_STYLES[change.nextStyle].tactic;
    const coachName = change.renameCoach || ctx.team.aiCoachName === null
      ? `${pick(styleRng, NAME_POOLS[pool.base].first)} ${pick(styleRng, NAME_POOLS[pool.base].last)}`
      : ctx.team.aiCoachName;
    ctx.team.aiStyle = change.nextStyle;
    ctx.team.formation = tactic.formation;
    ctx.team.mentality = tactic.mentality;
    ctx.team.tempo = tactic.tempo;
    ctx.team.pressing = tactic.pressing;
    ctx.team.defLine = tactic.defLine;
    ctx.team.playStyle = tactic.playStyle;
    ctx.team.aiCoachName = coachName;
    extraOps.push(
      db.team.update({
        where: { id: change.teamId },
        data: {
          aiStyle: change.nextStyle,
          formation: tactic.formation,
          mentality: tactic.mentality,
          tempo: tactic.tempo,
          pressing: tactic.pressing,
          defLine: tactic.defLine,
          playStyle: tactic.playStyle,
          aiCoachName: coachName,
        },
      }),
    );
  }

  // 8. [P4] ЕВРО следующего сезона (§5.6-8): квалификация по финальной таблице
  // (своя лига — топ-квота по месту), создание недостающих гостей, сброс состояния
  const nextSeason = season + 1;
  const placeById = new Map(standings.map((s) => [s.teamId, s.place] as const));
  const nextRoster = resolveEuroRoster({
    ownLeague: leagueCode,
    leagueTeams: Array.from(ctxs.values()).map((c) => ({
      id: c.team.id,
      strength: c.team.strength,
      place: placeById.get(c.team.id) ?? null,
    })),
    existingGuests: guestSides.map((g) => ({
      id: g.team.id,
      leagueCode: g.team.leagueCode ?? leagueCode,
      name: g.team.name,
    })),
    rng: mulberry32(hashString(`${saveId}:euroqual:${nextSeason}`)),
    guestRng: mulberry32(hashString(`${saveId}:euroguests:${nextSeason}`)),
    saveId,
    idFactory,
  });
  if (nextRoster.newGuests.length > 0) {
    extraOps.push(db.team.createMany({ data: nextRoster.newGuests.map((g) => g.team) }));
    extraOps.push(db.player.createMany({ data: nextRoster.newGuests.flatMap((g) => g.players) }));
  }
  const userQualifiedEuro = nextRoster.ownTeamIds.includes(userTeamId);
  extraOps.push(
    newsOp(
      saveId, season, week, idFactory, 'euro',
      userQualifiedEuro
        ? `Кубок Европы: ваш клуб квалифицировался в турнир сезона ${nextSeason}!`
        : `Кубок Европы: в турнир сезона ${nextSeason} ваш клуб не попал.`,
    ),
  );

  // Бонусы лауреатам клуба игрока — ПОСЛЕ межсезонья (мораль/стоимость
  // сохраняются в новом сезоне; сами награды вычислены до старения)
  const retiredSet = new Set(retiredIds);
  const awardNews = applyAwardBonuses(
    drafts,
    userTeamId,
    allPlayers.filter((p) => !retiredSet.has(p.id)),
  );

  // 5. Новый календарь лиги: карусель → сквозные недели того же плана
  const teamIds = Array.from(ctxs.values()).map((c) => c.team.id);
  for (const m of generateCalendar(teamIds, idFactory)) {
    extraOps.push(
      db.match.create({
        data: {
          id: m.id,
          saveId,
          season: season + 1,
          week: leagueWeekOf(plan, m.week),
          homeTeamId: m.homeTeamId,
          awayTeamId: m.awayTeamId,
          competition: 'league',
          cupRound: null,
        },
      }),
    );
  }

  // 9. Рынок: полная регенерация (пул имён лиги); free-лоты истёкших контрактов
  // НЕ гасим (Фаза 3, ловушка §10.3 — иначе «истёкшие» исчезают с рынка в момент создания)
  extraOps.push(
    db.transferListing.updateMany({
      where: { saveId, status: 'active', source: { not: 'free' } },
      data: { status: 'expired' },
    }),
  );
  const regenRng = mulberry32(hashString(`${saveId}:marketregen:${season}`));
  const topUp = marketTopUpCount(regenRng, 0);
  for (let i = 0; i < topUp; i++) {
    const gen = generateMarketListing(regenRng, pool);
    extraOps.push(db.player.create({ data: playerCreateData(saveId, gen.player) }));
    extraOps.push(
      db.transferListing.create({
        data: {
          id: idFactory(),
          saveId,
          playerId: gen.player.id,
          price: gen.price,
          askFactor: gen.askFactor,
          source: 'market',
          status: 'active',
          expiresAt: gen.expiresAt,
        },
      }),
    );
  }

  // 8. Призовые лиги
  extraOps.push(
    db.financeRecord.create({
      data: {
        id: idFactory(),
        saveId,
        season,
        week,
        kind: 'income',
        category: 'prize',
        amount: prize,
        description: `Призовые за ${userPlace} место в сезоне ${season}`,
      },
    }),
  );

  // Новости итогов (4 ключевые награды + бонусы лауреатам клуба игрока)
  const byType = new Map(drafts.map((d) => [d.type, d]));
  const champ = byType.get('champion');
  if (champ) extraOps.push(newsOp(saveId, season, week, idFactory, 'info', `Чемпион лиги: ${champ.label}`));
  const cupW = byType.get('cup_winner');
  if (cupW) {
    extraOps.push(
      newsOp(saveId, season, week, idFactory, 'cup', `Обладатель кубка: ${cupW.label.replace(' — обладатель кубка', '')}`),
    );
  }
  const scorer = byType.get('top_scorer');
  if (scorer) extraOps.push(newsOp(saveId, season, week, idFactory, 'info', `Золотая бутса: ${scorer.label}`));
  const mvp = byType.get('mvp');
  if (mvp) extraOps.push(newsOp(saveId, season, week, idFactory, 'info', `Игрок сезона (MVP): ${mvp.label}`));
  for (const text of awardNews) {
    extraOps.push(newsOp(saveId, season, week, idFactory, 'info', text));
  }

  // Вердикт правления — ПОСЛЕДНЕЙ новостью перехода (в ленте (desc по createdAt)
  // оказывается первой строкой нового сезона — §10.2)
  for (const text of verdictNews) {
    extraOps.push(newsOp(saveId, season, week, idFactory, 'board', text));
  }

  // Сброс кубка — в основном GameSave.update (cupRound=0, cupAliveTeamIds=null)
  // Фаза 4: евро-поля следующего сезона — тоже в основном GameSave.update

  return {
    standings,
    place: userPlace,
    prize,
    bonus,
    awards: awardDtos,
    sacked,
    boardVerdict: boardVerdictDto,
    confidenceNext,
    nextTarget,
    euroNextState: {
      season: nextSeason,
      participants: serializeEuroTeamIds(nextRoster.teamIds),
      alive: serializeEuroTeamIds(nextRoster.teamIds),
    },
    euroNextDto: {
      qualifiedNext: userQualifiedEuro,
      label: userQualifiedEuro
        ? 'Клуб квалифицировался в Кубок Европы'
        : 'Клуб не прошёл квалификацию в Кубок Европы',
    },
    extraOps,
  };
}

function newsOp(
  saveId: string,
  season: number,
  week: number,
  idFactory: () => string,
  type: NewsType,
  message: string,
): Prisma.PrismaPromise<unknown> {
  return db.newsItem.create({
    data: { id: idFactory(), saveId, season, week, type, message },
  });
}

// ── Симуляция недели ──────────────────────────────────────────────────────

export async function simulateWeek(saveId: string): Promise<WeekResultPayload> {
  const save = await db.gameSave.findUnique({ where: { id: saveId }, include: { team: true } });
  if (!save || !save.teamId || !save.team || save.status !== 'active') {
    throw new ApiGameError('NO_SAVE', 404);
  }

  const leagueCode = save.leagueCode as LeagueCode;
  const def = leagueByCode(leagueCode);
  if (!def) throw new ApiGameError('NO_SAVE', 404);
  const plan = buildSeasonPlan(leagueCode);
  const N = def.teamCount;
  const pool = poolContextOf(def);

  const season = save.season;
  const week = save.week;
  if (week > plan.totalWeeks) throw new ApiGameError('WEEK_ALREADY_PLAYED', 409);
  const slot = weekSlotAt(plan, week);
  const userTeamId = save.teamId;
  const idFactory = () => crypto.randomUUID();

  // Фаза 4 (§5.2-0): ЛИГОВЫЕ команды — БЕЗ гостей (изоляция §5.5: ctxs/кубок/
  // рынок/босман/академия/правление работают только с ними); гости — отдельным
  // запросом для евроматчей/восстановления/перехода
  const teams = await db.team.findMany({ where: { saveId, isEuroGuest: false } });
  const guestTeams = await db.team.findMany({ where: { saveId, isEuroGuest: true } });
  const teamById = new Map([...teams, ...guestTeams].map((t) => [t.id, t]));
  const playerRows = await db.player.findMany({ where: { saveId, teamId: { not: null } } });
  const weekMatches = await db.match.findMany({ where: { saveId, season, week } });

  // Оригинальные значения игроков — для диффа перед записью в БД
  const originals = new Map<string, PlayerLike>();
  for (const row of playerRows) originals.set(row.id, { ...(row as unknown as PlayerLike) });

  // ── Фаза 3, шаг 0: ленивая миграция легаси-контрактов ──
  // (сейвы до диффа имеют contractUntil = 3; если сезон уже ≥ 4 — продлеваем
  // до season+1..2, иначе массовое истечение при первом переходе; дифф запишет)
  const migRng = mulberry32(hashString(`${saveId}:contractmig:${season}`));
  for (const row of playerRows) {
    const p = row as unknown as PlayerLike;
    if (p.teamId !== null && p.contractUntil < season) {
      p.contractUntil = season + randInt(migRng, 1, 2);
    }
  }

  // ── Фаза 4, шаг 0b: ленивая миграция стилей легаси-ИИ (aiCoachName === null) ──
  // guessAiStyle по ТЕКУЩИМ тактическим полям (баланс не меняется), имя — из пула
  // лиги; новые сейвы пропускают (имя уже назначено при генерации)
  const styleMigOps: PrismaOps = [];
  const styleMigRng = mulberry32(hashString(`${saveId}:stylemig:${season}`));
  for (const team of teams) {
    if (team.isUserTeam || team.aiCoachName !== null) continue;
    const style = guessAiStyle({
      formation: team.formation,
      mentality: team.mentality,
      tempo: team.tempo,
      pressing: team.pressing,
      playStyle: team.playStyle,
    });
    const coachName = `${pick(styleMigRng, NAME_POOLS[def.basePool].first)} ${pick(styleMigRng, NAME_POOLS[def.basePool].last)}`;
    team.aiStyle = style;
    team.aiCoachName = coachName;
    styleMigOps.push(
      db.team.update({ where: { id: team.id }, data: { aiStyle: style, aiCoachName: coachName } }),
    );
  }

  // ── Фаза 3, шаг 0: ленивая инициализация правления (легаси-сейвы) ──
  let boardLazyInit: { target: BoardTargetInfo; honeymoonUntilWeek: number } | null = null;
  const storedBoardTarget: BoardTargetCode | null =
    save.boardTarget && save.boardTarget in BOARD_TARGET_LABELS
      ? (save.boardTarget as BoardTargetCode)
      : null;
  if (storedBoardTarget === null) {
    const lazyTarget = nextSeasonTarget({
      teamCount: N,
      teams: teams.map((t) => ({ id: t.id, strength: t.strength })),
      userTeamId,
      prevPlace: null,
      harderByOverperformance: false,
    });
    boardLazyInit = {
      target: lazyTarget,
      honeymoonUntilWeek: Math.min(week + BOARD_HONEYMOON_WEEKS, plan.totalWeeks),
    };
  }
  const boardTargetCode: BoardTargetCode | null =
    storedBoardTarget ?? boardLazyInit?.target.code ?? null;
  const boardTargetPlace: number =
    save.boardTargetPlace ?? boardLazyInit?.target.place ?? N;

  // Игроки, травмированные ДО этой недели (им декремент в конце)
  const preInjured = new Set(playerRows.filter((p) => p.injuryWeeks > 0).map((p) => p.id));

  const pendingNews: PendingNews[] = [];
  const transfersTexts: string[] = [];
  const played: PlayedMatch[] = [];
  const scheduledCreates: ScheduledCupMatch[] = [];
  const injuriesMap = new Map<string, number>();

  // ── Контексты команд + составы ──
  const playersByTeam = new Map<string, PlayerLike[]>();
  for (const row of playerRows) {
    const list = playersByTeam.get(row.teamId as string) ?? [];
    list.push(row as unknown as PlayerLike);
    playersByTeam.set(row.teamId as string, list);
  }

  const ctxs = new Map<string, TeamCtx>();
  for (const team of teams) {
    const players = playersByTeam.get(team.id) ?? [];
    const isUser = team.id === userTeamId;
    let lineup: (string | null)[];
    let bench: string[];
    const savedLineup = parseLineup(team.lineup);
    if (isUser && isLineupValid(savedLineup, players)) {
      lineup = savedLineup as string[];
      bench = parseLineup(team.bench) ?? [];
    } else {
      const auto = autoLineup(players, coerceFormation(team.formation));
      lineup = auto.lineup;
      bench = auto.bench;
      if (isUser) {
        pendingNews.push({
          id: idFactory(),
          type: 'info',
          message: 'Ассистент выставил состав автоматически: проверьте расстановку во вкладке «Тактика».',
        });
      }
    }
    ctxs.set(team.id, { team, players, lineup, bench, isUser });
  }

  // ── Фаза 4 (§5.2-В/§5.5): стороны гостей евро — отдельно от ctxs; их игроки
  // уже в playerRows/playersByTeam (дифф пишет изменения, в т.ч. евроматчей) ──
  const guestSides: { team: TeamModel; players: PlayerLike[] }[] = guestTeams.map((team) => ({
    team,
    players: playersByTeam.get(team.id) ?? [],
  }));

  const userCtx = ctxs.get(userTeamId);
  if (!userCtx) throw new ApiGameError('NO_SAVE', 404);

  // ── Прошлые ЛИГОВЫЕ матчи сезона (для таблицы) ──
  const playedLeagueBefore = await db.match.findMany({
    where: { saveId, season, status: 'played', competition: 'league' },
    select: { homeTeamId: true, awayTeamId: true, homeGoals: true, awayGoals: true, week: true },
  });
  const standingTeams: StandingTeamInput[] = teams.map((t) => ({
    id: t.id,
    name: t.name,
    shortName: t.shortName,
    colorPrimary: t.colorPrimary,
    colorSecondary: t.colorSecondary,
    isUser: t.isUserTeam,
  }));
  const playedLeagueInputs: StandingMatchInput[] = playedLeagueBefore
    .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
    .map((m) => ({
      homeTeamId: m.homeTeamId,
      awayTeamId: m.awayTeamId,
      homeGoals: m.homeGoals as number,
      awayGoals: m.awayGoals as number,
      week: m.week,
    }));

  let weekType: 'league' | 'cup' = slot.type;
  let weekLabel: string;
  let cupNextRound: { round: number; label: string; pairs: CupMatchDTO[] } | null = null;
  let cupPrize = 0;
  let cupWinnerTeamId: string | null = null;
  let newCupRound = save.cupRound;
  let newCupAlive: string | null = save.cupAliveTeamIds;
  // Фаза 4 (§5.2-12): матчи клуба игрока недели — 0..2 в порядке игры ([лига] | [кубок?, евро?])
  const userMatchDtos: UserMatchResultDTO[] = [];
  let standings: StandingRow[];
  // Фаза 3/4: матчи клуба игрока — входы еженедельного пересчёта правления (1..2)
  const boardMatchInputs: BoardMatchInput[] = [];
  // Фаза 4 (§5.2 Б.3): команды, сыгравшие ≥1 матч на этой неделе (кубок ∪ евро)
  const weekMatchTeamIds = new Set<string>();
  // Фаза 4: состояние Кубка Европы недели
  let euroPrize = 0;
  let newEuroSeason = save.euroSeason;
  let newEuroRound = save.euroRound;
  let newEuroAlive = save.euroAliveTeamIds;
  let newEuroParticipants = save.euroParticipants;
  let euroRoundDto: { round: number; label: string; drawn: boolean; pairs: EuroMatchDTO[] } | null = null;
  /** Гости, созданные ленивой инициализацией ЭТОЙ недели (createMany в транзакции). */
  const lazyEuroNewGuests: EuroGuestTeamGen[] = [];

  if (slot.type === 'league') {
    // ════════════════ ЛИГОВАЯ НЕДЕЛЯ ════════════════
    const leagueMatches = weekMatches.filter((m) => m.competition === 'league');
    const userMatchRow = leagueMatches.find(
      (m) => m.homeTeamId === userTeamId || m.awayTeamId === userTeamId,
    );
    if (!userMatchRow || userMatchRow.status === 'played' || leagueMatches.length === 0) {
      throw new ApiGameError('WEEK_ALREADY_PLAYED', 409);
    }
    const leagueRound = slot.leagueRound ?? 0;
    weekLabel = `Тур ${leagueRound}/${plan.leagueWeeks}`;

    // Фикс QA-1: контексты строго по ID команд из строки матча
    const homeCtx = ctxs.get(userMatchRow.homeTeamId);
    const awayCtx = ctxs.get(userMatchRow.awayTeamId);
    if (!homeCtx || !awayCtx || homeCtx === awayCtx) throw new ApiGameError('NO_SAVE', 404);
    const userHome = userMatchRow.homeTeamId === userTeamId;

    const matchRng = mulberry32(hashString(`${saveId}:${season}:${week}:${userMatchRow.id}`));
    const userResult = simulateMatch(matchRng, tacticInputOf(homeCtx), tacticInputOf(awayCtx));

    played.push({
      id: userMatchRow.id,
      homeTeamId: userMatchRow.homeTeamId,
      awayTeamId: userMatchRow.awayTeamId,
      week,
      isNeutral: false,
      competition: 'league',
      cupRound: null,
      homeGoals: userResult.homeGoals,
      awayGoals: userResult.awayGoals,
      homePens: null,
      awayPens: null,
      winnerTeamId: null,
      events: userResult.events,
      stats: userResult.stats,
      isNew: false,
    });
    for (const inj of userResult.injuries) injuriesMap.set(inj.playerId, inj.weeks);

    userMatchDtos.push({
      matchId: userMatchRow.id,
      home: toTeamBrief(homeCtx.team),
      away: toTeamBrief(awayCtx.team),
      homeGoals: userResult.homeGoals,
      awayGoals: userResult.awayGoals,
      homePens: null,
      awayPens: null,
      winnerTeamId: null,
      isNeutral: false,
      events: userResult.events,
      stats: userResult.stats,
      competition: 'league',
      homeXI: radarXiOf(homeCtx),
      awayXI: radarXiOf(awayCtx),
    });

    // ИИ-матчи тура
    const aiResults = new Map<string, { homeGoals: number; awayGoals: number; events: MatchEvent[] }>();
    for (const matchRow of leagueMatches) {
      if (matchRow.id === userMatchRow.id) continue;
      const home = ctxs.get(matchRow.homeTeamId);
      const away = ctxs.get(matchRow.awayTeamId);
      if (!home || !away) continue;
      const rng = mulberry32(hashString(`${saveId}:${season}:${week}:${matchRow.id}`));
      const res = simulateAiMatch(
        rng,
        { teamId: home.team.id, name: home.team.name, strength: home.team.strength, players: home.players },
        { teamId: away.team.id, name: away.team.name, strength: away.team.strength, players: away.players },
      );
      aiResults.set(matchRow.id, res);
      played.push({
        id: matchRow.id,
        homeTeamId: matchRow.homeTeamId,
        awayTeamId: matchRow.awayTeamId,
        week,
        isNeutral: false,
        competition: 'league',
        cupRound: null,
        homeGoals: res.homeGoals,
        awayGoals: res.awayGoals,
        homePens: null,
        awayPens: null,
        winnerTeamId: null,
        events: res.events,
        stats: null,
        isNew: false,
      });
    }

    // Таблица (прошлые туры + этот)
    standings = computeStandings(standingTeams, [
      ...playedLeagueInputs,
      ...played.map((m) => ({
        homeTeamId: m.homeTeamId,
        awayTeamId: m.awayTeamId,
        homeGoals: m.homeGoals,
        awayGoals: m.awayGoals,
        week,
      })),
    ]);

    // Пост-матч: все команды; cleanSheets стартовым GK
    // Фаза 4: per-match эффекты (замены матча клуба игрока — минутный drain);
    // недельное восстановление — один раз ПОСЛЕ цикла (§5.2 А)
    for (const ctx of ctxs.values()) {
      let outcome: 'W' | 'D' | 'L';
      let events: MatchEvent[];
      let conceded: number | null = null;
      let subs: SubRecord[] | undefined;
      if (ctx === homeCtx || ctx === awayCtx) {
        const isHome = ctx === homeCtx;
        const my = isHome ? userResult.homeGoals : userResult.awayGoals;
        const opp = isHome ? userResult.awayGoals : userResult.homeGoals;
        outcome = my > opp ? 'W' : my === opp ? 'D' : 'L';
        events = userResult.events.filter((e) => e.teamId === ctx.team.id);
        conceded = opp;
        subs = isHome ? userResult.homeSubs : userResult.awaySubs;
      } else {
        const matchRow = leagueMatches.find(
          (m) => m.id !== userMatchRow.id && (m.homeTeamId === ctx.team.id || m.awayTeamId === ctx.team.id),
        );
        const res = matchRow ? aiResults.get(matchRow.id) : undefined;
        if (matchRow && res) {
          const isHome = matchRow.homeTeamId === ctx.team.id;
          const my = isHome ? res.homeGoals : res.awayGoals;
          const opp = isHome ? res.awayGoals : res.homeGoals;
          outcome = my > opp ? 'W' : my === opp ? 'D' : 'L';
          events = res.events.filter((e) => e.teamId === ctx.team.id);
          conceded = opp;
        } else {
          outcome = 'D';
          events = [];
        }
      }

      applyMatchEffects(
        {
          players: ctx.players,
          starterIds: new Set(ctx.lineup.filter((x): x is string => !!x)),
          benchIds: new Set(ctx.bench),
          events,
          outcome,
          tempo: coerceTempo(ctx.team.tempo),
          pressing: coercePressing(ctx.team.pressing),
          competition: 'league',
          goalsConceded: conceded,
          subs,
        },
        injuriesMap,
        mulberry32(hashString(`${saveId}:rating:${season}:${week}:${ctx.team.id}`)),
      );
      if (conceded !== null) creditCleanSheet(ctx, conceded);
    }

    // Фаза 4 (§5.2 А): недельное восстановление — ровно 1 раз (лиговая неделя: все играли)
    for (const ctx of ctxs.values()) applyWeeklyRecovery(ctx.players);

    // Фаза 3: матч клуба игрока — вход еженедельного пересчёта правления
    const myGoals = userHome ? userResult.homeGoals : userResult.awayGoals;
    const oppGoals = userHome ? userResult.awayGoals : userResult.homeGoals;
    const oppCtx = userHome ? awayCtx : homeCtx;
    boardMatchInputs.push({
      outcome: myGoals > oppGoals ? 'W' : myGoals === oppGoals ? 'D' : 'L',
      myStrength: userCtx.team.strength,
      oppStrength: oppCtx.team.strength,
      competition: 'league',
      roundPassed: false,
      wonFinal: false,
      upsetCupLoss: false,
    });

    // Новость о результате
    const outcomeWord = myGoals > oppGoals ? 'Победа' : myGoals === oppGoals ? 'Ничья' : 'Поражение';
    pendingNews.push({
      id: idFactory(),
      type: 'result',
      message: `Тур ${leagueRound}: ${homeCtx.team.name} ${userResult.homeGoals}:${userResult.awayGoals} ${awayCtx.team.name}. ${outcomeWord}!`,
    });
    for (const e of userResult.events) {
      if (e.type === 'red') {
        pendingNews.push({
          id: idFactory(),
          type: 'info',
          message: `${e.playerName ?? 'Игрок'} удалён в матче ${leagueRound}-го тура.`,
        });
      } else if (e.type === 'injury') {
        pendingNews.push({ id: idFactory(), type: 'injury', message: e.text });
      }
    }
  } else {
    // ════════════════ КУБКОВАЯ НЕДЕЛЯ ════════════════
    const round = slot.cupRound as number;
    const isFinal = round === plan.cupRounds;
    const label = cupRoundLabel(N, round);
    weekLabel = `Кубок · ${label}`;

    const existingRound = weekMatches.filter((m) => m.competition === 'cup' && m.cupRound === round);
    if (existingRound.length > 0 && existingRound.every((m) => m.status === 'played')) {
      throw new ApiGameError('WEEK_ALREADY_PLAYED', 409);
    }

    // Жеребьёвка (лениво — раунд 1; раунды 2+ разведены заранее)
    let participantIds: string[] = [];
    const isNewDraw = existingRound.length === 0;
    if (isNewDraw) {
      if (round === 1) {
        if (N <= 16) {
          participantIds = teams.map((t) => t.id);
        } else {
          // season=1 — слабейшие по силе; season≥2 — худшие места финальной
          // таблицы ПРОШЛОГО сезона (competition='league')
          let prevStandings: { teamId: string; place: number }[] | null = null;
          if (season >= 2) {
            const prevLeague = await db.match.findMany({
              where: { saveId, season: season - 1, competition: 'league', status: 'played' },
              select: { homeTeamId: true, awayTeamId: true, homeGoals: true, awayGoals: true, week: true },
            });
            if (prevLeague.length > 0) {
              const inputs = prevLeague
                .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
                .map((m) => ({
                  homeTeamId: m.homeTeamId,
                  awayTeamId: m.awayTeamId,
                  homeGoals: m.homeGoals as number,
                  awayGoals: m.awayGoals as number,
                  week: m.week,
                }));
              prevStandings = computeStandings(standingTeams, inputs).map((s) => ({
                teamId: s.teamId,
                place: s.place,
              }));
            }
          }
          participantIds = prelimParticipants(
            teams.map((t) => ({ id: t.id, strength: t.strength })),
            prevStandings,
            N,
          );
        }
      } else {
        participantIds = parseTeamIdList(save.cupAliveTeamIds);
      }
      if (participantIds.length < 2 || participantIds.length % 2 !== 0) {
        console.error(`[week] кубковое состояние повреждено: раунд ${round}, участников ${participantIds.length}`);
        throw new ApiGameError('UNKNOWN', 500);
      }
    }

    // Пары раунда: из БД (scheduled) или свежая жеребьёвка
    let pairs: { id: string; pair: CupPair }[];
    if (isNewDraw) {
      const drawRng = mulberry32(hashString(`${saveId}:cupdraw:${season}:${round}`));
      const seeds = participantIds.map((id) => ({
        id,
        strength: teamById.get(id)?.strength ?? 60,
      }));
      const drawn = drawCupRound(drawRng, seeds, isFinal);
      pairs = drawn.map((pair) => ({ id: idFactory(), pair }));
    } else {
      pairs = existingRound.map((m) => ({
        id: m.id,
        pair: { homeTeamId: m.homeTeamId, awayTeamId: m.awayTeamId, isNeutral: m.isNeutral },
      }));
    }

    // Матч клуба игрока (может НЕ БЫТЬ — вылетел / не участвует в раунде)
    const userPair = pairs.find(
      (p) => p.pair.homeTeamId === userTeamId || p.pair.awayTeamId === userTeamId,
    );

    // Таблица лиги (для финансов и автотренировок ИИ) — лиговые матчи из БД
    standings = computeStandings(standingTeams, playedLeagueInputs);

    const roundResults = new Map<string, {
      homeGoals: number; awayGoals: number; events: MatchEvent[];
      homePens: number | null; awayPens: number | null; winnerTeamId: string;
      homeSubs: SubRecord[]; awaySubs: SubRecord[];
    }>();

    // ── Матч клуба игрока: полный движок + покиковая серия пенальти ──
    if (userPair) {
      const homeCtx = ctxs.get(userPair.pair.homeTeamId);
      const awayCtx = ctxs.get(userPair.pair.awayTeamId);
      if (!homeCtx || !awayCtx || homeCtx === awayCtx) throw new ApiGameError('NO_SAVE', 404);
      const userHome = userPair.pair.homeTeamId === userTeamId;

      const matchRng = mulberry32(hashString(`${saveId}:${season}:${week}:${userPair.id}`));
      const userResult = simulateMatch(
        matchRng,
        tacticInputOf(homeCtx),
        tacticInputOf(awayCtx),
        { neutral: userPair.pair.isNeutral },
      );
      for (const inj of userResult.injuries) injuriesMap.set(inj.playerId, inj.weeks);

      let homePens: number | null = null;
      let awayPens: number | null = null;
      let winnerTeamId: string;
      if (userResult.homeGoals === userResult.awayGoals) {
        // Серия пенальти — покиково, события в ту же ленту
        const homeById = new Map(homeCtx.players.map((p) => [p.id, p]));
        const awayById = new Map(awayCtx.players.map((p) => [p.id, p]));
        const homeTakers = shootoutTakers(homeCtx.lineup, homeById);
        const awayTakers = shootoutTakers(awayCtx.lineup, awayById);
        const homeGk = lineupGoalkeeper(homeCtx.lineup, homeById);
        const awayGk = lineupGoalkeeper(awayCtx.lineup, awayById);
        if (homeGk && awayGk && homeTakers.length > 0 && awayTakers.length > 0) {
          const shootout = simulatePenaltyShootout(matchRng, {
            homeName: homeCtx.team.name,
            awayName: awayCtx.team.name,
            homeTeamId: homeCtx.team.id,
            awayTeamId: awayCtx.team.id,
            homeTakers,
            awayTakers,
            homeGk,
            awayGk,
            events: userResult.events,
          });
          homePens = shootout.homePens;
          awayPens = shootout.awayPens;
          winnerTeamId = shootout.winnerIsHome ? homeCtx.team.id : awayCtx.team.id;
        } else {
          // вырожденный состав — монетка (защита)
          winnerTeamId = matchRng() < 0.5 ? homeCtx.team.id : awayCtx.team.id;
        }
      } else {
        winnerTeamId = userResult.homeGoals > userResult.awayGoals ? homeCtx.team.id : awayCtx.team.id;
      }

      roundResults.set(userPair.id, {
        homeGoals: userResult.homeGoals,
        awayGoals: userResult.awayGoals,
        events: userResult.events,
        homePens,
        awayPens,
        winnerTeamId,
        homeSubs: userResult.homeSubs,
        awaySubs: userResult.awaySubs,
      });
      played.push({
        id: userPair.id,
        homeTeamId: userPair.pair.homeTeamId,
        awayTeamId: userPair.pair.awayTeamId,
        week,
        isNeutral: userPair.pair.isNeutral,
        competition: 'cup',
        cupRound: round,
        homeGoals: userResult.homeGoals,
        awayGoals: userResult.awayGoals,
        homePens,
        awayPens,
        winnerTeamId,
        events: userResult.events,
        stats: userResult.stats,
        isNew: isNewDraw,
      });

      userMatchDtos.push({
        matchId: userPair.id,
        home: toTeamBrief(homeCtx.team),
        away: toTeamBrief(awayCtx.team),
        homeGoals: userResult.homeGoals,
        awayGoals: userResult.awayGoals,
        homePens,
        awayPens,
        winnerTeamId,
        isNeutral: userPair.pair.isNeutral,
        events: userResult.events,
        stats: userResult.stats,
        competition: 'cup',
        homeXI: radarXiOf(homeCtx),
        awayXI: radarXiOf(awayCtx),
      });

      // Новость о кубковом матче
      const won = winnerTeamId === userTeamId;
      // Фаза 3: матч клуба игрока — вход еженедельного пересчёта правления
      // (конвенция как в applyPostMatch: победа по пенальти = победа)
      const myGoalsCup = userHome ? userResult.homeGoals : userResult.awayGoals;
      const oppGoalsCup = userHome ? userResult.awayGoals : userResult.homeGoals;
      const oppCtxCup = userHome ? awayCtx : homeCtx;
      boardMatchInputs.push({
        outcome: won ? 'W' : myGoalsCup === oppGoalsCup ? 'L' : myGoalsCup > oppGoalsCup ? 'W' : 'L',
        myStrength: userCtx.team.strength,
        oppStrength: oppCtxCup.team.strength,
        competition: 'cup',
        roundPassed: won,
        wonFinal: isFinal && won,
        upsetCupLoss: !won && userCtx.team.strength - oppCtxCup.team.strength >= BOARD_STRENGTH_GAP,
      });
      const outcomeWord = won ? 'Победа!' : 'Поражение';
      const pensSuffix = homePens !== null ? ` (пен. ${homePens}:${awayPens})` : '';
      pendingNews.push({
        id: idFactory(),
        type: 'result',
        message: `Кубок · ${label}: ${homeCtx.team.name} ${userResult.homeGoals}:${userResult.awayGoals}${pensSuffix} ${awayCtx.team.name}. ${outcomeWord}`,
      });
      for (const e of userResult.events) {
        if (e.type === 'red') {
          pendingNews.push({
            id: idFactory(),
            type: 'info',
            message: `${e.playerName ?? 'Игрок'} удалён в кубковом матче (${label}).`,
          });
        } else if (e.type === 'injury') {
          pendingNews.push({ id: idFactory(), type: 'injury', message: e.text });
        }
      }

      // Призовые клуба игрока (финал: победа/финалист; раунд: победа)
      if (isFinal) {
        cupPrize = won ? prizeForRound(N, round) : finalistPrize();
      } else if (won) {
        cupPrize = prizeForRound(N, round);
      }
    } else {
      // Клуб игрока не участвует в раунде — отдых (+10 состояния в блоке ниже)
      pendingNews.push({
        id: idFactory(),
        type: 'cup',
        message: `Кубок · ${label}: ваша команда не участвует в раунде — игроки отдыхают и восстанавливаются.`,
      });
    }

    // ── ИИ-матчи раунда (пенальти вероятностно) ──
    for (const { id, pair } of pairs) {
      if (roundResults.has(id)) continue;
      const home = ctxs.get(pair.homeTeamId);
      const away = ctxs.get(pair.awayTeamId);
      if (!home || !away) continue;
      const rng = mulberry32(hashString(`${saveId}:${season}:${week}:${id}`));
      const res = simulateAiCupMatch(
        rng,
        { teamId: home.team.id, name: home.team.name, strength: home.team.strength, players: home.players },
        { teamId: away.team.id, name: away.team.name, strength: away.team.strength, players: away.players },
        { neutral: pair.isNeutral },
      );
      roundResults.set(id, { ...res, homeSubs: [], awaySubs: [] });
      played.push({
        id,
        homeTeamId: pair.homeTeamId,
        awayTeamId: pair.awayTeamId,
        week,
        isNeutral: pair.isNeutral,
        competition: 'cup',
        cupRound: round,
        homeGoals: res.homeGoals,
        awayGoals: res.awayGoals,
        homePens: res.homePens,
        awayPens: res.awayPens,
        winnerTeamId: res.winnerTeamId,
        events: res.events,
        stats: null,
        isNew: isNewDraw,
      });
    }

    // ── Пост-матч участников кубка + мораль раунда (Фаза 4: per-match эффекты,
    // замены матча клуба игрока — минутный drain; отдых неучастников — ПОСЛЕ
    // евроблока: команда могла сыграть в Европе без кубкового матча) ──
    const participants = new Set<string>();
    for (const { pair } of pairs) {
      participants.add(pair.homeTeamId);
      participants.add(pair.awayTeamId);
    }

    for (const ctx of ctxs.values()) {
      if (!participants.has(ctx.team.id)) continue;
      weekMatchTeamIds.add(ctx.team.id);
      const myPair = pairs.find(
        (p) => p.pair.homeTeamId === ctx.team.id || p.pair.awayTeamId === ctx.team.id,
      );
      if (!myPair) continue;
      const res = roundResults.get(myPair.id);
      if (!res) continue;
      const isHome = myPair.pair.homeTeamId === ctx.team.id;
      const my = isHome ? res.homeGoals : res.awayGoals;
      const opp = isHome ? res.awayGoals : res.homeGoals;
      // победа по пенальти = победа
      const outcome: 'W' | 'D' | 'L' =
        res.winnerTeamId === ctx.team.id ? 'W' : my === opp ? 'L' : my > opp ? 'W' : 'L';
      const events = res.events.filter((e) => e.teamId === ctx.team.id);

      applyMatchEffects(
        {
          players: ctx.players,
          starterIds: new Set(ctx.lineup.filter((x): x is string => !!x)),
          benchIds: new Set(ctx.bench),
          events,
          outcome,
          tempo: coerceTempo(ctx.team.tempo),
          pressing: coercePressing(ctx.team.pressing),
          competition: 'cup',
          goalsConceded: opp,
          subs: isHome ? res.homeSubs : res.awaySubs,
        },
        injuriesMap,
        mulberry32(hashString(`${saveId}:rating:${season}:${week}:${ctx.team.id}`)),
      );
      creditCleanSheet(ctx, opp);

      // Мораль кубка: победителям раунда +5, вылетевшим −5
      const moraleDelta = res.winnerTeamId === ctx.team.id ? CUP_MORALE_WIN : CUP_MORALE_OUT;
      for (const p of ctx.players) {
        p.morale = clamp(p.morale + moraleDelta, MORALE_MIN, MORALE_MAX);
      }
    }

    // ── Состояние кубка: победители раунда ──
    const winners = Array.from(roundResults.values()).map((r) => r.winnerTeamId);
    newCupRound = round;
    if (isFinal) {
      cupWinnerTeamId = winners[0] ?? null;
      newCupAlive = JSON.stringify(cupWinnerTeamId ? [cupWinnerTeamId] : []);
    }

    // ── Жеребьёвка СЛЕДУЮЩЕГО раунда (после каждого раунда) ──
    if (!isFinal) {
      let nextParticipants: string[];
      if (round === 1 && N > 16) {
        // победители предварительного + команды, не игравшие в нём (bye)
        const prelimIds = new Set(participantIds);
        nextParticipants = [
          ...winners,
          ...teams.filter((t) => !prelimIds.has(t.id)).map((t) => t.id),
        ];
      } else {
        nextParticipants = winners;
      }
      const nextRound = round + 1;
      const nextIsFinal = nextRound === plan.cupRounds;
      const drawRng = mulberry32(hashString(`${saveId}:cupdraw:${season}:${nextRound}`));
      const seeds = nextParticipants.map((id) => ({
        id,
        strength: teamById.get(id)?.strength ?? 60,
      }));
      const nextPairs = drawCupRound(drawRng, seeds, nextIsFinal);
      const nextWeek = plan.cupWeeks[nextRound - 1];

      // создать scheduled матчи следующего раунда (пары видны заранее)
      for (const pair of nextPairs) {
        scheduledCreates.push({
          id: idFactory(),
          week: nextWeek,
          homeTeamId: pair.homeTeamId,
          awayTeamId: pair.awayTeamId,
          cupRound: nextRound,
          isNeutral: pair.isNeutral,
          competition: 'cup',
        });
      }
      newCupAlive = JSON.stringify(nextParticipants);

      // DTO пар следующего раунда — для экрана кубка
      const pairDtos: CupMatchDTO[] = nextPairs.map((pair) => {
        const home = teamById.get(pair.homeTeamId);
        const away = teamById.get(pair.awayTeamId);
        return {
          id: '',
          home: home ? toTeamBrief(home) : null,
          away: away ? toTeamBrief(away) : null,
          homeGoals: null,
          awayGoals: null,
          homePens: null,
          awayPens: null,
          winnerTeamId: null,
          played: false,
          isUserMatch: pair.homeTeamId === userTeamId || pair.awayTeamId === userTeamId,
          isNeutral: pair.isNeutral,
        };
      });
      cupNextRound = { round: nextRound, label: cupRoundLabel(N, nextRound), pairs: pairDtos };
    }

    // Призовые клуба игрока → новость
    if (cupPrize > 0) {
      const won = userPair
        ? roundResults.get(userPair.id)?.winnerTeamId === userTeamId
        : false;
      const msg = isFinal
        ? won
          ? `Кубок: ВЫ — обладатель кубка! Призовые €${cupPrize.toLocaleString('ru-RU')}.`
          : `Кубок: финал проигран. Призовые финалиста €${cupPrize.toLocaleString('ru-RU')}.`
        : `Кубок · ${label}: победа и выход в ${cupRoundLabel(N, round + 1)}. Призовые €${cupPrize.toLocaleString('ru-RU')}.`;
      pendingNews.push({ id: idFactory(), type: 'cup', message: msg });
    }

    // ════════════════ ФАЗА 4: КУБОК ЕВРОПЫ (§5.2 Б.2; ПОСЛЕ национального
    // кубка — drain кубкового матча уже применён к составам участников) ══════
    const euroRound = euroRoundAt(plan, week); // 1..4 | null
    if (euroRound !== null) {
      const isEuroFinal = euroRound >= EURO_ROUNDS;
      const euroLabel = euroRoundLabel(euroRound);

      // 2a. Ленивая инициализация (§5.3): только на неделе 1/8 при
      // euroSeason !== season (сезон 1 / легаси; сезоны 2+ инициализирует переход)
      if (newEuroSeason !== season) {
        if (euroRound === 1) {
          // места прошлого сезона (сезоны 2+, легаси) — из его лиговых матчей;
          // сезон 1 — place=null → квалификация по силе
          let placeById: Map<string, number> | null = null;
          if (season >= 2) {
            const prevLeague = await db.match.findMany({
              where: { saveId, season: season - 1, competition: 'league', status: 'played' },
              select: { homeTeamId: true, awayTeamId: true, homeGoals: true, awayGoals: true, week: true },
            });
            if (prevLeague.length > 0) {
              placeById = new Map(
                computeStandings(
                  standingTeams,
                  prevLeague
                    .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
                    .map((m) => ({
                      homeTeamId: m.homeTeamId,
                      awayTeamId: m.awayTeamId,
                      homeGoals: m.homeGoals as number,
                      awayGoals: m.awayGoals as number,
                      week: m.week,
                    })),
                ).map((s) => [s.teamId, s.place] as const),
              );
            }
          }
          const roster = resolveEuroRoster({
            ownLeague: leagueCode,
            leagueTeams: teams.map((t) => ({
              id: t.id,
              strength: t.strength,
              place: placeById?.get(t.id) ?? null,
            })),
            existingGuests: guestSides.map((g) => ({
              id: g.team.id,
              leagueCode: g.team.leagueCode ?? leagueCode,
              name: g.team.name,
            })),
            rng: mulberry32(hashString(`${saveId}:euroqual:${season}:lazy`)),
            guestRng: mulberry32(hashString(`${saveId}:euroguests:${season}`)),
            saveId,
            idFactory,
          });
          // Регистрация новых гостей для матчей ЭТОЙ же недели: createMany-данные —
          // те же объекты, что и составы (пост-матч состояние запишется при создании)
          for (const gen of roster.newGuests) {
            const teamRow = {
              ...gen.team,
              isUserTeam: false,
              lineup: null,
              bench: null,
              trainingFocus: null,
              trainingIntensity: null,
              matchPlan: null,
            } as unknown as TeamModel;
            teamById.set(teamRow.id, teamRow);
            const genPlayers = gen.players as unknown as PlayerLike[];
            playersByTeam.set(teamRow.id, genPlayers);
            guestSides.push({ team: teamRow, players: genPlayers });
            lazyEuroNewGuests.push(gen);
          }
          newEuroSeason = season;
          newEuroRound = 0;
          newEuroParticipants = serializeEuroTeamIds(roster.teamIds);
          newEuroAlive = serializeEuroTeamIds(roster.teamIds);
          const userQualified = roster.ownTeamIds.includes(userTeamId);
          pendingNews.push({
            id: idFactory(),
            type: 'euro',
            message: userQualified
              ? `${EURO_TOURNAMENT_NAME}: ваш клуб квалифицировался! В турнире ${roster.teamIds.length} клубов.`
              : `${EURO_TOURNAMENT_NAME}: старт турнира — ${roster.teamIds.length} клубов (ваш клуб не участвует).`,
          });
        }
        // r !== 1: недели 1/8 уже прошли — евро пропускается до сезонного перехода (§5.3)
      }

      // 2b. Пары раунда: scheduled из БД (жеребьёвка прошлого раунда) или свежая жеребьёвка
      const existingEuro = weekMatches.filter((m) => m.competition === 'euro' && m.cupRound === euroRound);
      if (existingEuro.length > 0 && existingEuro.every((m) => m.status === 'played')) {
        throw new ApiGameError('WEEK_ALREADY_PLAYED', 409);
      }
      const euroStateReady = newEuroSeason === season;
      const euroAliveIds = parseEuroTeamIds(newEuroAlive);
      let euroPairs: { id: string; pair: CupPair }[] = [];
      const isNewEuroDraw = euroStateReady && existingEuro.length === 0;
      if (euroStateReady && euroAliveIds.length >= 2 && euroAliveIds.length % 2 === 0) {
        if (isNewEuroDraw) {
          const drawRng = mulberry32(hashString(`${saveId}:eurodraw:${season}:${euroRound}`));
          const seeds = euroAliveIds.map((id) => ({
            id,
            strength: teamById.get(id)?.strength ?? 60,
            leagueCode: teamById.get(id)?.leagueCode ?? leagueCode,
          }));
          euroPairs = drawEuroRound(drawRng, seeds, euroRound).map((pair) => ({ id: idFactory(), pair }));
          const pairsText = euroPairs
            .slice(0, 3)
            .map(({ pair }) => {
              const h = teamById.get(pair.homeTeamId)?.shortName ?? '?';
              const a = teamById.get(pair.awayTeamId)?.shortName ?? '?';
              return `${h} — ${a}`;
            })
            .join('; ');
          pendingNews.push({
            id: idFactory(),
            type: 'euro',
            message: `Жеребьёвка Кубка Европы · ${euroLabel}: ${pairsText}${euroPairs.length > 3 ? ' и другие пары' : ''}.`,
          });
        } else {
          euroPairs = existingEuro.map((m) => ({
            id: m.id,
            pair: { homeTeamId: m.homeTeamId, awayTeamId: m.awayTeamId, isNeutral: m.isNeutral },
          }));
        }
      }

      // 2c. Контексты участников: лиговые клубы — с пересборкой при сыгранном
      // кубковом матче этой недели (порог ротации EURO_ROTATE_COND); гости — autoLineup
      const euroSideCache = new Map<string, TeamCtx>();
      const euroSideOf = (teamId: string): TeamCtx | null => {
        const cached = euroSideCache.get(teamId);
        if (cached) return cached;
        const leagueCtx = ctxs.get(teamId);
        let side: TeamCtx | null = null;
        if (leagueCtx) {
          if (participants.has(teamId)) {
            const auto = autoLineup(
              leagueCtx.players,
              coerceFormation(leagueCtx.team.formation),
              true,
              EURO_ROTATE_COND,
            );
            side = {
              team: leagueCtx.team,
              players: leagueCtx.players,
              lineup: auto.lineup,
              bench: auto.bench,
              isUser: leagueCtx.isUser,
            };
          } else {
            side = leagueCtx; // кубковый матч этой недели не игрался — состав свежий
          }
        } else {
          const guest = guestSides.find((g) => g.team.id === teamId);
          if (guest) {
            const auto = autoLineup(
              guest.players,
              coerceFormation(guest.team.formation),
              true,
              EURO_ROTATE_COND,
            );
            side = {
              team: guest.team,
              players: guest.players,
              lineup: auto.lineup,
              bench: auto.bench,
              isUser: false,
            };
          }
        }
        if (side) euroSideCache.set(teamId, side);
        return side;
      };

      const euroRoundResults = new Map<string, {
        homeGoals: number; awayGoals: number; events: MatchEvent[];
        homePens: number | null; awayPens: number | null; winnerTeamId: string;
        homeSubs: SubRecord[]; awaySubs: SubRecord[];
      }>();
      const userEuroPair = euroPairs.find(
        (p) => p.pair.homeTeamId === userTeamId || p.pair.awayTeamId === userTeamId,
      );

      // 2e. Евроматч клуба игрока: ПОЛНЫЙ движок + пенальти при ничьей (как в кубке)
      if (userEuroPair) {
        const homeSide = euroSideOf(userEuroPair.pair.homeTeamId);
        const awaySide = euroSideOf(userEuroPair.pair.awayTeamId);
        if (!homeSide || !awaySide || homeSide === awaySide) throw new ApiGameError('NO_SAVE', 404);
        const userEuroHome = userEuroPair.pair.homeTeamId === userTeamId;

        const matchRng = mulberry32(hashString(`${saveId}:${season}:${week}:${userEuroPair.id}`));
        const userEuroResult = simulateMatch(
          matchRng,
          tacticInputOf(homeSide),
          tacticInputOf(awaySide),
          { neutral: userEuroPair.pair.isNeutral },
        );
        for (const inj of userEuroResult.injuries) injuriesMap.set(inj.playerId, inj.weeks);

        let homePens: number | null = null;
        let awayPens: number | null = null;
        let winnerTeamId: string;
        if (userEuroResult.homeGoals === userEuroResult.awayGoals) {
          // Серия пенальти — покиково, события в ту же ленту
          const homeById = new Map(homeSide.players.map((p) => [p.id, p]));
          const awayById = new Map(awaySide.players.map((p) => [p.id, p]));
          const homeTakers = shootoutTakers(homeSide.lineup, homeById);
          const awayTakers = shootoutTakers(awaySide.lineup, awayById);
          const homeGk = lineupGoalkeeper(homeSide.lineup, homeById);
          const awayGk = lineupGoalkeeper(awaySide.lineup, awayById);
          if (homeGk && awayGk && homeTakers.length > 0 && awayTakers.length > 0) {
            const shootout = simulatePenaltyShootout(matchRng, {
              homeName: homeSide.team.name,
              awayName: awaySide.team.name,
              homeTeamId: homeSide.team.id,
              awayTeamId: awaySide.team.id,
              homeTakers,
              awayTakers,
              homeGk,
              awayGk,
              events: userEuroResult.events,
            });
            homePens = shootout.homePens;
            awayPens = shootout.awayPens;
            winnerTeamId = shootout.winnerIsHome ? homeSide.team.id : awaySide.team.id;
          } else {
            // вырожденный состав — монетка (защита)
            winnerTeamId = matchRng() < 0.5 ? homeSide.team.id : awaySide.team.id;
          }
        } else {
          winnerTeamId = userEuroResult.homeGoals > userEuroResult.awayGoals
            ? homeSide.team.id
            : awaySide.team.id;
        }

        euroRoundResults.set(userEuroPair.id, {
          homeGoals: userEuroResult.homeGoals,
          awayGoals: userEuroResult.awayGoals,
          events: userEuroResult.events,
          homePens,
          awayPens,
          winnerTeamId,
          homeSubs: userEuroResult.homeSubs,
          awaySubs: userEuroResult.awaySubs,
        });
        played.push({
          id: userEuroPair.id,
          homeTeamId: userEuroPair.pair.homeTeamId,
          awayTeamId: userEuroPair.pair.awayTeamId,
          week,
          isNeutral: userEuroPair.pair.isNeutral,
          competition: 'euro',
          cupRound: euroRound,
          homeGoals: userEuroResult.homeGoals,
          awayGoals: userEuroResult.awayGoals,
          homePens,
          awayPens,
          winnerTeamId,
          events: userEuroResult.events,
          stats: userEuroResult.stats,
          isNew: isNewEuroDraw,
        });
        userMatchDtos.push({
          matchId: userEuroPair.id,
          home: toTeamBrief(homeSide.team),
          away: toTeamBrief(awaySide.team),
          homeGoals: userEuroResult.homeGoals,
          awayGoals: userEuroResult.awayGoals,
          homePens,
          awayPens,
          winnerTeamId,
          isNeutral: userEuroPair.pair.isNeutral,
          events: userEuroResult.events,
          stats: userEuroResult.stats,
          competition: 'euro',
          homeXI: radarXiOf(homeSide),
          awayXI: radarXiOf(awaySide),
        });

        // Призовые: участие €2M (один раз — при первом сыгранном раунде 1/8) + раунд/финал
        const won = winnerTeamId === userTeamId;
        if (euroRound === 1 && save.euroRound < 1) euroPrize += EURO_PRIZE_PARTICIPATION;
        euroPrize += euroPrizeFor({ round: euroRound, won, isFinal: isEuroFinal });

        // Правление (§5.8): евроматч — ВТОРОЙ вход недельного пересчёта
        const myGoalsEuro = userEuroHome ? userEuroResult.homeGoals : userEuroResult.awayGoals;
        const oppGoalsEuro = userEuroHome ? userEuroResult.awayGoals : userEuroResult.homeGoals;
        const oppSideEuro = userEuroHome ? awaySide : homeSide;
        boardMatchInputs.push({
          outcome: won ? 'W' : myGoalsEuro === oppGoalsEuro ? 'L' : myGoalsEuro > oppGoalsEuro ? 'W' : 'L',
          myStrength: userCtx.team.strength,
          oppStrength: oppSideEuro.team.strength,
          competition: 'euro',
          roundPassed: won,
          wonFinal: isEuroFinal && won,
          upsetCupLoss: !won && userCtx.team.strength - oppSideEuro.team.strength >= BOARD_STRENGTH_GAP,
        });

        // Новости евроматча
        const outcomeWord = won ? 'Победа!' : 'Поражение';
        const pensSuffix = homePens !== null ? ` (пен. ${homePens}:${awayPens})` : '';
        pendingNews.push({
          id: idFactory(),
          type: 'euro',
          message: `Кубок Европы · ${euroLabel}: ${homeSide.team.name} ${userEuroResult.homeGoals}:${userEuroResult.awayGoals}${pensSuffix} ${awaySide.team.name}. ${outcomeWord}`,
        });
        for (const e of userEuroResult.events) {
          if (e.type === 'red') {
            pendingNews.push({
              id: idFactory(),
              type: 'info',
              message: `${e.playerName ?? 'Игрок'} удалён в еврокубковом матче (${euroLabel}).`,
            });
          } else if (e.type === 'injury') {
            pendingNews.push({ id: idFactory(), type: 'injury', message: e.text });
          }
        }
      }

      // 2f. ИИ-евроматчи остальных пар (гости и лиговые клубы; пенальти вероятностно)
      for (const { id, pair } of euroPairs) {
        if (euroRoundResults.has(id)) continue;
        const homeTeam = teamById.get(pair.homeTeamId);
        const awayTeam = teamById.get(pair.awayTeamId);
        if (!homeTeam || !awayTeam) continue;
        const rng = mulberry32(hashString(`${saveId}:${season}:${week}:${id}`));
        const res = simulateEuroAiMatch(
          rng,
          {
            teamId: homeTeam.id,
            name: homeTeam.name,
            strength: homeTeam.strength,
            players: playersByTeam.get(homeTeam.id) ?? [],
            aiStyle: coerceAiStyle(homeTeam.aiStyle),
          },
          {
            teamId: awayTeam.id,
            name: awayTeam.name,
            strength: awayTeam.strength,
            players: playersByTeam.get(awayTeam.id) ?? [],
            aiStyle: coerceAiStyle(awayTeam.aiStyle),
          },
          { neutral: pair.isNeutral },
        );
        euroRoundResults.set(id, { ...res, homeSubs: [], awaySubs: [] });
        played.push({
          id,
          homeTeamId: pair.homeTeamId,
          awayTeamId: pair.awayTeamId,
          week,
          isNeutral: pair.isNeutral,
          competition: 'euro',
          cupRound: euroRound,
          homeGoals: res.homeGoals,
          awayGoals: res.awayGoals,
          homePens: res.homePens,
          awayPens: res.awayPens,
          winnerTeamId: res.winnerTeamId,
          events: res.events,
          stats: null,
          isNew: isNewEuroDraw,
        });
      }

      // 2g. Пост-матч участников: per-match эффекты (competition='euro' →
      // euroGoals/euroAssists; subs полного движка) + мораль раунда
      for (const { id, pair } of euroPairs) {
        const res = euroRoundResults.get(id);
        if (!res) continue;
        for (const teamId of [pair.homeTeamId, pair.awayTeamId]) {
          const side = euroSideOf(teamId);
          if (!side) continue;
          const isHome = pair.homeTeamId === teamId;
          const my = isHome ? res.homeGoals : res.awayGoals;
          const opp = isHome ? res.awayGoals : res.homeGoals;
          // победа по пенальти = победа
          const outcome: 'W' | 'D' | 'L' =
            res.winnerTeamId === teamId ? 'W' : my === opp ? 'L' : my > opp ? 'W' : 'L';
          const events = res.events.filter((e) => e.teamId === teamId);
          applyMatchEffects(
            {
              players: side.players,
              starterIds: new Set(side.lineup.filter((x): x is string => !!x)),
              benchIds: new Set(side.bench),
              events,
              outcome,
              tempo: coerceTempo(side.team.tempo),
              pressing: coercePressing(side.team.pressing),
              competition: 'euro',
              goalsConceded: opp,
              subs: isHome ? res.homeSubs : res.awaySubs,
            },
            injuriesMap,
            mulberry32(hashString(`${saveId}:rating:${season}:${week}:${teamId}:euro`)),
          );
          creditCleanSheet(side, opp);
          // Мораль раунда: победителям +5, вылетевшим −5 (как в кубке)
          const moraleDelta = res.winnerTeamId === teamId ? CUP_MORALE_WIN : CUP_MORALE_OUT;
          for (const p of side.players) {
            p.morale = clamp(p.morale + moraleDelta, MORALE_MIN, MORALE_MAX);
          }
          weekMatchTeamIds.add(teamId);
        }
      }

      // 2h. Победители → состояние; жеребьёвка + scheduled матчи СЛЕДУЮЩЕГО раунда
      if (euroPairs.length > 0) {
        const euroWinners = Array.from(euroRoundResults.values()).map((r) => r.winnerTeamId);
        newEuroRound = euroRound;
        if (isEuroFinal) {
          const championTeamId = euroWinners[0] ?? null;
          newEuroAlive = serializeEuroTeamIds(championTeamId ? [championTeamId] : []);
          if (championTeamId) {
            pendingNews.push({
              id: idFactory(),
              type: 'euro',
              message: `Кубок Европы: ${teamById.get(championTeamId)?.name ?? '—'} — чемпион Европы!`,
            });
          }
        } else {
          const nextEuroRound = euroRound + 1;
          const nextEuroWeek = euroWeeksOf(N)[nextEuroRound - 1];
          const nextDrawRng = mulberry32(hashString(`${saveId}:eurodraw:${season}:${nextEuroRound}`));
          const nextSeeds = euroWinners.map((id) => ({
            id,
            strength: teamById.get(id)?.strength ?? 60,
            leagueCode: teamById.get(id)?.leagueCode ?? leagueCode,
          }));
          const nextEuroPairs = drawEuroRound(nextDrawRng, nextSeeds, nextEuroRound);
          for (const pair of nextEuroPairs) {
            scheduledCreates.push({
              id: idFactory(),
              week: nextEuroWeek,
              homeTeamId: pair.homeTeamId,
              awayTeamId: pair.awayTeamId,
              cupRound: nextEuroRound,
              isNeutral: pair.isNeutral,
              competition: 'euro',
            });
          }
          newEuroAlive = serializeEuroTeamIds(euroWinners);

          const euroTeamDtoOf = (teamId: string): EuroTeamDTO | null => {
            const t = teamById.get(teamId);
            if (!t) return null;
            const code = (t.leagueCode ?? leagueCode) as EuroTeamDTO['leagueCode'];
            const def = leagueByCode(code);
            return {
              id: t.id,
              name: t.name,
              shortName: t.shortName,
              leagueCode: code,
              leagueFlag: def?.flag ?? '🌍',
              leagueName: def?.nameRu ?? code,
              colorPrimary: t.colorPrimary,
              colorSecondary: t.colorSecondary,
              strength: t.strength,
              isUser: t.isUserTeam,
              isGuest: t.isEuroGuest,
              coachStyle: t.isUserTeam ? null : coerceAiStyle(t.aiStyle),
              coachName: t.isUserTeam ? null : t.aiCoachName,
            };
          };
          const euroPairDtos: EuroMatchDTO[] = nextEuroPairs.map((pair) => ({
            id: '',
            home: euroTeamDtoOf(pair.homeTeamId),
            away: euroTeamDtoOf(pair.awayTeamId),
            homeGoals: null,
            awayGoals: null,
            homePens: null,
            awayPens: null,
            winnerTeamId: null,
            played: false,
            isUserMatch: pair.homeTeamId === userTeamId || pair.awayTeamId === userTeamId,
            isNeutral: pair.isNeutral,
          }));
          euroRoundDto = {
            round: nextEuroRound,
            label: euroRoundLabel(nextEuroRound),
            drawn: true,
            pairs: euroPairDtos,
          };
        }
      }

      // Призовые клуба игрока в евро → новость
      if (euroPrize > 0) {
        pendingNews.push({
          id: idFactory(),
          type: 'euro',
          message: `Кубок Европы: призовые €${euroPrize.toLocaleString('ru-RU')}.`,
        });
      }
      if (euroPairs.length > 0) {
        weekLabel = `${weekLabel} · Кубок Европы`;
      }
    } // конец евроблока

    // ── Фаза 4 (§5.2 Б.3): восстановление/отдых недели — ПОСЛЕ обеих конкуренций;
    // recovery +8 — сыгравшим (ровно 1 раз, даже при 2 матчах), полный отдых
    // +10/+2 — только командам БЕЗ матчей за неделю ──
    for (const ctx of ctxs.values()) {
      if (weekMatchTeamIds.has(ctx.team.id)) {
        applyWeeklyRecovery(ctx.players);
      } else {
        // Отдых невыступающих: +10 состояния, +2 морали, без статистики
        for (const p of ctx.players) {
          p.condition = clamp(p.condition + CUP_REST_COND, CONDITION_MIN, CONDITION_MAX);
          p.morale = clamp(p.morale + CUP_REST_MORALE, MORALE_MIN, MORALE_MAX);
        }
      }
    }
  }

  // ── Фаза 4 (§5.2 В): гости — еженедельное восстановление +8 (БЕЗ тренировок;
  // их развитие — только евроматчи и сезонное старение/реген) ──
  if (newEuroSeason !== null) {
    for (const g of guestSides) applyWeeklyRecovery(g.players);
  }

  // ── ТРЕНИРОВКИ (обе ветки): для КАЖДОЙ команды ──
  const placeByTeam = new Map(standings.map((s) => [s.teamId, s.place]));
  const pointsByTeam = new Map(standings.map((s) => [s.teamId, s.points]));
  const safeRow = standings[Math.min(Math.max(N - 4, 0), standings.length - 1)];

  for (const ctx of ctxs.values()) {
    const isUser = ctx.team.id === userTeamId;
    let focus: ReturnType<typeof coerceTrainingFocus>;
    let intensity: ReturnType<typeof coerceTrainingIntensity>;
    if (isUser) {
      focus = coerceTrainingFocus(ctx.team.trainingFocus);
      intensity = coerceTrainingIntensity(ctx.team.trainingIntensity);
    } else {
      const place = placeByTeam.get(ctx.team.id) ?? N;
      const pts = pointsByTeam.get(ctx.team.id) ?? 0;
      const choice = aiTrainingChoice(
        mulberry32(hashString(`${saveId}:aitrain:${season}:${week}:${ctx.team.id}`)),
        {
          players: ctx.players,
          place,
          safeGapPoints: (safeRow?.points ?? 0) - pts,
        },
      );
      focus = choice.focus;
      intensity = choice.intensity;
    }
    const trainRng = mulberry32(hashString(`${saveId}:training:${season}:${week}:${ctx.team.id}`));
    const report = applyWeeklyTraining(trainRng, focus, intensity, ctx.players);

    // Новости — только для клуба игрока
    if (isUser) {
      for (const note of report.notes) {
        pendingNews.push({ id: idFactory(), type: 'training', message: `Тренировка: ${note}.` });
      }
      for (const inj of report.injuries) {
        pendingNews.push({
          id: idFactory(),
          type: 'injury',
          message: `Тренировка: ${inj.playerName} получил травму (${inj.weeks} ${inj.weeks === 1 ? 'неделя' : 'недель'}).`,
        });
      }
    }
  }

  // Декремент давних травм (новые травмы этой недели не затрагиваются)
  for (const row of playerRows) {
    const p = row as unknown as PlayerLike;
    if (preInjured.has(p.id) && p.injuryWeeks > 0) p.injuryWeeks -= 1;
  }

  // ── Финансы клуба игрока ──
  const userPlace = standings.find((s) => s.teamId === userTeamId)?.place ?? N;
  const financeRng = mulberry32(hashString(`${saveId}:finance:${season}:${week}`));
  // Фаза 4: домашний матч — в ЛЮБОЙ конкуренции недели (кубок ИЛИ евро; билеты — один раз)
  const hasHomeMatch = userMatchDtos.some((m) => m.home.id === userTeamId);
  const finance = computeWeekFinance({
    players: userCtx.players,
    place: userPlace,
    teamCount: N,
    isHomeMatch: hasHomeMatch,
    stadiumCapacity: userCtx.team.stadiumCapacity,
    rng: financeRng,
  });
  let newBalance = save.balance + finance.net + cupPrize + euroPrize;

  // ── ПРАВЛЕНИЕ (Фаза 3): еженедельный пересчёт confidence ──
  let boardConfidence = save.boardConfidence;
  let boardWarnings = save.boardWarnings;
  let boardLowStreak = save.boardLowStreak;
  const honeymoonUntilWeek =
    save.honeymoonUntilWeek ?? boardLazyInit?.honeymoonUntilWeek ?? 0;
  let sackedMidSeason = false;
  let boardUpdateResult: { confidence: number; delta: number } | null = null;

  if (boardTargetCode !== null) {
    const incomeEstimate = weeklyIncomeEstimate(userPlace, userCtx.team.stadiumCapacity, N);
    const wageRatioNow = incomeEstimate > 0
      ? finance.wages / incomeEstimate
      : finance.wages > 0 ? 1 : 0;
    const avgMorale = userCtx.players.length > 0
      ? userCtx.players.reduce((s, p) => s + p.morale, 0) / userCtx.players.length
      : 60;

    const boardUpdate = weeklyBoardUpdate({
      confidence: boardConfidence,
      week,
      totalWeeks: plan.totalWeeks,
      honeymoonUntilWeek,
      place: userPlace,
      targetPlace: boardTargetPlace,
      targetCode: boardTargetCode,
      teamCount: N,
      match: boardMatchInputs[0] ?? null,
      matches: boardMatchInputs,
      balance: newBalance,
      wageRatio: wageRatioNow,
      avgMorale,
    });
    boardConfidence = boardUpdate.confidence;
    boardUpdateResult = { confidence: boardUpdate.confidence, delta: boardUpdate.delta };

    // Новость «Правление: …» — раз в 4 недели (вместе с обзором темпа) и при значимых сдвигах
    const isPaceWeek = week % BOARD_PACE_INTERVAL === 0 && week >= BOARD_PACE_INTERVAL;
    if ((isPaceWeek || Math.abs(boardUpdate.delta) >= 5) && boardUpdate.notes.length > 0) {
      pendingNews.push({
        id: idFactory(),
        type: 'board',
        message: `Правление: ${boardUpdate.notes.join(', ')}.`,
      });
    }

    // Предупреждение (единственное за сезон) и ультиматум
    if (boardConfidence < BOARD_WARN_BELOW && boardWarnings === 0) {
      boardWarnings = 1;
      pendingNews.push({
        id: idFactory(),
        type: 'board',
        message: 'Правление: вы получили предупреждение — результаты должны улучшиться.',
      });
    } else if (boardConfidence < BOARD_ULTIMATUM_BELOW && boardWarnings === 1) {
      boardWarnings = 2;
      pendingNews.push({
        id: idFactory(),
        type: 'board',
        message: 'Правление: ультиматум — шесть недель на исправление ситуации.',
      });
    }

    // Mid-season sack: confidence ниже порога 4 недели подряд (после медового месяца)
    if (week > honeymoonUntilWeek && boardConfidence < BOARD_SACK_CONF_WEEKLY) {
      boardLowStreak += 1;
    } else {
      boardLowStreak = 0;
    }
    if (boardLowStreak >= BOARD_SACK_STREAK) {
      sackedMidSeason = true;
      pendingNews.push({
        id: idFactory(),
        type: 'board',
        message: 'Вы уволены. Правление прекратило сотрудничество с вами.',
      });
    }
  }

  // ── Рынок ──
  const listingRows = await db.transferListing.findMany({
    where: { saveId, status: 'active' },
    include: { player: true },
  });
  const marketRng = mulberry32(hashString(`${saveId}:market:${season}:${week}`));

  const listingUpdates = new Map<string, { status?: string; expiresAt?: number }>();
  const soldListingIds = new Set<string>();
  const soldUserListings: { playerId: string; price: number; name: string }[] = [];
  const aiPurchases: { playerId: string; teamId: string; shirtNumber: number; contractUntil: number }[] = [];

  // 1) истечение лотов
  const activeAfterExpiry: { listingId: string; price: number; source: string; playerId: string }[] = [];
  for (const l of listingRows) {
    const remaining = l.expiresAt - 1;
    if (remaining <= 0) {
      listingUpdates.set(l.id, { status: 'expired', expiresAt: 0 });
    } else {
      listingUpdates.set(l.id, { expiresAt: remaining });
      activeAfterExpiry.push({ listingId: l.id, price: l.price, source: l.source, playerId: l.playerId });
    }
  }

  // 2) офферы на лоты игрока (мгновенная продажа по цене)
  for (const l of listingRows) {
    if (l.source !== 'user' || soldListingIds.has(l.id)) continue;
    if (listingUpdates.get(l.id)?.status === 'expired') continue;
    const probability = sellOfferProbability(l.price, l.player.value);
    if (marketRng() < probability) {
      soldListingIds.add(l.id);
      newBalance += l.price;
      const name = `${l.player.firstName} ${l.player.lastName}`;
      soldUserListings.push({ playerId: l.playerId, price: l.price, name });
      transfersTexts.push(`${name} продан за €${l.price.toLocaleString('ru-RU')}.`);
      pendingNews.push({
        id: idFactory(),
        type: 'transfer',
        message: `${name} продан за €${l.price.toLocaleString('ru-RU')}.`,
      });
    }
  }

  // 3) покупка ИИ (с вероятностью 0.15 — самый дешёвый «по карману» лот)
  if (marketRng() < AI_BUY_CHANCE) {
    const aiBudgets = teams
      .filter((t) => !t.isUserTeam)
      .map((t) => ({
        teamId: t.id,
        budget: Math.floor(
          (START_BALANCE_BASE + Math.max(0, t.strength - 55) * START_BALANCE_PER_STRENGTH)
            * TRANSFER_BUDGET_RATIO,
        ),
      }));
    const purchase = pickAiPurchase(
      marketRng,
      aiBudgets,
      activeAfterExpiry.filter((l) => !soldListingIds.has(l.listingId)),
    );
    if (purchase) {
      const listing = listingRows.find((l) => l.id === purchase.listingId);
      const buyer = teams.find((t) => t.id === purchase.teamId);
      if (listing && buyer) {
        soldListingIds.add(listing.id);
        const name = `${listing.player.firstName} ${listing.player.lastName}`;
        const buyerPlayers = playersByTeam.get(buyer.id) ?? [];
        const shirtNumber = freeShirtNumbers(buyerPlayers, []);
        // Фаза 3: новому клубу — новый контракт (детерминированный бросок по возрасту)
        const buyRng = mulberry32(hashString(`${saveId}:contractbuy:${listing.playerId}`));
        const contractUntil = contractUntilFromYears(
          season,
          contractYearsRoll(buyRng, listing.player.age),
        );
        aiPurchases.push({ playerId: listing.playerId, teamId: buyer.id, shirtNumber, contractUntil });
        transfersTexts.push(`${buyer.name} купила ${name} за €${purchase.price.toLocaleString('ru-RU')}.`);
        pendingNews.push({
          id: idFactory(),
          type: 'market',
          message: `${buyer.name} купила ${name} за €${purchase.price.toLocaleString('ru-RU')}.`,
        });
      }
    }
  }

  // 4) догенерация рынка (пул имён лиги)
  const activeMarketCount = activeAfterExpiry.filter(
    (l) => l.source === 'market' && !soldListingIds.has(l.listingId),
  ).length;
  const topUp = marketTopUpCount(marketRng, activeMarketCount);
  const newListings: { player: PlayerLike; price: number; askFactor: number; expiresAt: number }[] = [];
  for (let i = 0; i < topUp; i++) {
    newListings.push(generateMarketListing(marketRng, pool));
  }

  // ── БОСМАН (Фаза 3): предконтракты игроков последнего года контракта ──
  // Броски с 60% сезона, раз в 4 недели; только для клуба игрока.
  const bosmanStartWeek = Math.ceil(BOSMAN_SEASON_START * plan.totalWeeks);
  if (week >= bosmanStartWeek && week % BOSMAN_INTERVAL === 0) {
    const bosmanRng = mulberry32(hashString(`${saveId}:bosman:${season}:${week}`));
    const strengthRankById = new Map<string, number>();
    [...teams]
      .sort((a, b) => b.strength - a.strength)
      .forEach((t, i) => strengthRankById.set(t.id, i + 1));
    const userRank = strengthRankById.get(userTeamId) ?? N;
    const userTeamApps = teamAppsOf(userCtx.players);
    for (const p of userCtx.players) {
      if (p.contractUntil !== season || p.preContractTeamId) continue;
      const prob = bosmanProbability({ player: p, teamApps: userTeamApps });
      if (bosmanRng() >= prob) continue;
      // Клуб предконтракта: ИИ-клуб с рангом силы в пределах ± BOSMAN_RANK_SPAN
      const options = teams.filter(
        (t) =>
          !t.isUserTeam &&
          t.id !== userTeamId &&
          Math.abs((strengthRankById.get(t.id) ?? N) - userRank) <= BOSMAN_RANK_SPAN,
      );
      if (options.length === 0) continue;
      const club = pick(bosmanRng, options);
      p.preContractTeamId = club.id; // дифф запишет (спец-кейс)
      const name = `${p.firstName} ${p.lastName}`;
      pendingNews.push({
        id: idFactory(),
        type: 'transfer',
        message: `${name} подписал предконтракт с ${club.name} — уйдёт бесплатно по окончании сезона.`,
      });
      transfersTexts.push(`${name} подписал предконтракт с ${club.name}.`);
    }
  }

  // ── АКАДЕМИЯ (Фаза 3): набор воспитанников в неделю 4 каждого сезона ──
  const academyCreates: PrismaOps = [];
  if (week === ACADEMY_INTAKE_WEEK) {
    const academyRng = mulberry32(hashString(`${saveId}:academy:${season}`));
    for (const ctx of ctxs.values()) {
      const intake = runIntakeForClub({
        rng: academyRng,
        season,
        team: { id: ctx.team.id, strength: ctx.team.strength },
        squad: ctx.players,
        pool,
      });
      for (const player of intake.players) {
        player.teamId = ctx.team.id;
        player.shirtNumber = freeShirtNumbers(ctx.players, []);
        ctx.players.push(player);
        academyCreates.push(db.player.create({ data: playerCreateData(saveId, player) }));
      }
      // Новости набора — только клубу игрока
      if (ctx.team.id === userTeamId) {
        for (const text of intakeNews({ teamName: ctx.team.name, result: intake })) {
          pendingNews.push({ id: idFactory(), type: 'academy', message: text });
        }
      }
    }
  }

  // ── Сезонный переход (после финала кубка — последняя неделя сезона) ──
  const freeAgents: PlayerLike[] = week >= plan.totalWeeks
    ? ((await db.player.findMany({ where: { saveId, teamId: null } })) as unknown as PlayerLike[])
    : [];
  const activeListingPlayerIds = new Set(
    activeAfterExpiry
      .filter((l) => !soldListingIds.has(l.listingId))
      .map((l) => l.playerId),
  );
  // Проданные на этой неделе (офферы игрока + покупки ИИ): лот уже есть/ушёл,
  // free-лот не создаём (guard 5c §4.2)
  const soldThisWeekPlayerIds = new Set([
    ...aiPurchases.map((b) => b.playerId),
    ...soldUserListings.map((s) => s.playerId),
  ]);
  const boardForTransition = boardTargetCode !== null
    ? {
        targetCode: boardTargetCode,
        targetPlace: boardTargetPlace,
        confidence: boardConfidence, // после недельного апдейта
      }
    : null;
  const seasonEnded =
    week >= plan.totalWeeks
      ? buildSeasonTransition({
          saveId,
          season,
          week,
          leagueCode,
          ctxs,
          standings,
          cupWinnerTeamId,
          userTeamId,
          teamCount: N,
          pool,
          rng: mulberry32(hashString(`${saveId}:season:${season}`)),
          idFactory,
          freeAgents,
          board: boardForTransition,
          activeListingPlayerIds,
          soldThisWeekPlayerIds,
          guestSides,
        })
      : null;
  if (seasonEnded) {
    newBalance += seasonEnded.prize + seasonEnded.bonus;
    pendingNews.push({
      id: idFactory(),
      type: 'info',
      message: `Сезон ${season} завершён! Вы заняли ${seasonEnded.place} место и получили призовые €${seasonEnded.prize.toLocaleString('ru-RU')}.`,
    });
    transfersTexts.push(
      `Итоги сезона ${season}: ${seasonEnded.place} место, призовые €${seasonEnded.prize.toLocaleString('ru-RU')}.`,
    );
  }

  if (newBalance < 0) {
    pendingNews.push({
      id: idFactory(),
      type: 'finance',
      message: 'Клуб в минусе! Баланс ушёл ниже нуля — покупки заблокированы.',
    });
  }

  // ── Запись в БД (одна транзакция) ──
  const ops: PrismaOps = [];

  // Фаза 4: ленивое создание гостей евро (неделя 1/8) — СНАЧАЛА команды и
  // составы (FK: Match.homeTeamId → Team.id у евроматчей этой же недели);
  // пост-матч состояние недели уже в тех же объектах — createMany запишет итог
  if (lazyEuroNewGuests.length > 0) {
    ops.push(db.team.createMany({ data: lazyEuroNewGuests.map((g) => g.team) }));
    ops.push(db.player.createMany({ data: lazyEuroNewGuests.flatMap((g) => g.players) }));
  }
  // Фаза 4: ленивая миграция стилей легаси-ИИ
  ops.push(...styleMigOps);

  for (const pm of played) ops.push(...playedMatchOps(saveId, season, pm));
  for (const sched of scheduledCreates) {
    ops.push(
      db.match.create({
        data: {
          id: sched.id,
          saveId,
          season,
          week: sched.week,
          homeTeamId: sched.homeTeamId,
          awayTeamId: sched.awayTeamId,
          status: 'scheduled',
          competition: sched.competition,
          cupRound: sched.cupRound,
          isNeutral: sched.isNeutral,
        },
      }),
    );
  }

  // игроки (пост-матч/тренировки/межсезонье диффами)
  for (const row of playerRows) {
    const curr = row as unknown as PlayerLike;
    const orig = originals.get(curr.id);
    if (!orig) continue;
    const diff = playerDiff(orig, curr);
    if (diff) ops.push(db.player.update({ where: { id: curr.id }, data: diff }));
  }

  // финансы недели
  for (const rec of finance.records) {
    ops.push(
      db.financeRecord.create({
        data: {
          id: idFactory(),
          saveId,
          season,
          week,
          kind: rec.kind,
          category: rec.category,
          amount: rec.amount,
          description: rec.description,
        },
      }),
    );
  }
  if (cupPrize > 0) {
    ops.push(
      db.financeRecord.create({
        data: {
          id: idFactory(),
          saveId,
          season,
          week,
          kind: 'income',
          category: 'cup_prize',
          amount: cupPrize,
          description: 'Призовые за выступление в кубке',
        },
      }),
    );
  }
  // Фаза 4: призовые Кубка Европы (категория 'euro_prize', как cupPrize)
  if (euroPrize > 0) {
    ops.push(
      db.financeRecord.create({
        data: {
          id: idFactory(),
          saveId,
          season,
          week,
          kind: 'income',
          category: 'euro_prize',
          amount: euroPrize,
          description: 'Призовые за выступление в Кубке Европы',
        },
      }),
    );
  }
  for (const sale of soldUserListings) {
    ops.push(
      db.financeRecord.create({
        data: {
          id: idFactory(),
          saveId,
          season,
          week,
          kind: 'income',
          category: 'transfer_in',
          amount: sale.price,
          description: `Продажа игрока: ${sale.name}`,
        },
      }),
    );
  }

  // продажи игрока: игрок → свободный агент
  for (const sale of soldUserListings) {
    ops.push(db.player.update({ where: { id: sale.playerId }, data: { teamId: null } }));
  }
  // покупки ИИ: игрок → клуб ИИ (+ новый контракт, Фаза 3)
  for (const buy of aiPurchases) {
    ops.push(
      db.player.update({
        where: { id: buy.playerId },
        data: { teamId: buy.teamId, shirtNumber: buy.shirtNumber, contractUntil: buy.contractUntil },
      }),
    );
  }
  // лоты: истечение/продажа
  for (const [id, data] of listingUpdates) {
    ops.push(
      db.transferListing.update({
        where: { id },
        data: soldListingIds.has(id) ? { status: 'sold' } : data,
      }),
    );
  }
  // новые лоты рынка
  for (const gen of newListings) {
    ops.push(db.player.create({ data: playerCreateData(saveId, gen.player) }));
    ops.push(
      db.transferListing.create({
        data: {
          id: idFactory(),
          saveId,
          playerId: gen.player.id,
          price: gen.price,
          askFactor: gen.askFactor,
          source: 'market',
          status: 'active',
          expiresAt: gen.expiresAt,
        },
      }),
    );
  }

  // новости
  for (const n of pendingNews) {
    ops.push(
      db.newsItem.create({
        data: { id: n.id, saveId, season, week, type: n.type, message: n.message },
      }),
    );
  }

  // воспитанники академии (Фаза 3): создаются напрямую (не в playerRows — дифф их не трогает)
  ops.push(...academyCreates);

  const sacked = sackedMidSeason || (seasonEnded?.sacked ?? false);

  // сейв (переход: season+1, week=1, кубок сброшен; Фаза 3: правление + статус)
  ops.push(
    db.gameSave.update({
      where: { id: saveId },
      data: {
        balance: newBalance,
        week: seasonEnded ? 1 : week + 1,
        season: seasonEnded ? season + 1 : season,
        status: sacked ? 'finished' : 'active',
        ...(sacked ? { finishReason: 'sacked' } : {}),
        cupRound: seasonEnded ? 0 : newCupRound,
        cupAliveTeamIds: seasonEnded ? null : newCupAlive,
        // ── Фаза 4: Кубок Европы (переход — состояние нового сезона, см. §5.6-8) ──
        euroSeason: seasonEnded ? seasonEnded.euroNextState.season : newEuroSeason,
        euroRound: seasonEnded ? 0 : newEuroRound,
        euroAliveTeamIds: seasonEnded ? seasonEnded.euroNextState.alive : newEuroAlive,
        euroParticipants: seasonEnded ? seasonEnded.euroNextState.participants : newEuroParticipants,
        // ── Фаза 3: правление ──
        boardConfidence: seasonEnded ? seasonEnded.confidenceNext : boardConfidence,
        boardWarnings: seasonEnded ? 0 : boardWarnings,
        boardLowStreak: seasonEnded ? 0 : boardLowStreak,
        ...(boardLazyInit
          ? {
              boardTarget: boardLazyInit.target.code,
              boardTargetPlace: boardLazyInit.target.place,
              honeymoonUntilWeek: boardLazyInit.honeymoonUntilWeek,
            }
          : {}),
        ...(seasonEnded?.nextTarget
          ? {
              boardTarget: seasonEnded.nextTarget.code,
              boardTargetPlace: seasonEnded.nextTarget.place,
              honeymoonUntilWeek: BOARD_HONEYMOON_WEEKS,
            }
          : {}),
      },
    }),
  );

  ops.push(...(seasonEnded ? seasonEnded.extraOps : []));

  await db.$transaction(ops);

  // ── Ответ ──
  const newsDTO: NewsDTO[] = pendingNews.map((n) => ({
    id: n.id,
    season,
    week,
    type: n.type,
    message: n.message,
  }));

  return {
    season,
    week,
    weekType,
    weekLabel,
    // Фаза 4 (§5.2-12): 0..2 матча клуба игрока в порядке игры
    userMatches: userMatchDtos,
    weekResults: played.map((m) => ({
      homeId: m.homeTeamId,
      awayId: m.awayTeamId,
      homeGoals: m.homeGoals,
      awayGoals: m.awayGoals,
      homePens: m.homePens,
      awayPens: m.awayPens,
    })),
    cupRound: cupNextRound
      ? { round: cupNextRound.round, label: cupNextRound.label, drawn: true, pairs: cupNextRound.pairs }
      : null,
    // Фаза 4: жеребьёвка следующего раунда Кубка Европы (пары) — экран «Европа»
    euroRound: euroRoundDto,
    finances: {
      wages: finance.wages,
      sponsor: finance.sponsor,
      tickets: finance.tickets,
      // ── Модуль 5: ТВ-отчисления (легаси-зеркало: computeWeekFinance без tvBase → 0) ──
      tv: finance.tv,
      cupPrize,
      euroPrize,
      // ── D-5: содержание зданий и мерч уже внутри finance.net (легаси-зеркало) ──
      buildingsUpkeep: 0,
      merch: 0,
      net: finance.net + cupPrize + euroPrize,
    },
    news: newsDTO,
    transfers: transfersTexts,
    // ── Фаза 3 ──
    board: boardUpdateResult
      ? {
          confidence: boardUpdateResult.confidence,
          delta: boardUpdateResult.delta,
          jobStatusLabel: jobStatusOf(boardUpdateResult.confidence).label,
        }
      : null,
    sacked,
    seasonEnded: seasonEnded
      ? {
          standings: seasonEnded.standings,
          place: seasonEnded.place,
          prize: seasonEnded.prize,
          awards: seasonEnded.awards,
          boardVerdict: seasonEnded.boardVerdict,
          // Фаза 4: евро-итог + квалификация в следующий сезон (§7.7)
          euro: seasonEnded.euroNextDto,
        }
      : null,
  };
}

'use client';

import { useMemo } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { applySubs, awayKitOf, deriveRadar, formationChips, sentOffIds, shiftedChip, type RadarChip } from '@/lib/game/radar';
import type { MatchEvent, UserMatchResultDTO } from '@/lib/game/types';
import { cn } from '@/lib/utils';

/** Пружина позиций фишек/мяча: «живое» поле, не телепорт. */
const CHIP_SPRING = { type: 'spring', stiffness: 60, damping: 16, mass: 0.9 } as const;
const BALL_SPRING = { type: 'spring', stiffness: 90, damping: 15 } as const;

/** Цветовая подгонка текста фишки под фон формы. */
function readableTextOn(bg: string): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(bg.trim());
  if (!m) return '#FFFFFF';
  const n = Number.parseInt(m[1], 16);
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  return 0.299 * r + 0.587 * g + 0.114 * b > 140 ? '#0B1220' : '#FFFFFF';
}

const TONE_COLOR: Record<string, string> = {
  goal: '#22C55E',
  shot: '#00D4FF',
  card: '#FACC15',
  neutral: '#A78BFA',
};

/** Одна фишка: круг с номером + подпись, тянется к мячу (spring). */
function RadarChipView({
  chip,
  color,
  sentOff,
  hot,
  showName,
  isGk,
}: {
  chip: RadarChip;
  color: string;
  sentOff: boolean;
  hot: boolean;
  showName: boolean;
  isGk: boolean;
}) {
  const label = chip.number !== null ? String(chip.number) : chip.position;
  return (
    <motion.div
      className="absolute"
      style={{ zIndex: hot ? 30 : 20, transform: 'translate(-50%, -50%)' }}
      initial={false}
      animate={{ left: `${chip.baseX}%`, top: `${chip.baseY}%` }}
      transition={CHIP_SPRING}
    >
      <motion.span
        initial={false}
        animate={{ scale: hot ? 1.16 : 1 }}
        transition={{ type: 'spring', stiffness: 320, damping: 22 }}
        className={cn(
          'flex size-6 items-center justify-center rounded-full border text-[10px] font-black leading-none tabular select-none sm:size-7 sm:text-[11px]',
          'shadow-[0_2px_8px_rgba(0,0,0,0.55)]',
          sentOff && 'opacity-35 grayscale',
          isGk && 'border-dashed',
        )}
        style={{
          backgroundColor: color,
          borderColor: hot ? '#FFFFFF' : 'rgba(255,255,255,0.75)',
          color: readableTextOn(color),
          boxShadow: hot ? `0 0 0 3px rgba(255,255,255,0.35), 0 0 18px ${color}` : undefined,
        }}
        title={`${chip.name} · ${chip.position}${sentOff ? ' · удалён' : ''}`}
      >
        {label}
      </motion.span>
      {showName ? (
        <span
          className="absolute left-1/2 top-full mt-0.5 -translate-x-1/2 whitespace-nowrap rounded bg-background/85 px-1 text-[8px] font-semibold leading-tight text-foreground/90 sm:text-[9px]"
        >
          {chip.short}
        </span>
      ) : null}
    </motion.div>
  );
}

/** Пульс-маркер события (гол/удар/карточка) — расходящееся кольцо. */
function MarkerView({ x, y, tone, label }: { x: number; y: number; tone: string; label: string }) {
  const color = TONE_COLOR[tone] ?? TONE_COLOR.neutral;
  return (
    <div
      className="pointer-events-none absolute"
      style={{ left: `${x}%`, top: `${y}%`, transform: 'translate(-50%, -50%)', zIndex: 15 }}
      aria-hidden
    >
      <motion.span
        initial={{ scale: 0.2, opacity: 0.9 }}
        animate={{ scale: 2.4, opacity: 0 }}
        transition={{ duration: 1.8, ease: 'easeOut' }}
        className="absolute size-6 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 sm:size-8"
        style={{ borderColor: color }}
      />
      <motion.span
        initial={{ scale: 0.4, opacity: 1 }}
        animate={{ scale: 1, opacity: 0.15 }}
        transition={{ duration: 1.8, ease: 'easeOut' }}
        className="absolute size-4 -translate-x-1/2 -translate-y-1/2 rounded-full sm:size-5"
        style={{ backgroundColor: color }}
      />
      <span
        className="absolute left-2 top-[-6px] whitespace-nowrap rounded px-1 text-[9px] font-black uppercase tracking-wide"
        style={{ color, textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}
      >
        {label}
      </span>
    </div>
  );
}

/**
 * Модуль 6 — 2D-радар живого матча: поле 0..100 (X — атака хозяев слева→направо),
 * 22 фишки стартовых XI (замены/удаления применяются на лету), мяч со шлейфом,
 * пульс-маркеры событий, сдвиг блоков к мячу.
 */
export function MatchRadar({
  match,
  liveMinute,
  showNames = true,
  className,
}: {
  match: UserMatchResultDTO;
  liveMinute: number;
  showNames?: boolean;
  className?: string;
}) {
  const visible = useMemo<MatchEvent[]>(
    () => match.events.filter((e) => e.minute <= liveMinute),
    [match.events, liveMinute],
  );

  const radar = useMemo(() => deriveRadar(visible, 2), [visible]);

  const sentOff = useMemo(() => sentOffIds(visible), [visible]);

  const homeChips = useMemo(() => {
    const base = formationChips(match.home.formation, match.homeXI, 'home');
    return applySubs(base, visible).map((c) => shiftedChip(c, radar.ballX, radar.ballY, sentOff.has(c.playerId ?? '')));
  }, [match.home.formation, match.homeXI, visible, radar.ballX, radar.ballY, sentOff]);

  const awayChips = useMemo(() => {
    const base = formationChips(match.away.formation, match.awayXI, 'away');
    return applySubs(base, visible).map((c) => shiftedChip(c, radar.ballX, radar.ballY, sentOff.has(c.playerId ?? '')));
  }, [match.away.formation, match.awayXI, visible, radar.ballX, radar.ballY, sentOff]);

  const awayColor = useMemo(
    () => awayKitOf(match.home.colorPrimary, match.away.colorPrimary, match.away.colorSecondary),
    [match.home.colorPrimary, match.away.colorPrimary, match.away.colorSecondary],
  );

  // Вратари — пунктирная обводка
  const isGk = (chip: RadarChip) => chip.position === 'GK';
  const hotId = radar.hotPlayerId;

  const last = radar.lastLine;

  return (
    <div className={cn('overflow-hidden rounded-xl border-2 border-[#00D4FF]/30 shadow-[0_0_24px_rgba(0,212,255,0.12)]', className)}>
      {/* Заголовок радара: команды + направление атаки */}
      <div className="flex items-center justify-between gap-2 border-b border-border/60 bg-card/80 px-3 py-1.5">
        <span className="flex min-w-0 items-center gap-1.5 text-[11px] font-bold">
          <span
            className="size-2.5 shrink-0 rounded-full"
            style={{ backgroundColor: match.home.colorPrimary }}
            aria-hidden
          />
          <span className="truncate">{match.home.shortName}</span>
          <span className="text-muted-foreground" aria-hidden>→</span>
        </span>
        <span className="shrink-0 text-[10px] font-bold uppercase tracking-[0.14em] text-primary/80">
          Тактический радар
        </span>
        <span className="flex min-w-0 items-center gap-1.5 text-[11px] font-bold">
          <span className="text-muted-foreground" aria-hidden>←</span>
          <span className="truncate">{match.away.shortName}</span>
          <span
            className="size-2.5 shrink-0 rounded-full"
            style={{ backgroundColor: awayColor }}
            aria-hidden
          />
        </span>
      </div>

      {/* Поле (горизонтальное): X 0..100 → влево→вправо, Y 0..100 → сверху→вниз */}
      <div
        className="pitch relative w-full"
        style={{ aspectRatio: '8 / 5' }}
        role="img"
        aria-label={`2D-радар: ${match.home.shortName} против ${match.away.shortName}, минута ${liveMinute}`}
      >
        {/* Разметка */}
        <div className="pointer-events-none absolute inset-2 rounded-md border chalk" aria-hidden />
        <div className="pointer-events-none absolute inset-y-2 left-1/2 border-l chalk" aria-hidden />
        <div
          className="pointer-events-none absolute left-1/2 top-1/2 size-[22%] -translate-x-1/2 -translate-y-1/2 rounded-full border chalk"
          aria-hidden
        />
        {/* Штрафные хозяев (лево) и гостей (право) */}
        <div className="pointer-events-none absolute inset-y-[16%] left-2 w-[13%] border chalk" aria-hidden />
        <div className="pointer-events-none absolute inset-y-[16%] right-2 w-[13%] border chalk" aria-hidden />
        <div className="pointer-events-none absolute inset-y-[36%] left-2 w-[5%] border chalk" aria-hidden />
        <div className="pointer-events-none absolute inset-y-[36%] right-2 w-[5%] border chalk" aria-hidden />
        {/* Ворота */}
        <div className="pointer-events-none absolute inset-y-[42%] left-[1.2%] w-[1.4%] border border-[#00D4FF]/60 bg-[#00D4FF]/10" aria-hidden />
        <div className="pointer-events-none absolute inset-y-[42%] right-[1.2%] w-[1.4%] border border-[#00D4FF]/60 bg-[#00D4FF]/10" aria-hidden />

        {/* Шлейф мяча (последние точки — угасающие) */}
        {radar.trail.slice(0, -1).map((t, i, arr) => (
          <span
            key={`${t.x}-${t.y}-${i}`}
            className="pointer-events-none absolute rounded-full bg-white"
            style={{
              left: `${t.x}%`,
              top: `${t.y}%`,
              width: 4,
              height: 4,
              opacity: 0.08 + (0.28 * (i + 1)) / (arr.length + 1),
              transform: 'translate(-50%, -50%)',
            }}
            aria-hidden
          />
        ))}

        {/* Фишки */}
        {homeChips.map((chip) => (
          <RadarChipView
            key={chip.key}
            chip={chip}
            color={match.home.colorPrimary}
            sentOff={sentOff.has(chip.playerId ?? '')}
            hot={hotId !== null && chip.playerId === hotId}
            showName={showNames}
            isGk={isGk(chip)}
          />
        ))}
        {awayChips.map((chip) => (
          <RadarChipView
            key={chip.key}
            chip={chip}
            color={awayColor}
            sentOff={sentOff.has(chip.playerId ?? '')}
            hot={hotId !== null && chip.playerId === hotId}
            showName={showNames}
            isGk={isGk(chip)}
          />
        ))}

        {/* Маркеры событий */}
        <AnimatePresence>
          {radar.markers.map((m) => (
            <MarkerView key={m.id} x={m.x} y={m.y} tone={m.tone} label={m.label} />
          ))}
        </AnimatePresence>

        {/* Мяч */}
        <motion.span
          className="absolute z-40 flex size-3 items-center justify-center rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.9),0_1px_4px_rgba(0,0,0,0.6)]"
          initial={false}
          animate={{ left: `${radar.ballX}%`, top: `${radar.ballY}%` }}
          transition={BALL_SPRING}
          style={{ transform: 'translate(-50%, -50%)' }}
          aria-hidden
        />

        {/* Стоп-кадр: кик-офф/перерыв — лёгкая вспышка центра */}
        {visible.some((e) => (e.type === 'kickoff' || e.type === 'halftime' || e.type === 'fulltime') && e.minute === visible[visible.length - 1]?.minute) ? (
          <motion.span
            initial={{ opacity: 0.6, scale: 0.9 }}
            animate={{ opacity: 0, scale: 1.6 }}
            transition={{ duration: 1.2 }}
            className="pointer-events-none absolute left-1/2 top-1/2 size-[24%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#00D4FF]/50"
            aria-hidden
          />
        ) : null}
      </div>

      {/* Комментарий последнего события */}
      <div className="flex min-h-9 items-center gap-2 border-t border-border/60 bg-card/80 px-3 py-1.5">
        <span className="shrink-0 rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-bold tabular text-primary">
          {liveMinute}&apos;
        </span>
        {last ? (
          <p className="min-w-0 flex-1 truncate text-[11px] leading-tight text-foreground/90" title={last.text}>
            {last.text}
          </p>
        ) : (
          <p className="text-[11px] text-muted-foreground">Команды на поле — ожидаем свисток…</p>
        )}
      </div>
    </div>
  );
}

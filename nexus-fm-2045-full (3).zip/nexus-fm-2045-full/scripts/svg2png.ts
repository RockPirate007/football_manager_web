/**
 * D-9 (спека §7.1, прим. 3): logo.svg → public/logo.png 512x512.
 * Иконка нужна Neutralino: modes.window.icon /public/logo.png (окно) и
 * exepatch CLI (PE-ресурсы .exe: png2icons → ICO из этого PNG).
 *
 * sharp растеризует SVG по плотности: viewBox 30x30 при density 3600
 * даёт ~1500px — ресайзим в 512x512 (без искажений, letterbox не нужен:
 * иконка квадратная).
 *
 * Запуск: bun scripts/svg2png.ts (идемпотентен: перезаписывает logo.png).
 */
import sharp from 'sharp';

const SRC = 'public/logo.svg';
const DST = 'public/logo.png';
const SIZE = 512;

async function main(): Promise<void> {
  // density: 30 (viewBox) * 120 = 3600 dpi-единиц → рендер 1500px, даунскейл к 512
  const png = await sharp(SRC, { density: 3600 })
    .resize(SIZE, SIZE, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toBuffer();
  await sharp(png).toFile(DST);
  const meta = await sharp(DST).metadata();
  console.log(`svg2png: ${DST} ${meta.width}x${meta.height} OK`);
}

main().catch((err) => {
  console.error('svg2png: FAIL', err);
  process.exit(1);
});

import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';

/** Тайл-карточка дашборда: иконка, значение, подпись. */
export function StatCard({
  icon: Icon,
  value,
  label,
  tone = 'default',
  footer,
  className,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
  tone?: 'default' | 'success' | 'warning' | 'danger';
  footer?: React.ReactNode;
  className?: string;
}) {
  const toneClass = {
    default: 'text-foreground',
    success: 'text-[#22C55E]',
    warning: 'text-[#FACC15]',
    danger: 'text-[#EF4444]',
  }[tone];

  const iconClass = {
    default: 'text-muted-foreground',
    success: 'text-[#22C55E]',
    warning: 'text-[#FACC15]',
    danger: 'text-[#EF4444]',
  }[tone];

  return (
    <Card className={cn('border-border/70', className)}>
      <CardContent className="flex items-start gap-3 p-4">
        <div className="mt-0.5 rounded-md bg-secondary p-2">
          <Icon className={cn('size-4', iconClass)} aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <div className={cn('truncate text-lg font-bold tabular leading-tight', toneClass)}>
            {value}
          </div>
          <div className="mt-0.5 text-xs text-muted-foreground">{label}</div>
          {footer ? <div className="mt-2 text-xs">{footer}</div> : null}
        </div>
      </CardContent>
    </Card>
  );
}

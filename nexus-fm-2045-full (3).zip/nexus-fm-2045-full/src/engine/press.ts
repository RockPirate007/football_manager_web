/**
 * D-7 «Медиа»: генератор газетных вырезок (спека §5.1–5.4) — ЧИСТЫЙ модуль
 * без db-обращений (паттерн buildings.ts/manager.ts): классификатор контекста
 * (11 контекстов по приоритету §5.2), шаблоны заголовков ≤70 знаков с
 * подстановками {user}/{opp}/{score}/{player}/{city}, подзаголовок ≤120,
 * MOTM через computeMatchRating с сидами `${saveId}:press:${matchId}[:playerId]`,
 * выдержка с топ-2 оценками + фраза-клише, карточки-моменты (goal > red >
 * pens > injury > yellow, топ-3 по минуте) и спецвыпуск «сын в академии».
 * Записи создаёт week.ts (db.newspaperClipping.create); архив ≤ 60 (§5.4).
 */

import type { NewspaperClippingRecord } from './models';
import { computeMatchRating } from '@/lib/game/progression';
import { hashString, mulberry32 } from '@/lib/game/rng';
import type { PlayerLike } from '@/lib/game/players';
import type { MatchEvent } from '@/lib/game/types';

// ── Типы вырезки (§5.2–5.4) ────────────────────────────────────────────────

/** Контекст выпуска — 11 значений классификатора §5.2. */
export type PressContext =
  | 'cup_final_heartbreak'
  | 'hat_trick'
  | 'sensation'
  | 'big_win'
  | 'thrashing'
  | 'clean_sheet_win'
  | 'derby'
  | 'draw'
  | 'narrow_loss'
  | 'plain_win'
  | 'special_son';

/** Тип карточки-момента (§5.3: kind = 'goal'|'red'|'pens'|'injury'|'yellow'). */
export type PressMomentKind = 'goal' | 'red' | 'pens' | 'injury' | 'yellow';

/** Карточка-момент: минута + готовый event.text движка (русский). */
export interface PressMoment {
  minute: number;
  kind: PressMomentKind;
  text: string;
}

/** Игрок матча (§5.3): rating ×10 (78 = 7.8), clamp 4.5–10.0 уже в формуле. */
export interface PressMotm {
  playerId: string;
  name: string;
  position: string;
  rating: number;
}

/** Черновик записи newspaperClipping (id/saveId/createdAt ставит week.ts). */
export type ClippingDraft = Omit<NewspaperClippingRecord, 'id' | 'saveId' | 'createdAt'>;

/** Команда в терминах прессы: ровно поля классификатора/подстановок. */
export interface PressTeamInfo {
  id: string;
  name: string;
  city: string | null;
  strength: number;
}

// ── Константы (§5.2–5.4/§5.6) ──────────────────────────────────────────────

/** Название издания — шапка номера (§5.6). */
export const PRESS_NEWSPAPER_NAME = 'Спортивный Вестник';

/** Лимит архива вырезок (§5.4): последние 60 по (season, week, createdAt). */
export const PRESS_ARCHIVE_LIMIT = 60;

/** Максимум длины заголовка (§5.2). */
export const PRESS_HEADLINE_MAX = 70;

/** Максимум длины подзаголовка (§5.2). */
export const PRESS_SUBHEADLINE_MAX = 120;

/** Шаблоны заголовков по контекстам (§5.2, дословно; 2–3 на контекст). */
export const PRESS_HEADLINES: Record<PressContext, readonly string[]> = {
  cup_final_heartbreak: [
    'Серебро с горечью: финал кубка упущен — {score}',
    'Так близко: {user} проигрывает финал {score}',
  ],
  hat_trick: [
    'Хет-трик {player}! {user} побеждает — {score}',
    'Трижды {player}: мяч за мячом, {score}',
  ],
  sensation: [
    'Сенсация! {user} поверг {opp} — {score}',
    'Невероятный вечер: {user} выигрывает {score}',
    '{opp} повержен — сенсационные {score}',
  ],
  big_win: [
    'Разнос: {user} громит {opp} — {score}',
    '{user} безжалостен: {score}',
    'Яркий вечер на трибунах: {score} в пользу {user}',
  ],
  thrashing: [
    'Чёрный день: {user} разгромлен — {score}',
    '{opp} разбирает {user} со счётом {score}',
  ],
  clean_sheet_win: [
    'На ноль: {user} уверенно берёт верх — {score}',
    'Сухая победа: {score}, ворота на замке',
  ],
  derby: [
    'Дерби! {user} против {opp} — {score}',
    'Город говорит: {user} выигрывает дерби {score}',
    'Дерби за {city}: {score}',
  ],
  draw: [
    'Миром разошлись: {score}',
    'Очки поделены: {user} и {opp} — {score}',
  ],
  narrow_loss: [
    'Минимальное поражение: {score}',
    '{user} уступает — {score} в упорной борьбе',
  ],
  plain_win: [
    'Дело сделано: {user} — {score}',
    'Верная победа: {score}',
  ],
  special_son: [
    'Сын тренера — в академии {user}!',
    '{player} продолжает династию: путь в академии начат',
  ],
};

/** Фразы-клише выдержки — по одной на контекст (§5.3; big_win — из спеки). */
export const PRESS_PHRASES: Record<PressContext, string> = {
  cup_final_heartbreak: 'Финал есть финал: трофей уплыл, но болельщики запомнят этот путь.',
  hat_trick: 'Три мяча за вечер — редкость, за такими вечерами и ходят на стадион.',
  sensation: 'Сенсации и делают футбол: вечер, который останется в истории клуба.',
  big_win: 'Команда в ударе — болельщики требуют продолжения банкета.',
  thrashing: 'Тяжёлый вечер: разбирать ошибки придётся ещё неделю.',
  clean_sheet_win: 'Порядок в обороне — половина победы, и сегодня она была безупречной.',
  derby: 'Дерби — это больше чем три очка: город будет обсуждать его до следующего.',
  draw: 'Очки поделены: игра равных, и это честный итог.',
  narrow_loss: 'До очка не хватило самых мелких деталей.',
  plain_win: 'Рабочая победа без лишних эмоций — такие берут дистанцию.',
  special_son: 'Новая страница семейной истории: династия получает продолжение.',
};

/** Подписи соревнований для подзаголовка/шапки (§5.2/§5.6). */
export const PRESS_COMPETITION_LABELS: Record<string, string> = {
  league: 'Чемпионат',
  cup: 'Кубок',
  euro: 'Кубок Европы',
  academy: 'Молодёжная академия',
};

/** Приоритет событий для карточек-моментов (§5.3): goal(3) > red(2.5) > pen_save(2) > injury(1.5) > yellow(1). */
const MOMENT_RULES: ReadonlyArray<{ type: MatchEvent['type']; kind: PressMomentKind; priority: number }> = [
  { type: 'goal', kind: 'goal', priority: 3 },
  // Серия пенальти: удары/сэйвы/итог (минуты 94+, playerId может отсутствовать
  // у итоговой строки) — карточка «пенальти», приоритет как pen_save(2).
  { type: 'pen_goal', kind: 'pens', priority: 2 },
  { type: 'pen_save', kind: 'pens', priority: 2 },
  { type: 'red', kind: 'red', priority: 2.5 },
  { type: 'injury', kind: 'injury', priority: 1.5 },
  { type: 'yellow', kind: 'yellow', priority: 1 },
];

// ── Классификатор контекста (§5.2) ─────────────────────────────────────────

/** Вход классификатора: всё с точки зрения клуба игрока. */
export interface PressMatchContextInput {
  competition: 'league' | 'cup' | 'euro';
  /** Раунд матча = финал кубка (plan.cupRounds). */
  isCupFinal: boolean;
  /** Исход для клуба игрока; победа по пенальти = W (конвенция applyMatchEffects). */
  outcome: 'W' | 'D' | 'L';
  /** Голы клуба игрока. */
  userGoals: number;
  /** Голы соперника. */
  oppGoals: number;
  /** События матча (обе команды). */
  events: MatchEvent[];
  userTeamId: string;
  /** Сила соперника − сила клуба игрока (со знаком). */
  strengthGap: number;
  /** Место клуба игрока в таблице (лига, после матча); null — нет таблицы. */
  userPlace: number | null;
  /** Место соперника; null — нет таблицы. */
  oppPlace: number | null;
  userCity: string | null;
  oppCity: string | null;
}

/** Голы игроков клуба игрока по событиям goal/pen_goal (§5.2: хет-трик). */
export function userGoalsByPlayer(events: MatchEvent[], userTeamId: string): Map<string, number> {
  const goals = new Map<string, number>();
  for (const e of events) {
    if (e.teamId !== userTeamId || !e.playerId) continue;
    if (e.type === 'goal' || e.type === 'pen_goal') {
      goals.set(e.playerId, (goals.get(e.playerId) ?? 0) + 1);
    }
  }
  return goals;
}

/**
 * Классификатор — первое совпадение сверху (§5.2). Поражение в серии пенальти
 * (ничья по голам) не попадает ни в narrow_loss (разница 0), ни в draw по
 * исходу — замыкающий fallback возвращает draw (счёт-то ничейный).
 */
export function classifyPressContext(input: PressMatchContextInput): PressContext {
  const { outcome } = input;
  const diff = input.userGoals - input.oppGoals;

  // 1. cup_final_heartbreak: кубок, финал, клуб проиграл
  if (input.competition === 'cup' && input.isCupFinal && outcome === 'L') return 'cup_final_heartbreak';

  // 2. hat_trick: игрок клуба забил ≥ 3 голов (goal/pen_goal)
  for (const n of userGoalsByPlayer(input.events, input.userTeamId).values()) {
    if (n >= 3) return 'hat_trick';
  }

  // 3. sensation: победа И (сила соперника − сила клуба ≥ 8 ИЛИ место соперника выше на ≥ 5)
  if (
    outcome === 'W'
    && (input.strengthGap >= 8
      || (input.userPlace !== null && input.oppPlace !== null && input.userPlace - input.oppPlace >= 5))
  ) {
    return 'sensation';
  }

  // 4. big_win: победа с разницей ≥ 3
  if (outcome === 'W' && diff >= 3) return 'big_win';

  // 5. thrashing: поражение с разницей ≥ 3
  if (outcome === 'L' && diff <= -3) return 'thrashing';

  // 6. clean_sheet_win: победа с 0 пропущенных
  if (outcome === 'W' && input.oppGoals === 0) return 'clean_sheet_win';

  // 7. derby: один город (непустые) — любой исход
  if (input.userCity !== null && input.oppCity !== null && input.userCity === input.oppCity) return 'derby';

  // 8. draw: ничья
  if (outcome === 'D') return 'draw';

  // 9. narrow_loss: поражение с разницей 1–2
  if (outcome === 'L' && diff >= -2) return 'narrow_loss';

  // 10. plain_win: обычная победа
  if (outcome === 'W') return 'plain_win';

  // Поражение по пенальти при ничейном счёте — газетный итог «миром».
  return 'draw';
}

// ── Заголовок/подзаголовок (§5.2) ───────────────────────────────────────────

/** Подстановка {user}/{opp}/{score}/{player}/{city} в шаблон заголовка. */
export function fillHeadlineTemplate(
  template: string,
  values: { user: string; opp: string; score: string; player: string; city: string },
): string {
  return template
    .replace(/\{user\}/g, values.user)
    .replace(/\{opp\}/g, values.opp)
    .replace(/\{score\}/g, values.score)
    .replace(/\{player\}/g, values.player)
    .replace(/\{city\}/g, values.city);
}

// ── Карточки-моменты (§5.3) ────────────────────────────────────────────────

/** Топ-3 события матча по приоритету, затем сортировка по минуте. */
export function pickMoments(events: MatchEvent[]): PressMoment[] {
  const scored: { moment: PressMoment; priority: number; index: number }[] = [];
  events.forEach((e, index) => {
    // Маркеры начала серии пенальти (без teamId) — не карточки
    if (e.type === 'pen_goal' && e.teamId === undefined) return;
    const rule = MOMENT_RULES.find((r) => r.type === e.type);
    if (!rule) return;
    scored.push({
      moment: { minute: e.minute, kind: rule.kind, text: e.text },
      priority: rule.priority,
      index,
    });
  });
  scored.sort((a, b) =>
    b.priority - a.priority || a.moment.minute - b.moment.minute || a.index - b.index,
  );
  return scored
    .slice(0, 3)
    .map((s) => s.moment)
    .sort((a, b) => a.minute - b.minute || a.text.localeCompare(b.text));
}

// ── Пресс-рейтинги и MOTM (§5.3) ────────────────────────────────────────────

interface PlayerMatchStat {
  goals: number;
  assists: number;
  yellows: number;
  reds: number;
}

/** Статистика игроков клуба игрока по его событиям (goal/pen_goal — голы). */
function userStatsByPlayer(events: MatchEvent[], userTeamId: string): Map<string, PlayerMatchStat> {
  const stats = new Map<string, PlayerMatchStat>();
  const statOf = (id: string): PlayerMatchStat =>
    stats.get(id) ?? { goals: 0, assists: 0, yellows: 0, reds: 0 };
  for (const e of events) {
    if (e.teamId !== userTeamId) continue;
    if (e.playerId) {
      if (e.type === 'goal' || e.type === 'pen_goal') {
        const s = statOf(e.playerId);
        s.goals += 1;
        stats.set(e.playerId, s);
      }
      if (e.type === 'yellow' || e.type === 'red') {
        const s = statOf(e.playerId);
        if (e.type === 'yellow') s.yellows += 1;
        else s.reds += 1;
        stats.set(e.playerId, s);
      }
    }
    if ((e.type === 'goal' || e.type === 'pen_goal') && e.assistId) {
      const s = statOf(e.assistId);
      s.assists += 1;
      stats.set(e.assistId, s);
    }
  }
  return stats;
}

/** Результаты пресс-оценок: игравшие (стартёры + вышедшие) в порядке состава. */
export interface PressRatedPlayer {
  playerId: string;
  name: string;
  position: string;
  rating: number; // ×10
}

/**
 * Пресс-рейтинги игроков клуба (§5.3): computeMatchRating на СВОИХ сидах
 * `${saveId}:press:${matchId}:${playerId}` — не влияют на ratingSum.
 */
export function computePressRatings(args: {
  saveId: string;
  matchId: string;
  userTeamId: string;
  outcome: 'W' | 'D' | 'L';
  goalsConceded: number;
  players: PlayerLike[];
  starterIds: ReadonlySet<string>;
  subInIds: ReadonlySet<string>;
  events: MatchEvent[];
}): PressRatedPlayer[] {
  const stats = userStatsByPlayer(args.events, args.userTeamId);
  const out: PressRatedPlayer[] = [];
  for (const p of args.players) {
    const played = args.starterIds.has(p.id) || args.subInIds.has(p.id);
    if (!played) continue;
    const st = stats.get(p.id) ?? { goals: 0, assists: 0, yellows: 0, reds: 0 };
    const rating = computeMatchRating({
      player: p,
      outcome: args.outcome,
      goals: st.goals,
      assists: st.assists,
      yellows: st.yellows,
      reds: st.reds,
      goalsConceded: args.goalsConceded,
      rng: mulberry32(hashString(`${args.saveId}:press:${args.matchId}:${p.id}`)),
    });
    out.push({
      playerId: p.id,
      name: `${p.firstName} ${p.lastName}`,
      position: p.position,
      rating,
    });
  }
  return out;
}

// ── Генерация вырезки матча (§5.1–5.3) ─────────────────────────────────────

/** Полный вход buildClipping: всё, что week.ts знает о матче клуба игрока. */
export interface PressMatchInput {
  saveId: string;
  season: number;
  week: number;
  matchId: string;
  competition: 'league' | 'cup' | 'euro';
  /** Финал кубка (раунд = plan.cupRounds). */
  isCupFinal: boolean;
  /** Подпись раунда («1/8 финала») — кубок/евро. */
  roundLabel: string | null;
  /** Подпись недели («Тур 8/38») — лига. */
  weekLabel: string;
  userTeam: PressTeamInfo;
  oppTeam: PressTeamInfo;
  /** Место клуба игрока в таблице ПОСЛЕ матча (лига); null — нет таблицы. */
  userPlace: number | null;
  /** Место соперника (лига); null — нет таблицы. */
  oppPlace: number | null;
  /** Клуб игрока — хозяин? */
  userHome: boolean;
  homeName: string;
  awayName: string;
  homeGoals: number;
  awayGoals: number;
  homePens: number | null;
  awayPens: number | null;
  /** Победитель (кубок/евро, вкл. пенальти; лига — null). */
  winnerTeamId: string | null;
  /** Состав клуба игрока. */
  userPlayers: PlayerLike[];
  starterIds: ReadonlySet<string>;
  /** Вышедшие на замену (id). */
  subInIds: ReadonlySet<string>;
  /** Все события матча (обе команды). */
  events: MatchEvent[];
}

/**
 * Вырезка после матча клуба игрока (§5.1): классификация, заголовок (RNG
 * `${saveId}:press:${matchId}`), подзаголовок, MOTM, выдержка, моменты.
 */
export function buildClipping(input: PressMatchInput): ClippingDraft {
  const { saveId, season, week, matchId, competition } = input;
  const userTeamId = input.userTeam.id;
  const my = input.userHome ? input.homeGoals : input.awayGoals;
  const opp = input.userHome ? input.awayGoals : input.homeGoals;
  // Кубок/евро: победа по пенальти = победа (конвенция applyMatchEffects)
  const outcome: 'W' | 'D' | 'L' = input.winnerTeamId !== null
    ? (input.winnerTeamId === userTeamId ? 'W' : 'L')
    : my > opp ? 'W' : my === opp ? 'D' : 'L';

  const context = classifyPressContext({
    competition,
    isCupFinal: input.isCupFinal,
    outcome,
    userGoals: my,
    oppGoals: opp,
    events: input.events,
    userTeamId,
    strengthGap: input.oppTeam.strength - input.userTeam.strength,
    userPlace: input.userPlace,
    oppPlace: input.oppPlace,
    userCity: input.userTeam.city,
    oppCity: input.oppTeam.city,
  });

  // Герой хет-трика: первый по составу с ≥ 3 голами (goal/pen_goal)
  const goalsByPlayer = userGoalsByPlayer(input.events, userTeamId);
  let heroPlayer = '';
  let heroGoals = 0;
  for (const p of input.userPlayers) {
    const n = goalsByPlayer.get(p.id) ?? 0;
    if (n > heroGoals) {
      heroGoals = n;
      heroPlayer = `${p.firstName} ${p.lastName}`;
    }
  }

  // Заголовок: детерминированный выбор шаблона (§5.2)
  const templateRng = mulberry32(hashString(`${saveId}:press:${matchId}`));
  const templates = PRESS_HEADLINES[context];
  const template = templates[Math.floor(templateRng() * templates.length) % templates.length];
  const headline = fillHeadlineTemplate(template, {
    user: input.userTeam.name,
    opp: input.oppTeam.name,
    score: `${input.homeGoals}:${input.awayGoals}`,
    player: heroPlayer || 'герой матча',
    city: input.userTeam.city ?? input.oppTeam.city ?? 'город',
  });

  // Подзаголовок (§5.2): лига — тур и место; кубок/евро — раунд вместо места
  const subheadline = competition === 'league'
    ? `Чемпионат, ${input.weekLabel}. ${input.userTeam.name}`
      + (input.userPlace !== null ? ` — ${input.userPlace}-е место в таблице.` : '.')
    : `${PRESS_COMPETITION_LABELS[competition]}, ${input.roundLabel ?? 'раунд'}.`;

  // MOTM + выдержка: пресс-рейтинги на отдельных сидах (§5.3)
  const rated = computePressRatings({
    saveId,
    matchId,
    userTeamId,
    outcome,
    goalsConceded: opp,
    players: input.userPlayers,
    starterIds: input.starterIds,
    subInIds: input.subInIds,
    events: input.events,
  });
  const motm = rated.length > 0
    ? rated.reduce((best, r) => (r.rating > best.rating ? r : best))
    : null;
  const top = [...rated].sort((a, b) => b.rating - a.rating).slice(0, 2);
  const excerpt = top.length > 0
    ? `Лучшие у ${input.userTeam.name}: `
      + top.map((r) => `${r.name} (${(r.rating / 10).toFixed(1)})`).join(', ')
      + `. ${PRESS_PHRASES[context]}`
    : PRESS_PHRASES[context];

  return {
    season,
    week,
    matchId,
    competition,
    context,
    headline,
    subheadline,
    homeName: input.homeName,
    awayName: input.awayName,
    homeGoals: input.homeGoals,
    awayGoals: input.awayGoals,
    homePens: input.homePens,
    awayPens: input.awayPens,
    motm: motm !== null
      ? serializeMotm({
        playerId: motm.playerId,
        name: motm.name,
        position: motm.position,
        rating: motm.rating,
      })
      : null,
    excerpt,
    moments: JSON.stringify(pickMoments(input.events)),
  };
}

// ── Спецвыпуск «сын в академии» (§5.2-11, сезонный переход) ────────────────

/** Спецвыпуск: матчId нет, competition='academy', мотм/моментов нет. */
export function buildSonClipping(args: {
  saveId: string;
  season: number;
  week: number;
  userTeamName: string;
  son: { playerId: string; name: string; position: string };
}): ClippingDraft {
  const { saveId, season, week } = args;
  const templateRng = mulberry32(hashString(`${saveId}:press:academy:${season}`));
  const templates = PRESS_HEADLINES.special_son;
  const template = templates[Math.floor(templateRng() * templates.length) % templates.length];
  const headline = fillHeadlineTemplate(template, {
    user: args.userTeamName,
    opp: 'молодёжная академия',
    score: '—',
    player: args.son.name,
    city: '',
  });
  return {
    season,
    week,
    matchId: null,
    competition: 'academy',
    context: 'special_son',
    headline,
    subheadline: `Молодёжная академия, сезон ${season}`,
    homeName: args.userTeamName,
    awayName: 'Молодёжная академия',
    homeGoals: 0,
    awayGoals: 0,
    homePens: null,
    awayPens: null,
    motm: null,
    excerpt: PRESS_PHRASES.special_son,
    moments: '[]',
  };
}

// ── Сериализация JSON-полей записи (§5.4) ──────────────────────────────────

/** Канонический JSON motm (порядок ключей §5.4). */
export function serializeMotm(motm: PressMotm): string {
  return JSON.stringify({
    playerId: motm.playerId,
    name: motm.name,
    position: motm.position,
    rating: motm.rating,
  });
}

/** Толерантный разбор motm (битый JSON → null, как parseManager). */
export function parseMotm(raw: string | null): PressMotm | null {
  if (raw === null) return null;
  try {
    const v = JSON.parse(raw) as Record<string, unknown>;
    if (typeof v.playerId !== 'string' || typeof v.name !== 'string') return null;
    return {
      playerId: v.playerId,
      name: v.name,
      position: typeof v.position === 'string' ? v.position : '',
      rating: typeof v.rating === 'number' && Number.isFinite(v.rating)
        ? Math.round(v.rating)
        : 0,
    };
  } catch {
    return null;
  }
}

/** Толерантный разбор moments (битый JSON → []). */
export function parseMoments(raw: string | null): PressMoment[] {
  if (raw === null) return [];
  try {
    const v = JSON.parse(raw) as unknown;
    if (!Array.isArray(v)) return [];
    const out: PressMoment[] = [];
    for (const item of v) {
      if (item === null || typeof item !== 'object') continue;
      const r = item as Record<string, unknown>;
      if (typeof r.minute !== 'number' || typeof r.text !== 'string') continue;
      if (typeof r.kind !== 'string') continue;
      const kind = r.kind as PressMomentKind;
      if (kind !== 'goal' && kind !== 'red' && kind !== 'pens' && kind !== 'injury' && kind !== 'yellow') continue;
      out.push({ minute: Math.max(0, Math.round(r.minute)), kind, text: r.text });
    }
    return out;
  } catch {
    return [];
  }
}

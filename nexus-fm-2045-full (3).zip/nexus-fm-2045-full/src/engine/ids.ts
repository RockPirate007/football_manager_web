/**
 * Генерация id записей: crypto.randomUUID → фолбэк crypto.getRandomValues
 * (file://-контексты WebView2), крайний фолбэк Math.random (спека §1.1 ids.ts).
 * Изоморфно: только Web API.
 */

function uuidFromBytes(bytes: Uint8Array): string {
  // RFC 4122 v4: version 4 в позиции 12, вариант 10xx в позиции 16
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex: string[] = [];
  for (const b of bytes) hex.push(b.toString(16).padStart(2, '0'));
  return `${hex[0]}${hex[1]}${hex[2]}${hex[3]}-${hex[4]}${hex[5]}-${hex[6]}${hex[7]}-${hex[8]}${hex[9]}-${hex[10]}${hex[11]}${hex[12]}${hex[13]}${hex[14]}${hex[15]}`;
}

/** Идентификатор записи (заменяет crypto.randomUUID в движке). */
export function createId(): string {
  const c: Crypto | undefined = globalThis.crypto;
  if (c && typeof c.randomUUID === 'function') return c.randomUUID();
  if (c && typeof c.getRandomValues === 'function') {
    const bytes = new Uint8Array(16);
    c.getRandomValues(bytes);
    return uuidFromBytes(bytes);
  }
  // Крайний фолбэк (окружения без Web Crypto): качество не критично —
  // id не участвует в геймплейном RNG.
  const bytes = new Uint8Array(16);
  for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  return uuidFromBytes(bytes);
}

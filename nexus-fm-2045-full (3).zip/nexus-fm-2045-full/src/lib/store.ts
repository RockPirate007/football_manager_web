/**
 * Zustand-стор игры: фазы карьеры, навигация, снапшот, матч, рынок,
 * тренировки и награды (§7.10 docs/architecture-upgrade.md).
 * Фаза 3: контракты, правление, академия, история игроков (§7 architecture-phase3.md).
 * Активный сейв — localStorage 'fm.activeSaveId' (серверного флага нет).
 */

import { create } from 'zustand';
import { toast } from 'sonner';
import { ApiClientError, api, type CreateSaveParams } from './game/api';
import type {
  AcademyResponse, BoardResponse, ContractsResponse, EuroSnapshotDTO, GameSnapshot,
  LeagueCatalogDTO, LeagueCode, LeagueClubDTO, ManagerDTO, MarketFilters, MarketListingDTO,
  MatchPlanDTO, AwardsResponse, MediaResponse, NegotiationDTO, NewspaperClippingDTO,
  SaveCardDTO, ScoutResponse, StaffResponse, TacticPayload, TrainingFocus, TrainingIntensity,
  TrainingStateResponse, TransferOfferDTO, WeekResultPayload,
  PlayerDialogDTO,
} from './game/types';

export type TabId =
  | 'dashboard' | 'squad' | 'tactics' | 'match' | 'media' | 'league' | 'cup' | 'euro'
  | 'training' | 'academy' | 'territory' | 'transfers' | 'finances' | 'coach' | 'awards';

export type Phase = 'careers' | 'league-select' | 'club-select' | 'manager-setup' | 'playing';

export type MatchView = 'prematch' | 'live' | 'result' | 'ceremony';

export type LiveSpeed = 1 | 2 | 4;

const ACTIVE_SAVE_KEY = 'fm.activeSaveId';

function readActiveSaveId(): string | null {
  try {
    return window.localStorage.getItem(ACTIVE_SAVE_KEY);
  } catch {
    return null;
  }
}

function writeActiveSaveId(id: string | null): void {
  try {
    if (id === null) window.localStorage.removeItem(ACTIVE_SAVE_KEY);
    else window.localStorage.setItem(ACTIVE_SAVE_KEY, id);
  } catch {
    // localStorage недоступен — играем без персистентности выбора
  }
}

// ── Итоги карьеры для экрана «Карьера завершена» (§7.5) ─────────────────
// Переживают выход к списку карьер и повторное открытие finished-сейва:
// после переходного увольнения сейв уже в новом сезоне (week=1, таблица
// пуста, confidence сброшен) — без этого снапшота место/трофеи/доверие
// последнего сезона взять неоткуда (API /awards для finished → 404).

export interface CareerSummary {
  /** Число ЗАВЕРШЁННЫХ сезонов карьеры. */
  seasonsCompleted: number;
  championships: number;
  cups: number;
  /** Последний завершённый сезон (при mid-season sack — текущий). */
  lastSeason: number;
  lastPlace: number | null;
  /** Доверие правления на момент завершения (после итогового апдейта недели). */
  lastConfidence: number | null;
  /** true — карьера завершена в сезонном переходе (вердикт sacked). */
  transitionSacked: boolean;
}

function careerSummaryKey(saveId: string): string {
  return `fm.careerSummary.${saveId}`;
}

export function readCareerSummary(saveId: string): CareerSummary | null {
  try {
    const raw = window.localStorage.getItem(careerSummaryKey(saveId));
    if (!raw) return null;
    const data: unknown = JSON.parse(raw);
    if (typeof data !== 'object' || data === null) return null;
    const r = data as Record<string, unknown>;
    if (typeof r.seasonsCompleted !== 'number') return null;
    return {
      seasonsCompleted: r.seasonsCompleted,
      championships: typeof r.championships === 'number' ? r.championships : 0,
      cups: typeof r.cups === 'number' ? r.cups : 0,
      lastSeason: typeof r.lastSeason === 'number' ? r.lastSeason : r.seasonsCompleted,
      lastPlace: typeof r.lastPlace === 'number' ? r.lastPlace : null,
      lastConfidence: typeof r.lastConfidence === 'number' ? r.lastConfidence : null,
      transitionSacked: r.transitionSacked === true,
    };
  } catch {
    return null;
  }
}

function writeCareerSummary(saveId: string, summary: CareerSummary): void {
  try {
    window.localStorage.setItem(careerSummaryKey(saveId), JSON.stringify(summary));
  } catch {
    // localStorage недоступен — итоги карьеры переживут только текущую сессию
  }
}

function removeCareerSummary(saveId: string): void {
  try {
    window.localStorage.removeItem(careerSummaryKey(saveId));
  } catch {
    // ignore
  }
}

/** Обновить сохраняемые итоги по результату сыгранной недели. */
function persistCareerSummary(
  saveId: string,
  result: WeekResultPayload,
  myTeamId: string | null,
): void {
  const prev = readCareerSummary(saveId);
  const ended = result.seasonEnded;
  if (ended) {
    const champs = myTeamId
      ? ended.awards.filter((a) => a.teamId === myTeamId && a.type === 'champion').length
      : 0;
    const cupWins = myTeamId
      ? ended.awards.filter((a) => a.teamId === myTeamId && a.type === 'cup_winner').length
      : 0;
    writeCareerSummary(saveId, {
      seasonsCompleted: result.season,
      championships: (prev?.championships ?? 0) + champs,
      cups: (prev?.cups ?? 0) + cupWins,
      lastSeason: result.season,
      lastPlace: ended.place,
      lastConfidence: result.board?.confidence ?? prev?.lastConfidence ?? null,
      transitionSacked: ended.boardVerdict?.code === 'sacked',
    });
    return;
  }
  if (result.sacked) {
    // Mid-season sack: сезон продолжается — место/таблица остаются живыми
    // в снапшоте finished-сейва, копим только контекст увольнения.
    writeCareerSummary(saveId, {
      seasonsCompleted: prev?.seasonsCompleted ?? 0,
      championships: prev?.championships ?? 0,
      cups: prev?.cups ?? 0,
      lastSeason: result.season,
      lastPlace: null,
      lastConfidence: result.board?.confidence ?? null,
      transitionSacked: false,
    });
  }
}

interface GameStore {
  // Навигация
  activeTab: TabId;
  setTab: (t: TabId) => void;

  // Фаза игры
  phase: Phase;
  hydrated: boolean;
  loading: boolean;
  error: string | null;

  // Карьеры
  activeSaveId: string | null;
  saves: SaveCardDTO[];
  savesLoading: boolean;
  leagues: LeagueCatalogDTO[];
  leaguesLoading: boolean;

  // Флоу новой карьеры (выбор между шагами)
  newLeagueCode: LeagueCode | null;
  newClub: LeagueClubDTO | null;

  // Данные активной карьеры
  snapshot: GameSnapshot | null;

  // Матч
  matchView: MatchView;
  lastMatch: WeekResultPayload | null;
  liveMinute: number;
  liveSpeed: LiveSpeed;
  seasonSummarySeen: boolean;
  /** Фаза 4: индекс матча двойной недели в lastMatch.userMatches (0..1). */
  liveMatchIndex: number;
  // ── Модуль 6: настройки 2D-радара (персист в localStorage) ──
  /** Показывать фамилии под фишками радара. */
  radarNames: boolean;
  toggleRadarNames: () => void;

  // Рынок
  market: MarketListingDTO[];
  marketLoading: boolean;

  // ── Модуль 3: скаутинг + входящие офферы ──
  /** Кеш GET /scout (сбрасывается при playWeek/смене сейва). */
  scoutCache: ScoutResponse | null;
  scoutLoading: boolean;
  /** Кеш GET /transfer-offers (сбрасывается при playWeek/смене сейва). */
  transferOffers: TransferOfferDTO[];
  transferOffersLoading: boolean;
  /** Последний ответ переговоров для UI-диалога (PlayerDialog market-режим). */
  lastNegotiation: NegotiationDTO | null;

  // Тренировки / награды (кеш вкладок)
  trainingCache: TrainingStateResponse | null;
  trainingLoading: boolean;
  // ── Модуль 4: персонал и рынок труда ──
  /** Кеш GET /staff (сбрасывается при playWeek/смене сейва). */
  staffCache: StaffResponse | null;
  staffLoading: boolean;
  /** id сотрудника с открытым диалогом найма/продления. */
  staffActionStaffId: string | null;
  awardsCache: AwardsResponse | null;
  awardsLoading: boolean;

  // ── Фаза 3: кеши контрактов / правления / академии / истории игроков ──
  contractsCache: ContractsResponse | null;
  contractsLoading: boolean;
  boardCache: BoardResponse | null;
  boardLoading: boolean;
  academyCache: AcademyResponse | null;
  academyLoading: boolean;
  /** Кеш диалогов игроков по id (инвалидируется при смене сейва/сезона). */
  playerDialogCache: Map<string, PlayerDialogDTO>;
  /** id игрока, чей диалог сейчас грузится (null — не грузится). */
  playerDialogLoadingId: string | null;
  /** Фильтр «Истекают» на экране состава (включается с дашборда). */
  squadExpiringOnly: boolean;

  // ── Фаза 4: Кубок Европы + план на матч (§7.9 architecture-phase4.md) ──
  /** Снапшот /euro (сбрасывается при playWeek/смене сейва). */
  euroCache: EuroSnapshotDTO | null;
  euroLoading: boolean;
  /** План на матч клуба игрока (GET/POST /matchplan). */
  matchPlanCache: MatchPlanDTO | null;
  matchPlanLoading: boolean;
  matchPlanSaving: boolean;

  // ── D-6 «Тренер»: кеш GET /manager (сбрасывается при playWeek/смене сейва) ──
  managerCache: ManagerDTO | null;
  managerLoading: boolean;
  managerSaving: boolean;

  // ── D-7 «Медиа»: кеш GET /media — страница архива (§5.6, пагинация) ──
  mediaCache: { clippings: NewspaperClippingDTO[]; total: number; offset: number } | null;
  mediaLoading: boolean;
  /** Выбранный выпуск внутри загруженной страницы (индекс в clippings). */
  mediaPageIndex: number;

  // ── Actions ──
  hydrate: () => Promise<void>;
  fetchSaves: () => Promise<void>;
  fetchLeagues: () => Promise<void>;
  openSave: (id: string) => Promise<void>;
  exitToCareers: () => void;
  startNewCareer: () => void;
  setNewLeague: (code: LeagueCode) => void;
  setNewClub: (club: LeagueClubDTO) => void;
  backToLeagues: () => void;
  backToClubs: () => void;
  createCareer: (p: CreateSaveParams) => Promise<boolean>;
  renameSave: (id: string, careerName: string) => Promise<boolean>;
  deleteSave: (id: string) => Promise<boolean>;
  playWeek: () => Promise<void>;
  setMatchView: (v: MatchView) => void;
  setLiveMinute: (m: number) => void;
  setLiveSpeed: (s: LiveSpeed) => void;
  setLiveMatchIndex: (i: number) => void;
  dismissSeasonSummary: () => void;
  saveTactics: (payload: TacticPayload) => Promise<boolean>;
  buyPlayer: (playerId: string) => Promise<boolean>;
  listPlayer: (playerId: string, price: number) => Promise<boolean>;
  fetchMarket: (filters: MarketFilters) => Promise<void>;
  // ── Модуль 3: скаутинг + входящие офферы + переговоры ──
  fetchScout: (force?: boolean) => Promise<void>;
  scoutWatch: (playerId: string) => Promise<void>;
  scoutUnwatch: (playerId: string) => Promise<void>;
  fetchTransferOffers: (force?: boolean) => Promise<void>;
  acceptTransferOffer: (offerId: string) => Promise<boolean>;
  rejectTransferOffer: (offerId: string) => Promise<boolean>;
  buyPlayerNegotiated: (
    playerId: string,
    offer: { salary: number; years: number; goalBonus: number; cleanSheetBonus: number },
  ) => Promise<NegotiationDTO | null>;
  clearNegotiation: () => void;
  fetchTraining: () => Promise<void>;
  setTraining: (focus: TrainingFocus, intensity: TrainingIntensity) => Promise<boolean>;
  // ── Модуль 4: персонал + индивидуальные программы ──
  fetchStaff: (force?: boolean) => Promise<void>;
  hireStaff: (staffId: string, years: number) => Promise<boolean>;
  fireStaff: (staffId: string) => Promise<boolean>;
  renewStaff: (staffId: string, years: number) => Promise<boolean>;
  setPlayerTraining: (
    playerId: string,
    individual: { focus: TrainingFocus; intensity: TrainingIntensity } | null,
  ) => Promise<boolean>;
  fetchAwards: (force?: boolean, silent?: boolean) => Promise<void>;
  fetchContracts: (force?: boolean) => Promise<void>;
  fetchBoard: (force?: boolean) => Promise<void>;
  fetchAcademy: (force?: boolean) => Promise<void>;
  fetchPlayerDialog: (playerId: string, force?: boolean) => Promise<PlayerDialogDTO | null>;
  // ── Фаза 4 ──
  fetchEuro: (force?: boolean) => Promise<void>;
  fetchMatchPlan: (force?: boolean) => Promise<void>;
  saveMatchPlan: (plan: MatchPlanDTO) => Promise<boolean>;
  // ── D-5 «Территория» (данные уже в снапшоте — отдельного кеша нет, §9-D5) ──
  upgradeBuilding: (buildingId: string) => Promise<boolean>;
  // ── Модуль 5 (§ «Инфраструктура 2.0»): запуск расширения стадиона ──
  expandStadium: (seats: 3000 | 5000 | 8000) => Promise<boolean>;
  // ── D-6 «Тренер» (§4.6): профиль/кошелёк/активы/семья ──
  loadManager: (force?: boolean) => Promise<void>;
  buyAsset: (assetId: string) => Promise<boolean>;
  sellAsset: (assetId: string) => Promise<boolean>;
  // ── D-7 «Медиа» (§5.6): архив газет — страница по offset (+ выбор выпуска) ──
  fetchMedia: (offset?: number, force?: boolean) => Promise<void>;
  setMediaPageIndex: (i: number) => void;
  renewContract: (
    playerId: string,
    years: number,
    salary: number,
  ) => Promise<{ outcome: 'accepted' | 'counter'; demand: number } | null>;
  setSquadExpiringOnly: (v: boolean) => void;
}

function toastError(error: unknown): void {
  const message =
    error instanceof ApiClientError ? error.message : 'Неизвестная ошибка — попробуйте ещё раз';
  toast.error(message);
}

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof ApiClientError ? error.message : fallback;
}

const NOT_FOUND_CODES = new Set(['SAVE_NOT_FOUND', 'NO_SAVE']);

// ── Модуль 6: персист настроек просмотра (localStorage, без throw в приватном режиме) ──

const LIVE_SPEED_KEY = 'fm.liveSpeed';
const RADAR_NAMES_KEY = 'fm.radarNames';

function readLiveSpeedPref(): LiveSpeed {
  try {
    const v = window.localStorage.getItem(LIVE_SPEED_KEY);
    return v === '2' ? 2 : v === '4' ? 4 : 1;
  } catch {
    return 1;
  }
}

function writeLiveSpeedPref(s: LiveSpeed): void {
  try {
    window.localStorage.setItem(LIVE_SPEED_KEY, String(s));
  } catch {
    /* private mode */
  }
}

function readRadarNamesPref(): boolean {
  try {
    return window.localStorage.getItem(RADAR_NAMES_KEY) !== '0';
  } catch {
    return true;
  }
}

function writeRadarNamesPref(v: boolean): void {
  try {
    window.localStorage.setItem(RADAR_NAMES_KEY, v ? '1' : '0');
  } catch {
    /* private mode */
  }
}

export const useGameStore = create<GameStore>((set, get) => ({
  activeTab: 'dashboard',
  setTab: (t) => set({ activeTab: t }),

  phase: 'careers',
  hydrated: false,
  loading: false,
  error: null,

  activeSaveId: null,
  saves: [],
  savesLoading: false,
  leagues: [],
  leaguesLoading: false,

  newLeagueCode: null,
  newClub: null,

  snapshot: null,

  matchView: 'prematch',
  lastMatch: null,
  liveMinute: 0,
  liveSpeed: readLiveSpeedPref(),
  seasonSummarySeen: true,
  liveMatchIndex: 0,
  radarNames: readRadarNamesPref(),

  market: [],
  marketLoading: false,
  scoutCache: null,
  scoutLoading: false,
  transferOffers: [],
  transferOffersLoading: false,
  lastNegotiation: null,

  trainingCache: null,
  trainingLoading: false,
  staffCache: null,
  staffLoading: false,
  staffActionStaffId: null,
  awardsCache: null,
  awardsLoading: false,

  contractsCache: null,
  contractsLoading: false,
  boardCache: null,
  boardLoading: false,
  academyCache: null,
  academyLoading: false,
  playerDialogCache: new Map<string, PlayerDialogDTO>(),
  playerDialogLoadingId: null,
  squadExpiringOnly: false,

  euroCache: null,
  euroLoading: false,
  matchPlanCache: null,
  matchPlanLoading: false,
  matchPlanSaving: false,

  // ── D-6 «Тренер»: личная жизнь (кеш GET /manager, §4.6) ──
  managerCache: null,
  managerLoading: false,
  managerSaving: false,

  // ── D-7 «Медиа»: архив газет (кеш GET /media, §5.6) ──
  mediaCache: null,
  mediaLoading: false,
  mediaPageIndex: 0,

  hydrate: async () => {
    set({ loading: true });
    const savedId = readActiveSaveId();

    // Параллельно: список карьер (для экрана «Мои карьеры») + каталог лиг.
    const savesPromise = get().fetchSaves();
    void get().fetchLeagues();

    if (savedId) {
      try {
        const res = await api.getState(savedId);
        set({
          snapshot: res.snapshot,
          // finished (уволен) — тоже «playing»: GameShell покажет CareerOverScreen (§7.5).
          phase: 'playing',
          activeSaveId: savedId,
          error: null,
          trainingCache: null,
          awardsCache: null,
          contractsCache: null,
          boardCache: null,
          academyCache: null,
          playerDialogCache: new Map<string, PlayerDialogDTO>(),
          euroCache: null,
          matchPlanCache: null,
          managerCache: null,
          mediaCache: null,
          mediaPageIndex: 0,
          scoutCache: null,
          staffCache: null,
          transferOffers: [],
          lastNegotiation: null,
        });
      } catch (error) {
        if (error instanceof ApiClientError && NOT_FOUND_CODES.has(error.code)) {
          writeActiveSaveId(null);
          set({ activeSaveId: null, snapshot: null });
        } else {
          toastError(error);
          set({ error: errorMessage(error, 'Ошибка загрузки') });
        }
      } finally {
        set({ hydrated: true, loading: false });
      }
      return;
    }

    // Нет активного сейва — экран карьер (или сразу новая карьера при пустоте).
    await savesPromise;
    const saves = get().saves;
    set({
      phase: saves.length > 0 ? 'careers' : 'league-select',
      snapshot: null,
      error: null,
      hydrated: true,
      loading: false,
    });
  },

  fetchSaves: async () => {
    set({ savesLoading: true });
    try {
      const res = await api.getSaves();
      set({ saves: res.saves, error: null });
    } catch (error) {
      toastError(error);
    } finally {
      set({ savesLoading: false });
    }
  },

  fetchLeagues: async () => {
    if (get().leagues.length > 0) return;
    set({ leaguesLoading: true });
    try {
      const res = await api.getLeagues();
      set({ leagues: res.leagues });
    } catch (error) {
      toastError(error);
    } finally {
      set({ leaguesLoading: false });
    }
  },

  openSave: async (id) => {
    set({ loading: true });
    writeActiveSaveId(id);
    try {
      const res = await api.getState(id);
      set({
        snapshot: res.snapshot,
        phase: 'playing',
        activeSaveId: id,
        activeTab: 'dashboard',
        matchView: 'prematch',
        lastMatch: null,
        seasonSummarySeen: true,
        liveMatchIndex: 0,
        trainingCache: null,
        awardsCache: null,
        contractsCache: null,
        boardCache: null,
        academyCache: null,
        playerDialogCache: new Map<string, PlayerDialogDTO>(),
        squadExpiringOnly: false,
        euroCache: null,
        matchPlanCache: null,
        managerCache: null,
        mediaCache: null,
        mediaPageIndex: 0,
        scoutCache: null,
        staffCache: null,
        transferOffers: [],
        lastNegotiation: null,
        error: null,
      });
    } catch (error) {
      writeActiveSaveId(null);
      toastError(error);
      set({ activeSaveId: null, phase: 'careers' });
      void get().fetchSaves();
    } finally {
      set({ loading: false });
    }
  },

  exitToCareers: () => {
    set({
      phase: 'careers',
      snapshot: null,
      activeSaveId: null,
      matchView: 'prematch',
      lastMatch: null,
      liveMatchIndex: 0,
      trainingCache: null,
      awardsCache: null,
      contractsCache: null,
      boardCache: null,
      academyCache: null,
      playerDialogCache: new Map<string, PlayerDialogDTO>(),
      squadExpiringOnly: false,
      euroCache: null,
      matchPlanCache: null,
      managerCache: null,
      mediaCache: null,
      mediaPageIndex: 0,
      scoutCache: null,
      staffCache: null,
      transferOffers: [],
      lastNegotiation: null,
      error: null,
    });
    writeActiveSaveId(null);
    void get().fetchSaves();
  },

  startNewCareer: () => {
    set({ phase: 'league-select', newLeagueCode: null, newClub: null, error: null });
    void get().fetchLeagues();
  },

  setNewLeague: (code) => {
    set({ newLeagueCode: code, newClub: null, phase: 'club-select' });
  },

  setNewClub: (club) => {
    set({ newClub: club, phase: 'manager-setup' });
  },

  backToLeagues: () => {
    set({ phase: 'league-select', newClub: null });
  },

  backToClubs: () => {
    set({ phase: 'club-select' });
  },

  createCareer: async (p) => {
    set({ loading: true });
    try {
      const res = await api.createSave(p);
      writeActiveSaveId(res.saveId);
      set({ activeSaveId: res.saveId, newLeagueCode: null, newClub: null, error: null });
      await get().openSave(res.saveId);
      toast.success(`Карьера «${res.careerName}» началась. Впереди — ${res.league.nameRu}!`);
      return true;
    } catch (error) {
      toastError(error);
      // Лимит 8 и т.п. — остаёмся во флоу, список мог измениться.
      void get().fetchSaves();
      return false;
    } finally {
      set({ loading: false });
    }
  },

  renameSave: async (id, careerName) => {
    try {
      await api.renameSave(id, careerName);
      set({ saves: get().saves.map((s) => (s.id === id ? { ...s, careerName } : s)) });
      toast.success('Карьера переименована');
      return true;
    } catch (error) {
      toastError(error);
      return false;
    }
  },

  deleteSave: async (id) => {
    try {
      await api.deleteSave(id);
      removeCareerSummary(id);
      const saves = get().saves.filter((s) => s.id !== id);
      set({ saves });
      if (get().activeSaveId === id) {
        writeActiveSaveId(null);
        set({ activeSaveId: null, snapshot: null });
      }
      if (saves.length === 0 && get().phase === 'careers') {
        set({ phase: 'league-select' });
      }
      toast.success('Карьера удалена');
      return true;
    } catch (error) {
      toastError(error);
      return false;
    }
  },

  playWeek: async () => {
    const { loading, activeSaveId, snapshot } = get();
    // Guard от двойного клика «Начать матч» (QA-3).
    if (loading || !activeSaveId) return;
    set({ loading: true });
    try {
      const res = await api.simulate(activeSaveId);
      const seasonEnded = res.result.seasonEnded !== null;
      // Фаза 3: итоги карьеры для экрана «Карьера завершена» — пишем ДО
      // сброса снапшота (myTeam.id нужен для подсчёта трофеев).
      persistCareerSummary(activeSaveId, res.result, snapshot?.myTeam.id ?? null);
      set({
        lastMatch: res.result,
        // Кубковая/евронеделя без матчей клуба — сразу к итогам недели;
        // двойная неделя — лента матча 1 (индекс 0).
        matchView: res.result.userMatches.length > 0 ? 'live' : 'result',
        liveMinute: 0,
        liveSpeed: 1,
        liveMatchIndex: 0,
        seasonSummarySeen: !res.result.seasonEnded,
        error: null,
        trainingCache: null,
        awardsCache: null,
        // Фаза 3: контракты/правление/академия меняются каждую неделю — сбрасываем кеши.
        contractsCache: null,
        boardCache: null,
        academyCache: null,
        // Фаза 4: евро-сетка/жеребьёвка и призовые изменились — сбрасываем кеши.
        euroCache: null,
        matchPlanCache: null,
        // D-6: кошелёк/престиж/семья изменились — сбрасываем кеш менеджера.
        managerCache: null,
        // D-7: вырезки недели появились — сбрасываем архив газет.
        mediaCache: null,
        mediaPageIndex: 0,
        // Модуль 3: знания скаутов выросли, офферы могли прийти/истечь.
        scoutCache: null,
        staffCache: null,
        transferOffers: [],
        lastNegotiation: null,
        // Смена сезона — история игроков обновилась (новые записи PlayerSeasonRecord).
        ...(seasonEnded ? { playerDialogCache: new Map<string, PlayerDialogDTO>() } : {}),
      });
      // Mid-season sack: после закрытия экрана результата недели пользователь увидит
      // CareerOverScreen — гидрация уже вернёт status 'finished' (§7.5).
      if (res.result.sacked) {
        toast.warning('Правление отправило вас в отставку');
      }
      // Тихая ре-гидрация: снапшот должен отразить новую неделю.
      void get()
        .hydrate()
        .catch(() => undefined);
    } catch (error) {
      toastError(error);
      set({ error: errorMessage(error, 'Ошибка симуляции') });
    } finally {
      set({ loading: false });
    }
  },

  setMatchView: (v) => set({ matchView: v }),
  setLiveMinute: (m) => set({ liveMinute: m }),
  setLiveSpeed: (s) => {
    writeLiveSpeedPref(s);
    set({ liveSpeed: s });
  },
  setLiveMatchIndex: (i) => set({ liveMatchIndex: Math.max(0, i), liveMinute: 0 }),
  toggleRadarNames: () => {
    const next = !get().radarNames;
    writeRadarNamesPref(next);
    set({ radarNames: next });
  },
  dismissSeasonSummary: () => set({ seasonSummarySeen: true }),

  saveTactics: async (payload) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.saveTactic({ ...payload, saveId: activeSaveId });
      await get().hydrate();
      toast.success(`Тактика сохранена. Сила команды: ${res.teamStrength}`);
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  buyPlayer: async (playerId) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.buyPlayer(activeSaveId, playerId);
      set({ snapshot: res.snapshot, contractsCache: null });
      toast.success('Игрок куплен и присоединился к клубу!');
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  listPlayer: async (playerId, price) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.listPlayer(activeSaveId, playerId, price);
      set({ snapshot: res.snapshot });
      toast.success('Игрок выставлен на трансферный рынок.');
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  fetchMarket: async (filters) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return;
    set({ marketLoading: true });
    try {
      const res = await api.getMarket({ ...filters, saveId: activeSaveId });
      set({ market: res.listings });
    } catch (error) {
      toastError(error);
    } finally {
      set({ marketLoading: false });
    }
  },

  // ── Модуль 3: скаутинг (туман войны) ──
  fetchScout: async (force = false) => {
    const { activeSaveId, scoutCache } = get();
    if (!activeSaveId) return;
    if (!force && scoutCache) return;
    set({ scoutLoading: true });
    try {
      const res = await api.getScout(activeSaveId);
      set({ scoutCache: res });
    } catch (error) {
      toastError(error);
    } finally {
      set({ scoutLoading: false });
    }
  },

  scoutWatch: async (playerId) => {
    const { activeSaveId, scoutCache } = get();
    if (!activeSaveId) return;
    try {
      await api.scoutWatch(activeSaveId, playerId);
      const res = await api.getScout(activeSaveId);
      set({ scoutCache: res });
      toast.success('Скауты начали наблюдение за игроком.');
    } catch (error) {
      toastError(error);
      void get().fetchScout(true);
    }
  },

  scoutUnwatch: async (playerId) => {
    const { activeSaveId } = get();
    if (!activeSaveId) return;
    try {
      await api.scoutUnwatch(activeSaveId, playerId);
      const res = await api.getScout(activeSaveId);
      set({ scoutCache: res });
      toast.info('Наблюдение снято — знания будут постепенно забываться.');
    } catch (error) {
      toastError(error);
      void get().fetchScout(true);
    }
  },

  // ── Модуль 3: входящие офферы ИИ ──
  fetchTransferOffers: async (force = false) => {
    const { activeSaveId, transferOffers, transferOffersLoading } = get();
    if (!activeSaveId) return;
    if (!force && transferOffers.length > 0) return;
    if (transferOffersLoading) return;
    set({ transferOffersLoading: true });
    try {
      const res = await api.getTransferOffers(activeSaveId);
      set({ transferOffers: res.offers });
    } catch (error) {
      toastError(error);
    } finally {
      set({ transferOffersLoading: false });
    }
  },

  acceptTransferOffer: async (offerId) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.acceptTransferOffer(activeSaveId, offerId);
      set({ snapshot: res.snapshot, contractsCache: null, transferOffers: [] });
      toast.success('Игрок продан — деньги поступили на баланс клуба.');
      void get().fetchTransferOffers(true);
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  rejectTransferOffer: async (offerId) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.rejectTransferOffer(activeSaveId, offerId);
      set({ snapshot: res.snapshot, transferOffers: [] });
      toast.info('Предложение отклонено.');
      void get().fetchTransferOffers(true);
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  // ── Модуль 3: контрактные переговоры при подписании ──
  buyPlayerNegotiated: async (playerId, offer) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return null;
    set({ loading: true });
    try {
      const res = await api.buyPlayerNegotiated(activeSaveId, playerId, offer);
      set({ lastNegotiation: res.negotiation });
      if (res.negotiation.kind === 'accepted') {
        set({ snapshot: res.snapshot as GameSnapshot, contractsCache: null, scoutCache: null });
        toast.success(res.negotiation.message);
      }
      return res.negotiation;
    } catch (error) {
      toastError(error);
      return null;
    } finally {
      set({ loading: false });
    }
  },

  clearNegotiation: () => set({ lastNegotiation: null }),

  fetchTraining: async () => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return;
    set({ trainingLoading: true });
    try {
      const res = await api.getTraining(activeSaveId);
      set({ trainingCache: res });
    } catch (error) {
      toastError(error);
    } finally {
      set({ trainingLoading: false });
    }
  },

  setTraining: async (focus, intensity) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.setTraining(activeSaveId, focus, intensity);
      const training = res.training ?? { focus, intensity };
      set((state) => ({
        snapshot: state.snapshot
          ? { ...state.snapshot, training }
          : state.snapshot,
        trainingCache: state.trainingCache ? { ...state.trainingCache, training } : null,
      }));
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  // ── Модуль 4: персонал и рынок труда ──
  fetchStaff: async (force = false) => {
    const { activeSaveId, staffCache } = get();
    if (!activeSaveId) return;
    if (!force && staffCache) return;
    set({ staffLoading: true });
    try {
      const res = await api.getStaff(activeSaveId);
      set({ staffCache: res });
    } catch (error) {
      toastError(error);
    } finally {
      set({ staffLoading: false });
    }
  },

  hireStaff: async (staffId, years) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.hireStaff(activeSaveId, staffId, years);
      // гидрация обновляет снапшот (баланс) и СБРАСЫВАЕТ кеши — ставим кеш ПОСЛЕ
      await get().hydrate();
      set({ staffCache: { ok: true, ...res.staff } });
      const name = res.staff.staff.find((s) => s.id === staffId);
      toast.success(
        name
          ? `${name.firstName} ${name.lastName} принят в штаб (контракт до ${res.staff.season + years}).`
          : 'Сотрудник принят в штаб.',
      );
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  fireStaff: async (staffId) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.fireStaff(activeSaveId, staffId);
      await get().hydrate();
      set({ staffCache: { ok: true, ...res.staff } });
      toast.info(
        `Сотрудник уволен. Компенсация: €${Math.abs(res.balanceDelta).toLocaleString('ru-RU')}.`,
      );
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  renewStaff: async (staffId, years) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    set({ loading: true });
    try {
      const res = await api.renewStaff(activeSaveId, staffId, years);
      set({ staffCache: { ok: true, ...res.staff } });
      toast.success('Контракт персонала продлён.');
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  // ── Модуль 4: индивидуальные программы тренировок ──
  setPlayerTraining: async (playerId, individual) => {
    const activeSaveId = get().activeSaveId;
    if (!activeSaveId) return false;
    try {
      await api.setPlayerTraining(activeSaveId, playerId, individual);
      set((state) => ({
        trainingCache: state.trainingCache
          ? {
              ...state.trainingCache,
              squad: state.trainingCache.squad.map((p) =>
                p.id === playerId ? { ...p, individual: individual ?? null } : p,
              ),
            }
          : null,
      }));
      return true;
    } catch (error) {
      toastError(error);
      return false;
    }
  },

  fetchAwards: async (force = false, silent = false) => {
    const { activeSaveId, awardsCache } = get();
    if (!activeSaveId) return;
    if (!force && awardsCache) return;
    set({ awardsLoading: true });
    try {
      const res = await api.getAwards(activeSaveId);
      set({ awardsCache: res });
    } catch (error) {
      // Finished-сейв: /awards работает только для активных карьер — молча пропускаем.
      if (!silent) toastError(error);
    } finally {
      set({ awardsLoading: false });
    }
  },

  // ── Фаза 3 ──

  fetchContracts: async (force = false) => {
    const { activeSaveId, contractsCache, contractsLoading } = get();
    if (!activeSaveId || contractsLoading) return;
    if (!force && contractsCache) return;
    set({ contractsLoading: true });
    try {
      const res = await api.getContracts(activeSaveId);
      // Пока грузили — сейв мог смениться: проверяем, что ответ ещё актуален.
      if (get().activeSaveId === activeSaveId) set({ contractsCache: res });
    } catch (error) {
      toastError(error);
    } finally {
      set({ contractsLoading: false });
    }
  },

  fetchBoard: async (force = false) => {
    const { activeSaveId, boardCache, boardLoading } = get();
    if (!activeSaveId || boardLoading) return;
    if (!force && boardCache) return;
    set({ boardLoading: true });
    try {
      const res = await api.getBoard(activeSaveId);
      if (get().activeSaveId === activeSaveId) set({ boardCache: res });
    } catch (error) {
      toastError(error);
    } finally {
      set({ boardLoading: false });
    }
  },

  fetchAcademy: async (force = false) => {
    const { activeSaveId, academyCache, academyLoading } = get();
    if (!activeSaveId || academyLoading) return;
    if (!force && academyCache) return;
    set({ academyLoading: true });
    try {
      const res = await api.getAcademy(activeSaveId);
      if (get().activeSaveId === activeSaveId) set({ academyCache: res });
    } catch (error) {
      toastError(error);
    } finally {
      set({ academyLoading: false });
    }
  },

  fetchPlayerDialog: async (playerId, force = false) => {
    const { activeSaveId, playerDialogCache, playerDialogLoadingId } = get();
    if (!activeSaveId) return null;
    if (!force && playerDialogCache.has(playerId)) return playerDialogCache.get(playerId) ?? null;
    if (playerDialogLoadingId === playerId) return null; // уже грузится
    set({ playerDialogLoadingId: playerId });
    try {
      const res = await api.getPlayerDialog(activeSaveId, playerId);
      const cache = new Map(get().playerDialogCache);
      cache.set(playerId, res.dialog);
      if (get().activeSaveId === activeSaveId) set({ playerDialogCache: cache });
      return res.dialog;
    } catch (error) {
      toastError(error);
      return null;
    } finally {
      set({ playerDialogLoadingId: null });
    }
  },

  renewContract: async (playerId, years, salary) => {
    const { activeSaveId, loading } = get();
    if (!activeSaveId || loading) return null;
    set({ loading: true });
    try {
      const res = await api.renewContract(activeSaveId, playerId, years, salary);
      if (res.outcome === 'accepted' && res.snapshot) {
        const updated = res.snapshot.myPlayers.find((p) => p.id === playerId);
        const until = updated?.contractUntil ?? null;
        toast.success(
          until !== null
            ? `Контракт продлён до конца сезона ${until}`
            : 'Контракт продлён',
        );
        const cache = new Map(get().playerDialogCache);
        const cached = cache.get(playerId);
        if (cached && updated) cache.set(playerId, { ...cached, player: updated });
        set({ snapshot: res.snapshot, contractsCache: null, playerDialogCache: cache });
      } else {
        toast.warning(`Игрок запрашивает больше: ~${res.demand.toLocaleString('ru-RU')} €/нед`);
      }
      return { outcome: res.outcome, demand: res.demand };
    } catch (error) {
      toastError(error);
      return null;
    } finally {
      set({ loading: false });
    }
  },

  setSquadExpiringOnly: (v) => set({ squadExpiringOnly: v }),

  // ── Фаза 4: Кубок Европы + план на матч (§7.9) ──

  fetchEuro: async (force = false) => {
    const { activeSaveId, euroCache, euroLoading } = get();
    if (!activeSaveId || euroLoading) return;
    if (!force && euroCache) return;
    set({ euroLoading: true });
    try {
      const res = await api.getEuro(activeSaveId);
      // Пока грузили — сейв мог смениться: проверяем, что ответ ещё актуален.
      if (get().activeSaveId === activeSaveId) set({ euroCache: res.euro });
    } catch (error) {
      toastError(error);
    } finally {
      set({ euroLoading: false });
    }
  },

  fetchMatchPlan: async (force = false) => {
    const { activeSaveId, matchPlanCache, matchPlanLoading } = get();
    if (!activeSaveId || matchPlanLoading) return;
    if (!force && matchPlanCache) return;
    set({ matchPlanLoading: true });
    try {
      const res = await api.getMatchPlan(activeSaveId);
      if (get().activeSaveId === activeSaveId) set({ matchPlanCache: res.plan });
    } catch (error) {
      // finished-сейв (уволен): плана нет — молча оставляем дефолт.
      if (!(error instanceof ApiClientError && NOT_FOUND_CODES.has(error.code))) {
        toastError(error);
      }
    } finally {
      set({ matchPlanLoading: false });
    }
  },

  saveMatchPlan: async (plan) => {
    const { activeSaveId, matchPlanSaving } = get();
    if (!activeSaveId || matchPlanSaving) return false;
    set({ matchPlanSaving: true });
    try {
      const res = await api.setMatchPlan(activeSaveId, plan);
      if (get().activeSaveId === activeSaveId) set({ matchPlanCache: res.plan });
      toast.success('План на матч сохранён');
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ matchPlanSaving: false });
    }
  },

  // ── D-5 «Территория»: апгрейд здания — свежий снапшот с нового POST /buildings ──
  upgradeBuilding: async (buildingId) => {
    const { activeSaveId, loading } = get();
    if (!activeSaveId || loading) return false;
    set({ loading: true });
    try {
      const res = await api.upgradeBuilding(activeSaveId, buildingId);
      if (get().activeSaveId === activeSaveId) set({ snapshot: res.snapshot });
      const card = res.snapshot.myTeam.buildings.find((b) => b.id === buildingId);
      toast.success(
        card && card.upgradeEndsAtDay !== null
          ? `Стройка началась: ${card.name} — ${card.daysNext ?? ''} дн.`
          : 'Стройка началась',
      );
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  // ── Модуль 5 (§ «Инфраструктура 2.0»): запуск расширения стадиона ──
  expandStadium: async (seats) => {
    const { activeSaveId, loading } = get();
    if (!activeSaveId || loading) return false;
    set({ loading: true });
    try {
      const res = await api.startStadiumExpansion(activeSaveId, seats);
      if (get().activeSaveId === activeSaveId) set({ snapshot: res.snapshot });
      toast.success(
        `Стройка началась: +${res.pending.toLocaleString('ru-RU')} мест — трибуны вырастут до ${res.capacityAfter.toLocaleString('ru-RU')}`,
      );
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ loading: false });
    }
  },

  // ── D-6 «Тренер» (§4.6): личная жизнь — профиль/кошелёк/активы/семья ──

  loadManager: async (force = false) => {
    const { activeSaveId, managerCache, managerLoading } = get();
    if (!activeSaveId || managerLoading) return;
    if (!force && managerCache) return;
    set({ managerLoading: true });
    try {
      const res = await api.getManager(activeSaveId);
      // Пока грузили — сейв мог смениться: проверяем, что ответ ещё актуален.
      if (get().activeSaveId === activeSaveId) set({ managerCache: res.manager });
    } catch (error) {
      toastError(error);
    } finally {
      set({ managerLoading: false });
    }
  },

  buyAsset: async (assetId) => {
    const { activeSaveId, managerSaving } = get();
    if (!activeSaveId || managerSaving) return false;
    set({ managerSaving: true });
    try {
      const res = await api.managerAsset(activeSaveId, assetId, 'buy');
      if (get().activeSaveId === activeSaveId) set({ managerCache: res.manager });
      const asset = res.manager.assets.find((a) => a.id === assetId);
      toast.success(
        asset
          ? `Приобретено: ${asset.name}. Престиж +${(asset.prestige / 10).toFixed(1)}`
          : 'Актив приобретён',
      );
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ managerSaving: false });
    }
  },

  sellAsset: async (assetId) => {
    const { activeSaveId, managerSaving } = get();
    if (!activeSaveId || managerSaving) return false;
    set({ managerSaving: true });
    try {
      const res = await api.managerAsset(activeSaveId, assetId, 'sell');
      if (get().activeSaveId === activeSaveId) set({ managerCache: res.manager });
      const asset = res.manager.assets.find((a) => a.id === assetId);
      toast.success(
        asset
          ? `Продано: ${asset.name} — €${asset.sellPrice.toLocaleString('ru-RU')}`
          : 'Актив продан',
      );
      return true;
    } catch (error) {
      toastError(error);
      return false;
    } finally {
      set({ managerSaving: false });
    }
  },

  // ── D-7 «Медиа» (§5.6): страница архива вырезок (offset — срез от свежих) ──

  fetchMedia: async (offset = 0, force = false) => {
    const { activeSaveId, mediaCache, mediaLoading } = get();
    if (!activeSaveId || mediaLoading) return;
    if (!force && mediaCache !== null && mediaCache.offset === offset) return;
    set({ mediaLoading: true });
    try {
      const res: MediaResponse = await api.getMedia(activeSaveId, offset, 10);
      // Пока грузили — сейв мог смениться: проверяем, что ответ ещё актуален.
      if (get().activeSaveId === activeSaveId) {
        set({ mediaCache: { clippings: res.clippings, total: res.total, offset }, mediaPageIndex: 0 });
      }
    } catch (error) {
      toastError(error);
    } finally {
      set({ mediaLoading: false });
    }
  },

  setMediaPageIndex: (i) => set({ mediaPageIndex: Math.max(0, i) }),
}));

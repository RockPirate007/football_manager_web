/**
 * Типизированный шлюз игрового API — единственная точка входа UI в движок
 * (D-4, спека §1.5): вместо fetch('/api/...') — прямые вызовы виртуального
 * роутера src/engine/router.ts. Сигнатуры всех методов, типы DTO и обработка
 * ошибок (коды ApiClientError) сохранены 1:1 с серверной версией — store.ts
 * и компоненты не меняются.
 *
 * Фаза 2: все игровые вызовы несут saveId; новые эндпоинты
 * /leagues, /saves, /saves/[id], /training, /awards (§6 docs/architecture-upgrade.md).
 * Фаза 3 (§6.1 architecture-phase3.md): /contracts, /contracts/renew, /board,
 * /academy, /player (история игрока — лениво, не в /state).
 * Фаза 4 (§6.1 architecture-phase4.md): /matchplan (GET/POST — план на матч
 * клуба игрока), /euro (снапшот Кубка Европы).
 */

import { engineDispatch, type EngineRequest } from '@/engine/router';
import { ApiGameError, ERROR_MESSAGES } from './error';
import type {
  AcademyResponse, AwardsResponse, BoardResponse, BuyNegotiatedResponse, BuyResponse,
  ContractsResponse, CreateSaveResponse, EuroResponse, LeagueCatalogResponse,
  ManagerAssetResponse, ManagerResponse, MarketFilters, MarketResponse, MediaResponse,
  MatchPlanDTO, MatchPlanResponse, MatchResponse, PlayerDialogResponse, RenewResponse,
  SavesListResponse, ScoutResponse, SetMatchPlanResponse, SetTrainingResponse,
  SetPlayerTrainingResponse, SimulateResponse, StadiumResponse, StateResponse,
  StaffActionResponse,
  StaffResponse, TacticPayload, TacticResponse, TrainingFocus, TrainingIntensity,
  TrainingStateResponse, TransferOffersResponse,
} from './types';

const CLIENT_MESSAGES: Record<string, string> = {
  ...ERROR_MESSAGES,
  NETWORK_ERROR: 'Нет соединения с сервером — проверьте сеть',
  PARSE_ERROR: 'Сервер вернул некорректный ответ',
};

/** Ошибка API на клиенте: код + русское сообщение для тоста. */
export class ApiClientError extends Error {
  readonly code: string;

  constructor(code: string) {
    super(CLIENT_MESSAGES[code] ?? `Ошибка: ${code}`);
    this.name = 'ApiClientError';
    this.code = code;
  }
}

/**
 * Запрос к движку: engineDispatch возвращает DTO-ответ роута ({ ok: true, ... })
 * или бросает ApiGameError с кодом/статусом роута (§1.5). Обвязка — как в
 * серверной версии: ApiGameError → ApiClientError(code); непредвиденное —
 * NETWORK_ERROR; ответ без ok — PARSE_ERROR (мёртвые, но сохранённые коды).
 */
async function engineRequest<T>(method: string, path: string, body?: unknown): Promise<T> {
  let data: unknown;
  try {
    const req: EngineRequest = body === undefined ? {} : (body as EngineRequest);
    data = await engineDispatch(method, path, req);
  } catch (error) {
    if (error instanceof ApiGameError) throw new ApiClientError(error.code);
    throw new ApiClientError('NETWORK_ERROR');
  }

  if (data !== null && typeof data === 'object' && 'ok' in data) {
    const rec = data as Record<string, unknown>;
    if (rec.ok === true) return data as T;
    if (rec.ok === false && typeof rec.error === 'string') {
      throw new ApiClientError(rec.error);
    }
  }
  throw new ApiClientError('PARSE_ERROR');
}

function post<T>(path: string, body?: unknown): Promise<T> {
  return engineRequest<T>('POST', path, body);
}

function patch<T>(path: string, body: unknown): Promise<T> {
  return engineRequest<T>('PATCH', path, body);
}

function remove<T>(path: string): Promise<T> {
  return engineRequest<T>('DELETE', path);
}

/** Параметры создания карьеры (POST /saves движка). */
export interface CreateSaveParams {
  leagueCode: string;
  clubIndex: number;
  managerName: string;
  careerName?: string;
}

export const api = {
  // ── Каталог и карьеры ──
  getLeagues(): Promise<LeagueCatalogResponse> {
    return engineRequest<LeagueCatalogResponse>('GET', '/leagues');
  },

  getSaves(): Promise<SavesListResponse> {
    return engineRequest<SavesListResponse>('GET', '/saves');
  },

  createSave(p: CreateSaveParams): Promise<CreateSaveResponse> {
    return post<CreateSaveResponse>('/saves', p);
  },

  renameSave(saveId: string, careerName: string): Promise<{ ok: true }> {
    return patch<{ ok: true }>(`/saves/${encodeURIComponent(saveId)}`, { careerName });
  },

  deleteSave(saveId: string): Promise<{ ok: true }> {
    return remove<{ ok: true }>(`/saves/${encodeURIComponent(saveId)}`);
  },

  // ── Игра (всё с saveId) ──
  getState(saveId: string): Promise<StateResponse> {
    return engineRequest<StateResponse>('GET', '/state', { saveId });
  },

  simulate(saveId: string): Promise<SimulateResponse> {
    return post<SimulateResponse>('/simulate', { saveId });
  },

  saveTactic(payload: TacticPayload & { saveId: string }): Promise<TacticResponse> {
    return post<TacticResponse>('/tactic', payload);
  },

  getMarket(filters: MarketFilters & { saveId: string }): Promise<MarketResponse> {
    // Параметры — как в URL-версии: не-дефолтные передаются, дефолты роутера
    // (position 'ALL', maxPrice/minOvr null, sort 'ovr') применяются там же.
    return engineRequest<MarketResponse>('GET', '/market', {
      saveId: filters.saveId,
      ...(filters.position !== 'ALL' ? { position: filters.position } : {}),
      ...(filters.maxPrice !== null ? { maxPrice: filters.maxPrice } : {}),
      ...(filters.minOvr !== null ? { minOvr: filters.minOvr } : {}),
      sort: filters.sort,
    });
  },

  buyPlayer(saveId: string, playerId: string): Promise<BuyResponse> {
    return post<BuyResponse>('/market/buy', { saveId, playerId });
  },

  // ── Модуль 3: контрактные переговоры, скаутинг, входящие офферы ──

  /** Покупка с контракт-предложением: ответ — раунд переговоров либо сделка. */
  buyPlayerNegotiated(
    saveId: string,
    playerId: string,
    offer: { salary: number; years: number; goalBonus: number; cleanSheetBonus: number },
  ): Promise<BuyNegotiatedResponse> {
    return post<BuyNegotiatedResponse>('/market/buy', { saveId, playerId, ...offer });
  },

  getScout(saveId: string): Promise<ScoutResponse> {
    return engineRequest<ScoutResponse>('GET', '/scout', { saveId });
  },

  scoutWatch(saveId: string, playerId: string): Promise<{ ok: true }> {
    return post<{ ok: true }>('/scout/watch', { saveId, playerId });
  },

  scoutUnwatch(saveId: string, playerId: string): Promise<{ ok: true }> {
    return post<{ ok: true }>('/scout/unwatch', { saveId, playerId });
  },

  getTransferOffers(saveId: string): Promise<TransferOffersResponse> {
    return engineRequest<TransferOffersResponse>('GET', '/transfer-offers', { saveId });
  },

  acceptTransferOffer(saveId: string, offerId: string): Promise<BuyResponse> {
    return post<BuyResponse>('/transfer-offers/accept', { saveId, offerId });
  },

  rejectTransferOffer(saveId: string, offerId: string): Promise<BuyResponse> {
    return post<BuyResponse>('/transfer-offers/reject', { saveId, offerId });
  },

  listPlayer(saveId: string, playerId: string, price: number): Promise<BuyResponse> {
    return post<BuyResponse>('/market/sell', { saveId, playerId, price });
  },

  getMatch(saveId: string, id: string): Promise<MatchResponse> {
    return engineRequest<MatchResponse>('GET', '/match', { saveId, id });
  },

  // ── Тренировки ──
  getTraining(saveId: string): Promise<TrainingStateResponse> {
    return engineRequest<TrainingStateResponse>('GET', '/training', { saveId });
  },

  setTraining(
    saveId: string,
    focus: TrainingFocus,
    intensity: TrainingIntensity,
  ): Promise<SetTrainingResponse> {
    return post<SetTrainingResponse>('/training', { saveId, focus, intensity });
  },

  /** Модуль 4: индивидуальная программа игрока (null + null — сброс к командной). */
  setPlayerTraining(
    saveId: string,
    playerId: string,
    individual: { focus: TrainingFocus; intensity: TrainingIntensity } | null,
  ): Promise<SetPlayerTrainingResponse> {
    return post<SetPlayerTrainingResponse>('/training/player', {
      saveId,
      playerId,
      focus: individual?.focus ?? null,
      intensity: individual?.intensity ?? null,
    });
  },

  // ── Модуль 4: персонал и рынок труда ──
  getStaff(saveId: string): Promise<StaffResponse> {
    return engineRequest<StaffResponse>('GET', '/staff', { saveId });
  },

  hireStaff(saveId: string, staffId: string, years: number): Promise<StaffActionResponse> {
    return post<StaffActionResponse>('/staff/hire', { saveId, staffId, years });
  },

  fireStaff(saveId: string, staffId: string): Promise<StaffActionResponse> {
    return post<StaffActionResponse>('/staff/fire', { saveId, staffId });
  },

  renewStaff(saveId: string, staffId: string, years: number): Promise<StaffActionResponse> {
    return post<StaffActionResponse>('/staff/renew', { saveId, staffId, years });
  },

  // ── Награды ──
  getAwards(saveId: string): Promise<AwardsResponse> {
    return engineRequest<AwardsResponse>('GET', '/awards', { saveId });
  },

  // ── Фаза 3: контракты ──
  getContracts(saveId: string): Promise<ContractsResponse> {
    return engineRequest<ContractsResponse>('GET', '/contracts', { saveId });
  },

  /** Stateless: accepted при предложении ≥ 0.92×спроса, иначе counter. */
  renewContract(
    saveId: string,
    playerId: string,
    years: number,
    salary: number,
  ): Promise<RenewResponse> {
    return post<RenewResponse>('/contracts/renew', { saveId, playerId, years, salary });
  },

  // ── Фаза 3: правление ──
  getBoard(saveId: string): Promise<BoardResponse> {
    return engineRequest<BoardResponse>('GET', '/board', { saveId });
  },

  // ── Фаза 3: академия ──
  getAcademy(saveId: string): Promise<AcademyResponse> {
    return engineRequest<AcademyResponse>('GET', '/academy', { saveId });
  },

  // ── Фаза 3: диалог игрока (история по сезонам + итоги + награды) ──
  getPlayerDialog(saveId: string, playerId: string): Promise<PlayerDialogResponse> {
    return engineRequest<PlayerDialogResponse>('GET', '/player', { saveId, id: playerId });
  },

  // ── Фаза 4: план на матч клуба игрока (§6.1 architecture-phase4.md) ──
  getMatchPlan(saveId: string): Promise<MatchPlanResponse> {
    return engineRequest<MatchPlanResponse>('GET', '/matchplan', { saveId });
  },

  setMatchPlan(saveId: string, plan: MatchPlanDTO): Promise<SetMatchPlanResponse> {
    return post<SetMatchPlanResponse>('/matchplan', { saveId, ...plan });
  },

  // ── Фаза 4: Кубок Европы (resolveSave — finished-сейвы тоже доступны) ──
  getEuro(saveId: string): Promise<EuroResponse> {
    return engineRequest<EuroResponse>('GET', '/euro', { saveId });
  },

  // ── D-5 «Территория» (§3.6): покупка/апгрейд здания — свежий снапшот, как buy/sell ──
  upgradeBuilding(saveId: string, buildingId: string): Promise<BuyResponse> {
    return post<BuyResponse>('/buildings', { saveId, buildingId });
  },

  // ── Модуль 5 (§ «Инфраструктура 2.0»): запуск расширения стадиона ──
  startStadiumExpansion(saveId: string, seats: 3000 | 5000 | 8000): Promise<StadiumResponse> {
    return post<StadiumResponse>('/stadium', { saveId, seats });
  },

  // ── D-6 «Тренер» (§4.6): личная жизнь — профиль/кошелёк/активы/семья ──
  getManager(saveId: string): Promise<ManagerResponse> {
    return engineRequest<ManagerResponse>('GET', '/manager', { saveId });
  },

  managerAsset(
    saveId: string,
    assetId: string,
    action: 'buy' | 'sell',
  ): Promise<ManagerAssetResponse> {
    return post<ManagerAssetResponse>('/manager/asset', { saveId, assetId, action });
  },

  // ── D-7 «Медиа» (§5.6): архив газетных вырезок (ленивый, пагинация) ──
  getMedia(saveId: string, offset = 0, limit = 10): Promise<MediaResponse> {
    return engineRequest<MediaResponse>('GET', '/media', { saveId, offset, limit });
  },
};

'use client';

import { motion } from 'framer-motion';
import { Landmark, Shield, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import { formatMoney, strengthLabel } from '@/lib/game/format';
import type { LeagueClubDTO } from '@/lib/game/types';
import { cn } from '@/lib/utils';

const TONE_CLASS = {
  gold: 'border-[#EAB308]/40 bg-[#EAB308]/10 text-[#EAB308]',
  normal: 'border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]',
  low: 'border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]',
} as const;

/** Карточка клуба каталога лиги (шаг 2 флоу новой карьеры). */
export function ClubCard({
  club,
  selected,
  onSelect,
}: {
  club: LeagueClubDTO;
  selected: boolean;
  onSelect: () => void;
}) {
  const strength = strengthLabel(club.strength);
  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      whileHover={{ y: -2 }}
      onClick={onSelect}
      className={cn(
        'min-h-[44px] w-full rounded-lg text-left outline-none focus-visible:ring-2 focus-visible:ring-ring',
        selected && 'ring-2 ring-primary',
      )}
      aria-pressed={selected}
      aria-label={`Клуб ${club.name}`}
    >
      <Card
        className={cn(
          'h-full border-border/70 transition-colors hover:border-primary/50',
          selected && 'border-primary',
        )}
      >
        <CardContent className="flex h-full flex-col gap-3 p-4">
          <div className="flex items-center gap-3">
            <TeamCrest
              shortName={club.shortName}
              colorPrimary={club.colorPrimary}
              colorSecondary={club.colorSecondary}
              size="lg"
            />
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold leading-tight">{club.name}</div>
              <div className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                <Landmark className="size-3" aria-hidden />
                {club.city}
              </div>
            </div>
            <Badge className={cn('border', TONE_CLASS[strength.tone])}>
              {strength.text} · {club.strength}
            </Badge>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1.5 rounded bg-secondary/60 px-2 py-1.5">
              <Shield className="size-3.5 text-[#EAB308]" aria-hidden />
              <span className="tabular font-semibold text-[#EAB308]">
                {formatMoney(club.startBalance)}
              </span>
            </div>
            <div className="flex items-center gap-1.5 rounded bg-secondary/60 px-2 py-1.5">
              <Users className="size-3.5 text-muted-foreground" aria-hidden />
              <span className="tabular text-muted-foreground">
                {club.stadiumCapacity.toLocaleString('ru-RU')} мест
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.button>
  );
}

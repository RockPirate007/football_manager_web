/** Ошибка игрового API с кодом и HTTP-статусом (контракты раздела 7 architecture.md). */

export class ApiGameError extends Error {
  readonly code: string;
  readonly status: number;

  constructor(code: string, status: number) {
    super(code);
    this.name = 'ApiGameError';
    this.code = code;
    this.status = status;
  }
}

/** Русские сообщения об ошибках API для тостов. */
export const ERROR_MESSAGES: Record<string, string> = {
  INVALID_NAME: 'Имя менеджера должно быть от 1 до 40 символов',
  NO_SAVE: 'Сохранение не найдено — начните новую игру',
  SAVE_NOT_FOUND: 'Сохранение не найдено',
  ALREADY_SELECTED: 'Клуб уже выбран',
  INVALID_LINEUP: 'Неверный состав: нужно 11 своих игроков без дубликатов и травмированных',
  INVALID_PAYLOAD: 'Некорректные данные запроса',
  WEEK_ALREADY_PLAYED: 'Тур уже сыгран',
  NOT_FOR_SALE: 'Игрок недоступен для покупки',
  SQUAD_FULL: 'В составе уже максимум 25 игроков',
  INSUFFICIENT_BUDGET: 'Не хватает трансферного бюджета',
  SQUAD_MIN_VIOLATION: 'Продажа нарушит минимальные требования к составу',
  PRICE_OUT_OF_BAND: 'Цена вне допустимого диапазона (75–250% стоимости)',
  PLAYER_INJURED: 'Травмированного игрока нельзя продать',
  NOT_YOUR_PLAYER: 'Игрок не в вашем клубе',
  ALREADY_LISTED: 'Игрок уже выставлен на продажу',
  MATCH_NOT_FOUND: 'Матч не найден',
  UNKNOWN: 'Неизвестная ошибка сервера',
  // ── Фаза 2 (§6.5 architecture-upgrade.md) ──
  SAVE_LIMIT_REACHED: 'Достигнут лимит карьер (8) — удалите одну из них',
  INVALID_LEAGUE: 'Неизвестная лига или клуб',
  INVALID_TRAINING: 'Неверный фокус или интенсивность тренировки',
  INVALID_CAREER_NAME: 'Название карьеры — от 1 до 60 символов',
  // ── Фаза 3 (§6.4 architecture-phase3.md) ──
  INVALID_CONTRACT: 'Неверные параметры продления контракта',
  CONTRACT_NOT_RENEWABLE: 'Контракт можно продлить, когда осталось не более 2 лет',
  CONTRACT_PRECONTRACT: 'Игрок подписал предконтракт с другим клубом',
  PLAYER_NOT_FOUND: 'Игрок не найден',
  // ── Фаза 4 (§6.3 architecture-phase4.md) ──
  INVALID_MATCH_PLAN: 'Неверные настройки плана на матч',
  // ── D-5 «Территория» (§3.3/§3.6 спеки desktop) ──
  BUILDING_NOT_FOUND: 'Здание не найдено',
  BUILDING_MAX_LEVEL: 'Здание уже максимального уровня',
  BUILDING_IN_PROGRESS: 'Уже идёт стройка — дождитесь её завершения',
  INSUFFICIENT_FUNDS: 'Не хватает баланса клуба на постройку',
  // ── D-6 «Тренер» (§4.6 спеки desktop) ──
  ASSET_NOT_FOUND: 'Актив не найден',
  ASSET_NOT_OWNED: 'Актив не куплен — продавать нечего',
  INSUFFICIENT_WALLET: 'Не хватает личных средств на покупку',
  ASSET_ALREADY_OWNED: 'Актив уже в собственности',
  // ── Модуль 3 (трансферный рынок/скаутинг) ──
  SCOUT_SLOTS_FULL: 'Все скауты заняты — освободите слот наблюдения',
  OFFER_NOT_PENDING: 'Предложение уже не активно',
  // ── Модуль 4 (персонал/рынок труда) ──
  STAFF_NOT_FOUND: 'Сотрудник не найден',
  STAFF_SLOT_FULL: 'Слот роли занят — сначала уволите текущего сотрудника',
  STAFF_ALREADY_HIRED: 'Кандидат уже трудоустроен в другом клубе',
  STAFF_NOT_EMPLOYED: 'Этот человек не работает в вашем клубе',
  INVALID_STAFF_YEARS: 'Срок контракта — от 1 до 3 сезонов',
  PLAYER_TRAINING_INVALID: 'Неверная индивидуальная программа тренировки',
  // ── Модуль 5 (стадион/бюджеты/финансы) ──
  STADIUM_IN_PROGRESS: 'Стадион уже расширяется — дождитесь завершения стройки',
  STADIUM_TOO_BIG: 'Достигнута максимальная вместимость стадиона (90 000)',
  INVALID_STADIUM_SEATS: 'Неверный вариант расширения стадиона',
  WAGE_BUDGET_EXCEEDED: 'Правление: зарплатный бюджет исчерпан — сначала разгрузите ведомость',
};

/**
 * Генерация мира по LeagueDef: команды из данных лиг, составы 20–22 игрока,
 * календарь лиги (карусель) с маппингом тура → сквозная неделя.
 * Чистый модуль (§2.6 architecture-upgrade.md).
 */

import { buildSeasonPlan, leagueWeekOf } from './calendar';
import {
  AI_STYLES, AI_STYLE_ASSIGN, AI_STYLE_LEAGUE_BIAS, AI_STYLE_LEAGUE_BIAS_P,
  type AiStyleCode,
} from './constants';
import { LEAGUES, NAME_POOLS, type LeagueDef, type NamePoolContext } from './leagues';
import {
  assignShirtNumbers, ensureUniqueNames, generatePlayer, playerCreateData, type PlayerLike,
} from './players';
import { pick, pickWeighted, type RNG } from './rng';
import type { FormationId, LeagueCode, Mentality, Position } from './types';

export type { NamePoolContext } from './leagues';

export interface TeamGen {
  id: string;
  name: string;
  shortName: string;
  city: string;
  colorPrimary: string;
  colorSecondary: string;
  strength: number;
  stadiumCapacity: number;
  formation: FormationId;
  mentality: Mentality;
  tempo: 'low' | 'medium' | 'high';
  pressing: 'low' | 'medium' | 'high';
  defLine: 'low' | 'medium' | 'high';
  playStyle: 'balanced' | 'wing' | 'passing' | 'long' | 'counter';
  players: PlayerLike[];
  // ── Фаза 4: стиль ИИ-тренера ──
  aiStyle: AiStyleCode;
  aiCoachName: string;
  leagueCode: LeagueCode;
}

export interface MatchGen {
  id: string;
  week: number;
  homeTeamId: string;
  awayTeamId: string;
  competition: 'league';
}

export interface WorldGen {
  teams: TeamGen[];
  matches: MatchGen[];
}

/** Шаблон состава: GK×2, DL×2, DC×3, DR×2, DM×2, M×3, AM×2, ST×3 + допы → 20–22. */
function squadTemplatePositions(rng: RNG): Position[] {
  const positions: Position[] = [
    'GK', 'GK',
    'DL', 'DL', 'DC', 'DC', 'DC', 'DR', 'DR',
    pick(rng, ['DML', 'DMC', 'DMR'] as Position[]),
    pick(rng, ['DML', 'DMC', 'DMR'] as Position[]),
    'ML', 'MC', 'MR',
    pick(rng, ['AML', 'AMR', 'AMC'] as Position[]),
    pick(rng, ['AML', 'AMR', 'AMC'] as Position[]),
    'ST', 'ST', 'ST',
  ];
  // +1 случайный всегда, +1 с вероятностью ~0.6, +1 с вероятностью 0.25 → итог 20–22
  const extrasPool: Position[] = ['DC', 'MC', 'ST'];
  positions.push(pick(rng, extrasPool));
  if (rng() < 0.6) positions.push(pick(rng, extrasPool));
  if (rng() < 0.25) positions.push(pick(rng, extrasPool));
  return positions;
}

export function generateSquad(rng: RNG, strength: number, pool: NamePoolContext): PlayerLike[] {
  const positions = squadTemplatePositions(rng);
  const players = positions.map((pos) => generatePlayer(rng, strength, pos, { pool }));
  ensureUniqueNames(rng, players);
  assignShirtNumbers(players);
  return players;
}

/** Назначение стиля ИИ по силе + «национальный колорит» (research §2.6-2). Фаза 4. */
export function assignAiStyle(rng: RNG, strength: number, leagueCode: LeagueCode): AiStyleCode {
  const bias = AI_STYLE_LEAGUE_BIAS[leagueCode];
  if (bias && rng() < AI_STYLE_LEAGUE_BIAS_P) return bias;
  const band = strength >= 84 ? 'top' : strength >= 74 ? 'mid' : 'low';
  return pickWeighted(
    rng,
    AI_STYLE_ASSIGN[band].map((e) => ({ item: e.style, weight: e.p })),
  );
}

/** Круговой метод «карусель»: (N−1) туров + зеркальная вторая половина = (N−1)×2 туров. */
export function generateCalendar(teamIds: string[], idFactory: () => string): MatchGen[] {
  const n = teamIds.length;
  if (n < 2 || n % 2 !== 0) throw new Error(`generateCalendar: нужно чётное число команд, получено ${n}`);
  const fixed = teamIds[n - 1];
  const rotating = teamIds.slice(0, n - 1);
  const matches: MatchGen[] = [];

  const pairsByRound: [string, string][][] = [];
  for (let r = 0; r < n - 1; r++) {
    const order = [...rotating.slice(r), ...rotating.slice(0, r)];
    const full = [...order, fixed];
    const pairs: [string, string][] = [];
    for (let i = 0; i < n / 2; i++) {
      const a = full[i];
      const b = full[n - 1 - i];
      pairs.push(r % 2 === 0 ? [a, b] : [b, a]);
    }
    pairsByRound.push(pairs);
  }

  const rounds = n - 1;
  for (let r = 0; r < rounds; r++) {
    const week = r + 1;
    for (const [home, away] of pairsByRound[r]) {
      matches.push({ id: idFactory(), week, homeTeamId: home, awayTeamId: away, competition: 'league' });
    }
  }
  for (let r = 0; r < rounds; r++) {
    const week = rounds + r + 1;
    for (const [home, away] of pairsByRound[r]) {
      matches.push({ id: idFactory(), week, homeTeamId: away, awayTeamId: home, competition: 'league' });
    }
  }
  return matches;
}

/** Контекст пула имён лиги. */
export function poolContextOf(def: LeagueDef): NamePoolContext {
  return { base: def.basePool, foreign: def.foreignMix };
}

// ── Фаза 4: гостевые клубы Кубка Европы ──────────────────────────────────

/** Семя гостя: реальный клуб ДРУГОЙ лиги (leagues.ts; clubIndex — индекс в def.clubs). */
export interface EuroGuestSeedInput {
  leagueCode: LeagueCode;
  clubIndex: number;
  strength: number;
}

/** Готовые данные для db.team.createMany / db.player.createMany (Фаза 4, §4.5 ТЗ). */
export interface EuroGuestTeamGen {
  team: {
    id: string;
    saveId: string;
    name: string;
    shortName: string;
    city: string;
    colorPrimary: string;
    colorSecondary: string;
    strength: number;
    stadiumCapacity: number;
    formation: FormationId;
    mentality: Mentality;
    tempo: 'low' | 'medium' | 'high';
    pressing: 'low' | 'medium' | 'high';
    defLine: 'low' | 'medium' | 'high';
    playStyle: 'balanced' | 'wing' | 'passing' | 'long' | 'counter';
    aiStyle: AiStyleCode;
    aiCoachName: string;
    isEuroGuest: true;
    leagueCode: LeagueCode;
  };
  /** Строки Prisma Player (playerCreateData): contractUntil=99, teamId=team.id. */
  players: ReturnType<typeof playerCreateData>[];
}

/**
 * Генерация гостевых клубов Кубка Европы (чистая): реальные клубы из ДРУГИХ
 * лиг (leagues.ts), составы 20–22 (generateSquad по силе клуба), стиль
 * assignAiStyle + тактика стиля, имя тренера из пула лиги, isEuroGuest=true.
 * rng: seed `${saveId}:euroguests:${season}` (создаётся вызывающим кодом);
 * запись в БД — week.ts (team.createMany + player.createMany).
 */
export function generateEuroGuests(
  rng: RNG,
  saveId: string,
  seeds: EuroGuestSeedInput[],
  idFactory: () => string = () => crypto.randomUUID(),
): EuroGuestTeamGen[] {
  const out: EuroGuestTeamGen[] = [];
  for (const seed of seeds) {
    const def = LEAGUES.find((l) => l.code === seed.leagueCode);
    if (!def) throw new Error(`generateEuroGuests: неизвестная лига ${seed.leagueCode}`);
    const club = def.clubs[seed.clubIndex];
    if (!club) {
      throw new Error(`generateEuroGuests: лига ${seed.leagueCode} — нет клуба #${seed.clubIndex}`);
    }

    const aiStyle = assignAiStyle(rng, club.str, def.code);
    const tactic = AI_STYLES[aiStyle].tactic;
    const coachFirst = pick(rng, NAME_POOLS[def.basePool].first);
    const coachLast = pick(rng, NAME_POOLS[def.basePool].last);

    const teamId = idFactory();
    const squad = generateSquad(rng, club.str, poolContextOf(def));
    for (const p of squad) {
      p.teamId = teamId;
      p.contractUntil = 99; // гости вне системы контрактов/Босмана (§5.5 ТЗ)
    }

    out.push({
      team: {
        id: teamId,
        saveId,
        name: club.name,
        shortName: club.short,
        city: club.city,
        colorPrimary: club.c1,
        colorSecondary: club.c2,
        strength: club.str,
        stadiumCapacity: club.cap,
        ...tactic,
        aiStyle,
        aiCoachName: `${coachFirst} ${coachLast}`,
        isEuroGuest: true,
        leagueCode: def.code,
      },
      players: squad.map((p) => playerCreateData(saveId, p)),
    });
  }
  return out;
}

/**
 * Генерация мира по коду лиги: реальные клубы (сила без шума), тактика — aiTactic,
 * составы — из пула имён страны; лиговый календарь маппится на сквозные недели плана.
 */
export function generateLeague(
  rng: RNG,
  leagueCode: LeagueCode,
  idFactory: () => string = () => crypto.randomUUID(),
): WorldGen {
  const def = LEAGUES.find((l) => l.code === leagueCode);
  if (!def) throw new Error(`generateLeague: неизвестная лига ${leagueCode}`);
  if (def.clubs.length !== def.teamCount) {
    throw new Error(`generateLeague: лига ${leagueCode} — клубов ${def.clubs.length}, ожидалось ${def.teamCount}`);
  }

  const pool = poolContextOf(def);

  const teams: TeamGen[] = [];
  for (const club of def.clubs) {
    // Фаза 4: стиль НАЗНАЧАЕТ тактические поля (нулевое двойное учётие с MENTALITY_MODS)
    const aiStyle = assignAiStyle(rng, club.str, def.code);
    const tactic = AI_STYLES[aiStyle].tactic;
    const coachFirst = pick(rng, NAME_POOLS[def.basePool].first);
    const coachLast = pick(rng, NAME_POOLS[def.basePool].last);
    teams.push({
      id: idFactory(),
      name: club.name,
      shortName: club.short,
      city: club.city,
      colorPrimary: club.c1,
      colorSecondary: club.c2,
      strength: club.str,
      stadiumCapacity: club.cap,
      ...tactic,
      players: generateSquad(rng, club.str, pool),
      aiStyle,
      aiCoachName: `${coachFirst} ${coachLast}`,
      leagueCode: def.code,
    });
  }

  // Маппинг туров карусели на сквозные недели плана сезона
  const plan = buildSeasonPlan(def.code);
  const matches = generateCalendar(
    teams.map((t) => t.id),
    idFactory,
  ).map((m) => ({ ...m, week: leagueWeekOf(plan, m.week) }));

  return { teams, matches };
}

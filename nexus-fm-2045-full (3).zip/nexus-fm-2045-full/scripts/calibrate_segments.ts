/**
 * P4-3-2 · ГЕЙТ КАЛИБРОВКИ сегментного движка (§4.2/§10 architecture-phase4.md).
 *
 * 20 000 матчей равных по силе команд (полные MatchTeamInput: XI + 7 запасных,
 * дефолтный план матча) на РЕАЛЬНЫХ чистых модулях (match.ts / coach.ts /
 * strength.ts / rng.ts / generate.ts).
 *
 * Целевой коридор: home 44–48%, draw 24–27%, голы 2.6–2.9, ЖК 3.5–4.5.
 * Дополнительно: % матчей с заменами, распределение голов по сегментам
 * (ожидание ≈ 42/28/30), средняя доля владения и «в створ».
 *
 * Два прогона: A) обе команды balanced (бейзлайн движка, сравнение со старым
 * движком — инвариант линейности), B) стили по assignAiStyle (реалистичная
 * смесь). Гейт применяется к прогону A; прогон B — информационный.
 *
 * Запуск: bun scripts/calibrate_segments.ts
 */
import { simulateMatch, type MatchTeamInput } from '@/lib/game/match';
import { generateSquad, poolContextOf, assignAiStyle } from '@/lib/game/generate';
import { autoLineup } from '@/lib/game/players';
import { leagueByCode } from '@/lib/game/leagues';
import { mulberry32 } from '@/lib/game/rng';
import { AI_STYLES, MATCH_PLAN_DEFAULT, SEGMENT_BOUNDS } from '@/lib/game/constants';
import type { PlayerLike } from '@/lib/game/players';
import type { MatchEvent } from '@/lib/game/types';

const N_MATCHES = 20_000;
const STRENGTH = 75;

interface Squad {
  players: PlayerLike[];
  lineup: (string | null)[];
  bench: string[];
}

const EPL = leagueByCode('EPL');
if (!EPL) throw new Error('EPL not found');
const EPL_POOL = poolContextOf(EPL);

function makeSquad(seed: number): Squad {
  const rng = mulberry32(seed);
  const players = generateSquad(rng, STRENGTH, EPL_POOL);
  const auto = autoLineup(players, '4-4-2', false);
  return { players, lineup: auto.lineup, bench: auto.bench };
}

function balancedInput(s: Squad, teamId: string, name: string): MatchTeamInput {
  return {
    teamId,
    name,
    players: s.players,
    formation: '4-4-2',
    mentality: 'balanced',
    tempo: 'medium',
    pressing: 'medium',
    defLine: 'medium',
    playStyle: 'balanced',
    lineup: s.lineup,
    bench: s.bench,
    coach: { style: 'balanced', plan: { ...MATCH_PLAN_DEFAULT } },
  };
}

function styledInput(s: Squad, teamId: string, name: string, style: string): MatchTeamInput {
  const def = AI_STYLES[(style as keyof typeof AI_STYLES) ?? 'balanced'] ?? AI_STYLES.balanced;
  return {
    teamId,
    name,
    players: s.players,
    formation: def.tactic.formation,
    mentality: def.tactic.mentality,
    tempo: def.tactic.tempo,
    pressing: def.tactic.pressing,
    defLine: def.tactic.defLine,
    playStyle: def.tactic.playStyle,
    lineup: s.lineup,
    bench: s.bench,
    coach: { style: def.code, plan: { ...MATCH_PLAN_DEFAULT } },
  };
}

interface Agg {
  home: number;
  draw: number;
  away: number;
  goals: number;
  yellows: number;
  reds: number;
  subsMatches: number;
  subsTotal: number;
  segGoals: number[];
  possessionSum: number;
  shotsSum: number;
  sotSum: number;
}

function emptyAgg(): Agg {
  return {
    home: 0, draw: 0, away: 0, goals: 0, yellows: 0, reds: 0,
    subsMatches: 0, subsTotal: 0, segGoals: [0, 0, 0], possessionSum: 0, shotsSum: 0, sotSum: 0,
  };
}

function segBucket(minute: number): number {
  if (minute <= SEGMENT_BOUNDS[0]) return 0;
  if (minute <= SEGMENT_BOUNDS[1]) return 1;
  return 2;
}

function runPass(label: string, homeOf: (m: number) => MatchTeamInput, awayOf: (m: number) => MatchTeamInput): Agg {
  const agg = emptyAgg();
  for (let m = 0; m < N_MATCHES; m++) {
    const rng = mulberry32(0x4b1d5 + m);
    const res = simulateMatch(rng, homeOf(m), awayOf(m));
    if (res.homeGoals > res.awayGoals) agg.home += 1;
    else if (res.homeGoals === res.awayGoals) agg.draw += 1;
    else agg.away += 1;
    agg.goals += res.homeGoals + res.awayGoals;
    agg.yellows += res.stats.yellowsHome + res.stats.yellowsAway;
    agg.reds += res.stats.redsHome + res.stats.redsAway;
    const subs = res.homeSubs.length + res.awaySubs.length;
    if (subs > 0) agg.subsMatches += 1;
    agg.subsTotal += subs;
    for (const e of res.events) {
      if (e.type === 'goal') agg.segGoals[segBucket(e.minute)] += 1;
    }
    agg.possessionSum += res.stats.possessionHome;
    agg.shotsSum += res.stats.shotsHome + res.stats.shotsAway;
    agg.sotSum += res.stats.sotHome + res.stats.sotAway;
    if ((m + 1) % 5000 === 0) console.error(`  [${label}] ${m + 1}/${N_MATCHES}`);
  }
  return agg;
}

function report(label: string, agg: Agg): void {
  const n = N_MATCHES;
  const homePct = (100 * agg.home) / n;
  const drawPct = (100 * agg.draw) / n;
  const awayPct = (100 * agg.away) / n;
  const avgGoals = agg.goals / n;
  const avgYellows = agg.yellows / n;
  const avgReds = agg.reds / n;
  const subsPct = (100 * agg.subsMatches) / n;
  const segTotal = agg.segGoals.reduce((s, x) => s + x, 0);
  const segPct = agg.segGoals.map((x) => (100 * x) / segTotal);
  console.log(`\n=== ${label} (${n} матчей) ===`);
  console.log(`home=${homePct.toFixed(2)}%  draw=${drawPct.toFixed(2)}%  away=${awayPct.toFixed(2)}%`);
  console.log(`goals/match=${avgGoals.toFixed(3)}  yellows/match=${avgYellows.toFixed(2)}  reds/match=${avgReds.toFixed(3)}`);
  console.log(`subs: ${subsPct.toFixed(1)}% матчей с ≥1 заменой, ${agg.subsTotal / n} замен/матч`);
  console.log(
    `segments: 1-45=${segPct[0].toFixed(1)}%  46-70=${segPct[1].toFixed(1)}%  71-93=${segPct[2].toFixed(1)}% (ожидание 42/28/30)`,
  );
  console.log(`possessionHome=${agg.possessionSum / n}  shots=${agg.shotsSum / n}  sot=${agg.sotSum / n}`);
}

// ── Прогон A: balanced обе стороны (бейзлайн) ─────────────────────────────

const squadH = makeSquad(101);
const squadA = makeSquad(202);
const homeB = balancedInput(squadH, 'H', 'Калibra-Х');
const awayB = balancedInput(squadA, 'A', 'Калибра-Г');
const aggA = runPass('A/balanced', () => homeB, () => awayB);
report('A · balanced vs balanced (ГЕЙТ)', aggA);

// ── Прогон B: смесь стилей (информационно) ────────────────────────────────

const styleRng = mulberry32(0x5712);
const aggB = runPass(
  'B/styles',
  () => styledInput(squadH, 'H', 'Калибра-Х', assignAiStyle(styleRng, STRENGTH, 'EPL')),
  () => styledInput(squadA, 'A', 'Калибра-Г', assignAiStyle(styleRng, STRENGTH, 'EPL')),
);
report('B · смесь стилей (информационно)', aggB);

// ── Вердикт гейта (по прогону A) ──────────────────────────────────────────

const homePct = (100 * aggA.home) / N_MATCHES;
const drawPct = (100 * aggA.draw) / N_MATCHES;
const avgGoals = aggA.goals / N_MATCHES;
const avgYellows = aggA.yellows / N_MATCHES;
const verdict = [
  homePct >= 44 && homePct <= 48,
  drawPct >= 24 && drawPct <= 27,
  avgGoals >= 2.6 && avgGoals <= 2.9,
  avgYellows >= 3.5 && avgYellows <= 4.5,
];
const names = ['home 44-48%', 'draw 24-27%', 'goals 2.6-2.9', 'yellows 3.5-4.5'];
console.log('\n=== ВЕРДИКТ ГЕЙТА ===');
names.forEach((nm, i) => console.log(`${nm}: ${verdict[i] ? 'OK' : 'FAIL'}`));
console.log(verdict.every(Boolean) ? 'GATE=PASS' : 'GATE=FAIL');
process.exit(verdict.every(Boolean) ? 0 : 1);

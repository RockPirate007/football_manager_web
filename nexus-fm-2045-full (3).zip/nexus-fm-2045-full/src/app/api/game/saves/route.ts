import { NextResponse } from 'next/server';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { db } from '@/lib/db';
import { buildSaveCard, buildSaveCards, normalizeErrorCode } from '@/lib/game/api-helpers';
import { nextSeasonTarget } from '@/lib/game/board';
import {
  BOARD_CONF_START, BOARD_HONEYMOON_WEEKS, SAVES_MAX, START_BALANCE_BASE,
  START_BALANCE_PER_STRENGTH,
} from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { generateLeague } from '@/lib/game/generate';
import { leagueByCode } from '@/lib/game/leagues';
import { autoLineup, playerCreateData } from '@/lib/game/players';
import { hashString, mulberry32 } from '@/lib/game/rng';

const bodySchema = z.object({
  leagueCode: z.string().trim().min(1),
  clubIndex: z.number().int(),
  managerName: z.string().trim(),
  careerName: z.string().trim().optional(),
});

function fail(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

/** GET /api/game/saves — список карьер (до 8), сортировка lastOpenedAt desc. §6.2. */
export async function GET() {
  try {
    const saves = await buildSaveCards();
    return NextResponse.json({ ok: true, saves });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/saves GET]', error);
    return fail('UNKNOWN', 500);
  }
}

/**
 * POST /api/game/saves — создать карьеру (атомарная замена /new + /select).
 * Мир генерируется по leagueCode; клуб выбирается clubIndex сразу.
 */
export async function POST(request: Request) {
  try {
    const json: unknown = await request.json().catch(() => null);
    const parsed = bodySchema.safeParse(json ?? {});
    if (!parsed.success) return fail('INVALID_PAYLOAD', 400);
    const { leagueCode, clubIndex, managerName } = parsed.data;
    const careerNameRaw = parsed.data.careerName ?? '';

    // Валидация домена (§6.2): лига → клуб → имя → название карьеры
    const def = leagueByCode(leagueCode);
    if (!def || clubIndex < 0 || clubIndex >= def.teamCount) {
      return fail('INVALID_LEAGUE', 400);
    }
    if (managerName.length < 1 || managerName.length > 40) {
      return fail('INVALID_NAME', 400);
    }
    if (careerNameRaw.length > 60) {
      return fail('INVALID_CAREER_NAME', 400);
    }

    // Лимит 8 карьер
    const count = await db.gameSave.count();
    if (count >= SAVES_MAX) return fail('SAVE_LIMIT_REACHED', 409);

    // Генерация мира по лиге
    const seed = hashString(`${crypto.randomUUID()}:${Date.now()}`);
    const rng = mulberry32(seed);
    const world = generateLeague(rng, def.code);
    const saveId = crypto.randomUUID();
    const club = world.teams[clubIndex];
    const auto = autoLineup(club.players, '4-4-2');
    const startBalance =
      START_BALANCE_BASE + Math.max(0, club.strength - 55) * START_BALANCE_PER_STRENGTH;
    const careerName = careerNameRaw.length > 0 ? careerNameRaw : `${club.name} · Сезон 1`;

    // Фаза 3: цель правления по рангу силы клуба (сезон 1 — без прошлого места)
    const boardTarget = nextSeasonTarget({
      teamCount: def.teamCount,
      teams: world.teams.map((t) => ({ id: t.id, strength: t.strength })),
      userTeamId: club.id,
      prevPlace: null,
      harderByOverperformance: false,
    });

    // «select»-блок старого /select + вся генерация — одной транзакцией.
    // GameSave.teamId — FK на Team: сейв создаётся БЕЗ клуба, teamId
    // присваивается завершающим update (иначе нарушение FK в SQLite).
    const ops: Prisma.PrismaPromise<unknown>[] = [
      db.gameSave.create({
        data: {
          id: saveId,
          managerName,
          careerName,
          leagueCode: def.code,
          season: 1,
          week: 1,
          balance: startBalance,
          status: 'active',
          lastOpenedAt: new Date(),
          cupRound: 0,
          // ── Фаза 3: правление ──
          boardTarget: boardTarget.code,
          boardTargetPlace: boardTarget.place,
          boardConfidence: BOARD_CONF_START,
          honeymoonUntilWeek: BOARD_HONEYMOON_WEEKS,
        },
      }),
    ];
    for (const team of world.teams) {
      const isUser = team.id === club.id;
      ops.push(
        db.team.create({
          data: {
            id: team.id,
            saveId,
            name: team.name,
            shortName: team.shortName,
            city: team.city,
            colorPrimary: team.colorPrimary,
            colorSecondary: team.colorSecondary,
            strength: team.strength,
            isUserTeam: isUser,
            stadiumCapacity: team.stadiumCapacity,
            formation: isUser ? '4-4-2' : team.formation,
            mentality: isUser ? 'balanced' : team.mentality,
            tempo: isUser ? 'medium' : team.tempo,
            pressing: isUser ? 'medium' : team.pressing,
            defLine: isUser ? 'medium' : team.defLine,
            playStyle: isUser ? 'balanced' : team.playStyle,
            // Фаза 4: стиль и тренер ИИ (генерация их назначает, но маппинг их терял —
            // из-за этого все новые сейвы получали дефолт balanced/null до ленивой миграции)
            aiStyle: isUser ? 'balanced' : team.aiStyle,
            aiCoachName: isUser ? null : team.aiCoachName,
            leagueCode: team.leagueCode,
            lineup: isUser ? JSON.stringify(auto.lineup) : null,
            bench: isUser ? JSON.stringify(auto.bench) : null,
            trainingFocus: 'rest',
            trainingIntensity: 'normal',
          },
        }),
      );
      for (const player of team.players) {
        player.teamId = team.id;
        ops.push(db.player.create({ data: playerCreateData(saveId, player) }));
      }
    }
    for (const match of world.matches) {
      ops.push(
        db.match.create({
          data: {
            id: match.id,
            saveId,
            season: 1,
            week: match.week,
            homeTeamId: match.homeTeamId,
            awayTeamId: match.awayTeamId,
          },
        }),
      );
    }
    ops.push(
      db.newsItem.create({
        data: {
          id: crypto.randomUUID(),
          saveId,
          season: 1,
          week: 1,
          type: 'info',
          message: `Добро пожаловать в «${club.name}», ${managerName}! Впереди ${def.leagueWeeks} туров и ${def.cupName}! Правление: цель сезона — ${boardTarget.label.toLowerCase()}.`,
        },
      }),
    );
    // Клуб выбран: завершающий update после создания всех команд
    ops.push(db.gameSave.update({ where: { id: saveId }, data: { teamId: club.id } }));
    await db.$transaction(ops);

    const saveRow = await db.gameSave.findUnique({ where: { id: saveId } });
    const card = saveRow ? await buildSaveCard(saveRow) : null;

    return NextResponse.json({
      ok: true as const,
      saveId,
      careerName,
      league: { code: def.code, nameRu: def.nameRu, flag: def.flag },
      club: { name: club.name, shortName: club.shortName },
      ...(card ? { save: card } : {}),
    });
  } catch (error) {
    if (error instanceof ApiGameError) return fail(normalizeErrorCode(error.code), error.status);
    console.error('[api/game/saves POST]', error);
    return fail('UNKNOWN', 500);
  }
}

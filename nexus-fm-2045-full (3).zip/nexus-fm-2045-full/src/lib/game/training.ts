/**
 * Недельные тренировки: фокус + интенсивность, xp-накопление, потолок
 * potential, состояние/травмы. §4 architecture-upgrade.md.
 * Мутирует игроков на месте; вызывается в simulateWeek ПОСЛЕ пост-матча.
 */

import {
  CONDITION_MAX, CONDITION_MIN, MORALE_MAX, MORALE_MIN,
  TRAIN_BASE, TRAIN_CONDITION_DELTA, TRAIN_INJURY_COND_MULT, TRAIN_INJURY_RISK,
  TRAIN_INJURY_WEEKS, TRAIN_INTENSITY_FACTOR, TRAIN_NOTES_MAX, TRAIN_REST_COND,
  TRAIN_REST_MORALE, TRAIN_XP_CAP,
} from './constants';
import { attrCategoryOf, growthMultOf } from './development';
import { computeOvr, refreshEconomy, type PlayerLike } from './players';
import { clamp, randInt, type RNG } from './rng';
import { ATTR_LABELS, parseTrainingXp, type AttrKey, type TrainingFocus, type TrainingIntensity } from './types';

/** Индивидуальная программа игрока (Модуль 4): переопределяет командную. */
export interface IndividualTraining {
  focus: TrainingFocus;
  intensity: TrainingIntensity;
}

/** Множители категорий атрибутов (специализации тренеров, Модуль 4). */
export type CategoryMult = Record<'tech' | 'mental' | 'phys' | 'gk', number>;

export const TRAINING_FOCUS_LABELS: Record<TrainingFocus, string> = {
  attack: 'Атака',
  defense: 'Защита',
  possession: 'Владение',
  physical: 'Физика',
  goalkeepers: 'Вратари',
  rest: 'Отдых',
};

export const TRAINING_INTENSITY_LABELS: Record<TrainingIntensity, string> = {
  light: 'Лёгкая',
  normal: 'Обычная',
  hard: 'Жёсткая',
};

export const FOCUS_ATTRS: Record<TrainingFocus, AttrKey[]> = {
  attack: ['finishing', 'dribbling', 'crossing', 'pace'],
  defense: ['tackling', 'marking', 'positioning', 'heading'],
  possession: ['passing', 'dribbling', 'positioning', 'aggression'],
  physical: ['pace', 'stamina', 'strength'],
  goalkeepers: ['reflexes', 'rushingOut', 'kicking'],
  rest: [],
};

export const GK_ATTRS: AttrKey[] = ['reflexes', 'rushingOut', 'kicking'];

/** Приведение строк БД к enum тренировок. */
export function coerceTrainingFocus(v: string): TrainingFocus {
  const all: TrainingFocus[] = ['attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest'];
  return (all as string[]).includes(v) ? (v as TrainingFocus) : 'rest';
}

export function coerceTrainingIntensity(v: string): TrainingIntensity {
  const all: TrainingIntensity[] = ['light', 'normal', 'hard'];
  return (all as string[]).includes(v) ? (v as TrainingIntensity) : 'normal';
}

/** Возрастная кривая роста (ЛЕГАСИ, плоская): ≤19 → 1.6; 20–23 → 1.3; 24–27 → 1.0; 28–30 → 0.6; 31+ → 0.3.
 *  Модуль 2: актуальный расчёт — покатегорийные growthMultOf (development.ts),
 *  эта функция оставлена для обратной совместимости внешних вызовов. */
export function ageCurveOf(age: number): number {
  if (age <= 19) return 1.6;
  if (age <= 23) return 1.3;
  if (age <= 27) return 1.0;
  if (age <= 30) return 0.6;
  return 0.3;
}

/** Запас потенциала: clamp((potential − ovr) / 10, 0.2, 1.5). */
export function headroomOf(p: PlayerLike): number {
  return clamp((p.potential - p.ovr) / 10, 0.2, 1.5);
}

/** Атрибуты, которые тренирует игрок в данном фокусе (GK — всегда вратарские). */
export function attrsForPlayer(p: PlayerLike, focus: TrainingFocus): AttrKey[] {
  if (focus === 'rest') return [];
  if (p.position === 'GK') return GK_ATTRS; // множитель ×1.0/×0.5 — ниже
  if (focus === 'goalkeepers') return []; // для полевых это «лёгкая неделя»
  return FOCUS_ATTRS[focus];
}

export interface TrainingReport {
  notes: string[]; // «Имя +1 Финиш (72→73)» — максимум TRAIN_NOTES_MAX
  injuries: { playerId: string; playerName: string; weeks: number }[];
}

/**
 * Тренировка команды за неделю. Правила:
 * - rest → никто не растёт; вся команда +10 состояния, +3 морали, риск травм 0%;
 * - вратарь тренирует GK_ATTRS в любом не-rest фокусе (×1.0 при «Вратари», ×0.5 иначе);
 * - полевой при фокусе «Вратари» не растёт;
 * - injuryWeeks > 0 → роста нет;
 * - g = TRAIN_BASE × I × A(возраст) × H(потенциал) × U(0.5..1.5);
 * - xp ≥ 1.0 → +1 атрибут, пока OVR не превысит potential (потолок жёсткий);
 * - состояние: light +5 / normal 0 / hard −8 (clamp 30..100); травмы 0.5/1/3%.
 *
 * D-5 «Территория» (§3.5): опц. opts — множители зданий клуба игрока
 * (training L → xpMult, medical L → injuryRiskMult); без opts — как раньше
 * (обратная совместимость, ИИ-клубы тренируются без множителей).
 *
 * Модуль 4: opts.individual — индивидуальные программы (перезаписывают
 * командный фокус/интенсивность только этому игроку); opts.youthXpMult —
 * множитель ассистента для ≤23; opts.catMult — специализации тренеров
 * (категорийные множители XP). Все опции аддитивны и не меняют поведение
 * при отсутствии (легаси-вызовы без М4-опций детерминированы как раньше).
 */
export function applyWeeklyTraining(
  rng: RNG,
  focus: TrainingFocus,
  intensity: TrainingIntensity,
  players: PlayerLike[],
  opts?: {
    xpMult?: number;
    injuryRiskMult?: number;
    /** Модуль 4: индивидуальные программы (focus/intensity игрока). */
    individual?: (p: PlayerLike) => IndividualTraining | null;
    /** Модуль 4: XP-множитель для молодых (ассистент). */
    youthXpMult?: number;
    /** Модуль 4: категорийные множители XP (специализации тренеров). */
    catMult?: CategoryMult;
  },
): TrainingReport {
  const notes: string[] = [];
  const injuries: TrainingReport['injuries'] = [];
  const xpMult = opts?.xpMult ?? 1;
  const injuryRiskMult = opts?.injuryRiskMult ?? 1;
  const youthXpMult = opts?.youthXpMult ?? 1;
  const catMult = opts?.catMult ?? { tech: 1, mental: 1, phys: 1, gk: 1 };

  for (const p of players) {
    // Модуль 4: эффективные фокус/интенсивность (индивидуальная программа
    // переопределяет командную только для этого игрока)
    const own = opts?.individual?.(p) ?? null;
    const effFocus = own?.focus ?? focus;
    const effIntensity = own?.intensity ?? intensity;
    const intensityFactor = TRAIN_INTENSITY_FACTOR[effIntensity];

    // Отдых: восстановление всей команды
    if (effFocus === 'rest') {
      p.condition = clamp(p.condition + TRAIN_REST_COND, CONDITION_MIN, CONDITION_MAX);
      p.morale = clamp(p.morale + TRAIN_REST_MORALE, MORALE_MIN, MORALE_MAX);
      continue;
    }

    // Состояние от интенсивности (травмированным тоже — они «под наблюдением»)
    p.condition = clamp(
      p.condition + TRAIN_CONDITION_DELTA[effIntensity],
      CONDITION_MIN,
      CONDITION_MAX,
    );

    // Травмированный не тренируется (но риск новых травм не проверяем)
    if (p.injuryWeeks > 0) continue;

    // Травма от тренировки (риск ×2 при condition < 60; D-5: × medical-множитель)
    const riskMult = p.condition < 60 ? TRAIN_INJURY_COND_MULT : 1;
    if (rng() < TRAIN_INJURY_RISK[effIntensity] * riskMult * injuryRiskMult) {
      const weeks = randInt(rng, TRAIN_INJURY_WEEKS[0], TRAIN_INJURY_WEEKS[1]);
      p.injuryWeeks = weeks;
      injuries.push({ playerId: p.id, playerName: `${p.firstName} ${p.lastName}`, weeks });
      continue;
    }

    const attrs = attrsForPlayer(p, effFocus);
    const isGk = p.position === 'GK';

    // ── Модуль 2: УНИВЕРСАЛЬНАЯ конвертация накопленного xp (вкл. матчёвый) ──
    // Любой атрибут с xp ≥ 1.0 растёт на +1 (жёсткий потолок potential).
    // Без бросков rng и в детерминированном порядке ключей — движение xp от
    // матчей (development.applyMatchDevelopment) превращается в рост здесь.
    const xp = parseTrainingXp(p.trainingXp);
    let grown = false;
    const accumulated = (Object.keys(xp) as AttrKey[])
      .filter((k) => ATTR_LABELS[k] !== undefined)
      .sort();
    for (const attr of accumulated) {
      let guard = 0;
      while (xp[attr] !== undefined && xp[attr] >= 1.0 && guard < 10) {
        const before = p[attr];
        const tentative = { ...p, [attr]: p[attr] + 1 } as PlayerLike;
        if (computeOvr(tentative, p.position) > p.potential) {
          xp[attr] = Math.min(xp[attr], TRAIN_XP_CAP); // заморозка у потолка
          break;
        }
        p[attr] = p[attr] + 1;
        xp[attr] = (xp[attr] ?? 0) - 1;
        grown = true;
        if (notes.length < TRAIN_NOTES_MAX) {
          notes.push(`${p.firstName} ${p.lastName} +1 ${ATTR_LABELS[attr]} (${before}→${p[attr]})`);
        }
        guard++;
      }
    }

    if (attrs.length === 0) {
      // фокуса нет (Вратари для полевого / rest уже обработан) — только конвертация
      for (const key of Object.keys(xp)) {
        if (xp[key] <= 0) delete xp[key];
      }
      p.trainingXp = Object.keys(xp).length > 0 ? JSON.stringify(xp) : null;
      if (grown) refreshEconomy(p);
      continue;
    }

    // GK-множитель: фокус «Вратари» → ×1.0, иной фокус → ×0.5 (только для вратаря)
    const gkMult = isGk ? (effFocus === 'goalkeepers' ? 1.0 : 0.5) : 1.0;
    // Модуль 4: молодым — множитель ассистента; категориям — специализации тренеров
    const youthMult = p.age <= 23 ? youthXpMult : 1;

    for (const attr of attrs) {
      // U — отдельный бросок на игрока × атрибут × неделю; D-5: × training-множитель.
      // Модуль 2: кривая роста — покатегорийная (физика раньше плато, ментальные дольше)
      const u = 0.5 + rng() * 1.0;
      const g =
        TRAIN_BASE * intensityFactor * growthMultOf(attrCategoryOf(attr), p.age, isGk)
        * headroomOf(p) * u * gkMult * xpMult * youthMult
        * (catMult[attrCategoryOf(attr)] ?? 1);
      xp[attr] = (xp[attr] ?? 0) + g;

      // Цикл +1 при переполнении, с жёстким потолком potential
      let guard = 0;
      while (xp[attr] !== undefined && xp[attr] >= 1.0 && guard < 10) {
        const before = p[attr];
        const tentative = { ...p, [attr]: p[attr] + 1 } as PlayerLike;
        if (computeOvr(tentative, p.position) > p.potential) {
          xp[attr] = Math.min(xp[attr], TRAIN_XP_CAP); // заморозка у потолка
          break;
        }
        p[attr] = p[attr] + 1;
        xp[attr] = (xp[attr] ?? 0) - 1;
        grown = true;
        if (notes.length < TRAIN_NOTES_MAX) {
          notes.push(
            `${p.firstName} ${p.lastName} +1 ${ATTR_LABELS[attr]} (${before}→${p[attr]})`,
          );
        }
        guard++;
      }
    }

    // только накапливаемые ключи
    for (const key of Object.keys(xp)) {
      if (xp[key] <= 0) delete xp[key];
    }
    p.trainingXp = Object.keys(xp).length > 0 ? JSON.stringify(xp) : null;

    if (grown) refreshEconomy(p); // ovr + value + salary пересчитаны
  }

  return { notes, injuries };
}

/**
 * Автовыбор ИИ: focus = argmin средних по линиям (attack/defense/possession
 * атрибутов полевых); intensity: 'hard', если очки команды > 8 позади первого
 * безопасного места (N−3); 'light', если среднее condition состава < 55;
 * иначе 'normal'.
 */
export function aiTrainingChoice(rng: RNG, args: {
  players: PlayerLike[];
  place: number;
  safeGapPoints: number;
}): { focus: TrainingFocus; intensity: TrainingIntensity } {
  const { players, place, safeGapPoints } = args;
  const field = players.filter((p) => p.position !== 'GK');
  if (field.length === 0) return { focus: 'goalkeepers', intensity: 'normal' };

  const avg = (pick: (p: PlayerLike) => number): number =>
    field.reduce((s, p) => s + pick(p), 0) / field.length;

  const lines: { focus: TrainingFocus; value: number }[] = [
    { focus: 'attack', value: avg((p) => (p.finishing + p.dribbling + p.crossing + p.pace) / 4) },
    { focus: 'defense', value: avg((p) => (p.tackling + p.marking + p.positioning + p.heading) / 4) },
    { focus: 'possession', value: avg((p) => (p.passing + p.dribbling + p.positioning + p.aggression) / 4) },
    { focus: 'physical', value: avg((p) => (p.pace + p.stamina + p.strength) / 3) },
  ];
  lines.sort((a, b) => a.value - b.value);
  const focus = lines[0].focus;

  let intensity: TrainingIntensity = 'normal';
  if (safeGapPoints > 8 && place > 3) {
    intensity = 'hard';
  } else {
    const avgCondition = players.reduce((s, p) => s + p.condition, 0) / Math.max(1, players.length);
    if (avgCondition < 55) intensity = 'light';
  }
  // немного разнообразия
  if (intensity === 'normal' && rng() < 0.15) intensity = 'light';
  return { focus, intensity };
}

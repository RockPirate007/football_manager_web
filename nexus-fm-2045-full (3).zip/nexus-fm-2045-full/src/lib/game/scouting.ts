/**
 * Модуль 3 «Скаутинг и туман войны»: чистые функции знаний о чужих игроках
 * (ScoutReport.knowledge 0..100). Контракт уровней (§ схемы Prisma):
 *   0..39  — только OVR-вилка ±8 (атрибуты скрыты, потенциал «талант-вилка»);
 *   40..69 — атрибуты-оценки ±6, OVR ±2, потенциал-вилка ±6;
 *   70..100 — точные атрибуты и OVR, потенциал ±2.
 * Знания деградируют −2/нед после 26 недель без наблюдения (watched=false).
 *
 * Детерминизм: оценки атрибутов/вилки — производные seeded RNG на
 * (saveId, playerId, week) — в течение недели все запросы дают одинаковые
 * оценки (никакого «мигания» чисел при перезаходе на экран).
 */

import { ATTR_KEYS, computeSalary, type PlayerLike } from './players';
import { clamp, hashString, mulberry32, type RNG } from './rng';

/** Уровень знания для UI-подписей. */
export type KnowledgeTier = 'none' | 'basic' | 'partial' | 'full';

export const KNOWLEDGE_FULL = 70;
export const KNOWLEDGE_PARTIAL = 40;

export function knowledgeTierOf(knowledge: number): KnowledgeTier {
  if (knowledge >= KNOWLEDGE_FULL) return 'full';
  if (knowledge >= KNOWLEDGE_PARTIAL) return 'partial';
  if (knowledge > 0) return 'basic';
  return 'none';
}

export const KNOWLEDGE_TIER_LABELS: Record<KnowledgeTier, string> = {
  none: 'не изучен',
  basic: 'беглый взгляд',
  partial: 'изучается',
  full: 'досье',
};

/** Прирост знания за неделю активного наблюдения. 45-й скаут ≈ 8.25, 85-й ≈ 10.25. */
export function knowledgeGrowthOf(bestScoutRating: number | null): number {
  const rating = bestScoutRating ?? 45; // без скаутов в штате — «глаз» клуба
  return 5 + rating / 20;
}

/** Деградация знаний (не наблюдается): −2/нед, но не раньше 26 недель простоя. */
export const SCOUT_DECAY_DELAY = 26;
export const SCOUT_DECAY_PER_WEEK = 2;

/**
 * Еженедельный шаг одного отчёта: watched → рост (+ lastWeek=week);
 * пауза > 26 недель → деградация. Возвращает новые knowledge/lastWeek
 * (мутации применяет вызывающий) и true, если отчёт ещё жив (знание > 0).
 */
export function stepScoutReport(args: {
  knowledge: number;
  lastWeek: number;
  watched: boolean;
  week: number;
  growth: number;
}): { knowledge: number; lastWeek: number; alive: boolean } {
  const { knowledge, lastWeek, watched, week, growth } = args;
  if (watched) {
    return { knowledge: clamp(Math.round(knowledge + growth), 0, 100), lastWeek: week, alive: true };
  }
  const idle = week - lastWeek;
  if (idle > SCOUT_DECAY_DELAY) {
    const next = knowledge - SCOUT_DECAY_PER_WEEK;
    return { knowledge: next, lastWeek, alive: next > 0 };
  }
  return { knowledge, lastWeek, alive: true };
}

/**
 * Слоты наблюдения клуба: 2 базовых + 2 за каждого скаута штата (Модуль 4 найм)
 * + бонус скаут-центра (Модуль 5: L3 +1 · L5 +2 — здания расширяют сеть).
 * buildingBonus = scoutSlotsBonus(level) из engine/buildings — отдельный параметр,
 * чтобы lib/game не зависел от каталога (чистая функция, дефолт 0 — легаси).
 */
export const SCOUT_SLOTS_BASE = 2;
export const SCOUT_SLOTS_PER_STAFF = 2;

export function scoutSlotsOf(staffCount: number, buildingBonus = 0): number {
  return SCOUT_SLOTS_BASE + SCOUT_SLOTS_PER_STAFF * Math.max(0, staffCount) + Math.max(0, buildingBonus);
}

// ── Туман войны: производные оценки ────────────────────────────────────────

/** Зерно стабильных оценок недели: одинаковые числа всю неделю. */
export function scoutSeedOf(saveId: string, playerId: string, week: number): number {
  return hashString(`${saveId}:fog:${playerId}:${week}`);
}

/** Детерминированная «оценка» значения с шумом ±maxNoise. */
function fuzzOf(rng: RNG, value: number, maxNoise: number): number {
  if (maxNoise <= 0) return value;
  const noise = Math.round((rng() * 2 - 1) * maxNoise);
  return clamp(value + noise, 1, 99);
}

/** Шум OVR по уровню знания: <40 → ±8, 40..69 → ±2, ≥70 → 0. */
export function ovrNoiseOf(knowledge: number): number {
  const tier = knowledgeTierOf(knowledge);
  if (tier === 'full') return 0;
  if (tier === 'partial') return 2;
  return 8;
}

/** Шум атрибутов: <40 → скрыты (заполняется 0), 40..69 → ±6, ≥70 → 0. */
export function attrNoiseOf(knowledge: number): number {
  const tier = knowledgeTierOf(knowledge);
  if (tier === 'full') return 0;
  if (tier === 'partial') return 6;
  return 0;
}

/** Вилка потенциала по знанию: full → ±2, partial → ±6, basic → «талант-вилка». */
export function potentialRangeOf(potential: number, ovr: number, knowledge: number): [number, number] {
  const tier = knowledgeTierOf(knowledge);
  if (tier === 'full') return [potential - 2, potential + 2];
  if (tier === 'partial') {
    return [Math.max(ovr, potential - 6), potential + 6];
  }
  // basic: широкий диапазон от текущего OVR до потолка-«на глаз» (потолок скрыт,
  // но вилка монотонно связана с ним, чтобы UI не врал направленно)
  return [ovr, potential + 12];
}

export interface FoggedAttrs {
  /** Оценки атрибутов (0 = «скрыто», UI рисует «?»). */
  attrs: Record<string, number>;
  /** Оценка OVR. */
  ovr: number;
}

/**
 * Оценочная (туманная) версия полевых/вратарских атрибутов и OVR игрока.
 * Вызывается ТОЛЬКО для чужих игроков (свой состав — знание 100).
 */
export function fogOfWar(args: {
  rng: RNG;
  player: PlayerLike;
  knowledge: number;
}): FoggedAttrs {
  const { rng, player, knowledge } = args;
  const tier = knowledgeTierOf(knowledge);
  const ovrNoise = ovrNoiseOf(knowledge);
  const attrNoise = attrNoiseOf(knowledge);

  const attrs: Record<string, number> = {};
  for (const key of ATTR_KEYS) {
    const real = (player as unknown as Record<string, number>)[key] ?? 50;
    attrs[key] = tier === 'basic' ? 0 : fuzzOf(rng, real, attrNoise);
  }
  return { attrs, ovr: fuzzOf(rng, player.ovr, ovrNoise) };
}

// ── Контракт: зарплатный спрос неизвестен без знания ───────────────────────

/**
 * Оценка зарплатного спроса при подписании (для UI-подсказки и встречных
 * предложений): точность зависит от знания (недопроскаутленному агенту можно
 * «предложить меньше» — риск отказа выше, раскрытие в negotiation.ts).
 */
export function salaryAskHintOf(player: PlayerLike, knowledge: number, seed: number): number {
  const nominal = computeSalary(player.value);
  const rng = mulberry32(seed);
  const noise = knowledge >= KNOWLEDGE_FULL ? 0 : knowledge >= KNOWLEDGE_PARTIAL ? 0.1 : 0.25;
  const factor = 1 + (rng() * 2 - 1) * noise;
  return Math.round(nominal * factor);
}

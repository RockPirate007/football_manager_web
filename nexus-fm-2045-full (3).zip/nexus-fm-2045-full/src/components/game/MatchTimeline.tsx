'use client';

import { Fragment, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeftRight, Bandage, CircleDot, CornerUpRight, Flag, Goal, Hand, MoveHorizontal, Square, Swords, X, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { MatchEvent, MatchEventType } from '@/lib/game/types';

const TYPE_LABEL: Record<MatchEventType, string> = {
  kickoff: 'Начало матча',
  goal: 'Гол',
  yellow: 'Жёлтая карточка',
  red: 'Красная карточка',
  injury: 'Травма',
  chance: 'Опасный момент',
  pen_goal: 'Гол с пенальти',
  pen_miss: 'Промах с пенальти',
  pen_save: 'Сейв с пенальти',
  halftime: 'Перерыв',
  fulltime: 'Финальный свисток',
  sub: 'Замена',
  // ── Engine 2.0 ──
  shot_on: 'Удар в створ',
  shot_off: 'Удар мимо',
  save: 'Сейв',
  corner: 'Угловой',
  offside: 'Офсайд',
  duel: 'Единоборство',
  momentum: 'Ход игры',
};

function EventIcon({ type }: { type: MatchEventType }) {
  switch (type) {
    case 'goal':
      return <Goal className="size-4 text-[#22C55E]" aria-hidden />;
    case 'pen_goal':
      return <Goal className="size-4 text-[#22C55E]" aria-hidden />;
    case 'pen_save':
      return <Hand className="size-4 text-[#FACC15]" aria-hidden />;
    case 'pen_miss':
      return <X className="size-4 text-[#EF4444]" aria-hidden />;
    case 'yellow':
      return <Square className="size-3.5 fill-[#FACC15] text-[#FACC15]" aria-hidden />;
    case 'red':
      return <Square className="size-3.5 fill-[#EF4444] text-[#EF4444]" aria-hidden />;
    case 'injury':
      return <Bandage className="size-4 text-[#EF4444]" aria-hidden />;
    case 'sub':
      // Замена — «серое» событие без влияния на счёт (§7.1 ТЗ Фазы 4)
      return <ArrowLeftRight className="size-4 text-muted-foreground" aria-hidden />;
    case 'chance':
      return <Zap className="size-4 text-[#FACC15]" aria-hidden />;
    case 'shot_on':
      return <Zap className="size-4 text-[#00D4FF]" aria-hidden />;
    case 'shot_off':
      return <X className="size-4 text-muted-foreground" aria-hidden />;
    case 'save':
      return <Hand className="size-4 text-[#FACC15]" aria-hidden />;
    case 'corner':
      return <CornerUpRight className="size-4 text-[#00D4FF]" aria-hidden />;
    case 'offside':
      return <MoveHorizontal className="size-4 text-muted-foreground" aria-hidden />;
    case 'duel':
      return <Swords className="size-4 text-[#A78BFA]" aria-hidden />;
    case 'momentum':
      return <CircleDot className="size-4 text-[#FF6B35]" aria-hidden />;
    case 'halftime':
      return <Flag className="size-4 text-muted-foreground" aria-hidden />;
    case 'fulltime':
      return <Flag className="size-4 text-primary" aria-hidden />;
    default:
      return <CircleDot className="size-4 text-muted-foreground" aria-hidden />;
  }
}

/** Лента событий матча с анимацией появления и автоскроллом. */
export function MatchTimeline({
  events,
  homeTeamId,
  homeShort,
  awayShort,
  autoScroll = true,
  className,
}: {
  events: MatchEvent[];
  homeTeamId: string;
  homeShort: string;
  awayShort: string;
  autoScroll?: boolean;
  className?: string;
}) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll) bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [events.length, autoScroll]);

  return (
    <div className={cn('scroll-thin overflow-y-auto', className)} role="log" aria-live="polite">
      <ul className="space-y-1.5 p-1">
        <AnimatePresence initial={false}>
          {events.map((e, i) => {
            const isFrame =
              e.type === 'kickoff' || e.type === 'halftime' || e.type === 'fulltime';
            const isHome = e.teamId === homeTeamId;

            if (isFrame) {
              return (
                <motion.li
                  key={`${e.type}-${i}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2 py-1"
                >
                  <span className="h-px flex-1 bg-border/60" aria-hidden />
                  <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    <EventIcon type={e.type} />
                    {TYPE_LABEL[e.type]}
                  </span>
                  <span className="h-px flex-1 bg-border/60" aria-hidden />
                </motion.li>
              );
            }

            // Разделитель «Серия пенальти» перед первым пенальти-событием.
            const isPen = e.type === 'pen_goal' || e.type === 'pen_miss' || e.type === 'pen_save';
            const prev = i > 0 ? events[i - 1] : null;
            const prevIsPen =
              prev !== null &&
              (prev.type === 'pen_goal' || prev.type === 'pen_miss' || prev.type === 'pen_save');

            return (
              <Fragment key={`ev-group-${i}`}>
                {isPen && !prevIsPen ? (
                  <motion.li
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-2 py-1"
                  >
                    <span className="h-px flex-1 bg-[#EAB308]/50" aria-hidden />
                    <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-[#EAB308]">
                      <Goal className="size-3.5" aria-hidden />
                      Серия пенальти
                    </span>
                    <span className="h-px flex-1 bg-[#EAB308]/50" aria-hidden />
                  </motion.li>
                ) : null}
                <motion.li
                  key={`${e.type}-${e.minute}-${i}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={cn(
                    'flex items-center gap-2.5 rounded-md border border-border/50 bg-card/80 p-2.5',
                    (e.type === 'goal' || e.type === 'pen_goal') && 'border-[#22C55E]/40 bg-[#22C55E]/8',
                    e.type === 'pen_miss' && 'border-[#EF4444]/40',
                    e.type === 'pen_save' && 'border-[#FACC15]/40',
                  )}
                >
                  <span className="w-9 shrink-0 text-center text-xs font-bold tabular text-muted-foreground">
                    {e.minute > 93 ? 'П' : `${e.minute}'`}
                  </span>
                  <span className="shrink-0">
                    <EventIcon type={e.type} />
                  </span>
                  <span
                    className={cn(
                      'min-w-0 flex-1 text-xs leading-relaxed',
                      (e.type === 'goal' || e.type === 'pen_goal') && 'font-semibold',
                    )}
                  >
                    {e.text}
                  </span>
                  {e.teamId ? (
                    <span
                      className={cn(
                        'shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold',
                        isHome ? 'bg-primary/15 text-primary' : 'bg-secondary text-muted-foreground',
                      )}
                    >
                      {isHome ? homeShort : awayShort}
                    </span>
                  ) : null}
                </motion.li>
              </Fragment>
            );
          })}
        </AnimatePresence>
        <div ref={bottomRef} aria-hidden />
      </ul>
    </div>
  );
}

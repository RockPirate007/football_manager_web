/**
 * Калибровка ENGINE 2.0: распределения голов/владения/ударов на синтетике.
 * Запуск: bun scripts/engine2_calibrate.ts
 */

import { simulateMatchV2 } from '../src/lib/game/engine2/MatchEngine';
import { mulberry32, hashString } from '../src/lib/game/rng';
import type { MatchInput2 } from '../src/lib/game/engine2/MatchEngine';
import type { PlayerLike } from '../src/lib/game/players';
import type { Attributes } from '../src/lib/game/types';

/** Синтетический состав: base-атрибуты ± профиль по позиции. */
function mkPlayer(id: string, pos: string, base: number, jersey: number): PlayerLike {
  const a = (k: keyof Attributes, adj = 0) => Math.max(1, Math.min(99, Math.round(base + adj)));
  const isGK = pos === 'GK';
  const striker = pos === 'ST' || pos.startsWith('AM');
  const defender = pos.startsWith('D') && !pos.startsWith('DM');
  return {
    id, teamId: null, firstName: 'Игрок', lastName: `№${jersey}`, nationality: 'RU',
    position: pos as PlayerLike['position'], shirtNumber: jersey, age: 25,
    potential: base + 5, ovr: base,
    morale: 60, condition: 100, injuryWeeks: 0, value: 0, salary: 0,
    goals: 0, assists: 0, apps: 0, yellowCards: 0, redCards: 0,
    cleanSheets: 0, cupGoals: 0, cupAssists: 0, euroGoals: 0, euroAssists: 0,
    contractUntil: 4, preContractTeamId: null, ratingSum: 0, ratingApps: 0, isAcademy: false,
    finishing: isGK ? a('finishing', -30) : a('finishing', striker ? 10 : defender ? -15 : 0),
    passing: a('passing', defender ? -5 : 2),
    dribbling: isGK ? a('dribbling', -35) : a('dribbling', striker ? 8 : defender ? -10 : 0),
    crossing: isGK ? a('crossing', -30) : a('crossing', pos.endsWith('L') || pos.endsWith('R') ? 6 : -4),
    tackling: isGK ? a('tackling', -30) : a('tackling', defender ? 10 : striker ? -12 : 0),
    marking: isGK ? a('marking', -30) : a('marking', defender ? 10 : striker ? -12 : 0),
    positioning: a('positioning', defender ? 5 : 0),
    heading: a('heading', defender || striker ? 5 : -3),
    pace: a('pace', 3), stamina: a('stamina', 2), strength: a('strength', defender ? 5 : 0),
    aggression: a('aggression', defender ? 8 : 0),
    vision: a('vision', striker ? 3 : 0), decisions: a('decisions', 2), leadership: a('leadership', 0),
    acceleration: a('acceleration', 2), jumping: a('jumping', defender || striker ? 4 : -2),
    reflexes: isGK ? a('reflexes', 12) : a('reflexes', -35),
    rushingOut: isGK ? a('rushingOut', 8) : a('rushingOut', -35),
    kicking: isGK ? a('kicking', 5) : a('kicking', -10),
    handling: isGK ? a('handling', 12) : a('handling', -35),
    injuryProneness: 45, consistency: 60,
  } as PlayerLike;
}

function mkTeam(teamId: string, base: number): MatchInput2 {
  const order = ['GK', 'DL', 'DC', 'DC', 'DR', 'ML', 'MC', 'MC', 'MR', 'ST', 'ST'];
  const players = order.map((pos, i) => mkPlayer(`${teamId}-p${i}`, pos, base, i + 1));
  // 8 запасных
  const benchOrder = ['GK', 'DC', 'DL', 'MC', 'MC', 'MR', 'AMR', 'ST'];
  benchOrder.forEach((pos, i) => players.push(mkPlayer(`${teamId}-b${i}`, pos, base - 8, 20 + i)));
  return {
    teamId,
    name: `Клуб-${base}`,
    players,
    formation: '4-4-2',
    mentality: 'balanced',
    tempo: 'medium',
    pressing: 'medium',
    defLine: 'medium',
    playStyle: 'balanced',
    width: 'normal',
    lineup: players.slice(0, 11).map((p) => p.id),
    bench: players.slice(11).map((p) => p.id),
  };
}

interface Agg {
  total: number; homeWin: number; draw: number; awayWin: number;
  goals: number; hGoals: number; aGoals: number;
  hShots: number; aShots: number; hSot: number; aSot: number;
  poss: number; events: number; corners: number; yellows: number; reds: number;
  maxGoals: number; blank: number; subs: number; injuries: number;
}

function run(label: string, home: MatchInput2, away: MatchInput2, n: number, neutral = false): Agg {
  const agg: Agg = {
    total: 0, homeWin: 0, draw: 0, awayWin: 0, goals: 0, hGoals: 0, aGoals: 0,
    hShots: 0, aShots: 0, hSot: 0, aSot: 0, poss: 0, events: 0, corners: 0,
    yellows: 0, reds: 0, maxGoals: 0, blank: 0, subs: 0, injuries: 0,
  };
  let firstEvents: string[] = [];
  for (let i = 0; i < n; i++) {
    const rng = mulberry32(hashString(`cal:${label}:${i}`));
    const r = simulateMatchV2(rng, home, away, { neutral });
    agg.total += 1;
    const g = r.homeGoals + r.awayGoals;
    agg.goals += g;
    agg.maxGoals = Math.max(agg.maxGoals, g);
    if (r.homeGoals > r.awayGoals) agg.homeWin += 1;
    else if (r.homeGoals === r.awayGoals) agg.draw += 1;
    else agg.awayWin += 1;
    if (g === 0) agg.blank += 1;
    agg.hGoals += r.homeGoals;
    agg.aGoals += r.awayGoals;
    agg.hShots += r.stats.shotsHome;
    agg.aShots += r.stats.shotsAway;
    agg.hSot += r.stats.sotHome;
    agg.aSot += r.stats.sotAway;
    agg.poss += r.stats.possessionHome;
    agg.events += r.events.length;
    agg.corners += r.stats.cornersHome + r.stats.cornersAway;
    agg.yellows += r.stats.yellowsHome + r.stats.yellowsAway;
    agg.reds += r.stats.redsHome + r.stats.redsAway;
    agg.subs += r.homeSubs.length + r.awaySubs.length;
    agg.injuries += r.injuries.length;
    if (i === 0) {
      firstEvents = r.events.map((e) => `${e.minute}' [${e.type}] ${e.text}`);
    }
  }
  const p = (x: number) => (x / n).toFixed(2);
  console.log(`\n=== ${label} (n=${n}${neutral ? ', нейтральное' : ''}) ===`);
  console.log(`Голы: тотал ${p(agg.goals)} | ${p(agg.hGoals)}:${p(agg.aGoals)} | макс=${agg.maxGoals} | сухих=${agg.blank}`);
  console.log(`W/D/L (дом/ничья/гости): ${p(agg.homeWin * 100)}% / ${p(agg.draw * 100)}% / ${p(agg.awayWin * 100)}%`);
  console.log(`Удары: ${p(agg.hShots)}:${p(agg.aShots)} | в створ: ${p(agg.hSot)}:${p(agg.aSot)}`);
  console.log(`Владение дом: ${p(agg.poss)}% | события: ${p(agg.events)} | угловые: ${p(agg.corners / 2)}`);
  console.log(`Жёлтые: ${p(agg.yellows / 2)} | красные: ${((agg.reds / n) * 100).toFixed(2)}% | замены: ${p(agg.subs / 2)} | травмы: ${(agg.injuries / n).toFixed(3)}`);
  if (firstEvents.length > 0) {
    console.log('--- Первый матч (первые 25 событий) ---');
    for (const e of firstEvents.slice(0, 25)) console.log(e);
  }
  return agg;
}

// ── Сценарии ──────────────────────────────────────────────────────────────
const t40 = mkTeam('A', 40);
const t60 = mkTeam('B', 60);
const t80 = mkTeam('C', 80);
const t80w = mkTeam('D', 80);
const t80high = { ...t80w, tempo: 'high' as const, pressing: 'high' as const, playStyle: 'gegenpress' as never };
const t60bus = { ...t60, mentality: 'defensive' as const, playStyle: 'counter' as never };
const t60wing = { ...t60, playStyle: 'wing' as never, width: 'wide' as const };

run('равные 60-60', t60, { ...mkTeam('B2', 60) }, 2000);
run('равные 80-80', t80, t80w, 2000);
run('80 дом vs 40', t80, t40, 1000);
run('40 дом vs 80', t40, t80, 1000);
run('нейтрально 60-60', t60, { ...mkTeam('B3', 60) }, 1000, true);
run('60 высокий темп+прессинг vs 80', t80high, t80, 500);
run('60 автобус+контра vs 80', t60bus, t80, 500);
run('60 фланги vs 60', t60wing, { ...mkTeam('B4', 60) }, 500);

// Детерминизм
{
  const r1 = simulateMatchV2(mulberry32(12345), t60, t80);
  const r2 = simulateMatchV2(mulberry32(12345), t60, t80);
  const same =
    r1.homeGoals === r2.homeGoals &&
    r1.awayGoals === r2.awayGoals &&
    r1.events.length === r2.events.length &&
    r1.events.every((e, i) => e.minute === r2.events[i].minute && e.type === r2.events[i].type);
  console.log(`\nДетерминизм (seed 12345): ${same ? 'OK' : 'FAIL'}`);
}

// Производительность
{
  const t0 = Date.now();
  for (let i = 0; i < 500; i++) {
    simulateMatchV2(mulberry32(hashString(`perf:${i}`)), t60, t80);
  }
  const ms = (Date.now() - t0) / 500;
  console.log(`Производительность: ${ms.toFixed(2)} мс/матч`);
}

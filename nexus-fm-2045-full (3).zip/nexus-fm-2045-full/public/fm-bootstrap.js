/**
 * D-9 (спека §7.1 + §2.2): шим глобала NL_APPDATA + compat filesystem.removeFile.
 *
 * 1) В Neutralino v6.9.0 НЕТ глобала NL_APPDATA (проверено по исходникам
 *    neutralino v6.9.0: settings::getGlobalVars() инжектит NL_PATH и NL_DATAPATH,
 *    но не NL_APPDATA). Движок (src/engine/storage.ts) читает NL_APPDATA для
 *    каталога сейвов и при его отсутствии падает в CWD-зависимый './saves'.
 *    При dataLocation: "system" глобал NL_DATAPATH = %APPDATA%\ru.fm.desktop
 *    (Windows) / ~/.local/share/ru.fm.desktop (Linux) — проксируем его в
 *    NL_APPDATA, не трогая QA-пройденный движок.
 *
 * 2) Compat: Neutralino v6 заменил filesystem.removeFile на filesystem.remove;
 *    NeutralinoStorage.remove() вызывает старое имя. Патчим инжектированную
 *    инстанцию либы (injectScript выполняется ПОСЛЕ injectClientLibrary,
 *    порядок гарантирует api/window/window.cpp::__createWindow).
 *
 * Файл подключается modes.window.injectScript конфига Neutralino и выполняется
 * ДО скриптов страницы. В браузере не подключается (нет ссылки из HTML) —
 * код инертен.
 */
(function () {
  'use strict';
  if (typeof window === 'undefined') return;

  // (1) NL_APPDATA-шим: движок storage.ts читает глобал NL_APPDATA.
  if (window.NL_APPDATA === undefined &&
      typeof NL_DATAPATH !== 'undefined' && NL_DATAPATH) {
    window.NL_APPDATA = NL_DATAPATH;
  }

  // (2) removeFile-compat для инжектированной инстанции Neutralino-клиента
  // (инстанция из <script src="/neutralino.js"> патчится хвостом самого файла).
  var fs = window.Neutralino && window.Neutralino.filesystem;
  if (fs && !fs.removeFile && fs.remove) {
    fs.removeFile = function (path) { return fs.remove(path); };
  }
})();

/**
 * Проверки БД для смоук-теста Фазы 3 (scripts/smoke_phase3.sh).
 * Запуск: bun scripts/phase3_db_check.ts <команда> <saveId> [аргументы]
 * Вывод: строки «ключ=значение» для сопоставления в bash.
 * Отдельный тихий Prisma-клиент (без query-логов dev-клиента src/lib/db).
 */
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient({ log: [] });

/** Набор недели 4 сезона S: воспитанники с контрактом до S+2, 16–17 лет. */
async function academy(saveId: string, season: number) {
  const intake = await db.player.findMany({
    where: { saveId, isAcademy: true, contractUntil: season + 2 },
    select: { age: true, ovr: true, potential: true, teamId: true, position: true },
  });
  const agesOk = intake.every((p) => p.age === 16 || p.age === 17);
  const ovrOk = intake.every((p) => p.ovr >= 34 && p.ovr <= 52);
  const withTeam = intake.filter((p) => p.teamId !== null).length;
  const maxPot = intake.reduce((m, p) => Math.max(m, p.potential), 0);
  console.log(`academy_intake_count=${intake.length}`);
  console.log(`academy_ages_ok=${agesOk}`);
  console.log(`academy_ovr_ok=${ovrOk}`);
  console.log(`academy_with_team=${withTeam}`);
  console.log(`academy_max_pot=${maxPot}`);
}

/** Снапшот PlayerSeasonRecord сезона: объём, голы, рейтинги. */
async function seasonSnapshot(saveId: string, season: number) {
  const rows = await db.playerSeasonRecord.findMany({
    where: { saveId, season },
    select: { goals: true, apps: true, avgRating: true, teamName: true },
  });
  const totalGoals = rows.reduce((s, r) => s + r.goals, 0);
  const totalApps = rows.reduce((s, r) => s + r.apps, 0);
  const played = rows.filter((r) => r.apps > 0 && r.avgRating > 0);
  const avgRating = played.length > 0
    ? played.reduce((s, r) => s + r.avgRating, 0) / played.length / 10
    : 0;
  console.log(`records=${rows.length}`);
  console.log(`records_goals=${totalGoals}`);
  console.log(`records_apps=${totalApps}`);
  console.log(`records_avg_rating=${avgRating.toFixed(2)}`);
  console.log(`records_free_agent_named=${rows.filter((r) => r.teamName === 'Свободный агент').length}`);
}

/** После перехода: сезонная статистика всех клубных игроков обнулена. */
async function statsReset(saveId: string) {
  const notReset = await db.player.count({
    where: {
      saveId,
      teamId: { not: null },
      OR: [{ goals: { not: 0 } }, { apps: { not: 0 } }, { ratingApps: { not: 0 } }],
    },
  });
  console.log(`stats_not_reset=${notReset}`);
}

/** Контракты: free-листинги, свободные агенты, предконтракты, составы. */
async function contracts(saveId: string) {
  const free = await db.transferListing.count({
    where: { saveId, source: 'free', status: 'active' },
  });
  const freePlayers = await db.player.count({ where: { saveId, teamId: null } });
  const precontract = await db.player.count({
    where: { saveId, preContractTeamId: { not: null } },
  });
  const inTeams = await db.player.count({ where: { saveId, teamId: { not: null } } });
  console.log(`free_listings=${free}`);
  console.log(`free_players=${freePlayers}`);
  console.log(`precontracts=${precontract}`);
  console.log(`players_in_teams=${inTeams}`);
}

/** Guard состава ИИ: минимальный размер и число клубов ниже 15. */
async function aiSquads(saveId: string) {
  const teams = await db.team.findMany({
    where: { saveId, isUserTeam: false },
    select: { players: { select: { id: true } } },
  });
  const min = teams.reduce((m, t) => Math.min(m, t.players.length), 99);
  const below15 = teams.filter((t) => t.players.length < 15).length;
  console.log(`ai_min_squad=${min}`);
  console.log(`ai_below_15=${below15}`);
}

/** Список id ВСЕХ игроков сейва (для диффа «до/после перехода» — проверка клонов). */
async function teamPlayerIds(saveId: string) {
  const rows = await db.player.findMany({
    where: { saveId },
    select: { id: true },
  });
  console.log(rows.map((r) => r.id).join(' '));
}

/** Клоны-пенсионеры: клубные игроки, чьих id не было в списке до перехода. */
async function newTeamPlayers(saveId: string, beforeIds: string[]) {
  const rows = await db.player.findMany({
    where: { saveId, teamId: { not: null } },
    select: { id: true, age: true, ovr: true, isAcademy: true },
  });
  const before = new Set(beforeIds);
  const fresh = rows.filter((p) => !before.has(p.id));
  console.log(`new_team_players=${fresh.length}`);
  for (const p of fresh.slice(0, 5)) {
    console.log(`new_player age=${p.age} ovr=${p.ovr} academy=${p.isAcademy}`);
  }
}

/** Поля сейва: сезон/неделя/статус/правление. */
async function saveInfo(saveId: string) {
  const save = await db.gameSave.findUnique({
    where: { id: saveId },
    select: {
      season: true, week: true, status: true, finishReason: true,
      boardTarget: true, boardTargetPlace: true, boardConfidence: true,
      boardWarnings: true, boardLowStreak: true, honeymoonUntilWeek: true,
    },
  });
  if (!save) {
    console.log('save=missing');
    return;
  }
  console.log(`save_season=${save.season}`);
  console.log(`save_week=${save.week}`);
  console.log(`save_status=${save.status}`);
  console.log(`save_finish_reason=${save.finishReason ?? 'null'}`);
  console.log(`save_board_target=${save.boardTarget ?? 'null'}`);
  console.log(`save_board_target_place=${save.boardTargetPlace ?? 'null'}`);
  console.log(`save_board_confidence=${save.boardConfidence}`);
  console.log(`save_board_warnings=${save.boardWarnings}`);
  console.log(`save_board_low_streak=${save.boardLowStreak}`);
  console.log(`save_honeymoon_until=${save.honeymoonUntilWeek ?? 'null'}`);
}

/** Премия правления за перевыполнение (finance record, категория prize). */
async function boardBonus(saveId: string, season: number) {
  const rec = await db.financeRecord.findFirst({
    where: { saveId, season, category: 'prize', description: { contains: 'Премия правления' } },
    select: { amount: true },
  });
  console.log(`board_bonus=${rec ? rec.amount : 0}`);
}

/** Статистика игроков ДО перехода (сравнение с записями снапшота). */
async function preTransitionStats(saveId: string) {
  const rows = await db.player.findMany({
    where: { saveId, teamId: { not: null } },
    select: { goals: true, apps: true, ratingSum: true, ratingApps: true },
  });
  const totalGoals = rows.reduce((s, p) => s + p.goals, 0);
  const totalApps = rows.reduce((s, p) => s + p.apps, 0);
  const rated = rows.filter((p) => p.ratingApps > 0);
  const avgRating = rated.length > 0
    ? rated.reduce((s, p) => s + p.ratingSum / p.ratingApps, 0) / rated.length / 10
    : 0;
  console.log(`players_goals=${totalGoals}`);
  console.log(`players_apps=${totalApps}`);
  console.log(`players_avg_rating=${avgRating.toFixed(2)}`);
  console.log(`players_rated=${rated.length}`);
}

/** Легаси-миграция контрактов: клубные игроки с contractUntil < season. */
async function migration(saveId: string, season: number) {
  const stale = await db.player.count({
    where: { saveId, teamId: { not: null }, contractUntil: { lt: season } },
  });
  console.log(`stale_contracts=${stale}`);
}

/** Всего записей истории сейва (после удаления сейва — 0). */
async function recordsCount(saveId: string) {
  const n = await db.playerSeasonRecord.count({ where: { saveId } });
  console.log(`records_total=${n}`);
}

/** Сумма голов во всех сыгранных матчах сезона (независимый источник для №5). */
async function matchGoals(saveId: string, season: number) {
  const rows = await db.match.findMany({
    where: { saveId, season, status: 'played' },
    select: { homeGoals: true, awayGoals: true },
  });
  const total = rows.reduce((s, m) => s + (m.homeGoals ?? 0) + (m.awayGoals ?? 0), 0);
  console.log(`match_goals=${total}`);
}

/**
 * ДО перехода: строки «id goals apps age» всех игроков сейва → файл для snapshotcheck.
 * Вызывается перед симуляцией финальной недели сезона (неделя добавит матчи —
 * сверка строится на монотонности, а не на равенстве сумм).
 */
async function preIds(saveId: string) {
  const rows = await db.player.findMany({
    where: { saveId },
    select: { id: true, goals: true, apps: true, age: true },
  });
  console.log(rows.map((r) => `${r.id} ${r.goals} ${r.apps} ${r.age}`).join('\n'));
}

/**
 * Инвариант №5 (строгая форма по §1.3/§4.2 ТЗ): снапшот снят ДО старения и ДО
 * сброса статистики. Финальная неделя играется ВНУТРИ того же запроса simulate,
 * что и переход, поэтому проверяем не равенство сумм, а НЕРАВЕНСТВА + порядок:
 *  - у каждого пережившего переход игрока есть запись истории;
 *  - запись.age == возраст ДО перехода (снапшот строго ДО старения, шаг 3 < шаг 6);
 *  - запись.goals ≥ и запись.apps ≥ значений ДО финальной недели (сброс занулил бы);
 *  - записи без игрока в срезе ДО (новички рынка финальной недели) — нулевые.
 * Записи пенсионеров (шаг 6) и дренажа рынка (5d) удаляются каскадом — намеренно
 * (§1.3: история недостижима для UI) — поэтому из сверки исключены.
 */
async function snapshotCheck(saveId: string, season: number, preFile: string) {
  const { readFileSync } = await import('node:fs');
  const pre = readFileSync(preFile, 'utf-8')
    .trim()
    .split(/\n/)
    .filter(Boolean)
    .map((line) => {
      const [id, goals, apps, age] = line.trim().split(/\s+/);
      return { id, goals: Number(goals), apps: Number(apps), age: Number(age) };
    });
  const existing = await db.player.findMany({ where: { saveId }, select: { id: true } });
  const existingIds = new Set(existing.map((p) => p.id));
  const records = await db.playerSeasonRecord.findMany({
    where: { saveId, season },
    select: { playerId: true, goals: true, apps: true, age: true },
  });
  const recordById = new Map(records.map((r) => [r.playerId, r]));

  let missing = 0;
  let ageViolations = 0;
  let goalsViolations = 0;
  let appsViolations = 0;
  let expectedGoals = 0;
  for (const p of pre) {
    if (!existingIds.has(p.id)) continue; // пенсионер/дренаж — каскад унёс запись
    const rec = recordById.get(p.id);
    if (!rec) {
      missing += 1;
      continue;
    }
    if (rec.age !== p.age) ageViolations += 1;
    if (rec.goals < p.goals) goalsViolations += 1;
    if (rec.apps < p.apps) appsViolations += 1;
    expectedGoals += p.goals;
  }
  const preIds = new Set(pre.map((p) => p.id));
  const extra = records.filter((r) => !preIds.has(r.playerId));
  const extraNonZero = extra.filter((r) => r.goals > 0 || r.apps > 0).length;
  const gone = pre.filter((p) => !existingIds.has(p.id)).length;
  const recordsGoals = records.reduce((s, r) => s + r.goals, 0);
  const match = await db.match.aggregate({
    where: { saveId, season, status: 'played' },
    _sum: { homeGoals: true, awayGoals: true },
  });
  const matchGoalsTotal = (match._sum.homeGoals ?? 0) + (match._sum.awayGoals ?? 0);

  console.log(`records=${records.length}`);
  console.log(`players_before=${pre.length}`);
  console.log(`players_gone=${gone}`);
  console.log(`missing=${missing}`);
  console.log(`age_violations=${ageViolations}`);
  console.log(`goals_violations=${goalsViolations}`);
  console.log(`apps_violations=${appsViolations}`);
  console.log(`extra_records=${extra.length}`);
  console.log(`extra_nonzero=${extraNonZero}`);
  console.log(`records_goals=${recordsGoals}`);
  console.log(`expected_goals_min=${expectedGoals}`);
  console.log(`match_goals=${matchGoalsTotal}`);
  console.log(
    `goals_match=${missing === 0 && ageViolations === 0 && goalsViolations === 0 && appsViolations === 0 && extraNonZero === 0}`,
  );
}

/**
 * Даунгрейд свежего сейва до состояния «легаси Фазы 2» (для проверки ленивой
 * миграции/инициализации в simulateWeek на СОБСТВЕННОМ сейве смоука):
 * boardTarget/boardTargetPlace/honeymoonUntilWeek = null; каждому третьему
 * игроку — «протухший» контракт contractUntil = 0 (< season).
 */
async function downgrade(saveId: string) {
  await db.gameSave.update({
    where: { id: saveId },
    data: { boardTarget: null, boardTargetPlace: null, honeymoonUntilWeek: null },
  });
  const players = await db.player.findMany({
    where: { saveId, teamId: { not: null } },
    select: { id: true },
  });
  const staleIds = players.filter((_, i) => i % 3 === 0).map((p) => p.id);
  if (staleIds.length > 0) {
    await db.player.updateMany({ where: { id: { in: staleIds } }, data: { contractUntil: 0 } });
  }
  console.log(`downgraded=${players.length}`);
  console.log(`stale_set=${staleIds.length}`);
}

async function main() {
  const [cmd, saveId, ...rest] = process.argv.slice(2);
  if (!cmd || !saveId) {
    console.error('usage: phase3_db_check.ts <academy|snapshot|reset|contracts|ai|allids|newteam|save|bonus|prestats|mig|records|matchgoals|preids|snapshotcheck|downgrade> <saveId> [season|file]');
    process.exit(1);
  }
  const season = Number(rest[0] ?? 1);
  switch (cmd) {
    case 'academy': await academy(saveId, season); break;
    case 'snapshot': await seasonSnapshot(saveId, season); break;
    case 'reset': await statsReset(saveId); break;
    case 'contracts': await contracts(saveId); break;
    case 'ai': await aiSquads(saveId); break;
    case 'allids': await teamPlayerIds(saveId); break;
    case 'newteam': {
      const idsFile = rest[0];
      if (!idsFile) {
        console.error('newteam: файл с id до перехода обязателен');
        process.exit(1);
      }
      const { readFileSync } = await import('node:fs');
      const ids = readFileSync(idsFile, 'utf-8').trim().split(/\s+/).filter(Boolean);
      await newTeamPlayers(saveId, ids);
      break;
    }
    case 'save': await saveInfo(saveId); break;
    case 'bonus': await boardBonus(saveId, season); break;
    case 'prestats': await preTransitionStats(saveId); break;
    case 'mig': await migration(saveId, season); break;
    case 'records': await recordsCount(saveId); break;
    case 'matchgoals': await matchGoals(saveId, season); break;
    case 'preids': await preIds(saveId); break;
    case 'snapshotcheck': {
      // rest = [season, preFile] — файл идёт ВТОРЫМ аргументом
      const preFile = rest[1];
      if (!preFile) {
        console.error('snapshotcheck: файл preids обязателен (вторым аргументом после сезона)');
        process.exit(1);
      }
      await snapshotCheck(saveId, season, preFile);
      break;
    }
    case 'downgrade': await downgrade(saveId); break;
    default:
      console.error(`unknown command: ${cmd}`);
      process.exit(1);
  }
  await db.$disconnect();
}

main();

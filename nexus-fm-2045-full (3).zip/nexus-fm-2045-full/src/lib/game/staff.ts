/**
 * Модуль 2 «Персонал»: генерация тренерского штата клуба (минимальный срез
 * для регенов академии — Модуль 4 добавит рынок/найм/увольнение и все роли).
 *
 * Штат клуба: главный тренер + ассистент. Рейтинг коррелирует с силой клуба
 * (сильный клуб — сильный тренер, gauss σ=7) — влияет на качество выпускников
 * академии через development.academyStaffBonusOf.
 *
 * Чистые функции; записи совместимы с Prisma-моделью Staff и StaffRecord
 * движка (createdAt проставляет хранилище по clockFields).
 */

import { NAME_POOLS, type PoolCode } from './leagues';
import { clamp, gauss, pick, randInt, type RNG } from './rng';
import {
  STAFF_COACH_XP_SPAN, STAFF_INJURY_SPAN, STAFF_HEAL_MAX, STAFF_RECOVERY_SPAN,
  STAFF_ROLE_MAX, STAFF_SPECIALTY_CAT_MULT, STAFF_YOUTH_XP_MAX_AGE, STAFF_YOUTH_XP_SPAN,
} from './constants';

const STAFF_ROLE_MAX_LOCAL: Record<string, number> = STAFF_ROLE_MAX;

export type StaffRoleCode = 'head_coach' | 'assistant' | 'fitness' | 'physio' | 'scout';

/** POJO-запись персонала (структурно совместима с Prisma Staff / StaffRecord). */
export interface StaffLikeRecord {
  id: string;
  saveId: string;
  teamId: string | null;
  role: StaffRoleCode;
  firstName: string;
  lastName: string;
  nationality: string;
  age: number;
  rating: number;
  specialty: string | null;
  salary: number;
  contractUntil: number;
}

/** Зарплата персонала: €/нед, ~rating × 40 (90-рейтинг ≈ 3 600/нед). */
export function staffSalaryOf(rating: number): number {
  return Math.max(600, Math.round((rating * 40) / 100) * 100);
}

export interface GenerateStaffArgs {
  saveId: string;
  teamId: string;
  /** Текущий сезон (для contractUntil = сезон + 1..3). */
  season: number;
  /** Сила клуба — якорь рейтинга тренеров. */
  strength: number;
  idFactory: () => string;
  /** Пул имён лиги. */
  pool: PoolCode;
}

/**
 * Базовый тренерский штат клуба: главный тренер (рейтинг ~ strength) и
 * ассистент (−8). Возраст: главтренер 42–62, ассистент 33–58.
 * Национальность — базовая страна пула (косметика).
 */
export function generateStaffForTeam(rng: RNG, args: GenerateStaffArgs): StaffLikeRecord[] {
  const { saveId, teamId, season, strength, idFactory, pool } = args;
  const names = NAME_POOLS[pool];
  const mk = (role: StaffRoleCode, rating: number, ageFrom: number, ageTo: number): StaffLikeRecord => {
    const r = clamp(Math.round(rating), 20, 96);
    return {
      id: idFactory(),
      saveId,
      teamId,
      role,
      firstName: pick(rng, names.first),
      lastName: pick(rng, names.last),
      nationality: pool,
      age: randInt(rng, ageFrom, ageTo),
      rating: r,
      specialty: null,
      salary: staffSalaryOf(r),
      contractUntil: season + randInt(rng, 1, 3),
    };
  };
  return [
    mk('head_coach', gauss(rng, strength, 7), 42, 62),
    mk('assistant', gauss(rng, strength - 8, 7), 33, 58),
  ];
}

/** Данные для db.staff.create из POJO-записи (createdAt — дефолт часов). */
export function staffCreateData(s: StaffLikeRecord) {
  return {
    id: s.id,
    saveId: s.saveId,
    teamId: s.teamId,
    role: s.role,
    firstName: s.firstName,
    lastName: s.lastName,
    nationality: s.nationality,
    age: s.age,
    rating: s.rating,
    specialty: s.specialty,
    salary: s.salary,
    contractUntil: s.contractUntil,
  };
}

// ── Модуль 4: влияние штата на системы клуба ────────────────────────────────

/** Русские подписи ролей (UI + новости). */
export const STAFF_ROLE_LABELS: Record<StaffRoleCode, string> = {
  head_coach: 'Главный тренер',
  assistant: 'Ассистент',
  fitness: 'Фитнес-тренер',
  physio: 'Физиотерапевт',
  scout: 'Скаут',
};

/** Подписи специализаций (косметика + лёгкие эффекты). */
export const STAFF_SPECIALTY_LABELS: Record<string, string> = {
  tech: 'Техника',
  mental: 'Менталитет',
  phys: 'Физика',
  gk: 'Вратари',
  youth: 'Молодёжь',
  recovery: 'Восстановление',
  conditioning: 'Выносливость',
  treatment: 'Лечение',
  prevention: 'Профилактика',
  talent: 'Таланты (U21)',
  'first-team': 'Основной состав',
  data: 'Аналитика',
};

/** Категория атрибутов, на которую специализация коуча даёт бонус. */
const SPECIALTY_CATEGORY: Record<string, string> = {
  tech: 'tech',
  mental: 'mental',
  phys: 'phys',
  gk: 'gk',
};

/**
 * Сводные эффекты тренерского штата на клуб (Модуль 4). Все формулы — чистые,
 * нейтральны при пустом штате (легаси-сейвы):
 *  - xpMult: главный тренер (60 → 1.0, 90 → 1.12, 30 → 0.88);
 *  - youthXpMult: ассистент для молодых ≤23 (доп. множитель);
 *  - catMult: специализации коучей/ассистента → множитель категории атрибутов;
 *  - injuryRiskMult: физио (55 → 1.0, 85 → 0.9, 35 → 1.07);
 *  - healChance: физио 'treatment' — шанс ускорить лечение на 1 неделю;
 *  - recoveryBonus: фитнес-тренер (± к еженедельному восстановлению);
 *  - bestScoutRating: лучший скаут (рост знания в scouting.ts);
 */
export interface StaffEffects {
  xpMult: number;
  youthXpMult: number;
  catMult: Record<'tech' | 'mental' | 'phys' | 'gk', number>;
  injuryRiskMult: number;
  healChance: number;
  recoveryBonus: number;
  bestScoutRating: number | null;
}

/** Нейтральные эффекты (пустой штат / легаси). */
export function neutralStaffEffects(): StaffEffects {
  return {
    xpMult: 1,
    youthXpMult: 1,
    catMult: { tech: 1, mental: 1, phys: 1, gk: 1 },
    injuryRiskMult: 1,
    healChance: 0,
    recoveryBonus: 0,
    bestScoutRating: null,
  };
}

export function staffTrainingEffectsOf(staff: StaffLikeRecord[]): StaffEffects {
  const e = neutralStaffEffects();
  for (const s of staff) {
    switch (s.role) {
      case 'head_coach':
        e.xpMult *= 1 + (s.rating - 60) / 250;
        break;
      case 'assistant':
        e.youthXpMult *= 1 + (s.rating - 60) / 400;
        break;
      case 'fitness': {
        const bonus = (s.rating - 55) / 12;
        e.recoveryBonus += s.specialty === 'recovery' ? bonus + 1 : bonus;
        break;
      }
      case 'physio':
        e.injuryRiskMult *= 1 + (55 - s.rating) / 300;
        if (s.specialty === 'treatment') e.healChance += 0.05;
        if (s.specialty === 'prevention') e.injuryRiskMult *= 0.95;
        break;
      case 'scout':
        if (e.bestScoutRating === null || s.rating > e.bestScoutRating) e.bestScoutRating = s.rating;
        break;
    }
    // специализация коучей — бонус категории атрибутов
    const cat = s.specialty !== null ? SPECIALTY_CATEGORY[s.specialty] : undefined;
    if (
      (s.role === 'head_coach' || s.role === 'assistant') && cat !== undefined
      && cat in e.catMult
    ) {
      e.catMult[cat as keyof StaffEffects['catMult']] *= STAFF_SPECIALTY_CAT_MULT;
    }
  }
  e.xpMult = clamp(e.xpMult, STAFF_COACH_XP_SPAN[0], STAFF_COACH_XP_SPAN[1]);
  e.youthXpMult = clamp(e.youthXpMult, STAFF_YOUTH_XP_SPAN[0], STAFF_YOUTH_XP_SPAN[1]);
  e.injuryRiskMult = clamp(e.injuryRiskMult, STAFF_INJURY_SPAN[0], STAFF_INJURY_SPAN[1]);
  e.healChance = Math.min(e.healChance, STAFF_HEAL_MAX);
  e.recoveryBonus = clamp(e.recoveryBonus, STAFF_RECOVERY_SPAN[0], STAFF_RECOVERY_SPAN[1]);
  return e;
}

/** Молодой ли игрок для доп. XP ассистента. */
export function isYouthTrainee(age: number): boolean {
  return age <= STAFF_YOUTH_XP_MAX_AGE;
}

/** Занято ли место роли (роль уникальна, кроме скаутов: их до 3). */
export function staffRoleFull(role: string, employedInRole: number): boolean {
  const max = STAFF_ROLE_MAX_LOCAL[role];
  if (max === undefined) return true; // неизвестная роль не нанимается
  return employedInRole >= max;
}

/** Недельная ведомость штата, €. */
export function staffWagesOf(staff: StaffLikeRecord[]): number {
  return staff.reduce((sum, s) => sum + Math.max(0, s.salary), 0);
}

// ── Сезонный шаг персонала (межсезонье) ─────────────────────────────────────

/** Сезонный дрейф рейтинга: <45 растёт, 45–57 стабилен, 58+ падает. */
export function staffRatingDriftOf(rng: RNG, age: number): number {
  if (age < 45) return randInt(rng, 0, 2);
  if (age < 58) return randInt(rng, -1, 1);
  return randInt(rng, -3, 0);
}

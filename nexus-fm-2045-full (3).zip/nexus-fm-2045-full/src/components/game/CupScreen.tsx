'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Goal, ListOrdered, Loader2, Trophy } from 'lucide-react';
import { api } from '@/lib/game/api';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MatchDetailsDialog } from '@/components/game/shared/MatchDetailsDialog';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import type { CupMatchDTO, CupRoundDTO, MatchDetailsDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/** Карточка одного кубкового матча в сетке. */
function CupMatchCard({ m, myTeamId }: { m: CupMatchDTO; myTeamId: string }) {
  const notDrawn = !m.home || !m.away;

  if (notDrawn) {
    return (
      <div className="flex w-full items-center justify-between gap-2 rounded-lg border border-dashed border-border/60 bg-secondary/20 px-3 py-2.5 text-xs text-muted-foreground">
        <span className="flex size-6 items-center justify-center rounded-full border border-border/60">?</span>
        <span>Жеребьёвка</span>
        <span className="flex size-6 items-center justify-center rounded-full border border-border/60">?</span>
      </div>
    );
  }

  const home = m.home!;
  const away = m.away!;
  const homeWin = m.winnerTeamId === home.id;
  const awayWin = m.winnerTeamId === away.id;

  return (
    <div
      className={cn(
        'w-full rounded-lg border border-border/60 bg-card px-3 py-2.5',
        m.isUserMatch && 'border-primary/60 ring-1 ring-primary/30',
      )}
    >
      <div className="flex items-center gap-2">
        <TeamCrest
          shortName={home.shortName}
          colorPrimary={home.colorPrimary}
          colorSecondary={home.colorSecondary}
          size="sm"
          title={home.name}
        />
        <span
          className={cn(
            'min-w-0 flex-1 truncate text-xs',
            homeWin ? 'font-bold text-foreground' : m.played ? 'text-muted-foreground' : 'text-foreground',
          )}
        >
          {home.shortName}
        </span>
        <span className="w-6 text-center text-xs font-bold tabular">
          {m.played ? m.homeGoals : '—'}
        </span>
      </div>
      <div className="mt-1.5 flex items-center gap-2">
        <TeamCrest
          shortName={away.shortName}
          colorPrimary={away.colorPrimary}
          colorSecondary={away.colorSecondary}
          size="sm"
          title={away.name}
        />
        <span
          className={cn(
            'min-w-0 flex-1 truncate text-xs',
            awayWin ? 'font-bold text-foreground' : m.played ? 'text-muted-foreground' : 'text-foreground',
          )}
        >
          {away.shortName}
        </span>
        <span className="w-6 text-center text-xs font-bold tabular">
          {m.played ? m.awayGoals : '—'}
        </span>
      </div>
      {m.homePens !== null && m.awayPens !== null ? (
        <Badge className="mt-1.5 w-full justify-center border border-[#EAB308]/40 bg-[#EAB308]/10 text-[10px] font-semibold text-[#EAB308] tabular">
          пен. {m.homePens}:{m.awayPens}
        </Badge>
      ) : null}
      {m.isNeutral ? (
        <Badge variant="outline" className="mt-1.5 w-full justify-center text-[9px] text-muted-foreground">
          Нейтральное поле
        </Badge>
      ) : null}
    </div>
  );
}

/** Колонка раунда для десктопной сетки. */
function BracketColumn({ round, myTeamId }: { round: CupRoundDTO; myTeamId: string }) {
  return (
    <div className="flex w-52 shrink-0 flex-col">
      <div className="mb-2 text-center">
        <div className="text-xs font-bold">{round.label}</div>
        <div className="text-[10px] text-muted-foreground tabular">неделя {round.week}</div>
      </div>
      <div className="flex flex-1 flex-col justify-around gap-3">
        {round.drawn && round.matches.length > 0 ? (
          round.matches.map((m) => <CupMatchCard key={m.id} m={m} myTeamId={myTeamId} />)
        ) : (
          <div className="rounded-lg border border-dashed border-border/60 bg-secondary/20 px-3 py-4 text-center text-[11px] text-muted-foreground">
            Жеребьёвка ещё не состоялась
          </div>
        )}
      </div>
    </div>
  );
}

/** Строка статуса моей команды в кубке. */
function StatusBanner() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { cup } = snapshot;
  const current = cup.rounds.find((r) => r.round === cup.currentRound);
  const label =
    cup.myStatus === 'eliminated'
      ? cup.myEliminatedRound
        ? cup.rounds.find((r) => r.round === cup.myEliminatedRound)?.label ?? ''
        : ''
      : current?.label ?? '';

  if (cup.myStatus === 'winner') {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-[#EAB308]/40 bg-[#EAB308]/10 px-4 py-3">
        <Trophy className="size-5 text-[#EAB308]" aria-hidden />
        <p className="text-sm font-bold text-[#EAB308]">
          Вы — обладатель {cup.cupName}! 🏆
        </p>
      </div>
    );
  }
  if (cup.myStatus === 'eliminated') {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 px-4 py-3">
        <Badge variant="outline" className="border-[#EF4444]/40 text-[#EF4444]">
          Выбыли
        </Badge>
        <p className="text-sm font-semibold text-[#EF4444]">
          {label ? `Ваш клуб выбыл в раунде «${label}»` : 'Ваш клуб выбыл из кубка'}
        </p>
      </div>
    );
  }
  if (cup.myStatus === 'alive') {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-4 py-3">
        <Trophy className="size-5 text-primary" aria-hidden />
        <p className="text-sm font-semibold text-primary">
          Вы в игре{label ? ` · следующий раунд «${label}»` : ''}
        </p>
      </div>
    );
  }
  return null;
}

/** Сетка: десктоп — колонки раундов, мобайл — вертикальный список. */
function Bracket() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { cup, myTeam } = snapshot;
  const finalRound = cup.rounds[cup.rounds.length - 1];
  const cupWinner = finalRound?.matches.find((m) => m.played && m.winnerTeamId)?.winnerTeamId ?? null;
  const winnerTeam = finalRound?.matches
    .flatMap((m) => [m.home, m.away])
    .find((t) => t && t.id === cupWinner);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      {/* Десктоп: горизонтальная сетка */}
      <div className="scroll-thin hidden overflow-x-auto rounded-lg border border-border/70 bg-secondary/20 p-4 md:block">
        <div className="flex min-h-64 items-stretch gap-6">
          {cup.rounds.map((round) => (
            <BracketColumn key={round.round} round={round} myTeamId={myTeam.id} />
          ))}
          {cupWinner && winnerTeam ? (
            <div className="flex w-52 shrink-0 flex-col">
              <div className="mb-2 text-center text-xs font-bold text-[#EAB308]">Обладатель</div>
              <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-lg border border-[#EAB308]/40 bg-[#EAB308]/10 p-4">
                <TeamCrest
                  shortName={winnerTeam.shortName}
                  colorPrimary={winnerTeam.colorPrimary}
                  colorSecondary={winnerTeam.colorSecondary}
                  size="lg"
                  title={winnerTeam.name}
                />
                <Trophy className="size-6 text-[#EAB308]" aria-hidden />
                <div className="text-center text-xs font-bold">{winnerTeam.name}</div>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* Мобайл: вертикальный список раундов */}
      <div className="space-y-3 md:hidden">
        {cup.rounds.map((round) => (
          <Card key={round.round} className="border-border/70">
            <CardContent className="flex flex-col gap-3 p-4 pt-4">
              <div className="flex items-baseline justify-between">
                <div className="text-sm font-bold">{round.label}</div>
                <div className="text-[11px] text-muted-foreground tabular">неделя {round.week}</div>
              </div>
              {round.drawn && round.matches.length > 0 ? (
                round.matches.map((m) => <CupMatchCard key={m.id} m={m} myTeamId={myTeam.id} />)
              ) : (
                <p className="rounded-lg border border-dashed border-border/60 bg-secondary/20 px-3 py-3 text-center text-[11px] text-muted-foreground">
                  Жеребьёвка ещё не состоялась
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </motion.div>
  );
}

/** Все сыгранные кубковые матчи сезона, клик — детали. */
function CupResults() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const activeSaveId = useGameStore((s) => s.activeSaveId);
  const { seasonMatches, teams, cup } = snapshot;
  const teamById = useMemo(() => new Map(teams.map((t) => [t.id, t])), [teams]);

  const [matchId, setMatchId] = useState<string | null>(null);
  const [matchData, setMatchData] = useState<MatchDetailsDTO | null>(null);
  const [matchLoading, setMatchLoading] = useState(false);

  const openMatch = (id: string) => {
    if (!activeSaveId) return;
    setMatchId(id);
    setMatchLoading(true);
    setMatchData(null);
    void api
      .getMatch(activeSaveId, id)
      .then((res) => setMatchData(res.match))
      .catch(() => setMatchData(null))
      .finally(() => setMatchLoading(false));
  };

  const closeMatch = () => {
    setMatchId(null);
    setMatchData(null);
    setMatchLoading(false);
  };

  const played = useMemo(
    () => seasonMatches.filter((m) => m.competition === 'cup' && m.played).sort((a, b) => b.week - a.week),
    [seasonMatches],
  );

  const roundLabel = (round: number | null): string => {
    if (round === null) return '';
    const r = cup.rounds.find((x) => x.round === round);
    return r ? r.label : '';
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
      {played.length === 0 ? (
        <Card className="border-border/70">
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            Кубковые матчи ещё не сыграли. Первая кубковая неделя — по календарю лиги.
          </CardContent>
        </Card>
      ) : (
        played.map((m) => {
          const home = teamById.get(m.homeTeamId);
          const away = teamById.get(m.awayTeamId);
          const isUser = m.homeTeamId === snapshot.myTeam.id || m.awayTeamId === snapshot.myTeam.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => openMatch(m.id)}
              className={cn(
                'flex w-full items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-2.5 text-left transition-colors hover:border-primary/50',
                isUser && 'border-primary/40 bg-primary/5',
              )}
            >
              <Badge variant="outline" className="hidden shrink-0 text-[10px] sm:inline-flex">
                {roundLabel(m.cupRound)}
              </Badge>
              <div className="flex min-w-0 flex-1 items-center justify-end gap-2 text-right">
                <span className={cn('hidden truncate text-xs sm:inline', isUser && 'font-bold text-primary')}>
                  {home?.name ?? '—'}
                </span>
                <TeamCrest
                  shortName={home?.shortName ?? '—'}
                  colorPrimary={home?.colorPrimary ?? '#0E7490'}
                  colorSecondary={home?.colorSecondary ?? '#F0F6FC'}
                  size="sm"
                />
              </div>
              <div className="w-16 shrink-0 text-center text-sm font-bold tabular">
                {m.homeGoals} : {m.awayGoals}
              </div>
              <div className="flex min-w-0 flex-1 items-center gap-2">
                <TeamCrest
                  shortName={away?.shortName ?? '—'}
                  colorPrimary={away?.colorPrimary ?? '#0E7490'}
                  colorSecondary={away?.colorSecondary ?? '#F0F6FC'}
                  size="sm"
                />
                <span className={cn('hidden truncate text-xs sm:inline', isUser && 'font-bold text-primary')}>
                  {away?.name ?? '—'}
                </span>
              </div>
            </button>
          );
        })
      )}
      <MatchDetailsDialog
        matchId={matchId}
        match={matchData}
        loading={matchLoading}
        onClose={closeMatch}
      />
    </motion.div>
  );
}

/** Топ-5 бомбардиров кубка (live из GET /awards). */
function CupScorers() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const awardsCache = useGameStore((s) => s.awardsCache);
  const awardsLoading = useGameStore((s) => s.awardsLoading);
  const fetchAwards = useGameStore((s) => s.fetchAwards);

  useEffect(() => {
    void fetchAwards();
  }, [fetchAwards]);

  const scorers = awardsCache?.live.topCupScorers ?? [];

  if (awardsLoading && scorers.length === 0) {
    return (
      <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
        <Loader2 className="size-5 animate-spin" aria-hidden />
        Загружаем бомбардиров кубка…
      </div>
    );
  }

  if (scorers.length === 0) {
    return (
      <Card className="border-border/70">
        <CardContent className="py-8 text-center text-sm text-muted-foreground">
          Голы в кубке ещё не забиты.
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="overflow-hidden rounded-lg border border-border/70 bg-card"
    >
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="h-10 w-10 text-center text-[11px]">#</TableHead>
            <TableHead className="h-10 text-[11px]">Игрок</TableHead>
            <TableHead className="h-10 text-[11px]">Клуб</TableHead>
            <TableHead className="h-10 w-12 text-center text-[11px]">Голы</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="zebra">
          {scorers.map((p, i) => (
            <TableRow
              key={p.playerId}
              className={cn('h-10 border-border/40', p.isUser && 'bg-primary/10 hover:bg-primary/10')}
            >
              <TableCell className="text-center text-xs font-semibold tabular">{i + 1}</TableCell>
              <TableCell className={cn('text-xs', p.isUser && 'font-bold text-primary')}>
                <span className="flex items-center gap-1.5">
                  <Goal className="size-3 text-muted-foreground" aria-hidden />
                  {p.name}
                </span>
              </TableCell>
              <TableCell>
                <span className="flex items-center gap-1.5">
                  <TeamCrest
                    shortName={p.teamShort}
                    colorPrimary={p.colorPrimary}
                    colorSecondary={p.colorSecondary}
                    size="sm"
                    title={p.teamName}
                  />
                  <span className="truncate text-xs text-muted-foreground">{p.teamName}</span>
                </span>
              </TableCell>
              <TableCell className="text-center text-xs font-bold tabular">{p.goals}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <p className="border-t border-border/50 px-4 py-2 text-[11px] text-muted-foreground">
        Кубковые голы текущего сезона · {snapshot.cup.cupName}
      </p>
    </motion.div>
  );
}

/** Экран «Кубок»: сетка, результаты, бомбардиры. */
export function CupScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { cup, save } = snapshot;

  return (
    <div className="space-y-4">
      <SectionHeader
        title={cup.cupName}
        subtitle={`Сезон ${save.season} · одна игра в раунде, ничья — серия пенальти`}
      />
      <StatusBanner />
      <Tabs defaultValue="bracket">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="bracket" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Trophy className="size-4" aria-hidden />
            Сетка
          </TabsTrigger>
          <TabsTrigger value="results" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <ListOrdered className="size-4" aria-hidden />
            Результаты
          </TabsTrigger>
          <TabsTrigger value="scorers" className="min-h-9 flex-1 gap-1.5 sm:flex-none">
            <Goal className="size-4" aria-hidden />
            Бомбардиры
          </TabsTrigger>
        </TabsList>
        <TabsContent value="bracket">
          <Bracket />
        </TabsContent>
        <TabsContent value="results">
          <CupResults />
        </TabsContent>
        <TabsContent value="scorers">
          <CupScorers />
        </TabsContent>
      </Tabs>
    </div>
  );
}

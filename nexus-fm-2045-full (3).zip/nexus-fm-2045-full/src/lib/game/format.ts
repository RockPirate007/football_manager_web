/**
 * Форматирование и UI-хелперы (изоморфный модуль для клиента).
 */

/** €1.2M / €450K / €980 — компактный формат для карточек и таблиц. */
export function formatMoney(amount: number): string {
  const sign = amount < 0 ? '−' : '';
  const abs = Math.abs(amount);
  if (abs >= 1_000_000) {
    const v = abs / 1_000_000;
    const s = v >= 100 ? Math.round(v).toString() : v.toFixed(1).replace(/\.0$/, '');
    return `${sign}€${s}M`;
  }
  if (abs >= 1_000) return `${sign}€${Math.round(abs / 1_000)}K`;
  return `${sign}€${abs}`;
}

/** €1 234 567 — точный формат с разделителями (диалоги, финансы). */
export function formatMoneyExact(amount: number): string {
  const sign = amount < 0 ? '−' : '';
  return `${sign}€${Math.abs(amount).toLocaleString('ru-RU')}`;
}

/** Подпись уровня силы клуба для стартового экрана. */
export function strengthLabel(strength: number): { text: string; tone: 'gold' | 'normal' | 'low' } {
  if (strength >= 74) return { text: 'Топ', tone: 'gold' };
  if (strength >= 62) return { text: 'Середина', tone: 'normal' };
  return { text: 'Аутсайдер', tone: 'low' };
}

/** Цвет числа OVR — как в рефенсах NEXUS FM 2045 (value_color из темы бота):
 *  ≥85 зелёный (элита), 65–84 неон-циан, 50–64 жёлтый, <50 красный. */
export function ovrColor(ovr: number): string {
  if (ovr >= 85) return '#22C55E';
  if (ovr >= 65) return '#00D4FF';
  if (ovr >= 50) return '#FACC15';
  return '#EF4444';
}

/** Цвет полосы атрибута. */
export function attrColor(value: number): string {
  if (value >= 80) return '#22C55E';
  if (value >= 60) return '#00D4FF';
  if (value >= 45) return '#FACC15';
  return '#EF4444';
}

/** Классы цвета зоны таблицы. */
export function zoneClass(place: number): string {
  if (place <= 3) return 'bg-[#22C55E]';
  if (place <= 6) return 'bg-[#FACC15]';
  if (place >= 14) return 'bg-[#EF4444]';
  return 'bg-transparent';
}

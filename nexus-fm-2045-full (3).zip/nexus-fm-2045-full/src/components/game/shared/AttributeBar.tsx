import { cn } from '@/lib/utils';
import { attrColor } from '@/lib/game/format';

/**
 * Строка атрибута: подпись + полоса (цвет по величине) + число.
 * Модуль 3: unknown=true — «туман войны» (знание скаутов < 40): вместо числа
 * и полосы — «?» (данные закрыты, оценка недоступна).
 */
export function AttributeBar({
  label,
  value,
  className,
  unknown = false,
}: {
  label: string;
  value: number;
  className?: string;
  unknown?: boolean;
}) {
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <span className="w-24 shrink-0 truncate text-xs text-muted-foreground" title={label}>
        {label}
      </span>
      <div
        className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary"
        role="progressbar"
        aria-valuenow={unknown ? undefined : value}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label}
      >
        {unknown ? null : (
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${Math.min(100, Math.max(0, value))}%`, backgroundColor: attrColor(value) }}
          />
        )}
      </div>
      <span
        className={cn(
          'w-7 shrink-0 text-right text-xs font-semibold tabular',
          unknown && 'text-muted-foreground/70',
        )}
      >
        {unknown ? '?' : value}
      </span>
    </div>
  );
}

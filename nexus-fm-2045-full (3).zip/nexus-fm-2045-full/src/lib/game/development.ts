/**
 * Модуль 2 «Глубокая система игроков»: покатегорийные кривые роста/деградации
 * по возрасту, матчёвый опыт (минуты → развитие), влияние тренеров на регены,
 * звёздное отображение PA.
 *
 * FM-модель развития (сводка для QA):
 *  - ТЕХНИЧЕСКИЕ растут до ~27, плато, медленный спад после 33;
 *  - МЕНТАЛЬНЫЕ растут дольше всех — до ~31–33, спад только после 36;
 *  - ФИЗИЧЕСКИЕ: пик 27–29; Скорость/Ускорение падают с 30, Выносливость/
 *    Прыгучесть — с 32, Сила — с 33 (деградация физики после 30–32);
 *  - ВРАТАРСКИЕ созревают и стареют на ~3 года позже полевых;
 *  - жёсткий потолок: computeOvr(игрока) ≤ potential (инвариант QA №12);
 *  - матчёвый XP капает в trainingXp (единый канал развития с тренировками),
 *    конвертацию дробного xp в +1 делает applyWeeklyTraining.
 *
 * Все функции чистые (RNG только в параметрах), порядок бросков фиксирован.
 */

import { computeOvr, keyAttrsOf, refreshEconomy, type PlayerLike } from './players';
import { starsOf } from './academy';
import { clamp, pick, pickWeighted, randInt, type RNG } from './rng';
import { ATTR_GROUPS, type AttrKey } from './types';

// ── Категории атрибутов ───────────────────────────────────────────────────

export type AttrCategory = 'tech' | 'mental' | 'phys' | 'gk';

/** Категория каждого из 21 атрибута (по ATTR_GROUPS types.ts). */
const CATEGORY_OF: Record<AttrKey, AttrCategory> = (() => {
  const map = {} as Record<AttrKey, AttrCategory>;
  for (const group of ATTR_GROUPS) {
    for (const key of group.keys) map[key] = group.key;
  }
  return map;
})();

/** Категория атрибута ('tech'|'mental'|'phys'|'gk'). */
export function attrCategoryOf(attr: AttrKey): AttrCategory {
  return CATEGORY_OF[attr] ?? 'tech';
}

/** Все атрибуты категории. */
export function attrsOfCategory(cat: AttrCategory): AttrKey[] {
  const group = ATTR_GROUPS.find((g) => g.key === cat);
  return group ? [...group.keys] : [];
}

// ── Кривые роста по категориям (недельный масштаб) ─────────────────────────

/**
 * Множитель скорости роста категории в возрасте age.
 * GK: все категории сдвинуты на +3 года (вратари созревают позже).
 * Используется и недельными тренировками, и матчёвым XP.
 */
export function growthMultOf(cat: AttrCategory, age: number, isGk: boolean): number {
  const a = isGk && cat !== 'gk' ? age - 3 : age;
  switch (cat) {
    case 'tech':
      if (a <= 19) return 1.7;
      if (a <= 23) return 1.3;
      if (a <= 27) return 0.9;
      if (a <= 30) return 0.45;
      return 0.15;
    case 'mental':
      if (a <= 19) return 1.3;
      if (a <= 23) return 1.2;
      if (a <= 27) return 1.0;
      if (a <= 31) return 0.8;
      if (a <= 34) return 0.4;
      return 0.15;
    case 'phys':
      if (a <= 19) return 1.7;
      if (a <= 23) return 1.3;
      if (a <= 27) return 0.9;
      if (a <= 29) return 0.5;
      return 0.12;
    case 'gk':
      if (a <= 21) return 1.4;
      if (a <= 25) return 1.2;
      if (a <= 29) return 1.0;
      if (a <= 33) return 0.7;
      return 0.3;
  }
}

// ── Расписание деградации (межсезонье) ─────────────────────────────────────

/** Возраст начала спада атрибута (GK — +2–3 года, kicking не деградирует). */
const DECLINE_FROM: Record<AttrKey, number> = {
  // физические: скорость/ускорение первыми (30), выносливость/прыгучесть (32), сила (33)
  pace: 30,
  acceleration: 30,
  stamina: 32,
  jumping: 32,
  strength: 33,
  // технические — медленный спад с 33
  finishing: 33,
  passing: 34,
  dribbling: 33,
  crossing: 33,
  tackling: 34,
  marking: 34,
  heading: 34,
  // ментальные — самый поздний спад (36)
  vision: 36,
  decisions: 36,
  positioning: 36,
  leadership: 37,
  aggression: 38,
  // вратарские — позже всех
  reflexes: 34,
  rushingOut: 33,
  handling: 34,
  kicking: 99, // ввод мяча не деградирует
};

/** Возраст начала спада атрибута с учётом позиции (GK: вратарские +2, полевые — GK-атрибуты не падают). */
export function declineFromOf(attr: AttrKey, isGk: boolean): number {
  const base = DECLINE_FROM[attr] ?? 36;
  if (isGk) return attrCategoryOf(attr) === 'gk' ? base + 2 : base;
  return attrCategoryOf(attr) === 'gk' ? 99 : base;
}

// ── Сезонное развитие (замена плоской логики из progression.ts) ───────────

export interface SeasonalDevReport {
  grown: { name: string; attr: AttrKey; before: number; after: number }[];
  declined: { name: string; attr: AttrKey; before: number; after: number }[];
}

/**
 * Сезонный шаг развития игрока (вызывается из applySeasonProgression
 * ПОСЛЕ инкремента возраста). Рост — по категориям с запасом потенциала,
 * деградация — по расписанию DECLINE_FROM. Жёсткий потолок potential.
 * Мутирует игрока на месте и пересчитывает экономику.
 */
export function developPlayerSeasonal(rng: RNG, p: PlayerLike): SeasonalDevReport {
  const report: SeasonalDevReport = { grown: [], declined: [] };
  const isGk = p.position === 'GK';
  const keyAttrs = keyAttrsOf(p.position);

  // ── Рост: пул категорий, ещё способных расти ──
  const trainable = (['tech', 'mental', 'phys', 'gk'] as AttrCategory[])
    .filter((cat) => growthMultOf(cat, p.age, isGk) >= 0.3);
  // сколько точек роста (молодые — больше; key-атрибуты приоритетны) — FM-темп:
  // вундеркинд PA≈88 растёт ≈+3..4 OVR/сезон в 16–19 лет
  const growthBudget =
    p.age <= 19 ? randInt(rng, 5, 8)
    : p.age <= 23 ? randInt(rng, 3, 6)
    : p.age <= 27 ? randInt(rng, 2, 4)
    : p.age <= 30 ? randInt(rng, 1, 2)
    : randInt(rng, 0, 1);

  for (let i = 0; i < growthBudget; i++) {
    // 65% — ключевой атрибут позиции (профиль обостряется), 35% — любой тренируемый
    const attr: AttrKey =
      rng() < 0.65 && keyAttrs.length > 0
        ? pick(rng, keyAttrs)
        : (() => {
          const pool: { item: AttrKey; weight: number }[] = [];
          for (const cat of trainable) {
            for (const key of attrsOfCategory(cat)) {
              // GK-атрибуты у полевых не растут; вратарю доступны все категории
              if (!isGk && attrCategoryOf(key) === 'gk') continue;
              pool.push({ item: key, weight: Math.max(0.1, growthMultOf(attrCategoryOf(key), p.age, isGk)) });
            }
          }
          return pool.length > 0 ? pickWeighted(rng, pool) : pick(rng, keyAttrs);
        })();

    const inc = p.age <= 21 ? randInt(rng, 2, 5) : p.age <= 27 ? randInt(rng, 1, 3) : 1;
    const before = p[attr];
    const tentative = { ...p, [attr]: before + inc } as PlayerLike;
    if (computeOvr(tentative, p.position) > p.potential) continue; // потолок PA
    p[attr] = clamp(before + inc, 1, 99);
    report.grown.push({ name: `${p.firstName} ${p.lastName}`, attr, before, after: p[attr] });
  }

  // ── Деградация: атрибуты, прошедшие порог спада ──
  const allAttrs = ATTR_GROUPS.flatMap((g) => [...g.keys]);
  for (const attr of allAttrs) {
    const from = declineFromOf(attr, isGk);
    if (p.age <= from) continue;
    if (rng() < 0.3) continue; // 70% сезонов атрибут всё-таки падает
    const ramp = Math.min(4, p.age - from); // чем дальше за порогом, тем больнее
    const dec = randInt(rng, 1, 1 + ramp);
    const before = p[attr];
    p[attr] = clamp(before - dec, 1, 99);
    if (p[attr] !== before) {
      report.declined.push({ name: `${p.firstName} ${p.lastName}`, attr, before, after: p[attr] });
    }
  }

  if (report.grown.length > 0 || report.declined.length > 0) {
    refreshEconomy(p); // ovr/value/salary
  }
  return report;
}

// ── Матчёвый опыт: минуты → развитие ──────────────────────────────────────

/** Парсинг trainingXp JSON (устойчив к мусору — как parseTrainingXp types.ts). */
function parseXp(p: PlayerLike): Partial<Record<AttrKey, number>> {
  try {
    const raw = p.trainingXp ? JSON.parse(p.trainingXp) : {};
    return raw && typeof raw === 'object' ? raw : {};
  } catch {
    return {};
  }
}

/**
 * Матчёвый XP: сыгранные минуты дают дробный опыт в 1–2 ключевых атрибута
 * (молодым больше; категории, уже не растущие в этом возрасте, не получают).
 * Пишет в p.trainingXp; конвертацию в +1 делает applyWeeklyTraining
 * (универсальный проход по всем накопленным атрибутам ≥ 1.0).
 * Отдельный rng-поток от рейтингового — порядок бросков рейтинга не меняется.
 */
export function applyMatchDevelopment(rng: RNG, p: PlayerLike, minutes: number): boolean {
  if (minutes <= 0) return false;
  const isGk = p.position === 'GK';
  const keyAttrs = keyAttrsOf(p.position);
  if (keyAttrs.length === 0) return false;

  // возрастной множитель матчёвого опыта
  const ageMult =
    p.age <= 21 ? 1.35
    : p.age <= 24 ? 1.15
    : p.age <= 28 ? 0.9
    : p.age <= 31 ? 0.55
    : 0.3;
  if (ageMult < 0.3) return false;

  // в категории, которая уже не растёт, матчёвый xp не капает
  const eligible = keyAttrs.filter((a) =>
    growthMultOf(attrCategoryOf(a), p.age, isGk) >= 0.25,
  );
  if (eligible.length === 0) return false;

  const headroom = clamp((p.potential - p.ovr) / 9, 0.15, 1.4);
  const u = 0.6 + rng() * 0.8; // бросок стабильности роста
  const total = 0.22 * (minutes / 90) * ageMult * headroom * u;

  const xp = parseXp(p);
  const n = eligible.length >= 2 && rng() < 0.45 ? 2 : 1;
  for (let i = 0; i < n; i++) {
    const attr = pick(rng, eligible);
    xp[attr] = (xp[attr] ?? 0) + total / n;
  }
  const keys = Object.keys(xp);
  p.trainingXp = keys.length > 0 ? JSON.stringify(xp) : null;
  return true;
}

// ── Тренеры → качество регенов академии ───────────────────────────────────

export interface StaffLike {
  role: string;
  rating: number;
}

/**
 * Эффективный рейтинг тренерского штата для воспитанников:
 * главный тренер ×1.0 + ассистент ×0.6 (роли из Staff-модели Prisma).
 * 0 при пустом штате (легаси-сейвы без персонала).
 */
export function youthCoachingOf(staff: StaffLike[]): number {
  let sum = 0;
  let weight = 0;
  for (const s of staff) {
    if (s.role === 'head_coach') { sum += s.rating; weight += 1; }
    else if (s.role === 'assistant') { sum += 0.6 * s.rating; weight += 0.6; }
  }
  return weight > 0 ? sum / weight : 0;
}

/**
 * Бонус регенам от тренерского штата (добавляется к бонусам зданий академии):
 *  - potBonus: (rating − 55)/8 → диапазон −2..+5 к потолку выпускников;
 *  - gemMult: 0.9 + rating/500 → ±10% к шансу «жемчужины»;
 *  - sizeBonus: rating ≥ 75 → +1 выпускник.
 */
export function academyStaffBonusOf(staff: StaffLike[]): {
  sizeBonus: number;
  potBonus: number;
  gemMult: number;
} {
  const rating = youthCoachingOf(staff);
  if (rating <= 0) return { sizeBonus: 0, potBonus: 0, gemMult: 1 };
  return {
    sizeBonus: rating >= 75 ? 1 : 0,
    potBonus: Math.round((rating - 55) / 8),
    gemMult: 0.9 + rating / 500,
  };
}

// ── Звёздное отображение PA (скрытые параметры) ───────────────────────────

/** Звёзды потенциала 1..5 — канонические пороги ACADEMY_STARS (85/78/70/62). */
export function potentialStarsOf(potential: number): number {
  return starsOf(potential);
}

/** «★★★★★»-строка по числу звёзд. */
export function starsLabelOf(stars: number): string {
  return '★'.repeat(clamp(Math.round(stars), 1, 5));
}

/** Текстовая оценка таланта по звёздам (для карточки игрока и новостей). */
export function talentLabelOf(stars: number): string {
  switch (clamp(Math.round(stars), 1, 5)) {
    case 5: return 'Мировой талант';
    case 4: return 'Топ-талант';
    case 3: return 'Перспективный';
    case 2: return 'Ролевой';
    default: return 'Скромный потолок';
  }
}

/** Компактная строка «★★★★☆ Топ-талант» для UI. */
export function potentialLabelOf(potential: number): string {
  const stars = potentialStarsOf(potential);
  return `${starsLabelOf(stars)} ${talentLabelOf(stars)}`;
}

/**
 * Молодёжная академия: набор в неделю 4, качество по тиру клуба.
 * Чистые функции (§3.3 architecture-phase3.md). RNG — только в параметрах.
 */

import {
  ACADEMY_AGE_16_P, ACADEMY_GEM_P, ACADEMY_GEM_POT, ACADEMY_GK_MAX_AGE, ACADEMY_GK_P,
  ACADEMY_GK_YOUNG_MAX, ACADEMY_GOLDEN_BONUS, ACADEMY_GOLDEN_P, ACADEMY_OVR_MAX,
  ACADEMY_OVR_MIN, ACADEMY_OVR_TIER_BONUS, ACADEMY_POT_RANGE, ACADEMY_SIZE_MAX,
  ACADEMY_SIZE_MIN, ACADEMY_SIZE_TIER_BONUS, ACADEMY_STARS, ACADEMY_TIER_STR,
  ACADEMY_WEAK_GROUP_P, ATTR_MAX, ATTR_MIN, SQUAD_MAX,
} from './constants';
import type { NamePoolContext } from './leagues';
import {
  ATTR_KEYS, broadGroupOf, computeOvr, computeSalary, computeValue, ensureUniqueNames,
  generatePlayer, type PlayerLike,
} from './players';
import { clamp, pick, randInt, type RNG } from './rng';
import type { Position } from './types';

export type AcademyTier = 'top' | 'mid' | 'low';

/** Тир клуба по силе: ≥ 84 top · 74–83 mid · < 74 low. */
export function academyTierOf(strength: number): AcademyTier {
  if (strength >= ACADEMY_TIER_STR.top) return 'top';
  if (strength >= ACADEMY_TIER_STR.mid) return 'mid';
  return 'low';
}

/** Звёзды потенциала 1..5 (ACADEMY_STARS: pot ≥ 85 → 5★ … < 62 → 1★). */
export function starsOf(potential: number): number {
  for (const row of ACADEMY_STARS) {
    if (potential >= row.min) return row.stars;
  }
  return 1;
}

/** Строка «★★★★★» для UI/новостей. */
export function starsLabelOf(stars: number): string {
  return '★'.repeat(Math.min(5, Math.max(1, stars)));
}

const GROUP_POSITIONS: Record<'GK' | 'DEF' | 'MID' | 'FWD', readonly Position[]> = {
  GK: ['GK'],
  DEF: ['DL', 'DC', 'DR'],
  MID: ['DML', 'DMC', 'DMR', 'ML', 'MC', 'MR', 'AML', 'AMC', 'AMR'],
  FWD: ['ST'],
};

const FIELD_POSITIONS: readonly Position[] = [
  'DL', 'DC', 'DR', 'DML', 'DMC', 'DMR', 'ML', 'MC', 'MR', 'AML', 'AMC', 'AMR', 'ST',
];

/** Слабейшая широкая группа состава по среднему OVR (куда и докидывать молодёжь). */
export function weakestGroupOf(squad: PlayerLike[]): 'GK' | 'DEF' | 'MID' | 'FWD' {
  const groups: ('GK' | 'DEF' | 'MID' | 'FWD')[] = ['GK', 'DEF', 'MID', 'FWD'];
  let worst: 'GK' | 'DEF' | 'MID' | 'FWD' = 'MID';
  let worstAvg = Number.POSITIVE_INFINITY;
  for (const g of groups) {
    const list = squad.filter((p) => broadGroupOf(p.position) === g);
    if (list.length === 0) return g; // пустая группа — самая слабая
    const avg = list.reduce((s, p) => s + p.ovr, 0) / list.length;
    if (avg < worstAvg) {
      worstAvg = avg;
      worst = g;
    }
  }
  return worst;
}

/** Абсолютные границы OVR выпускника: [ACADEMY_OVR_MIN, ACADEMY_OVR_MAX + топ-бонус] = [34, 52]. */
const ACADEMY_OVR_ABS_MAX = ACADEMY_OVR_MAX + ACADEMY_OVR_TIER_BONUS.top;

/** D-5 (§3.2): жёсткий кап POT выпускника с бонусом корпуса академии. */
const ACADEMY_POT_CAP = 93;

/**
 * Нормализация OVR выпускника в диапазон [34, 52] (инвариант QA №8):
 * genAttrs использует гауссов шум (σ = 8) вокруг целевой силы, поэтому итоговый
 * computeOvr отклоняется от цели на ±5–6. Сдвиг ВСЕХ атрибутов на δ сдвигает
 * взвешенное среднее ровно на δ — пересчитываем OVR/потолок/цену/зарплату.
 */
function normalizeAcademyOvr(p: PlayerLike): void {
  if (p.ovr >= ACADEMY_OVR_MIN && p.ovr <= ACADEMY_OVR_ABS_MAX) return;
  const target = clamp(p.ovr, ACADEMY_OVR_MIN, ACADEMY_OVR_ABS_MAX);
  const delta = target - p.ovr;
  for (const key of ATTR_KEYS) {
    p[key] = clamp(p[key] + delta, ATTR_MIN, ATTR_MAX);
  }
  p.ovr = computeOvr(p, p.position);
  p.potential = Math.max(p.potential, p.ovr);
  p.value = computeValue({ ovr: p.ovr, age: p.age, potential: p.potential, morale: p.morale });
  p.salary = computeSalary(p.value);
}

export interface IntakeResult {
  /** Готовые к playerCreateData (isAcademy = true, contractUntil = season + 2). */
  players: PlayerLike[];
  /** «Золотой набор». */
  golden: boolean;
  /** Число «жемчужин» (pot ≥ 85). */
  gemCount: number;
  /** true = состав полон, набор сокращён до 0. */
  skippedNoSpace: boolean;
}

/**
 * Набор ОДНОГО клуба (вызывается для всех клубов сейва одним проходом):
 *  - размер = randInt(2, 4) + tierBonus, кап max(0, SQUAD_MAX − squad);
 *  - возраст: 16 лет с p = 0.8, иначе 17;
 *  - позиции: 1 GK с p = 0.5 (только если в составе < 2 GK моложе 33);
 *    прочие — слабейшая широкая группа состава с p = 0.6, иначе случайная полевая;
 *  - каждый игрок: generatePlayer(rng, randInt(34, 46) + ovrTierBonus, позиция,
 *    { fixedAge, potentialOverride, contractUntil, pool });
 *  - потенциал: randInt по диапазону тира; отдельный бросок «жемчужины»;
 *    «золотой набор» → весь набор +6 к потолку (кап 99) и ≥ 1 жемчужина;
 *  - ensureUniqueNames по составу (pool лиги).
 *
 * D-5 «Территория» (§3.5): опц. бонусы корпуса академии КЛУБА ИГРОКА —
 * sizeBonus (SIZE_BONUS [0,0,0,1,1,2]) прибавляется к размеру набора,
 * potBonus (0.8·L) — к границам ACADEMY_POT_RANGE (кап 93), gemMult
 * (1 + 0.15·L) — к шансу «жемчужины» ACADEMY_GEM_P. Без полей — как раньше.
 */
export function runIntakeForClub(args: {
  rng: RNG;
  season: number;
  team: { id: string; strength: number };
  squad: PlayerLike[];
  pool: NamePoolContext;
  sizeBonus?: number;
  potBonus?: number;
  gemMult?: number;
}): IntakeResult {
  const { rng, season, team, squad, pool } = args;
  const tier = academyTierOf(team.strength);
  const sizeBonus = args.sizeBonus ?? 0;
  const potBonus = args.potBonus ?? 0;
  const gemMult = args.gemMult ?? 1;

  let size = randInt(rng, ACADEMY_SIZE_MIN, ACADEMY_SIZE_MAX)
    + ACADEMY_SIZE_TIER_BONUS[tier]
    + sizeBonus;
  size = Math.min(size, Math.max(0, SQUAD_MAX - squad.length));
  if (size <= 0) {
    return { players: [], golden: false, gemCount: 0, skippedNoSpace: true };
  }

  const golden = rng() < ACADEMY_GOLDEN_P;
  // Золотой набор гарантирует ≥ 1 жемчужину — заранее выбираем её слот
  const gemSlot = golden ? randInt(rng, 0, size - 1) : -1;

  const youngGk = squad.filter(
    (p) => p.position === 'GK' && p.age < ACADEMY_GK_MAX_AGE,
  ).length;
  const wantGk = youngGk < ACADEMY_GK_YOUNG_MAX && rng() < ACADEMY_GK_P;

  // D-5: границы потенциала тира + potBonus корпуса академии (кап 93, §3.2)
  const potShift = Math.round(potBonus);
  const potRange: [number, number] = [
    Math.min(ACADEMY_POT_CAP, ACADEMY_POT_RANGE[tier][0] + potShift),
    Math.min(ACADEMY_POT_CAP, ACADEMY_POT_RANGE[tier][1] + potShift),
  ];
  if (potRange[1] < potRange[0]) potRange[1] = potRange[0];
  const ovrBonus = ACADEMY_OVR_TIER_BONUS[tier];
  const weakGroup = weakestGroupOf(squad);

  const players: PlayerLike[] = [];
  let gemCount = 0;

  for (let i = 0; i < size; i++) {
    const age = rng() < ACADEMY_AGE_16_P ? 16 : 17;

    let position: Position;
    if (i === 0 && wantGk) {
      position = 'GK';
    } else if (rng() < ACADEMY_WEAK_GROUP_P) {
      position = pick(rng, GROUP_POSITIONS[weakGroup]);
    } else {
      position = pick(rng, FIELD_POSITIONS);
    }

    const ovrTarget = randInt(rng, ACADEMY_OVR_MIN, ACADEMY_OVR_MAX) + ovrBonus;
    let potential = randInt(rng, potRange[0], potRange[1]);
    let gem = false;
    if (rng() < ACADEMY_GEM_P[tier] * gemMult) {
      potential = randInt(rng, ACADEMY_GEM_POT[0], ACADEMY_GEM_POT[1]);
      gem = true;
    }
    if (i === gemSlot && !gem) {
      potential = randInt(rng, ACADEMY_GEM_POT[0], ACADEMY_GEM_POT[1]);
      gem = true;
    }
    if (golden) potential = Math.min(99, potential + ACADEMY_GOLDEN_BONUS);
    if (gem) gemCount += 1;

    players.push(
      generatePlayer(rng, ovrTarget, position, {
        fixedAge: age,
        potentialOverride: potential,
        contractUntil: season + 2, // молодёжный договор на 3 года (S, S+1, S+2)
        pool,
      }),
    );
  }

  // Инвариант QA №8: OVR воспитанника ∈ [34, 52] несмотря на шум genAttrs
  for (const p of players) normalizeAcademyOvr(p);

  // Уникальные имена по составу (состав идёт первым — его имена не трогаем)
  ensureUniqueNames(rng, [...squad, ...players], pool);
  for (const p of players) p.isAcademy = true;

  return { players, golden, gemCount, skippedNoSpace: false };
}

/**
 * Тексты новостей отчёта о наборе для клуба игрока: список игроков со звёздами,
 * «Наибольшие надежды — {лучший}», спец-новость при золотом наборе,
 * «нет мест» при skippedNoSpace.
 */
export function intakeNews(args: { teamName: string; result: IntakeResult }): string[] {
  const { result } = args;
  if (result.skippedNoSpace) {
    return ['Академия: в составе нет свободных мест — набор воспитанников отменён.'];
  }
  const news: string[] = [];
  if (result.golden) {
    news.push('Академия: ЗОЛОТОЙ НАБОР! Юные таланты этого года — будущие звёзды мирового футбола.');
  }
  for (const p of result.players) {
    news.push(
      `Академия: ${p.firstName} ${p.lastName} — ${p.position}, ${p.age} лет, OVR ${p.ovr}, потенциал ${starsLabelOf(starsOf(p.potential))}.`,
    );
  }
  if (result.players.length > 0) {
    const best = [...result.players].sort((a, b) => b.potential - a.potential)[0];
    news.push(
      `Наибольшие надежды — ${best.firstName} ${best.lastName} (${starsLabelOf(starsOf(best.potential))}).`,
    );
  }
  return news;
}

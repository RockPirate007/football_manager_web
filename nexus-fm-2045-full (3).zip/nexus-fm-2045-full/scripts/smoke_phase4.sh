#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Smoke-тест Фазы 4 (Task P4-5): стили тренеров, план на матч, сегментный
# движок (замены/ЖК), Кубок Европы (жеребьёвка/гости/призы), congestion-неделя,
# изоляция гостей, сезонный переход с евро-квалификацией, легаси-совместимость,
# каскадное удаление. Запуск: bash scripts/smoke_phase4.sh
# Требует: работающий dev-сервер на :3000, jq, python3 (sqlite3), bun.
# Идемпотентен: чистит ТОЛЬКО свои сейвы «P4-Smoke EPL» / «P4-Smoke RPL».
# Опции: P4_KEEP=1 — не удалять RPL-сейв в конце (для браузерных проверок;
#         повторный запуск без P4_KEEP подчистит); SMOKE_ONLY_CLEANUP=1 —
#         только секции 0+10 (уборка остатков прошлого прогона).
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."

BASE="http://localhost:3000/api/game"
DB="python3 scripts/qa4_db.py"
TMP=$(mktemp -d)
PASS=0
FAIL=0
PASS_BEFORE=0

ok()  { PASS=$((PASS + 1)); echo "  ✔ $*"; }
bad() { FAIL=$((FAIL + 1)); echo "  ✘ $*"; }
section() { echo; echo "── $* ─────────────────────────────────"; PASS_BEFORE=$PASS; }
section_result() {
  local sec_pass=$((PASS - PASS_BEFORE)) sec_fail=$FAIL
  echo "  ══ секция: PASS=$sec_pass FAIL=$sec_fail"
}

call() { # call METHOD URL [json-body] → BODY, CODE
  local method="$1" url="$2" body="${3:-}"
  if [ -n "$body" ]; then
    BODY=$(curl -s -m 180 -w $'\n%{http_code}' -X "$method" -H 'Content-Type: application/json' -d "$body" "$url")
  else
    BODY=$(curl -s -m 180 -w $'\n%{http_code}' -X "$method" "$url")
  fi
  CODE=$(echo "$BODY" | tail -n1)
  BODY=$(echo "$BODY" | sed '$d')
}

check() { # check "desc" "jq-expr" "expected" — по последнему BODY
  local desc="$1" expr="$2" expected="$3" actual
  actual=$(echo "$BODY" | jq -r "$expr" 2>/dev/null)
  if [ "$actual" = "$expected" ]; then ok "$desc ($actual)"
  else bad "$desc: ожидалось '$expected', получено '$actual'"; fi
}

check_eq() { # check_eq "desc" "фактическое" "ожидание"
  if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1: ожидалось '$3', получено '$2'"; fi
}

check_code() {
  if [ "$CODE" = "$2" ]; then ok "$1 (HTTP $CODE)"
  else bad "$1: ожидался HTTP $2, получен $CODE"; fi
}

dbv() { # dbv <saveId> <cmd> <key> [args...] → значение ключа qa4_db.py
  # $1=saveId $2=cmd $3=key; в qa4_db.py передаются cmd, saveId и ТОЛЬКО args ($4+)
  $DB "$2" "$1" "${@:4}" 2>/dev/null | grep "^${3}=" | head -n1 | cut -d= -f2
}

dbq() { $DB "$2" "$1" "${@:3}" 2>/dev/null; }

simulate() { call POST "$BASE/simulate" "{\"saveId\":\"$1\"}"; }

ONLY_CLEANUP="${SMOKE_ONLY_CLEANUP:-0}"
KEEP="${P4_KEEP:-0}"

# ═══ 0. Очистка только СВОИХ тест-сейвов ═════════════════════════════════════
section "0. Очистка своих сейвов P4-Smoke (демо-карьеры не трогаем)"

call GET "$BASE/saves"
check_code "GET /saves" 200
SAVES_BODY="$BODY"
for sid in $(echo "$SAVES_BODY" | jq -r '.saves[] | select(.careerName=="P4-Smoke EPL" or .careerName=="P4-Smoke RPL") | .id'); do
  call DELETE "$BASE/saves/$sid"
  if [ "$CODE" = "200" ]; then ok "удалён остаток прошлого прогона: $sid"; else bad "не удалось удалить $sid (HTTP $CODE)"; fi
done
DEMO_COUNT=$(echo "$SAVES_BODY" | jq -r '[.saves[] | select(.careerName!="P4-Smoke EPL" and .careerName!="P4-Smoke RPL")] | length')
echo "  … чужих карьер не тронуто: $DEMO_COUNT"
section_result

if [ "$ONLY_CLEANUP" = "1" ]; then
  echo
  echo "════════════════════════════════════════════════════════════════"
  echo "ИТОГ SMOKE PHASE 4 (cleanup-only): PASS=$PASS FAIL=$FAIL"
  echo "════════════════════════════════════════════════════════════════"
  rm -rf "$TMP"; [ "$FAIL" = "0" ]; exit $?
fi

# ═══ 1. Новая карьера EPL: стили назначены, план на матч = дефолт ════════════
section "1. Новая карьера EPL: стили всех НЕ-гостей + matchPlan null → дефолт"

call POST "$BASE/saves" '{"leagueCode":"EPL","clubIndex":0,"managerName":"Smoke P4-5","careerName":"P4-Smoke EPL"}'
check_code "POST /saves (EPL, Манчестер Сити)" 200
EPL=$(echo "$BODY" | jq -r '.saveId')
check "saveId выдан" '.saveId != null and .ok' 'true'
check "клуб — Манчестер Сити" '.club.shortName' 'MCI'

STYLES_OUT=$(dbq "$EPL" styles)
STYLES_TOTAL=$(echo "$STYLES_OUT" | grep '^teams_total=' | cut -d= -f2)
AI_TEAMS=$(echo "$STYLES_OUT" | grep '^ai_teams=' | cut -d= -f2)
check_eq "все 20 клубов EPL — НЕ-гости (стили назначаются всем)" "$STYLES_TOTAL" "20"
check_eq "ИИ-клубов в сейве" "$AI_TEAMS" "19"
check_eq "aiStyle ∈ 5 значений у всех ИИ (§9.6)" "$(echo "$STYLES_OUT" | grep '^ai_style_valid=' | cut -d= -f2)" "$AI_TEAMS"
check_eq "aiCoachName не пуст у всех ИИ" "$(echo "$STYLES_OUT" | grep '^ai_coach_missing=' | cut -d= -f2)" "0"
RECOGNIZABLE=$(echo "$STYLES_OUT" | grep '^ai_recognizable_pct=' | cut -d= -f2)
RECOG_OK=$(python3 -c "print('true' if $RECOGNIZABLE >= 25 else 'false')" 2>/dev/null)
check_eq "узнаваемых стилей (gegenpress/tikitaka/bus/vertical) ≥ 25% (§9.6)" "$RECOG_OK" "true"
echo "  … распределение стилей: $(echo "$STYLES_OUT" | grep '^style_dist=' | cut -d= -f2)"
check_eq "matchPlan клуба игрока = null (новый сейв)" "$(dbv "$EPL" styles user_matchplan_null)" "1"

call GET "$BASE/matchplan?saveId=$EPL"
check_code "GET /matchplan (новый сейв)" 200
check "дефолт: leadMode=park" '.plan.leadMode' 'park'
check "дефолт: chaseMode=allout" '.plan.chaseMode' 'allout'
check "дефолт: fatigueSubs=true" '.plan.fatigueSubs' 'true'
section_result

# ═══ 2. GET/POST /matchplan: контракты API (§9.16) ══════════════════════════
section "2. GET/POST /matchplan: запись плана, мусор → 400, чужой сейв → 404"

call POST "$BASE/matchplan" "{\"saveId\":\"$EPL\",\"leadMode\":\"park\",\"chaseMode\":\"steady\",\"fatigueSubs\":false}"
check_code "POST валидный план" 200
check "ответ: chaseMode=steady" '.plan.chaseMode' 'steady'
check "ответ: fatigueSubs=false" '.plan.fatigueSubs' 'false'
call GET "$BASE/matchplan?saveId=$EPL"
check_code "GET после записи" 200
check "GET подтверждает: leadMode=park" '.plan.leadMode' 'park'
check "GET подтверждает: chaseMode=steady" '.plan.chaseMode' 'steady'
check "GET подтверждает: fatigueSubs=false" '.plan.fatigueSubs' 'false'

call POST "$BASE/matchplan" "{\"saveId\":\"$EPL\",\"leadMode\":\"banana\"}"
check_code "POST мусорный leadMode → 400" 400
check "код INVALID_MATCH_PLAN" '.error' 'INVALID_MATCH_PLAN'
call POST "$BASE/matchplan" '{"saveId":'
check_code "POST битый JSON → 400" 400
check "код INVALID_MATCH_PLAN (битый JSON)" '.error' 'INVALID_MATCH_PLAN'
call POST "$BASE/matchplan" '{"saveId":"00000000-0000-0000-0000-000000000000","leadMode":"hold"}'
check_code "POST чужой saveId → 404" 404
call GET "$BASE/matchplan?saveId=00000000-0000-0000-000000000000"
check_code "GET чужой saveId → 404" 404

# возвращаем дефолт (смоук-сценарий далее идёт с планом по умолчанию)
call POST "$BASE/matchplan" "{\"saveId\":\"$EPL\",\"leadMode\":\"park\",\"chaseMode\":\"allout\",\"fatigueSubs\":true}"
check_code "POST возврат дефолта" 200
section_result

# ═══ 3. Сегментный движок: 5 недель EPL, события матча ══════════════════════
section "3. Сегментный движок: недели 1–5 EPL, события/замены/минуты/ЖК"

EPL_MATCH_IDS=""
SUBS_TOTAL=0
for w in 1 2 3 4 5; do
  simulate "$EPL"
  check_code "неделя $w EPL" 200
  check "неделя $w: 1 матч клуба игрока (лига)" '.result.userMatches | length' '1'
  check "неделя $w: competition=league" '.result.userMatches[0].competition' 'league'
  MID=$(echo "$BODY" | jq -r '.result.userMatches[0].matchId')
  EPL_MATCH_IDS="$EPL_MATCH_IDS $MID"
done

# GET /match по каждому матчу: валидность ленты
for MID in $EPL_MATCH_IDS; do
  call GET "$BASE/match?saveId=$EPL&id=$MID"
  check_code "GET /match $MID" 200
  check "события непусты" '.match.events | length > 0' 'true'
  check "минуты 1..93 (кроме пен. и kickoff=0)" '[.match.events[] | select((.type | startswith("pen_")) | not) | select(.type != "kickoff") | .minute] | all(. >= 1 and . <= 93)' 'true'
  check "события отсортированы по минуте" '[.match.events[].minute] as $a | $a == ($a | sort)' 'true'
done

# Глубокая проверка по БД: замены ≤5/команду, пары имён, авторы голов из состава
EVOUT=$(dbq "$EPL" eventscheck $EPL_MATCH_IDS)
check_eq "замены ≤5/команду, минуты/типы/сортировка, авторы голов из XI∪бенча" \
  "$(echo "$EVOUT" | grep '^eventscheck_ok=' | cut -d= -f2 | cut -d/ -f1)" "5"
SUBS_TOTAL=$(python3 -c "
import sqlite3, json
con = sqlite3.connect('db/custom.db')
n = 0
for mid in '$EPL_MATCH_IDS'.split():
    evs = json.loads(con.execute('SELECT events FROM Match WHERE id=?', (mid,)).fetchone()[0] or '[]')
    n += sum(1 for e in evs if e['type'] == 'sub')
print(n)")
if [ "${SUBS_TOTAL:-0}" -ge 1 ]; then ok "события 'sub' встречаются (всего $SUBS_TOTAL за 5 матчей)"; else bad "ни одной замены за 5 матчей"; fi
echo "  … (справочно) замен суммарно: $SUBS_TOTAL — не во всех матчах обязательны"

# ЖК: база 1.9 → ≈3.81/матч (санити: есть в каждом матче почти всегда)
YELLOW_AVG=$(dbv "$EPL" yellowstats yellows_avg)
YELLOW_N=$(dbv "$EPL" yellowstats full_engine_matches)
YELLOW_OK=$(python3 -c "print('true' if 1.8 <= float('${YELLOW_AVG:-0}') <= 6.0 else 'false')" 2>/dev/null)
check_eq "ЖК выросли: среднее $YELLOW_AVG/матч за $YELLOW_N матчей (base 1.9, коридор санити 1.8–6.0)" "$YELLOW_OK" "true"
echo "  … строгий коридор ЖК проверяется в секции 8 (полный сезон)"
section_result

# ═══ 4. Калибровка движка (§9.1) ════════════════════════════════════════════
section "4. Калибровка: bun scripts/calibrate_segments.ts (коридор §9.1)"

CALIB_OUT=$(bun scripts/calibrate_segments.ts 2>&1)
CALIB_GATE=$(echo "$CALIB_OUT" | grep '^GATE=' | head -n1 | cut -d= -f2)
CALIB_HOME=$(echo "$CALIB_OUT" | grep -oP 'home=\K[0-9.]+%' | head -n1)
CALIB_DRAW=$(echo "$CALIB_OUT" | grep -oP 'draw=\K[0-9.]+%' | head -n1)
CALIB_GOALS=$(echo "$CALIB_OUT" | grep -oP 'goals/match=\K[0-9.]+' | head -n1)
CALIB_YELLOWS=$(echo "$CALIB_OUT" | grep -oP 'yellows/match=\K[0-9.]+' | head -n1)
check_eq "GATE калибровки" "$CALIB_GATE" "PASS"
echo "  … [A/balanced] home=$CALIB_HOME draw=$CALIB_DRAW goals=$CALIB_GOALS yellows=$CALIB_YELLOWS (коридор: home 44–48 / draw 24–27 / goals 2.6–2.9)"
section_result

# ═══ 5. Кубок Европы: RPL до недели 8 (§9.7) ════════════════════════════════
section "5. Кубок Европы: жеребьёвка 1/8, 16 участников, гости, призы, евро-голы"

call POST "$BASE/saves" '{"leagueCode":"RPL","clubIndex":0,"managerName":"Smoke P4-5","careerName":"P4-Smoke RPL"}'
check_code "POST /saves (RPL, Краснодар)" 200
RPL=$(echo "$BODY" | jq -r '.saveId')
check "клуб — Краснодар" '.club.shortName' 'KRD'

for w in 1 2 3 4 5 6 7; do
  simulate "$RPL"
  check_code "неделя $w RPL" 200
  if [ "$w" = "7" ]; then
    # срез состояния ДО congestion-недели (секция 6)
    dbq "$RPL" snapcond > "$TMP/cond_before_w8.txt"
    echo "  … срез состояния состава снят: $(wc -l < "$TMP/cond_before_w8.txt") игроков"
  fi
done

# неделя 8: кубок (1/8 нац. кубка) + евро (1/8) — congestion
simulate "$RPL"
check_code "неделя 8 (кубок + евро)" 200
check "неделя 8: 2 матча клуба игрока" '.result.userMatches | length' '2'
check "матч 1 — национальный кубок" '.result.userMatches[0].competition' 'cup'
check "матч 2 — Кубок Европы" '.result.userMatches[1].competition' 'euro'
CUP_MID=$(echo "$BODY" | jq -r '.result.userMatches[0].matchId')
EURO_MID=$(echo "$BODY" | jq -r '.result.userMatches[1].matchId')
check "европризовые в финансах недели" '.result.finances.euroPrize > 0' 'true'
check "евро-новость в ленте" '[.result.news[] | select(.type=="euro")] | length > 0' 'true'
echo "  … счёт евроматча: $(echo "$BODY" | jq -r '.result.userMatches[1] | "\(.home.shortName) \(.homeGoals):\(.awayGoals) \(.away.shortName) (пен. \(.homePens // "—"))"')"

EW=$(dbq "$RPL" euroweek 1 8)
check_eq "матчей 1/8 евро" "$(echo "$EW" | grep '^euro_matches=' | cut -d= -f2)" "8"
check_eq "все сыграны" "$(echo "$EW" | grep '^euro_played=' | cut -d= -f2)" "8"
check_eq "победители определены (пен. при ничьих)" "$(echo "$EW" | grep '^euro_winners=' | cut -d= -f2)" "8"
echo "  … серий пенальти в 1/8: $(echo "$EW" | grep '^euro_pens=' | cut -d= -f2)"
check_eq "16 участников (квоты 3+3+3+3+2+2)" "$(echo "$EW" | grep '^participants=' | cut -d= -f2)" "16"
check_eq "своих клубов РПЛ — 2 (квота)" "$(echo "$EW" | grep '^own_teams=' | cut -d= -f2)" "2"
check_eq "гостей — 14" "$(echo "$EW" | grep '^guests=' | cut -d= -f2)" "14"
echo "  … лиги гостей: $(echo "$EW" | grep '^guest_leagues=' | cut -d= -f2)"
check_eq "НЕТ пар одной лиги в 1/8 (§9.7)" "$(echo "$EW" | grep '^same_league_pairs=' | cut -d= -f2)" "0"
GUEST_MIN=$(echo "$EW" | grep '^guest_min_squad=' | cut -d= -f2)
GUEST_MIN_OK=$(python3 -c "print('true' if $GUEST_MIN >= 18 else 'false')" 2>/dev/null)
check_eq "составы гостей ≥ 18 (минимум $GUEST_MIN)" "$GUEST_MIN_OK" "true"
check_eq "матч клуба игрока — полный движок (stats не null)" "$(echo "$EW" | grep '^user_stats_nonnull=' | cut -d= -f2)" "1"
check_eq "halftime-событие в полном движке" "$(echo "$EW" | grep '^user_has_halftime=' | cut -d= -f2)" "1"
check_eq "прочие 7 матчей — БЕЗ stats" "$(echo "$EW" | grep '^ai_stats_nonnull=' | cut -d= -f2)" "0"
EG=$(echo "$EW" | grep '^euro_goals_sum=' | cut -d= -f2)
EG_OK=$(python3 -c "print('true' if $EG >= 5 else 'false')" 2>/dev/null)
check_eq "евро-голы в euroGoals игроков (сумма $EG ≥ 5)" "$EG_OK" "true"

# призы euro_prize в FinanceRecord клуба игрока
FE=$(dbq "$RPL" financeeuro)
FEN=$(echo "$FE" | grep '^euro_prize_records=' | cut -d= -f2)
FES=$(echo "$FE" | grep '^euro_prize_sum=' | cut -d= -f2)
FES_OK=$(python3 -c "print('true' if $FEN >= 1 and $FES >= 2000000 else 'false')" 2>/dev/null)
check_eq "призовые euro_prize в FinanceRecord: записей $FEN, сумма €$FES (участие €2M+)" "$FES_OK" "true"

# GET /euro: снапшот турнира
call GET "$BASE/euro?saveId=$RPL"
check_code "GET /euro" 200
check "статус турнира валиден (alive/eliminated — победа/поражение в 1/8 легитимны)" '.euro.status == "alive" or .euro.status == "qualified" or .euro.status == "eliminated"' 'true'
check "сетка: раунд 1 с 8 матчами" '[.euro.rounds[] | select(.round==1) | .matches[]] | length' '8'
check "16 карточек участников" '.euro.participants | length' '16'
check "квоты 6 лиг" '.euro.quotas | length' '6'
check "следующий раунд отрисован (1/4)" '.euro.rounds[] | select(.round==2) | .drawn' 'true'
section_result

# ═══ 6. Congestion-неделя 8: drain×2 − recovery×1 (§9.8) ════════════════════
section "6. Congestion: 2 матча за неделю, recovery +8 ровно 1× (допуск ±2)"

CG=$(dbq "$RPL" congestion "$CUP_MID" "$EURO_MID" "$TMP/cond_before_w8.txt")
CGQ=$(echo "$CG" | grep '^qualified=' | cut -d= -f2)
CGW=$(echo "$CG" | grep '^within2=' | cut -d= -f2)
echo "  … темп/прессинг клуба: $(echo "$CG" | grep '^tempo=' | cut -d= -f2) (drain = max(8, 22 − stamina/12))"
if [ "${CGQ:-0}" -ge 3 ]; then
  check_eq "игравшие оба матча: дельта = −drain×2 + 8 (±2) у $CGW из $CGQ" "$CGW" "$CGQ"
else
  if [ "${CGQ:-0}" -ge 1 ]; then
    check_eq "мало кандидатов ($CGQ из-за ротации/замен), но все в допуске" "$CGW" "$CGQ"
  else
    bad "нет игроков, сыгравших оба матча полные 90 (ротация евро-состава) — формула непроверяема"
  fi
fi
echo "  … неигравших ни одного матча: $(echo "$CG" | grep '^bench_neither=' | cut -d= -f2) (ожидаемая дельта +8)"
for mm in $(echo "$CG" | grep '^mismatch=' | head -n3); do echo "    ⚠ $mm"; done
section_result

# ═══ 7. Изоляция гостей: 7 мест (§5.5/§9.7) ═════════════════════════════════
section "7. Изоляция гостей: таблица/рынок/награды/лидеры/кубок/босман/академия"

call GET "$BASE/state?saveId=$RPL"
check_code "GET /state (неделя 9)" 200
echo "$BODY" | jq '[.snapshot.standings[].teamId] + [.snapshot.teams[].id]' > "$TMP/standings_ids.json"
echo "$BODY" | jq '[.snapshot.cup.rounds[].matches[] | .home.id, .away.id]' > "$TMP/cup_ids.json"
echo "$BODY" | jq '[.snapshot.leaders.topScorers[].teamId] + [.snapshot.leaders.topAssists[].teamId]' > "$TMP/leaders_ids.json"

call GET "$BASE/market?saveId=$RPL"
check_code "GET /market" 200
echo "$BODY" | jq '[.listings[].player.teamId]' > "$TMP/market_ids.json"

call GET "$BASE/awards?saveId=$RPL"
check_code "GET /awards" 200
echo "$BODY" > "$TMP/awards_live.json"
check "topEuroScorers в live-ответе (контракт Фазы 4)" '.live.topEuroScorers != null' 'true'

ISO=$(dbq "$RPL" isolation "$TMP/standings_ids.json" "$TMP/market_ids.json" "$TMP/cup_ids.json" "$TMP/leaders_ids.json")
check_eq "гостей в сейве" "$(echo "$ISO" | grep '^guest_ids=' | cut -d= -f2)" "14"
check_eq "1) таблица+список команд /state без гостей" "$(echo "$ISO" | grep '^standings_guests=' | cut -d= -f2)" "0"
check_eq "2) трансфер-рынок: лоты только НЕ-гости" "$(echo "$ISO" | grep '^market_guests=' | cut -d= -f2)" "0"
check_eq "3) бомбардиры/ассистенты лиги (leaders) без гостей" "$(echo "$ISO" | grep '^leaders_guests=' | cut -d= -f2)" "0"
check_eq "4) жеребьёвка нац. кубка без гостей" "$(echo "$ISO" | grep '^cup_guests=' | cut -d= -f2)" "0"
check_eq "5) босман не затрагивает гостей (preContract=null)" "$(echo "$ISO" | grep '^bosman_guests=' | cut -d= -f2)" "0"
check_eq "6) академия не затрагивает гостей (isAcademy=0)" "$(echo "$ISO" | grep '^academy_guests=' | cut -d= -f2)" "0"
check_eq "7) контракты гостей = 99 (вне системы контрактов)" "$(echo "$ISO" | grep '^guest_bad_contracts=' | cut -d= -f2)" "0"

ESC=$(dbq "$RPL" euroscorers "$TMP/awards_live.json")
check_eq "GET /awards live: лиговые лидеры без гостей" "$(echo "$ESC" | grep '^league_leaders_guests=' | cut -d= -f2)" "0"
ESC_GUESTS=$(echo "$ESC" | grep '^topEuroScorers_guests=' | cut -d= -f2)
ESC_LEN=$(echo "$ESC" | grep '^topEuroScorers_len=' | cut -d= -f2)
ESC_OK=$(python3 -c "print('true' if $ESC_LEN >= 5 and $ESC_GUESTS >= 1 else 'false')" 2>/dev/null)
check_eq "GET /awards live: topEuroScorers с гостями (лист $ESC_LEN, гостей $ESC_GUESTS)" "$ESC_OK" "true"
section_result

# ═══ 8. Сезонный переход: недели 9–34 + евро-финал + квалификация ════════════
section "8. Сезонный переход: финал недели 34, снапшоты, квалификация, дренаж"

W34_BODY=""
for w in $(seq 9 34); do
  simulate "$RPL"
  if [ "$CODE" != "200" ]; then
    bad "неделя $w: HTTP $CODE — $(echo "$BODY" | head -c 200)"
    break
  fi
  N_MATCHES=$(echo "$BODY" | jq -r '.result.userMatches | length')
  if [ "$w" = "16" ] || [ "$w" = "24" ]; then
    if [ "$N_MATCHES" = "2" ]; then ok "неделя $w: 2 матча (кубок+евро)"; else ok "неделя $w: $N_MATCHES матч(а) (клуб выбыл в одном из турниров)"; fi
  fi
  if [ "$w" = "34" ]; then W34_BODY="$BODY"; fi
done
if [ -n "$W34_BODY" ]; then
  ok "недели 9–34 отыграны"
  check "неделя 34: сезонный переход" '.result.seasonEnded != null' 'true'
  check "неделя 34: евро-итог в seasonEnded" '.result.seasonEnded.euro != null' 'true'
  echo "  … евро-итог: $(echo "$W34_BODY" | jq -r '.result.seasonEnded.euro.label') (квалификация: $(echo "$W34_BODY" | jq -r '.result.seasonEnded.euro.qualifiedNext'))"
else
  bad "финальная неделя не доиграна"
fi

SE=$(dbq "$RPL" seasonend 1)
check_eq "еврофинал (неделя 34) сыгран" "$(echo "$SE" | grep '^euro_final_played=' | cut -d= -f2)" "1"
echo "  … чемпион Европы: $(echo "$SE" | grep '^euro_champion=' | cut -d= -f2)"
check_eq "квалификация следующего сезона: euroSeason=2" "$(echo "$SE" | grep '^euro_season_next=' | cut -d= -f2)" "2"
check_eq "euroRound сброшен в 0" "$(echo "$SE" | grep '^euro_round_next=' | cut -d= -f2)" "0"
check_eq "16 участников нового сезона" "$(echo "$SE" | grep '^participants_next=' | cut -d= -f2)" "16"
check_eq "euroAlive = 16 (сброшено на новый розыгрыш)" "$(echo "$SE" | grep '^alive_next=' | cut -d= -f2)" "16"
echo "  … клуб игрока квалифицировался: $(echo "$SE" | grep '^user_qualified_next=' | cut -d= -f2) · гостей: $(echo "$SE" | grep '^guests=' | cut -d= -f2)"

call GET "$BASE/awards?saveId=$RPL&season=1"
check_code "GET /awards сезона 1" 200
check "награды сезона: все 8 типов" '([.awards[].type] | sort) == (["champion","cup_scorer","cup_winner","golden_glove","mvp","top_assist","top_scorer","young"] | sort)' 'true'

RECS=$(echo "$SE" | grep '^records=' | cut -d= -f2)
RECS_OK=$(python3 -c "print('true' if $RECS >= 550 else 'false')" 2>/dev/null)
check_eq "PlayerSeasonRecord сезона 1: $RECS строк (лига ~400 + гости)" "$RECS_OK" "true"
GREC=$(echo "$SE" | grep '^guest_records=' | cut -d= -f2)
GREC_OK=$(python3 -c "print('true' if $GREC >= 250 else 'false')" 2>/dev/null)
check_eq "записей гостей в снапшоте истории: $GREC (§9.13, ≥ 250)" "$GREC_OK" "true"
REG=$(echo "$SE" | grep '^records_euro_goals=' | cut -d= -f2)
REG_OK=$(python3 -c "print('true' if $REG >= 5 else 'false')" 2>/dev/null)
check_eq "снапшоты с euroGoals (сумма $REG ≥ 5)" "$REG_OK" "true"
check_eq "легаси-инвариант №5: возраст записи = возраст ДО старения" "$(echo "$SE" | grep '^age_violations=' | cut -d= -f2)" "0"
AI_MIN=$(echo "$SE" | grep '^ai_min_squad=' | cut -d= -f2)
AI_MIN_OK=$(python3 -c "print('true' if $AI_MIN >= 15 else 'false')" 2>/dev/null)
check_eq "ИИ-составы ≥ 15 после дренажа 30/60 (минимум $AI_MIN)" "$AI_MIN_OK" "true"
GUEST_MIN2=$(echo "$SE" | grep '^guest_min_squad=' | cut -d= -f2)
GUEST_MIN2_OK=$(python3 -c "print('true' if $GUEST_MIN2 >= 18 else 'false')" 2>/dev/null)
check_eq "составы гостей ≥ 18 после регена (минимум $GUEST_MIN2)" "$GUEST_MIN2_OK" "true"
echo "  … свободных агентов в пуле: $(echo "$SE" | grep '^free_agents=' | cut -d= -f2) (осознанное изменение CONTRACT_DRAIN 30/60 — пул сокращается)"
echo "  … распределение стилей после перехода (смена p=0.25, не инвариант): $(echo "$SE" | grep '^style_dist=' | cut -d= -f2)"

# строгий коридор ЖК за сезон (base 1.9: ≈3.81/матч; старая база 1.2 давала ≈2.4)
YS=$(dbq "$RPL" yellowstats)
YS_N=$(echo "$YS" | grep '^full_engine_matches=' | cut -d= -f2)
YS_AVG=$(echo "$YS" | grep '^yellows_avg=' | cut -d= -f2)
YS_OK=$(python3 -c "print('true' if 3.0 <= float('${YS_AVG:-0}') <= 5.0 else 'false')" 2>/dev/null)
check_eq "ЖК за сезон: $YS_AVG/матч за $YS_N полных матчей ∈ [3.0, 5.0] (осознанное изменение Фазы 4)" "$YS_OK" "true"

call GET "$BASE/state?saveId=$RPL"
check_code "GET /state: сезон 2 открыт" 200
check "сезон 2, неделя 1" '.snapshot.save.season == 2 and .snapshot.save.week == 1' 'true'
check "таблица нового сезона пуста" '([.snapshot.standings[] | select(.played > 0)] | length) == 0' 'true'
section_result

# ═══ 9. Легаси-сейвы живы (read-only) ════════════════════════════════════════
section "9. Легаси-сейвы живы: «QA · История игроков», «P4 Test»"

# «P4 Test» — имя менеджера (careerName автогенерирован «Краснодар · Сезон 1»)
for CAREER in "QA · История игроков" "P4 Test"; do
  LID=$(echo "$SAVES_BODY" | jq -r ".saves[] | select(.careerName==\"$CAREER\" or .managerName==\"$CAREER\") | .id" | head -n1)
  if [ -n "$LID" ]; then
    call GET "$BASE/state?saveId=$LID"
    check_code "GET /state «$CAREER»" 200
    check "«$CAREER»: статус в снапшоте" '.snapshot.save.status == "active" or .snapshot.save.status == "finished"' 'true'
  else
    bad "легаси-сейв «$CAREER» не найден в списке карьер"
  fi
done
section_result

# ═══ 10. Каскадное удаление тестового сейва ═════════════════════════════════
section "10. Каскадное удаление: 0 записей во всех таблицах"

call DELETE "$BASE/saves/$EPL"
check_code "DELETE EPL-сейва" 200
CAS=$(dbq "$EPL" cascade)
CAS_LEFT=$(echo "$CAS" | grep -v '=0$' | wc -l)
check_eq "таблиц с остатками записей EPL-сейва (все = 0)" "$CAS_LEFT" "0"
call GET "$BASE/state?saveId=$EPL"
check_code "GET /state удалённого EPL → 404" 404

if [ "$KEEP" = "1" ]; then
  echo "  … P4_KEEP=1: RPL-сейв $RPL СОХРАНЁН для браузерных проверок (не забудь SMOKE_ONLY_CLEANUP=1 после)"
else
  call DELETE "$BASE/saves/$RPL"
  check_code "DELETE RPL-сейва" 200
  CAS2=$(dbq "$RPL" cascade)
  CAS2_LEFT=$(echo "$CAS2" | grep -v '=0$' | wc -l)
  check_eq "таблиц с остатками записей RPL-сейва" "$CAS2_LEFT" "0"
  call GET "$BASE/state?saveId=$RPL"
  check_code "GET /state удалённого RPL → 404" 404
fi
section_result

rm -rf "$TMP"
echo
echo "════════════════════════════════════════════════════════════════"
echo "ИТОГ SMOKE PHASE 4: PASS=$PASS FAIL=$FAIL"
[ "$KEEP" = "1" ] && echo "(RPL-сейв сохранён: P4_KEEP=1)"
echo "════════════════════════════════════════════════════════════════"
[ "$FAIL" = "0" ]

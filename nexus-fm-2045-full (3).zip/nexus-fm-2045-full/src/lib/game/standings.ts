/**
 * Таблица лиги на лету из сыгранных матчей.
 * Раздел 4.14 docs/architecture.md.
 */

import type { FormResult, StandingRow } from './types';

export interface StandingTeamInput {
  id: string;
  name: string;
  shortName: string;
  colorPrimary: string;
  colorSecondary: string;
  isUser: boolean;
}

export interface StandingMatchInput {
  homeTeamId: string;
  awayTeamId: string;
  homeGoals: number;
  awayGoals: number;
  week: number;
}

interface TeamAcc {
  team: StandingTeamInput;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  points: number;
  results: { week: number; result: FormResult }[];
}

/** Сортировка: очки → разница мячей → забитые → имя (по алфавиту). */
export function computeStandings(
  teams: StandingTeamInput[],
  matches: StandingMatchInput[],
): StandingRow[] {
  const accs = new Map<string, TeamAcc>();
  for (const team of teams) {
    accs.set(team.id, {
      team,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      points: 0,
      results: [],
    });
  }

  const sortedMatches = [...matches].sort((a, b) => a.week - b.week);
  for (const m of sortedMatches) {
    const home = accs.get(m.homeTeamId);
    const away = accs.get(m.awayTeamId);
    if (!home || !away) continue;
    home.played += 1;
    away.played += 1;
    home.goalsFor += m.homeGoals;
    home.goalsAgainst += m.awayGoals;
    away.goalsFor += m.awayGoals;
    away.goalsAgainst += m.homeGoals;
    if (m.homeGoals > m.awayGoals) {
      home.won += 1;
      home.points += 3;
      home.results.push({ week: m.week, result: 'W' });
      away.lost += 1;
      away.results.push({ week: m.week, result: 'L' });
    } else if (m.homeGoals < m.awayGoals) {
      away.won += 1;
      away.points += 3;
      away.results.push({ week: m.week, result: 'W' });
      home.lost += 1;
      home.results.push({ week: m.week, result: 'L' });
    } else {
      home.drawn += 1;
      home.points += 1;
      home.results.push({ week: m.week, result: 'D' });
      away.drawn += 1;
      away.points += 1;
      away.results.push({ week: m.week, result: 'D' });
    }
  }

  const rows: StandingRow[] = Array.from(accs.values()).map((acc) => ({
    teamId: acc.team.id,
    name: acc.team.name,
    shortName: acc.team.shortName,
    colorPrimary: acc.team.colorPrimary,
    colorSecondary: acc.team.colorSecondary,
    isUser: acc.team.isUser,
    played: acc.played,
    won: acc.won,
    drawn: acc.drawn,
    lost: acc.lost,
    goalsFor: acc.goalsFor,
    goalsAgainst: acc.goalsAgainst,
    goalDiff: acc.goalsFor - acc.goalsAgainst,
    points: acc.points,
    place: 0,
    form: acc.results.slice(-5).map((r) => r.result),
  }));

  rows.sort(
    (a, b) =>
      b.points - a.points ||
      b.goalDiff - a.goalDiff ||
      b.goalsFor - a.goalsFor ||
      a.name.localeCompare(b.name, 'ru'),
  );
  rows.forEach((row, i) => {
    row.place = i + 1;
  });

  return rows;
}

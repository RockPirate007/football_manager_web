/**
 * Модуль 3 «ИИ-менеджеры трансферного рынка»: анализ слабых позиций состава,
 * осмысленные покупки (вместо «самого дешёвого лота»), входящие офферы на
 * игроков клуба пользователя. Чистые функции над PlayerLike; RNG — только
 * явно в параметрах (детерминизм недельного цикла).
 *
 * Модель «потребность» (Hattrick-стиль): для каждой линейной группы (GK/DEF/
 * MID/FWD) считается качество условного стартера (топ-K OVR) и глубина
 * (сколько игроков уровня стартера −10). Срочность = отрыв целевого качества
 * (сила клуба) от фактического + штраф за мелкую скамейку. ИИ покупает лоты,
 * которые закрывают самую больную группу и реально усиливают состав, не
 * переплачивая выше AI_PRICE_VALUE_MAX.
 */

import {
  AI_GROUP_DEPTH_MIN, AI_PRICE_VALUE_MAX, AI_UPGRADE_MIN_GAIN,
  INCOMING_OFFER_BOSMAN_FACTOR, INCOMING_OFFER_STAR_FACTOR,
} from './constants';
import { broadGroupOf, computeSalary, type PlayerLike } from './players';
import { pick, pickWeighted, type RNG } from './rng';

export type LineGroup = 'GK' | 'DEF' | 'MID' | 'FWD';

/** Человеческие названия линий для новостей/текстов. */
export const LINE_GROUP_LABELS: Record<LineGroup, string> = {
  GK: 'вратарскую линию',
  DEF: 'оборону',
  MID: 'середину поля',
  FWD: 'атаку',
};

/** Минимальная глубина группы (GK достаточно двух, линию — трёх). */
function groupDepthMin(group: LineGroup): number {
  return group === 'GK' ? 2 : AI_GROUP_DEPTH_MIN;
}

/** Сколько «стартеров» в группе для условного 4-4-2 (оценка потребности). */
const GROUP_STARTERS: Record<LineGroup, number> = { GK: 1, DEF: 4, MID: 4, FWD: 3 };

export interface GroupNeed {
  group: LineGroup;
  /** Средний OVR условных стартеров группы. */
  starter: number;
  /** Игроки уровня стартера −10 (запас). */
  depth: number;
  /** Целевое качество группы (= сила клуба). */
  target: number;
  /** ≥ 0 — насколько срочно усилить (0 = всё хорошо). */
  urgency: number;
}

/**
 * Потребности состава по группам: стартовое качество, глубина, срочность.
 * target — якорь силы клуба (strength): ИИ сравнивает свои группы с ним.
 */
export function squadNeedsOf(squad: PlayerLike[], target: number): GroupNeed[] {
  const groups: LineGroup[] = ['GK', 'DEF', 'MID', 'FWD'];
  return groups.map((group) => {
    const players = squad.filter((p) => broadGroupOf(p.position) === group);
    const k = GROUP_STARTERS[group];
    const byOvr = [...players].sort((a, b) => b.ovr - a.ovr);
    const starters = byOvr.slice(0, k);
    const starter = starters.length > 0
      ? starters.reduce((s, p) => s + p.ovr, 0) / starters.length
      : 30; // пустая группа — критический дефицит
    const depth = players.filter((p) => p.ovr >= starter - 10).length;
    const urgency = Math.max(0, target - starter)
      + Math.max(0, groupDepthMin(group) - depth) * 2
      + (players.length < k ? 6 : 0); // группа меньше стартовых мест
    return { group, starter, depth, target, urgency: Math.round(urgency * 10) / 10 };
  });
}

/** Дефицитная группа с максимальной срочностью (для текста новостей). */
export function weakestNeedOf(needs: GroupNeed[]): GroupNeed {
  return [...needs].sort((a, b) => b.urgency - a.urgency)[0];
}

/** Лот рынка, как его видит ИИ-менеджер. */
export interface AiListingView {
  listingId: string;
  price: number;
  source: string;
  playerId: string;
  ovr: number;
  age: number;
  value: number;
  group: LineGroup;
}

export interface AiTransferPick {
  listingId: string;
  price: number;
  playerId: string;
  group: LineGroup;
  /** Насколько усиливает стартовую группу (ovr лота − starter группы). */
  gain: number;
}

/**
 * Умный выбор лота для ИИ-клуба: лот обязан (1) быть по карману, (2) иметь
 * разумный price/value ≤ AI_PRICE_VALUE_MAX, (3) усиливать одну из групп
 * (ovr лота ≥ starter группы + AI_UPGRADE_MIN_GAIN). Скоринг:
 * срочность группы ×2 + прирост качества − штраф цены. Возвращает лучший
 * лот или null (клуб ничего не купит — «слишком дорого/не нужно»).
 */
export function pickAiTransferTarget(
  rng: RNG,
  args: {
    needs: GroupNeed[];
    budget: number;
    listings: AiListingView[];
    alreadyBoughtPlayerIds?: Set<string>;
  },
): AiTransferPick | null {
  const { needs, budget, listings } = args;
  const bought = args.alreadyBoughtPlayerIds ?? new Set<string>();
  const needByGroup = new Map(needs.map((n) => [n.group, n]));
  const needMax = Math.max(...needs.map((n) => n.urgency), 1);

  let best: (AiTransferPick & { score: number }) | null = null;
  for (const l of listings) {
    if (bought.has(l.playerId)) continue;
    if (l.price > budget) continue;
    if (l.value > 0 && l.price / l.value > AI_PRICE_VALUE_MAX) continue;
    const need = needByGroup.get(l.group);
    if (!need) continue;
    const gain = l.ovr - need.starter;
    if (gain < AI_UPGRADE_MIN_GAIN) continue; // не усиливает состав
    // Глубина: даже ровный по OVR игрок полезен тонкой группе
    const depthBonus = need.depth < groupDepthMin(need.group) ? 3 : 0;
    const relUrgency = need.urgency / needMax;
    const pricePressure = (l.price / Math.max(budget, 1)) * 6;
    const ageFactor = l.age > 32 ? -2 : l.age < 24 ? 1.5 : 0; // ИИ думает о будущем
    const score = relUrgency * 8 + gain + depthBonus - pricePressure + ageFactor;
    if (best === null || score > best.score) {
      best = {
        listingId: l.listingId, price: l.price, playerId: l.playerId,
        group: l.group, gain, score,
      };
    }
  }
  if (best === null) return null;
  // Не покупает при отрицательном скоринге — «рынок не предлагает нужного»
  if (best.score <= 0 && rng() < 0.8) return null;
  const { score: _score, ...pick } = best;
  return pick;
}

// ── Входящие офферы на игроков клуба пользователя ──────────────────────────

export interface IncomingOfferDraft {
  playerId: string;
  fromTeamId: string;
  amount: number;
  /** Причина выбора игрока (текст новости). */
  reason: 'star' | 'bosman' | 'bargain' | 'depth';
}

export interface IncomingOfferArgs {
  /** Состав клуба пользователя (без травмированных). */
  userSquad: PlayerLike[];
  /** Кандидаты-покупатели: ИИ-клубы с их силой. */
  aiTeams: { teamId: string; strength: number }[];
  /** Игроки, на которых уже есть pending-оффер (guard дублей). */
  offeredPlayerIds: Set<string>;
  /** Активные лоты клуба игрока: playerId → цена (ИИ торгуется от неё). */
  userListings: Map<string, number>;
  /** Текущий сезон (последний год контракта = дисконт). */
  season: number;
}

/**
 * Бросок одного входящего оффера: покупатель ищет игрока, который усилит его
 * старт (player.ovr ≥ strength − 4). Сумма: от цены лота (торг −15%) ИЛИ от
 * рыночной стоимости (0.85..1.15); star-игроку премия, последнему году
 * контракта дисконт. Взвешенно чаще целимся в лучших и недовольных.
 */
export function aiIncomingOfferOf(rng: RNG, args: IncomingOfferArgs): IncomingOfferDraft | null {
  const { userSquad, aiTeams, offeredPlayerIds, userListings, season } = args;
  if (userSquad.length === 0 || aiTeams.length === 0) return null;

  // фильтр: живой (не травмирован), не в pending-оффере, есть контракт
  const candidates = userSquad.filter((p) => p.injuryWeeks === 0 && !offeredPlayerIds.has(p.id));
  if (candidates.length === 0) return null;

  // Покупатель: равный или чуть более сильный клуб (как Босман-правило ±span)
  const buyer = pick(rng, aiTeams);

  // Цель: усилит старт покупателя (ovr ≥ strength − 4); взвешенно — лучшие
  const eligible = candidates.filter((p) => p.ovr >= buyer.strength - 4);
  const pool = eligible.length > 0 ? eligible : candidates;
  const target = pickWeighted(
    rng,
    pool.map((p) => ({
      item: p,
      weight: 1 + Math.max(0, p.ovr - buyer.strength + 4) * 2
        + (p.morale < 45 ? 3 : 0), // недовольные — «слышали, он хочет уйти»
    })),
  );

  // Сумма: от лота (торг) или от стоимости; модификаторы star/Bosman
  const listed = userListings.get(target.id) ?? null;
  let amount: number;
  let reason: IncomingOfferDraft['reason'];
  if (listed !== null) {
    amount = listed * (0.85 + rng() * 0.1);
    reason = 'bargain';
  } else {
    amount = target.value * (0.85 + rng() * 0.3);
    reason = 'depth';
  }
  if (target.ovr >= buyer.strength + 3) {
    amount *= INCOMING_OFFER_STAR_FACTOR[0] + rng()
      * (INCOMING_OFFER_STAR_FACTOR[1] - INCOMING_OFFER_STAR_FACTOR[0]);
    reason = 'star';
  }
  if (target.contractUntil === season) {
    // последний год: покупатель знает про Босмана и давит ценой —
    // итог никогда не выше 90% стоимости (заберут бесплатно через полгода)
    amount *= INCOMING_OFFER_BOSMAN_FACTOR[0] + rng()
      * (INCOMING_OFFER_BOSMAN_FACTOR[1] - INCOMING_OFFER_BOSMAN_FACTOR[0]);
    amount = Math.min(amount, target.value * 0.9);
    reason = 'bosman';
  }
  amount = Math.max(50_000, Math.round(amount / 10_000) * 10_000);
  return { playerId: target.id, fromTeamId: buyer.teamId, amount, reason };
}

/** Зарплата, которую ИИ-клуб положит купленному игроку (не торгуется). */
export function aiSigningSalaryOf(player: PlayerLike): number {
  return Math.max(500, Math.round((computeSalary(player.value) * 1.1) / 100) * 100);
}

/** Причина оффера — человеческий текст для новости. */
export function offerReasonTextOf(reason: IncomingOfferDraft['reason']): string {
  switch (reason) {
    case 'star': return 'видят в нём лидера своих амбиций';
    case 'bosman': return 'не хотят упустить его по правилу Босмана';
    case 'bargain': return 'считают цену выгодной';
    default: return 'нужны глубина и конкуренция в составе';
  }
}

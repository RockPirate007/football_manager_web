#!/bin/bash
# Регрессионный тест фиксов QA (Task 5): полный сезон 30 туров.
# Проверяет: QA-1 (гостевые матчи против правильного соперника),
# QA-2 (переход на сезон 2 без HTTP 500), общую целостность.
set -u
BASE="http://localhost:3000/api/game"
J="Content-Type: application/json"

echo "=== 1. Новая игра ==="
NEW=$(curl -s -X POST "$BASE/new" -H "$J" -d '{"managerName":"Тестер QA"}')
SAVE_ID=$(echo "$NEW" | python3 -c "import sys,json; print(json.load(sys.stdin)['saveId'])")
echo "saveId=$SAVE_ID"

# Себе выбираем клуб из списка (первый)
CLUB_ID=$(echo "$NEW" | python3 -c "import sys,json; print(json.load(sys.stdin)['clubs'][0]['id'])")
CLUB_NAME=$(echo "$NEW" | python3 -c "import sys,json; print(json.load(sys.stdin)['clubs'][0]['name'])")
echo "club=$CLUB_NAME ($CLUB_ID)"

echo "=== 2. Выбор клуба ==="
SEL=$(curl -s -X POST "$BASE/select" -H "$J" -d "{\"saveId\":\"$SAVE_ID\",\"teamId\":\"$CLUB_ID\"}")
echo "$SEL" | python3 -c "import sys,json; d=json.load(sys.stdin); print('ok:', d.get('ok'), '| balance:', d.get('balance'))"

echo "=== 3. Симуляция 30 туров (сезон 1) ==="
SELF_PLAYED=0
AWAY_BUG=0
HTTP500=0
for W in $(seq 1 30); do
  RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE/simulate" -H "$J" -d '{}')
  CODE=$(echo "$RESP" | tail -1)
  BODY=$(echo "$RESP" | head -1)
  if [ "$CODE" != "200" ]; then
    HTTP500=$((HTTP500+1))
    echo "ТУР $W: HTTP $CODE ❌"
    echo "$BODY" | head -c 300
    break
  fi
  # Проверка QA-1: соперник != своя команда
  READOUT=$(echo "$BODY" | python3 -c "
import sys, json
d = json.load(sys.stdin)
m = d['userMatch']
home, away = m['home']['name'], m['away']['name']
same = 'BUG_SELF_MATCH' if home == away else 'ok'
print(f\"{same} | {home} {m['homeGoals']}:{m['awayGoals']} {away} | сезон {d['season']} тур {d['week']}\")" 2>/dev/null)
  if echo "$READOUT" | grep -q "BUG_SELF_MATCH"; then
    AWAY_BUG=$((AWAY_BUG+1))
    echo "ТУР $W: $READOUT ❌"
  else
    SELF_PLAYED=$((SELF_PLAYED+1))
  fi
  # Обновляем teamId выбранной команды (id мог остаться прежним — это ок, id постоянный)
done

echo ""
echo "=== РЕЗУЛЬТАТЫ ==="
echo "Туров сыграно успешно: $SELF_PLAYED/30"
echo "Багов self-match (QA-1): $AWAY_BUG"
echo "HTTP ошибок (QA-2): $HTTP500"

echo ""
echo "=== 4. Состояние после сезона ==="
STATE=$(curl -s "$BASE/state")
echo "$STATE" | python3 -c "
import sys, json
d = json.load(sys.stdin)
s = d.get('save') or d.get('snapshot') or d
print('ok:', d.get('ok'))
" 2>/dev/null || echo "$STATE" | head -c 400

echo ""
echo "=== 5. Туры сезона 2 (первые 2) ==="
for W in 1 2; do
  RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE/simulate" -H "$J" -d '{}')
  CODE=$(echo "$RESP" | tail -1)
  BODY=$(echo "$RESP" | head -1)
  echo "Тур S2-$W: HTTP $CODE"
  echo "$BODY" | python3 -c "
import sys, json
d = json.load(sys.stdin)
m = d['userMatch']
print(f\"  {m['home']['name']} {m['homeGoals']}:{m['awayGoals']} {m['away']['name']} | сезон {d['season']} тур {d['week']}\")" 2>/dev/null || echo "  (нет userMatch: $(echo "$BODY" | head -c 200))"
done

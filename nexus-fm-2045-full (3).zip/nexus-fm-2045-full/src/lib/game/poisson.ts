/**
 * Сэмплер распределения Пуассона (алгоритм Кнута).
 * Раздел 4.2 docs/architecture.md.
 */

import { MAX_GOALS } from './constants';

export function samplePoisson(rng: () => number, lambda: number): number {
  const L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k++;
    p *= rng();
  } while (p > L);
  return Math.min(k - 1, MAX_GOALS);
}

'use client';

import { motion } from 'framer-motion';
import {
  Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip as ChartTooltip,
  XAxis, YAxis,
} from 'recharts';
import {
  AlertTriangle, ArrowLeftRight, Building2, ChartPie, ChartSpline, Crown, Globe, Handshake, HardHat,
  PiggyBank, Scale, Store, Ticket, Trophy, Tv, UserRound, Users, Wallet,
} from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { StatCard } from '@/components/game/shared/StatCard';
import { WAGE_ALERT_RATIO } from '@/lib/game/constants';
import { formatMoney, formatMoneyExact } from '@/lib/game/format';
import type { FinanceCategory } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const CATEGORY_META: Record<FinanceCategory, { label: string; icon: typeof Wallet }> = {
  sponsor: { label: 'Спонсор', icon: Handshake },
  tickets: { label: 'Билеты', icon: Ticket },
  prize: { label: 'Призовые', icon: Trophy },
  cup_prize: { label: 'Кубковые призовые', icon: Trophy },
  euro_prize: { label: 'Призовые Кубка Европы', icon: Globe }, // ── Фаза 4
  transfer_in: { label: 'Продажа', icon: ArrowLeftRight },
  transfer_out: { label: 'Покупка', icon: ArrowLeftRight },
  wages: { label: 'Зарплаты', icon: Wallet },
  // ── D-5 «Территория» (§3.5): категории инфраструктуры ──
  building: { label: 'Содержание инфраструктуры', icon: Building2 },
  construction: { label: 'Стройка', icon: HardHat },
  merch: { label: 'Фан-шоп', icon: Store },
  vip: { label: 'VIP-ложи', icon: Crown },
  // ── D-6 «Тренер» (§4): категория объявлена заранее ──
  coach_wages: { label: 'Зарплата тренера', icon: UserRound },
  // ── Модуль 4: зарплаты тренерского штата ──
  staff_wages: { label: 'Зарплаты штата', icon: Users },
  // ── Модуль 5: ТВ-отчисления лиги ──
  tv: { label: 'Телевещание', icon: Tv },
};

/** Экран «Финансы»: баланс, бюджет, ведомость, журнал операций. */
export function FinancesScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const { save, finances, myTeam, myPlayers } = snapshot;
  const records = finances.records.slice(0, 30);
  const wageRatioPct = Math.round(finances.wageRatio * 100);
  const wageAlert = finances.wageRatio > WAGE_ALERT_RATIO;
  const seasonRatio =
    finances.seasonIncome + finances.seasonExpense > 0
      ? Math.round((finances.seasonIncome / (finances.seasonIncome + finances.seasonExpense)) * 100)
      : 50;

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Финансы"
        subtitle={`${myTeam.name} · стадион на ${myTeam.stadiumCapacity.toLocaleString('ru-RU')} мест`}
      />

      {/* Сводка */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <StatCard
          icon={PiggyBank}
          value={formatMoney(save.balance)}
          label="Баланс клуба"
          tone={save.balance < 0 ? 'danger' : 'default'}
        />
        <StatCard
          icon={ArrowLeftRight}
          value={formatMoney(finances.transferBudget)}
          label="Бюджет трансферов (правление)"
          tone="success"
        />
        <StatCard
          icon={Wallet}
          value={`${formatMoney(finances.wagesActual)}/${formatMoney(finances.wageBudget)}`}
          label="Зарплаты / зарплатный бюджет"
          tone={wageAlert ? 'warning' : 'default'}
        />
        <StatCard
          icon={Ticket}
          value={`${formatMoney(finances.weeklyIncome)}/нед`}
          label="Доход (спонсор + билеты + ТВ + мерч)"
        />
      </div>

      {/* Здоровье экономики */}
      <Card className="border-border/70">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm">
            <Scale className="size-4 text-primary" aria-hidden />
            Здоровье клуба
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Зарплаты / недельный доход</span>
              <span
                className={cn(
                  'tabular font-semibold',
                  wageAlert ? 'text-[#FACC15]' : 'text-[#22C55E]',
                )}
              >
                {wageRatioPct}%
              </span>
            </div>
            <Progress
              value={Math.min(100, wageRatioPct)}
              className="h-2"
              aria-label="Доля зарплат в доходе"
            />
          </div>
          <div>
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Доходы / оборот сезона</span>
              <span className="tabular font-semibold">{seasonRatio}%</span>
            </div>
            <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
              <div className="bg-[#22C55E]" style={{ width: `${seasonRatio}%` }} />
              <div className="bg-[#EF4444]" style={{ width: `${100 - seasonRatio}%` }} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="rounded bg-[#22C55E]/10 p-2">
              <div className="text-muted-foreground">Доходы сезона</div>
              <div className="tabular font-bold text-[#22C55E]">
                +{formatMoney(finances.seasonIncome)}
              </div>
            </div>
            <div className="rounded bg-[#EF4444]/10 p-2">
              <div className="text-muted-foreground">Расходы сезона</div>
              <div className="tabular font-bold text-[#EF4444]">
                −{formatMoney(finances.seasonExpense)}
              </div>
            </div>
          </div>
          {wageAlert ? (
            <Alert className="border-[#FACC15]/40 bg-[#FACC15]/5">
              <AlertTriangle className="size-4 text-[#FACC15]" aria-hidden />
              <AlertTitle>Зарплаты съедают доход</AlertTitle>
              <AlertDescription>
                Ведомость превышает 70% недельного дохода ({wageRatioPct}%). Подумайте о продаже
                высокооплачиваемых игроков — иначе клуб уйдёт в минус.
              </AlertDescription>
            </Alert>
          ) : null}
          {save.balance < 0 ? (
            <Alert className="border-[#EF4444]/40 bg-[#EF4444]/5">
              <AlertTriangle className="size-4 text-[#EF4444]" aria-hidden />
              <AlertTitle>Клуб в минусе</AlertTitle>
              <AlertDescription>
                Баланс отрицательный: покупки заблокированы до восстановления платёжеспособности.
              </AlertDescription>
            </Alert>
          ) : null}
        </CardContent>
      </Card>

      {/* Модуль 6: недельный поток — доход/расход/чистый итог по неделям сезона */}
      {finances.weekly.length >= 2 ? (
        <Card className="border-border/70">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-1.5 text-sm">
              <ChartSpline className="size-4 text-primary" aria-hidden />
              Денежный поток по неделям · сезон {save.season}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[170px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={finances.weekly} margin={{ top: 6, right: 6, bottom: 0, left: -8 }}>
                  <defs>
                    <linearGradient id="netPosFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#22C55E" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="2 4" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis
                    dataKey="week"
                    tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }}
                    stroke="hsl(var(--border))"
                    minTickGap={14}
                  />
                  <YAxis
                    tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }}
                    stroke="hsl(var(--border))"
                    tickFormatter={(v: number) => (v === 0 ? '0' : `${Math.round(v / 1e6)}M€`)}
                    width={54}
                  />
                  <ReferenceLine y={0} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" />
                  <ChartTooltip
                    cursor={{ stroke: 'rgba(0,212,255,0.35)' }}
                    contentStyle={{
                      background: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 8,
                      fontSize: 11,
                    }}
                    formatter={(value: number | string, name: string) => [formatMoneyExact(Number(value)), name]}
                    labelFormatter={(label) => `Неделя ${label}`}
                  />
                  <Area
                    type="monotone"
                    dataKey="net"
                    name="Чистый поток"
                    stroke="#00D4FF"
                    strokeWidth={2}
                    fill="url(#netPosFill)"
                    isAnimationActive
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="mt-1 text-center text-[10px] text-muted-foreground">
              Ось — разница доходов и расходов недели (зарплаты, стройка, трансферы, призовые)
            </p>
          </CardContent>
        </Card>
      ) : null}

      {/* Модуль 5: отчёт по статьям сезона (агрегация FinanceRecord) */}
      <Card className="border-border/70">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-1.5 text-sm">
            <ChartPie className="size-4 text-primary" aria-hidden />
            Отчёт по статьям · сезон {save.season}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {finances.byCategory.length === 0 ? (
            <p className="py-4 text-center text-xs text-muted-foreground">
              Статей пока нет — сыграйте первые туры сезона.
            </p>
          ) : (
            <>
              {finances.byCategory.map((row) => {
                const meta = CATEGORY_META[row.category] ?? CATEGORY_META.wages;
                const Icon = meta.icon;
                const turnover = row.income + row.expense;
                const maxTurnover = Math.max(
                  ...finances.byCategory.map((r) => r.income + r.expense),
                  1,
                );
                const widthPct = (turnover / maxTurnover) * 100;
                const incomePct = turnover > 0 ? (row.income / turnover) * 100 : 0;
                return (
                  <div key={row.category} className="space-y-1">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="flex min-w-0 items-center gap-1.5">
                        <Icon className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                        <span className="truncate">{row.label}</span>
                      </span>
                      <span className="flex shrink-0 items-center gap-2 tabular">
                        {row.income > 0 ? (
                          <span className="text-[#22C55E]">+{formatMoney(row.income)}</span>
                        ) : null}
                        {row.expense > 0 ? (
                          <span className="text-[#EF4444]">−{formatMoney(row.expense)}</span>
                        ) : null}
                      </span>
                    </div>
                    <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full bg-[#22C55E]/70"
                        style={{ width: `${(widthPct * incomePct) / 100}%` }}
                        aria-hidden
                      />
                      <div
                        className="h-full bg-[#EF4444]/70"
                        style={{ width: `${(widthPct * (100 - incomePct)) / 100}%` }}
                        aria-hidden
                      />
                    </div>
                  </div>
                );
              })}
              <p className="pt-1 text-[10px] text-muted-foreground">
                Полоса — доля статьи в обороте сезона (зелёная часть — доходы, красная — расходы).
                Итог: +{formatMoney(finances.seasonIncome)} / −{formatMoney(finances.seasonExpense)} =
                {' '}{finances.seasonIncome - finances.seasonExpense >= 0 ? '+' : '−'}
                {formatMoney(Math.abs(finances.seasonIncome - finances.seasonExpense))}.
              </p>
            </>
          )}
        </CardContent>
      </Card>

      {/* Журнал операций */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="scroll-thin overflow-x-auto rounded-lg border border-border/70 bg-card"
      >
        <div className="flex items-center justify-between px-4 py-3">
          <span className="text-sm font-semibold">Журнал операций</span>
          <Badge variant="secondary" className="text-[10px]">
            последние {records.length} записей · {myPlayers.length} игроков в ведомости
          </Badge>
        </div>
        <Table className="min-w-[620px]">
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="h-9 w-16 text-center text-[11px]">Тур</TableHead>
              <TableHead className="h-9 w-28 text-[11px]">Категория</TableHead>
              <TableHead className="h-9 text-[11px]">Описание</TableHead>
              <TableHead className="h-9 w-28 text-right text-[11px]">Сумма</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="zebra">
            {records.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="py-8 text-center text-xs text-muted-foreground">
                  Операций пока нет — сыграйте первый тур.
                </TableCell>
              </TableRow>
            ) : (
              records.map((r) => {
                const meta = CATEGORY_META[r.category] ?? CATEGORY_META.wages;
                const Icon = meta.icon;
                const income = r.kind === 'income';
                return (
                  <TableRow key={r.id} className="border-border/40">
                    <TableCell className="py-2 text-center text-xs tabular text-muted-foreground">
                      {r.week}
                    </TableCell>
                    <TableCell className="py-2">
                      <span className="inline-flex items-center gap-1.5 text-xs">
                        <Icon
                          className={cn('size-3.5', income ? 'text-[#22C55E]' : 'text-[#EF4444]')}
                          aria-hidden
                        />
                        {meta.label}
                      </span>
                    </TableCell>
                    <TableCell className="py-2 text-xs text-muted-foreground">
                      <span className="line-clamp-1">{r.description}</span>
                    </TableCell>
                    <TableCell
                      className={cn(
                        'py-2 text-right text-xs font-semibold tabular',
                        income ? 'text-[#22C55E]' : 'text-[#EF4444]',
                      )}
                    >
                      {income ? '+' : '−'}
                      {formatMoneyExact(r.amount)}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </motion.div>
    </div>
  );
}

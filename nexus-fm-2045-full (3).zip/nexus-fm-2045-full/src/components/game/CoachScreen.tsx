'use client';

import { useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  AlertTriangle, Baby, BadgeCheck, Briefcase, Building2, CalendarDays, Car, Coins,
  GraduationCap, Heart, Home, Loader2, Minus, Ship, Sparkles, TrendingDown, TrendingUp,
  UserRound, Wallet, Waves,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { TeamCrest } from '@/components/game/shared/TeamCrest';
import type { AssetDTO, ManagerDTO } from '@/lib/game/types';
import { formatMoney, formatMoneyExact } from '@/lib/game/format';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';

/**
 * Экран «Тренер» (D-6, спека §4.7): личная жизнь менеджера — профиль,
 * ЛИЧНЫЙ кошелёк (визуально отделён от клубного), шкала престижа 0–100 с
 * зонами <40 серая / 40–60 зелёная / ≥60 золотая (#D4AF37), сетка 7 активов
 * (Купить / Продать за 70 %) и семья-таймлайн (свадьба → ребёнок → «сын в
 * академии» с прогрессом до 14 лет). Русский; тачи ≥ 44px; без синих/эмодзи.
 */

/** Иконки активов (§4.7: Building2/Home/Waves — недвижимость, Car, Ship). */
const ASSET_ICONS: Record<string, typeof Home> = {
  re_flat: Home,
  re_house: Building2,
  re_villa: Waves,
  car_compact: Car,
  car_sport: Car,
  car_lux: Car,
  yacht: Ship,
};

const CATEGORY_LABELS: Record<AssetDTO['category'], string> = {
  realty: 'Недвижимость',
  auto: 'Авто',
  yacht: 'Яхта',
};

// ── Шкала престижа (§4.7) ──────────────────────────────────────────────────

/** Зона престижа: <40 серая · 40–60 зелёная · ≥60 золотая. */
function prestigeZoneOf(prestige: number): 'low' | 'mid' | 'high' {
  if (prestige < 40) return 'low';
  if (prestige < 60) return 'mid';
  return 'high';
}

const ZONE_META: Record<'low' | 'mid' | 'high', { fill: string; text: string; label: string }> = {
  low: { fill: 'bg-[#2A382F]', text: 'text-muted-foreground', label: 'серая зона' },
  mid: { fill: 'bg-primary', text: 'text-primary', label: 'зелёная зона' },
  high: { fill: 'bg-[#D4AF37]', text: 'text-[#D4AF37]', label: 'золотая зона' },
};

/** Полоса престижа 0–100 с зонами и маркерами порогов 40/60. */
function PrestigeScale({ prestige, label }: { prestige: number; label: string }) {
  const zone = prestigeZoneOf(prestige);
  const meta = ZONE_META[zone];
  const value = Math.min(100, Math.max(0, prestige));
  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-2">
        <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          <Sparkles className={cn('size-3.5', meta.text)} aria-hidden />
          Престиж
        </span>
        <span className={cn('text-lg font-bold tabular', meta.text)}>
          {value.toFixed(1)}
          <span className="ml-1 text-[10px] font-medium text-muted-foreground">/ 100</span>
        </span>
      </div>
      <div className="relative h-3 w-full overflow-hidden rounded-full bg-secondary">
        {/* Зоны фона: <40 (граница #2A382F), 40–60 (зелёная), ≥60 (золотая) */}
        <div className="absolute inset-y-0 left-0 w-[40%] bg-[#2A382F]" aria-hidden />
        <div className="absolute inset-y-0 left-[40%] w-[20%] bg-primary/30" aria-hidden />
        <div className="absolute inset-y-0 left-[60%] right-0 bg-[#D4AF37]/25" aria-hidden />
        {/* Заполнение текущим цветом зоны */}
        <motion.div
          className={cn('absolute inset-y-0 left-0 rounded-full', meta.fill)}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          aria-hidden
        />
        {/* Маркеры порогов */}
        <span className="absolute inset-y-0 left-[40%] w-px bg-foreground/25" aria-hidden />
        <span className="absolute inset-y-0 left-[60%] w-px bg-foreground/25" aria-hidden />
      </div>
      <div className="flex items-center justify-between gap-2 text-[10px] text-muted-foreground">
        <span>{label}</span>
        <span className="tabular">порог «звёзды слушаются»: 60</span>
      </div>
    </div>
  );
}

/** Подписи эффектов престижа (шкала эффектов §4.3/§4.6). */
function EffectsList({ manager }: { manager: ManagerDTO }) {
  const { effects } = manager;
  const rows: { text: string; active: boolean }[] = [
    {
      text: 'Продление контрактов: спрос ×0.95',
      active: effects.contractsDemandMult < 1,
    },
    {
      text: 'Продление контрактов: спрос ×1.05',
      active: effects.contractsDemandMult > 1,
    },
    {
      text: 'Трансферы: цена ×0.95 (скидка)',
      active: effects.marketDiscount,
    },
    {
      text: 'Звёзды (OVR ≥ 80) требуют наценку ×1.10',
      active: effects.marketStarPremium,
    },
    {
      text: `Правление: порог предупреждения ${effects.boardWarnBelow}`,
      active: effects.boardWarnBelow < 30,
    },
  ];
  return (
    <ul className="space-y-1.5">
      {rows.map((row) => (
        <li
          key={row.text}
          className={cn(
            'flex items-center gap-1.5 text-xs',
            row.active ? 'text-[#D4AF37]' : 'text-muted-foreground',
          )}
        >
          {row.active ? (
            <BadgeCheck className="size-3.5 shrink-0" aria-hidden />
          ) : (
            <Minus className="size-3.5 shrink-0" aria-hidden />
          )}
          <span>{row.text}</span>
        </li>
      ))}
    </ul>
  );
}

// ── Карточка актива (§4.7) ─────────────────────────────────────────────────

function AssetCard({
  asset,
  wallet,
  saving,
  index,
  onBuy,
  onSell,
}: {
  asset: AssetDTO;
  wallet: number;
  saving: boolean;
  index: number;
  onBuy: () => void;
  onSell: () => void;
}) {
  const Icon = ASSET_ICONS[asset.id] ?? Coins;
  const owned = asset.owned;
  const missing = asset.price - wallet;
  const canBuy = !owned && !saving && missing <= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, delay: Math.min(index * 0.04, 0.25) }}
      className={cn(
        'flex flex-col gap-3 rounded-lg border p-3.5',
        owned
          ? 'border-[#D4AF37]/60 bg-[#D4AF37]/5'
          : 'border-border/70 bg-card',
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div
          className={cn(
            'flex size-10 shrink-0 items-center justify-center rounded-lg border',
            owned ? 'border-[#D4AF37]/40 bg-[#D4AF37]/10' : 'border-border/70 bg-secondary/60',
          )}
        >
          <Icon
            className={cn('size-5', owned ? 'text-[#D4AF37]' : 'text-primary')}
            aria-hidden
          />
        </div>
        {owned ? (
          <Badge className="border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[10px] text-[#D4AF37]">
            В собственности
          </Badge>
        ) : (
          <span className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
            {CATEGORY_LABELS[asset.category]}
          </span>
        )}
      </div>

      <div>
        <p className="text-sm font-semibold leading-tight">{asset.name}</p>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
          <span className="tabular">Цена {formatMoneyExact(asset.price)}</span>
          <span className="tabular text-[#D4AF37]">
            +{(asset.prestige / 10).toFixed(1)} престижа
          </span>
        </div>
        <div className="mt-0.5 flex items-center gap-x-3 text-[11px] text-muted-foreground">
          <span className="tabular">Содержание {formatMoney(asset.upkeepWeekly)}/нед</span>
          <span className="tabular">Продажа {formatMoney(asset.sellPrice)}</span>
        </div>
      </div>

      {owned ? (
        <Button
          type="button"
          variant="outline"
          size="lg"
          className="min-h-11 w-full"
          disabled={saving}
          onClick={onSell}
        >
          {saving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
          Продать за 70 %
        </Button>
      ) : (
        <Button
          type="button"
          size="lg"
          className="min-h-11 w-full font-semibold"
          disabled={!canBuy}
          onClick={onBuy}
        >
          {saving ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden />
              Оформляем…
            </>
          ) : missing > 0 ? (
            `Не хватает ${formatMoney(missing)}`
          ) : (
            'Купить'
          )}
        </Button>
      )}
    </motion.div>
  );
}

// ── Семья-таймлайн (§4.7) ──────────────────────────────────────────────────

/** Одна веха вертикального таймлайна. */
function TimelineItem({
  icon: Icon,
  title,
  detail,
  state,
  last,
}: {
  icon: typeof Heart;
  title: string;
  detail?: string;
  state: 'done' | 'next' | 'locked';
  last?: boolean;
}) {
  return (
    <li className="relative flex gap-3 pb-4 last:pb-0">
      {!last ? (
        <span
          className={cn(
            'absolute left-[17px] top-9 h-[calc(100%-2.25rem)] w-px',
            state === 'done' ? 'bg-primary/40' : 'bg-border/60',
          )}
          aria-hidden
        />
      ) : null}
      <span
        className={cn(
          'relative z-10 flex size-9 shrink-0 items-center justify-center rounded-full border',
          state === 'done' && 'border-primary/50 bg-primary/15 text-primary',
          state === 'next' && 'border-[#D4AF37]/50 bg-[#D4AF37]/10 text-[#D4AF37]',
          state === 'locked' && 'border-border/70 bg-secondary/60 text-muted-foreground/70',
        )}
      >
        <Icon className="size-4" aria-hidden />
      </span>
      <div className="min-w-0 flex-1 pt-0.5">
        <p className={cn(
          'text-xs font-semibold leading-tight',
          state === 'locked' && 'text-muted-foreground',
        )}>
          {title}
        </p>
        {detail ? <p className="mt-1 text-[11px] text-muted-foreground">{detail}</p> : null}
      </div>
    </li>
  );
}

/** Блок «Семья»: таймлайн событий от статуса до академии. */
function FamilyTimeline({ manager }: { manager: ManagerDTO }) {
  const family = manager.family;
  const married = family?.marriedAtWeek !== null && family?.marriedAtWeek !== undefined;
  const child = family?.child ?? null;

  return (
    <ol className="space-y-0">
      <TimelineItem
        icon={married ? Heart : UserRound}
        title={married ? `Женат на ${family?.spouseName}` : 'Не женат'}
        detail={
          married
            ? `Свадьба — ${family?.marriedAtWeek}-я неделя карьеры`
            : 'Шанс появляется при престиже ≥ 50.0 после 26 недель карьеры'
        }
        state={married ? 'done' : 'locked'}
      />
      <TimelineItem
        icon={Baby}
        title={child !== null ? `${child.gender === 'м' ? 'Сын' : 'Дочь'} — ${child.name}` : 'Детей пока нет'}
        detail={
          child !== null
            ? `${child.age} ${child.age === 1 ? 'год' : child.age < 5 ? 'года' : 'лет'} · рождение — ${child.bornAtWeek}-я неделя`
            : married
              ? 'Ребёнок родится через 40 недель после свадьбы'
              : 'Сначала свадьба'
        }
        state={child !== null ? 'done' : married ? 'next' : 'locked'}
      />
      <TimelineItem
        icon={GraduationCap}
        title={
          child?.joinedAcademyPlayerId !== null && child !== null
            ? child.gender === 'м' ? 'Сын в академии!' : 'Дочь в академии!'
            : 'Ребёнок в академии клуба'
        }
        detail={
          child === null
            ? 'В 14 лет ребёнок попадает в академию клуба'
            : child.joinedAcademyPlayerId !== null
              ? 'Воспитанник вашей академии — повышенный шанс «жемчужины»'
              : child.seasonsToAcademy !== null
                ? `${child.name}, ${child.age} ${child.age === 1 ? 'год' : child.age < 5 ? 'года' : 'лет'} — до академии ${child.seasonsToAcademy} ${child.seasonsToAcademy === 1 ? 'сезон' : child.seasonsToAcademy < 5 ? 'сезона' : 'сезонов'}`
                : 'Скоро в академии'
        }
        state={child === null ? 'locked' : 'next'}
        last
      />
    </ol>
  );
}

// ── Экран «Тренер» ─────────────────────────────────────────────────────────

export function CoachScreen() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const manager = useGameStore((s) => s.managerCache);
  const managerLoading = useGameStore((s) => s.managerLoading);
  const managerSaving = useGameStore((s) => s.managerSaving);
  const loadManager = useGameStore((s) => s.loadManager);
  const buyAsset = useGameStore((s) => s.buyAsset);
  const sellAsset = useGameStore((s) => s.sellAsset);

  // Кеш сбрасывается при playWeek/смене сейва — подтягиваем заново
  useEffect(() => {
    if (!manager) void loadManager();
  }, [manager, loadManager]);

  const ownedAssets = useMemo(
    () => (manager ? manager.assets.filter((a) => a.owned) : []),
    [manager],
  );

  if (!manager) {
    return (
      <div className="flex min-h-[240px] flex-col items-center justify-center gap-2 text-muted-foreground">
        {managerLoading ? (
          <>
            <Loader2 className="size-6 animate-spin" aria-hidden />
            <p className="text-xs">Загружаем профиль тренера…</p>
          </>
        ) : (
          <>
            <UserRound className="size-8 text-muted-foreground/50" aria-hidden />
            <p className="text-xs">Профиль тренера недоступен</p>
          </>
        )}
      </div>
    );
  }

  const walletNegative = manager.wallet < 0;

  return (
    <div className="space-y-4">
      <SectionHeader
        title="Тренер"
        subtitle={`${manager.name} · личная жизнь, кошелёк и престиж`}
        action={
          <Badge variant="outline" className="gap-1 text-[11px] tabular">
            <UserRound className="size-3.5" aria-hidden />
            {manager.age} лет
          </Badge>
        }
      />

      {/* ── Профиль + кошелёк ── */}
      <div className="grid gap-3 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="rounded-lg border border-border/70 bg-card p-4"
        >
          <div className="flex items-start gap-3">
            <TeamCrest
              shortName={snapshot.myTeam.shortName}
              colorPrimary={snapshot.myTeam.colorPrimary}
              colorSecondary={snapshot.myTeam.colorSecondary}
              size="md"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold leading-tight">{manager.name}</p>
              <p className="mt-0.5 truncate text-xs text-muted-foreground">
                Главный тренер · {manager.clubName}
              </p>
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <CalendarDays className="size-3.5" aria-hidden />
                  Сезон {manager.season} в клубе
                </span>
                <span className="flex items-center gap-1">
                  <Briefcase className="size-3.5" aria-hidden />
                  {manager.age} лет
                </span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <PrestigeScale prestige={manager.prestige} label={manager.prestigeLabel} />
          </div>
          <div className="mt-3 rounded-lg border border-border/60 bg-secondary/40 p-3">
            <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Эффекты престижа
            </p>
            <EffectsList manager={manager} />
          </div>
        </motion.div>

        {/* ЛИЧНЫЙ кошелёк — визуально отделён от клубного баланса */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2, delay: 0.06 }}
          className={cn(
            'flex flex-col gap-3 rounded-lg border p-4',
            walletNegative
              ? 'border-[#EF4444]/40 bg-[#EF4444]/5'
              : 'border-primary/30 bg-primary/5',
          )}
        >
          <div className="flex items-center justify-between gap-2">
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              <Wallet className="size-4 text-primary" aria-hidden />
              Личный кошелёк
            </p>
            {walletNegative ? (
              <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[10px] text-[#EF4444]">
                <AlertTriangle className="size-3" aria-hidden />
                Долг
              </Badge>
            ) : null}
          </div>
          <p
            className={cn(
              'text-2xl font-bold tabular',
              walletNegative ? 'text-[#EF4444]' : 'text-primary',
            )}
          >
            {formatMoneyExact(manager.wallet)}
          </p>
          <p className="text-[11px] text-muted-foreground">
            Личные средства тренера — отдельно от баланса клуба
          </p>
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="rounded bg-secondary/60 p-2">
              <div className="text-[10px] text-muted-foreground">Зарплата</div>
              <div className="tabular text-xs font-bold">{formatMoney(manager.salary)}/нед</div>
            </div>
            <div className="rounded bg-secondary/60 p-2">
              <div className="text-[10px] text-muted-foreground">Чистый поток</div>
              <div
                className={cn(
                  'flex items-center justify-center gap-1 tabular text-xs font-bold',
                  manager.netWeekly >= 0 ? 'text-primary' : 'text-[#EF4444]',
                )}
              >
                {manager.netWeekly >= 0 ? (
                  <TrendingUp className="size-3" aria-hidden />
                ) : (
                  <TrendingDown className="size-3" aria-hidden />
                )}
                {formatMoney(manager.netWeekly)}/нед
              </div>
            </div>
          </div>
          {ownedAssets.length > 0 ? (
            <div className="rounded-lg border border-border/60 bg-card/60 p-2.5">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Содержание активов
              </p>
              <p className="tabular text-xs font-bold">
                {formatMoney(
                  ownedAssets.reduce((s, a) => s + a.upkeepWeekly, 0),
                )}/нед
              </p>
            </div>
          ) : null}
          {walletNegative ? (
            <p className="flex items-start gap-1.5 text-[11px] text-[#EF4444]">
              <AlertTriangle className="mt-0.5 size-3.5 shrink-0" aria-hidden />
              Кошелёк в минусе: престиж снижается на 1.0 каждую неделю, пока долг не закрыт.
            </p>
          ) : null}
        </motion.div>
      </div>

      {/* ── Активы: сетка 7 карточек ── */}
      <div>
        <SectionHeader
          title="Активы"
          subtitle="Недвижимость, авто и яхта — покупка из личного кошелька, продажа за 70 %"
          action={
            <Badge variant="outline" className="text-[11px] tabular">
              {ownedAssets.length} / 7 в собственности
            </Badge>
          }
        />
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {manager.assets.map((asset, i) => (
            <AssetCard
              key={asset.id}
              asset={asset}
              wallet={manager.wallet}
              saving={managerSaving}
              index={i}
              onBuy={() => {
                void buyAsset(asset.id);
              }}
              onSell={() => {
                void sellAsset(asset.id);
              }}
            />
          ))}
        </div>
      </div>

      {/* ── Семья: таймлайн ── */}
      <div>
        <SectionHeader
          title="Семья"
          subtitle="Свадьба, ребёнок и академия — события личной жизни тренера"
        />
        <div className="rounded-lg border border-border/70 bg-card p-4">
          {manager.family === null ? (
            <p className="flex items-start gap-2 text-xs text-muted-foreground">
              <Heart className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
              {manager.name} пока не женат. При престиже ≥ 50.0 после 26 недель карьеры
              появляется шанс свадьбы, а через 40 недель — ребёнок.
            </p>
          ) : (
            <FamilyTimeline manager={manager} />
          )}
        </div>
      </div>

      {/* Прогресс-бар академии ребёнка — акцент внизу блока семьи */}
      {manager.family?.child && manager.family.child.joinedAcademyPlayerId === null ? (
        <div className="rounded-lg border border-[#D4AF37]/30 bg-[#D4AF37]/5 p-3">
          <div className="mb-2 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 font-semibold">
              <GraduationCap className="size-3.5 text-[#D4AF37]" aria-hidden />
              До академии: {manager.family.child.name}
            </span>
            <span className="tabular text-muted-foreground">
              {manager.family.child.age} / 14 лет
            </span>
          </div>
          <Progress
            value={Math.min(100, (manager.family.child.age / 14) * 100)}
            className="h-2"
            aria-label={`Возраст ребёнка: ${manager.family.child.age} из 14 лет`}
          />
        </div>
      ) : null}
    </div>
  );
}

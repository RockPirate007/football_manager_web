/**
 * Модуль 6 smoke: 2D-радар / UI-данные / графики.
 * Юниты чистой геометрии (radar.ts: фишки, сдвиг блока, мяч, замены,
 * удаления, формы, атрибутный радар) + parseEvents roundtrip (x/y и типы
 * Engine 2.0 переживают сохранение) + интеграция через engineDispatch:
 * XI в UserMatchResultDTO, координаты событий, финансы weekly.
 * Запуск: `bun scripts/m6_smoke.ts`.
 */

import {
  applySubs, attributeRadar, awayKitOf, colorDistance, deriveRadar, formationChips,
  sentOffIds, shiftedChip, shortNameOf,
} from '@/lib/game/radar';
import { parseEvents } from '@/lib/game/types';
import { FORMATIONS } from '@/lib/game/constants';
import { engineDispatch } from '@/engine/router';
import { getEngine } from '@/engine/index';
import type {
  MatchEvent, RadarPlayerDTO, UserMatchResultDTO,
} from '@/lib/game/types';

let pass = 0;
let fail = 0;
const failures: string[] = [];

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    pass += 1;
    console.log(`PASS ${name}`);
  } else {
    fail += 1;
    failures.push(name);
    const suffix = detail !== undefined ? ` :: ${detail}` : '';
    console.log(`FAIL ${name}${suffix}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  check(name, actual === expected, `actual=${String(actual)} expected=${String(expected)}`);
}

// патч uuid (как engine-smoke / m4 / m5)
let uuidCounter = 0;
crypto.randomUUID = ((): string => {
  uuidCounter += 1;
  return `00000000-0000-4000-8000-${String(uuidCounter).padStart(12, '0')}`;
}) as typeof crypto.randomUUID;

const NOW = new Date('2025-07-01T12:00:00Z');

// ── U1: parseEvents — roundtrip координат и типов Engine 2.0 ──────────────

console.log('\n== U1: parseEvents roundtrip ==');

const rawEvents: MatchEvent[] = [
  { minute: 1, type: 'kickoff', text: 'Стартовый свисток' },
  { minute: 12, type: 'shot_on', teamId: 't1', playerId: 'p1', x: 88, y: 44, text: 'Удар в створ' },
  { minute: 34, type: 'duel', teamId: 't2', playerId: 'p9', x: 41, y: 70, text: 'Отбор' },
  { minute: 55, type: 'goal', teamId: 't1', playerId: 'p1', x: 91, y: 50, text: 'Гол!' },
  { minute: 90, type: 'fulltime', text: 'Финальный свисток' },
  { minute: 91, type: 'unknown_future_type', text: '???' } as MatchEvent,
];
const roundtripped = parseEvents(JSON.stringify(rawEvents));
eq('u1_count_known_types', roundtripped.length, 5);
const shot = roundtripped.find((e) => e.type === 'shot_on');
check('u1_shot_x_preserved', shot?.x === 88, `x=${shot?.x}`);
check('u1_shot_y_preserved', shot?.y === 44, `y=${shot?.y}`);
const goal = roundtripped.find((e) => e.type === 'goal');
check('u1_goal_x_preserved', goal?.x === 91);
const duel = roundtripped.find((e) => e.type === 'duel');
check('u1_engine2_type_kept', duel !== undefined);
eq('u1_empty_raw', parseEvents(null).length, 0);
eq('u1_garbage_raw', parseEvents('не json').length, 0);
eq('u1_legacy_no_coords_no_crash', parseEvents('[{"minute":1,"type":"goal","text":"г"}]').length, 1);

// ── U2: фишки формаций (formationChips) ───────────────────────────────────

console.log('\n== U2: formationChips ==');

const xi442: RadarPlayerDTO[] = FORMATIONS['4-4-2'].slots.map((slot, i) => ({
  slot: i,
  playerId: `hp${i}`,
  name: `Иван Игроков ${i + 1}`,
  position: slot.position,
  number: i + 1,
}));

const homeChips = formationChips('4-4-2', xi442, 'home');
eq('u2_home_eleven', homeChips.length, 11);
const homeGk = homeChips[0];
check('u2_home_gk_deep', homeGk.baseX < 15, `x=${homeGk.baseX}`);
const homeSt = homeChips[homeChips.length - 1];
check('u2_home_st_high', homeSt.baseX > 70, `x=${homeSt.baseX}`);
check('u2_home_names_kept', homeChips.every((c) => c.name.includes('Игроков')));
check('u2_home_numbers_kept', homeChips.every((c) => typeof c.number === 'number'));
check('u2_home_positions_from_slots', homeChips[0].position === 'GK');

const awayChips = formationChips('4-4-2', xi442.map((p) => ({ ...p, playerId: `ap${p.slot}` })), 'away');
eq('u2_away_eleven', awayChips.length, 11);
const awayGk = awayChips[0];
check('u2_away_gk_mirrored_deep', awayGk.baseX > 85, `x=${awayGk.baseX}`);
const awaySt = awayChips[awayChips.length - 1];
check('u2_away_st_mirrored_high', awaySt.baseX < 30, `x=${awaySt.baseX}`);
// Зеркальность: homeGk.x + awayGk.x ≈ 100
check('u2_mirror_symmetry', Math.abs(homeGk.baseX + awayGk.baseX - 100) < 1e-9);

// ── U3: сдвиг блока к мячу (shiftedChip) ──────────────────────────────────

console.log('\n== U3: сдвиг блока ==');

const mid = homeChips.find((c) => c.position === 'MC')!;
const shifted = shiftedChip(mid, 80, 20, false);
check('u3_mid_moves_to_ball_x', shifted.baseX > mid.baseX, `${mid.baseX}→${shifted.baseX}`);
check('u3_mid_moves_to_ball_y', shifted.baseY < mid.baseY, `${mid.baseY}→${shifted.baseY}`);
const gkStill = shiftedChip(homeGk, 80, 20, false);
eq('u3_gk_frozen', gkStill.baseX, homeGk.baseX);
const sentOffChip = shiftedChip(mid, 80, 20, true);
eq('u3_sentoff_frozen', sentOffChip.baseX, mid.baseX);
check('u3_shift_bounded', shifted.baseX >= 3 && shifted.baseX <= 97);

// ── U4: deriveRadar — мяч/шлейф/маркеры/лента ─────────────────────────────

console.log('\n== U4: deriveRadar ==');

const events: MatchEvent[] = [
  { minute: 1, type: 'kickoff', text: 'Старт' },
  { minute: 10, type: 'duel', teamId: 't1', playerId: 'p3', x: 30, y: 60, text: 'Единоборство' },
  { minute: 20, type: 'shot_on', teamId: 't1', playerId: 'p9', x: 85, y: 40, text: 'Удар' },
  { minute: 30, type: 'goal', teamId: 't1', playerId: 'p9', x: 90, y: 50, text: 'ГОЛ!' },
  { minute: 32, type: 'momentum', teamId: 't2', x: 45, y: 55, text: 'Перелом' },
  { minute: 40, type: 'sub', teamId: 't1', playerId: 'p20', subOutId: 'p3', text: 'Замена' },
  { minute: 50, type: 'yellow', teamId: 't2', playerId: 'p7', x: 60, y: 30, text: 'ЖК' },
];
const r40 = deriveRadar(events.filter((e) => e.minute <= 40), 2);
// momentum — тоже «двигатель» мяча (перевод владения): мяч на (45,55)
check('u4_ball_at_last_mover', r40.ballX === 45 && r40.ballY === 55, `x=${r40.ballX} y=${r40.ballY}`);
check('u4_trail_has_points', r40.trail.length >= 2);
check('u4_marker_goal_present', r40.markers.some((m) => m.type === 'goal'));
check('u4_marker_window_ttl', !r40.markers.some((m) => m.minute < 30), JSON.stringify(r40.markers.map((m) => m.minute)));
check('u4_marker_goal_lingers', r40.markers.some((m) => m.type === 'goal' && m.minute === 30));
// momentum/sub исключены из «последней реплики» — остаётся гол
eq('u4_last_line_not_sub', r40.lastLine?.type, 'goal');
eq('u4_hot_player', r40.hotPlayerId, 'p9'); // автор гола подсвечен

const r31 = deriveRadar(events.filter((e) => e.minute <= 31), 2);
check('u4_kickoff_center', r31.ballX === 90); // после гола мяч там до след. события
const r1 = deriveRadar(events.filter((e) => e.minute <= 1), 2);
eq('u4_only_kickoff_center', r1.ballX, 50);
const r0 = deriveRadar([], 2);
eq('u4_empty_center', r0.ballX, 50);
const legacy = deriveRadar([{ minute: 5, type: 'goal', teamId: 't1', text: 'г' }], 2);
eq('u4_legacy_no_coords_center', legacy.ballX, 50);

// ── U5: замены и удаления поверх XI ───────────────────────────────────────

console.log('\n== U5: замены/удаления ==');

const afterSubs = applySubs(homeChips, events.filter((e) => e.minute <= 40).map((e) =>
  e.type === 'sub' ? { ...e, subOutId: 'hp3', playerId: 'p20' } : e,
));
const replaced = afterSubs.find((c) => c.slot === 3);
check('u5_sub_replaced_chip', replaced?.playerId === 'p20', `pid=${replaced?.playerId}`);
check('u5_sub_replaced_name', replaced?.name === 'p20' || (replaced?.name ?? '').length > 0);
eq('u5_no_subs_unchanged', applySubs(homeChips, []).every((c, i) => c.playerId === homeChips[i].playerId), true);

const redEvents: MatchEvent[] = [
  { minute: 30, type: 'red', teamId: 't1', playerId: 'p5', text: 'КК' },
];
const off = sentOffIds(redEvents);
check('u5_red_sent_off', off.has('p5'));
const subAfterRed: MatchEvent[] = [
  ...redEvents,
  { minute: 40, type: 'sub', teamId: 't1', playerId: 'p21', subOutId: 'p5', text: 'Замена' },
];
const offAfterSub = sentOffIds(subAfterRed);
check('u5_sub_clears_sent_off', !offAfterSub.has('p5'));

// ── U6: цвета команд (awayKitOf) ──────────────────────────────────────────

console.log('\n== U6: цвета ==');

eq('u6_same_primary_uses_secondary', awayKitOf('#EF4444', '#DC2626', '#1D4ED8'), '#1D4ED8');
eq('u6_diff_primary_keeps_own', awayKitOf('#EF4444', '#1D4ED8', '#FACC15'), '#1D4ED8');
check('u6_distance_same', colorDistance('#EF4444', '#DC2626') < 90);
check('u6_distance_far', colorDistance('#EF4444', '#1D4ED8') > 200);
eq('u6_garbage_far', colorDistance('zzz', '#1D4ED8'), 441);
eq('u6_short_name', shortNameOf('Cristiano Ronaldo'), 'Ronaldo');
eq('u6_short_name_single', shortNameOf('Хулio'), 'Хулio'.slice(0, 12));

// ── U7: атрибутный радар (attributeRadar) ─────────────────────────────────

console.log('\n== U7: attributeRadar ==');

const fieldAttrs = {
  finishing: 16, passing: 14, dribbling: 15, crossing: 12, tackling: 6, marking: 5,
  positioning: 10, heading: 11, pace: 15, stamina: 14, strength: 12, aggression: 8,
  vision: 13, decisions: 12, leadership: 9, acceleration: 16, jumping: 10,
  reflexes: 2, rushingOut: 1, kicking: 3, handling: 2,
};
const fieldRadar = attributeRadar(fieldAttrs, false);
eq('u7_field_six_axes', fieldRadar.length, 6);
check('u7_field_labels', fieldRadar.some((a) => a.label === 'Атака') && fieldRadar.some((a) => a.label === 'Оборона'));
check('u7_field_values_0_100', fieldRadar.every((a) => a.value >= 0 && a.value <= 100));
eq('u7_attack_avg', fieldRadar.find((a) => a.label === 'Атака')?.value, Math.round(((16 + 11) / 2) * 5));
const gkRadar = attributeRadar(fieldAttrs, true);
eq('u7_gk_six_axes', gkRadar.length, 6);
check('u7_gk_own_labels', gkRadar.some((a) => a.label === 'Рефлексы'));

// ── I1: интеграция — XI и координаты в результате недели ──────────────────

console.log('\n== I1: XI и координаты событий (engineDispatch) ==');

type StateApi = {
  snapshot: {
    save: { season: number; week: number; balance: number };
    finances: {
      weekly: { week: number; income: number; expense: number; net: number }[];
    };
  };
};

const engine = getEngine();
const created = await engine.createCareer({
  leagueCode: 'RPL',
  clubIndex: 4,
  managerName: 'М6 Смоук',
  seed: 6666,
  now: NOW,
});
check('i1_career_created', created.slot >= 1 && created.saveId.length > 0);

const sim1 = (await engineDispatch('POST', '/simulate', { saveId: created.saveId })) as {
  ok: boolean;
  result: { userMatches: UserMatchResultDTO[] };
};
check('i1_simulated', sim1.ok);
const um = sim1.result.userMatches[0];
check('i1_user_match_present', um !== undefined);
eq('i1_home_xi_eleven', um.homeXI.length, 11);
eq('i1_away_xi_eleven', um.awayXI.length, 11);
check('i1_xi_slots_ordered', um.homeXI.every((p, i) => p.slot === i) && um.awayXI.every((p, i) => p.slot === i));
check('i1_xi_names_nonempty', um.homeXI.every((p) => p.name.trim().length > 1) && um.awayXI.every((p) => p.name.trim().length > 1));
check('i1_xi_gk_first', um.homeXI[0].position === 'GK' && um.awayXI[0].position === 'GK');
check('i1_xi_numbers', um.homeXI.every((p) => typeof p.number === 'number') && um.awayXI.every((p) => typeof p.number === 'number'));
check(
  'i1_xi_positions_match_formation',
  um.homeXI.every((p, i) => p.position === FORMATIONS[um.home.formation].slots[i].position),
);

// Координаты событий
const withCoords = um.events.filter((e) => typeof e.x === 'number' && typeof e.y === 'number');
check('i1_events_have_coords', withCoords.length >= 5, `count=${withCoords.length}`);
check('i1_coords_in_range', withCoords.every((e) => (e.x ?? 0) >= 0 && (e.x ?? 0) <= 100 && (e.y ?? 0) >= 0 && (e.y ?? 0) <= 100));
const engine2Types = um.events.filter((e) =>
  ['shot_on', 'shot_off', 'save', 'corner', 'offside', 'duel', 'momentum', 'chance'].includes(e.type),
);
check('i1_engine2_events_present', engine2Types.length >= 10, `count=${engine2Types.length}`);

// Полная деривация радара на 90-й минуте
const final = deriveRadar(um.events.filter((e) => e.minute <= 90), 2);
check('i1_radar_derives_final', final.ballX >= 0 && final.ballX <= 100 && final.markers.length >= 0);
const chipsH = applySubs(formationChips(um.home.formation, um.homeXI, 'home'), um.events);
const chipsA = applySubs(formationChips(um.away.formation, um.awayXI, 'away'), um.events);
eq('i1_chips_22', chipsH.length + chipsA.length, 22);

// ── I2: детали матча из БД — parseEvents сохраняет координаты ─────────────

console.log('\n== I2: GET /match — координаты из БД ==');

const detail = (await engineDispatch('GET', '/match', {
  saveId: created.saveId,
  id: um.matchId,
})) as {
  ok: boolean;
  match: { events: MatchEvent[]; stats: { possessionHome: number } | null };
};
check('i2_match_details_ok', detail.ok);
const detCoord = detail.match.events.filter((e) => typeof e.x === 'number');
check('i2_details_keep_coords', detCoord.length >= 5, `count=${detCoord.length}`);
const detEngine2 = detail.match.events.filter((e) =>
  ['shot_on', 'shot_off', 'save', 'corner', 'offside', 'duel', 'momentum'].includes(e.type),
);
check('i2_details_keep_engine2_types', detEngine2.length >= 10, `count=${detEngine2.length}`);
check(
  'i2_details_events_equal_count',
  detail.match.events.length === um.events.length,
  `db=${detail.match.events.length} live=${um.events.length}`,
);

// ── I3: финансы weekly (график «Финансы») ─────────────────────────────────

console.log('\n== I3: финансы weekly ==');

await engineDispatch('POST', '/simulate', { saveId: created.saveId });
await engineDispatch('POST', '/simulate', { saveId: created.saveId });
const state = (await engineDispatch('GET', '/state', { saveId: created.saveId })) as StateApi;
const weekly = state.snapshot.finances.weekly;
check('i3_weekly_present', Array.isArray(weekly) && weekly.length >= 3, `len=${weekly?.length}`);
check('i3_weekly_sorted', weekly.every((w, i) => i === 0 || weekly[i - 1].week < w.week));
check('i3_weekly_net_consistent', weekly.every((w) => w.income - w.expense === w.net));
check('i3_weekly_has_wage_expense', weekly.some((w) => w.expense > 0));

// ── Итог ──────────────────────────────────────────────────────────────────

console.log(`\n=== ИТОГ: ${pass} PASS / ${fail} FAIL ===`);
if (fail > 0) {
  console.log(`Провалены: ${failures.join(', ')}`);
  process.exit(1);
}

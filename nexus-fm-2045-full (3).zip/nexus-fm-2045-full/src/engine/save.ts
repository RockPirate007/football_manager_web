/**
 * Слоты сейвов (спека §2.1–§2.2): slot-1..slot-8.json + meta.json-карточки.
 * Файл слота — канонический JSON (stable key order, Date → ISO, formatVersion):
 * { formatVersion, createdAt, updatedAt, career: CareerDump }. save→load→save
 * даёт байт-в-байт тот же файл: конверт даты обратим (ISO ↔ Date), записи
 * канонизируются при загрузке. Лимит 8 (SAVES_MAX) — программный: 9-й слот →
 * SAVE_LIMIT_REACHED (409). Изоморфно: работа с диском — через StorageAdapter.
 */

import { SAVES_MAX } from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { buildSaveCard } from './career';
import { createSaveStoreFromDump, type SaveStore } from './db';
import type { SlotMeta, StorageAdapter } from './storage';

/** Версия формата слота (миграции по версии при будущих изменениях, §2.1). */
export const SLOT_FORMAT_VERSION = 1;

/** Конверт слота (ISO-строки — как в файле). */
export interface SlotEnvelope {
  formatVersion: number;
  /** ISO — создание карьеры. */
  createdAt: string;
  /** ISO — последний автосейв. */
  updatedAt: string;
}

/** Загруженный/созданный слот: хранилище + конверт (сохраняется при save). */
export interface SlotHandle {
  slot: number;
  store: SaveStore;
  envelope: SlotEnvelope;
}

export interface SaveSlots {
  /** Карточки занятых слотов (сортировка как GET /saves: lastOpenedAt desc). */
  list(): Promise<SlotMeta[]>;
  /** Первый свободный слот 1..8 или null. */
  freeSlot(): Promise<number | null>;
  /** Записать новое карьерное хранилище в первый свободный слот. */
  create(store: SaveStore, options?: { now?: Date }): Promise<SlotHandle>;
  /** Прочитать + распарсить + ревайв Date; SAVE_NOT_FOUND для пустого слота.
   * clock — часы загруженного хранилища (тесты детерминизма; дефолт системные). */
  load(slot: number, options?: { clock?: () => Date }): Promise<SlotHandle>;
  /** Канонический дамп → slot-N.json + meta.json (байт-стабильно для handle). */
  save(handle: SlotHandle): Promise<void>;
  /** Удалить слот + карточку из meta. */
  remove(slot: number): Promise<void>;
  /** Переименовать (1–60 символов): meta.json сразу, careerName в слоте — лениво. */
  rename(slot: number, careerName: string): Promise<void>;
  /** Активный (последний загруженный/созданный) слот, если он ещё занят. */
  current(): SlotHandle | null;
}

interface SlotFile {
  formatVersion: number;
  createdAt: string;
  updatedAt: string;
  career: unknown;
}

function assertSlot(slot: number): void {
  if (!Number.isInteger(slot) || slot < 1 || slot > SAVES_MAX) {
    throw new ApiGameError('SAVE_NOT_FOUND', 404);
  }
}

/** Отметка автосейва: смена updatedAt — ответственность движка (§2.3), не save(). */
export function touchSlot(handle: SlotHandle, now: Date = new Date()): SlotHandle {
  handle.envelope.updatedAt = now.toISOString();
  return handle;
}

/** Файл слота в каноническом виде: порядок ключей фиксирован (§2.1). */
function slotJsonOf(handle: SlotHandle): string {
  const file = {
    formatVersion: handle.envelope.formatVersion,
    createdAt: handle.envelope.createdAt,
    updatedAt: handle.envelope.updatedAt,
    career: handle.store.toJSON(),
  };
  return JSON.stringify(file);
}

function parseSlotFile(raw: string): SlotFile {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    throw new Error(`load: слот содержит не-JSON (${(error as Error).message})`);
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('load: файл слота должен быть объектом');
  }
  const rec = parsed as Record<string, unknown>;
  const formatVersion = typeof rec.formatVersion === 'number' ? rec.formatVersion : 1;
  if (formatVersion > SLOT_FORMAT_VERSION) {
    throw new Error(`load: версия формата ${formatVersion} новее поддерживаемой ${SLOT_FORMAT_VERSION}`);
  }
  if (typeof rec.createdAt !== 'string' || typeof rec.updatedAt !== 'string') {
    throw new Error('load: createdAt/updatedAt должны быть ISO-строками');
  }
  if (rec.career === null || typeof rec.career !== 'object' || Array.isArray(rec.career)) {
    throw new Error('load: career должен быть объектом (дамп таблиц)');
  }
  return {
    formatVersion,
    createdAt: rec.createdAt,
    updatedAt: rec.updatedAt,
    career: rec.career,
  };
}

/** Сортировка карточек как GET /saves: lastOpenedAt desc (null — старейшие), updatedAt desc, slot asc. */
function compareMetas(a: SlotMeta, b: SlotMeta): number {
  const la = a.card.lastOpenedAt;
  const lb = b.card.lastOpenedAt;
  if (la !== lb) {
    if (la === null) return 1;
    if (lb === null) return -1;
    return la < lb ? 1 : -1;
  }
  if (a.updatedAt !== b.updatedAt) return a.updatedAt < b.updatedAt ? 1 : -1;
  return a.slot - b.slot;
}

/** Менеджер слотов поверх StorageAdapter. */
export function createSlots(storage: StorageAdapter): SaveSlots {
  let active: SlotHandle | null = null;

  const slots: SaveSlots = {
    async list(): Promise<SlotMeta[]> {
      const metas = await storage.list();
      return [...metas].sort(compareMetas);
    },

    async freeSlot(): Promise<number | null> {
      const metas = await storage.list();
      const used = new Set(metas.map((m) => m.slot));
      for (let s = 1; s <= SAVES_MAX; s++) {
        if (!used.has(s)) return s;
      }
      return null;
    },

    async create(store: SaveStore, options: { now?: Date } = {}): Promise<SlotHandle> {
      const slot = await this.freeSlot();
      if (slot === null) throw new ApiGameError('SAVE_LIMIT_REACHED', 409);
      const now = options.now ?? new Date();
      const handle: SlotHandle = {
        slot,
        store,
        envelope: {
          formatVersion: SLOT_FORMAT_VERSION,
          createdAt: now.toISOString(),
          updatedAt: now.toISOString(),
        },
      };
      await this.save(handle);
      return handle;
    },

    async load(slot: number, options: { clock?: () => Date } = {}): Promise<SlotHandle> {
      assertSlot(slot);
      const raw = await storage.read(slot);
      if (raw === null) throw new ApiGameError('SAVE_NOT_FOUND', 404);
      const file = parseSlotFile(raw);
      const store = createSaveStoreFromDump(
        file.career,
        options.clock ? { clock: options.clock } : {},
      );
      const handle: SlotHandle = {
        slot,
        store,
        envelope: {
          formatVersion: file.formatVersion,
          createdAt: file.createdAt,
          updatedAt: file.updatedAt,
        },
      };
      active = handle;
      return handle;
    },

    async save(handle: SlotHandle): Promise<void> {
      assertSlot(handle.slot);
      const saveRow = await handle.store.gameSave.findFirst();
      if (!saveRow) {
        throw new Error('save: в хранилище нет строки gameSave (карьера не создана)');
      }
      const card = await buildSaveCard(handle.store, saveRow);
      if (!card) {
        throw new Error('save: не удалось построить карточку карьеры (сейв без клуба?)');
      }
      const json = slotJsonOf(handle);
      await storage.write(handle.slot, json, { slot: handle.slot, card, updatedAt: handle.envelope.updatedAt });
      active = handle;
    },

    async remove(slot: number): Promise<void> {
      assertSlot(slot);
      await storage.remove(slot);
      if (active && active.slot === slot) active = null;
    },

    async rename(slot: number, careerName: string): Promise<void> {
      assertSlot(slot);
      const name = careerName.trim();
      if (name.length < 1 || name.length > 60) {
        throw new ApiGameError('INVALID_CAREER_NAME', 400);
      }
      await storage.rename(slot, name);
      // Поле gameSave.careerName — лениво: в памяти сразу, на диске в слоте —
      // при следующем автосейве (§2.2 rename).
      if (active && active.slot === slot) {
        const row = await active.store.gameSave.findFirst();
        if (row) {
          await active.store.gameSave.update({ where: { id: row.id }, data: { careerName: name } });
        }
      }
    },

    current(): SlotHandle | null {
      return active;
    },
  };
  return slots;
}

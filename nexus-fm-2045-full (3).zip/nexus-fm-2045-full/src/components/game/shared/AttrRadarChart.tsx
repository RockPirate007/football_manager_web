'use client';

import { PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer } from 'recharts';
import { attributeRadar } from '@/lib/game/radar';
import type { Attributes, Position } from '@/lib/game/types';
import { cn } from '@/lib/utils';

/**
 * Модуль 6 — профиль игрока радаром (FM-стиль «Playing Styles»): 6 нормированных
 * осей (средние групп атрибутов 0..100); у вратаря свой профиль осей.
 */
export function AttrRadarChart({
  attrs,
  position,
  className,
}: {
  attrs: Attributes;
  position: Position;
  className?: string;
}) {
  const data = attributeRadar(attrs, position === 'GK');
  return (
    <div className={cn('h-[210px] w-full', className)}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} cx="50%" cy="52%" outerRadius="72%">
          <PolarGrid stroke="rgba(0,212,255,0.16)" />
          <PolarAngleAxis
            dataKey="label"
            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          />
          <Radar
            dataKey="value"
            stroke="#00D4FF"
            fill="#00D4FF"
            fillOpacity={0.26}
            strokeWidth={2}
            isAnimationActive
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

/**
 * Создание карьеры в памяти (порт POST /api/game/saves — атомарная замена
 * легаси /new + /select; спека §1.1 career.ts, §1.4). Мир: generateLeague по
 * коду лиги (6 лиг / 112 клубов), клуб выбирается clubIndex сразу: автосостав
 * 4-4-2, стартовый баланс, цель правления, приветственная новость, финальный
 * gameSave.update(teamId) — одной $transaction поверх SaveStore.
 * Карточки карьер — порт api-helpers.buildSaveCard/buildSaveCards без Prisma.
 * Детерминизм: сид (rng.ts) + детерминированный поток id (см. rngUuid).
 */

import { nextSeasonTarget } from '@/lib/game/board';
import { migrateTransferBudget, migrateWageBudget } from '@/lib/game/budget';
import { buildSeasonPlan, weekLabelOf } from '@/lib/game/calendar';
import {
  BOARD_CONF_START, BOARD_HONEYMOON_WEEKS, START_BALANCE_BASE, START_BALANCE_PER_STRENGTH,
} from '@/lib/game/constants';
import { ApiGameError } from '@/lib/game/error';
import { generateLeague } from '@/lib/game/generate';
import { leagueByCode } from '@/lib/game/leagues';
import { autoLineup, playerCreateData } from '@/lib/game/players';
import { generateStaffForTeam, staffCreateData } from '@/lib/game/staff';
import { generateStaffMarket } from '@/lib/game/staff-market';
import { hashString, mulberry32, type RNG } from '@/lib/game/rng';
import { computeStandings, type StandingMatchInput, type StandingTeamInput } from '@/lib/game/standings';
import type { SaveCardDTO } from '@/lib/game/types';
import { createSaveStore, type EngineOp, type SaveStore } from './db';
import { createId } from './ids';
import { serializeBuildings, startLevelsByStrength } from './buildings';
import { createManagerState, serializeManager } from './manager';
import type { GameSaveRecord } from './models';

// ── createCareer ───────────────────────────────────────────────────────────

export interface CreateCareerInput {
  /** Код лиги из LEAGUES: EPL|LAL|SEA|BUN|FL1|RPL. */
  leagueCode: string;
  /** Индекс клуба в def.clubs (порядок фиксирован). */
  clubIndex: number;
  /** Имя менеджера (1–40 символов после trim). */
  managerName: string;
  /** Название карьеры (опционально, ≤60 символов; дефолт «{Клуб} · Сезон 1»). */
  careerName?: string;
  /** Сид мира (тесты/детерминизм); дефолт hashString(`${uuid}:${Date.now()}`). */
  seed?: number;
  /** Фиксирует createdAt/lastOpenedAt (тесты); дефолт new Date(). */
  now?: Date;
}

export interface CreateCareerResult {
  saveId: string;
  careerName: string;
  league: { code: string; nameRu: string; flag: string };
  club: { name: string; shortName: string };
  /** Карточка новой карьеры — как GET /saves (аддитивно, как у роута). */
  save?: SaveCardDTO;
  /** Готовое in-memory хранилище карьеры (слот пишет его в slot-N.json). */
  store: SaveStore;
}

/** Детерминированный UUID v4-формата из RNG-потока (id не из gameplay-сида). */
function rngUuid(rng: RNG): string {
  const hex: string[] = [];
  for (let i = 0; i < 32; i++) hex.push(Math.floor(rng() * 16).toString(16));
  hex[12] = '4';
  hex[16] = ['8', '9', 'a', 'b'][Math.floor(rng() * 4)];
  const h = hex.join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20, 32)}`;
}

/**
 * Создать карьеру в памяти. Порядок валидации и коды ошибок — как в
 * POST /saves (§6.2): лига → имя → название карьеры.
 */
export async function createCareer(input: CreateCareerInput): Promise<CreateCareerResult> {
  const managerName = input.managerName.trim();
  const careerNameRaw = (input.careerName ?? '').trim();

  const def = leagueByCode(input.leagueCode);
  if (!def || !Number.isInteger(input.clubIndex) || input.clubIndex < 0 || input.clubIndex >= def.teamCount) {
    throw new ApiGameError('INVALID_LEAGUE', 400);
  }
  if (managerName.length < 1 || managerName.length > 40) {
    throw new ApiGameError('INVALID_NAME', 400);
  }
  if (careerNameRaw.length > 60) {
    throw new ApiGameError('INVALID_CAREER_NAME', 400);
  }

  const now = input.now ?? new Date();
  // Часы хранилища заморожены на моменте создания: все createdAt одинаковы
  // (аналог одной транзакции) и детерминированы при фиксированном now.
  const store = createSaveStore({ clock: () => now });

  // Сид мира: как в роуте — невоспроизводим по умолчанию; тесты задают явный.
  const seed = input.seed ?? hashString(`${createId()}:${now.getTime()}`);
  const rng = mulberry32(seed);
  // Поток id отделён от gameplay-сида: generateLeague/generatePlayer расходуют
  // rng в том же порядке, что и на сервере (там id = crypto.randomUUID).
  const idRng = mulberry32(hashString(`${seed}:ids`));
  const idFactory = () => rngUuid(idRng);

  const saveId = idFactory();
  const world = generateLeague(rng, def.code, idFactory);
  // generateSquad назначает id игроков через crypto.randomUUID (не из сида) —
  // переприсваиваем из детерминированного потока; игровые поля не зависят от id.
  for (const team of world.teams) {
    for (const p of team.players) p.id = idFactory();
  }

  const club = world.teams[input.clubIndex];
  const auto = autoLineup(club.players, '4-4-2');
  const startBalance =
    START_BALANCE_BASE + Math.max(0, club.strength - 55) * START_BALANCE_PER_STRENGTH;
  // Модуль 5: стартовые бюджеты правления (трансферный 40% баланса;
  // зарплатный потолок — ведомость стартового состава ×1.12)
  const startTransferBudget = migrateTransferBudget(startBalance, 0);
  const startWageBudget = migrateWageBudget(
    club.players.reduce((s, p) => s + p.salary, 0),
    0,
  );
  const careerName = careerNameRaw.length > 0 ? careerNameRaw : `${club.name} · Сезон 1`;

  // Фаза 3: цель правления по рангу силы клуба (сезон 1 — без прошлого места)
  const boardTarget = nextSeasonTarget({
    teamCount: def.teamCount,
    teams: world.teams.map((t) => ({ id: t.id, strength: t.strength })),
    userTeamId: club.id,
    prevPlace: null,
    harderByOverperformance: false,
  });

  // «select»-блок + вся генерация — одной транзакцией (как в роуте):
  // сейв создаётся БЕЗ teamId, клуб присваивается завершающим update.
  const ops: EngineOp[] = [
    store.gameSave.create({
      data: {
        id: saveId,
        managerName,
        careerName,
        leagueCode: def.code,
        season: 1,
        week: 1,
        balance: startBalance,
        // ── Модуль 5: бюджеты правления ──
        transferBudget: startTransferBudget,
        wageBudget: startWageBudget,
        status: 'active',
        lastOpenedAt: now,
        cupRound: 0,
        // ── Фаза 3: правление ──
        boardTarget: boardTarget.code,
        boardTargetPlace: boardTarget.place,
        boardConfidence: BOARD_CONF_START,
        honeymoonUntilWeek: BOARD_HONEYMOON_WEEKS,
        // D-6 «Тренер» (§4.1/§4.5): профиль менеджера фиксируется при создании
        // карьеры — зарплата по stature клуба, кошелёк 50К, престиж 40.0
        manager: serializeManager(createManagerState(club.strength)),
      },
    }),
  ];
  for (const team of world.teams) {
    const isUser = team.id === club.id;
    ops.push(
      store.team.create({
        data: {
          id: team.id,
          saveId,
          name: team.name,
          shortName: team.shortName,
          city: team.city,
          colorPrimary: team.colorPrimary,
          colorSecondary: team.colorSecondary,
          strength: team.strength,
          isUserTeam: isUser,
          stadiumCapacity: team.stadiumCapacity,
          formation: isUser ? '4-4-2' : team.formation,
          mentality: isUser ? 'balanced' : team.mentality,
          tempo: isUser ? 'medium' : team.tempo,
          pressing: isUser ? 'medium' : team.pressing,
          defLine: isUser ? 'medium' : team.defLine,
          playStyle: isUser ? 'balanced' : team.playStyle,
          // Фаза 4: стиль и тренер ИИ (маппинг полей генерации — фикс роута)
          aiStyle: isUser ? 'balanced' : team.aiStyle,
          aiCoachName: isUser ? null : team.aiCoachName,
          leagueCode: team.leagueCode,
          lineup: isUser ? JSON.stringify(auto.lineup) : null,
          bench: isUser ? JSON.stringify(auto.bench) : null,
          trainingFocus: 'rest',
          trainingIntensity: 'normal',
          // D-5 «Территория»: стартовые уровни зданий по stature — ВСЕМ командам
          // (ИИ — статичные, §3.2 симметрия рейтингов; фиксируются навсегда)
          buildings: serializeBuildings(startLevelsByStrength(team.strength)),
          // Модуль 5: стадион изначально не строится (дефолт 0/null)
          stadiumPending: 0,
          stadiumUpgradeEndsAtDay: null,
        },
      }),
    );
    for (const player of team.players) {
      player.teamId = team.id;
      ops.push(store.player.create({ data: playerCreateData(saveId, player) }));
    }
  }
  // Модуль 2 «Персонал»: тренерский штата всем клубам при создании мира —
  // рейтинг ~ сила клуба; влияет на регены академии (development.academyStaffBonusOf).
  // Модуль 4 добавит рынок/найм/увольнение и остальные роли.
  for (const team of world.teams) {
    const staff = generateStaffForTeam(rng, {
      saveId,
      teamId: team.id,
      season: 1,
      strength: team.strength,
      idFactory,
      pool: def.basePool,
    });
    for (const s of staff) {
      ops.push(store.staff.create({ data: staffCreateData(s) }));
    }
  }
  // Модуль 4: стартовый рынок персонала — свободные кандидаты всех 5 ролей
  // (teamId = null); блок ПОСЛЕ штата клубов — броски rng дописываются в конец
  // потока, существующие генерации (игроки/составы/матчи) не сдвигаются.
  const staffMarket = generateStaffMarket(rng, {
    saveId,
    pool: def.basePool,
    idFactory,
    season: 1,
  });
  for (const s of staffMarket) {
    ops.push(store.staff.create({ data: staffCreateData(s) }));
  }
  for (const match of world.matches) {
    ops.push(
      store.match.create({
        data: {
          id: match.id,
          saveId,
          season: 1,
          week: match.week,
          homeTeamId: match.homeTeamId,
          awayTeamId: match.awayTeamId,
        },
      }),
    );
  }
  ops.push(
    store.newsItem.create({
      data: {
        id: idFactory(),
        saveId,
        season: 1,
        week: 1,
        type: 'info',
        message: `Добро пожаловать в «${club.name}», ${managerName}! Впереди ${def.leagueWeeks} туров и ${def.cupName}! Правление: цель сезона — ${boardTarget.label.toLowerCase()}.`,
      },
    }),
  );
  // Клуб выбран: завершающий update после создания всех команд
  ops.push(store.gameSave.update({ where: { id: saveId }, data: { teamId: club.id } }));
  await store.$transaction(ops);

  const saveRow = await store.gameSave.findUnique({ where: { id: saveId } });
  const card = saveRow ? await buildSaveCard(store, saveRow) : null;

  return {
    saveId,
    careerName,
    league: { code: def.code, nameRu: def.nameRu, flag: def.flag },
    club: { name: club.name, shortName: club.shortName },
    ...(card ? { save: card } : {}),
    store,
  };
}

// ── Карточки карьер (порт api-helpers.buildSaveCard, §6.3) ─────────────────

/**
 * Карточка карьеры: место и форма — по ЛИГОВЫМ матчам текущего сезона
 * (competition='league'), метка недели — по плану сезона. null для сейва
 * без клуба или с неизвестной лигой.
 */
export async function buildSaveCard(
  store: SaveStore,
  save: GameSaveRecord,
): Promise<SaveCardDTO | null> {
  const def = leagueByCode(save.leagueCode);
  if (!def || !save.teamId) return null;
  const plan = buildSeasonPlan(def.code);

  const teams = await store.team.findMany({ where: { saveId: save.id, isEuroGuest: false } });
  const club = teams.find((t) => t.id === save.teamId);
  if (!club) return null;

  const playedLeague = await store.match.findMany({
    where: { saveId: save.id, season: save.season, status: 'played', competition: 'league' },
    select: { homeTeamId: true, awayTeamId: true, homeGoals: true, awayGoals: true, week: true },
  });
  const teamInputs: StandingTeamInput[] = teams.map((t) => ({
    id: t.id,
    name: t.name,
    shortName: t.shortName,
    colorPrimary: t.colorPrimary,
    colorSecondary: t.colorSecondary,
    isUser: t.isUserTeam,
  }));
  const matchInputs: StandingMatchInput[] = playedLeague
    .filter((m) => m.homeGoals !== null && m.awayGoals !== null)
    .map((m) => ({
      homeTeamId: m.homeTeamId,
      awayTeamId: m.awayTeamId,
      homeGoals: m.homeGoals as number,
      awayGoals: m.awayGoals as number,
      week: m.week,
    }));
  const standings = computeStandings(teamInputs, matchInputs);
  const myRow = standings.find((r) => r.teamId === save.teamId);

  const week = Math.min(Math.max(save.week, 1), plan.totalWeeks);

  return {
    id: save.id,
    careerName: save.careerName ?? `${club.name} · Сезон ${save.season}`,
    managerName: save.managerName,
    leagueCode: def.code,
    leagueName: def.nameRu,
    leagueFlag: def.flag,
    teamCount: def.teamCount,
    clubName: club.name,
    clubShort: club.shortName,
    colorPrimary: club.colorPrimary,
    colorSecondary: club.colorSecondary,
    season: save.season,
    week: save.week,
    totalWeeks: plan.totalWeeks,
    weekLabel: weekLabelOf(plan, week),
    place: myRow?.place ?? def.teamCount,
    form: myRow?.form ?? [],
    status: save.status,
    lastOpenedAt: save.lastOpenedAt ? save.lastOpenedAt.toISOString() : null,
    updatedAt: save.updatedAt.toISOString(),
  };
}

/** Карточка единственной карьеры хранилища (движок = 1 сейв на слот). */
export async function buildSaveCards(store: SaveStore): Promise<SaveCardDTO[]> {
  const saves = await store.gameSave.findMany({
    orderBy: [{ lastOpenedAt: 'desc' }, { createdAt: 'desc' }],
  });
  const cards: SaveCardDTO[] = [];
  for (const save of saves) {
    const card = await buildSaveCard(store, save);
    if (card) cards.push(card);
  }
  return cards;
}

/**
 * QA Фаза 3 (Task P3-5) — юнит-проверки чистых функций Фазы 3 (детерминированные
 * инварианты §9, которые нельзя надёжно проверить через API из-за наложения
 * еженедельных факторов): правление (№11/№15/№16), контракты (№2/№21),
 * Босман (№19), история (№6). Запуск: bun scripts/qa3_unit.ts
 * Вывод: PASS/FAIL-строки «key=value|ok» для scripts/qa_phase3.sh.
 */
import { weeklyBoardUpdate, evaluateSeasonTarget, jobStatusOf, boardTargetFor } from '@/lib/game/board';
import type { BoardWeeklyInput } from '@/lib/game/board';
import type { BoardTargetCode } from '@/lib/game/constants';
import {
  yearsLeftOf, renewalOutcome, maxRenewYears, bosmanProbability, contractRoleOf,
  contractUntilFromYears, renewDemand,
} from '@/lib/game/contracts';
import { starsOf, academyTierOf, runIntakeForClub } from '@/lib/game/academy';
import { buildSeasonRecords, careerTotalsOf } from '@/lib/game/history';
import { mulberry32 } from '@/lib/game/rng';
import { poolContextOf } from '@/lib/game/generate';
import { leagueByCode } from '@/lib/game/leagues';
import type { PlayerLike } from '@/lib/game/players';

let pass = 0;
let fail = 0;

function check(name: string, actual: unknown, expected: unknown) {
  if (actual === expected) {
    pass += 1;
    console.log(`${name}=${actual}|ok`);
  } else {
    fail += 1;
    console.log(`${name}=${actual}|expected:${expected}|FAIL`);
  }
}

function checkTrue(name: string, cond: boolean) {
  check(name, cond, true);
}

// ── Игрок-заглушка ────────────────────────────────────────────────────────
const basePlayer = {
  id: 'p1', teamId: 't1', firstName: 'A', lastName: 'B', nationality: 'RU',
  position: 'ST', shirtNumber: 9, age: 24, potential: 90, ovr: 80,
  morale: 70, condition: 100, injuryWeeks: 0, value: 5_000_000, salary: 50_000,
  goals: 0, assists: 0, apps: 0, yellowCards: 0, redCards: 0, trainingXp: '{}',
  cleanSheets: 0, cupGoals: 0, cupAssists: 0,
  contractUntil: 3, preContractTeamId: null, ratingSum: 0, ratingApps: 0, isAcademy: false,
  finishing: 80, passing: 75, dribbling: 78, crossing: 70, tackling: 40, marking: 40,
  positioning: 60, heading: 70, pace: 85, stamina: 80, strength: 75, aggression: 60,
  reflexes: 20, rushingOut: 20, kicking: 30,
} as unknown as PlayerLike;

const match = (outcome: 'W' | 'D' | 'L', myStrength = 80, oppStrength = 78) => ({
  outcome, myStrength, oppStrength, competition: 'league' as const,
  roundPassed: false, wonFinal: false, upsetCupLoss: false,
});
const boardArgs = (over: Partial<BoardWeeklyInput>): BoardWeeklyInput => ({
  confidence: 50, week: 5, totalWeeks: 34, honeymoonUntilWeek: 0, place: 5,
  targetPlace: 5, targetCode: 'uel', teamCount: 16, match: match('W'),
  balance: 1_000_000, wageRatio: 0.5, avgMorale: 70, ...over,
});

// ── №11: матчевые дельты ─────────────────────────────────────────────────
check('board_win_delta', weeklyBoardUpdate(boardArgs({ match: match('W') })).delta, 2);
check('board_win_upset_delta', weeklyBoardUpdate(boardArgs({ match: match('W', 70, 82) })).delta, 3);
check('board_loss_delta', weeklyBoardUpdate(boardArgs({ match: match('L') })).delta, -2);
check('board_loss_weak_delta', weeklyBoardUpdate(boardArgs({ match: match('L', 82, 60) })).delta, -3);
check('board_draw_even_delta', weeklyBoardUpdate(boardArgs({ match: match('D') })).delta, 0);
checkTrue('board_conf_clamp_100', weeklyBoardUpdate(boardArgs({ confidence: 99, match: match('W') })).confidence === 100);
checkTrue('board_conf_clamp_0', weeklyBoardUpdate(boardArgs({ confidence: 1, match: match('L') })).confidence === 0);

// ── №12: honeymoon floor ─────────────────────────────────────────────────
check('board_honeymoon_floor', weeklyBoardUpdate(
  boardArgs({ confidence: 20, week: 3, honeymoonUntilWeek: 8, match: match('L', 82, 40) }),
).confidence, 35);
checkTrue('board_honeymoon_off', weeklyBoardUpdate(
  boardArgs({ confidence: 20, week: 9, honeymoonUntilWeek: 8, match: match('L', 82, 40) }),
).confidence < 35);

// ── №15/№16: вердикт сезона ──────────────────────────────────────────────
const teams = Array.from({ length: 16 }, (_, i) => ({ id: `t${i}`, strength: 90 - i }));
const verdictArgs = (place: number, conf: number, targetCode: BoardTargetCode = 'champion', targetPlace = 1) => ({
  place, targetCode, targetPlace, confidence: conf, teamCount: 16, teams,
  userTeamId: 't0', prevPlace: null,
});
check('verdict_over', evaluateSeasonTarget(verdictArgs(1, 55, 'champion', 4)).verdict, 'over');
check('verdict_over_boundary_3', evaluateSeasonTarget(verdictArgs(3, 55, 'uel', 6)).verdict, 'over');
check('verdict_over_boundary_4_met', evaluateSeasonTarget(verdictArgs(4, 55, 'uel', 6)).verdict, 'met');
check('verdict_met', evaluateSeasonTarget(verdictArgs(1, 55, 'champion', 1)).verdict, 'met');
check('verdict_met_boundary', evaluateSeasonTarget(verdictArgs(6, 55, 'uel', 6)).verdict, 'met');
check('verdict_missed', evaluateSeasonTarget(verdictArgs(7, 55, 'uel', 6)).verdict, 'missed');
checkTrue('verdict_sack_miss4_conf30', evaluateSeasonTarget(verdictArgs(10, 25, 'uel', 6)).sacked);
checkTrue('verdict_sack_miss3_no', !evaluateSeasonTarget(verdictArgs(9, 25, 'uel', 6)).sacked);
checkTrue('verdict_sack_conf29_no_miss', !evaluateSeasonTarget(verdictArgs(9, 31, 'uel', 6)).sacked);
checkTrue('verdict_sack_hard_conf14', evaluateSeasonTarget(verdictArgs(1, 14, 'champion', 1)).sacked);
checkTrue('verdict_sack_hard_conf15_no', !evaluateSeasonTarget(verdictArgs(1, 15, 'champion', 1)).sacked);
check('verdict_over_conf_next', evaluateSeasonTarget(verdictArgs(1, 55, 'champion', 4)).confidenceNext, 70);
check('verdict_met_conf_next', evaluateSeasonTarget(verdictArgs(1, 40, 'champion', 1)).confidenceNext, 60);
check('verdict_missed_conf_next', evaluateSeasonTarget(verdictArgs(7, 42, 'uel', 6)).confidenceNext, 42);
check('verdict_over_bonus', evaluateSeasonTarget(verdictArgs(1, 55, 'champion', 4)).bonus, 2_000_000);

// ── №21: границы продления ──────────────────────────────────────────────
check('renew_accepted_at_092', renewalOutcome(92, 100), 'accepted');
checkTrue('renew_counter_below_092', renewalOutcome(91, 100) === 'counter');
check('years_left_1', yearsLeftOf(3, 3), 1);
check('years_left_0', yearsLeftOf(2, 3), 0);
check('years_left_4', yearsLeftOf(6, 3), 4);
check('max_renew_years_29', maxRenewYears(29), 4);
check('max_renew_years_30', maxRenewYears(30), 2);
check('contract_until_from_years', contractUntilFromYears(3, 4), 6);
checkTrue('contract_role_star', contractRoleOf(basePlayer, [basePlayer]) === 'star');

// ── №19: вероятность Босмана ────────────────────────────────────────────
const happy = { ...basePlayer, morale: 70, salary: 50_000, apps: 30 } as PlayerLike;
const unhappy = { ...basePlayer, morale: 20, salary: 100, apps: 0 } as PlayerLike;
const pHappy = bosmanProbability({ player: happy, teamApps: 30 });
const pUnhappy = bosmanProbability({ player: unhappy, teamApps: 30 });
check('bosman_base_p', Math.round(pHappy * 100) / 100, 0.1);
check('bosman_max_p', Math.round(pUnhappy * 100) / 100, 0.75);
checkTrue('bosman_only_last_year_logic_depends_on_caller', true); // фильтр contractUntil === season — в week.ts

// ── №9/№10: тиры и звёзды академии ──────────────────────────────────────
check('academy_tier_top', academyTierOf(84), 'top');
check('academy_tier_mid', academyTierOf(74), 'mid');
check('academy_tier_low', academyTierOf(73), 'low');
check('stars_5_at_85', starsOf(85), 5);
check('stars_4_at_84', starsOf(84), 4);
check('stars_1_below_62', starsOf(61), 1);

// ── №6: снапшот истории ─────────────────────────────────────────────────
const rated = { ...basePlayer, ratingSum: 6800, ratingApps: 100, apps: 30, goals: 10 } as PlayerLike;
const unrated = { ...basePlayer, id: 'p2', ratingSum: 0, ratingApps: 0, apps: 0, goals: 0 } as PlayerLike;
const rows = buildSeasonRecords({
  season: 1, squadPlayers: [rated], freeAgents: [unrated], teamNameById: new Map([['t1', 'Клуб']]),
});
check('history_avg_rating_x10', rows.find((r) => r.playerId === 'p1')?.avgRating, 68);
check('history_unrated_zero', rows.find((r) => r.playerId === 'p2')?.avgRating, 0);
check('history_free_agent_name', rows.find((r) => r.playerId === 'p2')?.teamName, 'Свободный агент');
const totals = careerTotalsOf(rows);
check('history_totals_seasons', totals.seasons, 2);
check('history_totals_apps', totals.apps, 30);
check('history_totals_avg', totals.avgRating, 6.8);

// ── renewDemand: округление к SALARY_ROUND и границы ─────────────────────
const demand = renewDemand({ player: basePlayer, squad: [basePlayer], teamApps: 10 });
checkTrue('renew_demand_rounded', demand % 100 === 0);
checkTrue('renew_demand_above_salary', demand > basePlayer.salary);

// ── Цели: матрица boardTargetFor ─────────────────────────────────────────
check('target_rank1', boardTargetFor(1, 16).code, 'champion');
check('target_rank3', boardTargetFor(3, 16).code, 'ucl');
check('target_rank6', boardTargetFor(6, 16).code, 'uel');
check('target_rank8', boardTargetFor(8, 16).code, 'upper');
check('target_rank13', boardTargetFor(13, 16).code, 'safe');
check('target_rank16', boardTargetFor(16, 16).code, 'survive');

// ── 7 статусов должности ────────────────────────────────────────────────
const statuses = new Set([0, 25, 35, 45, 60, 75, 90].map((c) => jobStatusOf(c).code));
check('job_statuses_7_unique', statuses.size, 7);

// ── №9/№10: статистика академии (200 наборов × 3 тира, детерминированный RNG) ──
{
  const def = leagueByCode('RPL');
  const pool = def ? poolContextOf(def) : null;
  if (pool) {
    const stats = (strength: number) => {
      const rng = mulberry32(42 + strength);
      let pots: number[] = [];
      let gems = 0;
      let golden = 0;
      let goldenWithGem = 0;
      for (let i = 0; i < 200; i++) {
        const r = runIntakeForClub({ rng, season: 1, team: { id: 'x', strength }, squad: [], pool });
        pots = pots.concat(r.players.map((p) => p.potential));
        gems += r.gemCount;
        if (r.golden) {
          golden += 1;
          if (r.gemCount >= 1) goldenWithGem += 1;
        }
      }
      return {
        count: pots.length,
        avgPot: pots.reduce((s, p) => s + p, 0) / pots.length,
        maxPot: Math.max(...pots),
        gemFreq: gems / pots.length,
        golden, goldenWithGem,
      };
    };
    const top = stats(90);
    const mid = stats(80);
    const low = stats(65);
    console.log(`academy_top players=${top.count} avgPot=${top.avgPot.toFixed(1)} maxPot=${top.maxPot} gemFreq=${top.gemFreq.toFixed(3)} golden=${top.golden}/${top.goldenWithGem}`);
    console.log(`academy_mid players=${mid.count} avgPot=${mid.avgPot.toFixed(1)} gemFreq=${mid.gemFreq.toFixed(3)}`);
    console.log(`academy_low players=${low.count} avgPot=${low.avgPot.toFixed(1)} gemFreq=${low.gemFreq.toFixed(3)}`);
    checkTrue('academy_top_max_pot_88', top.maxPot >= 88);
    checkTrue('academy_top_avg_above_low', top.avgPot > low.avgPot);
    checkTrue('academy_gem_freq_top', top.gemFreq >= 0.04 && top.gemFreq <= 0.14);
    checkTrue('academy_gem_freq_mid', mid.gemFreq >= 0.012 && mid.gemFreq <= 0.06);
    checkTrue('academy_gem_freq_low', low.gemFreq >= 0.002 && low.gemFreq <= 0.03);
    checkTrue('academy_golden_guarantees_gem', top.golden === 0 || top.goldenWithGem === top.golden);
  } else {
    checkTrue('academy_pool_found', false);
  }
}

console.log(`unit_pass=${pass}`);
console.log(`unit_fail=${fail}`);
if (fail > 0) process.exit(1);

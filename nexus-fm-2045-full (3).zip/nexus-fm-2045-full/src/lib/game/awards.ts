/**
 * Награды сезона: 8 наград, MVP-формула, бонусы лауреатам, live-лидеры.
 * §5 architecture-upgrade.md. Чистый модуль (запись в БД — в week.ts).
 */

import { AWARD_MORALE, AWARD_MVP_W, AWARD_VALUE_MULT } from './constants';
import type { PlayerLike } from './players';
import { clamp } from './rng';
import { AWARD_TYPE_LABELS } from './types';
import type { PlayerLeaderDTO, StandingRow } from './types';

export type AwardType =
  | 'top_scorer' | 'top_assist' | 'mvp' | 'young'
  | 'golden_glove' | 'cup_scorer' | 'champion' | 'cup_winner';

export const AWARD_CEREMONY_ORDER: AwardType[] = [
  'champion', 'cup_winner', 'top_scorer', 'top_assist',
  'golden_glove', 'young', 'cup_scorer', 'mvp',
];

/** MVP = 4×голы + 2.5×пасы + 0.5×матчи + 2×(OVR − 70). */
export function mvpScore(p: { goals: number; assists: number; apps: number; ovr: number }): number {
  return (
    AWARD_MVP_W.goal * p.goals +
    AWARD_MVP_W.assist * p.assists +
    AWARD_MVP_W.app * p.apps +
    AWARD_MVP_W.ovr * (p.ovr - AWARD_MVP_W.ovrBase)
  );
}

export interface AwardDraft {
  type: AwardType;
  playerId: string | null; // null для командных наград
  teamId: string;
  value: number;
  label: string;
}

interface PlayerRef {
  id: string;
  name: string;
  teamId: string;
  teamName: string;
}

function playerLabel(p: PlayerRef, value: number, unit: string): string {
  return `${p.name} (${p.teamName}) — ${value} ${unit}`;
}

/**
 * Вычисление 8 наград сезона. Вызывается ДО старения и сброса статистики.
 * Возвращает drafts в порядке церемонии.
 */
export function computeSeasonAwards(args: {
  teams: { id: string; name: string }[];
  players: PlayerLike[]; // все игроки лиги (не только клуба игрока)
  standings: StandingRow[]; // финальная таблица лиги
  cupWinnerTeamId: string | null;
}): AwardDraft[] {
  const { teams, players, standings, cupWinnerTeamId } = args;
  const teamName = new Map(teams.map((t) => [t.id, t.name]));
  const ref = (p: PlayerLike): PlayerRef => ({
    id: p.id,
    name: `${p.firstName} ${p.lastName}`,
    teamId: p.teamId as string,
    teamName: p.teamId ? (teamName.get(p.teamId) ?? '') : '',
  });

  const drafts: AwardDraft[] = [];

  // Командные: чемпион
  const champion = standings[0];
  if (champion) {
    drafts.push({
      type: 'champion',
      playerId: null,
      teamId: champion.teamId,
      value: champion.points,
      label: `${champion.name} — ${champion.points} очков`,
    });
  }

  // Командные: обладатель кубка
  if (cupWinnerTeamId) {
    const name = teamName.get(cupWinnerTeamId) ?? '';
    drafts.push({
      type: 'cup_winner',
      playerId: null,
      teamId: cupWinnerTeamId,
      value: 1,
      label: `${name} — обладатель кубка`,
    });
  }

  const withTeam = players.filter((p) => p.teamId !== null);

  // Золотая бутса: max goals; тай-брейки — меньше apps, больше assists, выше ovr
  const scorer = [...withTeam].sort(
    (a, b) => b.goals - a.goals || a.apps - b.apps || b.assists - a.assists || b.ovr - a.ovr,
  )[0];
  if (scorer && scorer.goals > 0) {
    drafts.push({
      type: 'top_scorer',
      playerId: scorer.id,
      teamId: scorer.teamId as string,
      value: scorer.goals,
      label: playerLabel(ref(scorer), scorer.goals, 'голов'),
    });
  }

  // Лучший ассистент: max assists; тай-брейки — больше goals, меньше apps, выше ovr
  const assist = [...withTeam].sort(
    (a, b) => b.assists - a.assists || b.goals - a.goals || a.apps - b.apps || b.ovr - a.ovr,
  )[0];
  if (assist && assist.assists > 0) {
    drafts.push({
      type: 'top_assist',
      playerId: assist.id,
      teamId: assist.teamId as string,
      value: assist.assists,
      label: playerLabel(ref(assist), assist.assists, 'пасов'),
    });
  }

  // Золотая перчатка: max cleanSheets (GK); тай-брейки — больше apps, выше ovr
  const gks = withTeam.filter((p) => p.position === 'GK');
  const glove = [...gks].sort(
    (a, b) => b.cleanSheets - a.cleanSheets || b.apps - a.apps || b.ovr - a.ovr,
  )[0];
  if (glove && glove.cleanSheets > 0) {
    drafts.push({
      type: 'golden_glove',
      playerId: glove.id,
      teamId: glove.teamId as string,
      value: glove.cleanSheets,
      label: playerLabel(ref(glove), glove.cleanSheets, '«сухих» матчей'),
    });
  }

  // Лучший молодой (U21: возраст на момент вручения ≤ 20): max mvpScore; тай-брейк — больше goals
  const youngs = withTeam.filter((p) => p.age <= 20);
  const young = [...youngs].sort(
    (a, b) => mvpScore(b) - mvpScore(a) || b.goals - a.goals,
  )[0];
  if (young) {
    const score = Math.round(mvpScore(young));
    drafts.push({
      type: 'young',
      playerId: young.id,
      teamId: young.teamId as string,
      value: score,
      label: playerLabel(ref(young), score, 'очков MVP'),
    });
  }

  // Бомбардир кубка: max cupGoals; тай-брейки — больше cupAssists, больше goals
  const cupScorer = [...withTeam].sort(
    (a, b) => b.cupGoals - a.cupGoals || b.cupAssists - a.cupAssists || b.goals - a.goals,
  )[0];
  if (cupScorer && cupScorer.cupGoals > 0) {
    drafts.push({
      type: 'cup_scorer',
      playerId: cupScorer.id,
      teamId: cupScorer.teamId as string,
      value: cupScorer.cupGoals,
      label: playerLabel(ref(cupScorer), cupScorer.cupGoals, 'голов в кубке'),
    });
  }

  // MVP: max mvpScore, НЕ вратари; тай-брейк — больше goals
  const field = withTeam.filter((p) => p.position !== 'GK');
  const mvp = [...field].sort((a, b) => mvpScore(b) - mvpScore(a) || b.goals - a.goals)[0];
  if (mvp) {
    const score = Math.round(mvpScore(mvp));
    drafts.push({
      type: 'mvp',
      playerId: mvp.id,
      teamId: mvp.teamId as string,
      value: score,
      label: playerLabel(ref(mvp), score, 'очков MVP'),
    });
  }

  // Порядок церемонии
  const byType = new Map(drafts.map((d) => [d.type as string, d]));
  const ordered: AwardDraft[] = [];
  for (const type of AWARD_CEREMONY_ORDER) {
    const d = byType.get(type);
    if (d) ordered.push(d);
  }
  return ordered;
}

/**
 * Бонусы лауреатам КЛУБА ИГРОКА: мораль +10 (clamp 5..100), value ×1.05.
 * Возвращает тексты новостей. Мутирует игроков на месте.
 */
export function applyAwardBonuses(
  drafts: AwardDraft[],
  userTeamId: string,
  players: PlayerLike[],
): string[] {
  const news: string[] = [];
  const mine = new Map(players.map((p) => [p.id, p]));
  for (const d of drafts) {
    if (!d.playerId) continue;
    const p = mine.get(d.playerId);
    if (!p || p.teamId !== userTeamId) continue;
    p.morale = clamp(p.morale + AWARD_MORALE, 5, 100);
    p.value = Math.round(p.value * AWARD_VALUE_MULT);
    news.push(`${AWARD_TYPE_LABELS[d.type] ?? 'Награда'}: ${p.firstName} ${p.lastName} — ${d.label.split(' — ')[1] ?? ''}`);
  }
  return news;
}

export interface LeaderTeamInfo {
  name: string;
  shortName: string;
  c1: string;
  c2: string;
  isUser: boolean;
}

/** Live-лидеры сезона: топ-N бомбардиров и ассистентов. */
export function liveLeaders(args: {
  players: PlayerLike[];
  teams: Map<string, LeaderTeamInfo>;
  take?: number;
}): { topScorers: PlayerLeaderDTO[]; topAssists: PlayerLeaderDTO[] } {
  const { players, teams } = args;
  const take = args.take ?? 10;
  const withTeam = players.filter((p) => p.teamId !== null);

  const toDto = (p: PlayerLike): PlayerLeaderDTO => {
    const t = p.teamId ? teams.get(p.teamId) : undefined;
    return {
      playerId: p.id,
      name: `${p.firstName} ${p.lastName}`,
      teamId: p.teamId as string,
      teamName: t?.name ?? '',
      teamShort: t?.shortName ?? '',
      colorPrimary: t?.c1 ?? '#0E7490',
      colorSecondary: t?.c2 ?? '#F0F6FC',
      isUser: t?.isUser ?? false,
      goals: p.goals,
      assists: p.assists,
      apps: p.apps,
      ovr: p.ovr,
    };
  };

  const topScorers = [...withTeam]
    .sort((a, b) => b.goals - a.goals || b.assists - a.assists || b.apps - a.apps)
    .slice(0, take)
    .map(toDto);
  const topAssists = [...withTeam]
    .sort((a, b) => b.assists - a.assists || b.goals - a.goals || b.apps - a.apps)
    .slice(0, take)
    .map(toDto);

  return { topScorers, topAssists };
}

/** Live бомбардиры кубка (топ-N по cupGoals) — для экрана «Кубок»/«Награды». */
export function liveCupScorers(args: {
  players: PlayerLike[];
  teams: Map<string, LeaderTeamInfo>;
  take?: number;
}): PlayerLeaderDTO[] {
  const { players, teams } = args;
  const take = args.take ?? 5;
  const withTeam = players.filter((p) => p.teamId !== null);
  return [...withTeam]
    .sort((a, b) => b.cupGoals - a.cupGoals || b.cupAssists - a.cupAssists)
    .slice(0, take)
    .map((p) => {
      const t = p.teamId ? teams.get(p.teamId) : undefined;
      return {
        playerId: p.id,
        name: `${p.firstName} ${p.lastName}`,
        teamId: p.teamId as string,
        teamName: t?.name ?? '',
        teamShort: t?.shortName ?? '',
        colorPrimary: t?.c1 ?? '#0E7490',
        colorSecondary: t?.c2 ?? '#F0F6FC',
        isUser: t?.isUser ?? false,
        goals: p.cupGoals, // для единообразия DTO: голы кубковые
        assists: p.cupAssists,
        apps: p.apps,
        ovr: p.ovr,
      };
    });
}

/**
 * Live бомбардиры Кубка Европы (топ-N по euroGoals) — экран «Европа»/«Награды».
 * Фаза 4 (§5.5 ТЗ): в отличие от лиговых лидеров — ВСЕ игроки сейва,
 * включая гостей (isEuroGuest); без голов — пусто (UI покажет заглушку).
 */
export function liveEuroScorers(args: {
  players: PlayerLike[];
  teams: Map<string, LeaderTeamInfo>;
  take?: number;
}): PlayerLeaderDTO[] {
  const { players, teams } = args;
  const take = args.take ?? 10;
  const withTeam = players.filter((p) => p.teamId !== null && (p.euroGoals > 0 || p.euroAssists > 0));
  return [...withTeam]
    .sort((a, b) => b.euroGoals - a.euroGoals || b.euroAssists - a.euroAssists || b.apps - a.apps)
    .slice(0, take)
    .map((p) => {
      const t = p.teamId ? teams.get(p.teamId) : undefined;
      return {
        playerId: p.id,
        name: `${p.firstName} ${p.lastName}`,
        teamId: p.teamId as string,
        teamName: t?.name ?? '',
        teamShort: t?.shortName ?? '',
        colorPrimary: t?.c1 ?? '#0E7490',
        colorSecondary: t?.c2 ?? '#F0F6FC',
        isUser: t?.isUser ?? false,
        goals: p.euroGoals, // для единообразия DTO: голы еврокубковые
        assists: p.euroAssists,
        apps: p.apps,
        ovr: p.ovr,
      };
    });
}

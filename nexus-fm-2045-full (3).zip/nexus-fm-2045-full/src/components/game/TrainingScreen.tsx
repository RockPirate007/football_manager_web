'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, AlertTriangle, Bandage, Bed, Dumbbell, Hand, Loader2, Repeat, Save, Shield, Swords,
  Target, Zap,
} from 'lucide-react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { OvrBadge } from '@/components/game/shared/OvrBadge';
import { PositionBadge } from '@/components/game/shared/PositionBadge';
import { SectionHeader } from '@/components/game/shared/SectionHeader';
import { potentialStarsOf, starsLabelOf, talentLabelOf } from '@/lib/game/development';
import { ATTR_LABELS, type AttrKey } from '@/lib/game/types';
import type { TrainingFocus, TrainingIntensity, TrainingPlayerDTO } from '@/lib/game/types';
import { useGameStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { StaffTab } from '@/components/game/StaffTab';

/** Константы отображения фокусов (иконки + описания-фолбэки). */
const FOCUS_LABELS: Record<TrainingFocus, string> = {
  attack: 'Атака',
  defense: 'Защита',
  possession: 'Владение',
  physical: 'Физика',
  goalkeepers: 'Вратари',
  rest: 'Отдых',
};

const FOCUS_META: Record<TrainingFocus, { icon: typeof Swords; hint: string }> = {
  attack: { icon: Swords, hint: 'Финиш, дриблинг, кроссы, скорость' },
  defense: { icon: Shield, hint: 'Отбор, опека, позиционирование, игра головой' },
  possession: { icon: Repeat, hint: 'Пас, дриблинг, позиционирование, агрессия' },
  physical: { icon: Zap, hint: 'Скорость, выносливость, сила' },
  goalkeepers: { icon: Hand, hint: 'Рефлексы, выходы, ввод мяча — только вратари' },
  rest: { icon: Bed, hint: 'Восстановление: +10 состояния, +3 морали' },
};

const FOCUS_ORDER: TrainingFocus[] = ['attack', 'defense', 'possession', 'physical', 'goalkeepers', 'rest'];

const INTENSITY_META: Record<TrainingIntensity, { label: string; note: string; tone: string }> = {
  light: { label: 'Лёгкая', note: '+5 состояния · риск травм 0.5%', tone: 'text-[#22C55E]' },
  normal: { label: 'Обычная', note: 'без потерь состояния · риск травм 1%', tone: 'text-foreground' },
  hard: { label: 'Жёсткая', note: '−8 состояния · риск травм 3%', tone: 'text-[#EF4444]' },
};

const INTENSITY_ORDER: TrainingIntensity[] = ['light', 'normal', 'hard'];
const INTENSITY_INDEX: Record<TrainingIntensity, number> = { light: 0, normal: 1, hard: 2 };
const INTENSITY_BY_INDEX: TrainingIntensity[] = ['light', 'normal', 'hard'];

const INDIVIDUAL_FOCUS_OPTIONS: { value: string; label: string }[] = [
  { value: 'team', label: 'Командная' },
  ...FOCUS_ORDER.map((f) => ({ value: f, label: FOCUS_LABELS[f] })),
];

const INDIVIDUAL_INTENSITY_OPTIONS: { value: string; label: string }[] =
  INTENSITY_ORDER.map((i) => ({ value: i, label: INTENSITY_META[i].label }));

/** Компактный селект-контрол строки состава. */
function RowSelect({
  value,
  options,
  onChange,
  ariaLabel,
  className,
}: {
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
  ariaLabel: string;
  className?: string;
}) {
  const current = options.find((o) => o.value === value);
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger aria-label={ariaLabel} className={cn('h-7 w-[130px] text-[11px]', className)}>
        <SelectValue>{current?.label ?? value}</SelectValue>
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value} className="text-xs">
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/** Таблица состава: прогресс по фокусу + индивидуальная программа (Модуль 4). */
function SquadProgress({
  squad,
  teamFocus,
  onSetIndividual,
  savingPlayerId,
}: {
  squad: TrainingPlayerDTO[];
  teamFocus: TrainingFocus;
  onSetIndividual: (
    playerId: string,
    individual: { focus: TrainingFocus; intensity: TrainingIntensity } | null,
  ) => void;
  savingPlayerId: string | null;
}) {
  const rows = useMemo(() => [...squad].sort((a, b) => b.ovr - a.ovr), [squad]);

  return (
    <div className="scroll-thin max-h-96 overflow-y-auto rounded-lg border border-border/70 bg-card">
      <Table className="min-w-[860px]">
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="h-10 text-[11px]">Игрок</TableHead>
            <TableHead className="h-10 w-16 text-center text-[11px]">Поз</TableHead>
            <TableHead className="h-10 w-10 text-center text-[11px]">Возр</TableHead>
            <TableHead className="h-10 w-12 text-center text-[11px]">OVR</TableHead>
            <TableHead className="h-10 w-40 text-[11px]">Потенциал</TableHead>
            <TableHead className="h-10 text-[11px]">Прогресс по фокусу</TableHead>
            <TableHead className="h-10 w-[280px] text-[11px]">Индивидуально</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="zebra">
          {rows.map((p) => {
            const xpEntries = Object.entries(p.trainingXp ?? {}) as [AttrKey, number][];
            const potentialPct = Math.min(100, Math.round((p.ovr / Math.max(p.potential, 1)) * 100));
            const ind = p.individual;
            const saving = savingPlayerId === p.id;
            return (
              <TableRow key={p.id} className="h-10 border-border/40">
                <TableCell className="py-1.5">
                  <div className="flex items-center gap-2">
                    <OvrBadge ovr={p.ovr} size="sm" />
                    <span className="truncate text-xs">
                      {p.firstName} {p.lastName}
                    </span>
                    {p.injuryWeeks > 0 ? (
                      <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[9px] text-[#EF4444]">
                        <Bandage className="size-2.5" aria-hidden />
                        {p.injuryWeeks} нед
                      </Badge>
                    ) : null}
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <PositionBadge position={p.position} />
                </TableCell>
                <TableCell className="text-center text-xs tabular text-muted-foreground">{p.age}</TableCell>
                <TableCell className="text-center text-xs font-bold tabular">{p.ovr}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Progress value={potentialPct} className="h-1.5" aria-hidden />
                    <span
                      className="shrink-0 text-[10px] text-[#EAB308]"
                      title={`Потолок: ${talentLabelOf(potentialStarsOf(p.potential))}`}
                    >
                      {starsLabelOf(potentialStarsOf(p.potential))}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  {xpEntries.length === 0 ? (
                    <span className="text-[11px] text-muted-foreground">—</span>
                  ) : (
                    <div className="flex flex-wrap gap-x-3 gap-y-1">
                      {xpEntries.map(([attr, xp]) => (
                        <span
                          key={attr}
                          className="flex items-center gap-1.5"
                          title={`${ATTR_LABELS[attr] ?? attr}: ${(xp * 100).toFixed(0)}% до +1`}
                        >
                          <span className="text-[10px] text-muted-foreground">
                            {ATTR_LABELS[attr] ?? attr}
                          </span>
                          <span className="h-1 w-10 overflow-hidden rounded-full bg-secondary">
                            <span
                              className="block h-full rounded-full bg-primary"
                              style={{ width: `${Math.min(100, xp * 100)}%` }}
                            />
                          </span>
                        </span>
                      ))}
                    </div>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1.5">
                    {saving ? (
                      <Loader2 className="size-3.5 animate-spin text-muted-foreground" aria-hidden />
                    ) : null}
                    <RowSelect
                      ariaLabel={`Индивидуальный фокус: ${p.firstName} ${p.lastName}`}
                      value={ind?.focus ?? 'team'}
                      options={INDIVIDUAL_FOCUS_OPTIONS}
                      onChange={(v) => {
                        if (v === 'team') {
                          // сброс всей программы
                          onSetIndividual(p.id, null);
                          return;
                        }
                        const focus = v as TrainingFocus;
                        const intensity = ind?.intensity ?? 'normal';
                        onSetIndividual(p.id, { focus, intensity });
                      }}
                    />
                    <RowSelect
                      ariaLabel={`Индивидуальная интенсивность: ${p.firstName} ${p.lastName}`}
                      value={ind?.intensity ?? 'normal'}
                      options={INDIVIDUAL_INTENSITY_OPTIONS}
                      className="w-[130px]"
                      onChange={(v) => {
                        // без программы: стартует с текущего командного фокуса
                        onSetIndividual(p.id, {
                          focus: ind?.focus ?? teamFocus,
                          intensity: (v === 'team' ? 'normal' : v) as TrainingIntensity,
                        });
                      }}
                    />
                    {ind !== null ? (
                      <button
                        type="button"
                        title="Сбросить к командной программе"
                        aria-label={`Сброс программы: ${p.firstName} ${p.lastName}`}
                        onClick={() => onSetIndividual(p.id, null)}
                        className="rounded-md border border-border/60 px-1.5 py-0.5 text-[10px] text-muted-foreground transition-colors hover:border-[#EF4444]/40 hover:text-[#EF4444]"
                      >
                        сброс
                      </button>
                    ) : null}
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

/** Вкладка «Программа»: фокус, ползунок интенсивности, прогресс состава. */
function ProgramTab() {
  const snapshot = useGameStore((s) => s.snapshot)!;
  const trainingCache = useGameStore((s) => s.trainingCache);
  const trainingLoading = useGameStore((s) => s.trainingLoading);
  const fetchTraining = useGameStore((s) => s.fetchTraining);
  const setTraining = useGameStore((s) => s.setTraining);
  const setPlayerTraining = useGameStore((s) => s.setPlayerTraining);
  const loading = useGameStore((s) => s.loading);

  const initial = trainingCache?.training ?? snapshot.training;
  const [localFocus, setLocalFocus] = useState<TrainingFocus | null>(null);
  const [localIntensity, setLocalIntensity] = useState<TrainingIntensity | null>(null);
  const focus = localFocus ?? initial.focus;
  const intensity = localIntensity ?? initial.intensity;
  const dirty = focus !== initial.focus || intensity !== initial.intensity;
  const [saving, setSaving] = useState(false);
  const [savingPlayerId, setSavingPlayerId] = useState<string | null>(null);

  useEffect(() => {
    void fetchTraining();
  }, [fetchTraining]);

  const squad = trainingCache?.squad ?? null;
  const players = snapshot.myPlayers;
  const avgCondition = players.length
    ? Math.round(players.reduce((s, p) => s + p.condition, 0) / players.length)
    : 0;
  const injuries = players.filter((p) => p.injuryWeeks > 0).length;

  const hints = trainingCache?.hints;
  const focusHint = (f: TrainingFocus): string => {
    const fromHints = hints?.focuses.find((x) => x.code === f)?.attrLabels;
    return fromHints && fromHints.length > 0 ? fromHints.join(', ') : FOCUS_META[f].hint;
  };

  const pickFocus = (f: TrainingFocus) => {
    setLocalFocus(f);
  };

  const handleSave = async () => {
    setSaving(true);
    const ok = await setTraining(focus, intensity);
    setSaving(false);
    if (ok) {
      setLocalFocus(null);
      setLocalIntensity(null);
      toast.success('Программа тренировок на неделю сохранена');
    }
  };

  const handleSetIndividual = async (
    playerId: string,
    individual: { focus: TrainingFocus; intensity: TrainingIntensity } | null,
  ) => {
    setSavingPlayerId(playerId);
    const ok = await setPlayerTraining(playerId, individual);
    setSavingPlayerId(null);
    if (!ok) {
      void fetchTraining(); // откат UI на серверное состояние
    }
  };

  const disabled = saving || loading || !dirty;

  return (
    <div className="space-y-4">
      <section className="visual-panel rounded-2xl border border-[#53e6a0]/25 bg-card p-5 shadow-[0_18px_50px_rgba(0,0,0,.22)] sm:p-6" style={{ backgroundImage: "url('/visuals/training-grid.svg')" }}>
        <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-[#53e6a0]"><Activity className="size-3.5" aria-hidden /> Training ground // session planner</p>
            <h1 className="mt-2 text-2xl font-black tracking-tight sm:text-3xl">Тренировочный штаб</h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">Соберите сессию под ближайший матч: выберите направление, нагрузку и точечно настройте развитие игроков.</p>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            <div className="rounded-xl border border-border/60 bg-background/60 px-3 py-2.5"><div className="text-[10px] uppercase tracking-wide text-muted-foreground">Фокус</div><div className="mt-1 flex items-center gap-1.5 text-xs font-bold text-[#53e6a0]"><Target className="size-3.5" aria-hidden />{FOCUS_LABELS[focus]}</div></div>
            <div className="rounded-xl border border-border/60 bg-background/60 px-3 py-2.5"><div className="text-[10px] uppercase tracking-wide text-muted-foreground">Нагрузка</div><div className={cn('mt-1 flex items-center gap-1.5 text-xs font-bold', INTENSITY_META[intensity].tone)}><Zap className="size-3.5" aria-hidden />{INTENSITY_META[intensity].label}</div></div>
            <div className="col-span-2 rounded-xl border border-border/60 bg-background/60 px-3 py-2.5 sm:col-span-1"><div className="text-[10px] uppercase tracking-wide text-muted-foreground">Статус</div><div className="mt-1 text-xs font-bold text-primary">{dirty ? 'Есть изменения' : 'Сессия готова'}</div></div>
          </div>
        </div>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-border/50 pt-4">
          <p className="text-[11px] text-muted-foreground">{INTENSITY_META[intensity].note}. План применится во время следующей симуляции недели.</p>
          <Button size="lg" className="h-11 gap-2 bg-[#53e6a0] px-5 font-bold text-[#07121d] hover:bg-[#7af2bc]" onClick={() => void handleSave()} disabled={disabled}>
            {saving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Dumbbell className="size-4" aria-hidden />}
            {saving ? 'Сохраняем план…' : dirty ? 'Сохранить план тренировки' : 'План сохранён'}
          </Button>
        </div>
      </section>
      {/* Индикаторы клуба */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="text-[11px] text-muted-foreground">Среднее состояние</div>
            <div className="mt-1 flex items-center gap-2">
              <Progress
                value={avgCondition}
                className="h-1.5"
                aria-label="Среднее состояние состава"
              />
              <span className="shrink-0 text-sm font-bold tabular">{avgCondition}</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/70">
          <CardContent className="p-3">
            <div className="text-[11px] text-muted-foreground">Травмированы</div>
            <div className="mt-1">
              {injuries > 0 ? (
                <Badge className="border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444]">
                  <Bandage className="size-3" aria-hidden />
                  {injuries} игрок(ов)
                </Badge>
              ) : (
                <Badge className="border border-[#22C55E]/40 bg-[#22C55E]/10 text-[#22C55E]">
                  Все здоровы
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-2 border-border/70">
          <CardContent className="flex h-full items-center gap-2 p-3 text-[11px] text-muted-foreground">
            <Dumbbell className="size-4 shrink-0 text-primary" aria-hidden />
            Тренировки применяются каждый тур после матча. Рост зависит от возраста,
            интенсивности, штата тренеров и запаса потенциала. Индивидуальные программы
            переопределяют командную для конкретного игрока.
          </CardContent>
        </Card>
      </div>

      {/* Фокус недели */}
      <Card className="border-border/70">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Фокус недели</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {FOCUS_ORDER.map((f) => {
              const meta = FOCUS_META[f];
              const selected = focus === f;
              return (
                <button
                  key={f}
                  type="button"
                  onClick={() => pickFocus(f)}
                  aria-pressed={selected}
                  className={cn(
                    'flex min-h-[88px] flex-col items-start gap-1.5 rounded-lg border bg-secondary/30 p-3 text-left transition-colors',
                    selected
                      ? 'border-primary bg-primary/10'
                      : 'border-border/60 hover:border-primary/40',
                  )}
                >
                  <meta.icon
                    className={cn('size-5', selected ? 'text-primary' : 'text-muted-foreground')}
                    aria-hidden
                  />
                  <span className={cn('text-xs font-semibold', selected && 'text-primary')}>
                    {hints?.focuses.find((x) => x.code === f)?.label ?? FOCUS_LABELS[f]}
                  </span>
                  <span className="text-[10px] leading-snug text-muted-foreground">
                    {focusHint(f)}
                  </span>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Интенсивность: ползунок (Модуль 4 — «ползунки интенсивности») */}
      <Card className="border-border/70">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Интенсивность</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-[1fr_auto] sm:items-center">
            <div className="space-y-2">
              <Slider
                value={[INTENSITY_INDEX[intensity]]}
                min={0}
                max={2}
                step={1}
                onValueChange={([v]) => setLocalIntensity(INTENSITY_BY_INDEX[v] ?? 'normal')}
                aria-label="Интенсивность тренировок"
                className="py-2"
              />
              <div className="flex justify-between text-[10px] text-muted-foreground">
                {INTENSITY_ORDER.map((i) => (
                  <span key={i} className={cn(i === intensity && INTENSITY_META[i].tone)}>
                    {hints?.intensities.find((x) => x.code === i)?.label ?? INTENSITY_META[i].label}
                  </span>
                ))}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-muted-foreground">Эффект недели</div>
              <div className={cn('text-xs font-semibold', INTENSITY_META[intensity].tone)}>
                {INTENSITY_META[intensity].note}
              </div>
              <div className="mt-0.5 text-[10px] text-muted-foreground">
                рост ×{TRAIN_GROWTH_OF[intensity]}
              </div>
            </div>
          </div>
          {intensity === 'hard' ? (
            <Alert className="border-[#EF4444]/40 bg-[#EF4444]/5">
              <AlertTriangle className="size-4 text-[#EF4444]" aria-hidden />
              <AlertTitle className="text-sm text-[#EF4444]">Жёсткий режим</AlertTitle>
              <AlertDescription className="text-xs">
                Риск травм 3% на игрока за неделю и −8 к состоянию после матча.
                Молодые игроки растут быстрее, но усталость копится. Физиотерапевт
                штата снижает риск (вкладка «Персонал»).
              </AlertDescription>
            </Alert>
          ) : null}
          <Button
            size="lg"
            className="h-12 w-full text-base sm:w-auto sm:px-8"
            onClick={() => void handleSave()}
            disabled={disabled}
          >
            {saving ? (
              <Loader2 className="size-5 animate-spin" aria-hidden />
            ) : (
              <Save className="size-5" aria-hidden />
            )}
            {dirty ? 'Сохранить программу' : 'Программа на неделю актуальна'}
          </Button>
        </CardContent>
      </Card>

      {/* Прогресс состава */}
      <Card className="border-border/70">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Прогресс состава</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {trainingLoading && !squad ? (
            <div className="flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground">
              <Loader2 className="size-5 animate-spin" aria-hidden />
              Загружаем состав…
            </div>
          ) : squad ? (
            <>
              <p className="text-[11px] text-muted-foreground">
                Полоски — накопленный опыт по атрибутам текущего фокуса (до +1 к атрибуту).
                «Индивидуально» — личная программа игрока: свой фокус и интенсивность.
              </p>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <SquadProgress
                  squad={squad}
                  teamFocus={focus}
                  onSetIndividual={handleSetIndividual}
                  savingPlayerId={savingPlayerId}
                />
              </motion.div>
            </>
          ) : (
            <p className="py-4 text-center text-xs text-muted-foreground">
              Данные тренировок появятся после загрузки.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/** Множители роста интенсивности (для подписи ползунка). */
const TRAIN_GROWTH_OF: Record<TrainingIntensity, string> = {
  light: '0.6',
  normal: '1.0',
  hard: '1.5',
};

/** Экран «Тренировки»: программа недели + персонал (Модуль 4). */
export function TrainingScreen() {
  return (
    <div className="space-y-4">
      <SectionHeader
        title="Тренировки и персонал"
        subtitle="Программа недели, индивидуальные планы и тренерский штаб клуба"
      />
      <Tabs defaultValue="program" className="space-y-4">
        <TabsList>
          <TabsTrigger value="program">Программа</TabsTrigger>
          <TabsTrigger value="staff">Персонал</TabsTrigger>
        </TabsList>
        <TabsContent value="program" className="space-y-4">
          <ProgramTab />
        </TabsContent>
        <TabsContent value="staff" className="space-y-4">
          <StaffTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
